import React, { useEffect, useState } from 'react';

/**
 * Self-Improvement status — real data only.
 * - Reads lessons from GET /api/engine/lessons (learningLoop.ts).
 * - "analyzing" is shown ONLY when real code dispatches
 *   window event 'zyntheor-self-improvement' with detail { running: boolean }.
 *   Nothing emits it yet, so today the indicator never claims analysis is running.
 * - If the API is unreachable it shows UNAVAILABLE, never a fake "ready".
 */
type Lesson = { status: 'CANDIDATE' | 'VALIDATED' | 'REJECTED' | 'STALE' };

export const SelfImprovementIndicator: React.FC<{ lang?: 'en' | 'th' }> = ({ lang = 'th' }) => {
  const [lessons, setLessons] = useState<Lesson[] | null>(null);
  const [unavailable, setUnavailable] = useState(false);
  const [running, setRunning] = useState(false);
  const th = lang === 'th';

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch('/api/engine/lessons');
        if (!res.ok) throw new Error(String(res.status));
        const data = await res.json();
        if (!cancelled) { setLessons(data.lessons ?? []); setUnavailable(false); }
      } catch {
        if (!cancelled) setUnavailable(true);
      }
    };
    load();
    const id = window.setInterval(load, 15000);
    const onEvt = (e: Event) => setRunning(Boolean((e as CustomEvent).detail?.running));
    window.addEventListener('zyntheor-self-improvement', onEvt);
    return () => { cancelled = true; clearInterval(id); window.removeEventListener('zyntheor-self-improvement', onEvt); };
  }, []);

  const count = (st: Lesson['status']) => (lessons ?? []).filter((l) => l.status === st).length;
  let label: string;
  let dot: string;
  if (unavailable) { label = 'UNAVAILABLE'; dot = 'bg-zinc-500'; }
  else if (running) { label = th ? 'กำลังวิเคราะห์จุดอ่อนของผลงานล่าสุด' : 'Analyzing weaknesses in recent outputs'; dot = 'bg-amber-400 animate-pulse'; }
  else if (lessons === null) { label = th ? 'กำลังตรวจสอบ…' : 'Checking…'; dot = 'bg-zinc-500 animate-pulse'; }
  else { label = th ? `ไม่ได้วิเคราะห์ · บทเรียน ${count('VALIDATED')} ยืนยันแล้ว / ${count('CANDIDATE')} รอยืนยัน` : `Idle · ${count('VALIDATED')} validated / ${count('CANDIDATE')} candidate lessons`; dot = 'bg-emerald-400'; }

  return (
    <div role="status" aria-label="Self-Improvement status" className="flex items-center gap-2 px-4 py-1 text-[11px] text-zinc-400">
      <span className={`inline-block h-2 w-2 rounded-full ${dot}`} />
      <span className="font-medium text-zinc-300">Self-Improvement</span>
      <span>{label}</span>
    </div>
  );
};
