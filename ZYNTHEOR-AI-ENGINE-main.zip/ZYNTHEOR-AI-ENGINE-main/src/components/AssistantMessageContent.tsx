import React from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-markup';
import 'prismjs/components/prism-markdown';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-yaml';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-sql';
import { ExternalLink } from 'lucide-react';
import { UrlPreviewCard } from './UrlPreviewCard';

const LANGUAGE_ALIASES: Record<string, string> = {
  js: 'javascript', ts: 'typescript', html: 'markup', xml: 'markup', sh: 'bash', shell: 'bash', py: 'python', yml: 'yaml', md: 'markdown',
};

function CodeBlock({ code, language }: { code: string; language: string }) {
  const normalized = LANGUAGE_ALIASES[language.toLowerCase()] || language.toLowerCase();
  const grammar = Prism.languages[normalized] || Prism.languages.plain;
  const highlighted = Prism.highlight(code, grammar, normalized);
  const lines = highlighted.split('\n');
  return (
    <div className="my-3 overflow-hidden rounded-xl border border-cyan-500/25 bg-[#050914]" onClick={(event) => event.stopPropagation()}>
      <div className="flex items-center justify-between border-b border-slate-800 px-3 py-1.5 text-[10px] text-slate-400">
        <span className="font-mono text-cyan-300">{language || 'code'}</span>
        <span>{lines.length} lines</span>
      </div>
      <pre className="m-0 overflow-x-auto py-2 text-[11px] leading-5"><code className={`language-${normalized}`}>
        {lines.map((line, index) => <span className="code-line flex min-h-[1.25rem]" key={index}><span aria-hidden="true" className="code-line-number sticky left-0 mr-3 w-10 shrink-0 select-none border-r border-slate-800 bg-[#050914] pr-2 text-right text-slate-600">{index + 1}</span><span className="pr-4" dangerouslySetInnerHTML={{ __html: line || '&nbsp;' }} /></span>)}
      </code></pre>
    </div>
  );
}

export function extractUrlsFromText(text: string): string[] {
  const urlRegex = /(?:https?:\/\/[^\s<>"')]+)/gi;
  const matches = text.match(urlRegex) || [];
  const cleanUrls = matches.map((u) => u.replace(/[.,;!?]+$/, '')).filter((u) => {
    try {
      const parsed = new URL(u);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  });
  return Array.from(new Set(cleanUrls));
}

function renderTextWithSafeLinks(
  text: string,
  searchQuery?: string,
  highlightText?: (text: string, query: string) => React.ReactNode,
  onOpenSafeRedirect?: (url: string) => void
): React.ReactNode {
  // Regex to match markdown links [label](url) OR raw URLs
  const linkRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)|(https?:\/\/[^\s<>"')]+)/gi;
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = linkRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      const nonLinkText = text.slice(lastIndex, match.index);
      parts.push(searchQuery && highlightText ? highlightText(nonLinkText, searchQuery) : nonLinkText);
    }

    const isMarkdown = Boolean(match[1] && match[2]);
    const label = isMarkdown ? match[1] : match[3];
    const targetUrl = (isMarkdown ? match[2] : match[3]).replace(/[.,;!?]+$/, '');

    parts.push(
      <a
        key={`link-${match.index}`}
        href={targetUrl}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          if (onOpenSafeRedirect) {
            onOpenSafeRedirect(targetUrl);
          } else {
            window.open(targetUrl, '_blank', 'noopener,noreferrer');
          }
        }}
        className="text-cyan-400 hover:text-cyan-300 underline font-medium cursor-pointer inline-flex items-center gap-0.5"
        title={`เปิดลิงก์: ${targetUrl} (ผ่านระบบตรวจสอบ Safe Redirect)`}
      >
        <span>{label}</span>
        <ExternalLink size={10} className="inline opacity-80 shrink-0" />
      </a>
    );

    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < text.length) {
    const remainingText = text.slice(lastIndex);
    parts.push(searchQuery && highlightText ? highlightText(remainingText, searchQuery) : remainingText);
  }

  return parts.length > 0 ? <>{parts}</> : (searchQuery && highlightText ? highlightText(text, searchQuery) : text);
}

/** Render markdown-style fenced code blocks with safe Prism token markup, line numbers, and link previews with safe redirects. */
export function AssistantMessageContent({
  content,
  searchQuery,
  highlightText,
  onOpenSafeRedirect,
}: {
  content: string;
  searchQuery?: string;
  highlightText?: (text: string, query: string) => React.ReactNode;
  onOpenSafeRedirect?: (url: string) => void;
}) {
  const parts = content.split(/```([^\n`]*)\n([\s\S]*?)```/g);
  const output: React.ReactNode[] = [];

  for (let i = 0; i < parts.length; i += 3) {
    const text = parts[i];
    if (text) {
      output.push(
        <React.Fragment key={`text-${i}`}>
          {renderTextWithSafeLinks(text, searchQuery, highlightText, onOpenSafeRedirect)}
        </React.Fragment>
      );
    }
    if (i + 1 < parts.length) {
      output.push(<CodeBlock key={`code-${i}`} language={parts[i + 1].trim()} code={parts[i + 2] || ''} />);
    }
  }

  // Extract URLs for visual preview cards (up to 3 previews per message)
  const urls = extractUrlsFromText(content).slice(0, 3);

  return (
    <>
      {output}
      {urls.length > 0 && (
        <div className="mt-2.5 pt-2 border-t border-slate-800/80 space-y-2">
          {urls.map((url) => (
            <UrlPreviewCard key={url} url={url} onOpenSafeRedirect={onOpenSafeRedirect} />
          ))}
        </div>
      )}
    </>
  );
}
