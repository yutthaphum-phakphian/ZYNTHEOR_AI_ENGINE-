import React, { useEffect, useRef } from 'react';
import { Copy, Bookmark, Trash2, AlertTriangle, Pencil, CheckSquare } from 'lucide-react';

export interface MessageContextMenuActionProps {
  x: number;
  y: number;
  isOpen: boolean;
  messageId: string;
  messageContent: string;
  isPinned: boolean;
  role: 'user' | 'assistant';
  onCopy: () => void;
  onEdit?: () => void;
  onTogglePin: () => void;
  onDelete: () => void;
  onReportIssue: () => void;
  onSelectMessage?: () => void;
  onClose: () => void;
}

export const MessageContextMenu: React.FC<MessageContextMenuActionProps> = ({
  x,
  y,
  isOpen,
  messageId,
  messageContent,
  isPinned,
  role,
  onCopy,
  onEdit,
  onTogglePin,
  onDelete,
  onReportIssue,
  onSelectMessage,
  onClose,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  // Close on outside click or escape
  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    const handleScroll = () => {
      onClose();
    };

    window.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('scroll', handleScroll, true);

    return () => {
      window.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('scroll', handleScroll, true);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Viewport edge calculation
  const menuWidth = 220;
  const menuHeight = 220;
  const adjustedX = typeof window !== 'undefined'
    ? Math.max(10, Math.min(x, window.innerWidth - menuWidth - 10))
    : x;
  const adjustedY = typeof window !== 'undefined'
    ? Math.max(10, Math.min(y, window.innerHeight - menuHeight - 10))
    : y;

  return (
    <div
      ref={menuRef}
      role="menu"
      aria-label="Message options context menu"
      data-testid="message-context-menu"
      style={{ left: `${adjustedX}px`, top: `${adjustedY}px` }}
      className="fixed z-[85] w-[220px] rounded-xl border border-cyan-500/40 bg-[#071026]/95 p-1.5 shadow-[0_10px_35px_rgba(0,0,0,0.7)] backdrop-blur-md animate-in fade-in zoom-in-95 duration-100 font-sans"
    >
      <div className="px-2 py-1 mb-1 border-b border-slate-800 text-[10px] font-mono text-cyan-400 flex items-center justify-between">
        <span>{role === 'assistant' ? 'ZYNTHEOR AI' : 'ข้อความของคุณ'}</span>
        <span className="text-slate-500">{messageId.slice(0, 8)}</span>
      </div>

      <div className="space-y-0.5">
        {/* 1. Copy Message / Save to Clipboard */}
        <button
          type="button"
          role="menuitem"
          data-testid="context-menu-copy"
          aria-label="Copy Message"
          onClick={async () => {
            if (messageContent && typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
              try {
                await navigator.clipboard.writeText(messageContent);
              } catch {
                // Clipboard write error handled gracefully; onCopy still triggers application notification
              }
            }
            onCopy();
            onClose();
          }}
          className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:text-white hover:bg-cyan-500/15 hover:border-cyan-500/30 transition-all text-left group cursor-pointer"
        >
          <Copy className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
          <span className="flex-1">Copy Message (Save to Clipboard)</span>
        </button>

        {/* 2. Edit Message */}
        {(role === 'user' || onEdit) && (
          <button
            type="button"
            role="menuitem"
            data-testid="context-menu-edit"
            aria-label="Edit Message"
            onClick={() => {
              if (onEdit) {
                onEdit();
              }
              onClose();
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:text-white hover:bg-cyan-500/15 transition-all text-left group cursor-pointer"
          >
            <Pencil className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
            <span className="flex-1">Edit Message (แก้ไขข้อความ)</span>
          </button>
        )}

        {/* 3. Select Message (Multi-selection mode) */}
        <button
          type="button"
          role="menuitem"
          data-testid="context-menu-select"
          aria-label="Select Message"
          onClick={() => {
            if (onSelectMessage) {
              onSelectMessage();
            }
            onClose();
          }}
          className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:text-white hover:bg-cyan-500/15 transition-all text-left group cursor-pointer"
        >
          <CheckSquare className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
          <span className="flex-1">Select Message (เลือกข้อความ)</span>
        </button>

        {/* 4. Pin Message */}
        <button
          type="button"
          role="menuitem"
          data-testid="context-menu-pin"
          onClick={() => {
            onTogglePin();
            onClose();
          }}
          className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:text-white hover:bg-amber-500/15 transition-all text-left group cursor-pointer"
        >
          <Bookmark className={`w-3.5 h-3.5 ${isPinned ? 'text-amber-400 fill-amber-400' : 'text-amber-400'} group-hover:scale-110 transition-transform`} />
          <span className="flex-1">
            {isPinned ? 'Unpin message (ถอนหมุด)' : 'Pin message (ปักหมุดข้อความ)'}
          </span>
        </button>

        {/* 4. Delete Message */}
        <button
          type="button"
          role="menuitem"
          data-testid="context-menu-delete"
          aria-label="Delete Message"
          onClick={() => {
            onDelete();
            onClose();
          }}
          className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs text-rose-300 hover:text-rose-200 hover:bg-rose-500/20 transition-all text-left group cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5 text-rose-400 group-hover:scale-110 transition-transform" />
          <span className="flex-1">Delete Message (Delete message)</span>
        </button>

        <div className="my-1 border-t border-slate-800" />

        {/* 4. Report Issue */}
        <button
          type="button"
          role="menuitem"
          onClick={() => {
            onReportIssue();
            onClose();
          }}
          className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs text-amber-300 hover:text-amber-200 hover:bg-amber-500/15 transition-all text-left group cursor-pointer"
        >
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
          <span className="flex-1">Report issue (รายงานปัญหา)</span>
        </button>
      </div>
    </div>
  );
};
