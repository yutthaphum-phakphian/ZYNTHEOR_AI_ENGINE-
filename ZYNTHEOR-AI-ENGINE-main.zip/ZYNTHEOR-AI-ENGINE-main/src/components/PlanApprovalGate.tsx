import { useState } from 'react'

type Proposal = { file: string, old: string, next: string, approved: boolean }

/**
 * P12 File Change Proposals - Diff + Approval Gate
 * Zero Phantom: no write until approved
 */
export function PlanApprovalGate({ proposals: initial = [] as Proposal[] }:{ proposals?: Proposal[] }) {
  const [proposals, setProposals] = useState<Proposal[]>(initial.length ? initial : [
    { file: 'server/routes/mobile-api.ts', old: '// old', next: '// new P11 mobile api', approved: false },
    { file: 'README.md', old: '# OLD', next: '# ZYNTHEOR v10.0-final', approved: false }
  ])

  const approve = (idx: number) => {
    setProposals(p => p.map((pr,i)=> i===idx ? {...pr, approved: true} : pr))
  }

  return (
    <div className="bg-zinc-900 rounded-xl p-4 border border-zinc-800">
      <div className="text-xs text-zinc-400 mb-3">P12 - File Change Proposals • Approval Gate • Diff View</div>
      {proposals.map((pr, i) => (
        <div key={i} className="mb-3 p-3 bg-zinc-950 rounded border border-zinc-800">
          <div className="flex justify-between text-xs">
            <span className="font-mono text-violet-400">{pr.file}</span>
            <span className={pr.approved ? 'text-emerald-400' : 'text-amber-400'}>{pr.approved ? 'APPROVED' : 'PENDING APPROVAL'}</span>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-2 font-mono text-[11px]">
            <div className="bg-red-950/30 p-2 rounded text-red-300">- {pr.old}</div>
            <div className="bg-emerald-950/30 p-2 rounded text-emerald-300">+ {pr.next}</div>
          </div>
          {!pr.approved && (
            <button onClick={()=>approve(i)} className="mt-2 px-3 py-1 bg-violet-600 rounded text-xs">Approve</button>
          )}
        </div>
      ))}
      <div className="text-[10px] text-zinc-500 mt-2">Zero-Fake: No write until human approves. Digest verified.</div>
    </div>
  )
}
