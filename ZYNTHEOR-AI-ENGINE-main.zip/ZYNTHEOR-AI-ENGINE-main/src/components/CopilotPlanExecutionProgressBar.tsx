import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Play,
  Pause,
  CheckCircle2,
  Clock,
  RotateCcw,
  FastForward,
  X,
  ChevronDown,
  ChevronUp,
  Layers,
  Check,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { Plan as CopilotPlan, PlanStep as CopilotStep } from '../../features/copilot/plans/types';

export interface CopilotPlanExecutionProgressBarProps {
  plan: CopilotPlan;
  isExecuting?: boolean;
  initialElapsedSeconds?: number;
  onUpdatePlan?: (updated: CopilotPlan) => void;
  onStepComplete?: (stepId: string, status: 'done' | 'in_progress' | 'pending') => Promise<void> | void;
  onClose?: () => void;
  onOpenInPlansStudio?: () => void;
  lang?: 'en' | 'th';
}

export const CopilotPlanExecutionProgressBar: React.FC<CopilotPlanExecutionProgressBarProps> = ({
  plan,
  isExecuting: initialIsExecuting = true,
  initialElapsedSeconds = 0,
  onUpdatePlan,
  onStepComplete,
  onClose,
  onOpenInPlansStudio,
  lang = 'th',
}) => {
  const [isExecuting, setIsExecuting] = useState(initialIsExecuting);
  const [elapsedSeconds, setElapsedSeconds] = useState(initialElapsedSeconds);
  const [expanded, setExpanded] = useState(false);
  const [localSteps, setLocalSteps] = useState<CopilotStep[]>(plan.steps || []);
  const executionTimerRef = useRef<number | null>(null);
  
  // Sync internal steps if plan prop updates
  useEffect(() => {
    setLocalSteps(plan.steps || []);
  }, [plan]);

  // Elapsed timer tick (1 second intervals during active execution)
  useEffect(() => {
    if (isExecuting) {
      executionTimerRef.current = window.setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (executionTimerRef.current) clearInterval(executionTimerRef.current);
    }

    return () => {
      if (executionTimerRef.current) clearInterval(executionTimerRef.current);
    };
  }, [isExecuting]);

  const totalSteps = localSteps.length;
  const completedSteps = localSteps.filter((s) => s.status === 'done').length;
  const currentStepIndex = localSteps.findIndex((s) => s.status === 'in_progress');
  const activeStep = currentStepIndex !== -1 ? localSteps[currentStepIndex] : localSteps.find((s) => s.status === 'pending');
  const calculatedProgress = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;
  const isAllCompleted = totalSteps > 0 && completedSteps === totalSteps;

  // No simulated auto-advance: a step is "done" only when the server reports it
  // (or the user marks it). While executing, poll the real plan state.
  useEffect(() => {
    if (!isExecuting || isAllCompleted) return;
    let cancelled = false;
    const tick = async () => {
      try {
        const res = await fetch(`/api/copilot/plans/${plan.id}`);
        if (!res.ok) return;
        const data = await res.json();
        if (cancelled || !data?.plan?.steps) return;
        setLocalSteps(data.plan.steps);
      } catch { /* keep last known real state */ }
    };
    const id = window.setInterval(tick, 2000);
    return () => { cancelled = true; clearInterval(id); };
  }, [isExecuting, isAllCompleted, plan.id]);

  // Execute or advance single step
  const handleExecuteStep = async (stepId: string, targetStatus: 'done' | 'in_progress' | 'pending') => {
    const updated = localSteps.map((s) => {
      if (s.id === stepId) return { ...s, status: targetStatus };
      return s;
    });
    setLocalSteps(updated);

    const doneCount = updated.filter((s) => s.status === 'done').length;
    const newProgress = Math.round((doneCount / updated.length) * 100);
    const updatedPlan: CopilotPlan = {
      ...plan,
      steps: updated,
      progress: newProgress,
      status: newProgress === 100 ? 'completed' : 'active',
      updatedAt: new Date().toISOString(),
    };

    if (onUpdatePlan) {
      onUpdatePlan(updatedPlan);
    }

    if (onStepComplete) {
      try {
        await onStepComplete(stepId, targetStatus);
      } catch (e) {
        console.warn('Step sync error:', e);
      }
    }

    // Call server API to keep persistence in sync
    try {
      await fetch(`/api/copilot/plans/${plan.id}/step`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stepId, status: targetStatus }),
      });
    } catch (err) {
      console.warn('Failed to sync plan step to server:', err);
    }

    if (newProgress === 100) {
      setIsExecuting(false);
    }
  };

  const handleManualNextStep = () => {
    const inProg = localSteps.findIndex((s) => s.status === 'in_progress');
    if (inProg !== -1) {
      handleExecuteStep(localSteps[inProg].id, 'done');
    } else {
      const nextPending = localSteps.findIndex((s) => s.status === 'pending');
      if (nextPending !== -1) {
        handleExecuteStep(localSteps[nextPending].id, 'done');
      }
    }
  };

  const handleReset = async () => {
    setIsExecuting(false);
    setElapsedSeconds(0);
    const reset = localSteps.map((s) => ({ ...s, status: 'pending' as const }));
    setLocalSteps(reset);
    if (onUpdatePlan) {
      onUpdatePlan({ ...plan, steps: reset, progress: 0, status: 'active' });
    }
    for (const step of reset) {
      try {
        await fetch(`/api/copilot/plans/${plan.id}/step`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stepId: step.id, status: 'pending' }),
        });
      } catch { /* optional */ }
    }
  };

  return (
    <aside
      aria-label="Copilot Plan active execution status and progress"
      className={`mx-2 sm:mx-4 my-2 rounded-2xl border transition-all duration-300 shadow-xl overflow-hidden backdrop-blur-md ${
        isAllCompleted
          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
          : isExecuting
          ? 'bg-zinc-900/95 border-blue-500/50 text-zinc-100 ring-1 ring-blue-500/20'
          : 'bg-zinc-900/90 border-zinc-750 text-zinc-200'
      }`}
    >
      {/* Top Banner Row */}
      <div className="p-3 sm:px-4 sm:py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Icon, Title & Status */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border transition-all ${
              isAllCompleted
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                : isExecuting
                ? 'bg-blue-500/20 border-blue-500/40 text-blue-400 animate-pulse'
                : 'bg-zinc-800 border-zinc-700 text-zinc-400'
            }`}
          >
            {isAllCompleted ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <Layers className="w-4 h-4 text-blue-400" />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono">
                Copilot Plan
              </span>
              <h3 className="text-xs sm:text-sm font-bold truncate text-zinc-100 max-w-[180px] sm:max-w-xs md:max-w-md" title={plan.title}>
                {plan.title}
              </h3>
            </div>

            {/* Sub-status: Active Step or Completion summary */}
            <p className="text-[11px] text-zinc-400 truncate flex items-center gap-1.5 mt-0.5">
              {isAllCompleted ? (
                <span className="text-emerald-400 font-medium flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  {lang === 'th' ? 'ดำเนินการสำเร็จครบถ้วนทุกขั้นตอน' : 'All steps completed successfully'}
                </span>
              ) : activeStep ? (
                <>
                  <span className="text-blue-400 font-medium">
                    {lang === 'th' ? 'กำลังดำเนินการ:' : 'Running:'}
                  </span>
                  <span className="text-zinc-300 truncate font-mono">
                    {activeStep.title}
                  </span>
                </>
              ) : (
                <span className="text-zinc-500">{plan.description || (lang === 'th' ? 'พร้อมดำเนินการ' : 'Ready to execute')}</span>
              )}
            </p>
          </div>
        </div>

        {/* Right: Timer, Step Count, Action Buttons */}
        <div className="flex items-center gap-2 shrink-0 ml-auto sm:ml-0">
          {/* Active processing timer badge (e.g. "ประมวลผล 11s") */}
          <div
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono font-semibold border shadow-sm transition-all ${
              isAllCompleted
                ? 'bg-emerald-950/80 border-emerald-700/60 text-emerald-300'
                : isExecuting
                ? 'bg-blue-950/80 border-blue-700/60 text-blue-300 ring-1 ring-blue-500/30'
                : 'bg-zinc-800 border-zinc-750 text-zinc-300'
            }`}
            title={lang === 'th' ? 'ระยะเวลาประมวลผลการทำงาน' : 'Execution elapsed time'}
          >
            <Clock className={`w-3.5 h-3.5 ${isExecuting ? 'animate-spin text-blue-400' : 'text-zinc-400'}`} />
            <span>
              {lang === 'th' ? `ประมวลผล ${elapsedSeconds}s` : `Running ${elapsedSeconds}s`}
            </span>
          </div>

          {/* Step Counter Badge */}
          <div className="px-2.5 py-1 rounded-lg bg-zinc-800/80 border border-zinc-700/70 text-xs font-mono font-bold text-zinc-200">
            <span className="text-blue-400">{completedSteps}</span>
            <span className="text-zinc-500">/</span>
            <span>{totalSteps}</span>
            <span className="text-zinc-400 font-normal ml-1 text-[11px]">
              ({calculatedProgress}%)
            </span>
          </div>

          {/* Play/Pause Control */}
          {!isAllCompleted && (
            <button
              type="button"
              onClick={() => setIsExecuting(!isExecuting)}
              className={`p-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
                isExecuting
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300 hover:bg-amber-500/30'
                  : 'bg-blue-600 border-blue-500 text-white hover:bg-blue-500'
              }`}
              title={isExecuting ? (lang === 'th' ? 'พักการรันชั่วคราว' : 'Pause') : (lang === 'th' ? 'ดำเนินการต่อ' : 'Resume')}
              aria-label={isExecuting ? (lang === 'th' ? 'พักการรันชั่วคราว' : 'Pause execution') : (lang === 'th' ? 'ดำเนินการต่อ' : 'Resume execution')}
            >
              {isExecuting ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            </button>
          )}

          {/* Advance single step button */}
          {!isAllCompleted && (
            <button
              type="button"
              onClick={handleManualNextStep}
              className="p-1.5 rounded-lg bg-zinc-800 border border-zinc-700 hover:bg-zinc-750 text-zinc-300 hover:text-zinc-100 transition-colors cursor-pointer"
              title={lang === 'th' ? 'รันขั้นตอนถัดไปทันที' : 'Advance to next step'}
              aria-label={lang === 'th' ? 'รันขั้นตอนถัดไปทันที' : 'Advance to next step'}
            >
              <FastForward className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Reset button if all done */}
          {isAllCompleted && (
            <button
              type="button"
              onClick={handleReset}
              className="p-1.5 rounded-lg bg-zinc-800 border border-zinc-700 hover:bg-zinc-750 text-zinc-300 hover:text-zinc-100 transition-colors cursor-pointer"
              title={lang === 'th' ? 'รันแผนงานอีกครั้ง' : 'Rerun plan'}
              aria-label={lang === 'th' ? 'รันแผนงานอีกครั้ง' : 'Rerun plan'}
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Expand / Collapse Details Button */}
          <button
            type="button"
            onClick={() => setExpanded(!expanded)}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors cursor-pointer"
            title={expanded ? (lang === 'th' ? 'ย่อรายละเอียด' : 'Collapse') : (lang === 'th' ? 'ดูขั้นตอนทั้งหมด' : 'Expand')}
            aria-label={expanded ? (lang === 'th' ? 'ย่อรายละเอียด' : 'Collapse plan details') : (lang === 'th' ? 'ดูขั้นตอนทั้งหมด' : 'Expand plan details')}
          >
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {/* Dismiss button */}
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 transition-colors cursor-pointer"
              title={lang === 'th' ? 'ปิดแถบความคืบหน้า' : 'Close progress bar'}
              aria-label={lang === 'th' ? 'ปิดแถบความคืบหน้า' : 'Close progress bar'}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Visual Progress Bar Section with Step Markers */}
      <div className="px-3 sm:px-4 pb-3">
        <div className="relative h-2.5 w-full bg-zinc-800/90 rounded-full overflow-hidden p-0.5 border border-zinc-700/60 shadow-inner">
          <div
            className={`h-full rounded-full transition-all duration-500 ease-out relative ${
              isAllCompleted
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-sm shadow-emerald-500/50'
                : 'bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-400 shadow-sm shadow-blue-500/50'
            }`}
            style={{ width: `${Math.max(calculatedProgress, 2)}%` }}
          >
            {/* Shimmer light bar across active fill during execution */}
            {isExecuting && !isAllCompleted && (
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent animate-[shimmer_2s_infinite] w-full" />
            )}
          </div>
        </div>

        {/* Step Checkpoints Line */}
        {totalSteps > 1 && totalSteps <= 8 && (
          <div className="flex justify-between px-1 mt-1.5 text-[10px] font-mono">
            {localSteps.map((s, idx) => {
              const isDone = s.status === 'done';
              const isInProg = s.status === 'in_progress';
              return (
                <div
                  key={s.id || idx}
                  className={`flex items-center gap-1 transition-colors cursor-pointer ${
                    isDone
                      ? 'text-emerald-400 font-bold'
                      : isInProg
                      ? 'text-amber-400 font-bold animate-pulse'
                      : 'text-zinc-500'
                  }`}
                  onClick={() => handleExecuteStep(s.id, isDone ? 'pending' : 'done')}
                  title={`${s.title} (${s.status})`}
                >
                  <span className="w-1.5 h-1.5 rounded-full inline-block bg-current" />
                  <span className="hidden sm:inline truncate max-w-[90px]">
                    {idx + 1}. {s.title}
                  </span>
                  <span className="sm:hidden font-mono">#{idx + 1}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Expanded Step List View */}
      {expanded && (
        <div className="border-t border-zinc-800/80 bg-zinc-950/60 p-3 sm:p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-zinc-400 mb-2">
            <span className="font-semibold text-zinc-300">
              {lang === 'th' ? 'รายการขั้นตอนในแผนงาน Copilot:' : 'Copilot Plan Step Breakdown:'}
            </span>
            {onOpenInPlansStudio && (
              <button
                type="button"
                onClick={onOpenInPlansStudio}
                className="text-[11px] text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer"
              >
                <ExternalLink className="w-3 h-3" />
                <span>{lang === 'th' ? 'เปิดใน Plans Studio' : 'Open in Plans Studio'}</span>
              </button>
            )}
          </div>

          <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {localSteps.map((step, idx) => {
              const isDone = step.status === 'done';
              const isInProg = step.status === 'in_progress';
              return (
                <div
                  key={step.id || idx}
                  onClick={() => handleExecuteStep(step.id, isDone ? 'pending' : 'done')}
                  className={`flex items-center justify-between gap-3 p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                    isDone
                      ? 'bg-emerald-950/25 border-emerald-900/40 text-zinc-200'
                      : isInProg
                      ? 'bg-blue-950/30 border-blue-900/50 text-blue-100 ring-1 ring-blue-500/30'
                      : 'bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:bg-zinc-850'
                  }`}
                  title={lang === 'th' ? 'คลิกเพื่อสลับสถานะ' : 'Click to toggle status'}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : isInProg ? (
                      <Clock className="w-4 h-4 text-blue-400 animate-spin shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-zinc-600 shrink-0" />
                    )}
                    <span className={`truncate font-medium ${isDone ? 'line-through text-zinc-400' : 'text-zinc-200'}`}>
                      {idx + 1}. {step.title}
                    </span>
                  </div>

                  <span
                    className={`text-[9px] px-2 py-0.5 rounded font-mono font-bold uppercase shrink-0 ${
                      isDone
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                        : isInProg
                        ? 'bg-blue-950 text-blue-400 border border-blue-900'
                        : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {step.status}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </aside>
  );
};
