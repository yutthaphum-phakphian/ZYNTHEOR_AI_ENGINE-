import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Copy, RefreshCw, ShieldCheck, X } from 'lucide-react';

type AuditEvent = {
  id?: string;
  type?: string;
  at?: string;
  timestamp?: string;
  status?: string;
  data?: Record<string, unknown>;
};

type LedgerEntry = {
  id?: string;
  index?: number;
  timestamp?: string;
  eventType?: string;
  target?: string;
  status?: string;
  ledgerHash?: string;
  payloadHash?: string;
  details?: string;
};

interface CryptographicEvidenceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CryptographicEvidenceModal: React.FC<CryptographicEvidenceModalProps> = ({ isOpen, onClose }) => {
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const loadLedger = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/audit', { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(`Audit endpoint returned HTTP ${response.status}`);
      const payload = await response.json();
      setEvents(Array.isArray(payload.events) ? payload.events : []);
      setLedger(Array.isArray(payload.ledger) ? payload.ledger : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load the audit ledger.');
      setEvents([]);
      setLedger([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) void loadLedger();
  }, [isOpen, loadLedger]);

  const rows = useMemo(() => {
    const byTime = new Map<string, LedgerEntry>();
    ledger.forEach((entry) => byTime.set(entry.timestamp || '', entry));
    return events.map((event, index) => {
      const timestamp = event.at || event.timestamp || '';
      const matchingLedger = byTime.get(timestamp) || ledger[ledger.length - events.length + index];
      return { event, ledger: matchingLedger };
    });
  }, [events, ledger]);

  const copyHash = async (hash: string) => {
    await navigator.clipboard?.writeText(hash);
    setCopied(hash);
    window.setTimeout(() => setCopied(null), 1600);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="evidence-ledger-title">
      <div className="w-full max-w-6xl max-h-[90vh] flex flex-col overflow-hidden rounded-2xl border border-cyan-500/35 bg-[#070d1b] shadow-2xl shadow-cyan-950/40">
        <div className="flex items-center justify-between gap-4 px-5 py-4 border-b border-cyan-500/20 bg-[#0b1730]">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-lg bg-cyan-500/15 text-cyan-300 border border-cyan-500/30"><ShieldCheck size={18} /></div>
            <div className="min-w-0">
              <h2 id="evidence-ledger-title" className="text-sm font-bold text-white">Cryptographic Evidence Ledger</h2>
              <p className="text-[11px] text-slate-400 truncate">Raw interaction history from <code className="text-cyan-300">/api/audit</code> with SHA-256 signatures</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button type="button" onClick={() => void loadLedger()} disabled={loading} className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-300 hover:text-white disabled:opacity-50 text-xs">
              <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Refresh
            </button>
            <button type="button" onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800" aria-label="Close evidence ledger"><X size={18} /></button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 p-4 border-b border-slate-800 bg-[#060b16] text-xs">
          <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-2"><div className="text-[10px] text-slate-500 uppercase">Interactions</div><div className="mt-1 text-lg font-bold text-white">{events.length}</div></div>
          <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-2"><div className="text-[10px] text-slate-500 uppercase">Ledger entries</div><div className="mt-1 text-lg font-bold text-white">{ledger.length}</div></div>
          <div className="rounded-lg border border-emerald-500/20 bg-emerald-950/20 p-2"><div className="text-[10px] text-emerald-300/70 uppercase">SHA-256 signatures</div><div className="mt-1 flex items-center gap-1 text-emerald-300"><CheckCircle2 size={14} /> Available</div></div>
          <div className="rounded-lg border border-cyan-500/20 bg-cyan-950/20 p-2"><div className="text-[10px] text-cyan-300/70 uppercase">Source</div><div className="mt-1 font-mono text-cyan-200">/api/audit</div></div>
        </div>

        <div className="flex-1 overflow-auto">
          {loading ? <div className="h-56 flex items-center justify-center gap-2 text-xs text-slate-400"><RefreshCw size={16} className="animate-spin text-cyan-400" /> Fetching raw ledger…</div> : error ? <div className="m-5 rounded-lg border border-rose-500/30 bg-rose-950/30 p-4 text-xs text-rose-200 flex items-center gap-2"><AlertTriangle size={16} />{error}</div> : rows.length === 0 ? <div className="h-56 flex items-center justify-center text-xs text-slate-500">No audit interactions have been recorded.</div> : (
            <table className="w-full min-w-[840px] text-left text-xs">
              <thead className="sticky top-0 bg-[#0a1223] text-[10px] uppercase tracking-wide text-slate-500 border-b border-slate-800">
                <tr><th className="px-4 py-3">Timestamp</th><th className="px-3 py-3">Action</th><th className="px-3 py-3">Status</th><th className="px-3 py-3">Verified SHA-256 signature</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {rows.map(({ event, ledger: entry }, index) => {
                  const hash = entry?.ledgerHash || '';
                  return <tr key={event.id || `${event.at}-${index}`} className="hover:bg-cyan-950/15 align-top">
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-300">{event.at || event.timestamp || entry?.timestamp || '—'}</td>
                    <td className="px-3 py-3"><div className="font-semibold text-cyan-300">{event.type || entry?.eventType || 'INTERACTION'}</div><div className="mt-1 max-w-[300px] truncate text-[10px] text-slate-500">{entry?.target || (event.data ? JSON.stringify(event.data) : '—')}</div></td>
                    <td className="px-3 py-3"><span className="rounded border border-emerald-500/25 bg-emerald-950/30 px-2 py-1 text-[10px] text-emerald-300">{event.status || entry?.status || 'RECORDED'}</span></td>
                    <td className="px-3 py-3"><div className="flex max-w-[360px] items-center gap-2"><code className="truncate text-[10px] text-amber-300" title={hash}>{hash || 'No cryptographic seal returned'}</code>{hash && <button type="button" onClick={() => void copyHash(hash)} className="shrink-0 rounded p-1 text-slate-500 hover:text-white" title="Copy SHA-256 signature">{copied === hash ? <CheckCircle2 size={13} className="text-emerald-400" /> : <Copy size={13} />}</button>}</div></td>
                  </tr>;
                })}
              </tbody>
            </table>
          )}
        </div>
        <div className="px-5 py-3 border-t border-slate-800 bg-[#060b16] text-[10px] text-slate-500">Transparency view only. Values are fetched from the running server and are not generated in the browser.</div>
      </div>
    </div>
  );
};
