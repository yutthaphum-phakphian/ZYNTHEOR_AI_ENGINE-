import React, { useEffect, useMemo } from 'react';
import { X, Code2 } from 'lucide-react';
import Prism from 'prismjs';
import 'prismjs/components/prism-markup';
import 'prismjs/components/prism-markdown';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-yaml';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-sql';
import { AttachedFile } from '../types/agent';
import { FileIconBadge } from './FileIconBadge';
import { formatFileSize } from '../utils/fileHelper';

interface AttachmentPreviewModalProps {
  file: AttachedFile | null;
  onClose: () => void;
}

const EXT_TO_LANG: Record<string, string> = {
  js: 'javascript',
  mjs: 'javascript',
  cjs: 'javascript',
  jsx: 'jsx',
  ts: 'typescript',
  mts: 'typescript',
  cts: 'typescript',
  tsx: 'tsx',
  json: 'json',
  py: 'python',
  sh: 'bash',
  bash: 'bash',
  zsh: 'bash',
  css: 'css',
  scss: 'css',
  html: 'markup',
  xml: 'markup',
  svg: 'markup',
  md: 'markdown',
  markdown: 'markdown',
  yaml: 'yaml',
  yml: 'yaml',
  sql: 'sql',
};

export const AttachmentPreviewModal: React.FC<AttachmentPreviewModalProps> = ({ file, onClose }) => {
  useEffect(() => {
    if (!file) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [file, onClose]);

  const rawContent = useMemo(() => {
    if (!file) return '';
    if (file.textSnippet) return file.textSnippet;
    if (file.dataUrl && file.dataUrl.startsWith('data:') && !file.type?.startsWith('image/')) {
      try {
        const parts = file.dataUrl.split(',');
        if (parts[1]) {
          return atob(parts[1]);
        }
      } catch {
        return '';
      }
    }
    return '';
  }, [file]);

  const detectedLanguage = useMemo(() => {
    if (!file) return 'none';
    const ext = (file.name.split('.').pop() || file.extension || '').toLowerCase();
    return EXT_TO_LANG[ext] || (ext === 'txt' ? 'none' : 'none');
  }, [file]);

  const highlightedLines = useMemo(() => {
    if (!rawContent) return [];
    const grammar = detectedLanguage === 'none' ? undefined : Prism.languages[detectedLanguage];
    return rawContent.split('\n').map((line, index) => ({
      index,
      raw: line,
      html: grammar ? Prism.highlight(line || ' ', grammar, detectedLanguage) : (line || ' '),
    }));
  }, [rawContent, detectedLanguage]);

  if (!file) return null;

  const isImage = file.type?.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp|ico)$/i.test(file.name);

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-gray-950/65 p-4 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      role="presentation"
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="attachment-preview-title"
        className="flex max-h-[min(85vh,760px)] w-full max-w-4xl flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-2xl dark:border-gray-700 dark:bg-gray-900"
      >
        <header className="flex items-center gap-3 border-b border-gray-200 px-4 py-3 dark:border-gray-800">
          <FileIconBadge file={file} size="md" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h2 id="attachment-preview-title" className="truncate text-sm font-semibold text-gray-900 dark:text-gray-100">
                {file.name}
              </h2>
              {rawContent && (
                <span className="inline-flex items-center gap-1 rounded bg-cyan-950/70 px-2 py-0.5 text-[10px] font-mono text-cyan-300 border border-cyan-500/30">
                  <Code2 className="h-3 w-3" />
                  {detectedLanguage}
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {formatFileSize(file.size)} · {file.type || 'Unknown type'}
              {highlightedLines.length > 0 && ` · ${highlightedLines.length} บรรทัด`}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-gray-100"
            aria-label="Close preview"
          >
            <X className="h-4 w-4" />
          </button>
        </header>
        <div className="min-h-40 overflow-auto bg-gray-50 p-4 dark:bg-gray-950">
          {isImage && file.previewUrl ? (
            <img src={file.previewUrl} alt={file.name} className="mx-auto max-h-[58vh] max-w-full object-contain" />
          ) : rawContent ? (
            <div className="overflow-hidden rounded-lg border border-slate-700/60 bg-[#050914] shadow-inner">
              <pre className="m-0 max-h-[60vh] overflow-auto py-3 text-xs leading-5 font-mono">
                <code className={`language-${detectedLanguage}`}>
                  {highlightedLines.map((line) => (
                    <span className="code-line flex min-h-[1.25rem] hover:bg-slate-900/50" key={line.index}>
                      <span
                        aria-hidden="true"
                        className="code-line-number sticky left-0 mr-3 w-10 shrink-0 select-none border-r border-slate-800 bg-[#050914] pr-2 text-right font-mono text-[11px] text-slate-500 tabular-nums"
                      >
                        {line.index + 1}
                      </span>
                      <span
                        className="pr-4 font-mono text-[11px] text-slate-200"
                        dangerouslySetInnerHTML={{ __html: line.html || '&nbsp;' }}
                      />
                    </span>
                  ))}
                </code>
              </pre>
            </div>
          ) : (
            <div className="flex min-h-40 items-center justify-center text-sm text-gray-500 dark:text-gray-400">
              No preview is available for this file type.
            </div>
          )}
        </div>
      </section>
    </div>
  );
};