import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ExternalLink,
  Copy,
  Check,
  X,
  AlertTriangle,
  Globe2,
  Lock,
} from 'lucide-react';
import type { UrlMetadata } from '../types/urlMetadata';

interface SafeRedirectModalProps {
  url: string | null;
  onClose: () => void;
}

export const SafeRedirectModal: React.FC<SafeRedirectModalProps> = ({ url, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [metadata, setMetadata] = useState<UrlMetadata | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!url) {
      setMetadata(null);
      return;
    }

    setLoading(true);
    let isCancelled = false;

    fetch(`/api/url-metadata?url=${encodeURIComponent(url)}`)
      .then((res) => res.json())
      .then((data) => {
        if (!isCancelled) {
          setMetadata(data);
        }
      })
      .catch(() => {
        if (!isCancelled) {
          let domain = 'external-website';
          try {
            domain = new URL(url).hostname;
          } catch {}
          setMetadata({
            url,
            domain,
            title: domain,
            description: null,
            image: null,
            status: 'FALLBACK',
          });
        }
      })
      .finally(() => {
        if (!isCancelled) setLoading(false);
      });

    return () => {
      isCancelled = true;
    };
  }, [url]);

  if (!url) return null;

  let domain = 'external-website';
  let isSecure = false;
  try {
    const parsed = new URL(url);
    domain = parsed.hostname;
    isSecure = parsed.protocol === 'https:';
  } catch {}

  const handleCopy = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleProceed = () => {
    // Open in new window safely with noopener, noreferrer
    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="safe-redirect-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg rounded-2xl bg-[#081226] border border-amber-500/40 shadow-[0_0_50px_rgba(245,158,11,0.25)] flex flex-col overflow-hidden text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Security Notice */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/20 bg-[#0d1a38]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0">
              <ShieldAlert size={20} />
            </div>
            <div>
              <h3 id="safe-redirect-title" className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>ยืนยันการเปิดลิงก์ภายนอก</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Safe Redirect
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">การตรวจสอบความปลอดภัยก่อนออกจากระบบ</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="ปิดหน้าต่าง"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 text-xs">
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200/90 leading-relaxed flex items-start gap-2.5">
            <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
            <div>
              คุณกำลังจะนำทางออกจาก <strong>ZYNTHEOR AI ENGINE</strong> ไปยังเว็บไซต์ภายนอกซึ่งเป็นบริการภายนอกที่ยังไม่ได้รับการรับรองความปลอดภัย กรุณาตรวจสอบลิงก์ก่อนดำเนินการ
            </div>
          </div>

          {/* Domain & URL Box */}
          <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 font-semibold flex items-center gap-1.5">
                <Globe2 size={13} className="text-cyan-400" />
                <span>โดเมนปลายทาง:</span>
              </span>
              <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono text-[11px] border border-cyan-500/30">
                {isSecure ? <Lock size={10} className="text-emerald-400" /> : <AlertTriangle size={10} className="text-amber-400" />}
                <span>{domain}</span>
              </span>
            </div>

            <div className="p-2 rounded bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 break-all select-all leading-normal">
              {url}
            </div>
          </div>

          {/* Scraped Visual Metadata Preview Card */}
          {metadata && metadata.title && (
            <div className="rounded-xl border border-cyan-500/30 bg-[#07132e]/90 overflow-hidden shadow-md">
              {metadata.image && (
                <div className="w-full h-32 sm:h-36 bg-slate-950 overflow-hidden relative border-b border-slate-800">
                  <img
                    src={metadata.image}
                    alt={metadata.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                    }}
                  />
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-xs text-[10px] text-cyan-300 font-mono flex items-center gap-1">
                    <Globe2 size={10} />
                    <span>{domain}</span>
                  </div>
                </div>
              )}
              <div className="p-3 space-y-1">
                <h4 className="text-xs font-bold text-slate-100 line-clamp-1">{metadata.title}</h4>
                {metadata.description && (
                  <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">{metadata.description}</p>
                )}
              </div>
            </div>
          )}

          {/* Safety Tips */}
          <div className="text-[11px] text-slate-400 space-y-1 pl-1">
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
              <span>ลิงก์จะถูกเปิดในแท็บใหม่ด้วยการตั้งค่าความปลอดภัย <code>rel="noopener noreferrer"</code></span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
              <span>อย่ากรอกข้อมูลความลับ เช่น รหัสผ่าน หรือ API Token บนเว็บไซต์ที่ไม่ไว้วางใจ</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-5 py-3.5 border-t border-slate-800 bg-[#060D1E] flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
            <span>{copied ? 'คัดลอกลิงก์แล้ว' : 'คัดลอกลิงก์'}</span>
          </button>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              ยกเลิก
            </button>
            <button
              type="button"
              onClick={handleProceed}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ExternalLink size={13} />
              <span>เปิดลิงก์ภายนอก</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
