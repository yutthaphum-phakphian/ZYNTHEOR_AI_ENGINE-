import React, { useState, useEffect, useCallback } from 'react';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Gauge,
  Key,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import type { GitHubRateLimitReport } from '../types/connectors';

interface GitHubRateLimitDashboardProps {
  lang: 'en' | 'th';
  githubToken?: string;
  onRefreshTrigger?: () => void;
}

export const GitHubRateLimitDashboard: React.FC<GitHubRateLimitDashboardProps> = ({
  lang,
  githubToken,
  onRefreshTrigger,
}) => {
  const th = lang === 'th';

  const [report, setReport] = useState<GitHubRateLimitReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [secondsUntilReset, setSecondsUntilReset] = useState<number | null>(null);

  const fetchRateLimit = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const activeToken =
        githubToken ||
        (typeof localStorage !== 'undefined'
          ? localStorage.getItem('zyntheor_github_token') ||
            localStorage.getItem('zyntheor_auth_token') ||
            ''
          : '');

      const headers: Record<string, string> = { Accept: 'application/json' };
      if (activeToken) {
        headers['x-github-token'] = activeToken;
        headers['Authorization'] = `Bearer ${activeToken}`;
      }

      const res = await fetch('/api/engine/connectors/github/rate-limit', { headers });
      if (!res.ok) {
        throw new Error(`Rate limit fetch failed: HTTP ${res.status}`);
      }
      const data = (await res.json()) as GitHubRateLimitReport;
      setReport(data);

      if (data.rate?.reset) {
        const now = Math.floor(Date.now() / 1000);
        setSecondsUntilReset(Math.max(0, data.rate.reset - now));
      }
    } catch (err: any) {
      setError(err.message || 'Failed to fetch rate limit');
      setReport(null);
      setSecondsUntilReset(null);
    } finally {
      setIsLoading(false);
      onRefreshTrigger?.();
    }
  }, [githubToken, onRefreshTrigger]);

  useEffect(() => {
    void fetchRateLimit();
  }, [fetchRateLimit]);

  // Countdown timer for quota reset
  useEffect(() => {
    if (secondsUntilReset === null || secondsUntilReset <= 0) return;
    const interval = setInterval(() => {
      setSecondsUntilReset((prev) => (prev !== null && prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [secondsUntilReset]);

  const formatCountdown = (secs: number | null) => {
    if (secs === null || secs <= 0) return th ? 'รีเซ็ตแล้ว' : 'Resetting';
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s < 10 ? '0' : ''}${s}s`;
  };

  const core = report?.resources?.core ?? { limit: 60, used: 0, remaining: 60, reset: 0 };
  const search = report?.resources?.search ?? { limit: 10, used: 0, remaining: 10, reset: 0 };
  const graphql = report?.resources?.graphql ?? { limit: 0, used: 0, remaining: 0, reset: 0 };
  const codeSearch = report?.resources?.code_search ?? { limit: 0, used: 0, remaining: 0, reset: 0 };

  const corePercentUsed = core.limit > 0 ? Math.min(100, Math.round((core.used / core.limit) * 100)) : 0;
  const isHighUsage = corePercentUsed >= 80;
  const isNearExhausted = core.remaining <= 5;

  // Chart data for Recharts BarChart
  const barChartData = [
    { name: 'Core REST', used: core.used, remaining: core.remaining, limit: core.limit },
    { name: 'Search API', used: search.used, remaining: search.remaining, limit: search.limit },
    { name: 'GraphQL', used: graphql.used, remaining: graphql.remaining, limit: graphql.limit },
    { name: 'Code Search', used: codeSearch.used, remaining: codeSearch.remaining, limit: codeSearch.limit },
  ];

  // Pie chart data for Core API usage
  const pieChartData = [
    { name: th ? 'ใช้งานแล้ว' : 'Used', value: Math.max(core.used, 1), fill: isHighUsage ? '#f43f5e' : '#14b8a6' },
    { name: th ? 'คงเหลือ' : 'Remaining', value: Math.max(core.remaining, 0), fill: '#27272a' },
  ];

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-400">
            <Gauge className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-zinc-100">
                {th ? 'การใช้งานโควตา GitHub API (Rate Limit Dashboard)' : 'GitHub API Rate Limit Dashboard'}
              </h3>
              {report?.authenticated ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-emerald-950/80 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  {th ? 'บัญชีเชื่อมต่อแล้ว (5,000/hr)' : 'Authenticated (5,000/hr)'}
                </span>
              ) : report ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-amber-950/80 text-amber-300 border border-amber-800 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  {th ? 'โควตาสาธารณะ (60/hr)' : 'Public Quota (60/hr)'}
                </span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-zinc-950/80 text-zinc-400 border border-zinc-700 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-zinc-500" />
                  {th ? 'UNAVAILABLE' : 'UNAVAILABLE'}
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              {th
                ? 'ติดตามปริมาณการเรียกใช้งาน GitHub REST API แบบเรียลไทม์ ป้องกันการถูกระงับสิทธิ์ชั่วคราว'
                : 'Monitor GitHub REST API consumption in real-time with visual Recharts gauges'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            type="button"
            onClick={() => void fetchRateLimit()}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium transition-colors disabled:opacity-50"
            title="Refresh GitHub Rate Limits"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-amber-400' : ''}`} />
            <span>{th ? 'รีเฟรชโควตา' : 'Refresh Limits'}</span>
          </button>
        </div>
      </div>

      {report ? (
        <>
      {/* Quota Warning Alert */}
      {isHighUsage && (
        <div className="p-3 bg-rose-950/70 border border-rose-800 rounded-xl text-xs text-rose-200 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
          <span>
            {th
              ? `คำเตือน: คุณใช้โควตา Core API ไปแล้ว ${corePercentUsed}% (${core.remaining} ครั้งคงเหลือ) กรุณารอรีเซ็ตเพื่อไม่ให้เกินขีดจำกัด`
              : `Warning: ${corePercentUsed}% of your Core API rate limit has been used. Only ${core.remaining} requests remain.`}
          </span>
        </div>
      )}

      {/* Key Metric Tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Core Limit */}
        <div className="p-3.5 bg-zinc-950/80 border border-zinc-850 rounded-xl space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
              {th ? 'Core REST คงเหลือ' : 'Core Remaining'}
            </span>
            <Activity className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-lg font-bold font-mono text-zinc-100">
            {core.remaining.toLocaleString()}
            <span className="text-xs font-normal text-zinc-500 font-mono"> / {core.limit.toLocaleString()}</span>
          </div>
          <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden mt-1.5">
            <div
              className={`h-full transition-all ${
                isNearExhausted ? 'bg-rose-500' : isHighUsage ? 'bg-amber-400' : 'bg-amber-500'
              }`}
              style={{ width: `${corePercentUsed}%` }}
            ></div>
          </div>
        </div>

        {/* Search API */}
        <div className="p-3.5 bg-zinc-950/80 border border-zinc-850 rounded-xl space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
              {th ? 'Search API คงเหลือ' : 'Search Remaining'}
            </span>
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-lg font-bold font-mono text-cyan-300">
            {search.remaining.toLocaleString()}
            <span className="text-xs font-normal text-zinc-500 font-mono"> / {search.limit.toLocaleString()}</span>
          </div>
          <div className="text-[10px] text-zinc-500">
            {th ? 'รีเซ็ตทุก 1 นาที' : 'Per-minute quota'}
          </div>
        </div>

        {/* Usage % */}
        <div className="p-3.5 bg-zinc-950/80 border border-zinc-850 rounded-xl space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
              {th ? 'อัตราการใช้งาน' : 'Quota Used'}
            </span>
            <Gauge className={`w-3.5 h-3.5 ${isHighUsage ? 'text-rose-400' : 'text-emerald-400'}`} />
          </div>
          <div className={`text-lg font-bold font-mono ${isHighUsage ? 'text-rose-400' : 'text-emerald-400'}`}>
            {corePercentUsed}%
          </div>
          <div className="text-[10px] text-zinc-500">
            {core.used.toLocaleString()} {th ? 'การเรียกใช้' : 'calls made'}
          </div>
        </div>

        {/* Countdown */}
        <div className="p-3.5 bg-zinc-950/80 border border-zinc-850 rounded-xl space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
              {th ? 'เวลารีเซ็ตโควตา' : 'Reset Timer'}
            </span>
            <Clock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-lg font-bold font-mono text-amber-300">
            {formatCountdown(secondsUntilReset)}
          </div>
          <div className="text-[10px] text-zinc-500 truncate">
            {report?.rate?.reset ? new Date(report.rate.reset * 1000).toLocaleTimeString() : 'Hourly'}
          </div>
        </div>
      </div>

      {/* Visual Recharts Charts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Bar Chart: Resources breakdown */}
        <div className="md:col-span-2 p-4 bg-zinc-950/70 border border-zinc-850 rounded-xl space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-zinc-300">
            <span>{th ? 'การกระจายโควตาตามหมวดหมู่ API (Recharts Bar View)' : 'API Resources Quota Distribution'}</span>
            <span className="text-[11px] font-mono text-zinc-500 font-normal">
              {th ? 'สีม่วง: ใช้แล้ว / สีเทา: คงเหลือ' : 'Purple: Used / Dark: Remaining'}
            </span>
          </div>

          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barChartData} margin={{ top: 8, right: 12, left: -20, bottom: 4 }}>
                <XAxis dataKey="name" tick={{ fill: '#a1a1aa', fontSize: 11 }} />
                <YAxis tick={{ fill: '#71717a', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '11px',
                    color: '#f4f4f5',
                  }}
                  formatter={(val: any, name: any) => [
                    Number(val).toLocaleString(),
                    name === 'used' ? (th ? 'ใช้งาน' : 'Used') : (th ? 'คงเหลือ' : 'Remaining'),
                  ]}
                />
                <Bar dataKey="used" fill="#14b8a6" radius={[4, 4, 0, 0]} name="used" />
                <Bar dataKey="remaining" fill="#3f3f46" radius={[4, 4, 0, 0]} name="remaining" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Donut Gauge: Core API Usage */}
        <div className="p-4 bg-zinc-950/70 border border-zinc-850 rounded-xl flex flex-col justify-between items-center text-center space-y-2">
          <div className="text-xs font-semibold text-zinc-300 w-full text-left">
            {th ? 'สัดส่วน Core REST API' : 'Core Quota Proportion'}
          </div>

          <div className="h-32 w-32 relative flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={36}
                  outerRadius={50}
                  startAngle={90}
                  endAngle={-270}
                  dataKey="value"
                  stroke="none"
                >
                  {pieChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className={`text-base font-bold font-mono ${isHighUsage ? 'text-rose-400' : 'text-amber-300'}`}>
                {corePercentUsed}%
              </span>
              <span className="text-[9px] text-zinc-500 uppercase">{th ? 'ใช้แล้ว' : 'Used'}</span>
            </div>
          </div>

          <div className="w-full text-center pt-1 border-t border-zinc-850 text-[11px] text-zinc-400">
            {core.remaining.toLocaleString()} {th ? 'ครั้งคงเหลือในรอบนี้' : 'calls remaining'}
          </div>
        </div>
      </div>
        </>
      ) : (
        <div className="p-5 bg-zinc-950/70 border border-zinc-800 rounded-xl text-center space-y-2">
          <AlertTriangle className="w-6 h-6 text-zinc-500 mx-auto" />
          <p className="text-sm font-semibold text-zinc-300">UNAVAILABLE</p>
          <p className="text-xs text-zinc-500">
            {error || (th ? 'ยังไม่มีข้อมูลโควตาจาก GitHub API' : 'GitHub API rate-limit data is not available.')}
          </p>
        </div>
      )}
    </div>
  );
};
