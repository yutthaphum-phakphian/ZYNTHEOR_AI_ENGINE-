import { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  Zap,
  Gauge,
  Activity,
  TrendingUp,
  RefreshCw,
  Maximize2,
  X,
  Clock,
  Sparkles,
  AlertTriangle,
} from 'lucide-react';

export interface ModelPerformancePoint {
  id: string;
  timestamp: number;
  timeStr: string;
  latencyMs: number;
  tokensPerSecond: number;
  tokensCount: number;
  model: string;
  provider: string;
  status: 'PASS' | 'FAIL' | 'UNAVAILABLE';
}

interface ModelPerformanceChartProps {
  /** Real historical performance points */
  history: ModelPerformancePoint[];
  /** Model status label, e.g. "Ready" or "Offline" */
  modelStatus: { label: string; tone: 'ok' | 'bad' | 'idle' | 'neutral' };
  /** Currently selected model name */
  selectedModel?: string;
  /** Active provider, e.g. 'local' */
  provider?: string;
  /** Callback to re-probe or refresh runtime */
  onRefreshProbe?: () => Promise<void> | void;
  /** If rendered in a full modal view vs inline card */
  isModal?: boolean;
  /** Modal close callback */
  onClose?: () => void;
  /** Callback to open full modal if rendered inline */
  onExpand?: () => void;
}

export function ModelPerformanceChart({
  history,
  modelStatus,
  selectedModel = 'local-weights',
  provider = 'local',
  onRefreshProbe,
  isModal = false,
  onClose,
  onExpand,
}: ModelPerformanceChartProps) {
  const [activeMetric, setActiveMetric] = useState<'both' | 'latency' | 'tps'>('both');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    if (!onRefreshProbe || isRefreshing) return;
    setIsRefreshing(true);
    try {
      await onRefreshProbe();
    } finally {
      setTimeout(() => setIsRefreshing(false), 400);
    }
  };

  // Compute summary stats from real history
  const stats = useMemo(() => {
    if (history.length === 0) {
      return {
        latestLatency: null,
        avgLatency: null,
        minLatency: null,
        maxLatency: null,
        latestTps: null,
        avgTps: null,
        peakTps: null,
        totalTokens: 0,
        sampleCount: 0,
      };
    }

    const validLatencies = history.map((p) => p.latencyMs).filter((n) => typeof n === 'number' && n > 0);
    const validTps = history.map((p) => p.tokensPerSecond).filter((n) => typeof n === 'number' && n > 0);
    const totalTokens = history.reduce((sum, p) => sum + (p.tokensCount || 0), 0);

    const latest = history[history.length - 1];

    const avgLat = validLatencies.length > 0
      ? Math.round(validLatencies.reduce((a, b) => a + b, 0) / validLatencies.length)
      : null;

    const avgTokensPerSec = validTps.length > 0
      ? parseFloat((validTps.reduce((a, b) => a + b, 0) / validTps.length).toFixed(1))
      : null;

    return {
      latestLatency: latest?.latencyMs ?? null,
      avgLatency: avgLat,
      minLatency: validLatencies.length > 0 ? Math.min(...validLatencies) : null,
      maxLatency: validLatencies.length > 0 ? Math.max(...validLatencies) : null,
      latestTps: latest?.tokensPerSecond ?? null,
      avgTps: avgTokensPerSec,
      peakTps: validTps.length > 0 ? Math.max(...validTps) : null,
      totalTokens,
      sampleCount: history.length,
    };
  }, [history]);

  // Chart data formatting with sanitized numbers
  const chartData = useMemo(() => {
    return history.map((point) => ({
      time: point.timeStr,
      latency: Math.max(0, point.latencyMs || 0),
      tps: Math.max(0, point.tokensPerSecond || 0),
      tokens: point.tokensCount || 0,
      model: point.model,
      status: point.status,
    }));
  }, [history]);

  const containerClasses = isModal
    ? 'bg-[#060D1E] border border-cyan-500/30 rounded-2xl shadow-2xl p-5 md:p-6 w-full max-w-4xl mx-auto flex flex-col space-y-4 max-h-[90vh] overflow-y-auto'
    : 'rounded-xl border border-cyan-500/25 bg-[#091534]/85 p-3.5 shadow-lg space-y-3';

  return (
    <div className={containerClasses} id="model-performance-panel">
      {/* Header */}
      <div className="flex items-center justify-between pb-1 border-b border-cyan-500/15">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-tr from-cyan-500/20 to-indigo-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <Gauge size={14} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-bold text-white tracking-wide">
                Model Performance History
              </h3>
              <span
                className={`w-2 h-2 rounded-full ${
                  modelStatus.tone === 'ok'
                    ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.6)]'
                    : modelStatus.tone === 'bad'
                    ? 'bg-rose-400'
                    : 'bg-slate-500'
                }`}
                title={`Status: ${modelStatus.label}`}
              />
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-400">
              <span className="text-cyan-300 font-mono">Inference Latency (ms)</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">{selectedModel}</span>
              <span aria-hidden="true">·</span>
              <span className="uppercase text-cyan-400 font-mono">{provider}</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-500">{stats.sampleCount} recorded runs</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {onRefreshProbe && (
            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="px-2 py-1 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-slate-800/60 border border-slate-700/60 bg-slate-900/60 text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer"
              title="ทดสอบ Probe Local Runtime ทันที"
              aria-label="Refresh probe local runtime"
            >
              <RefreshCw size={12} className={isRefreshing ? 'animate-spin text-cyan-400' : 'text-cyan-400'} />
              <span className="hidden sm:inline">Probe Local Runtime</span>
              <span className="sm:hidden">Probe</span>
            </button>
          )}

          {!isModal && onExpand && (
            <button
              onClick={onExpand}
              className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800/60 transition-colors"
              title="เปิดมุมมองกราฟขนาดใหญ่"
              aria-label="Expand chart view"
            >
              <Maximize2 size={13} />
            </button>
          )}

          {isModal && onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition-colors"
              title="ปิดหน้าต่าง"
              aria-label="Close modal"
            >
              <X size={16} />
            </button>
          )}
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
        {/* Metric 1: Current Latency */}
        <div
          className={`p-2.5 rounded-lg bg-slate-900/80 border flex flex-col justify-between transition-all ${
            stats.latestLatency != null && stats.latestLatency > 2000
              ? 'border-amber-500/60 shadow-[0_0_12px_rgba(245,158,11,0.25)] animate-pulse'
              : 'border-cyan-500/20'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
            <span className="flex items-center gap-1">
              {stats.latestLatency != null && stats.latestLatency > 2000 ? (
                <AlertTriangle size={11} className="text-amber-400 animate-bounce" />
              ) : (
                <Zap size={11} className="text-cyan-400" />
              )}
              <span className={stats.latestLatency != null && stats.latestLatency > 2000 ? 'text-amber-300 font-semibold' : ''}>
                Latency
              </span>
            </span>
            {stats.latestLatency != null && stats.latestLatency > 2000 ? (
              <span className="font-mono text-[9px] text-amber-400 font-bold flex items-center gap-0.5" title="Latency exceeds 2000ms threshold">
                &gt;2000ms Issue
              </span>
            ) : (
              <span className="font-mono text-[9px] text-slate-500">
                AVG: {stats.avgLatency ? `${stats.avgLatency}ms` : '—'}
              </span>
            )}
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span
              className={`text-lg font-bold font-mono tabular-nums ${
                stats.latestLatency != null && stats.latestLatency > 2000 ? 'text-amber-300' : 'text-cyan-300'
              }`}
            >
              {stats.latestLatency != null ? `${stats.latestLatency} ms` : '—'}
            </span>
            <span className="text-[9px] text-slate-400 font-mono">
              {stats.minLatency ? `Min ${stats.minLatency}ms` : ''}
            </span>
          </div>
        </div>

        {/* Metric 2: Tokens / Second */}
        <div className="p-2.5 rounded-lg bg-slate-900/80 border border-emerald-500/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
            <span className="flex items-center gap-1">
              <Activity size={11} className="text-emerald-400" /> Throughput
            </span>
            <span className="font-mono text-[9px] text-slate-500">
              PEAK: {stats.peakTps ? `${stats.peakTps} t/s` : '—'}
            </span>
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-lg font-bold font-mono text-emerald-300 tabular-nums">
              {stats.latestTps != null ? `${stats.latestTps} t/s` : '—'}
            </span>
            <span className="text-[9px] text-slate-400 font-mono">
              {stats.avgTps ? `Avg ${stats.avgTps}` : ''}
            </span>
          </div>
        </div>

        {/* Metric 3: Total Tokens */}
        <div className="p-2.5 rounded-lg bg-slate-900/80 border border-indigo-500/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
            <span className="flex items-center gap-1">
              <TrendingUp size={11} className="text-indigo-400" /> Tokens Generated
            </span>
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-lg font-bold font-mono text-indigo-300 tabular-nums">
              {stats.totalTokens > 0 ? stats.totalTokens.toLocaleString() : '—'}
            </span>
            <span className="text-[9px] text-slate-400 font-mono">tokens</span>
          </div>
        </div>

        {/* Metric 4: Runtime Health Status */}
        <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-700/60 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
            <span className="flex items-center gap-1">
              <Clock size={11} className="text-amber-400" /> Runtime Verification
            </span>
          </div>
          <div className="flex items-baseline justify-between mt-1">
            <span
              className={`text-sm font-bold font-mono ${
                modelStatus.tone === 'ok' ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {modelStatus.label}
            </span>
            <span className="text-[9px] text-slate-500 font-mono">Zero-Fake</span>
          </div>
        </div>
      </div>

      {/* Metric Selector Tabs */}
      <div className="flex items-center justify-between pt-1 flex-wrap gap-2">
        <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-900/90 border border-slate-800 text-[10px]" role="tablist" aria-label="Toggle between performance views">
          <button
            type="button"
            role="tab"
            aria-selected={activeMetric === 'both'}
            onClick={() => setActiveMetric('both')}
            className={`px-2.5 py-1 rounded-md transition-colors font-medium cursor-pointer ${
              activeMetric === 'both'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Combined View
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeMetric === 'latency'}
            onClick={() => setActiveMetric('latency')}
            className={`px-2.5 py-1 rounded-md transition-colors font-medium cursor-pointer ${
              activeMetric === 'latency'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Latency (ms)
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeMetric === 'tps'}
            onClick={() => setActiveMetric('tps')}
            className={`px-2.5 py-1 rounded-md transition-colors font-medium cursor-pointer ${
              activeMetric === 'tps'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Throughput (tokens per second)
          </button>
        </div>

        <div className="flex items-center gap-3 text-[10px] text-slate-400">
          {(activeMetric === 'both' || activeMetric === 'latency') && (
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-0.5 bg-cyan-400 rounded-full inline-block" />
              <span className="text-cyan-300 font-medium">Latency (ms)</span>
            </span>
          )}
          {(activeMetric === 'both' || activeMetric === 'tps') && (
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-0.5 bg-emerald-400 rounded-full inline-block" />
              <span className="text-emerald-300 font-medium">Throughput (TPS)</span>
            </span>
          )}
        </div>
      </div>

      {/* Main Recharts Visualization */}
      <div className={`w-full bg-slate-950/70 rounded-xl p-2 border border-slate-800/90 relative ${isModal ? 'h-[280px]' : 'h-[160px]'}`}>
        {chartData.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-4 text-xs text-slate-500 space-y-1">
            <Activity size={24} className="text-slate-600 mb-1 animate-pulse" />
            <span className="font-medium text-slate-400">ยังไม่มีข้อมูลการประมวลผล Inference ในเซสชันนี้</span>
            <span className="text-[10px] text-slate-600 max-w-sm">
              ส่งข้อความในแชทหรือกดปุ่มรีเฟรชเพื่อบันทึกตัวชี้วัด Latency (ms) และ Throughput (tokens/s) จากโมเดลจริง
            </span>
            {onRefreshProbe && (
              <button
                type="button"
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="mt-2 px-3 py-1.5 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-500/40 text-cyan-300 text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                aria-label="Probe local runtime"
              >
                <RefreshCw size={12} className={isRefreshing ? 'animate-spin' : ''} />
                <span>Probe Local Runtime</span>
              </button>
            )}
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            {activeMetric === 'latency' ? (
              <AreaChart data={chartData} margin={{ top: 8, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="latencyGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="latency"
                  name="Latency (ms)"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#latencyGradient)"
                  isAnimationActive={false}
                />
              </AreaChart>
            ) : activeMetric === 'tps' ? (
              <AreaChart data={chartData} margin={{ top: 8, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="tpsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="tps"
                  name="Tokens/sec"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#tpsGradient)"
                  isAnimationActive={false}
                />
              </AreaChart>
            ) : (
              <LineChart data={chartData} margin={{ top: 8, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="left" tick={{ fontSize: 9, fill: '#06b6d4' }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 9, fill: '#10b981' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="latency"
                  name="Latency (ms)"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  dot={{ r: 2, fill: '#06b6d4' }}
                  isAnimationActive={false}
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="tps"
                  name="Tokens/sec"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={{ r: 2, fill: '#10b981' }}
                  isAnimationActive={false}
                />
              </LineChart>
            )}
          </ResponsiveContainer>
        )}
      </div>

      {/* Footer Info */}
      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
        <span className="flex items-center gap-1">
          <Sparkles size={11} className="text-cyan-400" />
          <span>Real-time measurement from verified model execution</span>
        </span>
        <span className="font-mono">
          {stats.latestLatency ? `Last probe: ${stats.latestLatency}ms` : 'Waiting for inference'}
        </span>
      </div>
    </div>
  );
}

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    const lat = payload.find((p: any) => p.dataKey === 'latency')?.value;
    const tps = payload.find((p: any) => p.dataKey === 'tps')?.value;
    const tokens = payload[0]?.payload?.tokens;
    const model = payload[0]?.payload?.model;

    return (
      <div className="bg-[#050D1E] border border-cyan-500/40 rounded-lg p-2.5 shadow-xl text-[11px] space-y-1.5 min-w-[150px]">
        <div className="text-slate-400 font-mono text-[10px] border-b border-slate-800 pb-1 flex justify-between">
          <span>{label}</span>
          <span className="text-cyan-400 truncate max-w-[100px]">{model}</span>
        </div>
        {lat !== undefined && (
          <div className="flex items-center justify-between text-cyan-300">
            <span>Latency:</span>
            <span className="font-mono font-bold">{lat} ms</span>
          </div>
        )}
        {tps !== undefined && (
          <div className="flex items-center justify-between text-emerald-300">
            <span>Throughput:</span>
            <span className="font-mono font-bold">{tps} t/s</span>
          </div>
        )}
        {tokens > 0 && (
          <div className="flex items-center justify-between text-indigo-300 text-[10px]">
            <span>Generated:</span>
            <span className="font-mono">{tokens} tokens</span>
          </div>
        )}
      </div>
    );
  }
  return null;
}

export { ModelPerformanceChart as ModelPerformanceHistory };
export default ModelPerformanceChart;

