import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { subscribeNotices, type Notice } from '../utils/notify';

const STYLE: Record<Notice['kind'], string> = {
  info: 'border-cyan-400/40 text-slate-100',
  success: 'border-emerald-400/40 text-emerald-100',
  error: 'border-rose-400/50 text-rose-100',
};

export default function StatusBanner() {
  const [notice, setNotice] = useState<Notice | null>(null);

  useEffect(() => subscribeNotices(setNotice), []);

  // Errors stay until dismissed; other messages clear themselves.
  useEffect(() => {
    if (!notice || notice.kind === 'error') return;
    const t = window.setTimeout(() => setNotice(null), 6000);
    return () => window.clearTimeout(t);
  }, [notice]);

  return (
    <div
      className="pointer-events-none fixed inset-x-0 top-3 z-[100] flex justify-center px-3"
      role={notice?.kind === 'error' ? 'alert' : 'status'}
      aria-live={notice?.kind === 'error' ? 'assertive' : 'polite'}
    >
      {notice && (
        <div className={`pointer-events-auto flex max-w-lg items-start gap-3 rounded-xl border bg-[#101018]/95 px-4 py-2.5 text-xs shadow-2xl backdrop-blur ${STYLE[notice.kind]}`}>
          <span className="flex-1 leading-relaxed">{notice.message}</span>
          <button
            type="button"
            onClick={() => setNotice(null)}
            aria-label="ปิดข้อความแจ้งสถานะ"
            className="rounded p-0.5 text-slate-400 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          >
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
