import React, { useState, useEffect } from 'react';
import {
  Key,
  ShieldCheck,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Copy,
  Check,
  X,
  Lock,
  GitBranch,
} from 'lucide-react';
import type { GitHubOAuthUser } from '../types/connectors';

interface GitHubOAuthConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'en' | 'th';
  onTokenSaved: (token: string, user?: GitHubOAuthUser) => void;
}

export const GitHubOAuthConnectModal: React.FC<GitHubOAuthConnectModalProps> = ({
  isOpen,
  onClose,
  lang,
  onTokenSaved,
}) => {
  const th = lang === 'th';

  const [activeTab, setActiveTab] = useState<'oauth' | 'pat'>('oauth');
  const [patInput, setPatInput] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [oauthLoading, setOauthLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedCallback, setCopiedCallback] = useState(false);

  // Exact callback URLs from AI Studio runtime environment
  const DEV_CALLBACK_URL = 'https://ais-dev-6ytvaxkjwyfjo3z4yxdugb-1491951632.asia-southeast1.run.app/auth/github/callback';
  const SHARED_CALLBACK_URL = 'https://ais-pre-6ytvaxkjwyfjo3z4yxdugb-1491951632.asia-southeast1.run.app/auth/github/callback';

  // Listen for OAuth postMessage from popup window
  useEffect(() => {
    const handleOAuthMessage = async (event: MessageEvent) => {
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost') && !origin.includes('127.0.0.1')) {
        return;
      }

      if (event.data?.type === 'GITHUB_OAUTH_SUCCESS') {
        const receivedToken = event.data.token;
        if (receivedToken) {
          try {
            // Validate and fetch user profile
            const res = await fetch('/api/auth/github/token', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ token: receivedToken }),
            });
            const data = await res.json();
            const user = data.user as GitHubOAuthUser | undefined;

            // Replace placeholder for APPHUB_AUTH_TOKEN
            localStorage.setItem('zyntheor_auth_token', receivedToken);
            localStorage.setItem('zyntheor_github_token', receivedToken);
            onTokenSaved(receivedToken, user);

            setStatusMsg({
              type: 'success',
              text: th
                ? `เชื่อมต่อ GitHub OAuth สำเร็จ (${user?.login || 'User'}) บันทึกโทเค็นแทน APPHUB_AUTH_TOKEN แล้ว`
                : `GitHub OAuth connected successfully! Saved as user token.`,
            });
            setOauthLoading(false);
            setTimeout(() => onClose(), 1500);
          } catch {
            localStorage.setItem('zyntheor_auth_token', receivedToken);
            localStorage.setItem('zyntheor_github_token', receivedToken);
            onTokenSaved(receivedToken);
            setOauthLoading(false);
            onClose();
          }
        }
      }
    };

    window.addEventListener('message', handleOAuthMessage);
    return () => window.removeEventListener('message', handleOAuthMessage);
  }, [th, onTokenSaved, onClose]);

  // Initiate Popup-based OAuth flow
  const handleStartOAuthPopup = async () => {
    setOauthLoading(true);
    setStatusMsg(null);
    try {
      // 1. Fetch OAuth URL from server
      const res = await fetch('/api/auth/github/url');
      if (!res.ok) throw new Error('Failed to obtain GitHub auth URL');
      const data = await res.json();

      if (!data.url) throw new Error('OAuth endpoint is not configured');

      // 2. Open provider URL directly in popup
      const popup = window.open(
        data.url,
        'github_oauth_popup',
        'width=600,height=720,menubar=no,toolbar=no,status=no'
      );

      if (!popup) {
        throw new Error(
          th
            ? 'เบราว์เซอร์บล็อกหน้าต่างป็อปอัป กรุณาอนุญาตป็อปอัปสำหรับเว็บไซต์นี้'
            : 'Popup blocked. Please allow popups for this site to authenticate.'
        );
      }
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'OAuth initialization failed' });
      setOauthLoading(false);
    }
  };

  // Direct Personal Access Token validation & save
  const handleSavePat = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = patInput.trim();
    if (!token) return;

    setIsValidating(true);
    setStatusMsg(null);
    try {
      const res = await fetch('/api/auth/github/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      });
      const data = await res.json();

      if (res.ok && data.status === 'valid') {
        // Securely replace the placeholder APPHUB_AUTH_TOKEN
        localStorage.setItem('zyntheor_auth_token', token);
        localStorage.setItem('zyntheor_github_token', token);
        onTokenSaved(token, data.user);

        setStatusMsg({
          type: 'success',
          text: th
            ? `ยืนยันสำเร็จ! เชื่อมต่อบัญชี @${data.user?.login} และบันทึกแทน APPHUB_AUTH_TOKEN แล้ว`
            : `Token verified! Connected @${data.user?.login} and saved to workspace.`,
        });
        setTimeout(() => onClose(), 1200);
      } else {
        throw new Error(data.message || 'Invalid GitHub token');
      }
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Token verification failed' });
    } finally {
      setIsValidating(false);
    }
  };

  const copyCallbackUrl = () => {
    navigator.clipboard.writeText(DEV_CALLBACK_URL);
    setCopiedCallback(true);
    setTimeout(() => setCopiedCallback(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-zinc-900 border border-zinc-750 rounded-2xl p-6 shadow-2xl space-y-5 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-zinc-100">
                {th ? 'เชื่อมต่อสิทธิ์ GitHub & กำหนดโทเค็นผู้ใช้' : 'GitHub OAuth & User Token Setup'}
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                {th
                  ? 'แทนที่ placeholder สำหรับ APPHUB_AUTH_TOKEN ด้วยโทเค็นยืนยันตัวตนจริง'
                  : 'Securely obtain user-specific token to replace APPHUB_AUTH_TOKEN'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex rounded-xl bg-zinc-950 p-1 border border-zinc-800">
          <button
            type="button"
            onClick={() => setActiveTab('oauth')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'oauth'
                ? 'bg-amber-600 text-white shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {th ? 'GitHub OAuth (เปิดหน้าต่าง)' : 'GitHub OAuth Popup'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('pat')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'pat'
                ? 'bg-amber-600 text-white shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {th ? 'Personal Access Token (PAT)' : 'Personal Access Token (PAT)'}
          </button>
        </div>

        {statusMsg && (
          <div
            className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
              statusMsg.type === 'success'
                ? 'bg-emerald-950/80 border border-emerald-800 text-emerald-300'
                : 'bg-rose-950/80 border border-rose-800 text-rose-300'
            }`}
          >
            {statusMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{statusMsg.text}</span>
          </div>
        )}

        {/* Tab 1: OAuth Popup */}
        {activeTab === 'oauth' && (
          <div className="space-y-4 text-xs">
            <p className="text-zinc-300 leading-relaxed">
              {th
                ? 'คลิกปุ่มด้านล่างเพื่อเปิดหน้าต่างเข้าสู่ระบบ GitHub และอนุญาตสิทธิ์การเข้าถึงแบบ Read-Only โทเค็นที่ได้รับจะถูกบันทึกลง Session ของคุณโดยอัตโนมัติ'
                : 'Click below to initiate the popup authorization flow directly on GitHub. The returned token replaces APPHUB_AUTH_TOKEN.'}
            </p>

            <button
              type="button"
              onClick={handleStartOAuthPopup}
              disabled={oauthLoading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold text-xs shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
            >
              {oauthLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{th ? 'กำลังเชื่อมต่อ OAuth...' : 'Waiting for GitHub Popup...'}</span>
                </>
              ) : (
                <>
                  <ExternalLink className="w-4 h-4" />
                  <span>{th ? 'เข้าสู่ระบบด้วย GitHub (Connect OAuth)' : 'Connect with GitHub OAuth'}</span>
                </>
              )}
            </button>

            {/* Provider Configuration Guide */}
            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2 text-[11px]">
              <span className="font-semibold text-zinc-300 block">
                {th ? '📋 การตั้งค่า GitHub OAuth App (ถ้ามี):' : '📋 GitHub OAuth App Setup Instructions:'}
              </span>
              <p className="text-zinc-400">
                {th ? 'เพิ่ม Authorization callback URL ในหน้า Developer Settings ของ GitHub:' : 'Add this callback URL in your GitHub Developer Settings:'}
              </p>
              <div className="flex items-center gap-2 p-2 bg-zinc-900 border border-zinc-750 rounded-lg font-mono text-[10px] text-amber-300 break-all select-all">
                <span className="truncate flex-1">{DEV_CALLBACK_URL}</span>
                <button
                  type="button"
                  onClick={copyCallbackUrl}
                  className="p-1 hover:text-white text-zinc-400 shrink-0"
                  title="Copy Callback URL"
                >
                  {copiedCallback ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Direct PAT Input */}
        {activeTab === 'pat' && (
          <form onSubmit={handleSavePat} className="space-y-4 text-xs">
            <p className="text-zinc-300 leading-relaxed">
              {th
                ? 'ป้อน GitHub Personal Access Token (classic หรือ fine-grained) เพื่อเพิ่มโควตาเป็น 5,000 requests/hr และเข้าถึงคลังโค้ดส่วนตัวของคุณ'
                : 'Enter your GitHub Personal Access Token (classic or fine-grained) to increase rate limits to 5,000/hr.'}
            </p>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-zinc-300">
                GitHub Personal Access Token (PAT)
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={patInput}
                  onChange={(e) => setPatInput(e.target.value)}
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxx or github_pat_..."
                  className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-mono text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500"
                />
              </div>
              <span className="text-[10px] text-zinc-500 block">
                {th
                  ? 'ต้องการสิทธิ์เพียง `repo` (หรือ public_repo) และ `read:user` สำหรับโหมดอ่านอย่างเดียว'
                  : 'Only requires read permissions (repo / public_repo and read:user)'}
              </span>
            </div>

            <div className="flex items-center justify-between pt-2">
              <a
                href="https://github.com/settings/tokens/new?scopes=repo,read:user,read:org&description=Zyntheor%20AI%20Engine"
                target="_blank"
                rel="noreferrer"
                className="text-amber-400 hover:text-amber-300 text-[11px] flex items-center gap-1 underline"
              >
                <ExternalLink className="w-3 h-3" />
                <span>{th ? 'สร้าง Token บน GitHub' : 'Generate Token on GitHub'}</span>
              </a>

              <button
                type="submit"
                disabled={isValidating || !patInput.trim()}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold text-xs shadow-md transition-all cursor-pointer"
              >
                {isValidating ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{th ? 'กำลังตรวจสอบ...' : 'Verifying...'}</span>
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{th ? 'ตรวจสอบและบันทึก' : 'Verify & Save Token'}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
