import { useState, useEffect } from 'react';
import { Download, CheckCircle2, ShieldCheck, AlertCircle, RefreshCw, HardDrive, Check, Key } from 'lucide-react';

export interface GgufModelItem {
  id: string;
  name: string;
  filename: string;
  parameters: string;
  quantization: string;
  sizeBytes: number;
  sizeFormatted: string;
  expectedSha256: string;
  description: string;
  compatibility: string;
  status: 'AVAILABLE' | 'DOWNLOADING' | 'VERIFYING' | 'INSTALLED' | 'VERIFIED' | 'HASH_MISMATCH' | 'ERROR';
  installedPath?: string;
  verifiedAt?: string;
  computedSha256?: string;
  downloadProgress?: number;
}

interface GgufModelInstallerProps {
  currentModel: string;
  onSelectModel: (modelName: string) => void;
}

export function GgufModelInstaller({ currentModel, onSelectModel }: GgufModelInstallerProps) {
  const [models, setModels] = useState<GgufModelItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [installingId, setInstallingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{
    modelId: string;
    success: boolean;
    message: string;
    computedHash?: string;
    expectedHash?: string;
    match?: boolean;
  } | null>(null);

  const fetchModels = async () => {
    try {
      const res = await fetch('/api/models/gguf');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.models)) {
          setModels(data.models);
        }
      }
    } catch {
      // Fallback state if server unavailable
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchModels();
  }, []);

  const handleInstall = async (modelId: string) => {
    setInstallingId(modelId);
    setFeedback(null);

    setModels((prev) =>
      prev.map((m) =>
        m.id === modelId ? { ...m, status: 'DOWNLOADING', downloadProgress: undefined } : m
      )
    );

    try {
      const res = await fetch('/api/models/gguf/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ modelId }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setModels((prev) =>
          prev.map((m) =>
            m.id === modelId
              ? {
                  ...m,
                  status: 'VERIFIED',
                  computedSha256: data.computedSha256,
                  verifiedAt: data.model?.verifiedAt || new Date().toISOString(),
                }
              : m
          )
        );

        setFeedback({
          modelId,
          success: true,
          message: `ติดตั้งและตรวจสอบ SHA-256 สำเร็จแล้ว: ${data.model?.filename}`,
          computedHash: data.computedSha256,
          expectedHash: data.expectedSha256,
          match: data.hashMatch,
        });
      } else {
        setModels((prev) =>
          prev.map((m) =>
            m.id === modelId ? { ...m, status: 'ERROR', downloadProgress: 0 } : m
          )
        );
        setFeedback({
          modelId,
          success: false,
          message: data.error || data.verificationMessage || 'การติดตั้งหรือตรวจสอบ Hash ล้มเหลว',
          computedHash: data.computedSha256,
          expectedHash: data.expectedSha256,
          match: data.hashMatch,
        });
      }
    } catch (err: any) {
      setModels((prev) =>
        prev.map((m) =>
          m.id === modelId ? { ...m, status: 'ERROR', downloadProgress: 0 } : m
        )
      );
      setFeedback({
        modelId,
        success: false,
        message: err.message || 'การเชื่อมต่อไปยังระบบติดตั้งโมเดลล้มเหลว',
      });
    } finally {
      setInstallingId(null);
    }
  };

  if (loading) {
    return (
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-center gap-2 text-slate-400 text-xs">
        <RefreshCw size={14} className="animate-spin text-cyan-400" />
        <span>กำลังโหลดรายการโมเดล GGUF ที่รองรับ...</span>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-semibold text-white text-xs flex items-center gap-1.5">
            <HardDrive size={13} className="text-cyan-400" />
            <span>คลังโมเดล GGUF ท้องถิ่น (Sovereign GGUF Weights)</span>
          </h4>
          <p className="text-[10px] text-slate-400 mt-0.5">
            ดาวน์โหลดและติดตั้งโมเดล GGUF สำหรับรันบนเครื่อง พร้อมการตรวจสอบความถูกต้องด้วย SHA-256 Hash
          </p>
        </div>
        <button
          type="button"
          onClick={fetchModels}
          className="p-1 text-slate-400 hover:text-cyan-300 transition-colors"
          title="รีเฟรชรายการ"
        >
          <RefreshCw size={13} />
        </button>
      </div>

      {/* Global verification feedback banner */}
      {feedback && (
        <div
          className={`p-2.5 rounded-lg text-xs border space-y-1.5 ${
            feedback.success
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/40 border-rose-500/40 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-1.5 font-medium">
            {feedback.success ? (
              <CheckCircle2 size={14} className="text-emerald-400" />
            ) : (
              <AlertCircle size={14} className="text-rose-400" />
            )}
            <span>{feedback.message}</span>
          </div>
          {feedback.computedHash && (
            <div className="text-[10px] font-mono bg-black/40 p-1.5 rounded space-y-0.5 border border-emerald-500/20">
              <div className="flex items-center justify-between text-slate-400">
                <span>Calculated SHA-256:</span>
                        <span className={feedback.match === false ? 'text-rose-300' : 'text-emerald-300'}>
                          {feedback.match === false ? '✕ HASH MISMATCH — REJECTED' : '✓ MATCHES INTEGRITY CONTRACT'}
                        </span>
              </div>
              <div className="truncate text-slate-200">{feedback.computedHash}</div>
            </div>
          )}
        </div>
      )}

      {/* Models List */}
      <div className="space-y-2.5">
        {models.map((m) => {
          const isCurrentlyActive =
            currentModel.toLowerCase().includes(m.id.toLowerCase()) ||
            currentModel.toLowerCase().includes(m.name.toLowerCase().split(' ')[0]);
          const isInstalling = installingId === m.id;
          const isVerified = m.status === 'VERIFIED';

          return (
            <div
              key={m.id}
              className={`p-3 rounded-xl border transition-all ${
                isCurrentlyActive
                  ? 'bg-cyan-950/20 border-cyan-500/50 shadow-sm'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs">{m.name}</span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                      {m.quantization}
                    </span>
                    {isCurrentlyActive && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                        ACTIVE MODEL
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1 leading-snug">{m.description}</p>

                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2 text-[10px] text-slate-400 font-mono">
                    <span>ไฟล์: <strong className="text-slate-300">{m.filename}</strong></span>
                    <span>ขนาด: <strong className="text-cyan-300">{m.sizeFormatted}</strong></span>
                    <span>พารามิเตอร์: <strong className="text-slate-300">{m.parameters}</strong></span>
                  </div>

                  {/* SHA-256 Hash Display */}
                  <div className="mt-2 text-[9px] font-mono bg-black/40 p-1.5 rounded border border-slate-800/80 flex items-center justify-between text-slate-400">
                    <div className="flex items-center gap-1 truncate">
                      <Key size={11} className="text-amber-400 shrink-0" />
                      <span className="text-slate-500">SHA-256:</span>
                      <span className="text-slate-300 truncate">{m.expectedSha256}</span>
                    </div>
                    {isVerified && (
                      <span className="text-emerald-400 shrink-0 flex items-center gap-0.5 font-bold">
                        <ShieldCheck size={12} /> VERIFIED
                      </span>
                    )}
                  </div>
                </div>

                {/* Action button */}
                <div className="shrink-0 flex flex-col items-end gap-1.5 pt-1">
                  {isVerified ? (
                    <button
                      type="button"
                      onClick={() => onSelectModel(m.name)}
                      disabled={isCurrentlyActive}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ${
                        isCurrentlyActive
                          ? 'bg-slate-800 text-slate-400 cursor-default'
                          : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-sm'
                      }`}
                    >
                      {isCurrentlyActive ? <Check size={13} /> : <CheckCircle2 size={13} />}
                      <span>{isCurrentlyActive ? 'โมเดลปัจจุบัน' : 'เลือกใช้งาน'}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleInstall(m.id)}
                      disabled={isInstalling}
                      className="px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow transition-all"
                    >
                      {isInstalling ? (
                        <>
                          <RefreshCw size={13} className="animate-spin" />
                          <span>กำลังตรวจสอบ...</span>
                        </>
                      ) : (
                        <>
                          <Download size={13} />
                          <span>ดาวน์โหลด & ตรวจสอบ</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>

              {isInstalling && (
                <div className="mt-2.5 pt-2 border-t border-slate-800">
                  <div className="text-[10px] text-slate-400 font-mono mb-1">กำลังรอผลติดตั้งและตรวจ SHA-256 จากเซิร์ฟเวอร์...</div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full w-1/3 bg-cyan-500 rounded-full animate-pulse"
                    ></div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
