import React, { useMemo, useState, useEffect } from 'react';
import {
  X,
  MessageSquare,
  Clock,
  Zap,
  FileText,
  Copy,
  Check,
  Download,
  ArrowRight,
  TrendingUp,
  Search,
  Filter,
  BarChart2,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { calculateConversationStats, type WordCloudItem, type ConversationStats } from '../utils/conversationStats';

export interface ConversationOverviewSession {
  id: string;
  title: string;
  updatedAt: string;
  messages: Array<{
    id: string;
    role: 'user' | 'assistant';
    content: string;
    createdAt?: string;
    timestamp?: number;
    latencyMs?: number;
    status?: string;
    [key: string]: any;
  }>;
  archived?: boolean;
  tags?: string[];
  customTitle?: boolean;
}

interface ConversationOverviewPanelProps {
  session: ConversationOverviewSession | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectSessionAndChat?: (session: ConversationOverviewSession) => void;
  onFilterByKeyword?: (keyword: string) => void;
}

export const ConversationOverviewPanel: React.FC<ConversationOverviewPanelProps> = ({
  session,
  isOpen,
  onClose,
  onSelectSessionAndChat,
  onFilterByKeyword,
}) => {
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'all' | 'tech' | 'concept' | 'action'>('all');

  // Handle ESC key to dismiss panel
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const stats: ConversationStats = useMemo(() => {
    if (!session || !session.messages) {
      return calculateConversationStats([]);
    }
    return calculateConversationStats(session.messages);
  }, [session]);

  const filteredWordCloud = useMemo(() => {
    if (activeCategoryFilter === 'all') return stats.wordCloud;
    return stats.wordCloud.filter((item) => item.category === activeCategoryFilter);
  }, [stats.wordCloud, activeCategoryFilter]);

  // Snippets matching the selected word cloud topic
  const matchingMessages = useMemo(() => {
    if (!selectedTopic || !session?.messages) return [];
    const lower = selectedTopic.toLowerCase();
    return session.messages.filter((m) => m.content.toLowerCase().includes(lower));
  }, [selectedTopic, session?.messages]);

  if (!isOpen || !session) return null;

  const handleCopySummary = async () => {
    const summaryText = `[Conversation Overview: ${session.title}]
• Total Messages: ${stats.totalMessages} (${stats.userMessagesCount} User / ${stats.assistantMessagesCount} Assistant)
• Avg Latency: ${stats.avgResponseLatencyMs}ms (Min: ${stats.minLatencyMs}ms / Max: ${stats.maxLatencyMs}ms)
• Word Count: ${stats.totalWords.toLocaleString()} words (~${stats.totalTokens.toLocaleString()} tokens)
• Estimated Reading Time: ~${stats.estimatedReadingMinutes} min
• Top Discussion Topics: ${stats.topTopics.map((t) => `${t.name} (${t.count})`).join(', ') || 'N/A'}`;

    try {
      await navigator.clipboard.writeText(summaryText);
      setCopiedSummary(true);
      setTimeout(() => setCopiedSummary(false), 2200);
    } catch (err) {
      console.warn('Failed to copy conversation summary:', err);
    }
  };

  const handleExportMarkdown = () => {
    const lines: string[] = [
      `# Conversation: ${session.title}`,
      ``,
      `> **Session ID:** \`${session.id}\`  `,
      `> **Date / Time:** ${session.updatedAt}  `,
      `> **Total Messages:** ${stats.totalMessages} (${stats.userMessagesCount} User, ${stats.assistantMessagesCount} Assistant)  `,
      `> **Avg Latency:** ${stats.avgResponseLatencyMs}ms  `,
      `> **Words:** ${stats.totalWords.toLocaleString()}  `,
      ``,
      `---`,
      ``,
    ];

    for (const msg of session.messages) {
      const roleName = msg.role === 'assistant' ? '🤖 Zyntheor AI' : '👤 User';
      const timeStr = msg.createdAt ? ` (${msg.createdAt})` : '';
      lines.push(`### ${roleName}${timeStr}`);
      lines.push(``);
      lines.push(msg.content);
      lines.push(``);
      lines.push(`---`);
      lines.push(``);
    }

    const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `conversation-${session.id}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getWeightStyle = (weight: number, category: WordCloudItem['category']) => {
    // Sized mathematically from 12px to 22px
    switch (weight) {
      case 5:
        return 'text-lg md:text-xl font-bold text-cyan-300 drop-shadow-[0_0_12px_rgba(6,182,212,0.35)]';
      case 4:
        return 'text-base md:text-lg font-semibold text-indigo-300';
      case 3:
        return 'text-sm md:text-base font-medium text-emerald-300';
      case 2:
        return 'text-xs md:text-sm font-medium text-slate-200';
      case 1:
      default:
        return 'text-xs font-normal text-slate-400';
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="conversation-overview-title"
    >
      <div
        className="w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl bg-[#0c101a] border border-cyan-500/25 shadow-2xl shadow-cyan-950/40 text-slate-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <header className="flex items-center justify-between gap-4 px-6 py-4 border-b border-slate-800/80 bg-[#0e1424]">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-inner shrink-0">
              <BarChart2 size={18} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 id="conversation-overview-title" className="text-sm sm:text-base font-bold text-white tracking-tight truncate">
                  {session.title || 'การสนทนา'}
                </h2>
                {session.archived && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    Archived
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-sans">
                <span>ภาพรวมและสถิติการสนทนา</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums text-slate-400">{session.updatedAt}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums text-cyan-400 font-semibold">{stats.totalMessages} ข้อความ</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleCopySummary}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700/80 bg-slate-850 hover:bg-slate-800 text-xs font-medium text-slate-200 transition-colors"
              title="คัดลอกบทสรุปสถิติ"
            >
              {copiedSummary ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              <span>{copiedSummary ? 'คัดลอกแล้ว' : 'คัดลอกสรุป'}</span>
            </button>
            <button
              type="button"
              onClick={handleExportMarkdown}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700/80 bg-slate-850 hover:bg-slate-800 text-xs font-medium text-slate-200 transition-colors"
              title="ดาวน์โหลดประวัติเป็น Markdown (.md)"
            >
              <Download size={13} />
              <span>ส่งออก .md</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors focus-visible:ring-2 focus-visible:ring-cyan-400"
              aria-label="ปิดภาพรวมการสนทนา"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Key Metrics Strip (4 High-Density KPI Cards) */}
          <section aria-label="Key Conversation Metrics">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {/* 1. Total Messages */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700/80 transition-all">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>ข้อความทั้งหมด</span>
                  <MessageSquare size={14} className="text-cyan-400" />
                </div>
                <div className="text-2xl font-bold font-mono tabular-nums text-white">
                  {stats.totalMessages}
                </div>
                <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between font-mono tabular-nums">
                  <span>ผู้ใช้: {stats.userMessagesCount}</span>
                  <span aria-hidden="true">·</span>
                  <span>AI: {stats.assistantMessagesCount}</span>
                </div>
                {/* Visual Ratio Bar */}
                <div className="w-full h-1.5 rounded-full bg-slate-800 mt-2 overflow-hidden flex">
                  <div
                    className="h-full bg-indigo-500"
                    style={{ width: `${(stats.userMessagesCount / (stats.totalMessages || 1)) * 100}%` }}
                    title={`ข้อความจากผู้ใช้: ${stats.userMessagesCount}`}
                  />
                  <div
                    className="h-full bg-cyan-400"
                    style={{ width: `${(stats.assistantMessagesCount / (stats.totalMessages || 1)) * 100}%` }}
                    title={`ข้อความจาก AI ผู้ช่วย: ${stats.assistantMessagesCount}`}
                  />
                </div>
              </div>

              {/* 2. Response Latency */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700/80 transition-all">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>ความหน่วงเฉลี่ย (Latency)</span>
                  <Zap size={14} className="text-amber-400" />
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-bold font-mono tabular-nums text-white">
                    {stats.avgResponseLatencyMs}
                  </span>
                  <span className="text-xs font-mono text-slate-400">ms</span>
                </div>
                <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between font-mono tabular-nums">
                  <span>ต่ำสุด: {stats.minLatencyMs}ms</span>
                  <span aria-hidden="true">·</span>
                  <span>สูงสุด: {stats.maxLatencyMs}ms</span>
                </div>
                <div className="mt-2 flex items-center gap-1.5 text-[10px]">
                  <span
                    className={`font-mono font-semibold ${
                      stats.avgResponseLatencyMs < 600
                        ? 'text-emerald-400'
                        : stats.avgResponseLatencyMs < 1500
                        ? 'text-cyan-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {stats.avgResponseLatencyMs < 600 ? '⚡ รวดเร็วมาก (Optimal)' : stats.avgResponseLatencyMs < 1500 ? '✓ ปกติ (Nominal)' : '⚠️ ปานกลาง'}
                  </span>
                </div>
              </div>

              {/* 3. Word & Token Count */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700/80 transition-all">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>ปริมาณคำและโทเค็น</span>
                  <FileText size={14} className="text-emerald-400" />
                </div>
                <div className="text-2xl font-bold font-mono tabular-nums text-white">
                  {stats.totalWords.toLocaleString()}
                </div>
                <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between font-mono tabular-nums">
                  <span>คำ (Words)</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-cyan-400">~{stats.totalTokens.toLocaleString()} tokens</span>
                </div>
                <div className="mt-2 text-[10px] text-slate-500 font-mono">
                  เฉลี่ย ~{Math.round(stats.totalWords / (stats.totalMessages || 1))} คำ/ข้อความ
                </div>
              </div>

              {/* 4. Reading Time & Duration */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700/80 transition-all">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>เวลาในการอ่าน</span>
                  <Clock size={14} className="text-indigo-400" />
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-bold font-mono tabular-nums text-white">
                    ~{stats.estimatedReadingMinutes}
                  </span>
                  <span className="text-xs font-sans text-slate-400">นาที</span>
                </div>
                <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>อัตราเร็ว: 200 wpm</span>
                </div>
                <div className="mt-2 text-[10px] text-slate-500 truncate font-mono">
                  {stats.firstMessageTime ? `เริ่ม: ${stats.firstMessageTime}` : 'ไม่มีประวัติเวลา'}
                </div>
              </div>
            </div>
          </section>

          {/* Interactive Word Cloud Section */}
          <section className="p-5 rounded-2xl bg-gradient-to-b from-[#0e1628] to-[#0c111e] border border-cyan-500/20 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <Sparkles size={16} className="text-cyan-400" />
                  <h3 className="text-sm font-bold text-white tracking-wide">
                    Word Cloud: หัวข้อและคีย์เวิร์ดเด่นที่สนทนา
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  คำและเทคโนโลยีที่กล่าวถึงบ่อยในเซสชันนี้ ขนาดตัวอักษรระบุความถี่ คลิกที่คำเพื่อดูบริบทในแชท
                </p>
              </div>

              {/* Category Filter Tabs */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] shrink-0">
                <button
                  type="button"
                  onClick={() => setActiveCategoryFilter('all')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                    activeCategoryFilter === 'all'
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  ทั้งหมด ({stats.wordCloud.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCategoryFilter('tech')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                    activeCategoryFilter === 'tech'
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Tech
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCategoryFilter('concept')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                    activeCategoryFilter === 'concept'
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Concept
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCategoryFilter('action')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                    activeCategoryFilter === 'action'
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Action
                </button>
              </div>
            </div>

            {/* Visual Word Cloud Container */}
            <div className="min-h-48 p-6 rounded-xl bg-slate-950/60 border border-slate-800/80 flex flex-wrap items-center justify-center gap-x-4 gap-y-3 select-none">
              {filteredWordCloud.length === 0 ? (
                <div className="text-xs text-slate-500 py-8 text-center">
                  ยังไม่มีคีย์เวิร์ดเด่นในหมวดหมู่นี้
                </div>
              ) : (
                filteredWordCloud.map((item) => {
                  const isSelected = selectedTopic === item.text;
                  const weightClass = getWeightStyle(item.weight, item.category);

                  return (
                    <button
                      key={item.text}
                      type="button"
                      onClick={() => {
                        setSelectedTopic(isSelected ? null : item.text);
                      }}
                      className={`group inline-flex items-baseline gap-1 px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-500/25 border border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)] ring-1 ring-cyan-400'
                          : 'hover:bg-slate-800/60 hover:scale-105 border border-transparent'
                      }`}
                      title={`${item.text} — พบ ${item.count} ครั้ง (คลิกเพื่อดูข้อความที่เกี่ยวข้อง)`}
                    >
                      <span className={`${weightClass} transition-colors group-hover:text-cyan-200`}>
                        {item.text}
                      </span>
                      <span className="text-[10px] font-mono tabular-nums text-slate-500 opacity-60 group-hover:opacity-100">
                        {item.count}
                      </span>
                    </button>
                  );
                })
              )}
            </div>

            {/* Top Themes Summary Strip */}
            <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-slate-400 font-medium">ประเด็นหลัก 5 อันดับแรก:</span>
              {stats.topTopics.slice(0, 5).map((topic, i) => (
                <button
                  key={topic.name}
                  type="button"
                  onClick={() => setSelectedTopic(topic.name)}
                  className="px-2.5 py-0.5 rounded-md bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-slate-300 hover:text-white font-sans text-xs flex items-center gap-1.5 transition-colors"
                >
                  <span className="font-mono text-cyan-400 font-bold">{i + 1}.</span>
                  <span>{topic.name}</span>
                  <span className="text-[10px] font-mono tabular-nums text-slate-500">({topic.count})</span>
                </button>
              ))}
            </div>

            {/* Keyword Context Drilldown (when a word in the cloud is clicked) */}
            {selectedTopic && (
              <div className="mt-4 p-4 rounded-xl bg-slate-900/90 border border-cyan-500/40 space-y-2.5 animate-in fade-in duration-150">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2 text-xs">
                    <Search size={13} className="text-cyan-400" />
                    <span className="text-slate-300">
                      บริบทที่พบคำว่า <strong className="text-cyan-300 font-bold">"{selectedTopic}"</strong> ({matchingMessages.length} ข้อความ)
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {onFilterByKeyword && (
                      <button
                        type="button"
                        onClick={() => {
                          onFilterByKeyword(selectedTopic);
                          onClose();
                        }}
                        className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 underline"
                      >
                        ค้นหาในหน้าแชทหลัก
                        <ArrowRight size={12} />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setSelectedTopic(null)}
                      className="text-xs text-slate-400 hover:text-white"
                      title="ปิดการดูบริบทคำนี้"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>

                <div className="max-h-44 overflow-y-auto space-y-2 pr-1">
                  {matchingMessages.slice(0, 4).map((msg, idx) => (
                    <div
                      key={msg.id || idx}
                      className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                        <span className={msg.role === 'assistant' ? 'text-cyan-400' : 'text-indigo-400'}>
                          {msg.role === 'assistant' ? 'AI Assistant' : 'User'}
                        </span>
                        <span>{msg.createdAt || ''}</span>
                      </div>
                      <p className="text-slate-300 text-xs line-clamp-2 leading-relaxed">
                        {msg.content}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>

          {/* Turn-by-Turn Latency Mini Timeline */}
          {stats.turnLatencies.length > 0 && (
            <section className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp size={16} className="text-indigo-400" />
                  <h3 className="text-sm font-bold text-white">ลำดับรอบการตอบกลับ (Turn Latency History)</h3>
                </div>
                <div className="text-xs font-mono text-slate-400 tabular-nums">
                  {stats.turnLatencies.length} คำตอบ
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-48 overflow-y-auto pr-1">
                {stats.turnLatencies.slice(-9).map((turn) => (
                  <div
                    key={turn.turnIndex}
                    className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="text-slate-400">รอบที่ #{turn.turnIndex}</span>
                      <span
                        className={`tabular-nums font-semibold ${
                          turn.latencyMs < 600 ? 'text-emerald-400' : turn.latencyMs < 1500 ? 'text-cyan-400' : 'text-amber-400'
                        }`}
                      >
                        {turn.latencyMs} ms
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 truncate" title={turn.assistantSnippet}>
                      {turn.assistantSnippet}
                    </p>
                    <div className="flex items-center justify-between text-[9px] text-slate-500 font-mono">
                      <span>~{turn.tokensCount} tokens</span>
                      <span>{turn.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Bottom Footer Actions */}
        <footer className="flex flex-col sm:flex-row items-center justify-between gap-3 px-6 py-4 border-t border-slate-800/80 bg-[#0e1424]">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>พร้อมใช้งาน · เซสชัน ID: <code className="font-mono text-slate-300">{session.id}</code></span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-700 bg-slate-850 hover:bg-slate-800 text-xs font-medium text-slate-300 transition-colors"
            >
              ปิด (Esc)
            </button>
            {onSelectSessionAndChat && (
              <button
                type="button"
                onClick={() => {
                  onSelectSessionAndChat(session);
                  onClose();
                }}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-lg shadow-cyan-950/50 transition-all cursor-pointer"
              >
                <span>เปิดสนทนาต่อ</span>
                <ArrowRight size={14} />
              </button>
            )}
          </div>
        </footer>
      </div>
    </div>
  );
};
