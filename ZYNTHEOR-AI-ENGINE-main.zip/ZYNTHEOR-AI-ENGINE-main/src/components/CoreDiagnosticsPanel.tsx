import React, { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { fetchCoreDiagnostics, fetchPreflight, type CoreDiagnosticsReport, type PreflightReportResult } from '../services/api';

const TONE: Record<string, string> = {
  PASS: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/40',
  FAIL: 'text-red-400 border-red-500/40 bg-red-950/40',
  UNKNOWN: 'text-amber-300 border-amber-500/40 bg-amber-950/30',
  NOT_TESTED: 'text-slate-400 border-slate-600/60 bg-slate-900/60',
};

/** Shows the real evidence for each hop: Frontend -> Core API -> Local Runtime -> Model -> Inference. */
export const CoreDiagnosticsPanel: React.FC<{ selectedModel?: string }> = ({ selectedModel }) => {
  const [report, setReport] = useState<CoreDiagnosticsReport | null>(null);
  const [coreError, setCoreError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [preflight, setPreflight] = useState<PreflightReportResult | null>(null);

  const runPreflight = async (infer: boolean) => {
    setBusy(true);
    setCoreError(null);
    try {
      setPreflight(await fetchPreflight({ infer, model: infer ? selectedModel : undefined }));
    } catch (err: any) {
      setPreflight(null);
      setCoreError(`Preflight: เรียก Core API ไม่ได้ — ${err?.message || 'request failed'}`);
    } finally {
      setBusy(false);
    }
  };

  const run = async (infer: boolean) => {
    setBusy(true);
    setCoreError(null);
    try {
      setReport(await fetchCoreDiagnostics({ infer, model: infer ? selectedModel : undefined }));
    } catch (err: any) {
      setReport(null);
      setCoreError(`Frontend → Core API: FAIL — ${err?.message || 'request failed'}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="p-4 rounded-lg bg-[#070a12] border border-slate-800 space-y-3" data-testid="core-diagnostics-panel">
      <div className="flex items-center justify-between gap-2">
        <span className="font-semibold text-slate-200">ตรวจสอบการเชื่อมต่อ Core (Core Connection Diagnostics)</span>
        <div className="flex gap-2">
          <button type="button" disabled={busy} onClick={() => run(false)}
            className="px-3 py-1 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-[11px] flex items-center gap-1.5 disabled:opacity-50">
            {busy && <RefreshCw className="w-3 h-3 animate-spin" />}<span>ตรวจสอบ</span>
          </button>
          <button type="button" disabled={busy} onClick={() => runPreflight(false)} data-testid="preflight-button"
            title="ตรวจความพร้อมของเส้นทางส่งข้อความ (ไม่รันโมเดล ไม่สลับโมเดลให้เอง)"
            className="px-3 py-1 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-[11px] disabled:opacity-50">
            Preflight
          </button>
          <button type="button" disabled={busy || !selectedModel} onClick={() => run(true)}
            title={selectedModel ? `ทดสอบ inference จริงด้วย ${selectedModel}` : 'เลือกโมเดลก่อนจึงทดสอบ inference ได้'}
            className="px-3 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-[11px] disabled:opacity-40">
            ทดสอบ inference จริง
          </button>
        </div>
      </div>
      {coreError && <div className="text-[11px] text-red-400 font-mono">{coreError}</div>}
      {!report && !coreError && <div className="text-[11px] text-slate-500">UNKNOWN: ยังไม่ได้ตรวจสอบ</div>}
      {report && (
        <div className="space-y-1.5">
          {report.stages.map((stage) => (
            <div key={stage.id} className="flex items-start gap-2 text-[11px]">
              <span className={`shrink-0 px-1.5 py-0.5 rounded border font-mono text-[10px] ${TONE[stage.status]}`}>{stage.status}</span>
              <div className="min-w-0">
                <div className="text-slate-200">{stage.label}{stage.code ? <span className="text-slate-500 font-mono"> · {stage.code}</span> : null}</div>
                <div className="text-slate-400 break-words">{stage.evidence}</div>
              </div>
            </div>
          ))}
          <div className="text-[10px] text-slate-500 font-mono pt-1">
            overall: {report.overall}{report.firstFailure ? ` · ขาดที่: ${report.firstFailure}` : ''} · {report.generatedAt}
          </div>
        </div>
      )}
      {preflight && (
        <div className="space-y-1.5 pt-2 border-t border-slate-800" data-testid="preflight-report">
          <div className="text-[11px] text-slate-200 font-semibold">
            Preflight: <span className={preflight.overall === 'READY' ? 'text-emerald-400' : preflight.overall === 'PARTIAL' ? 'text-amber-300' : 'text-red-400'}>{preflight.overall}</span>
            {preflight.firstFailure ? <span className="text-slate-500 font-mono"> · ขาดที่: {preflight.firstFailure}</span> : null}
          </div>
          {preflight.checks.map((c) => (
            <div key={c.id} className="flex items-start gap-2 text-[11px]">
              <span className={`shrink-0 px-1.5 py-0.5 rounded border font-mono text-[10px] ${TONE[c.status]}`}>{c.status}</span>
              <div className="min-w-0">
                <div className="text-slate-200">{c.label}<span className="text-slate-500 font-mono"> · {c.basis}{c.blocking ? '' : ' · non-blocking'}{c.code ? ` · ${c.code}` : ''}</span></div>
                <div className="text-slate-400 break-words">{c.evidence}</div>
              </div>
            </div>
          ))}
          {preflight.notTested.length > 0 && (
            <div className="text-[10px] text-slate-500">ยังไม่ได้ทดสอบ: {preflight.notTested.join(', ')}</div>
          )}
        </div>
      )}
    </div>
  );
};
