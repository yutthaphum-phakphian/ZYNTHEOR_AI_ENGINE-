import React from 'react';
import {
  ShieldCheck,
  FolderGit2,
  FileSpreadsheet,
  Activity,
  Cpu,
  Layers,
  Terminal,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface HeaderProps {
  onOpenWorkspaceInspector: () => void;
  onOpenAuditReport: () => void;
  onOpenRuntimeModal: () => void;
  ledgerValid: boolean;
  totalLedgerEvents: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenWorkspaceInspector,
  onOpenAuditReport,
  onOpenRuntimeModal,
  ledgerValid,
  totalLedgerEvents
}) => {
  return (
    <header className="border-b border-cyan-500/20 bg-[#070a12]/90 backdrop-blur-md sticky top-0 z-40 px-4 py-3">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Logo & System Brand */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-950 via-[#0a1224] to-cyan-900 border border-cyan-400/50 shadow-neon-cyan overflow-hidden">
            <span className="font-extrabold text-cyan-400 text-base tracking-wider">Z</span>
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#070a12]" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-lg tracking-wider text-slate-100 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-sky-200 to-indigo-300">
                ZYNTHEOR AI ENGINE
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                v4.2 PRO
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
                Zero-Fake Policy Active
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-cyan-400/80">Container Scope Sandbox</span>
            </div>
          </div>
        </div>

        {/* Quick Diagnostic Pills & Special Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
          {/* SPECIAL FEATURE 1: Inspect .data/workspace button */}
          <button
            onClick={onOpenWorkspaceInspector}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium font-mono text-cyan-300 bg-cyan-950/50 border border-cyan-500/40 hover:bg-cyan-900/60 hover:border-cyan-400 transition-all shadow-sm hover:shadow-neon-cyan"
            title="ตรวจสอบโครงสร้างไฟล์และขนาดใน .data/workspace"
          >
            <FolderGit2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>.data/workspace</span>
            <span className="px-1 py-0.2 rounded bg-cyan-500/20 text-[10px] text-cyan-300 font-bold">
              ตรวจขอบเขต
            </span>
          </button>

          {/* SPECIAL FEATURE 2: Cryptographic Audit Ledger & Report button */}
          <button
            onClick={onOpenAuditReport}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium font-mono text-amber-300 bg-amber-950/50 border border-amber-500/40 hover:bg-amber-900/60 hover:border-amber-400 transition-all shadow-sm hover:shadow-neon-cyan"
            title="สรุปและดาวน์โหลด Audit Report จาก Cryptographic Evidence Ledger"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Audit Ledger</span>
            <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
              ledgerValid ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300'
            }`}>
              {ledgerValid ? 'SHA-256 OK' : 'TAMPERED'} ({totalLedgerEvents})
            </span>
          </button>

          {/* Runtime & Hardware Diagnostics button */}
          <button
            onClick={onOpenRuntimeModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium font-mono text-slate-300 bg-slate-900/70 border border-slate-700/60 hover:bg-slate-800/80 hover:border-slate-500 transition-all"
            title="ตรวจสอบสถานะ Hardware และ Local Runtime"
          >
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <span>Hardware/Runtime</span>
          </button>
        </div>
      </div>
    </header>
  );
};
