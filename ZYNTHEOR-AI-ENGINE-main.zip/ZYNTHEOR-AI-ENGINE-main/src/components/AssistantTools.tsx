import React, { useMemo, useState } from 'react';
import { BookOpen, Check, FileText, Lightbulb, Mic, RotateCcw, Sparkles, Terminal, X, Zap } from 'lucide-react';
import { ChatSession } from '../types/agent';
import { deriveAssistantInsights } from '../utils/newFeatureLogic';

interface AssistantToolsProps {
  session: ChatSession;
  onSendCommand: (command: string) => void;
  onClearContext: () => void;
  onExportDocument: () => void;
  onOpenShortcuts: () => void;
}

const voiceCommands = [
  ['สรุปเซสชัน', 'สรุปประเด็นสำคัญของบทสนทนาปัจจุบัน'],
  ['เปิดแผนงาน', 'เปิดมุมมองแผนและงาน'],
  ['ตรวจสอบโค้ด', 'วิเคราะห์ไฟล์ที่เลือกและหาจุดบกพร่อง'],
  ['สร้างเอกสาร', 'สร้างเอกสารจากบริบทปัจจุบัน'],
  ['รันการทดสอบ', 'รัน /test ใน Sandbox'],
];

export const AssistantTools: React.FC<AssistantToolsProps> = ({ session, onSendCommand, onClearContext, onExportDocument, onOpenShortcuts }) => {
  const [open, setOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [insightsOpen, setInsightsOpen] = useState(false);
  const insights = useMemo(() => {
    return deriveAssistantInsights(session.messages || []);
  }, [session.messages]);

  return <>
    <div className="fixed right-5 bottom-[104px] z-40 flex flex-col items-end gap-2">
      {open && <div className="w-72 rounded-xl border border-zinc-800 bg-zinc-900/95 p-2 shadow-2xl backdrop-blur-md">
        <div className="px-3 py-2 text-[10px] font-mono font-bold uppercase tracking-wider text-blue-400">Quick Actions</div>
        {[
          ['สรุปเซสชัน', () => onSendCommand('ช่วยสรุปเซสชันนี้เป็นประเด็นสำคัญและรายการถัดไป')],
          ['ล้างบริบท', onClearContext],
          ['สร้างเอกสาร', onExportDocument],
          ['แผงช่วยเหลือ / ทางลัด', () => setHelpOpen(true)],
          ['ข้อมูลเชิงลึกจาก AI', () => setInsightsOpen(true)],
        ].map(([label, action]) => <button key={String(label)} onClick={() => { (action as () => void)(); setOpen(false); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-800/80 transition-colors cursor-pointer"><Zap className="h-3.5 w-3.5 text-blue-400" />{String(label)}</button>)}
      </div>}
      <button aria-label="เปิดการดำเนินการด่วน" onClick={() => setOpen(!open)} className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-500/20 transition-all cursor-pointer"><Sparkles className="h-4 w-4" /></button>
    </div>

    {(helpOpen || insightsOpen) && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4" onClick={() => { setHelpOpen(false); setInsightsOpen(false); }}>
      <div className="max-h-[85vh] w-full max-w-lg overflow-auto rounded-xl border border-zinc-800 bg-zinc-900 p-5 shadow-2xl text-zinc-100" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2 text-sm font-bold text-zinc-100">{helpOpen ? <BookOpen className="h-4 w-4 text-blue-400" /> : <Lightbulb className="h-4 w-4 text-amber-400" />}{helpOpen ? 'ความช่วยเหลือและทางลัดคีย์บอร์ด' : 'ข้อมูลเชิงลึกจาก AI Engine'}</div><button onClick={() => { setHelpOpen(false); setInsightsOpen(false); }} className="p-1 rounded text-zinc-400 hover:text-zinc-200"><X className="h-4 w-4" /></button></div>
        {helpOpen ? <div className="space-y-3"><div className="overflow-hidden rounded-lg border border-zinc-800 bg-zinc-950 p-3"><div className="flex items-center gap-2 text-cyan-400 text-xs font-mono font-semibold mb-1"><Terminal className="h-4 w-4" /> Zyntheor Engineering Studio</div><p className="text-[11px] text-zinc-400">ระบบสั่งการและพัฒนาซอฟต์แวร์อัจฉริยะแบบบูรณาการ</p></div><div className="rounded-lg bg-zinc-950 border border-zinc-800/80 p-3 text-xs text-zinc-300"><div className="mb-2 flex items-center gap-2 font-semibold text-zinc-200"><Mic className="h-3.5 w-3.5 text-blue-400" />คำสั่งเสียงที่รองรับ (Thai Voice Commands)</div>{voiceCommands.map(([command, description]) => <button key={command} onClick={() => onSendCommand(command)} className="mb-1.5 flex w-full items-center justify-between rounded-md bg-zinc-900 border border-zinc-850 px-2.5 py-2 text-left hover:border-blue-500/40 text-xs"><span><b className="text-zinc-100">“{command}”</b><span className="ml-2 text-zinc-400">{description}</span></span><Check className="h-3 w-3 text-emerald-400" /></button>)}</div><button onClick={onOpenShortcuts} className="flex w-full items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-2 text-xs text-zinc-300 hover:border-zinc-700 transition-colors"><BookOpen className="h-3.5 w-3.5 text-blue-400" />เปิดรายการคีย์ลัดทั้งหมด (Ctrl+/)</button></div> : <div className="space-y-4 text-xs"><section><h4 className="mb-2 font-semibold text-zinc-200 font-mono uppercase text-[11px] tracking-wider">ประเด็นสำคัญ (Key Points)</h4>{insights.keyPoints.length ? insights.keyPoints.map((x, i) => <div key={i} className="mb-1.5 rounded-lg bg-zinc-950 border border-zinc-850 p-2.5 text-zinc-300">• {x}</div>) : <div className="text-zinc-500">ยังไม่มีข้อมูลเพียงพอ</div>}</section><section><h4 className="mb-2 font-semibold text-zinc-200 font-mono uppercase text-[11px] tracking-wider">รายการดำเนินการที่รออยู่ (Pending Tasks)</h4>{insights.pending.length ? insights.pending.map((x, i) => <div key={i} className="mb-1.5 rounded-lg border border-amber-500/30 bg-amber-500/5 p-2.5 text-amber-200">{i + 1}. {x}</div>) : <div className="text-zinc-500">ไม่พบรายการค้าง</div>}</section></div>}
      </div>
    </div>}
  </>;
};
