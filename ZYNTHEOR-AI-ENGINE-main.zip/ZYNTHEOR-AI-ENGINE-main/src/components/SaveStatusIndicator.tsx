import { useEffect, useState } from 'react';
import { AlertTriangle, Check, RefreshCw } from 'lucide-react';
import { summarizeSaveStatus, type SaveChannel } from '../utils/saveStatus';

/** Small status chip: spinner while saving, green check (briefly highlighted) after a real save, red/amber on failure. */
export function SaveStatusIndicator({ local, server }: { local: SaveChannel; server: SaveChannel }) {
  const summary = summarizeSaveStatus(local, server);
  const lastOk = Math.max(local.at ?? 0, server.at ?? 0);
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    if (!lastOk) return;
    setFlash(true);
    const t = window.setTimeout(() => setFlash(false), 2500);
    return () => window.clearTimeout(t);
  }, [lastOk]);

  const toneClass =
    summary.tone === 'error'
      ? 'border-rose-500/40 bg-rose-500/10 text-rose-300'
      : summary.tone === 'partial'
      ? 'border-amber-500/40 bg-amber-500/10 text-amber-300'
      : summary.tone === 'saving'
      ? 'border-cyan-500/30 bg-cyan-500/10 text-cyan-300'
      : summary.tone === 'saved'
      ? flash
        ? 'border-emerald-400/60 bg-emerald-500/20 text-emerald-200'
        : 'border-emerald-500/20 bg-transparent text-emerald-400/80'
      : 'border-slate-700/60 bg-transparent text-slate-500';

  return (
    <span
      role="status"
      aria-live="polite"
      aria-atomic="true"
      data-testid="save-status"
      data-tone={summary.tone}
      title={summary.detail}
      className={`flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium whitespace-nowrap transition-colors duration-300 ${toneClass}`}
    >
      {summary.tone === 'saving' ? (
        <RefreshCw size={11} className="animate-spin" />
      ) : summary.tone === 'error' || summary.tone === 'partial' ? (
        <AlertTriangle size={11} />
      ) : summary.tone === 'saved' ? (
        <Check size={11} />
      ) : null}
      <span>{summary.text}</span>
    </span>
  );
}
