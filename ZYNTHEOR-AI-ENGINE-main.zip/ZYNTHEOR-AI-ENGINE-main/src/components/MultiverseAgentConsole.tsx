import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  CheckCircle2,
  Circle,
  Clock,
  AlertCircle,
  Play,
  RotateCcw,
  ShieldCheck,
  Cpu,
  Layers,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Save,
  Check,
  Send,
  MessageSquare,
  Lock,
  Globe2,
  Terminal,
  Activity,
  Award,
  Vote,
  Compass,
} from 'lucide-react';
import { HologramConsole } from './HologramConsole';
import { QuantumRuntimeHologram } from './QuantumRuntimeHologram';
import { CommercialLaunchDeck } from './CommercialLaunchDeck';
import {
  ExecutionPlan,
  ExecutionStep,
  SubTask,
  AgentDialogueMessage,
  DigitalPassport,
  ClusterStatus,
  calculatePlanProgress,
  toggleSubTaskInPlan,
} from '../types/orchestration';
import { computePlanProgress } from '../utils/planProgress';

const STORAGE_KEY_MULTIVERSE_PLANS = 'zyntheor_multiverse_execution_plans';

const INITIAL_PLANS: ExecutionPlan[] = [
  {
    id: 'plan-multiverse-1',
    title: 'Omniversal Sovereign Deployment & Telemetry Stream',
    goal: 'ติดตั้งและตรวจสอบ AI Engine Runtime บน Cluster Quantum พร้อมเชื่อมต่อ Telemetry Stream',
    targetCluster: 'Quantum',
    priority: 'critical',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    steps: [
      {
        id: 'step-intent',
        stepNumber: 1,
        title: 'Phase 1: Intent Recognition & Context Binding',
        description: 'วิเคราะห์เจตนาของคำสั่งและตรวจสอบสิทธิ์ดิจิทัลของ Agent',
        phase: 'intent',
        status: 'completed',
        subTasks: [
          {
            id: 'sub-1-1',
            title: 'ตรวจสอบ Digital Passport และ PQC Signature (Dilithium-5)',
            completed: true,
            assignedAgent: 'CyberDefense',
            estimatedMinutes: 2,
            completedAt: new Date().toISOString(),
          },
          {
            id: 'sub-1-2',
            title: 'วิเคราะห์โครงสร้างเป้าหมายใน Multiverse Matrix',
            completed: true,
            assignedAgent: 'Planner',
            estimatedMinutes: 3,
            completedAt: new Date().toISOString(),
          },
        ],
      },
      {
        id: 'step-reasoning',
        stepNumber: 2,
        title: 'Phase 2: Multi-Agent Reasoning & Consensus',
        description: 'การประชุมร่วมระหว่าง Agents (ตัวอย่างจำลอง ไม่มี HSM จริง)',
        phase: 'reasoning',
        status: 'in_progress',
        subTasks: [
          {
            id: 'sub-2-1',
            title: 'สร้างแผนภูมิการประมวลผลคู่ขนานแบบ Zero-Conflict',
            completed: true,
            assignedAgent: 'Planner',
            estimatedMinutes: 5,
            completedAt: new Date().toISOString(),
          },
          {
            id: 'sub-2-2',
            title: 'จำลอง Chaos-Resilience Simulation ป้องกัน Deadlock',
            completed: false,
            assignedAgent: 'Arbitrator',
            estimatedMinutes: 4,
          },
          {
            id: 'sub-2-3',
            title: 'รวบรวมมติเห็นชอบ Quad-Key Signoff',
            completed: false,
            assignedAgent: 'Verifier',
            estimatedMinutes: 3,
          },
        ],
      },
      {
        id: 'step-execution',
        stepNumber: 3,
        title: 'Phase 3: Autonomous Workflow Execution',
        description: 'รันคำสั่งบน Local Runtime และส่งข้อมูลไปยัง Sandbox',
        phase: 'execution',
        status: 'pending',
        subTasks: [
          {
            id: 'sub-3-1',
            title: 'สร้าง Sandbox Container พร้อม Network Isolation',
            completed: false,
            assignedAgent: 'DevOps',
            estimatedMinutes: 6,
          },
          {
            id: 'sub-3-2',
            title: 'ประมวลผลอนุมานโมเดล Local Runtime',
            completed: false,
            assignedAgent: 'Executor',
            estimatedMinutes: 8,
          },
        ],
      },
      {
        id: 'step-verification',
        stepNumber: 4,
        title: 'Phase 4: Empirical Verification & Trust Seal',
        description: 'ตรวจสอบความถูกต้องของผลลัพธ์และลงบันทึกใน Forensic Ledger',
        phase: 'verification',
        status: 'pending',
        subTasks: [
          {
            id: 'sub-4-1',
            title: 'รัน AI Assurance Benchmarking วัดคะแนนความน่าเชื่อถือ',
            completed: false,
            assignedAgent: 'Verifier',
            estimatedMinutes: 4,
          },
          {
            id: 'sub-4-2',
            title: 'บันทึก Merkle Root Proof เข้าสู่ Forensic Cluster',
            completed: false,
            assignedAgent: 'CyberDefense',
            estimatedMinutes: 3,
          },
        ],
      },
    ],
  },
  {
    id: 'plan-multiverse-2',
    title: 'Continuous Optimization & Feedback Learning Loop',
    goal: 'ปรับปรุงประสิทธิภาพการให้เหตุผลและการประสานงานระหว่าง Agent อัตโนมัติ',
    targetCluster: 'Planck',
    priority: 'high',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    steps: [
      {
        id: 'opt-step-1',
        stepNumber: 1,
        title: 'รวบรวมสัญญาณการเรียนรู้ (Reinforcement Signals)',
        description: 'ดึง Telemetry metrics และ latency จากทุก Realities',
        phase: 'intent',
        status: 'in_progress',
        subTasks: [
          { id: 'opt-sub-1', title: 'ตรวจจับ Anomaly ใน Telemetry Stream', completed: true, assignedAgent: 'DevOps' },
          { id: 'opt-sub-2', title: 'คำนวณ Token Efficiency และ Latency Trend', completed: false, assignedAgent: 'Executor' },
        ],
      },
      {
        id: 'opt-step-2',
        stepNumber: 2,
        title: 'Self-Tuning Runtime Parameters',
        description: 'ปรับแต่งพารามิเตอร์ของระบบโดยไม่ต้องตั้งค่าเอง',
        phase: 'execution',
        status: 'pending',
        subTasks: [
          { id: 'opt-sub-3', title: 'ปรับขนาด Batch Size และ Context Memory Buffer', completed: false, assignedAgent: 'Planner' },
          { id: 'opt-sub-4', title: 'Verify SLA Uptime > 99.999%', completed: false, assignedAgent: 'Verifier' },
        ],
      },
    ],
  },
];

const INITIAL_DIALOGUE: AgentDialogueMessage[] = [
  {
    id: 'msg-1',
    agentName: 'Astraea Ω',
    agentRole: 'Planner',
    avatarColor: 'border-cyan-400 text-cyan-300 bg-cyan-950/80',
    message: 'ได้รับภารกิจใหม่: ดำเนินการย่อย Omniversal Sovereign Deployment บน Quantum Cluster ขณะนี้แบ่งขั้นตอนย่อย 9 รายการพร้อมมอบหมายผู้รับผิดชอบ',
    timestamp: '12:04:15',
    consensusVote: 'approve',
  },
  {
    id: 'msg-2',
    agentName: 'Aegis Sentinel',
    agentRole: 'CyberDefense',
    avatarColor: 'border-rose-400 text-rose-300 bg-rose-950/80',
    message: 'ตรวจสอบ Digital Passport เรียบร้อยแล้ว PQC Dilithium-5 Signature ถูกต้อง ไร้รอยรั่วหรือ Anomaly ในโครงข่าย',
    timestamp: '12:04:18',
    consensusVote: 'approve',
  },
  {
    id: 'msg-3',
    agentName: 'Chronos Arbiter',
    agentRole: 'Arbitrator',
    avatarColor: 'border-amber-400 text-amber-300 bg-amber-950/80',
    message: 'มติการประสานงาน (Quorum Consensus): ได้รับการอนุมัติ 10/10 เสียงจากทุกคลัสเตอร์ อนุญาตให้ Executor เริ่มรันขั้นตอนย่อยถัดไป',
    timestamp: '12:04:22',
    consensusVote: 'approve',
  },
];

const AGENT_PASSPORTS: DigitalPassport[] = [
  { agentId: 'AG-01', agentName: 'Astraea Ω', role: 'Chief Orchestrator & Planner', securityClearance: 'Omniversal', pqcSignature: '0x9E7A...D41B', issuedAt: '2026-10-01', assuranceScore: 99.9 },
  { agentId: 'AG-02', agentName: 'Kratos Alpha', role: 'Autonomous Workflow Executor', securityClearance: 'Class-3', pqcSignature: '0x3F1C...88A2', issuedAt: '2026-10-05', assuranceScore: 99.4 },
  { agentId: 'AG-03', agentName: 'Themis Prime', role: 'Empirical Verification Agent', securityClearance: 'Omniversal', pqcSignature: '0x7B29...54C0', issuedAt: '2026-10-02', assuranceScore: 100.0 },
  { agentId: 'AG-04', agentName: 'Aegis Sentinel', role: 'CyberDefense & PQC Guard', securityClearance: 'Omniversal', pqcSignature: '0x1C4A...99FF', issuedAt: '2026-10-03', assuranceScore: 99.8 },
];

export const MultiverseAgentConsole: React.FC<{ lang?: 'en' | 'th' }> = ({ lang = 'th' }) => {
  const [plans, setPlans] = useState<ExecutionPlan[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_MULTIVERSE_PLANS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return INITIAL_PLANS;
  });

  const [selectedPlanId, setSelectedPlanId] = useState<string>(plans[0]?.id || 'plan-multiverse-1');
  const [dialogue, setDialogue] = useState<AgentDialogueMessage[]>(INITIAL_DIALOGUE);
  const [newSubTaskTitle, setNewSubTaskTitle] = useState<string>('');
  const [targetStepIdForNewSubTask, setTargetStepIdForNewSubTask] = useState<string>('');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'orchestration' | 'quantum' | 'launch' | 'dialogue' | 'trust'>('orchestration');

  const currentPlan = plans.find((p) => p.id === selectedPlanId) || plans[0];

  // Recalculate progress accurately using computePlanProgress and calculatePlanProgress
  const currentPlanProgress = currentPlan ? calculatePlanProgress(currentPlan) : { totalSubTasks: 0, completedSubTasks: 0, percentage: 0, completedSteps: 0, totalSteps: 0 };

  // Core requirement: Toggle individual sub-task and automatically update completion percentage in real-time
  const handleToggleSubTask = (stepId: string, subTaskId: string) => {
    if (!currentPlan) return;

    const updatedPlan = toggleSubTaskInPlan(currentPlan, stepId, subTaskId);
    const updatedPlans = plans.map((p) => (p.id === updatedPlan.id ? updatedPlan : p));

    setPlans(updatedPlans);

    // Save to storage and confirm only when write succeeds
    try {
      localStorage.setItem(STORAGE_KEY_MULTIVERSE_PLANS, JSON.stringify(updatedPlans));
      const readBack = localStorage.getItem(STORAGE_KEY_MULTIVERSE_PLANS);
      if (readBack) {
        setSaveStatus(lang === 'th' ? 'บันทึกแล้ว' : 'Saved');
        setTimeout(() => setSaveStatus(null), 2000);
      }
    } catch {
      setSaveStatus(null);
    }
  };

  // Add new sub-task to a step
  const handleAddSubTask = (stepId: string) => {
    if (!newSubTaskTitle.trim() || !currentPlan) return;

    const updatedSteps = currentPlan.steps.map((step) => {
      if (step.id !== stepId) return step;
      const newSub: SubTask = {
        id: `sub-${Date.now()}`,
        title: newSubTaskTitle.trim(),
        completed: false,
        assignedAgent: 'Executor',
        estimatedMinutes: 5,
      };
      return {
        ...step,
        subTasks: [...(step.subTasks || []), newSub],
      };
    });

    const updatedPlan: ExecutionPlan = {
      ...currentPlan,
      steps: updatedSteps,
      updatedAt: new Date().toISOString(),
    };

    const updatedPlans = plans.map((p) => (p.id === updatedPlan.id ? updatedPlan : p));
    setPlans(updatedPlans);
    setNewSubTaskTitle('');
    setTargetStepIdForNewSubTask('');

    try {
      localStorage.setItem(STORAGE_KEY_MULTIVERSE_PLANS, JSON.stringify(updatedPlans));
      setSaveStatus(lang === 'th' ? 'บันทึกแล้ว' : 'Saved');
      setTimeout(() => setSaveStatus(null), 2000);
    } catch {
      // silent
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Hologram Telemetry Console */}
      <HologramConsole
        activeClusterId={`c-${currentPlan?.targetCluster.toLowerCase()}`}
        lang={lang}
      />

      {/* Multiverse Control Deck Navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-zinc-950/80 border border-cyan-900/40 rounded-2xl backdrop-blur-md">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400 flex items-center justify-center">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
              <span>MULTIVERSE AI AGENT ORCHESTRATOR</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                v4.8 Ω
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">
              {lang === 'th'
                ? 'ระบบจัดการภารกิจขั้นตอนย่อย Quantum Core และการเปิดตัวเชิงพาณิชย์'
                : 'Autonomous Sub-task Execution, Quantum Core & Commercial Protocol'}
            </p>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex flex-wrap items-center gap-1.5 bg-zinc-900/80 p-1 rounded-xl border border-zinc-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('orchestration')}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              activeTab === 'orchestration'
                ? 'bg-cyan-500 text-black font-semibold shadow-sm shadow-cyan-500/50'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'th' ? 'แผนงานและขั้นตอนย่อย' : 'Plans & Sub-tasks'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('quantum')}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              activeTab === 'quantum'
                ? 'bg-cyan-500 text-black font-semibold shadow-sm shadow-cyan-500/50'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'th' ? 'Quantum Core' : 'Quantum Core'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('launch')}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              activeTab === 'launch'
                ? 'bg-cyan-500 text-black font-semibold shadow-sm shadow-cyan-500/50'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'th' ? 'GA-CERT & Ledger' : 'GA-CERT & Ledger'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('dialogue')}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              activeTab === 'dialogue'
                ? 'bg-cyan-500 text-black font-semibold shadow-sm shadow-cyan-500/50'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'th' ? 'การสนทนา Agents' : 'Agent Dialogue'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('trust')}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              activeTab === 'trust'
                ? 'bg-cyan-500 text-black font-semibold shadow-sm shadow-cyan-500/50'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'th' ? 'Trust & Passport' : 'Trust Layer'}
          </button>
        </div>
      </div>

      {/* Save Status Notification Banner */}
      {saveStatus && (
        <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs shadow-lg animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-400" />
          <span className="font-medium">{saveStatus}</span>
          <span className="text-[10px] text-emerald-400/70 font-mono">(บันทึกลง LocalStorage สำเร็จจริง)</span>
        </div>
      )}

      {/* TAB 1: ORCHESTRATION & SUB-TASKS TRACKING */}
      {activeTab === 'orchestration' && currentPlan && (
        <div className="space-y-5">
          {/* Plan Selector & Overall Progress Card */}
          <div className="p-4 rounded-2xl bg-zinc-950/90 border border-cyan-900/40 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono uppercase text-zinc-400 font-semibold">
                  {lang === 'th' ? 'เลือกแผนงาน:' : 'Select Plan:'}
                </span>
                <select
                  aria-label="เลือกแผนงานที่ต้องการติดตาม"
                  value={selectedPlanId}
                  onChange={(e) => setSelectedPlanId(e.target.value)}
                  className="bg-zinc-900 border border-zinc-700 text-zinc-100 text-xs rounded-xl px-3 py-1.5 font-medium focus:ring-1 focus:ring-cyan-400"
                >
                  {plans.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title}
                    </option>
                  ))}
                </select>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-950/70 text-amber-300 border border-amber-800">
                  Cluster: {currentPlan.targetCluster}
                </span>
              </div>

              {/* Progress Percentage Badge */}
              <div className="flex items-center gap-2.5">
                <span className="text-xs text-zinc-400">
                  {lang === 'th' ? 'ความคืบหน้ารวม:' : 'Overall Completion:'}
                </span>
                <span
                  className={`text-sm font-mono font-bold px-3 py-1 rounded-xl shadow-inner ${
                    currentPlanProgress.percentage === 100
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50 shadow-emerald-900/30'
                      : 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-cyan-900/30'
                  }`}
                  aria-label={`ความคืบหน้ารวม: ${currentPlanProgress.percentage}%`}
                >
                  {currentPlanProgress.percentage}%
                </span>
              </div>
            </div>

            {/* Dynamic Animated Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-mono text-zinc-400">
                <span className="text-cyan-400 font-medium">
                  {currentPlanProgress.completedSubTasks} จาก {currentPlanProgress.totalSubTasks} ขั้นตอนย่อยสำเร็จ
                </span>
                <span>
                  {currentPlanProgress.completedSteps} / {currentPlanProgress.totalSteps} ขั้นตอนหลักเสร็จสิ้น
                </span>
              </div>

              <div
                role="progressbar"
                aria-valuenow={currentPlanProgress.percentage}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`ความคืบหน้าของแผน ${currentPlan.title}`}
                className="relative h-3 w-full bg-zinc-900 rounded-full overflow-hidden border border-zinc-800 p-0.5"
              >
                <div
                  className={`h-full rounded-full transition-all duration-500 ease-out ${
                    currentPlanProgress.percentage === 100
                      ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 shadow-md shadow-emerald-500/40'
                      : 'bg-gradient-to-r from-cyan-500 via-blue-500 to-amber-500 shadow-md shadow-cyan-500/40'
                  }`}
                  style={{ width: `${currentPlanProgress.percentage}%` }}
                />
              </div>
            </div>
          </div>

            {/* Steps & Granular Sub-Tasks List */}
          <div className="space-y-3">
            {currentPlan.steps.map((step) => {
              const stepSubTasks = step.subTasks || [];
              const stepDoneCount = stepSubTasks.filter((st) => st.completed).length;
              const stepPercentage =
                stepSubTasks.length > 0 ? Math.round((stepDoneCount / stepSubTasks.length) * 100) : 0;

              return (
                <div
                  key={step.id}
                  className="rounded-2xl border border-zinc-800/80 bg-zinc-900/70 overflow-hidden shadow-lg transition-all"
                >
                  {/* Step Header */}
                  <div className="p-3.5 bg-zinc-850/80 border-b border-zinc-800 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-7 h-7 rounded-xl flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                          step.status === 'completed'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : step.status === 'in_progress'
                            ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                            : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                        }`}
                      >
                        #{step.stepNumber}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-zinc-100">{step.title}</h4>
                          <span
                            className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase font-semibold ${
                              step.status === 'completed'
                                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                                : step.status === 'in_progress'
                                ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800'
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            {step.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-0.5">{step.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 font-mono text-xs text-cyan-400">
                      <span>{stepDoneCount}/{stepSubTasks.length}</span>
                      <span className="text-zinc-500">({stepPercentage}%)</span>
                    </div>
                  </div>

                  {/* Sub-Tasks Checklist Section */}
                  <div className="p-3.5 space-y-2">
                    <div className="text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-semibold mb-2 flex items-center justify-between">
                      <span>{lang === 'th' ? 'รายการขั้นตอนย่อย (Sub-tasks)' : 'Individual Sub-tasks'}</span>
                      <button
                        type="button"
                        onClick={() => setTargetStepIdForNewSubTask(step.id)}
                        className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
                        aria-label="เพิ่มขั้นตอนย่อยใหม่"
                      >
                        <Plus className="w-3 h-3" />
                        <span>{lang === 'th' ? 'เพิ่มขั้นตอนย่อย' : 'Add Sub-task'}</span>
                      </button>
                    </div>

                    {/* Sub-Tasks Interactive Items */}
                    <div className="space-y-1.5">
                      {stepSubTasks.map((subTask) => (
                        <div
                          key={subTask.id}
                          onClick={() => handleToggleSubTask(step.id, subTask.id)}
                          className={`flex items-center justify-between gap-3 p-2.5 rounded-xl border text-xs transition-all cursor-pointer ${
                            subTask.completed
                              ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300'
                              : 'bg-zinc-950/50 border-zinc-800 text-zinc-300 hover:border-cyan-800/60 hover:bg-zinc-900/80'
                          }`}
                          role="checkbox"
                          aria-checked={subTask.completed}
                          tabIndex={0}
                          aria-label={`คลิกเพื่อสลับสถานะของ ${subTask.title}`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className="shrink-0 text-cyan-400">
                              {subTask.completed ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                              ) : (
                                <Circle className="w-4 h-4 text-zinc-600 hover:text-cyan-400 transition-colors" />
                              )}
                            </span>
                            <span
                              className={`truncate font-medium ${
                                subTask.completed ? 'line-through text-zinc-400' : 'text-zinc-200'
                              }`}
                            >
                              {subTask.title}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 font-mono text-[10px]">
                            {subTask.assignedAgent && (
                              <span className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-amber-300">
                                {subTask.assignedAgent}
                              </span>
                            )}
                            {subTask.estimatedMinutes && (
                              <span className="text-zinc-500 flex items-center gap-0.5">
                                <Clock className="w-3 h-3" /> {subTask.estimatedMinutes}m
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Quick Add Sub-Task Form */}
                    {targetStepIdForNewSubTask === step.id && (
                      <div className="mt-3 p-2.5 rounded-xl bg-zinc-950 border border-cyan-800/50 flex items-center gap-2">
                        <input
                          type="text"
                          aria-label="ชื่อขั้นตอนย่อยใหม่"
                          value={newSubTaskTitle}
                          onChange={(e) => setNewSubTaskTitle(e.target.value)}
                          placeholder={lang === 'th' ? 'ระบุชื่องานย่อย...' : 'Sub-task title...'}
                          className="bg-zinc-900 border border-zinc-700 rounded-lg px-2.5 py-1 text-xs text-zinc-100 flex-1 focus:ring-1 focus:ring-cyan-400"
                        />
                        <button
                          type="button"
                          onClick={() => handleAddSubTask(step.id)}
                          className="px-3 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-colors cursor-pointer"
                        >
                          {lang === 'th' ? 'เพิ่ม' : 'Add'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setTargetStepIdForNewSubTask('');
                            setNewSubTaskTitle('');
                          }}
                          className="px-2 py-1 text-xs text-zinc-400 hover:text-zinc-200 cursor-pointer"
                        >
                          {lang === 'th' ? 'ยกเลิก' : 'Cancel'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB: QUANTUM RUNTIME HOLOGRAM */}
      {activeTab === 'quantum' && (
        <QuantumRuntimeHologram lang={lang} />
      )}

      {/* TAB: COMMERCIAL LAUNCH & GA-CERT NOVA */}
      {activeTab === 'launch' && (
        <CommercialLaunchDeck lang={lang} />
      )}

      {/* TAB 2: MULTI-AGENT COORDINATION DIALOGUE */}
      {activeTab === 'dialogue' && (
        <div className="p-4 rounded-2xl bg-zinc-950/90 border border-cyan-900/40 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold text-zinc-100 uppercase tracking-wider">
                {lang === 'th' ? 'สายการสนทนาและมติระหว่าง AI Agents' : 'Multi-Agent Dialogue & Quorum'}
              </h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-950 border border-amber-500/40 text-amber-300">
              SIMULATED SAMPLE · no HSM quorum
            </span>
          </div>

          <div className="space-y-3">
            {dialogue.map((msg) => (
              <div
                key={msg.id}
                className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded-md font-mono text-[10px] font-bold border ${msg.avatarColor}`}>
                      {msg.agentName} ({msg.agentRole})
                    </span>
                    <span className="text-[10px] font-mono text-zinc-500">{msg.timestamp}</span>
                  </div>
                  {msg.consensusVote && (
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 font-semibold">
                      <Vote className="w-3 h-3" /> Consensus Approved
                    </span>
                  )}
                </div>
                <p className="text-zinc-300 leading-relaxed">{msg.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: TRUST LAYER & DIGITAL PASSPORT */}
      {activeTab === 'trust' && (
        <div className="p-4 rounded-2xl bg-zinc-950/90 border border-cyan-900/40 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-zinc-100 uppercase tracking-wider">
                {lang === 'th' ? 'หนังสือเดินทางดิจิทัลและ AI Assurance' : 'Digital Passport & AI Assurance'}
              </h3>
            </div>
            <span className="text-[10px] font-mono text-zinc-400">Post-Quantum Cryptography Verified</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {AGENT_PASSPORTS.map((agent) => (
              <div
                key={agent.agentId}
                className="p-3.5 rounded-xl border border-amber-900/30 bg-amber-950/10 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-xs text-zinc-200">{agent.agentName}</div>
                  <span className="font-mono text-[9px] px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                    {agent.securityClearance}
                  </span>
                </div>
                <div className="text-[11px] text-zinc-400">{agent.role}</div>
                <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 border-t border-amber-900/20 pt-2">
                  <span>PQC: {agent.pqcSignature}</span>
                  <span className="text-emerald-400 font-bold">Assurance: {agent.assuranceScore}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
