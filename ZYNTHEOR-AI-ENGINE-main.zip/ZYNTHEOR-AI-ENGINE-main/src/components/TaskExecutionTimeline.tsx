import React, { useState, useEffect, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import {
  Clock,
  RotateCcw,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Play,
  ShieldCheck,
  Filter,
} from 'lucide-react';

export interface TimelineDataPoint {
  index: number;
  timestamp: number;
  timeFormatted: string;
  isoTime: string;
  taskId: string;
  taskType?: string;
  state: string;
  stateLevel: number;
  previousState?: string;
  reason?: string;
  exitCode?: number;
  durationMs?: number;
  verified?: boolean;
}

const STATE_LEVEL_MAP: Record<string, { level: number; label: string; color: string }> = {
  FAILED: { level: 0, label: 'FAILED', color: '#f43f5e' },
  BLOCKED: { level: 0.5, label: 'BLOCKED', color: '#fb7185' },
  PENDING: { level: 1, label: 'PENDING / PROPOSED', color: '#a1a1aa' },
  PLANNED: { level: 1, label: 'PLANNED', color: '#a1a1aa' },
  PROPOSED: { level: 1, label: 'PROPOSED', color: '#a1a1aa' },
  WAITING_APPROVAL: { level: 2, label: 'WAITING_APPROVAL', color: '#f59e0b' },
  APPROVED: { level: 2.2, label: 'APPROVED', color: '#6366f1' },
  RETRY: { level: 2.7, label: 'RETRY', color: '#ec4899' },
  RUNNING: { level: 3.5, label: 'RUNNING', color: '#06b6d4' },
  VERIFYING: { level: 4.2, label: 'VERIFYING', color: '#14b8a6' },
  COMPLETED: { level: 5, label: 'COMPLETED', color: '#10b981' },
  SUCCEEDED: { level: 5, label: 'SUCCEEDED', color: '#10b981' },
};

function getStateLevel(stateStr?: string): { level: number; label: string; color: string } {
  if (!stateStr) return { level: 1, label: 'UNKNOWN', color: '#71717a' };
  const upper = stateStr.toUpperCase();
  if (STATE_LEVEL_MAP[upper]) return STATE_LEVEL_MAP[upper];
  if (upper.includes('FAIL')) return STATE_LEVEL_MAP.FAILED;
  if (upper.includes('RETRY')) return STATE_LEVEL_MAP.RETRY;
  if (upper.includes('RUN') || upper.includes('EXEC')) return STATE_LEVEL_MAP.RUNNING;
  if (upper.includes('VERIF')) return STATE_LEVEL_MAP.VERIFYING;
  if (upper.includes('SUCC') || upper.includes('COMPL') || upper.includes('DONE')) return STATE_LEVEL_MAP.COMPLETED;
  if (upper.includes('APPROV')) return STATE_LEVEL_MAP.APPROVED;
  return { level: 1, label: upper, color: '#71717a' };
}

interface TaskExecutionTimelineProps {
  lang?: 'en' | 'th';
  highlightTaskId?: string;
}

export const TaskExecutionTimeline: React.FC<TaskExecutionTimelineProps> = ({
  lang = 'th',
  highlightTaskId,
}) => {
  const [timelineData, setTimelineData] = useState<TimelineDataPoint[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string>(highlightTaskId || 'all');
  const [chartType, setChartType] = useState<'area' | 'line'>('area');

  // Load audit trail & evidence ledger records to construct timeline
  const fetchTimelineHistory = async () => {
    setLoading(true);
    try {
      const [resAudit, resEvidence, resPlans] = await Promise.all([
        fetch('/api/audit').catch(() => null),
        fetch('/api/evidence-ledger').catch(() => null),
        fetch('/api/plans').catch(() => null),
      ]);

      const points: TimelineDataPoint[] = [];

      // 1. Audit events
      if (resAudit && resAudit.ok) {
        const auditData = await resAudit.json();
        const events = auditData.events || [];

        events.forEach((evt: any) => {
          const t = new Date(evt.timestamp || evt.at || Date.now()).getTime();
          let state = 'PENDING';
          const type = (evt.type || '').toUpperCase();

          if (type.includes('PROPOSED') || type === 'PLAN_PROPOSED') state = 'PROPOSED';
          else if (type.includes('WAITING') || type === 'APPROVAL_REQUESTED') state = 'WAITING_APPROVAL';
          else if (type.includes('APPROVED') || type === 'PLAN_APPROVED') state = 'APPROVED';
          else if (type.includes('EXECUTED') || type === 'STEP_EXECUTED') state = 'RUNNING';
          else if (type.includes('VERIFIED') || type === 'STEP_VERIFIED') state = 'VERIFYING';
          else if (type.includes('FAILED') || type === 'TASK_EXECUTION_FAILED') state = 'FAILED';
          else if (type.includes('RETRY')) state = 'RETRY';
          else if (evt.data?.state) state = evt.data.state;

          const { level } = getStateLevel(state);
          const taskId = evt.planId || evt.data?.taskId || evt.data?.plan?.id || 'sys_task';

          points.push({
            index: 0,
            timestamp: t,
            timeFormatted: new Date(t).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            isoTime: new Date(t).toISOString(),
            taskId,
            taskType: evt.data?.taskType || evt.type,
            state,
            stateLevel: level,
            previousState: evt.data?.stateAtFailure || evt.data?.fromState,
            reason: evt.data?.failureReason || evt.reason || evt.type,
            exitCode: evt.data?.exitCode,
            durationMs: evt.data?.durationMs,
          });
        });
      }

      // 2. Evidence ledger records
      if (resEvidence && resEvidence.ok) {
        const evData = await resEvidence.json();
        const records = evData.records || [];

        records.forEach((rec: any) => {
          const t = rec.timestamps?.startedAt
            ? new Date(rec.timestamps.startedAt).getTime()
            : new Date(rec.timestamp || Date.now()).getTime();

          const exitCode = rec.exitCode ?? 0;
          const isVerified = rec.verified || rec.verificationStatus === 'VERIFIED';
          const state = exitCode !== 0 ? 'FAILED' : isVerified ? 'COMPLETED' : 'VERIFYING';
          const { level } = getStateLevel(state);

          points.push({
            index: 0,
            timestamp: t,
            timeFormatted: new Date(t).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            isoTime: new Date(t).toISOString(),
            taskId: rec.taskId || 'evidence_task',
            taskType: rec.taskType || (Array.isArray(rec.command) ? rec.command[0] : 'command'),
            state,
            stateLevel: level,
            reason: rec.outputSummary ? rec.outputSummary.slice(0, 100) : undefined,
            exitCode,
            durationMs: rec.timestamps?.durationMs || rec.executionTimeMs,
            verified: isVerified,
          });
        });
      }

      // An empty ledger is a real empty state; never fabricate transitions for display.
      // Sort chronologically and assign indices
      points.sort((a, b) => a.timestamp - b.timestamp);
      points.forEach((p, idx) => {
        p.index = idx + 1;
      });

      setTimelineData(points);
    } catch (err) {
      console.warn('Failed to fetch timeline history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTimelineHistory();
  }, []);

  // Filter unique task IDs
  const uniqueTaskIds = useMemo(() => {
    const set = new Set<string>();
    timelineData.forEach((p) => {
      if (p.taskId) set.add(p.taskId);
    });
    return Array.from(set);
  }, [timelineData]);

  // Filtered timeline data
  const filteredData = useMemo(() => {
    if (selectedTaskId === 'all') return timelineData;
    return timelineData.filter((p) => p.taskId === selectedTaskId);
  }, [timelineData, selectedTaskId]);

  // Stats calculation
  const stats = useMemo(() => {
    const total = filteredData.length;
    const completed = filteredData.filter((p) => p.state === 'COMPLETED' || p.state === 'SUCCEEDED').length;
    const retries = filteredData.filter((p) => p.state === 'RETRY').length;
    const failures = filteredData.filter((p) => p.state === 'FAILED' || p.state === 'BLOCKED').length;
    return { total, completed, retries, failures };
  }, [filteredData]);

  // Custom Recharts Tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data: TimelineDataPoint = payload[0].payload;
      const stateInfo = getStateLevel(data.state);

      return (
        <div className="bg-zinc-950/95 border border-zinc-700 p-3 rounded-xl shadow-2xl text-xs space-y-1.5 max-w-xs font-sans backdrop-blur-md">
          <div className="flex items-center justify-between gap-2 border-b border-zinc-800 pb-1.5">
            <span className="font-mono text-[10px] text-zinc-400">{data.timeFormatted}</span>
            <span
              className="px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase"
              style={{ backgroundColor: `${stateInfo.color}25`, color: stateInfo.color }}
            >
              {data.state}
            </span>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-zinc-300">
              <span className="text-zinc-500 font-mono text-[10px]">Task ID:</span>
              <span className="font-mono text-cyan-300 truncate" title={data.taskId}>
                {data.taskId.length > 20 ? `${data.taskId.slice(0, 16)}...` : data.taskId}
              </span>
            </div>

            {data.previousState && (
              <div className="text-[11px] text-zinc-400">
                <span className="text-zinc-500">Transition:</span> {data.previousState} ➔{' '}
                <strong style={{ color: stateInfo.color }}>{data.state}</strong>
              </div>
            )}

            {data.durationMs !== undefined && (
              <div className="text-[11px] text-zinc-400">
                <span className="text-zinc-500">Duration:</span> {data.durationMs} ms
              </div>
            )}

            {data.exitCode !== undefined && (
              <div className="text-[11px] text-zinc-400">
                <span className="text-zinc-500">Exit Code:</span>{' '}
                <span className={data.exitCode === 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {data.exitCode}
                </span>
              </div>
            )}

            {data.reason && (
              <p className="text-[11px] text-zinc-300 bg-zinc-900 p-1.5 rounded border border-zinc-800 break-words line-clamp-3">
                {data.reason}
              </p>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-zinc-900/70 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-5">
      {/* Timeline Header Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-800 text-cyan-400 flex items-center justify-center">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-100">
                {lang === 'th' ? 'ไทม์ไลน์การเปลี่ยนสถานะของงาน (Task Execution Timeline)' : 'Task Execution & Transition Timeline'}
              </h3>
              <p className="text-xs text-zinc-400">
                {lang === 'th'
                  ? 'แสดงพัฒนาการเชิงเวลาของ State Transitions ตาม FSM Lifecycle จาก Ledger จริง'
                  : 'Historical progression of task executions mapping state transitions over time'}
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls & Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Task Filter */}
          <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-zinc-300">
            <Filter className="w-3.5 h-3.5 text-zinc-500" />
            <select
              value={selectedTaskId}
              onChange={(e) => setSelectedTaskId(e.target.value)}
              className="bg-transparent focus:outline-none text-xs text-zinc-200 cursor-pointer"
            >
              <option value="all" className="bg-zinc-900">
                {lang === 'th' ? 'งานทั้งหมด (All Tasks)' : 'All Tasks'} ({timelineData.length})
              </option>
              {uniqueTaskIds.map((id) => (
                <option key={id} value={id} className="bg-zinc-900">
                  {id.slice(0, 18)}...
                </option>
              ))}
            </select>
          </div>

          {/* Chart Type Switcher */}
          <div className="flex items-center bg-zinc-950 p-0.5 rounded-lg border border-zinc-800 text-xs">
            <button
              type="button"
              onClick={() => setChartType('area')}
              className={`px-2 py-1 rounded font-medium transition-all ${
                chartType === 'area'
                  ? 'bg-zinc-800 text-cyan-400 font-bold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              Area
            </button>
            <button
              type="button"
              onClick={() => setChartType('line')}
              className={`px-2 py-1 rounded font-medium transition-all ${
                chartType === 'line'
                  ? 'bg-zinc-800 text-cyan-400 font-bold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              Line
            </button>
          </div>

          <button
            type="button"
            onClick={fetchTimelineHistory}
            className="p-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
            title={lang === 'th' ? 'รีเฟรชข้อมูลไทม์ไลน์' : 'Refresh timeline'}
          >
            <RotateCcw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Metric Chips Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
          <div className="text-[10px] text-zinc-400 uppercase font-semibold">
            {lang === 'th' ? 'การเปลี่ยนสถานะทั้งหมด' : 'Total Transitions'}
          </div>
          <div className="text-lg font-bold font-mono text-zinc-100">{stats.total}</div>
        </div>
        <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
          <div className="text-[10px] text-emerald-400 uppercase font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> {lang === 'th' ? 'สำเร็จยืนยันแล้ว' : 'Completed / Succeeded'}
          </div>
          <div className="text-lg font-bold font-mono text-emerald-300">{stats.completed}</div>
        </div>
        <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
          <div className="text-[10px] text-pink-400 uppercase font-semibold flex items-center gap-1">
            <RotateCcw className="w-3 h-3" /> {lang === 'th' ? 'รอบการลองใหม่ (Retries)' : 'Recovery Retries'}
          </div>
          <div className="text-lg font-bold font-mono text-pink-300">{stats.retries}</div>
        </div>
        <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
          <div className="text-[10px] text-rose-400 uppercase font-semibold flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> {lang === 'th' ? 'ข้อผิดพลาด/ถูกบล็อก' : 'Failed / Blocked'}
          </div>
          <div className="text-lg font-bold font-mono text-rose-300">{stats.failures}</div>
        </div>
      </div>

      {/* Main Recharts Visual Timeline Component */}
      <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800/90">
        <div className="h-64 sm:h-72 w-full relative">
          {filteredData.length === 0 && (
            <div className="absolute inset-0 z-10 flex items-center justify-center text-center text-sm text-zinc-500">
              {lang === 'th' ? 'ไม่มีข้อมูลการเปลี่ยนสถานะจาก Audit/Evidence Ledger' : 'UNAVAILABLE: no Audit/Evidence Ledger transitions were returned'}
            </div>
          )}
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={filteredData} margin={{ top: 10, right: 15, left: 0, bottom: 20 }}>
              <defs>
                <linearGradient id="timelineGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.6} />
                  <stop offset="50%" stopColor="#6366f1" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
              <XAxis
                dataKey="timeFormatted"
                stroke="#71717a"
                tick={{ fontSize: 10 }}
                tickMargin={8}
              />
              <YAxis
                domain={[0, 5]}
                ticks={[0, 1, 2, 3, 4, 5]}
                stroke="#71717a"
                tick={{ fontSize: 10 }}
                tickFormatter={(val) => {
                  switch (val) {
                    case 0:
                      return 'FAILED';
                    case 1:
                      return 'PLANNED';
                    case 2:
                      return 'APPROVAL';
                    case 3:
                      return 'RUNNING';
                    case 4:
                      return 'VERIFY';
                    case 5:
                      return 'COMPLETED';
                    default:
                      return '';
                  }
                }}
              />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine
                y={5}
                stroke="#10b981"
                strokeDasharray="4 4"
                label={{ value: 'Target: Verified Complete (5.0)', fill: '#10b981', fontSize: 10, position: 'insideTopRight' }}
              />
              <ReferenceLine
                y={3}
                stroke="#06b6d4"
                strokeDasharray="3 3"
                label={{ value: 'Execution: RUNNING (3.0)', fill: '#06b6d4', fontSize: 9, position: 'insideBottomRight' }}
              />

              {chartType === 'area' ? (
                <Area
                  type="monotone"
                  dataKey="stateLevel"
                  stroke="#06b6d4"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#timelineGradient)"
                  dot={{ r: 4, fill: '#06b6d4', stroke: '#0891b2', strokeWidth: 1.5 }}
                  activeDot={{ r: 7, fill: '#38bdf8', stroke: '#ffffff', strokeWidth: 2 }}
                />
              ) : (
                <Line
                  type="stepAfter"
                  dataKey="stateLevel"
                  stroke="#38bdf8"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#38bdf8', stroke: '#0284c7' }}
                  activeDot={{ r: 7, fill: '#ffffff', stroke: '#06b6d4', strokeWidth: 2 }}
                />
              )}
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Legend of FSM Transition States */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-3 border-t border-zinc-800 text-[11px] text-zinc-400 font-mono">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-zinc-500" /> 1. Planned
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> 2. Waiting Approval
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-pink-500" /> 2.7 Recovery Retry
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" /> 3. Running
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> 4. Verifying
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> 5. Completed
          </span>
        </div>
      </div>
    </div>
  );
};
