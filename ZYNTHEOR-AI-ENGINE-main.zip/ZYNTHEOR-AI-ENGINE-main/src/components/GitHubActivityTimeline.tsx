import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  GitCommit,
  GitPullRequest,
  GitBranch,
  GitMerge,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ExternalLink,
  RefreshCw,
  Search,
  Filter,
  Copy,
  Check,
  User,
  Tag,
  Calendar,
} from 'lucide-react';
import type {
  MonitoredRepository,
  GitHubCommitItem,
  GitHubPullRequestItem,
  GitHubActivityItem,
} from '../types/connectors';

interface GitHubActivityTimelineProps {
  lang: 'en' | 'th';
  monitoredRepo?: MonitoredRepository | null;
  githubToken?: string;
  onRefreshTrigger?: () => void;
}

export const GitHubActivityTimeline: React.FC<GitHubActivityTimelineProps> = ({
  lang,
  monitoredRepo,
  githubToken,
  onRefreshTrigger,
}) => {
  const th = lang === 'th';

  const [activeTab, setActiveTab] = useState<'all' | 'commits' | 'prs'>('all');
  const [filterQuery, setFilterQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedSha, setCopiedSha] = useState<string | null>(null);

  const [commits, setCommits] = useState<GitHubCommitItem[]>([]);
  const [pullRequests, setPullRequests] = useState<GitHubPullRequestItem[]>([]);
  const [lastFetchedAt, setLastFetchedAt] = useState<string | null>(null);

  // Active repository resolution
  const repo = useMemo<MonitoredRepository | null>(() => {
    if (monitoredRepo) return monitoredRepo;
    try {
      if (typeof localStorage !== 'undefined') {
        const saved = localStorage.getItem('zyntheor_active_github_repo');
        if (saved) return JSON.parse(saved) as MonitoredRepository;
      }
    } catch {
      // ignore
    }
    return null;
  }, [monitoredRepo]);

  // Fetch commits and PRs from server activity endpoint
  const fetchActivity = useCallback(async () => {
    if (!repo?.owner || !repo.name) {
      setCommits([]);
      setPullRequests([]);
      setLastFetchedAt(null);
      setError(th ? 'ยังไม่ได้เลือก repository ที่มอนิเตอร์' : 'No monitored GitHub repository is selected.');
      return;
    }
    setIsLoading(true);
    setError(null);

    const activeToken =
      githubToken ||
      (typeof localStorage !== 'undefined'
        ? localStorage.getItem('zyntheor_github_token') ||
          localStorage.getItem('zyntheor_auth_token') ||
          ''
        : '');

    const headers: Record<string, string> = { Accept: 'application/json' };
    if (activeToken) {
      headers['x-github-token'] = activeToken;
      headers['Authorization'] = `Bearer ${activeToken}`;
    }

    try {
      const res = await fetch(
        `/api/engine/connectors/github/activity?owner=${encodeURIComponent(repo.owner)}&repo=${encodeURIComponent(repo.name)}`,
        { headers }
      );

      if (!res.ok) {
        throw new Error(`Failed to load activity: HTTP ${res.status}`);
      }

      const data = await res.json();
      setCommits(Array.isArray(data.commits) ? data.commits : []);
      setPullRequests(Array.isArray(data.pullRequests) ? data.pullRequests : []);
      setLastFetchedAt(new Date().toLocaleTimeString());
    } catch (err: any) {
      setError(err.message || 'Error fetching activity');
      setCommits([]);
      setPullRequests([]);
      setLastFetchedAt(null);
    } finally {
      setIsLoading(false);
      onRefreshTrigger?.();
    }
  }, [repo, githubToken, onRefreshTrigger]);

  useEffect(() => {
    void fetchActivity();
  }, [fetchActivity]);

  // Combine commits and PRs into a unified chronological timeline
  const combinedTimeline = useMemo<GitHubActivityItem[]>(() => {
    const items: GitHubActivityItem[] = [];

    commits.forEach((c) => {
      items.push({
        id: `commit_${c.sha}`,
        type: 'commit',
        timestamp: c.date,
        commit: c,
      });
    });

    pullRequests.forEach((pr) => {
      items.push({
        id: `pr_${pr.number}`,
        type: 'pull_request',
        timestamp: pr.updatedAt || pr.createdAt,
        pullRequest: pr,
      });
    });

    // Sort descending by timestamp
    return items.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [commits, pullRequests]);

  // Filter based on active tab and query
  const filteredItems = useMemo(() => {
    const q = filterQuery.toLowerCase().trim();
    return combinedTimeline.filter((item) => {
      if (activeTab === 'commits' && item.type !== 'commit') return false;
      if (activeTab === 'prs' && item.type !== 'pull_request') return false;

      if (!q) return true;

      if (item.type === 'commit' && item.commit) {
        return (
          item.commit.message.toLowerCase().includes(q) ||
          item.commit.author.toLowerCase().includes(q) ||
          item.commit.shortSha.toLowerCase().includes(q)
        );
      }

      if (item.type === 'pull_request' && item.pullRequest) {
        return (
          item.pullRequest.title.toLowerCase().includes(q) ||
          item.pullRequest.user.toLowerCase().includes(q) ||
          String(item.pullRequest.number).includes(q) ||
          item.pullRequest.labels.some((l) => l.toLowerCase().includes(q))
        );
      }

      return true;
    });
  }, [combinedTimeline, activeTab, filterQuery]);

  const copySha = (sha: string) => {
    navigator.clipboard.writeText(sha);
    setCopiedSha(sha);
    setTimeout(() => setCopiedSha(null), 2000);
  };

  const formatRelativeTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 1) return th ? 'เมื่อสักครู่' : 'just now';
      if (diffMins < 60) return th ? `${diffMins} นาทีที่แล้ว` : `${diffMins}m ago`;
      if (diffHours < 24) return th ? `${diffHours} ชั่วโมงที่แล้ว` : `${diffHours}h ago`;
      if (diffDays === 1) return th ? 'เมื่อวาน' : 'yesterday';
      if (diffDays < 30) return th ? `${diffDays} วันที่แล้ว` : `${diffDays}d ago`;
      return date.toLocaleDateString();
    } catch {
      return isoString;
    }
  };

  if (!repo) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-3 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-zinc-500/10 border border-zinc-500/20 rounded-xl text-zinc-400">
            <GitBranch className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-zinc-100">
              {th ? 'ไทม์ไลน์ GitHub' : 'GitHub Activity Timeline'}
            </h3>
            <p className="text-xs text-zinc-500">
              UNAVAILABLE — {error || (th ? 'ยังไม่ได้เลือก repository ที่มอนิเตอร์' : 'No monitored repository selected.')}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-400">
            <GitBranch className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-zinc-100">
                {th ? 'ไทม์ไลน์คอมมิต & สถานะ Pull Request' : 'Commit Activity & Pull Request Timeline'}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                {repo.fullName}
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              {th
                ? 'ติดตามกิจกรรมการส่งโค้ดล่าสุด และความคืบหน้าของ Pull Requests ในคลังที่มอนิเตอร์'
                : 'Visualize recent commits and pull request lifecycle for the active repository'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {lastFetchedAt && (
            <span className="text-[11px] text-zinc-500 font-mono hidden sm:inline">
              {th ? 'อัปเดต:' : 'Updated:'} {lastFetchedAt}
            </span>
          )}
          <button
            type="button"
            onClick={() => void fetchActivity()}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium transition-colors disabled:opacity-50"
            title="Refresh Activity"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-cyan-400' : ''}`} />
            <span>{th ? 'รีเฟรชไทม์ไลน์' : 'Refresh'}</span>
          </button>
        </div>
      </div>

      {/* Filter and Tab Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Tabs */}
        <div className="flex rounded-xl bg-zinc-950 p-1 border border-zinc-800 self-start">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'all'
                ? 'bg-cyan-600 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {th ? `ทั้งหมด (${combinedTimeline.length})` : `All (${combinedTimeline.length})`}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('commits')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'commits'
                ? 'bg-cyan-600 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <GitCommit className="w-3.5 h-3.5" />
            <span>{th ? `คอมมิต (${commits.length})` : `Commits (${commits.length})`}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('prs')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'prs'
                ? 'bg-cyan-600 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <GitPullRequest className="w-3.5 h-3.5" />
            <span>{th ? `Pull Requests (${pullRequests.length})` : `PRs (${pullRequests.length})`}</span>
          </button>
        </div>

        {/* Search input in timeline */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-zinc-500" />
          <input
            type="text"
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            placeholder={th ? 'ค้นหาคอมมิต หรือ PR...' : 'Filter timeline events...'}
            className="w-full pl-8 pr-3 py-1.5 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Timeline Stream */}
      <div className="relative pl-6 sm:pl-8 space-y-4 max-h-96 overflow-y-auto pr-1">
        {/* Continuous vertical timeline connector line */}
        <div className="absolute left-2.5 sm:left-3.5 top-3 bottom-3 w-0.5 bg-gradient-to-b from-cyan-500 via-amber-500 to-zinc-800"></div>

        {filteredItems.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500 italic">
            {isLoading
              ? th ? 'กำลังโหลดกิจกรรมจาก GitHub...' : 'Fetching activity from GitHub...'
              : error
              ? `UNAVAILABLE: ${error}`
              : th ? 'ไม่พบรายการที่ตรงกับคำค้นหา' : 'No activity records match your filter.'}
          </div>
        ) : (
          filteredItems.map((item) => {
            const isCommit = item.type === 'commit' && item.commit;
            const isPR = item.type === 'pull_request' && item.pullRequest;

            return (
              <div key={item.id} className="relative group">
                {/* Node icon on timeline line */}
                <div
                  className={`absolute -left-6 sm:-left-8 top-2.5 w-6 h-6 rounded-full flex items-center justify-center border transition-all ${
                    isCommit
                      ? 'bg-zinc-950 border-cyan-500/60 text-cyan-400 group-hover:scale-110 group-hover:border-cyan-400'
                      : item.pullRequest?.state === 'merged'
                      ? 'bg-amber-950 border-amber-500 text-amber-300 group-hover:scale-110'
                      : item.pullRequest?.state === 'closed'
                      ? 'bg-rose-950 border-rose-600 text-rose-300'
                      : 'bg-emerald-950 border-emerald-500 text-emerald-300 group-hover:scale-110'
                  }`}
                >
                  {isCommit ? (
                    <GitCommit className="w-3.5 h-3.5" />
                  ) : item.pullRequest?.state === 'merged' ? (
                    <GitMerge className="w-3.5 h-3.5" />
                  ) : item.pullRequest?.state === 'closed' ? (
                    <XCircle className="w-3.5 h-3.5" />
                  ) : (
                    <GitPullRequest className="w-3.5 h-3.5" />
                  )}
                </div>

                {/* Timeline Card */}
                {isCommit && item.commit && (
                  <div className="p-3 bg-zinc-950/80 hover:bg-zinc-950 border border-zinc-850 hover:border-cyan-900/60 rounded-xl space-y-2 transition-all">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-[10px] px-1.5 py-0.5 rounded font-mono font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800">
                          COMMIT
                        </span>
                        <div className="flex items-center gap-1 font-mono text-xs text-zinc-300 font-semibold truncate">
                          <span>{item.commit.shortSha}</span>
                          <button
                            type="button"
                            onClick={() => copySha(item.commit!.sha)}
                            className="p-1 hover:text-white text-zinc-500"
                            title="Copy Full SHA"
                          >
                            {copiedSha === item.commit.sha ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-zinc-500 shrink-0">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3 text-zinc-400" />
                          <span className="text-zinc-300 font-medium">@{item.commit.author}</span>
                        </span>
                        <span>•</span>
                        <span>{formatRelativeTime(item.commit.date)}</span>
                      </div>
                    </div>

                    <p className="text-xs text-zinc-200 font-medium leading-snug">
                      {item.commit.message}
                    </p>

                    <div className="flex items-center justify-between pt-1 border-t border-zinc-900 text-[11px]">
                      <span className="text-[10px] text-zinc-500 font-mono">
                        Branch: {repo.selectedBranch || repo.defaultBranch}
                      </span>
                      {item.commit.htmlUrl && (
                        <a
                          href={item.commit.htmlUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 hover:underline"
                        >
                          <span>{th ? 'ดูบน GitHub' : 'View Commit'}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                )}

                {isPR && item.pullRequest && (
                  <div className="p-3 bg-zinc-950/80 hover:bg-zinc-950 border border-zinc-850 hover:border-amber-900/60 rounded-xl space-y-2 transition-all">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border ${
                            item.pullRequest.state === 'merged'
                              ? 'bg-amber-950 text-amber-300 border-amber-800'
                              : item.pullRequest.state === 'closed'
                              ? 'bg-rose-950 text-rose-300 border-rose-800'
                              : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          }`}
                        >
                          {item.pullRequest.state === 'merged'
                            ? 'Merged'
                            : item.pullRequest.state === 'closed'
                            ? 'Closed'
                            : 'Open PR'}
                        </span>
                        <span className="text-xs font-mono font-bold text-zinc-300">
                          #{item.pullRequest.number}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-zinc-500 shrink-0">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3 text-zinc-400" />
                          <span className="text-zinc-300 font-medium">@{item.pullRequest.user}</span>
                        </span>
                        <span>•</span>
                        <span>{formatRelativeTime(item.pullRequest.createdAt)}</span>
                      </div>
                    </div>

                    <p className="text-xs text-zinc-100 font-medium leading-snug">
                      {item.pullRequest.title}
                    </p>

                    {item.pullRequest.labels.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1 pt-1">
                        {item.pullRequest.labels.map((lbl) => (
                          <span
                            key={lbl}
                            className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-900 border border-zinc-800 text-zinc-400 font-mono"
                          >
                            {lbl}
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-1 border-t border-zinc-900 text-[11px]">
                      <span className="text-[10px] text-zinc-500">
                        {item.pullRequest.mergedAt
                          ? `${th ? 'ผสานเมื่อ' : 'Merged'}: ${formatRelativeTime(item.pullRequest.mergedAt)}`
                          : `${th ? 'สถานะ' : 'State'}: ${item.pullRequest.state}`}
                      </span>
                      {item.pullRequest.htmlUrl && (
                        <a
                          href={item.pullRequest.htmlUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-amber-400 hover:text-amber-300 flex items-center gap-1 hover:underline"
                        >
                          <span>{th ? 'ดู Pull Request' : 'View PR'}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
