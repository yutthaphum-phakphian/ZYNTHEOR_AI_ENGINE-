import React, { useState, useEffect, useRef } from 'react';
import { AnimatePresence, LayoutGroup, motion } from 'framer-motion';
import {
  CheckSquare,
  Clock,
  DollarSign,
  Code,
  Plus,
  Trash2,
  Play,
  Pause,
  RotateCcw,
  Check,
  X,
  ExternalLink,
  RefreshCw,
  Sparkles,
  Archive,
} from 'lucide-react';
import { TodoItem, ExpenseItem, PomodoroMode } from '../types/agent';

interface ProductivityPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProductivityPanel: React.FC<ProductivityPanelProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'todo' | 'pomodoro' | 'expenses' | 'preview'>('todo');

  // --- TODO STATE ---
  const [todos, setTodos] = useState<TodoItem[]>(() => {
    const saved = localStorage.getItem('sraang_todos');
    return saved
      ? JSON.parse(saved)
      : [
          { id: '1', text: 'ออกแบบหน้าจอ ChatWorkspace v0.2', completed: true, createdAt: Date.now(), priority: 'high' },
          { id: '2', text: 'ทดสอบการลากวางไฟล์จาก Desktop', completed: true, createdAt: Date.now(), priority: 'medium' },
          { id: '3', text: 'ตรวจสอบไอคอนไฟล์ PDF/JS/TXT', completed: false, createdAt: Date.now(), priority: 'high' },
        ];
  });
  const [newTodoText, setNewTodoText] = useState('');
  const [todoFilter, setTodoFilter] = useState<'all' | 'pending' | 'completed' | 'archive'>('all');
  const [archivedTodos, setArchivedTodos] = useState<TodoItem[]>(() => {
    try {
      const saved = localStorage.getItem('sraang_archived_todos');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('sraang_todos', JSON.stringify(todos));
  }, [todos]);

  useEffect(() => {
    localStorage.setItem('sraang_archived_todos', JSON.stringify(archivedTodos));
  }, [archivedTodos]);

  const handleAddTodo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTodoText.trim()) return;
    const item: TodoItem = {
      id: `todo_${Date.now()}`,
      text: newTodoText.trim(),
      completed: false,
      createdAt: Date.now(),
      priority: 'medium',
    };
    setTodos([item, ...todos]);
    setNewTodoText('');
  };

  const handleToggleTodo = (id: string) => {
    setTodos(todos.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  };

  const handleDeleteTodo = (id: string) => {
    setTodos(todos.filter((t) => t.id !== id));
  };

  const handleArchiveTodo = (id: string) => {
    const todo = todos.find((item) => item.id === id);
    if (!todo?.completed) return;
    setTodos((previous) => previous.filter((item) => item.id !== id));
    setArchivedTodos((previous) => [todo, ...previous]);
  };

  const handleRestoreTodo = (id: string) => {
    const todo = archivedTodos.find((item) => item.id === id);
    if (!todo) return;
    setArchivedTodos((previous) => previous.filter((item) => item.id !== id));
    setTodos((previous) => [todo, ...previous]);
  };

  // --- POMODORO STATE ---
  const [pomodoroMode, setPomodoroMode] = useState<PomodoroMode>('work');
  const [workMinutes, setWorkMinutes] = useState(25);
  const [breakMinutes, setBreakMinutes] = useState(5);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [completedSessions, setCompletedSessions] = useState(0);

  useEffect(() => {
    let timer: any = null;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (isRunning && timeLeft === 0) {
      if (pomodoroMode === 'work') {
        setCompletedSessions((prev) => prev + 1);
        setPomodoroMode('shortBreak');
        setTimeLeft(breakMinutes * 60);
      } else {
        setPomodoroMode('work');
        setTimeLeft(workMinutes * 60);
      }
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft, pomodoroMode, breakMinutes, workMinutes]);

  const togglePomodoro = () => setIsRunning(!isRunning);

  const resetPomodoro = () => {
    setIsRunning(false);
    setTimeLeft(pomodoroMode === 'work' ? workMinutes * 60 : breakMinutes * 60);
  };

  const setMode = (mode: PomodoroMode) => {
    setIsRunning(false);
    setPomodoroMode(mode);
    setTimeLeft(mode === 'work' ? workMinutes * 60 : breakMinutes * 60);
  };

  // --- EXPENSE TRACKER STATE ---
  const [expenses, setExpenses] = useState<ExpenseItem[]>(() => {
    const saved = localStorage.getItem('sraang_expenses');
    return saved
      ? JSON.parse(saved)
      : [
          { id: '1', title: 'ค่าบริการ Cloud Run Server', amount: 350, category: 'software', date: '13 ต.ค.' },
          { id: '2', title: 'กาแฟอเมซอนขณะเขียนโค้ด', amount: 65, category: 'food', date: '13 ต.ค.' },
        ];
  });
  const [expTitle, setExpTitle] = useState('');
  const [expAmount, setExpAmount] = useState('');
  const [expCategory, setExpCategory] = useState<ExpenseItem['category']>('software');

  useEffect(() => {
    localStorage.setItem('sraang_expenses', JSON.stringify(expenses));
  }, [expenses]);

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(expAmount);
    if (!expTitle.trim() || isNaN(parsedAmount) || parsedAmount <= 0) return;

    const item: ExpenseItem = {
      id: `exp_${Date.now()}`,
      title: expTitle.trim(),
      amount: parsedAmount,
      category: expCategory,
      date: new Date().toLocaleDateString('th-TH', { day: 'numeric', month: 'short' }),
    };
    setExpenses([item, ...expenses]);
    setExpTitle('');
    setExpAmount('');
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(expenses.filter((e) => e.id !== id));
  };

  const totalExpenseAmount = expenses.reduce((sum, item) => sum + item.amount, 0);

  // --- STATIC PREVIEW (SANDBOXED) STATE ---
  const [htmlCode, setHtmlCode] = useState(
    `<!DOCTYPE html>\n<html>\n<head>\n  <style>\n    body { font-family: system-ui, sans-serif; padding: 24px; background: #0f172a; color: #f8fafc; text-align: center; }\n    .badge { display: inline-block; padding: 6px 14px; border-radius: 999px; background: #6366f1; color: white; font-weight: bold; font-size: 13px; }\n    h1 { margin-top: 16px; font-size: 22px; }\n    p { color: #94a3b8; font-size: 14px; line-height: 1.6; }\n  </style>\n</head>\n<body>\n  <span class="badge">Sandboxed Preview</span>\n  <h1>⚡ One Chat Workspace</h1>\n  <p>StaticPreview พร้อมระบบ Scoped Isolation และปลอดภัย 100%</p>\n</body>\n</html>`
  );
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);
  const [previewSrcDoc, setPreviewSrcDoc] = useState(htmlCode);

  const handleRefreshPreview = () => {
    setIsPreviewLoading(true);
    setTimeout(() => {
      setPreviewSrcDoc(htmlCode);
      setIsPreviewLoading(false);
    }, 400); // 400ms loading spinner per spec
  };

  if (!isOpen) return null;

  return (
    <aside className="w-88 sm:w-96 h-full border-l border-gray-200/80 dark:border-gray-800/80 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md flex flex-col shrink-0 z-30 transition-all select-none">
      {/* Top Header */}
      <div className="p-3.5 border-b border-gray-100 dark:border-gray-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-500" />
          <h3 className="text-xs font-bold text-gray-800 dark:text-gray-200 uppercase tracking-wider">
            ชุดเครื่องมือผลิตภาพ
          </h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="ปิดแถบเครื่องมือ"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 dark:border-gray-800/80 p-1.5 gap-1 bg-gray-50/70 dark:bg-gray-950/40">
        <button
          onClick={() => setActiveTab('todo')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'todo'
              ? 'bg-white dark:bg-gray-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
          }`}
        >
          <CheckSquare className="w-3.5 h-3.5" />
          <span>สิ่งที่ต้องทำ</span>
        </button>

        <button
          onClick={() => setActiveTab('pomodoro')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'pomodoro'
              ? 'bg-white dark:bg-gray-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Pomodoro</span>
        </button>

        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'expenses'
              ? 'bg-white dark:bg-gray-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>ค่าใช้จ่าย</span>
        </button>

        <button
          onClick={() => setActiveTab('preview')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'preview'
              ? 'bg-white dark:bg-gray-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
          }`}
        >
          <Code className="w-3.5 h-3.5" />
          <span>พรีวิวโค้ด</span>
        </button>
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-y-auto p-3">
        {/* TAB 1: TODO */}
        {activeTab === 'todo' && (
          <div className="space-y-3">
            <form onSubmit={handleAddTodo} className="flex gap-2">
              <input
                type="text"
                value={newTodoText}
                onChange={(e) => setNewTodoText(e.target.value)}
                placeholder="เพิ่มภารกิจใหม่..."
                className="flex-1 px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-xs text-gray-800 dark:text-gray-200 placeholder:text-gray-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
              />
              <button
                type="submit"
                className="p-2 rounded-xl bg-indigo-600 text-white text-xs hover:bg-indigo-700 transition-colors"
                title="เพิ่ม"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </form>

            <div className="flex items-center gap-1 text-[11px] text-gray-400">
              <button
                onClick={() => setTodoFilter('all')}
                className={`px-2 py-0.5 rounded-md ${todoFilter === 'all' ? 'bg-gray-200 dark:bg-gray-700 font-bold text-gray-800 dark:text-gray-200' : ''}`}
              >
                ทั้งหมด ({todos.length})
              </button>
              <button
                onClick={() => setTodoFilter('pending')}
                className={`px-2 py-0.5 rounded-md ${todoFilter === 'pending' ? 'bg-gray-200 dark:bg-gray-700 font-bold text-gray-800 dark:text-gray-200' : ''}`}
              >
                รอดำเนินการ ({todos.filter((t) => !t.completed).length})
              </button>
              <button
                onClick={() => setTodoFilter('completed')}
                className={`px-2 py-0.5 rounded-md ${todoFilter === 'completed' ? 'bg-gray-200 dark:bg-gray-700 font-bold text-gray-800 dark:text-gray-200' : ''}`}
              >
                เสร็จแล้ว ({todos.filter((t) => t.completed).length})
              </button>
              <button
                onClick={() => setTodoFilter('archive')}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md ${todoFilter === 'archive' ? 'bg-gray-200 dark:bg-gray-700 font-bold text-gray-800 dark:text-gray-200' : ''}`}
              >
                <Archive className="h-3 w-3" />
                Archive ({archivedTodos.length})
              </button>
            </div>

            <LayoutGroup>
              <div className="space-y-1.5">
                <AnimatePresence initial={false} mode="popLayout">
                  {(todoFilter === 'archive'
                    ? archivedTodos
                    : todos.filter((todo) =>
                        todoFilter === 'all' ||
                        (todoFilter === 'completed' ? todo.completed : !todo.completed)
                      )
                  ).map((todo) => (
                  <motion.div
                    layout
                    key={todo.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -16 }}
                    transition={{ duration: 0.18 }}
                    className="flex items-center gap-2 p-2 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-100 dark:border-gray-800 group"
                  >
                    <button
                      onClick={() => todoFilter === 'archive' ? handleRestoreTodo(todo.id) : handleToggleTodo(todo.id)}
                      className={`w-4 h-4 rounded-md border flex items-center justify-center transition-colors ${
                        todo.completed || todoFilter === 'archive'
                          ? 'bg-emerald-500 border-emerald-500 text-white'
                          : 'border-gray-300 dark:border-gray-600 hover:border-indigo-500'
                      }`}
                      title={todoFilter === 'archive' ? 'Restore task' : 'Toggle completion'}
                    >
                      {(todo.completed || todoFilter === 'archive') && <Check className="w-3 h-3" />}
                    </button>
                    <span
                      className={`text-xs flex-1 min-w-0 break-words ${
                        todo.completed || todoFilter === 'archive'
                          ? 'line-through text-gray-400 dark:text-gray-500'
                          : 'text-gray-700 dark:text-gray-200 font-medium'
                      }`}
                    >
                      {todo.text}
                    </span>
                    {todoFilter === 'archive' ? (
                      <button
                        onClick={() => handleRestoreTodo(todo.id)}
                        className="p-1 rounded text-gray-400 hover:text-indigo-500"
                        title="Restore task"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    ) : todo.completed ? (
                      <button
                        onClick={() => handleArchiveTodo(todo.id)}
                        className="p-1 rounded text-gray-400 hover:text-indigo-500"
                        title="Archive completed task"
                      >
                        <Archive className="w-3.5 h-3.5" />
                      </button>
                    ) : null}
                    <button
                      onClick={() => todoFilter === 'archive'
                        ? setArchivedTodos((previous) => previous.filter((item) => item.id !== todo.id))
                        : handleDeleteTodo(todo.id)}
                      className="p-1 rounded text-gray-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Delete task"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </LayoutGroup>
          </div>
        )}

        {/* TAB 2: POMODORO TIMER */}
        {activeTab === 'pomodoro' && (
          <div className="space-y-4 text-center py-2">
            <div className="flex justify-center gap-2">
              <button
                onClick={() => setMode('work')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  pomodoroMode === 'work'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                }`}
              >
                โฟกัส (25m)
              </button>
              <button
                onClick={() => setMode('shortBreak')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  pomodoroMode === 'shortBreak'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                }`}
              >
                พักสั้น (5m)
              </button>
            </div>

            {/* Circular Countdown Display */}
            <div className="relative w-44 h-44 mx-auto rounded-full border-4 border-indigo-100 dark:border-indigo-950 flex flex-col items-center justify-center bg-gray-50/50 dark:bg-gray-900/50 shadow-inner">
              <span className="text-4xl font-extrabold font-mono tracking-tight text-gray-900 dark:text-gray-100">
                {String(Math.floor(timeLeft / 60)).padStart(2, '0')}:
                {String(timeLeft % 60).padStart(2, '0')}
              </span>
              <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 mt-1 uppercase tracking-wider">
                {pomodoroMode === 'work' ? 'ช่วงทำงาน' : 'ช่วงพักผ่อน'}
              </span>
            </div>

            {/* Controls */}
            <div className="flex justify-center items-center gap-3">
              <button
                onClick={togglePomodoro}
                className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition-all"
              >
                {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isRunning ? 'หยุดชั่วคราว' : 'เริ่มจับเวลา'}</span>
              </button>

              <button
                onClick={resetPomodoro}
                className="p-2.5 rounded-2xl bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
                title="รีเซ็ตเวลา"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[11px] text-gray-400">
              สำเร็จแล้ว {completedSessions} รอบเซสชันในวันนี้ 🎉
            </p>
          </div>
        )}

        {/* TAB 3: EXPENSE TRACKER */}
        {activeTab === 'expenses' && (
          <div className="space-y-3">
            <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-100 dark:border-indigo-900/40 flex justify-between items-center">
              <div>
                <p className="text-[11px] text-indigo-700 dark:text-indigo-300 font-semibold">ยอดรวมค่าใช้จ่าย</p>
                <p className="text-xl font-extrabold text-indigo-900 dark:text-indigo-100">
                  ฿{totalExpenseAmount.toLocaleString()}
                </p>
              </div>
              <span className="text-xs px-2.5 py-1 rounded-lg bg-indigo-200/50 dark:bg-indigo-900/50 text-indigo-800 dark:text-indigo-200 font-bold">
                {expenses.length} รายการ
              </span>
            </div>

            <form onSubmit={handleAddExpense} className="space-y-2">
              <input
                type="text"
                value={expTitle}
                onChange={(e) => setExpTitle(e.target.value)}
                placeholder="ชื่อรายการ (เช่น ซื้อเซิร์ฟเวอร์, อาหาร)..."
                className="w-full px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-xs text-gray-800 dark:text-gray-200 placeholder:text-gray-400 focus:outline-hidden"
              />
              <div className="flex gap-2">
                <input
                  type="number"
                  value={expAmount}
                  onChange={(e) => setExpAmount(e.target.value)}
                  placeholder="จำนวนเงิน (บาท)"
                  className="w-1/2 px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-xs text-gray-800 dark:text-gray-200 placeholder:text-gray-400 focus:outline-hidden"
                />
                <select
                  value={expCategory}
                  onChange={(e) => setExpCategory(e.target.value as any)}
                  className="w-1/2 px-2.5 py-1.5 rounded-xl bg-gray-100 dark:bg-gray-800 text-xs text-gray-800 dark:text-gray-200 focus:outline-hidden"
                >
                  <option value="software">💻 ซอฟต์แวร์</option>
                  <option value="hardware">🎧 อุปกรณ์</option>
                  <option value="food">🍔 อาหาร/เครื่องดื่ม</option>
                  <option value="transport">🚗 เดินทาง</option>
                  <option value="other">📦 อื่นๆ</option>
                </select>
              </div>
              <button
                type="submit"
                className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors"
              >
                บันทึกค่าใช้จ่าย
              </button>
            </form>

            <div className="space-y-1.5 pt-2">
              {expenses.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-100 dark:border-gray-800"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-gray-800 dark:text-gray-200 truncate">
                      {item.title}
                    </p>
                    <p className="text-[10px] text-gray-400">
                      {item.category} • {item.date}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-gray-900 dark:text-gray-100">
                      ฿{item.amount.toLocaleString()}
                    </span>
                    <button
                      onClick={() => handleDeleteExpense(item.id)}
                      className="p-1 text-gray-400 hover:text-rose-500"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: STATIC PREVIEW (SANDBOXED) */}
        {activeTab === 'preview' && (
          <div className="space-y-2 h-full flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-gray-500 uppercase">
                HTML/CSS/JS Sandboxed Frame
              </span>
              <button
                onClick={handleRefreshPreview}
                className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100"
                title="รีเฟรชการแสดงผล (จำลองการโหลด 400ms)"
              >
                <RefreshCw className={`w-3 h-3 ${isPreviewLoading ? 'animate-spin' : ''}`} />
                <span>รันพรีวิว</span>
              </button>
            </div>

            <textarea
              value={htmlCode}
              onChange={(e) => setHtmlCode(e.target.value)}
              rows={4}
              className="w-full p-2 rounded-xl bg-gray-900 text-gray-100 font-mono text-[11px] focus:outline-hidden resize-none border border-gray-800"
              placeholder="เขียน HTML/CSS ตรงนี้..."
            />

            {/* Sandboxed iframe with 400ms spinner per spec */}
            <div className="relative flex-1 min-h-[200px] rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden bg-white">
              {isPreviewLoading && (
                <div className="absolute inset-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-xs flex items-center justify-center z-10">
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                    <span className="text-[10px] font-medium text-gray-500">
                      กำลังคอมไพล์ในแซนด์บ็อกซ์ (400ms)...
                    </span>
                  </div>
                </div>
              )}
              <iframe
                title="Static Sandbox Preview"
                srcDoc={previewSrcDoc}
                sandbox="allow-scripts"
                className="w-full h-full border-none"
              />
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
