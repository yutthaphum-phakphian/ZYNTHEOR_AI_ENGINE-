import { useState } from 'react'

/**
 * P11 OneChatWorkspace - Fullscreen unified workspace
 * Modes: Auto, Fast, Deep, Coding, Review, Custom
 * Local-only, no external provider
 */
export function OneChatWorkspace() {
  const [mode, setMode] = useState<'Auto'|'Fast'|'Deep'|'Coding'|'Review'|'Custom'>('Auto')
  const [isSandbox, setIsSandbox] = useState(true)

  return (
    <div className="flex h-screen bg-zinc-950 text-white">
      {/* Left: Assistant & Chat */}
      <div className="w-[35%] border-r border-zinc-800 p-4 flex flex-col">
        <div className="flex gap-2 mb-4">
          {(['Auto','Fast','Deep','Coding','Review','Custom'] as const).map(m => (
            <button key={m} onClick={()=>setMode(m)}
              className={`px-3 py-1 rounded-full text-xs ${mode===m ? 'bg-violet-600' : 'bg-zinc-800'}`}>
              {m}
            </button>
          ))}
        </div>
        <div className="flex-1 bg-zinc-900 rounded-xl p-3">
          <div className="text-xs text-zinc-400">One-Chat • {mode} • {isSandbox ? 'Sandbox ON' : 'Sandbox OFF'} • local-only</div>
          <div className="mt-4 text-sm">Assistant & Chat - Zero Phantom Execution</div>
        </div>
      </div>
      
      {/* Middle: Code & File Studio */}
      <div className="w-[40%] border-r border-zinc-800 p-4">
        <div className="text-xs text-zinc-400 mb-2">Code & File Studio • Diff • Proposals (Approval Gate)</div>
        <div className="bg-zinc-900 rounded-xl h-[90%] p-3 font-mono text-xs">Code Studio - P11 Mobile Sandbox</div>
      </div>
      
      {/* Right: Plans & Audit */}
      <div className="w-[25%] p-4 flex flex-col gap-4">
        <div className="bg-zinc-900 rounded-xl p-3 h-[45%]">
          <div className="text-xs text-zinc-400">Plans & Tasks • Step Progress</div>
        </div>
        <div className="bg-zinc-900 rounded-xl p-3 h-[45%]">
          <div className="text-xs text-zinc-400">Audit Ledger • SHA-256 • Correlation ID</div>
        </div>
        <div className="flex gap-2">
          <button onClick={()=>setIsSandbox(!isSandbox)} className="px-3 py-1 bg-zinc-800 rounded text-xs">
            {isSandbox ? 'Sandbox: ON' : 'Sandbox: OFF'}
          </button>
          <span className="text-[10px] text-emerald-400">local-only • v10.0-final base</span>
        </div>
      </div>
    </div>
  )
}
