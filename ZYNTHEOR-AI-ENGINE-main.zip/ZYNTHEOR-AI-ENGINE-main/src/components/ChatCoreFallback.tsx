import React from 'react';
import { Bot } from 'lucide-react';

/** CSS-only core (styles live in zyntheor-theme.css). Used while the 3D chunk loads, and when WebGL is unavailable. */
export const ChatCoreFallback: React.FC = () => (
  <div className="zy-ai-core-wrap" aria-hidden="true" data-testid="chat-core-fallback">
    <span className="zy-core-orbit zy-core-orbit-one" />
    <span className="zy-core-orbit zy-core-orbit-two" />
    <span className="zy-core-orbit zy-core-orbit-three" />
    <div className="zy-ai-core"><Bot className="w-8 h-8 text-cyan-100" /></div>
    <span className="zy-core-spark zy-core-spark-a" />
    <span className="zy-core-spark zy-core-spark-b" />
  </div>
);

export default ChatCoreFallback;
