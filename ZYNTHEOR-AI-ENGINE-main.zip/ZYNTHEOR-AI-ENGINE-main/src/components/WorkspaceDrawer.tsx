import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { notify } from '../utils/notify';
import {
  Plus,
  Search,
  MessageSquare,
  Trash2,
  Pin,
  Download,
  Upload,
  Keyboard,
  Sparkles,
  Layers,
  Bot,
  FolderOpen,
  Code,
  Globe,
  ListChecks,
  ShieldCheck,
  Brain,
  Settings,
  X,
  Cloud,
  GripVertical,
  Tag,
  Calendar,
  Filter,
  Archive,
  ArchiveRestore,
  Pencil,
  Check,
} from 'lucide-react';
import { ChatSession, MissionCategory } from '../types/agent';
import { isSessionWithinDateRange, DateRangePreset } from '../utils/newFeatureLogic';

export type WorkspaceViewId = 'assistant' | 'code' | 'preview' | 'tasks' | 'audit' | 'memory' | 'settings';

interface WorkspaceDrawerProps {
  currentView: WorkspaceViewId;
  onSelectView: (view: WorkspaceViewId) => void;
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: (category?: MissionCategory) => void;
  onDeleteSession: (id: string) => void;
  onPinSession: (id: string) => void;
  onArchiveSession?: (id: string) => void;
  onRenameSession?: (id: string, newTitle: string) => void;
  onImportSessions: (sessions: ChatSession[]) => void;
  isOpen: boolean;
  onClose: () => void;
  onOpenShortcutsModal: () => void;
  lang?: 'en' | 'th';
  onReorderSessions?: (sessions: ChatSession[]) => void;
  onSyncToCloud?: () => Promise<boolean>;
  isSyncing?: boolean;
  lastSyncedAt?: string | null;
  onUpdateSessionTags?: (sessionId: string, tags: string[]) => void;
}


const CATEGORY_COLORS: Record<MissionCategory, { dot: string; label: string }> = {
  development: { dot: 'bg-blue-500 ring-blue-300 dark:ring-blue-900', label: 'Development' },
  research: { dot: 'bg-amber-500 ring-amber-300 dark:ring-amber-900', label: 'Research' },
  content: { dot: 'bg-amber-500 ring-amber-300 dark:ring-amber-900', label: 'Content' },
  data: { dot: 'bg-emerald-500 ring-emerald-300 dark:ring-emerald-900', label: 'Data' },
  general: { dot: 'bg-slate-400 ring-slate-200 dark:ring-slate-700', label: 'General' },
};

export const WorkspaceDrawer: React.FC<WorkspaceDrawerProps> = ({
  currentView,
  onSelectView,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onPinSession,
  onImportSessions,
  isOpen,
  onClose,
  onOpenShortcutsModal,
  lang = 'th',
  onReorderSessions,
  onSyncToCloud,
  isSyncing = false,
  lastSyncedAt,
  onUpdateSessionTags,
  onArchiveSession,
  onRenameSession,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [editingTagSessionId, setEditingTagSessionId] = useState<string | null>(null);
  const [newTagInput, setNewTagInput] = useState('');
  const tagInputRef = useRef<HTMLInputElement>(null);
  const [renamingSessionId, setRenamingSessionId] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');
  const renameInputRef = useRef<HTMLInputElement>(null);
  const [dateRangePreset, setDateRangePreset] = useState<DateRangePreset>('all');
  const [customDateFrom, setCustomDateFrom] = useState<string>('');
  const [customDateTo, setCustomDateTo] = useState<string>('');
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [focusedIndex, setFocusedIndex] = useState<number>(-1);
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const sessionItemRefs = useRef<(HTMLDivElement | null)[]>([]);
  const sessionsListRef = useRef<HTMLDivElement>(null);

  // Focus inline tag input when opened
  useEffect(() => {
    if (editingTagSessionId && tagInputRef.current) {
      tagInputRef.current.focus();
    }
  }, [editingTagSessionId]);

  // Focus inline rename input when opened
  useEffect(() => {
    if (renamingSessionId && renameInputRef.current) {
      renameInputRef.current.focus();
      renameInputRef.current.select();
    }
  }, [renamingSessionId]);

  const handleStartRename = (id: string, currentTitle: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setRenamingSessionId(id);
    setRenameDraft(currentTitle);
  };

  const handleSaveRename = (id: string, e?: React.FormEvent | React.MouseEvent) => {
    e?.stopPropagation();
    const trimmed = renameDraft.trim();
    if (trimmed) {
      if (onRenameSession) {
        onRenameSession(id, trimmed);
      } else {
        const target = sessions.find((s) => s.id === id);
        if (target) {
          target.title = trimmed;
          target.customTitle = true;
          try {
            localStorage.setItem(`zyntheor.sessionTitle.${id}`, trimmed);
          } catch {}
        }
      }
    }
    setRenamingSessionId(null);
  };

  const handleCancelRename = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setRenamingSessionId(null);
  };

  // Collect all unique tags across all sessions
  const allAvailableTags = useMemo(() => {
    const tagSet = new Set<string>();
    sessions.forEach((s) => {
      (s.tags || []).forEach((t) => {
        const clean = t.trim();
        if (clean) tagSet.add(clean);
      });
    });
    return Array.from(tagSet).sort();
  }, [sessions]);

  // Add custom tag handler
  const handleAddTagSubmit = useCallback(
    (sessionId: string) => {
      const clean = newTagInput.trim().replace(/^#+/, '');
      if (!clean || !onUpdateSessionTags) return;
      const target = sessions.find((s) => s.id === sessionId);
      if (!target) return;
      const existing = target.tags || [];
      if (!existing.includes(clean)) {
        onUpdateSessionTags(sessionId, [...existing, clean]);
      }
      setNewTagInput('');
      setEditingTagSessionId(null);
    },
    [newTagInput, onUpdateSessionTags, sessions]
  );

  // Drag and drop handlers for session reordering
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, id: string) => {
    e.dataTransfer.setData('text/plain', id);
    e.dataTransfer.effectAllowed = 'move';
    setDraggedId(id);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>, id: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverId !== id) {
      setDragOverId(id);
    }
  };

  const handleDragLeave = () => {
    setDragOverId(null);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, targetId: string) => {
    e.preventDefault();
    const sourceId = e.dataTransfer.getData('text/plain') || draggedId;
    setDraggedId(null);
    setDragOverId(null);
    if (!sourceId || sourceId === targetId || !onReorderSessions) return;

    const sourceIndex = sessions.findIndex((s) => s.id === sourceId);
    const targetIndex = sessions.findIndex((s) => s.id === targetId);
    if (sourceIndex === -1 || targetIndex === -1) return;

    const next = [...sessions];
    const [removed] = next.splice(sourceIndex, 1);
    next.splice(targetIndex, 0, removed);
    onReorderSessions(next);
  };

  const handleDragEnd = () => {
    setDraggedId(null);
    setDragOverId(null);
  };

  const handleTriggerCloudSync = async () => {
    if (!onSyncToCloud || isSyncing) return;
    setSyncFeedback(lang === 'th' ? 'กำลังซิงค์…' : 'Syncing…');
    const success = await onSyncToCloud();
    if (success) {
      setSyncFeedback(lang === 'th' ? 'ซิงค์สำเร็จ!' : 'Synced!');
      setTimeout(() => setSyncFeedback(null), 3000);
    } else {
      setSyncFeedback(lang === 'th' ? 'ซิงค์ล้มเหลว' : 'Sync failed');
      setTimeout(() => setSyncFeedback(null), 3000);
    }
  };

  // Filter sessions based on search, category, custom tags, creation date ranges, and archive status
  const filteredSessions = useMemo(() => {
    return sessions.filter((session) => {
      // 0. Archive filter: show archived sessions only when showArchived is true, otherwise show active sessions
      const matchesArchive = showArchived ? Boolean(session.archived) : !session.archived;
      if (!matchesArchive) return false;

      // 1. Custom tag matching
      const matchesTag = !selectedTag || (session.tags && session.tags.includes(selectedTag));
      if (!matchesTag) return false;

      // 2. Creation Date range matching
      const matchesDate = isSessionWithinDateRange(
        session.createdAt,
        dateRangePreset,
        customDateFrom,
        customDateTo
      );
      if (!matchesDate) return false;

      // 3. Category matching
      const matchesCat =
        selectedCategory === 'all' || session.category === selectedCategory;
      if (!matchesCat) return false;

      // 4. Keyword search (matches session title, summary, custom tags, or message contents)
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;

      const inTitle = session.title.toLowerCase().includes(q);
      const inSummary = Boolean(session.summary && session.summary.toLowerCase().includes(q));
      const inTags = Boolean(session.tags && session.tags.some((t) => t.toLowerCase().includes(q)));
      const inMessages = Boolean(session.messages && session.messages.some((m) =>
        m.content.toLowerCase().includes(q)
      ));

      return inTitle || inSummary || inTags || inMessages;
    });
  }, [sessions, searchQuery, selectedCategory, selectedTag, dateRangePreset, customDateFrom, customDateTo, showArchived]);


  // Sync focused index with active session or clamp when filtered list changes
  useEffect(() => {
    const activeIdx = filteredSessions.findIndex((s) => s.id === activeSessionId);
    if (activeIdx !== -1) {
      setFocusedIndex(activeIdx);
    } else if (filteredSessions.length > 0) {
      setFocusedIndex((prev) => (prev >= 0 && prev < filteredSessions.length ? prev : 0));
    } else {
      setFocusedIndex(-1);
    }
  }, [activeSessionId, filteredSessions]);

  // Select and open session in Assistant view
  const handleSelectAndOpen = useCallback(
    (session: ChatSession) => {
      onSelectView('assistant');
      onSelectSession(session.id);
    },
    [onSelectView, onSelectSession]
  );

  // Key navigation from search input: ArrowDown moves into the session list
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      if (filteredSessions.length > 0) {
        e.preventDefault();
        const targetIdx = 0;
        setFocusedIndex(targetIdx);
        sessionItemRefs.current[targetIdx]?.focus();
        sessionItemRefs.current[targetIdx]?.scrollIntoView({ block: 'nearest' });
      }
    } else if (e.key === 'Enter') {
      if (filteredSessions.length > 0) {
        e.preventDefault();
        const target =
          focusedIndex >= 0 && focusedIndex < filteredSessions.length
            ? filteredSessions[focusedIndex]
            : filteredSessions[0];
        handleSelectAndOpen(target);
      }
    }
  };

  // Arrow key navigation between session items
  const handleSessionKeyDown = (
    e: React.KeyboardEvent<HTMLDivElement>,
    index: number,
    session: ChatSession
  ) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      const nextIdx = index < filteredSessions.length - 1 ? index + 1 : 0;
      setFocusedIndex(nextIdx);
      sessionItemRefs.current[nextIdx]?.focus();
      sessionItemRefs.current[nextIdx]?.scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (index > 0) {
        const prevIdx = index - 1;
        setFocusedIndex(prevIdx);
        sessionItemRefs.current[prevIdx]?.focus();
        sessionItemRefs.current[prevIdx]?.scrollIntoView({ block: 'nearest' });
      } else {
        // Return focus to search input when navigating up from the first session
        setFocusedIndex(-1);
        searchInputRef.current?.focus();
      }
    } else if (e.key === 'Home') {
      e.preventDefault();
      if (filteredSessions.length > 0) {
        setFocusedIndex(0);
        sessionItemRefs.current[0]?.focus();
        sessionItemRefs.current[0]?.scrollIntoView({ block: 'nearest' });
      }
    } else if (e.key === 'End') {
      e.preventDefault();
      if (filteredSessions.length > 0) {
        const lastIdx = filteredSessions.length - 1;
        setFocusedIndex(lastIdx);
        sessionItemRefs.current[lastIdx]?.focus();
        sessionItemRefs.current[lastIdx]?.scrollIntoView({ block: 'nearest' });
      }
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleSelectAndOpen(session);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setFocusedIndex(-1);
      searchInputRef.current?.focus();
    }
  };

  // Export all sessions to JSON
  const handleExportAll = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(sessions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `zyntheor_workspace_backup_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Import sessions from JSON file
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportSessions(parsed);
          notify(lang === 'th' ? `นำเข้าสำเร็จ ${parsed.length} เซสชัน` : `Imported ${parsed.length} sessions`, 'success');
        } else if (parsed && parsed.id) {
          onImportSessions([parsed]);
          notify(lang === 'th' ? 'นำเข้าสำเร็จ 1 เซสชัน' : 'Imported 1 session', 'success');
        }
      } catch (err) {
        notify(lang === 'th' ? 'ไฟล์ JSON ไม่ถูกต้อง' : 'Invalid JSON file', 'error');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  if (!isOpen) return null;

  const navItems = [
    {
      id: 'assistant' as const,
      icon: MessageSquare,
      labelEn: 'Assistant & Chat',
      labelTh: 'ผู้ช่วยแชทอัจฉริยะ',
    },
    {
      id: 'code' as const,
      icon: Code,
      labelEn: 'Code & File Studio',
      labelTh: 'สตูดิโอโค้ด & ตรวจไฟล์',
    },
    {
      id: 'preview' as const,
      icon: Globe,
      labelEn: 'Live Preview & Web Studio',
      labelTh: 'ไลฟ์พรีวิว & เว็บสตูดิโอ',
    },
    {
      id: 'tasks' as const,
      icon: ListChecks,
      labelEn: 'Plans & Tasks',
      labelTh: 'แผนงาน & ภารกิจ (Plans)',
    },
    {
      id: 'audit' as const,
      icon: ShieldCheck,
      labelEn: 'Audit & Ledger',
      labelTh: 'สมุดบันทึกตรวจสอบ (Audit)',
    },
    {
      id: 'memory' as const,
      icon: Brain,
      labelEn: 'Memory Insight',
      labelTh: 'ภาพรวมความจำ (Memory)',
    },
    {
      id: 'settings' as const,
      icon: Settings,
      labelEn: 'System Settings',
      labelTh: 'การตั้งค่าระบบ (Settings)',
    },
  ];

  return (
    <aside
      id="sidebar"
      className="w-72 sm:w-80 h-full border-r border-zinc-800/80 bg-zinc-950/95 dark:bg-zinc-950 text-zinc-100 flex flex-col shrink-0 z-30 transition-all select-none overflow-y-auto"
      aria-label="Zyntheor Navigation"
    >
      {/* Brand Header */}
      <div className="p-4 border-b border-zinc-800/80 space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-950 to-blue-900 border border-cyan-500/30 shadow-md shadow-cyan-500/10 flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm font-bold text-zinc-100 tracking-tight">
                  Zyntheor
                </h1>
                <span className="text-[10px] text-zinc-500 font-mono">v1.0</span>
              </div>
              <p className="text-[11px] text-zinc-400 font-medium truncate">
                AI Engineering Studio
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={onOpenShortcutsModal}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/70 transition-colors"
              title="ดูปุ่มลัดแป้นพิมพ์ทั้งหมด (Ctrl+/)"
              aria-label="Keyboard shortcuts"
            >
              <Keyboard className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/70 transition-colors sm:hidden"
              title="Close sidebar"
              aria-label="Close sidebar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* View Navigation Modules */}
        <div className="space-y-1">
          <div className="text-[10px] uppercase font-mono font-medium text-zinc-500 tracking-wider px-1">
            {lang === 'th' ? 'โมดูลการทำงาน' : 'WORKSPACE MODULES'}
          </div>
          <nav className="space-y-0.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectView(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-blue-600/15 text-blue-300 border border-blue-500/30 shadow-xs'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60 border border-transparent'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-400' : 'text-zinc-500'}`} />
                  <span className="truncate">{lang === 'th' ? item.labelTh : item.labelEn}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Sessions Section */}
      <div id="sidebar-sessions-section" className="flex-1 flex flex-col min-h-0 border-b border-zinc-800/80">
        <div className="p-3 border-b border-zinc-850 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-mono font-semibold text-zinc-500 tracking-wider">
                {lang === 'th' ? 'เซสชันที่บันทึกไว้' : 'SAVED SESSIONS'}
              </span>
              <span
                className="text-[9px] font-mono text-zinc-400 bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800/80"
                title="Use ↑ and ↓ arrow keys to navigate, Enter to open session"
              >
                ↑↓ Nav • ↵ Open
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              {onSyncToCloud && (
                <button
                  type="button"
                  id="cloud-sync-btn"
                  onClick={handleTriggerCloudSync}
                  disabled={isSyncing}
                  className="px-2.5 py-1 rounded-md bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-[11px] font-medium transition-colors flex items-center gap-1.5 disabled:opacity-50"
                  title={lastSyncedAt ? `Last synced: ${new Date(lastSyncedAt).toLocaleTimeString()}` : 'Sync sessions to Cloud'}
                  aria-label="Sync sessions to cloud storage"
                >
                  <Cloud className={`w-3.5 h-3.5 ${isSyncing ? 'animate-pulse text-blue-400' : 'text-zinc-400'}`} />
                  <span>{syncFeedback || (lang === 'th' ? 'ซิงค์' : 'Sync')}</span>
                </button>
              )}
              <button
                type="button"
                id="new-session-mini-btn"
                onClick={() => {
                  onSelectView('assistant');
                  onNewSession('development');
                }}
                className="px-2.5 py-1 rounded-md bg-blue-600 hover:bg-blue-500 text-white font-medium text-[11px] shadow-sm transition-colors flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>{lang === 'th' ? 'เซสชันใหม่' : 'New'}</span>
              </button>
            </div>
          </div>

          {/* Search Input for sessions */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              ref={searchInputRef}
              type="search"
              id="session-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              placeholder={lang === 'th' ? 'ค้นหาเซสชัน... (↓ เพื่อเลือก)' : 'Search sessions... (↓ to select)'}
              aria-label={lang === 'th' ? 'ค้นหาเซสชัน' : 'Search sessions'}
              className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-zinc-900/90 border border-zinc-800 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-blue-500/80 transition-colors"
            />
          </div>

          {/* Active / Archive Toggle Tabs */}
          <div className="flex items-center gap-1 bg-zinc-900/90 p-0.5 rounded-lg border border-zinc-800 text-[10px]">
            <button
              type="button"
              onClick={() => setShowArchived(false)}
              className={`flex-1 py-1 rounded font-medium transition-colors text-center ${
                !showArchived
                  ? 'bg-blue-600/20 text-blue-300 font-semibold border border-blue-500/40 shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {lang === 'th' ? `ใช้งานอยู่ (${sessions.filter((s) => !s.archived).length})` : `Active (${sessions.filter((s) => !s.archived).length})`}
            </button>
            <button
              type="button"
              onClick={() => setShowArchived(true)}
              className={`flex-1 py-1 rounded font-medium transition-colors flex items-center justify-center gap-1 text-center ${
                showArchived
                  ? 'bg-amber-600/20 text-amber-300 font-semibold border border-amber-500/40 shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title={lang === 'th' ? 'ดูเซสชันที่เก็บถาวร' : 'View archived sessions'}
            >
              <Archive className="w-3 h-3" />
              <span>{lang === 'th' ? `เก็บถาวร (${sessions.filter((s) => s.archived).length})` : `Archived (${sessions.filter((s) => s.archived).length})`}</span>
            </button>
          </div>


          {/* Custom Labels / Tags Filter Bar */}
          {allAvailableTags.length > 0 && (
            <div className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
              <span className="text-[10px] text-zinc-500 font-mono shrink-0 flex items-center gap-0.5">
                <Tag className="w-2.5 h-2.5" />
              </span>
              <button
                type="button"
                onClick={() => setSelectedTag(null)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors shrink-0 ${
                  selectedTag === null
                    ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40 font-semibold'
                    : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
                }`}
              >
                All
              </button>
              {allAvailableTags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors shrink-0 flex items-center gap-0.5 ${
                    selectedTag === tag
                      ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40 font-semibold'
                      : 'bg-zinc-900 text-zinc-400 hover:text-blue-300 border border-zinc-800'
                  }`}
                  title={`Filter sessions with #${tag}`}
                >
                  <span>#{tag}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Saved Sessions List with Drag & Drop Reordering */}
        <div
          ref={sessionsListRef}
          id="saved-sessions-list"
          className="flex-1 overflow-y-auto p-2 space-y-1.5 focus:outline-none"
          role="listbox"
          aria-label={lang === 'th' ? 'รายการเซสชันที่บันทึกไว้' : 'Saved sessions list'}
        >
          {filteredSessions.length === 0 ? (
            <div className="text-center py-6 px-3 text-xs text-zinc-500">
              {searchQuery || selectedTag ? 'ไม่พบเซสชันที่ค้นหา' : 'ยังไม่มีเซสชันที่บันทึก'}
            </div>
          ) : (
            filteredSessions.map((session, index) => {
              const isActive = session.id === activeSessionId && currentView === 'assistant';
              const isKeyboardFocused = focusedIndex === index;
              const isDragging = draggedId === session.id;
              const isDragOver = dragOverId === session.id;
              const isRenaming = renamingSessionId === session.id;
              const categoryMeta = CATEGORY_COLORS[session.category] || CATEGORY_COLORS.general;

              return (
                <div
                  key={session.id}
                  ref={(el) => {
                    sessionItemRefs.current[index] = el;
                  }}
                  role="option"
                  tabIndex={0}
                  draggable={!isRenaming}
                  onDragStart={(e) => handleDragStart(e, session.id)}
                  onDragOver={(e) => handleDragOver(e, session.id)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, session.id)}
                  onDragEnd={handleDragEnd}
                  aria-selected={isActive}
                  aria-label={`Session: ${session.title}`}
                  onClick={() => {
                    if (!isRenaming) {
                      setFocusedIndex(index);
                      handleSelectAndOpen(session);
                    }
                  }}
                  onKeyDown={(e) => {
                    if (!isRenaming) {
                      handleSessionKeyDown(e, index, session);
                    }
                  }}
                  onFocus={() => setFocusedIndex(index)}
                  className={`group relative flex flex-col p-2.5 rounded-lg cursor-pointer transition-all outline-none select-none ${
                    isDragging
                      ? 'opacity-40 border border-dashed border-blue-500 bg-zinc-900/60'
                      : isDragOver
                      ? 'border border-blue-400 bg-blue-950/20'
                      : isActive
                      ? 'bg-zinc-850 text-zinc-100 border border-blue-500/40 shadow-xs'
                      : isKeyboardFocused
                      ? 'bg-zinc-800/60 text-zinc-100 border border-zinc-700'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/70 border border-transparent'
                  } focus-visible:ring-1 focus-visible:ring-blue-400`}
                >
                  <div className="flex items-center justify-between gap-1.5 w-full">
                    {isRenaming ? (
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleSaveRename(session.id, e);
                        }}
                        onClick={(e) => e.stopPropagation()}
                        className="flex items-center gap-1.5 flex-1 min-w-0"
                      >
                        <input
                          ref={renameInputRef}
                          type="text"
                          value={renameDraft}
                          onChange={(e) => setRenameDraft(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Escape') {
                              e.preventDefault();
                              handleCancelRename(e as any);
                            }
                          }}
                          placeholder={lang === 'th' ? 'ชื่อเซสชันใหม่...' : 'New session title...'}
                          aria-label={lang === 'th' ? 'เปลี่ยนชื่อเซสชัน' : 'Rename session'}
                          className="w-full px-2 py-0.5 text-xs bg-zinc-950 border border-blue-500 rounded text-zinc-100 focus:outline-none focus:ring-1 focus:ring-blue-400"
                        />
                        <button
                          type="submit"
                          className="p-1 rounded bg-blue-600 hover:bg-blue-500 text-white transition-colors cursor-pointer shrink-0"
                          title={lang === 'th' ? 'บันทึกชื่อเซสชัน' : 'Save session title'}
                          aria-label={lang === 'th' ? 'บันทึกชื่อเซสชัน' : 'Save session title'}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={handleCancelRename}
                          className="p-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors cursor-pointer shrink-0"
                          title={lang === 'th' ? 'ยกเลิกการเปลี่ยนชื่อ' : 'Cancel rename'}
                          aria-label={lang === 'th' ? 'ยกเลิกการเปลี่ยนชื่อ' : 'Cancel rename'}
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </form>
                    ) : (
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        {/* Drag Handle */}
                        <span
                          className="cursor-grab active:cursor-grabbing text-zinc-600 hover:text-zinc-300 opacity-0 group-hover:opacity-100 transition-opacity p-0.5 shrink-0"
                          title="Drag to reorder session"
                        >
                          <GripVertical className="w-3.5 h-3.5" />
                        </span>
                        <p
                          className="text-xs font-semibold truncate text-zinc-200 group-hover:text-blue-300 transition-colors flex-1"
                          onDoubleClick={(e) => handleStartRename(session.id, session.title, e)}
                          title={lang === 'th' ? 'ดับเบิลคลิกเพื่อเปลี่ยนชื่อ' : 'Double-click to rename'}
                        >
                          {session.title}
                        </p>
                        {session.customTitle && (
                          <span
                            className="px-1 py-0.2 rounded bg-blue-950/80 text-blue-300 border border-blue-500/30 text-[9px] font-mono shrink-0"
                            title={lang === 'th' ? 'ชื่อที่กำหนดเอง' : 'Custom name'}
                          >
                            {lang === 'th' ? 'กำหนดเอง' : 'Custom'}
                          </span>
                        )}
                      </div>
                    )}

                    {/* Actions */}
                    {!isRenaming && (
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity shrink-0">
                        <button
                          type="button"
                          onClick={(e) => handleStartRename(session.id, session.title, e)}
                          className="p-1 rounded text-zinc-500 hover:text-blue-300 hover:bg-zinc-700 cursor-pointer"
                          title={lang === 'th' ? 'เปลี่ยนชื่อเซสชัน' : 'Rename session'}
                          aria-label={lang === 'th' ? 'เปลี่ยนชื่อเซสชัน' : 'Rename session'}
                        >
                          <Pencil className="w-3 h-3" />
                        </button>
                        {onUpdateSessionTags && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingTagSessionId((prev) => (prev === session.id ? null : session.id));
                              setNewTagInput('');
                            }}
                            className="p-1 rounded text-zinc-500 hover:text-cyan-300 hover:bg-zinc-700"
                            title="Add or edit tags"
                            aria-label="Add or edit tags"
                          >
                            <Tag className="w-3 h-3" />
                          </button>
                        )}
                        {onArchiveSession && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onArchiveSession(session.id);
                            }}
                            className={`p-1 rounded hover:bg-zinc-700 ${
                              session.archived ? 'text-amber-400 opacity-100' : 'text-zinc-500 hover:text-amber-300'
                            }`}
                            title={session.archived ? (lang === 'th' ? 'นำออกจากคลังเก็บถาวร' : 'Restore from archive') : (lang === 'th' ? 'เก็บถาวร (Archive)' : 'Archive session')}
                            aria-label={session.archived ? 'Unarchive session' : 'Archive session'}
                          >
                            {session.archived ? <ArchiveRestore className="w-3 h-3" /> : <Archive className="w-3 h-3" />}
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onPinSession(session.id);
                          }}
                          className={`p-1 rounded hover:bg-zinc-700 ${
                            session.pinned ? 'text-amber-400 opacity-100' : 'text-zinc-500'
                          }`}
                          title="Pin session"
                          aria-label="Pin session"
                        >
                          <Pin className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm('Delete this session?')) {
                              onDeleteSession(session.id);
                            }
                          }}
                          className="p-1 rounded text-zinc-500 hover:text-rose-400"
                          title="Delete session"
                          aria-label="Delete session"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Brief Session Summary for Better Identification */}
                  <div className="mt-1 pl-6 pr-1 flex items-baseline justify-between gap-2">
                    <p className="text-[11px] text-zinc-400 truncate line-clamp-1 flex-1 leading-snug">
                      {session.archived && (
                        <span className="mr-1.5 px-1 py-0.2 rounded bg-amber-950/80 text-amber-300 border border-amber-500/40 font-mono text-[9px] font-semibold">
                          ARCHIVED
                        </span>
                      )}
                      {session.summary || 'พร้อมสำหรับคำสั่งและแผนงาน'}
                    </p>

                    <span className="text-[9px] text-zinc-500 font-mono shrink-0">
                      {new Date(session.updatedAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  {/* Custom Labels / Tags and Inline Tag Input */}
                  <div className="mt-1.5 pl-6 pr-1 flex flex-wrap items-center gap-1">
                    {(session.tags || []).map((tag) => (
                      <span
                        key={tag}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedTag((prev) => (prev === tag ? null : tag));
                        }}
                        className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors ${
                          selectedTag === tag
                            ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/50'
                            : 'bg-zinc-800 text-zinc-300 border border-zinc-700 hover:border-cyan-500/50'
                        }`}
                        title={`Filter by tag #${tag}`}
                      >
                        <span>#{tag}</span>
                        {onUpdateSessionTags && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              const nextTags = (session.tags || []).filter((t) => t !== tag);
                              onUpdateSessionTags(session.id, nextTags);
                            }}
                            className="hover:text-rose-400 p-0.5 text-zinc-400 transition-colors"
                            title="Remove tag"
                            aria-label={`Remove tag ${tag}`}
                          >
                            <X className="w-2.5 h-2.5" />
                          </button>
                        )}
                      </span>
                    ))}

                    {/* Inline Tag Input Form */}
                    {onUpdateSessionTags && editingTagSessionId === session.id && (
                      <div
                        className="inline-flex items-center gap-1 bg-zinc-900 border border-cyan-500/80 rounded px-1.5 py-0.5 shadow-sm"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <span className="text-[10px] text-zinc-500 font-mono">#</span>
                        <input
                          ref={tagInputRef}
                          type="text"
                          value={newTagInput}
                          onChange={(e) => setNewTagInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleAddTagSubmit(session.id);
                            } else if (e.key === 'Escape') {
                              setEditingTagSessionId(null);
                              setNewTagInput('');
                            }
                          }}
                          placeholder={lang === 'th' ? 'พิมพ์ป้าย...' : 'label...'}
                          className="w-16 bg-transparent text-[10px] font-mono text-cyan-200 placeholder:text-zinc-600 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => handleAddTagSubmit(session.id)}
                          className="text-[10px] text-cyan-400 font-bold hover:text-cyan-300 px-0.5"
                          title="Save tag"
                        >
                          +
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingTagSessionId(null);
                            setNewTagInput('');
                          }}
                          className="text-[9px] text-zinc-500 hover:text-zinc-300 px-0.5"
                          title="Cancel"
                        >
                          ✕
                        </button>
                      </div>
                    )}

                    {onUpdateSessionTags && editingTagSessionId !== session.id && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingTagSessionId(session.id);
                          setNewTagInput('');
                        }}
                        className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-mono text-zinc-500 hover:text-cyan-300 hover:bg-zinc-800 border border-dashed border-zinc-700/60 transition-colors ${
                          session.tags && session.tags.length > 0
                            ? 'opacity-60 hover:opacity-100'
                            : 'opacity-0 group-hover:opacity-100 group-focus-within:opacity-100'
                        }`}
                        title="Add custom tag"
                      >
                        <Tag className="w-2.5 h-2.5" />
                        <span>+ Tag</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Active Session & Server Utility Footer */}
      <div className="p-3 border-t border-zinc-800/80 bg-zinc-950/80 space-y-2 text-xs">
        <div className="flex items-center justify-between text-zinc-400 font-mono text-[11px]">
          <span className="text-zinc-300 font-medium">Local Engine</span>
          <span className="text-zinc-500">Node v22 · Port 3000</span>
        </div>

        <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1.5 border-t border-zinc-900">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImportFile}
            accept=".json"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="hover:text-zinc-200 transition-colors flex items-center gap-1.5 py-1 px-2 rounded-md hover:bg-zinc-900"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import</span>
          </button>
          <button
            type="button"
            onClick={handleExportAll}
            className="hover:text-zinc-200 transition-colors flex items-center gap-1.5 py-1 px-2 rounded-md hover:bg-zinc-900"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Backup</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
