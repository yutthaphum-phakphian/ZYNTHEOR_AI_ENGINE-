import React, { useState, useRef, useEffect } from 'react';
import { notify } from '../utils/notify';
import {
  Send,
  Square,
  RefreshCw,
  FolderGit2,
  ShieldCheck,
  Cpu,
  Trash2,
  Plus,
  MessageSquare,
  Edit2,
  Check,
  AlertCircle,
  HelpCircle,
  Sparkles,
  Server
} from 'lucide-react';
import { ChatSession, ChatMessage } from '../types';
import { sendChatMessage, fetchProviders } from '../services/api';

interface ChatModeProps {
  onOpenWorkspaceInspector: () => void;
  onOpenAuditReport: () => void;
  onOpenRuntimeModal: () => void;
  onLedgerUpdated?: () => void;
  localEndpoint: string;
}

export const ChatMode: React.FC<ChatModeProps> = ({
  onOpenWorkspaceInspector,
  onOpenAuditReport,
  onOpenRuntimeModal,
  onLedgerUpdated,
  localEndpoint
}) => {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('syntheor_chat_sessions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return [
      {
        id: 'default-session',
        title: 'เซสชันเริ่มต้น (Default)',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: []
      }
    ];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(sessions[0]?.id || 'default-session');
  const [inputPrompt, setInputPrompt] = useState('');
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [editingTitleId, setEditingTitleId] = useState<string | null>(null);
  const [editingTitleText, setEditingTitleText] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Save sessions to localStorage
  useEffect(() => {
    localStorage.setItem('syntheor_chat_sessions', JSON.stringify(sessions));
  }, [sessions]);

  // Scroll to bottom on message updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [sessions, activeSessionId, isProcessing]);

  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0];

  const handleNewSession = () => {
    const newSession: ChatSession = {
      id: 'session-' + Date.now(),
      title: 'บทสนทนาใหม่ ' + (sessions.length + 1),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: []
    };
    setSessions([newSession, ...sessions]);
    setActiveSessionId(newSession.id);
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (sessions.length <= 1) {
      notify('จำเป็นต้องมีอย่างน้อยหนึ่งเซสชัน', 'info');
      return;
    }
    const filtered = sessions.filter((s) => s.id !== id);
    setSessions(filtered);
    if (activeSessionId === id) {
      setActiveSessionId(filtered[0].id);
    }
  };

  const handleSaveRename = (id: string) => {
    if (!editingTitleText.trim()) {
      setEditingTitleId(null);
      return;
    }
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: editingTitleText.trim() } : s))
    );
    setEditingTitleId(null);
  };

  const handleSendMessage = async () => {
    const trimmed = inputPrompt.trim();
    if (!trimmed || isProcessing) return;

    // Check Slash Commands
    if (trimmed === '/inspect-workspace') {
      setInputPrompt('');
      onOpenWorkspaceInspector();
      return;
    }
    if (trimmed === '/audit') {
      setInputPrompt('');
      onOpenAuditReport();
      return;
    }
    if (trimmed === '/diagnostics' || trimmed === '/runtime') {
      setInputPrompt('');
      onOpenRuntimeModal();
      return;
    }

    const userMessage: ChatMessage = {
      id: 'user-' + Date.now(),
      role: 'user',
      content: trimmed,
      timestamp: new Date().toISOString()
    };

    // Update session title if first user message
    const updatedMessages = [...activeSession.messages, userMessage];
    const isFirstUserMessage = activeSession.messages.filter((m) => m.role === 'user').length === 0;
    const newTitle = isFirstUserMessage
      ? trimmed.slice(0, 24) + (trimmed.length > 24 ? '...' : '')
      : activeSession.title;

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id
          ? { ...s, title: newTitle, messages: updatedMessages, updatedAt: new Date().toISOString() }
          : s
      )
    );

    setInputPrompt('');
    setIsProcessing(true);

    try {
      // Build conversation context from previous messages
      const contextPrompt = updatedMessages
        .slice(-6)
        .map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
        .join('\n');

      // Call API with strictly chosen provider (NO silent fallback)
      const res = await sendChatMessage({
        prompt: contextPrompt,
        provider: 'LOCAL_OLLAMA',
        modelId: selectedModel,
        endpoint: localEndpoint,
        systemInstruction: 'You are ZYNTHEOR AI ENGINE v4.2 PRO. Obey Zero-Fake Policy strictly. Respond accurately in Thai or English according to the user language.'
      });

      let assistantMessage: ChatMessage;

      if (res.success && res.response) {
        assistantMessage = {
          id: 'asst-' + Date.now(),
          role: 'assistant',
          content: res.response,
          timestamp: new Date().toISOString(),
          engineUsed: 'LOCAL_MODEL',
          modelName: `${res.provider} (${res.modelId})`,
          latencyMs: res.latencyMs,
          tokensEstimate: res.tokensEstimate
        };
      } else {
        // Honest error reporting (Zero-Fake Policy)
        assistantMessage = {
          id: 'asst-err-' + Date.now(),
          role: 'assistant',
          content: `⚠️ **ข้อผิดพลาดจาก Runtime (HTTP ${res.statusCode}):**\n\n${res.message || 'ไม่สามารถรับคำตอบจากโมเดลได้'}\n\n*Zero-Fake Policy Active: ระบบจะไม่สร้างคำตอบปลอมและไม่สลับไปใช้ Cloud API อื่นโดยไม่ได้รับอนุญาต*`,
          timestamp: new Date().toISOString(),
          engineUsed: 'NONE',
          modelName: res.provider || 'None',
          latencyMs: res.latencyMs,
          isError: true
        };
      }

      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeSession.id
            ? { ...s, messages: [...s.messages, assistantMessage], updatedAt: new Date().toISOString() }
            : s
        )
      );

      if (onLedgerUpdated) onLedgerUpdated();
    } catch (err: any) {
      const errMessage: ChatMessage = {
        id: 'asst-err-' + Date.now(),
        role: 'assistant',
        content: `❌ **ข้อผิดพลาดระบบ:** ${err.message}`,
        timestamp: new Date().toISOString(),
        engineUsed: 'NONE',
        isError: true
      };
      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeSession.id ? { ...s, messages: [...s.messages, errMessage] } : s
        )
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsProcessing(false);
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden font-mono text-xs">
      {/* Session Sidebar */}
      <div className="w-full md:w-64 bg-[#070b14] border-r border-slate-800/80 flex flex-col shrink-0">
        <div className="p-3 border-b border-slate-800 flex items-center justify-between">
          <span className="font-semibold text-slate-300 flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-cyan-400" />
            เซสชันแชท
          </span>
          <button
            onClick={handleNewSession}
            className="flex items-center gap-1 px-2 py-1 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/30 text-[11px] transition-all"
            title="สร้างห้องแชทใหม่"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>สร้างใหม่</span>
          </button>
        </div>

        {/* Sessions List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {sessions.map((s) => {
            const isActive = s.id === activeSession.id;
            const isEditing = editingTitleId === s.id;

            return (
              <div
                key={s.id}
                onClick={() => setActiveSessionId(s.id)}
                className={`group flex items-center justify-between p-2 rounded-lg cursor-pointer transition-all ${
                  isActive
                    ? 'bg-cyan-950/50 text-cyan-200 border border-cyan-500/30'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                {isEditing ? (
                  <div className="flex items-center gap-1 w-full" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="text"
                      value={editingTitleText}
                      onChange={(e) => setEditingTitleText(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSaveRename(s.id)}
                      className="w-full px-1.5 py-0.5 text-xs bg-black border border-cyan-500 rounded text-slate-100 focus:outline-none"
                      autoFocus
                    />
                    <button
                      onClick={() => handleSaveRename(s.id)}
                      className="p-1 text-emerald-400 hover:text-emerald-300"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="truncate flex-1 pr-2">
                      <div className="truncate font-medium">{s.title}</div>
                      <div className="text-[10px] text-slate-500">
                        {new Date(s.updatedAt).toLocaleTimeString()} ({s.messages.length} ข้อความ)
                      </div>
                    </div>

                    <div className="hidden group-hover:flex items-center gap-1 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingTitleId(s.id);
                          setEditingTitleText(s.title);
                        }}
                        className="p-1 text-slate-400 hover:text-cyan-300"
                        title="เปลี่ยนชื่อเซสชัน"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => handleDeleteSession(s.id, e)}
                        className="p-1 text-slate-400 hover:text-red-400"
                        title="ลบเซสชัน"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>

        {/* Quick Slash Commands Info */}
        <div className="p-3 border-t border-slate-800/80 bg-[#060810] text-[10px] text-slate-500 space-y-1">
          <div className="text-slate-400 font-semibold flex items-center gap-1">
            <HelpCircle className="w-3 h-3 text-cyan-400" />
            คำสั่งพิเศษ (พิมพ์ในช่องแชท):
          </div>
          <div className="text-cyan-300/80 cursor-pointer hover:underline" onClick={onOpenWorkspaceInspector}>
            • /inspect-workspace
          </div>
          <div className="text-amber-300/80 cursor-pointer hover:underline" onClick={onOpenAuditReport}>
            • /audit
          </div>
          <div className="text-amber-300/80 cursor-pointer hover:underline" onClick={onOpenRuntimeModal}>
            • /diagnostics
          </div>
        </div>
      </div>

      {/* Main Chat Workspace */}
      <div className="flex-1 flex flex-col bg-[#05070c] overflow-hidden">
        {/* Chat Control Toolbar */}
        <div className="px-4 py-2.5 bg-[#080d1a] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Local runtime:</span>

            <input
              type="text"
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              placeholder="ชื่อโมเดลที่ติดตั้งจริง"
              className="w-40 px-2 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200 text-xs focus:outline-none focus:border-cyan-400 font-mono"
              title="ชื่อ Model ID ใน runtime"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setSessions((prev) =>
                  prev.map((s) => (s.id === activeSessionId ? { ...s, messages: [], updatedAt: new Date().toISOString() } : s))
                );
              }}
              disabled={activeSession.messages.length === 0}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-[11px] transition-colors ${
                activeSession.messages.length === 0
                  ? 'border-slate-800 text-slate-600 cursor-not-allowed opacity-50'
                  : 'border-rose-500/30 bg-rose-950/20 text-rose-300 hover:text-white hover:bg-rose-900/30'
              }`}
              title="Clear Conversation — ล้างข้อความทั้งหมดในเซสชันนี้และเริ่มต้นใหม่"
              aria-label="Clear Conversation"
            >
              <Trash2 className="w-3 h-3 text-rose-400" />
              <span>Clear Conversation</span>
            </button>
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Zero-Fake Policy Active: ห้ามสร้างผลลัพธ์จำลอง</span>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeSession.messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center text-slate-500">
              <Sparkles className="w-8 h-8 text-cyan-400/50 mb-3 animate-pulse" />
              <p className="text-sm font-semibold text-slate-300">เริ่มการสนทนากับ ZYNTHEOR AI ENGINE</p>
              <p className="text-xs text-slate-500 max-w-md mt-1">
                สอบถามข้อมูล วิเคราะห์โค้ด ค้นหาไฟล์ใน .data/workspace หรือสั่งประมวลผลผ่านคำสั่งพิเศษได้ทันที
              </p>
            </div>
          ) : (
            activeSession.messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl p-3.5 text-xs leading-relaxed ${
                      isUser
                        ? 'bg-cyan-950/60 text-slate-100 border border-cyan-500/40 shadow-sm'
                        : msg.isError
                        ? 'bg-red-950/40 text-red-200 border border-red-500/30'
                        : 'bg-[#090d18] text-slate-200 border border-slate-800'
                    }`}
                  >
                    <div className="whitespace-pre-wrap">{msg.content}</div>

                    {/* Metadata Telemetry Footnote */}
                    {!isUser && msg.engineUsed && (
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-3 text-[10px] text-slate-500 font-mono">
                        <span className="text-cyan-400 font-semibold">{msg.modelName || msg.engineUsed}</span>
                        {msg.latencyMs !== undefined && <span>{msg.latencyMs}ms</span>}
                        {msg.tokensEstimate !== undefined && <span>~{msg.tokensEstimate} tokens</span>}
                        <span className="text-emerald-400 flex items-center gap-1">
                          <Check className="w-3 h-3" /> Sealed in Ledger
                        </span>
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-600 mt-1 px-1">
                    {new Date(msg.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              );
            })
          )}
          {isProcessing && (
            <div className="flex items-center gap-2 text-xs text-cyan-400 p-2 font-mono">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>AI กำลังประมวลผลคำขอ (Zero-Fake Inference)...</span>
              <button
                onClick={handleCancel}
                className="ml-2 px-2 py-0.5 rounded bg-red-950 hover:bg-red-900 text-red-300 border border-red-500/30 text-[10px]"
              >
                ยกเลิก
              </button>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 border-t border-slate-800 bg-[#080c16]">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
              disabled={isProcessing}
              placeholder="พิมพ์คำถาม หรือใช้คำสั่งพิเศษเช่น /inspect-workspace, /audit, /diagnostics..."
              className="flex-1 px-4 py-2.5 rounded-lg bg-slate-900/90 border border-slate-700 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 text-xs font-mono"
            />
            {isProcessing ? (
              <button
                onClick={handleCancel}
                className="p-2.5 rounded-lg bg-red-950 hover:bg-red-900 text-red-300 border border-red-500/40 transition-all"
                title="ยกเลิกคำขอ"
              >
                <Square className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleSendMessage}
                disabled={!inputPrompt.trim()}
                className="p-2.5 rounded-lg bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 hover:shadow-neon-cyan transition-all disabled:opacity-40"
                title="ส่งข้อความ"
              >
                <Send className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
