import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Keyboard, X, Search, Check, Play, Copy, Command } from 'lucide-react';
import type { ShortcutDef } from '../hooks/useShortcutManager';
import { filterShortcuts, splitKeys } from '../utils/shortcutHelp';

export interface ShortcutOverlayProps {
  shortcuts: ShortcutDef[];
  onClose: () => void;
}

export type ShortcutCategory = 'ALL' | 'NAV' | 'CHAT' | 'SYSTEM';

export function ShortcutOverlay({ shortcuts, onClose }: ShortcutOverlayProps) {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ShortcutCategory>('ALL');
  const [copiedLabel, setCopiedLabel] = useState<string | null>(null);
  const [executedLabel, setExecutedLabel] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Categorize shortcut
  const getCategory = (s: ShortcutDef): ShortcutCategory => {
    const l = (s.description + ' ' + s.label).toLowerCase();
    if (l.includes('โหมด') || l.includes('แถบ') || l.includes('หน้า') || l.includes('นำทาง') || l.includes('ประวัติ')) {
      return 'NAV';
    }
    if (l.includes('เซสชัน') || l.includes('ข้อความ') || l.includes('ค้นหา') || l.includes('เสียง')) {
      return 'CHAT';
    }
    return 'SYSTEM';
  };

  const filtered = useMemo(() => {
    let list = filterShortcuts(shortcuts, query);
    if (selectedCategory !== 'ALL') {
      list = list.filter((s) => getCategory(s) === selectedCategory);
    }
    return list;
  }, [shortcuts, query, selectedCategory]);

  const handleExecute = (s: ShortcutDef) => {
    setExecutedLabel(s.label);
    setTimeout(() => {
      setExecutedLabel(null);
      s.run();
      onClose();
    }, 200);
  };

  const handleCopy = (e: React.MouseEvent, label: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(label);
    setCopiedLabel(label);
    setTimeout(() => setCopiedLabel(null), 1800);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Keyboard shortcuts"
      data-testid="shortcut-overlay"
      className="fixed inset-0 z-[75] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        className="w-full max-w-xl bg-[#071026] border border-cyan-500/40 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.25)] overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-cyan-500/20 bg-[#091534]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.3)]">
              <Keyboard size={18} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <span>แผนผังปุ่มลัดแป้นพิมพ์ (Keyboard Shortcuts Overlay)</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-700">
                  Alt + /
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">ควบคุมระบบ ZYNTHEOR รวดเร็วด้วยคีย์ลัด หรือคลิกเพื่อเรียกใช้ทันที</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close shortcuts"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Search & Category Filter */}
        <div className="px-5 pt-4 pb-2 space-y-3 bg-[#060D1E]/60 border-b border-slate-800/80">
          <div className="relative">
            <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ค้นหาปุ่มลัด (เช่น Alt+N, ธีม, เสียง, เซสชัน)..."
              className="w-full rounded-xl border border-slate-700 bg-slate-900/90 py-2.5 pl-9 pr-3 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-cyan-400 shadow-inner"
            />
          </div>

          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setSelectedCategory('ALL')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${
                  selectedCategory === 'ALL'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-[0_0_10px_rgba(6,182,212,0.3)]'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-400'
                }`}
              >
                ทั้งหมด ({shortcuts.length})
              </button>
              <button
                type="button"
                onClick={() => setSelectedCategory('CHAT')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${
                  selectedCategory === 'CHAT'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-400'
                }`}
              >
                การสนทนา & งาน
              </button>
              <button
                type="button"
                onClick={() => setSelectedCategory('NAV')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${
                  selectedCategory === 'NAV'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-400'
                }`}
              >
                การนำทาง
              </button>
              <button
                type="button"
                onClick={() => setSelectedCategory('SYSTEM')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${
                  selectedCategory === 'SYSTEM'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-400'
                }`}
              >
                ระบบและมุมมอง
              </button>
            </div>

            <span className="text-[10px] text-slate-500 font-mono">
              แสดง {filtered.length} จาก {shortcuts.length} รายการ
            </span>
          </div>
        </div>

        {/* Shortcuts Map List */}
        <div className="p-4 space-y-1.5 overflow-y-auto flex-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              ไม่พบปุ่มลัดที่ตรงกับ "{query}"
            </div>
          ) : (
            filtered.map((s) => {
              const keys = splitKeys(s.label);
              const isExecuted = executedLabel === s.label;
              return (
                <div
                  key={s.label + s.description}
                  onClick={() => handleExecute(s)}
                  className={`group flex items-center justify-between gap-3 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                    isExecuted
                      ? 'bg-cyan-500/30 border-cyan-400 text-white'
                      : 'bg-slate-900/60 hover:bg-slate-850/80 border-slate-800/80 hover:border-cyan-500/40 text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <span className="text-slate-200 group-hover:text-cyan-200 font-medium truncate">
                      {s.description}
                    </span>
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] text-cyan-400 flex items-center gap-1 font-mono">
                      <Play size={10} className="fill-cyan-400" />
                      <span>คลิกเพื่อเรียกใช้</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      title="คัดลอกปุ่มลัด"
                      onClick={(e) => handleCopy(e, s.label)}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-white rounded transition-opacity"
                    >
                      {copiedLabel === s.label ? (
                        <Check size={12} className="text-emerald-400" />
                      ) : (
                        <Copy size={12} />
                      )}
                    </button>

                    <div className="flex items-center gap-1">
                      {keys.map((k, idx) => (
                        <kbd
                          key={k + idx}
                          className="px-2 py-1 rounded-md bg-[#091534] border border-cyan-500/40 text-[11px] font-mono font-bold text-cyan-300 shadow-[0_2px_4px_rgba(0,0,0,0.4)]"
                        >
                          {k}
                        </kbd>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-[#060D1E] flex items-center justify-between text-[11px] text-slate-500">
          <span>
            กด <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] text-slate-300">Esc</kbd> เพื่อปิดหน้าต่าง
          </span>
          <span className="font-mono text-cyan-400/80">
            คลิกที่แถวใดก็ได้เพื่อเรียกใช้คำสั่งทันที
          </span>
        </div>
      </div>
    </div>
  );
}
