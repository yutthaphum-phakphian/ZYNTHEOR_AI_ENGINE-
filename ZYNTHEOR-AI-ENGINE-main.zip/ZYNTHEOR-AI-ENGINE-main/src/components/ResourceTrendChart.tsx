import { useState, useEffect, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';
import { Cpu, HardDrive, Zap, Activity } from 'lucide-react';

export interface MetricDataPoint {
  time: string;
  timestamp: number;
  cpu: number;
  ram: number;
  latencyMs: number | null;
}

interface ResourceTrendChartProps {
  /** null = no data received from the server yet. */
  currentCpu: number | null;
  cpuDisplay: string | null;
  currentRam: number | null;
  ramDisplay: string | null;
  latencyMs: number | null;
  resourceSource: string | null;
  modelComparison?: Array<{
    model: string;
    latencyMs: number | null;
    tokensPerSecond: number | null;
    memoryBytes: number | null;
    sampleCount: number;
  }>;
}

export function ResourceTrendChart({
  currentCpu,
  cpuDisplay,
  currentRam,
  ramDisplay,
  latencyMs,
  resourceSource,
  modelComparison,
}: ResourceTrendChartProps) {
  // Store a rolling five-minute window. Points are timestamp-filtered so the
  // window remains five minutes even if the server polling cadence changes.
  // Starts empty: only real samples received from the server are ever plotted.
  const [history, setHistory] = useState<MetricDataPoint[]>([]);

  // Append new live data point when metrics update
  useEffect(() => {
    if (currentCpu == null || currentRam == null) return;
    const now = new Date();
    const timeStr = now.toLocaleTimeString('th-TH', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });

    setHistory((prev) => {
      const newPoint: MetricDataPoint = {
        time: timeStr,
        timestamp: now.getTime(),
        cpu: currentCpu,
        ram: currentRam,
        latencyMs,
      };

      const cutoff = now.getTime() - 5 * 60 * 1000;
      const updated = [...prev, newPoint].filter((point) => point.timestamp >= cutoff).slice(-60);
      return updated;
    });
  }, [currentCpu, currentRam, latencyMs]);

  // Average statistics over the 5-minute window
  const stats = useMemo(() => {
    if (history.length === 0) return null;
    const cpuSum = history.reduce((acc, p) => acc + p.cpu, 0);
    const ramSum = history.reduce((acc, p) => acc + p.ram, 0);
    const peakCpu = Math.max(...history.map((p) => p.cpu));
    return {
      avgCpu: Math.round(cpuSum / history.length),
      avgRam: Math.round(ramSum / history.length),
      peakCpu,
    };
  }, [history, currentCpu, currentRam]);

  return (
    <section className="rounded-xl border border-cyan-500/25 bg-[#091534]/85 p-3.5 shadow-lg space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Activity size={14} className="text-cyan-400" />
          <span className="text-xs font-bold text-white tracking-wide">
            ทรัพยากรระบบ (Real-Time Trend)
          </span>
        </div>
        <span className="text-[9px] text-slate-500" title={resourceSource || undefined}>
          {resourceSource || 'Metric source unavailable'}
        </span>
        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
          <span>5 MIN WINDOW</span>
        </div>
      </div>

      {/* Metric Cards Summary */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="p-2 rounded-lg bg-slate-900/80 border border-cyan-500/20">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-0.5">
            <span className="flex items-center gap-1">
              <Cpu size={12} className="text-cyan-400" /> CPU
            </span>
            <span className="text-[10px] text-slate-500 font-mono">AVG: {stats ? `${stats.avgCpu}%` : '—'}</span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-base font-bold font-mono text-cyan-300 tabular-nums">
              {cpuDisplay ?? '—'}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">PEAK: {stats ? `${stats.peakCpu}%` : '—'}</span>
          </div>
        </div>

        <div className="min-w-0 p-2 rounded-lg bg-slate-900/80 border border-indigo-500/20">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-0.5">
            <span className="flex items-center gap-1">
              <HardDrive size={12} className="text-indigo-400" /> RAM
            </span>
            <span className="text-[10px] text-slate-500 font-mono">AVG: {stats ? `${stats.avgRam}%` : '—'}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-base font-bold font-mono text-indigo-300 tabular-nums leading-tight">
              {currentRam == null ? '—' : `${currentRam}%`}
            </span>
            <span className="block max-w-full truncate text-[10px] text-slate-400 font-mono whitespace-nowrap" title={ramDisplay ?? undefined}>
              {ramDisplay ? `${ramDisplay.split('(')[0].trim()}` : '—'}
            </span>
          </div>
        </div>
      </div>

      {/* Real-Time Recharts Trend Lines (Replacing static bar indicators) */}
      <div className="relative pt-1">
        <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1 px-1">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-2 h-0.5 bg-cyan-400 inline-block"></span>
              <span className="text-cyan-300 font-medium">CPU %</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-0.5 bg-indigo-400 inline-block"></span>
              <span className="text-indigo-300 font-medium">RAM %</span>
            </span>
          </div>
          <span className="font-mono text-slate-500 text-[9px]">-5m → NOW</span>
        </div>

        <div className="h-[125px] w-full bg-slate-950/60 rounded-lg p-1 border border-slate-800/80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={history} margin={{ top: 5, right: 8, left: -25, bottom: 0 }}>
              <XAxis
                dataKey="time"
                tick={{ fontSize: 9, fill: '#64748b' }}
                interval={9}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                domain={[0, 100]}
                tick={{ fontSize: 9, fill: '#64748b' }}
                axisLine={false}
                tickLine={false}
                ticks={[0, 25, 50, 75, 100]}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const cpuVal = payload.find((p) => p.dataKey === 'cpu')?.value;
                    const ramVal = payload.find((p) => p.dataKey === 'ram')?.value;
                    return (
                      <div className="bg-[#071026] border border-cyan-500/40 rounded-md p-2 shadow-xl text-[10px] space-y-1">
                        <div className="text-slate-400 font-mono border-b border-slate-800 pb-0.5">{label}</div>
                        <div className="flex items-center gap-2 text-cyan-300">
                          <span>CPU:</span>
                          <span className="font-mono font-bold">{cpuVal}%</span>
                        </div>
                        <div className="flex items-center gap-2 text-indigo-300">
                          <span>RAM:</span>
                          <span className="font-mono font-bold">{ramVal}%</span>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Line
                type="monotone"
                dataKey="cpu"
                stroke="#06b6d4"
                strokeWidth={2}
                dot={false}
                isAnimationActive={false}
              />
              <Line
                type="monotone"
                dataKey="ram"
                stroke="#5eead4"
                strokeWidth={2}
                dot={false}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Latency & GPU Footer */}
      <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[11px]">
        <span className="flex items-center gap-1 text-slate-400">
          <Zap size={12} className="text-amber-400" />
          <span>Local Engine Latency:</span>
        </span>
        <span className="text-cyan-400 font-mono font-bold tabular-nums">
          {latencyMs == null ? '—' : `${latencyMs}ms`}
        </span>
      </div>

      {modelComparison && (
        <div className="border-t border-cyan-500/20 pt-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="text-xs font-bold text-white">เปรียบเทียบประสิทธิภาพโมเดล</div>
            <div className="text-[9px] text-slate-500">Inference samples + runtime-reported memory</div>
          </div>
          {modelComparison.length < 2 ? (
            <div role="status" className="rounded-lg border border-amber-800/60 bg-amber-950/20 p-3 text-[11px] text-amber-300">
              UNAVAILABLE — ต้องมีโมเดลที่ runtime รายงานอย่างน้อย 2 โมเดลเพื่อเปรียบเทียบ
            </div>
          ) : (
            <div className="space-y-3">
              {/* Overlay Performance Comparison Chart (Latency & TPS) */}
              <div className="rounded-xl border border-cyan-500/30 bg-[#070d1d] p-3 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300">
                    <Activity size={13} className="text-cyan-400" />
                    <span>Overlay Performance Comparison (Latency & Throughput)</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {modelComparison[0]?.model} vs {modelComparison[1]?.model}
                  </span>
                </div>

                {/* Overlaid Dual Bar Chart comparing Model A and Model B */}
                <div className="h-36 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        {
                          metric: 'Latency (ms)',
                          unit: 'ms',
                          [modelComparison[0].model]: modelComparison[0].latencyMs,
                          [modelComparison[1].model]: modelComparison[1].latencyMs,
                        },
                        {
                          metric: 'TPS (tokens/s)',
                          unit: 't/s',
                          [modelComparison[0].model]: modelComparison[0].tokensPerSecond,
                          [modelComparison[1].model]: modelComparison[1].tokensPerSecond,
                        },
                      ]}
                      margin={{ top: 8, right: 10, left: -20, bottom: 2 }}
                    >
                      <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="metric" tick={{ fontSize: 9, fill: '#cbd5e1' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 8, fill: '#64748b' }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#091024', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                        formatter={(val: any, name: any) => [val == null ? 'UNAVAILABLE' : `${val}`, String(name)]}
                      />
                      <Bar dataKey={modelComparison[0].model} fill="#06b6d4" radius={[4, 4, 0, 0]} isAnimationActive={false} />
                      <Bar dataKey={modelComparison[1].model} fill="#f59e0b" radius={[4, 4, 0, 0]} isAnimationActive={false} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Hardware Efficiency Insight Verdict */}
                <div className="flex flex-wrap items-center justify-between gap-2 p-2 rounded-lg bg-slate-900/90 border border-slate-800 text-[10px]">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1 text-cyan-300">
                      <span className="w-2 h-2 rounded-xs bg-[#06b6d4] inline-block" />
                      <span className="font-mono font-semibold">{modelComparison[0].model}</span>
                    </span>
                    <span className="flex items-center gap-1 text-amber-300">
                      <span className="w-2 h-2 rounded-xs bg-[#f59e0b] inline-block" />
                      <span className="font-mono font-semibold">{modelComparison[1].model}</span>
                    </span>
                  </div>
                  <div className="text-slate-300 font-medium">
                    {modelComparison[0].latencyMs && modelComparison[1].latencyMs ? (
                      modelComparison[0].latencyMs < modelComparison[1].latencyMs ? (
                        <span className="text-emerald-400">
                          ✓ แนะนำสำหรับฮาร์ดแวร์นี้: <strong className="font-mono">{modelComparison[0].model}</strong> เร็วกว่า (Latency ต่ำกว่า {(modelComparison[1].latencyMs - modelComparison[0].latencyMs)}ms)
                        </span>
                      ) : modelComparison[1].latencyMs < modelComparison[0].latencyMs ? (
                        <span className="text-emerald-400">
                          ✓ แนะนำสำหรับฮาร์ดแวร์นี้: <strong className="font-mono">{modelComparison[1].model}</strong> เร็วกว่า (Latency ต่ำกว่า {(modelComparison[0].latencyMs - modelComparison[1].latencyMs)}ms)
                        </span>
                      ) : (
                        <span>โมเดลทั้งสองมี Latency ใกล้เคียงกัน</span>
                      )
                    ) : (
                      <span className="text-slate-500">รอตัวอย่างการรันจริงเพื่อวิเคราะห์ความคุ้มค่าของฮาร์ดแวร์</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Individual metric breakdown cards */}
              <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
                {([
                  { key: 'latencyMs', label: 'Inference latency', unit: 'ms', color: '#fbbf24' },
                  { key: 'tokensPerSecond', label: 'Throughput', unit: 'tokens/s', color: '#22d3ee' },
                  { key: 'memoryBytes', label: 'Loaded memory', unit: 'MB', color: '#fbbf24' },
                ] as const).map((metric) => {
                  const data = modelComparison.map((item) => ({
                    model: item.model,
                    value: metric.key === 'memoryBytes' && item.memoryBytes != null ? Number((item.memoryBytes / (1024 * 1024)).toFixed(1)) : item[metric.key],
                  }));
                  const hasValues = data.some((item) => typeof item.value === 'number' && Number.isFinite(item.value));
                  return (
                    <div key={metric.key} className="min-w-0 rounded-lg border border-slate-800 bg-slate-950/70 p-2">
                      <div className="mb-1 flex items-center justify-between gap-1 text-[10px]">
                        <span className="truncate font-semibold text-slate-200">{metric.label}</span>
                        <span className="shrink-0 text-slate-500">{metric.unit}</span>
                      </div>
                      {hasValues ? (
                        <div className="h-28 w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={data} margin={{ top: 4, right: 3, left: -22, bottom: 1 }}>
                              <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="model" tick={{ fontSize: 8, fill: '#94a3b8' }} interval={0} tickFormatter={(value) => String(value).length > 14 ? `${String(value).slice(0, 12)}…` : value} />
                              <YAxis tick={{ fontSize: 8, fill: '#64748b' }} width={34} />
                              <Tooltip formatter={(value) => [value == null ? 'UNAVAILABLE' : `${value} ${metric.unit}`, metric.label]} />
                              <Bar dataKey="value" fill={metric.color} radius={[3, 3, 0, 0]} isAnimationActive={false} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      ) : (
                        <div className="flex h-28 items-center justify-center text-[10px] text-amber-300">UNAVAILABLE — no real samples</div>
                      )}
                      <div className="mt-1 text-[9px] text-slate-500">{modelComparison.map((item) => `${item.model}: ${item.sampleCount} sample(s)`).join(' · ')}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
}

