import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Activity,
  ShieldCheck,
  Zap,
  Cpu,
  Layers,
  RotateCcw,
  Sparkles,
  Sliders,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { QuantumCoreParameters } from '../types/quantum';

interface QuantumRuntimeHologramProps {
  onParameterChange?: (params: QuantumCoreParameters) => void;
  lang?: 'en' | 'th';
}

const DEFAULT_PARAMS: QuantumCoreParameters = {
  frequencyGhz: 4.8,
  pulseIntensity: 88,
  entropyDamping: 99.4,
  quantumState: 'RESONANT',
  chaosHealStatus: 'ACTIVE',
  uptimePercentage: 99.999,
  telemetryLatencyMs: 3.8,
};

const CLUSTERS = [
  { name: 'Genesis', colorHex: 0x00f5ff, pos: [-3, 1.5, 0] },
  { name: 'Custodian', colorHex: 0x10b981, pos: [3, 1.5, 0] },
  { name: 'Cryo', colorHex: 0x38bdf8, pos: [-2.2, -1.8, 1.5] },
  { name: 'Quantum', colorHex: 0xf59e0b, pos: [2.2, -1.8, 1.5] },
  { name: 'Planck', colorHex: 0xf43f5e, pos: [0, 2.5, -2] },
  { name: 'Forensic', colorHex: 0xf59e0b, pos: [0, -2.5, -2] },
];

export const QuantumRuntimeHologram: React.FC<QuantumRuntimeHologramProps> = ({
  onParameterChange,
  lang = 'th',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [params, setParams] = useState<QuantumCoreParameters>(DEFAULT_PARAMS);
  const [activeAgentPhase, setActiveAgentPhase] = useState<'Think' | 'Act' | 'Evolve' | 'Verify'>('Evolve');

  // Three.js Scene Setup
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight || 380;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030712, 0.04);

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    camera.position.set(0, 1.5, 8.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // 1. Quantum Core Inner Dodecahedron (Neon Cyan)
    const coreGeo = new THREE.DodecahedronGeometry(1.4, 1);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0x00f5ff,
      wireframe: true,
      transparent: true,
      opacity: 0.5,
    });
    const quantumCore = new THREE.Mesh(coreGeo, coreMat);
    scene.add(quantumCore);

    // 2. Quantum Entanglement Outer Shell (Neon Violet)
    const shellGeo = new THREE.IcosahedronGeometry(2.1, 2);
    const shellMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });
    const shell = new THREE.Mesh(shellGeo, shellMat);
    scene.add(shell);

    // 3. Quantum Flux Torus Ring
    const torusGeo = new THREE.TorusGeometry(3.0, 0.04, 16, 100);
    const torusMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.6,
    });
    const torus = new THREE.Mesh(torusGeo, torusMat);
    torus.rotation.x = Math.PI / 3;
    scene.add(torus);

    // 4. Cluster Nodes & Connecting Flux Lines
    const clusterNodesGroup = new THREE.Group();
    scene.add(clusterNodesGroup);

    CLUSTERS.forEach((cluster) => {
      const nodeGeo = new THREE.SphereGeometry(0.2, 16, 16);
      const nodeMat = new THREE.MeshBasicMaterial({ color: cluster.colorHex });
      const nodeMesh = new THREE.Mesh(nodeGeo, nodeMat);
      nodeMesh.position.set(cluster.pos[0], cluster.pos[1], cluster.pos[2]);
      clusterNodesGroup.add(nodeMesh);

      // Link line to center
      const points = [
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(cluster.pos[0], cluster.pos[1], cluster.pos[2]),
      ];
      const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
      const lineMat = new THREE.LineBasicMaterial({
        color: cluster.colorHex,
        transparent: true,
        opacity: 0.25,
      });
      const line = new THREE.Line(lineGeo, lineMat);
      clusterNodesGroup.add(line);
    });

    // 5. Quantum Particles Field
    const particleCount = 350;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    const cyanColor = new THREE.Color(0x00f5ff);
    const amberColor = new THREE.Color(0xf59e0b);

    for (let i = 0; i < particleCount * 3; i += 3) {
      const r = 2.0 + Math.random() * 4.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = (Math.random() - 0.5) * Math.PI;

      positions[i] = r * Math.cos(phi) * Math.cos(theta);
      positions[i + 1] = r * Math.sin(phi);
      positions[i + 2] = r * Math.cos(phi) * Math.sin(theta);

      const mixed = Math.random() > 0.5 ? cyanColor : amberColor;
      colors[i] = mixed.r;
      colors[i + 1] = mixed.g;
      colors[i + 2] = mixed.b;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.05,
      vertexColors: true,
      transparent: true,
      opacity: 0.7,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Mouse movement
    let mouseX = 0;
    let mouseY = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseX = ((e.clientX - rect.left) / width - 0.5) * 1.5;
      mouseY = ((e.clientY - rect.top) / height - 0.5) * 1.5;
    };
    container.addEventListener('mousemove', handleMouseMove);

    // Animation Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Speed adjusted by frequency parameter
      const speedMultiplier = (params.frequencyGhz / 4.8);

      quantumCore.rotation.x = elapsed * 0.4 * speedMultiplier;
      quantumCore.rotation.y = elapsed * 0.5 * speedMultiplier;

      shell.rotation.x = -elapsed * 0.25 * speedMultiplier;
      shell.rotation.z = elapsed * 0.3 * speedMultiplier;

      torus.rotation.z = elapsed * 0.2 * speedMultiplier;

      clusterNodesGroup.rotation.y = elapsed * 0.1 * speedMultiplier;
      particles.rotation.y = elapsed * 0.05 * speedMultiplier;

      // Camera tilt
      camera.position.x += (mouseX * 2 - camera.position.x) * 0.05;
      camera.position.y += (-mouseY * 1.2 + 1.5 - camera.position.y) * 0.05;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };
    animate();

    // Agent Phase cycler
    const phaseInterval = window.setInterval(() => {
      setActiveAgentPhase((prev) => {
        if (prev === 'Think') return 'Act';
        if (prev === 'Act') return 'Evolve';
        if (prev === 'Evolve') return 'Verify';
        return 'Think';
      });
    }, 2800);

    let resizeRaf: number | null = null;
    const resizeObserver = new ResizeObserver(() => {
      if (resizeRaf !== null) cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(() => {
        if (!container) return;
        const newWidth = container.clientWidth;
        const newHeight = container.clientHeight || 380;
        camera.aspect = newWidth / newHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(newWidth, newHeight, false);
      });
    });
    resizeObserver.observe(container);

    return () => {
      if (resizeRaf !== null) cancelAnimationFrame(resizeRaf);
      cancelAnimationFrame(animId);
      clearInterval(phaseInterval);
      resizeObserver.disconnect();
      container.removeEventListener('mousemove', handleMouseMove);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      coreGeo.dispose();
      coreMat.dispose();
      shellGeo.dispose();
      shellMat.dispose();
      torusGeo.dispose();
      torusMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, [params.frequencyGhz]);

  const handleUpdate = (updated: Partial<QuantumCoreParameters>) => {
    const next = { ...params, ...updated };
    setParams(next);
    if (onParameterChange) onParameterChange(next);
  };

  return (
    <div className="space-y-4">
      {/* 3D Quantum Runtime Viewport */}
      <div className="relative rounded-2xl overflow-hidden border border-cyan-500/40 bg-gradient-to-b from-zinc-950 via-slate-950 to-zinc-950 shadow-2xl">
        <div
          ref={containerRef}
          className="w-full h-80 md:h-96 cursor-grab active:cursor-grabbing relative"
          aria-label="Quantum Runtime 3D Hologram"
        />

        {/* Top Floating Badge Bar */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          <div className="flex items-center gap-2 pointer-events-auto">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
            <span className="font-mono text-xs font-bold tracking-widest text-cyan-300 uppercase">
              QUANTUM RUNTIME HOLOGRAM
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-950/80 border border-amber-500/40 text-amber-300">
              STATE: {params.quantumState}
            </span>
          </div>

          <div className="flex items-center gap-2 pointer-events-auto font-mono text-[11px]">
            <span className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" /> DILITHIUM-5 PQC
            </span>
            <span className="hidden sm:inline bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 px-2 py-0.5 rounded-md">
              DRIFT: 0.00%
            </span>
          </div>
        </div>

        {/* Agent Activity Pipeline Indicator: Think → Act → Evolve → Verify */}
        <div className="absolute bottom-3 left-3 right-3 bg-zinc-950/90 border border-cyan-800/40 backdrop-blur-md rounded-xl p-2.5 flex items-center justify-between pointer-events-auto">
          <div className="flex items-center gap-1.5 sm:gap-3 text-xs font-mono">
            <span className="text-[11px] text-zinc-400 uppercase font-semibold mr-1 hidden sm:inline">
              AGENT CYCLE:
            </span>
            {(['Think', 'Act', 'Evolve', 'Verify'] as const).map((phase, idx) => {
              const isActive = activeAgentPhase === phase;
              return (
                <div key={phase} className="flex items-center gap-1 sm:gap-2">
                  <div
                    className={`px-2 py-1 rounded-lg flex items-center gap-1 text-[11px] font-bold transition-all ${
                      isActive
                        ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/50 scale-105'
                        : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
                    }`}
                  >
                    <span>{idx + 1}. {phase}</span>
                    {isActive && <Sparkles className="w-3 h-3 animate-spin" />}
                  </div>
                  {idx < 3 && <span className="text-zinc-600 text-xs">→</span>}
                </div>
              );
            })}
          </div>

          <div className="hidden md:flex items-center gap-3 font-mono text-[11px] text-zinc-400">
            <span className="text-cyan-400 font-semibold">{params.telemetryLatencyMs} ms</span>
            <span>Uptime: {params.uptimePercentage}%</span>
            <span className="text-emerald-400">Auto-Heal: {params.chaosHealStatus}</span>
          </div>
        </div>
      </div>

      {/* Quantum Core Controls & Parameter Tuner */}
      <div className="p-4 rounded-2xl bg-zinc-950/90 border border-cyan-900/40 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-zinc-100 uppercase tracking-wider">
              {lang === 'th' ? 'แผงควบคุมแกนควอนตัม (Quantum Core & Entropy Control)' : 'Quantum Core Controls'}
            </h3>
          </div>
          <button
            type="button"
            onClick={() => handleUpdate(DEFAULT_PARAMS)}
            className="text-[11px] text-zinc-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer font-mono"
          >
            <RotateCcw className="w-3 h-3" />
            <span>{lang === 'th' ? 'คืนค่ามาตรฐาน' : 'Reset Defaults'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Frequency Control */}
          <div className="space-y-1.5 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-300 font-medium">{lang === 'th' ? 'ความถี่คอร์ (Frequency)' : 'Core Frequency'}</span>
              <span className="font-mono text-cyan-400 font-bold">{params.frequencyGhz.toFixed(1)} GHz</span>
            </div>
            <input
              type="range"
              min={1.0}
              max={10.0}
              step={0.1}
              value={params.frequencyGhz}
              onChange={(e) => handleUpdate({ frequencyGhz: parseFloat(e.target.value) })}
              className="w-full accent-cyan-400 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
              aria-label="Quantum Core Frequency"
            />
            <div className="text-[10px] text-zinc-500 font-mono flex justify-between">
              <span>1.0 GHz</span>
              <span>Baseline: 4.8 GHz</span>
              <span>10.0 GHz</span>
            </div>
          </div>

          {/* Pulse Intensity */}
          <div className="space-y-1.5 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-300 font-medium">{lang === 'th' ? 'ความเข้มของพัลส์ (Pulse Intensity)' : 'Pulse Intensity'}</span>
              <span className="font-mono text-amber-400 font-bold">{params.pulseIntensity}%</span>
            </div>
            <input
              type="range"
              min={10}
              max={100}
              step={1}
              value={params.pulseIntensity}
              onChange={(e) => handleUpdate({ pulseIntensity: parseInt(e.target.value, 10) })}
              className="w-full accent-amber-400 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
              aria-label="Quantum Pulse Intensity"
            />
            <div className="text-[10px] text-zinc-500 font-mono flex justify-between">
              <span>10%</span>
              <span>Resonant: 88%</span>
              <span>100%</span>
            </div>
          </div>

          {/* Entropy Damping */}
          <div className="space-y-1.5 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-300 font-medium">{lang === 'th' ? 'การลดเอนโทรปี (Entropy Damping)' : 'Entropy Damping'}</span>
              <span className="font-mono text-emerald-400 font-bold">{params.entropyDamping.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min={80}
              max={100}
              step={0.1}
              value={params.entropyDamping}
              onChange={(e) => handleUpdate({ entropyDamping: parseFloat(e.target.value) })}
              className="w-full accent-emerald-400 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
              aria-label="Entropy Damping"
            />
            <div className="text-[10px] text-zinc-500 font-mono flex justify-between">
              <span>80.0%</span>
              <span>Coherence: 99.4%</span>
              <span>100.0%</span>
            </div>
          </div>
        </div>

        {/* Quantum State Selector */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="text-xs text-zinc-400 font-mono">
            {lang === 'th' ? 'สภาวะควอนตัม (Quantum State):' : 'Quantum State:'}
          </div>
          <div className="flex flex-wrap gap-2">
            {(['COHERENT', 'ENTANGLED', 'SUPERPOSITION', 'RESONANT'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => handleUpdate({ quantumState: st })}
                className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                  params.quantumState === st
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-400 shadow-sm shadow-cyan-500/30'
                    : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-zinc-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
