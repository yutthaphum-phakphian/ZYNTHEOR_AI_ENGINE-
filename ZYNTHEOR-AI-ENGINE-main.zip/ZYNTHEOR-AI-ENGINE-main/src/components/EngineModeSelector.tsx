import React, { useEffect, useState } from 'react';

/**
 * Engine mode selector — only modes with real backend behavior are selectable.
 *  auto    -> /api/chat mode "auto"
 *  fast    -> mode "auto" + preferred depth FAST (advisory; risk/approval can still force DEEP)
 *  deep    -> mode "auto" + preferred depth DEEP (advisory)
 *  coding  -> /api/chat mode "code"
 *  review  -> /api/chat mode "review" (read-only audit)
 *  custom  -> /api/chat mode "custom" + custom policy schema (depth, allowedConnectors, approval, read-only)
 *  planning -> /api/chat mode "plan" (propose steps, impact, risks, tests; WAITING_APPROVAL before Build)
 * creative: no backend behavior exists, shown disabled — never pretending to work.
 */
import { ENGINE_MODE_OPTIONS, UNSUPPORTED_MODES, toChatMode, toPreferredDepth, type EngineChoice } from '../utils/engineModes';
export { toChatMode, toPreferredDepth };
export type { EngineChoice };

export interface CustomEngineConfig {
  depth?: 'AUTO' | 'FAST' | 'DEEP';
  allowedConnectors?: string[];
  requiresApproval?: boolean;
  allowFileModifications?: boolean;
  maxSteps?: number;
  strictness?: 'permissive' | 'standard' | 'strict';
}

export const DEFAULT_CUSTOM_UI_CONFIG: Required<CustomEngineConfig> = {
  depth: 'AUTO',
  allowedConnectors: ['github', 'web_research'],
  requiresApproval: false,
  allowFileModifications: true,
  maxSteps: 10,
  strictness: 'standard',
};

export type RouteState =
  | { kind: 'idle' }
  | { kind: 'unavailable' }
  | {
      kind: 'ready';
      decision: { depth: 'FAST' | 'DEEP'; reasons: string[]; depthOverridden?: boolean; connectorHints: string[] };
      connectors: Array<{ hint: string; availability: string }>;
      limitations: string[];
    };

const OPTIONS = ENGINE_MODE_OPTIONS;

export const EngineModeSelector: React.FC<{
  value: EngineChoice;
  onChange: (v: EngineChoice) => void;
  route: RouteState;
  customConfig?: CustomEngineConfig;
  onCustomConfigChange?: (cfg: CustomEngineConfig) => void;
  lang?: 'en' | 'th';
  /** The mode list lives in the chat mode sheet; keep only Custom config and route info here. */
  hideModeButtons?: boolean;
}> = ({
  value,
  onChange,
  route,
  customConfig = DEFAULT_CUSTOM_UI_CONFIG,
  onCustomConfigChange,
  lang = 'th',
  hideModeButtons = false,
}) => {
  const th = lang === 'th';
  const [showConfigPanel, setShowConfigPanel] = useState(false);

  // Choosing Custom from the chat mode sheet opens its config panel, same as clicking the old button.
  useEffect(() => {
    if (value === 'custom') setShowConfigPanel(true);
  }, [value]);

  const activeConfig: Required<CustomEngineConfig> = {
    depth: customConfig.depth ?? 'AUTO',
    allowedConnectors: customConfig.allowedConnectors ?? ['github', 'web_research'],
    requiresApproval: customConfig.requiresApproval ?? false,
    allowFileModifications: customConfig.allowFileModifications ?? true,
    maxSteps: customConfig.maxSteps ?? 10,
    strictness: customConfig.strictness ?? 'standard',
  };

  const updateConfig = (patch: Partial<CustomEngineConfig>) => {
    if (onCustomConfigChange) {
      onCustomConfigChange({ ...activeConfig, ...patch });
    }
  };

  const toggleConnector = (connectorId: string) => {
    const current = activeConfig.allowedConnectors;
    const next = current.includes(connectorId)
      ? current.filter((id) => id !== connectorId)
      : [...current, connectorId];
    updateConfig({ allowedConnectors: next });
  };

  if (hideModeButtons && value !== 'custom' && route.kind === 'idle') return null;

  return (
    <div className="px-4 py-1.5 text-[11px] text-zinc-400 space-y-1.5 bg-zinc-950/60 border-b border-zinc-800/80">
      <div className="flex flex-wrap items-center justify-between gap-1.5">
        {!hideModeButtons && (
        <div className="flex flex-wrap items-center gap-1.5" role="radiogroup" aria-label="Engine mode">
          {OPTIONS.map((o) => (
            <button
              key={o.id}
              role="radio"
              aria-checked={value === o.id}
              onClick={() => {
                onChange(o.id);
                if (o.id === 'custom') setShowConfigPanel(true);
              }}
              className={`px-2 py-0.5 rounded border transition-colors ${
                value === o.id
                  ? 'border-blue-500 text-blue-300 bg-blue-950/40 font-medium'
                  : 'border-zinc-700 hover:border-zinc-500 text-zinc-300'
              }`}
            >
              {th ? o.th : o.en}
            </button>
          ))}
          {['Creative'].map((n) => (
            <button
              key={n}
              disabled
              title={th ? 'ยังไม่มีพฤติกรรมรองรับใน backend (รอการกำหนดโมเดล)' : 'No backend behavior yet (model specification pending)'}
              className="px-2 py-0.5 rounded border border-zinc-800 text-zinc-600 cursor-not-allowed"
            >
              {n}
            </button>
          ))}
        </div>
        )}

        {value === 'custom' && (
          <button
            type="button"
            onClick={() => setShowConfigPanel((prev) => !prev)}
            className="text-[10px] text-blue-400 hover:text-blue-300 underline font-mono flex items-center gap-1"
          >
            {showConfigPanel ? (th ? '▲ ซ่อนการตั้งค่า Custom' : '▲ Hide Custom Config') : (th ? '▼ ตั้งค่า Custom Schema' : '▼ Configure Custom Schema')}
          </button>
        )}
      </div>

      {/* Custom Configuration Drawer / Panel */}
      {value === 'custom' && showConfigPanel && (
        <div className="p-2.5 rounded-lg border border-blue-500/30 bg-blue-950/20 space-y-2 text-zinc-300">
          <div className="flex items-center justify-between border-b border-blue-500/20 pb-1.5 text-[10px]">
            <span className="font-semibold text-blue-300">
              {th ? '⚙️ Schema ตั้งค่านโยบาย Custom Mode' : '⚙️ Custom Policy Configuration Schema'}
            </span>
            <span className="text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
              {th ? 'ตรวจสอบโดย Backend แล้ว' : 'Backend Validated'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 text-[10.5px]">
            {/* Depth */}
            <div className="space-y-1">
              <label className="text-zinc-400 block">{th ? 'ระดับการวิเคราะห์ (Depth):' : 'Analysis Depth:'}</label>
              <div className="flex gap-1">
                {(['AUTO', 'FAST', 'DEEP'] as const).map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => updateConfig({ depth: d })}
                    className={`px-2 py-0.5 rounded text-[10px] border ${
                      activeConfig.depth === d
                        ? 'border-blue-400 bg-blue-900/60 text-blue-200 font-medium'
                        : 'border-zinc-700 bg-zinc-900 text-zinc-400 hover:border-zinc-600'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Approval & Modifications */}
            <div className="space-y-1">
              <label className="text-zinc-400 block">{th ? 'ความปลอดภัยและการอนุมัติ:' : 'Safety & Approvals:'}</label>
              <div className="space-y-1">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={activeConfig.requiresApproval}
                    onChange={(e) => updateConfig({ requiresApproval: e.target.checked })}
                    className="rounded border-zinc-700 bg-zinc-900 text-blue-500"
                  />
                  <span>{th ? 'ต้องขออนุมัติทุกขั้นตอน' : 'Require approval'}</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!activeConfig.allowFileModifications}
                    onChange={(e) => updateConfig({ allowFileModifications: !e.target.checked })}
                    className="rounded border-zinc-700 bg-zinc-900 text-blue-500"
                  />
                  <span className={!activeConfig.allowFileModifications ? 'text-amber-300' : ''}>
                    {th ? 'ห้ามแก้ไขไฟล์ (Read-Only)' : 'Disallow file writes'}
                  </span>
                </label>
              </div>
            </div>

            {/* Allowed Connectors */}
            <div className="space-y-1">
              <label className="text-zinc-400 block">{th ? 'Connectors ที่อนุญาต:' : 'Allowed Connectors:'}</label>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: 'github', label: 'GitHub' },
                  { id: 'web_research', label: 'Web Research' },
                  { id: 'file_store', label: 'File Store' },
                  { id: 'external_api', label: 'External API' },
                ].map((c) => {
                  const checked = activeConfig.allowedConnectors.includes(c.id);
                  return (
                    <label key={c.id} className="flex items-center gap-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleConnector(c.id)}
                        className="rounded border-zinc-700 bg-zinc-900 text-blue-500"
                      />
                      <span className={checked ? 'text-zinc-200' : 'text-zinc-500'}>{c.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Decision / Route Status */}
      {route.kind === 'unavailable' && (
        <div>
          <span className="font-semibold text-zinc-300">UNAVAILABLE</span> —{' '}
          {th ? 'เรียก /api/engine/route ไม่ได้' : 'could not reach /api/engine/route'}
        </div>
      )}
      {route.kind === 'ready' && (
        <div className="leading-tight">
          <span className="font-semibold text-zinc-300">{route.decision.depth}</span>
          {route.decision.depthOverridden ? (th ? ' (ขอ FAST แต่ระบบคง DEEP)' : ' (FAST requested, kept DEEP)') : ''}
          {' · '}{route.decision.reasons.join('; ')}
          {route.connectors.length > 0 && <> · {route.connectors.map((c) => `${c.hint}: ${c.availability}`).join(', ')}</>}
          <div className="text-zinc-500 mt-0.5">{route.limitations.join(' · ')}</div>
        </div>
      )}
    </div>
  );
};
