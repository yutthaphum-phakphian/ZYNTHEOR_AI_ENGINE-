import React, { useState, useRef, useEffect } from 'react';
import { notify } from '../utils/notify';
import { Paperclip, Image as ImageIcon, Smile, Mic, MicOff, Send, X, Sparkles, Eye } from 'lucide-react';
import { AttachedFile } from '../types/agent';
import { FileIconBadge } from './FileIconBadge';
import { formatFileSize, processFileToAttachedFile } from '../utils/fileHelper';
import { AttachmentPreviewModal } from './AttachmentPreviewModal';

interface CommandInputProps {
  onSendMessage: (content: string, files: AttachedFile[]) => void;
  attachedFiles: AttachedFile[];
  onRemoveFile: (fileId: string) => void;
  onAddFiles: (newFiles: AttachedFile[]) => void;
  disabled?: boolean;
  placeholder?: string;
}

export const CommandInput: React.FC<CommandInputProps> = ({
  onSendMessage,
  attachedFiles,
  onRemoveFile,
  onAddFiles,
  disabled = false,
  placeholder = 'พิมพ์คำสั่ง, สอบถามเอเจนต์, หรือลากไฟล์มาวางที่นี่... (Enter ส่ง / Shift+Enter ขึ้นบรรทัดใหม่)',
}) => {
  const [text, setText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [voiceCommands, setVoiceCommands] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('sraang_voice_commands');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [previewFile, setPreviewFile] = useState<AttachedFile | null>(null);
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [activeStickerCategory, setActiveStickerCategory] = useState<'cyber' | 'dev' | 'reactions'>('cyber');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const voiceInputRef = useRef(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const stopAudioCapture = () => {
    mediaStreamRef.current?.getTracks().forEach((track) => track.stop());
    mediaStreamRef.current = null;
    analyserRef.current = null;
    const audioContext = audioContextRef.current;
    audioContextRef.current = null;
    if (audioContext && audioContext.state !== 'closed') void audioContext.close();
  };

  useEffect(() => {
    try {
      localStorage.setItem('sraang_voice_commands', JSON.stringify(voiceCommands));
    } catch (error) {
      console.warn('Voice command history save error:', error);
    }
  }, [voiceCommands]);

  // Initialize Web Speech API for Thai and English
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'th-TH';

    recognition.onresult = (event: any) => {
      let currentTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        currentTranscript += event.results[i][0].transcript;
      }
      if (currentTranscript) voiceInputRef.current = true;
      setText((prev) => {
        // Append smoothly if needed
        const base = prev.trim() ? prev.trim() + ' ' : '';
        return base + currentTranscript;
      });
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      setIsRecording(false);
      stopAudioCapture();
    };

    recognition.onend = () => {
      setIsRecording(false);
      stopAudioCapture();
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  const toggleRecording = () => {
    if (!speechSupported || !recognitionRef.current) {
      notify('เบราว์เซอร์ของคุณยังไม่รองรับ Web Speech API กรุณาใช้ Chrome หรือ Edge ครับ', 'error');
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
      stopAudioCapture();
    } else {
      void startRecording();
    }
  };

  const startRecording = async () => {
    try {
      if (navigator.mediaDevices?.getUserMedia && typeof AudioContext !== 'undefined') {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const audioContext = new AudioContext();
        const analyser = audioContext.createAnalyser();
        analyser.fftSize = 512;
        audioContext.createMediaStreamSource(stream).connect(analyser);
        mediaStreamRef.current = stream;
        audioContextRef.current = audioContext;
        analyserRef.current = analyser;
      }
    } catch (error) {
      console.warn('Waveform microphone access unavailable:', error);
    }

    try {
      recognitionRef.current.start();
      setIsRecording(true);
    } catch (error) {
      stopAudioCapture();
      console.error('Speech recognition could not start:', error);
    }
  };

  useEffect(() => {
    if (!isRecording) return;
    const canvas = canvasRef.current;
    const analyser = analyserRef.current;
    const context = canvas?.getContext('2d');
    if (!canvas || !context || !analyser) return;

    const samples = new Uint8Array(analyser.fftSize);
    const draw = () => {
      const bounds = canvas.getBoundingClientRect();
      const pixelRatio = window.devicePixelRatio || 1;
      canvas.width = Math.max(1, Math.floor(bounds.width * pixelRatio));
      canvas.height = Math.max(1, Math.floor(bounds.height * pixelRatio));
      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
      analyser.getByteTimeDomainData(samples);
      context.clearRect(0, 0, bounds.width, bounds.height);
      context.beginPath();
      context.lineWidth = 1.5;
      context.strokeStyle = '#e11d48';
      samples.forEach((sample, index) => {
        const x = (index / (samples.length - 1)) * bounds.width;
        const y = (sample / 255) * bounds.height;
        if (index === 0) context.moveTo(x, y);
        else context.lineTo(x, y);
      });
      context.stroke();
      animationFrameRef.current = requestAnimationFrame(draw);
    };

    animationFrameRef.current = requestAnimationFrame(draw);
    return () => {
      if (animationFrameRef.current !== null) cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    };
  }, [isRecording]);

  useEffect(() => () => {
    recognitionRef.current?.abort();
    stopAudioCapture();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if ((!text.trim() && attachedFiles.length === 0) || disabled) return;
    const messageText = text.trim();
    onSendMessage(messageText, attachedFiles);
    if (voiceInputRef.current && messageText) {
      setVoiceCommands((previous) => [messageText, ...previous.filter((command) => command !== messageText)].slice(0, 5));
    }
    voiceInputRef.current = false;
    setText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
    if (isRecording && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsRecording(false);
      stopAudioCapture();
    }
  };

  const replayVoiceCommand = (command: string) => {
    setText(command);
    voiceInputRef.current = true;
    textareaRef.current?.focus();
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const fileList: AttachedFile[] = [];
    for (let i = 0; i < files.length; i++) {
      const processed = await processFileToAttachedFile(files[i]);
      fileList.push(processed);
    }
    onAddFiles(fileList);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleImageInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const fileList: AttachedFile[] = [];
    for (let i = 0; i < files.length; i++) {
      const processed = await processFileToAttachedFile(files[i]);
      fileList.push(processed);
    }
    onAddFiles(fileList);
    if (imageInputRef.current) {
      imageInputRef.current.value = '';
    }
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    if (e.clipboardData?.files && e.clipboardData.files.length > 0) {
      const files = Array.from(e.clipboardData.files);
      const fileList: AttachedFile[] = [];
      for (const file of files) {
        const processed = await processFileToAttachedFile(file);
        fileList.push(processed);
      }
      onAddFiles(fileList);
    }
  };

  const handleSelectSticker = (emoji: string) => {
    setText((prev) => (prev ? `${prev} ${emoji}` : emoji));
    setShowStickerPicker(false);
    textareaRef.current?.focus();
  };

  // Auto-resize textarea
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  };

  return (
    <div className="relative w-full rounded-xl border border-zinc-800 bg-zinc-900/90 shadow-lg shadow-black/20 transition-all focus-within:border-blue-500/70 focus-within:ring-1 focus-within:ring-blue-500/30">
      <AttachmentPreviewModal file={previewFile} onClose={() => setPreviewFile(null)} />

      {/* Attached Files Tray with Dynamic Type Icons */}
      {attachedFiles.length > 0 && (
        <div className="flex flex-wrap gap-2 p-3 border-b border-zinc-800/80 bg-zinc-950/60 rounded-t-xl">
          {attachedFiles.map((file) => (
            <div
              key={file.id}
              className="group flex items-center gap-2 pl-2 pr-2.5 py-1 bg-zinc-850 rounded-lg border border-zinc-700/70 text-xs text-zinc-200 shadow-xs hover:border-blue-500/50 transition-all max-w-[260px]"
            >
              <FileIconBadge file={file} size="sm" />
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-medium text-zinc-200 truncate" title={file.name}>
                  {file.name}
                </span>
                <span className="text-[10px] text-zinc-400 font-mono">
                  {formatFileSize(file.size)}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setPreviewFile(file)}
                className="p-1 rounded text-zinc-400 hover:text-blue-300 hover:bg-zinc-700/60"
                title="Preview attachment"
                aria-label={`Preview ${file.name}`}
              >
                <Eye className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onRemoveFile(file.id)}
                className="ml-auto p-1 rounded text-zinc-400 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                title="ลบไฟล์แนบ"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {voiceCommands.length > 0 && (
        <section className="border-b border-zinc-800 px-3 py-2" aria-label="Recent voice commands">
          <div className="mb-1 text-[10px] font-semibold uppercase text-zinc-500 font-mono">Recent voice commands</div>
          <div className="flex gap-1.5 overflow-x-auto pb-0.5">
            {voiceCommands.map((command) => (
              <button
                key={command}
                type="button"
                onClick={() => replayVoiceCommand(command)}
                className="max-w-52 shrink-0 truncate rounded-md border border-zinc-800 bg-zinc-950/40 px-2 py-1 text-left text-[11px] text-zinc-400 hover:border-blue-500/40 hover:text-blue-300"
                title={`Use command: ${command}`}
              >
                {command}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Recording indicator bar */}
      {isRecording && (
        <div className="flex items-center gap-2 px-4 py-2 bg-rose-950/30 border-b border-rose-900/40 text-xs text-rose-300 font-medium">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse shrink-0"></span>
          <span className="min-w-0 flex-1">กำลังรับเสียงพูดภาษาไทย...</span>
          <canvas ref={canvasRef} className="h-7 w-24 shrink-0" aria-label="Live microphone waveform" />
          <button
            onClick={() => {
              recognitionRef.current?.stop();
              setIsRecording(false);
              stopAudioCapture();
            }}
            className="ml-auto text-xs underline font-semibold text-rose-400 hover:text-rose-300"
          >
            หยุดบันทึก
          </button>
        </div>
      )}

      {/* Input area */}
      <div className="flex items-end gap-2 p-3">
        {/* Hidden file input */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileInputChange}
          multiple
          className="hidden"
        />

        {/* Hidden image input */}
        <input
          type="file"
          ref={imageInputRef}
          onChange={handleImageInputChange}
          accept="image/*"
          multiple
          className="hidden"
        />

        {/* Attach file button */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled}
          className="p-2 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors shrink-0 cursor-pointer"
          title="แนบไฟล์ (เอกสาร, ข้อมูล, โค้ด)"
          aria-label="Attach files"
        >
          <Paperclip className="w-4 h-4" />
        </button>

        {/* Attach image button */}
        <button
          type="button"
          onClick={() => imageInputRef.current?.click()}
          disabled={disabled}
          className="p-2 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors shrink-0 cursor-pointer"
          title="แทรกรูปภาพ (PNG, JPG, WebP)"
          aria-label="Attach images"
        >
          <ImageIcon className="w-4 h-4" />
        </button>

        {/* Sticker button */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowStickerPicker((v) => !v)}
            disabled={disabled}
            className={`p-2 rounded-lg transition-colors shrink-0 cursor-pointer ${
              showStickerPicker
                ? 'bg-blue-600 text-white'
                : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800'
            }`}
            title="สติกเกอร์ (Stickers & Emojis)"
            aria-label="Stickers"
          >
            <Smile className="w-4 h-4" />
          </button>

          {showStickerPicker && (
            <div className="absolute bottom-full mb-2 left-0 z-50 w-72 sm:w-80 rounded-2xl bg-zinc-900 border border-zinc-700 shadow-2xl p-3 animate-in fade-in duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-800 text-xs font-semibold text-zinc-200">
                <span className="flex items-center gap-1.5">
                  <Smile className="w-4 h-4 text-blue-400" />
                  <span>สติกเกอร์ ZYNTHEOR</span>
                </span>
                <button
                  type="button"
                  onClick={() => setShowStickerPicker(false)}
                  className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-800"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Category tabs */}
              <div className="flex gap-1 my-2 p-1 bg-zinc-950 rounded-lg text-[11px]">
                <button
                  type="button"
                  onClick={() => setActiveStickerCategory('cyber')}
                  className={`flex-1 py-1 rounded font-medium transition-colors ${
                    activeStickerCategory === 'cyber' ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  🤖 Cyber
                </button>
                <button
                  type="button"
                  onClick={() => setActiveStickerCategory('dev')}
                  className={`flex-1 py-1 rounded font-medium transition-colors ${
                    activeStickerCategory === 'dev' ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  💻 Dev
                </button>
                <button
                  type="button"
                  onClick={() => setActiveStickerCategory('reactions')}
                  className={`flex-1 py-1 rounded font-medium transition-colors ${
                    activeStickerCategory === 'reactions' ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  😄 Reactions
                </button>
              </div>

              {/* Grid */}
              <div className="max-h-48 overflow-y-auto grid grid-cols-4 gap-1.5 p-1">
                {(activeStickerCategory === 'cyber'
                  ? ['⚡', '🛡️', '🧠', '🚀', '🔒', '✅', '🐛', '💡', '⚙️', '🎯', '🦾', '🏆']
                  : activeStickerCategory === 'dev'
                  ? ['💻', '🤖', '📦', '📊', '🔍', '🧬', '🌐', '🧪', '🛠️', '⌨️', '🔥', '📁']
                  : ['👍', '🎉', '❤️', '✨', '🌟', '👏', '🙌', '💯', '🤝', '😎', '🤔', '☕']
                ).map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => handleSelectSticker(emoji)}
                    className="h-10 flex items-center justify-center rounded-xl bg-zinc-800/60 hover:bg-zinc-700/80 text-xl hover:scale-125 transition-transform duration-150 cursor-pointer"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Voice Speech-to-Text Button */}
        <button
          type="button"
          onClick={toggleRecording}
          disabled={disabled || !speechSupported}
          className={`p-2 rounded-lg transition-colors shrink-0 cursor-pointer ${
            isRecording
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800'
          }`}
          title={isRecording ? 'หยุดฟังเสียง' : 'สั่งการด้วยเสียงพูด (Web Speech API)'}
          aria-label="Voice input"
        >
          {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        {/* Text Area */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          disabled={disabled}
          rows={1}
          placeholder={placeholder}
          className="flex-1 max-h-44 min-h-[40px] py-2 px-2 bg-transparent text-zinc-100 text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none resize-none leading-relaxed"
        />

        {/* Send Action */}
        <button
          type="button"
          onClick={handleSend}
          disabled={disabled || (!text.trim() && attachedFiles.length === 0)}
          className={`p-2.5 rounded-lg transition-all shrink-0 ${
            text.trim() || attachedFiles.length > 0
              ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-sm cursor-pointer'
              : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
          }`}
          title="ส่งข้อความ (Enter)"
          aria-label="Send message"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

      {/* Footer hint */}
      <div className="flex items-center justify-between px-3.5 pb-2.5 text-[11px] text-zinc-500 border-t border-zinc-800/40 pt-2">
        <div className="flex items-center gap-1.5 font-mono text-[10px]">
          <span className="text-zinc-400 font-semibold">Zyntheor Engine</span>
          <span>·</span>
          <span>Verified Execution & Cryptographic Hash</span>
        </div>
        <div className="hidden sm:flex items-center gap-1.5 font-mono text-[10px]">
          <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-300">
            ↵ Enter
          </kbd>
          <span>ส่ง</span>
          <span>·</span>
          <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-300">
            Shift + ↵
          </kbd>
          <span>ขึ้นบรรทัด</span>
        </div>
      </div>
    </div>
  );
};
