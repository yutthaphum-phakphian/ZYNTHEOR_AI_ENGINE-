import React, { useEffect, useState } from 'react';
import { Check, ChevronUp, X } from 'lucide-react';
import { ENGINE_MODE_OPTIONS, UNSUPPORTED_MODES, modeLabel, type EngineChoice } from '../utils/engineModes';

/**
 * Compact mode chip + bottom sheet, placed above the chat input (same pattern as the model picker sheet).
 * One conversation: changing the mode never clears history, context or attachments — it only changes
 * the `mode` sent with the next message. Only modes with real backend behavior are selectable.
 */
export const ChatModeSheet: React.FC<{
  value: EngineChoice;
  onChange: (v: EngineChoice) => void;
  disabled?: boolean;
}> = ({ value, onChange, disabled = false }) => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <button
        type="button"
        data-testid="chat-mode-chip"
        disabled={disabled}
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        aria-expanded={open}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border border-zinc-700 bg-zinc-900 text-zinc-200 hover:border-zinc-500 disabled:opacity-50 cursor-pointer"
      >
        <span>{modeLabel(value)}</span>
        <ChevronUp className="w-3.5 h-3.5 text-zinc-400" aria-hidden="true" />
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60" onClick={() => setOpen(false)}>
          <div
            role="dialog"
            aria-modal="true"
            aria-label="เลือกโหมด"
            data-testid="chat-mode-sheet"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg max-h-[80vh] overflow-y-auto rounded-t-2xl bg-zinc-950 border border-zinc-800 p-4 pb-6 space-y-2"
          >
            <div className="flex items-center justify-between pb-1">
              <button type="button" onClick={() => setOpen(false)} aria-label="ปิด" className="p-1 text-zinc-400 hover:text-zinc-200 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
              <h2 className="text-sm font-semibold text-zinc-100">เลือกโหมด</h2>
              <span className="w-7" aria-hidden="true" />
            </div>

            <div role="radiogroup" aria-label="โหมด" className="rounded-xl border border-zinc-800 divide-y divide-zinc-800 overflow-hidden">
              {ENGINE_MODE_OPTIONS.map((o) => (
                <button
                  key={o.id}
                  type="button"
                  role="radio"
                  aria-checked={value === o.id}
                  data-testid={`chat-mode-option-${o.id}`}
                  onClick={() => { onChange(o.id); setOpen(false); }}
                  className="w-full flex items-center justify-between gap-3 px-3 py-2.5 text-left hover:bg-zinc-900 cursor-pointer"
                >
                  <span className="min-w-0">
                    <span className="block text-sm text-zinc-100">{o.th}</span>
                    <span className="block text-[11px] text-zinc-500">{o.descriptionTh}</span>
                  </span>
                  {value === o.id && <Check className="w-4 h-4 text-blue-400 shrink-0" aria-hidden="true" />}
                </button>
              ))}
            </div>

            <div className="pt-1">
              <div className="text-[11px] text-zinc-500 pb-1">ยังไม่รองรับใน backend</div>
              <div className="flex flex-wrap gap-1.5">
                {UNSUPPORTED_MODES.map((m) => (
                  <span
                    key={m.id}
                    aria-disabled="true"
                    title="ยังไม่มีเวิร์กโฟลว์รองรับ จึงยังเลือกไม่ได้"
                    className="px-2 py-0.5 rounded border border-zinc-800 text-[11px] text-zinc-600 cursor-not-allowed"
                  >
                    {m.th}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
