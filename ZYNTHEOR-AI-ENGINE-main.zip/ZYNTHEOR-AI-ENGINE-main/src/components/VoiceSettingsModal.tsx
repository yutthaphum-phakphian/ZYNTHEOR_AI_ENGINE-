import React, { useState, useEffect } from 'react';
import {
  Volume2,
  Sliders,
  Sparkles,
  Check,
  RotateCcw,
  Play,
  Square,
  X,
  Languages,
  BellRing,
  Bot,
  Radio,
} from 'lucide-react';
import {
  VoiceSettings,
  getVoiceSettings,
  saveVoiceSettings,
  DEFAULT_VOICE_SETTINGS,
  getAvailableVoices,
  speakText,
  stopSpeaking,
  playStatusChime,
} from '../utils/voiceSettings';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang?: 'en' | 'th';
}

export const VoiceSettingsModal: React.FC<VoiceSettingsModalProps> = ({
  isOpen,
  onClose,
  lang = 'th',
}) => {
  const [settings, setSettings] = useState<VoiceSettings>(getVoiceSettings());
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isPlayingTest, setIsPlayingTest] = useState<'th' | 'en' | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Load voices and sync settings on open
  useEffect(() => {
    if (!isOpen) return;

    setSettings(getVoiceSettings());

    let mounted = true;
    getAvailableVoices().then((loadedVoices) => {
      if (mounted) {
        setVoices(loadedVoices);
      }
    });

    return () => {
      mounted = false;
      stopSpeaking();
      setIsPlayingTest(null);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // Separate voices by language
  const thaiVoices = voices.filter(
    (v) => v.lang.toLowerCase().startsWith('th') || v.name.toLowerCase().includes('thai')
  );
  const englishVoices = voices.filter(
    (v) => v.lang.toLowerCase().startsWith('en')
  );

  const handleRateChange = (rate: number) => {
    setSettings((prev) => ({ ...prev, speakingRate: rate }));
  };

  const handleTestVoice = (testLang: 'th' | 'en') => {
    if (isPlayingTest) {
      stopSpeaking();
      setIsPlayingTest(null);
      return;
    }

    setIsPlayingTest(testLang);

    const testText =
      testLang === 'th'
        ? 'สวัสดีครับ ผมคือผู้ช่วย AI พร้อมสนับสนุนการเขียนโค้ดและตรวจสอบความปลอดภัย'
        : 'Hello! I am your AI development assistant, ready to build and verify code.';

    speakText(
      testText,
      {
        ...settings,
        preferredLang: testLang === 'th' ? 'th-TH' : 'en-US',
      },
      () => setIsPlayingTest(null),
      () => setIsPlayingTest(null)
    );
  };

  const handleSave = () => {
    saveVoiceSettings(settings);
    setSaveSuccess(true);
    playStatusChime('done');
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 900);
  };

  const handleReset = () => {
    setSettings({ ...DEFAULT_VOICE_SETTINGS });
    stopSpeaking();
    setIsPlayingTest(null);
  };

  const ratePresets = [0.75, 1.0, 1.25, 1.5, 1.75];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="voice-settings-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 text-zinc-950 flex items-center justify-center shadow-lg shadow-cyan-500/20 font-bold">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <h2
                id="voice-settings-title"
                className="text-base font-bold text-zinc-100 flex items-center gap-2"
              >
                <span>{lang === 'th' ? 'การตั้งค่าระบบเสียงและ Text-to-Speech' : 'Voice Interaction Settings'}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800">
                  Web Speech API
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                {lang === 'th'
                  ? 'เลือกโมเดลเสียงภาษาไทย/อังกฤษ ปรับระดับความเร็ว และกำหนดการอ่านตอบกลับอัตโนมัติ'
                  : 'Configure Thai & English voice models, speaking rates, and auto-read preferences'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1 text-xs text-zinc-300">
          {/* Section 1: Thai & English Voice Models */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold text-zinc-200 text-sm">
                <Languages className="w-4 h-4 text-cyan-400" />
                <span>{lang === 'th' ? 'โมเดลเสียงสังเคราะห์ (Voice Models)' : 'Voice Models'}</span>
              </div>
              <span className="text-[11px] text-zinc-500">
                {voices.length > 0
                  ? `${voices.length} voices installed`
                  : lang === 'th'
                  ? 'ใช้ค่าเริ่มต้นของเบราว์เซอร์'
                  : 'Browser system default'}
              </span>
            </div>

            {/* Thai Voice Model */}
            <div className="p-3.5 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="thai-voice-select"
                  className="font-medium text-zinc-200 flex items-center gap-2"
                >
                  <span className="w-5 h-5 rounded-md bg-amber-500/10 text-amber-400 flex items-center justify-center text-[10px] font-bold border border-amber-500/20">
                    TH
                  </span>
                  <span>{lang === 'th' ? 'เสียงสังเคราะห์ภาษาไทย (Thai Voice)' : 'Thai Voice Model'}</span>
                </label>
                <button
                  type="button"
                  onClick={() => handleTestVoice('th')}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-cyan-300 font-medium text-[11px] transition-colors"
                >
                  {isPlayingTest === 'th' ? (
                    <>
                      <Square className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
                      <span>{lang === 'th' ? 'หยุดเสียง' : 'Stop'}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
                      <span>{lang === 'th' ? 'ทดสอบเสียงไทย' : 'Test Thai'}</span>
                    </>
                  )}
                </button>
              </div>

              <select
                id="thai-voice-select"
                value={settings.thaiVoiceURI}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, thaiVoiceURI: e.target.value }))
                }
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="">
                  {lang === 'th'
                    ? '⚡ ระบบตรวจจับอัตโนมัติ (Default Thai Voice / Google ภาษาไทย)'
                    : '⚡ Automatic / Default Thai Voice'}
                </option>
                {thaiVoices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    🇹🇭 {v.name} ({v.lang})
                  </option>
                ))}
              </select>

              {thaiVoices.length === 0 && (
                <div className="text-[11px] text-amber-400 bg-amber-950/30 border border-amber-900/40 p-2 rounded-lg flex items-center gap-1.5 mt-1">
                  <span className="shrink-0">⚠️</span>
                  <span>
                    {lang === 'th'
                      ? 'ไม่พบโมเดลเสียงภาษาไทยเฉพาะในระบบของคุณ ระบบจะใช้โมเดลเสียงมาตรฐานของเบราว์เซอร์ในการอ่านออกเสียง'
                      : 'No dedicated Thai voice detected on this browser/OS. Standard system fallback will be used.'}
                  </span>
                </div>
              )}
            </div>

            {/* English Voice Model */}
            <div className="p-3.5 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="english-voice-select"
                  className="font-medium text-zinc-200 flex items-center gap-2"
                >
                  <span className="w-5 h-5 rounded-md bg-blue-500/10 text-blue-400 flex items-center justify-center text-[10px] font-bold border border-blue-500/20">
                    EN
                  </span>
                  <span>{lang === 'th' ? 'เสียงสังเคราะห์ภาษาอังกฤษ (English Voice)' : 'English Voice Model'}</span>
                </label>
                <button
                  type="button"
                  onClick={() => handleTestVoice('en')}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-cyan-300 font-medium text-[11px] transition-colors"
                >
                  {isPlayingTest === 'en' ? (
                    <>
                      <Square className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
                      <span>{lang === 'th' ? 'หยุดเสียง' : 'Stop'}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
                      <span>{lang === 'th' ? 'ทดสอบเสียงอังกฤษ' : 'Test English'}</span>
                    </>
                  )}
                </button>
              </div>

              <select
                id="english-voice-select"
                value={settings.englishVoiceURI}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, englishVoiceURI: e.target.value }))
                }
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="">
                  {lang === 'th'
                    ? '⚡ ระบบตรวจจับอัตโนมัติ (Default English Voice / Google US English)'
                    : '⚡ Automatic / Default English Voice'}
                </option>
                {englishVoices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    🌐 {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Section 2: Speaking Rate & Modulation Controls */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 font-semibold text-zinc-200 text-sm">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>{lang === 'th' ? 'การควบคุมความเร็วและโทนเสียง (Speaking Rate)' : 'Speaking Rate & Controls'}</span>
            </div>

            <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-4">
              {/* Rate Slider & Presets */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-400 font-medium">
                    {lang === 'th' ? 'ความเร็วการอ่าน (Speaking Rate):' : 'Speech Rate:'}
                  </span>
                  <span className="font-mono font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800 text-[11px]">
                    {settings.speakingRate.toFixed(2)}x
                  </span>
                </div>

                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.05"
                  value={settings.speakingRate}
                  onChange={(e) => handleRateChange(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
                />

                <div className="flex items-center justify-between gap-1 pt-1">
                  {ratePresets.map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => handleRateChange(rate)}
                      className={`flex-1 py-1 rounded text-[11px] font-medium transition-all ${
                        Math.abs(settings.speakingRate - rate) < 0.03
                          ? 'bg-cyan-500 text-zinc-950 font-bold shadow-md shadow-cyan-500/20'
                          : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-400'
                      }`}
                    >
                      {rate.toFixed(2)}x {rate === 1.0 ? (lang === 'th' ? '(ปกติ)' : '(1x)') : ''}
                    </button>
                  ))}
                </div>
              </div>

              {/* Pitch & Volume Dual Column */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-zinc-850">
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] text-zinc-400">
                    <span>{lang === 'th' ? 'ระดับเสียงสูงต่ำ (Pitch)' : 'Pitch'}</span>
                    <span className="font-mono text-zinc-300">{settings.pitch.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.6"
                    max="1.4"
                    step="0.1"
                    value={settings.pitch}
                    onChange={(e) =>
                      setSettings((prev) => ({ ...prev, pitch: parseFloat(e.target.value) }))
                    }
                    className="w-full accent-amber-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] text-zinc-400">
                    <span>{lang === 'th' ? 'ระดับความดัง (Volume)' : 'Volume'}</span>
                    <span className="font-mono text-zinc-300">{Math.round(settings.volume * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.05"
                    value={settings.volume}
                    onChange={(e) =>
                      setSettings((prev) => ({ ...prev, volume: parseFloat(e.target.value) }))
                    }
                    className="w-full accent-emerald-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Auto-Read Preferences for New Agent Responses */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 font-semibold text-zinc-200 text-sm">
              <Bot className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'th' ? 'การอ่านคำตอบของ Agent อัตโนมัติ (Auto-Read Preferences)' : 'Auto-Read Preferences'}</span>
            </div>

            <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-4">
              {/* Primary Toggle: Auto Read Responses */}
              <div className="flex items-center justify-between pb-3 border-b border-zinc-850">
                <div className="space-y-0.5 pr-4">
                  <div className="font-medium text-zinc-200">
                    {lang === 'th'
                      ? 'อ่านออกเสียงคำตอบใหม่ของ AI อัตโนมัติ'
                      : 'Auto-read new agent responses'}
                  </div>
                  <p className="text-[11px] text-zinc-400">
                    {lang === 'th'
                      ? 'เมื่อ AI ส่งคำตอบเสร็จสิ้น ระบบจะเริ่มสังเคราะห์เสียงและอ่านคำตอบให้ฟังทันที'
                      : 'Automatically trigger text-to-speech when an agent completes a new message'}
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={settings.autoReadResponses}
                    onChange={(e) =>
                      setSettings((prev) => ({
                        ...prev,
                        autoReadResponses: e.target.checked,
                      }))
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              {/* Auto Read Scope Mode: Summary First vs Full Text */}
              {settings.autoReadResponses && (
                <div className="space-y-2 pt-1 animate-in fade-in duration-200">
                  <span className="text-zinc-400 font-medium block">
                    {lang === 'th' ? 'รูปแบบขอบเขตการอ่านเสียง:' : 'Playback Scope Mode:'}
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <label
                      onClick={() =>
                        setSettings((prev) => ({ ...prev, autoReadMode: 'summary' }))
                      }
                      className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        settings.autoReadMode === 'summary'
                          ? 'bg-cyan-950/40 border-cyan-500 text-zinc-100'
                          : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700 text-zinc-400'
                      }`}
                    >
                      <input
                        type="radio"
                        name="autoReadMode"
                        checked={settings.autoReadMode === 'summary'}
                        onChange={() => {}}
                        className="mt-0.5 accent-cyan-400"
                      />
                      <div className="space-y-0.5">
                        <div className="font-semibold text-xs text-zinc-200">
                          {lang === 'th' ? '🎯 อ่านสรุปสาระสำคัญก่อน (แนะนำ)' : '🎯 Summary First (Recommended)'}
                        </div>
                        <div className="text-[11px] text-zinc-500 leading-snug">
                          {lang === 'th'
                            ? 'อ่านเฉพาะข้อความสรุปสั้นหรือสาระสำคัญ ไม่รบกวนสมาธิ'
                            : 'Reads concise summary or key takeaways first'}
                        </div>
                      </div>
                    </label>

                    <label
                      onClick={() =>
                        setSettings((prev) => ({ ...prev, autoReadMode: 'full' }))
                      }
                      className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        settings.autoReadMode === 'full'
                          ? 'bg-cyan-950/40 border-cyan-500 text-zinc-100'
                          : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700 text-zinc-400'
                      }`}
                    >
                      <input
                        type="radio"
                        name="autoReadMode"
                        checked={settings.autoReadMode === 'full'}
                        onChange={() => {}}
                        className="mt-0.5 accent-cyan-400"
                      />
                      <div className="space-y-0.5">
                        <div className="font-semibold text-xs text-zinc-200">
                          {lang === 'th' ? '📖 อ่านเนื้อหาทั้งหมด (Full Text)' : '📖 Full Response'}
                        </div>
                        <div className="text-[11px] text-zinc-500 leading-snug">
                          {lang === 'th'
                            ? 'อ่านเนื้อหาทั้งหมดของข้อความตั้งแต่ต้นจนจบ'
                            : 'Reads the entire response text from start to end'}
                        </div>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* Status Audio Alert Toggle */}
              <div className="flex items-center justify-between pt-1">
                <div className="space-y-0.5 pr-4">
                  <div className="font-medium text-zinc-300 flex items-center gap-1.5">
                    <BellRing className="w-3.5 h-3.5 text-amber-400" />
                    <span>
                      {lang === 'th'
                        ? 'เสียงกระดิ่งแจ้งเตือนเมื่อรอการอนุมัติหรือติดขัด (BLOCKED / APPROVAL)'
                        : 'Audio chime on WAITING_APPROVAL / BLOCKED status'}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-500">
                    {lang === 'th'
                      ? 'ส่งเสียงเตือนเบาๆ ทันทีที่ระบบมีข้อเสนอรออนุมัติหรือถูกปฏิเสธ'
                      : 'Play soft chime notification when agent requires your approval'}
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={settings.alertOnBlockedOrApproval}
                    onChange={(e) =>
                      setSettings((prev) => ({
                        ...prev,
                        alertOnBlockedOrApproval: e.target.checked,
                      }))
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-zinc-800 bg-zinc-950/80">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-zinc-200 text-xs font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'คืนค่าเริ่มต้น' : 'Reset Defaults'}</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold transition-colors"
            >
              {lang === 'th' ? 'ยกเลิก' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-zinc-950 text-xs font-bold shadow-lg shadow-cyan-500/20 transition-all"
            >
              {saveSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>{lang === 'th' ? 'บันทึกสำเร็จ ✓' : 'Saved ✓'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{lang === 'th' ? 'บันทึกการตั้งค่า' : 'Save Voice Settings'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
