import { useCallback, useEffect, useState } from 'react';
import { X, RefreshCw } from 'lucide-react';
import { UnifiedBuildView } from './views/UnifiedBuildView';
import { ProjectsView } from './views/ProjectsView';

/**
 * Companion panel of the single Chat workspace. Every tab reads/writes an EXISTING backend route; nothing here is simulated.
 * When a call fails the real HTTP status and error text are shown (and kept in the Status tab), never a placeholder.
 */
export type WorkspaceTab = 'plan' | 'build' | 'projects' | 'files' | 'diff' | 'run' | 'status';

const TABS: { id: WorkspaceTab; label: string }[] = [
  { id: 'plan', label: 'Plan' },
  { id: 'build', label: 'Build' },
  { id: 'projects', label: 'Projects' },
  { id: 'files', label: 'Files' },
  { id: 'diff', label: 'Diff & Approval' },
  { id: 'run', label: 'Run & Test' },
  { id: 'status', label: 'Status' },
];

export interface BackendErrorEntry { at: string; where: string; message: string }

interface CallResult<T = any> { ok: boolean; status: number; data: T | null; error: string | null }

async function call<T = any>(path: string, token: string, init?: { method?: string; body?: unknown }): Promise<CallResult<T>> {
  try {
    const res = await fetch(path, {
      method: init?.method || 'GET',
      headers: { ...(init?.body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });
    let data: any = null;
    try { data = await res.json(); } catch { /* non-JSON body */ }
    if (!res.ok) return { ok: false, status: res.status, data, error: String(data?.error || data?.message || data?.code || `HTTP ${res.status}`) };
    return { ok: true, status: res.status, data, error: null };
  } catch (e: any) {
    return { ok: false, status: 0, data: null, error: `เชื่อมต่อ backend ไม่ได้: ${e?.message || e}` };
  }
}

const authHint = (r: CallResult) => (r.status === 401 || r.status === 503 ? ' (ต้องใส่ API token ในเมนู "+" ของช่องแชท และตั้ง APPHUB_AUTH_TOKEN บนเซิร์ฟเวอร์)' : '');

function ErrorBox({ r }: { r: CallResult | null }) {
  if (!r || r.ok) return null;
  return <div role="alert" className="m-2 rounded border border-rose-800 bg-rose-950/40 p-2 text-[11px] text-rose-300">HTTP {r.status || '—'}: {r.error}{authHint(r)}</div>;
}

function Badge({ text }: { text: string }) {
  const good = /SUCCEEDED|VERIFIED|APPLIED|APPROVED|PASS/.test(text);
  const bad = /FAIL|BLOCK|REJECT/.test(text);
  return <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono border ${good ? 'border-emerald-700 text-emerald-300' : bad ? 'border-rose-700 text-rose-300' : 'border-slate-600 text-slate-300'}`}>{text}</span>;
}

function PlanTab({ token, log }: { token: string; log: (w: string, m: string) => void }) {
  const [r, setR] = useState<CallResult | null>(null);
  const [busy, setBusy] = useState('');
  const load = useCallback(async () => { const x = await call('/api/plans', token); setR(x); if (!x.ok) log('GET /api/plans', x.error || ''); }, [token, log]);
  useEffect(() => { void load(); }, [load]);
  const act = async (id: string, action: string, body?: unknown) => {
    setBusy(id + action);
    const x = await call(`/api/plans/${encodeURIComponent(id)}/${action}`, token, { method: 'POST', body: body ?? {} });
    if (!x.ok) { log(`POST /api/plans/${id}/${action}`, x.error || ''); setR(x); } else await load();
    setBusy('');
  };
  const plans: any[] = r?.ok ? (r.data?.plans || []) : [];
  return (
    <div>
      <ErrorBox r={r} />
      {r?.ok && plans.length === 0 && <p className="p-3 text-xs text-slate-400">ยังไม่มีแผนใน backend (แผนจะแสดงเมื่อถูกสร้างผ่าน /api/plans)</p>}
      {plans.map((p) => (
        <div key={p.id} className="m-2 rounded-lg border border-slate-700 bg-slate-900/60 p-2 text-xs">
          <div className="flex items-start justify-between gap-2"><span className="font-semibold text-slate-100">{p.goal}</span><Badge text={p.status} /></div>
          <div className="mt-1 text-[10px] text-slate-400">ความเสี่ยง {p.riskLevel} · rev {p.revision}</div>
          <ol className="mt-1 list-decimal pl-4 space-y-0.5">
            {(p.steps || []).map((s: any) => <li key={s.id}><span className="font-mono text-cyan-300">{s.tool}</span> <Badge text={s.status} />{s.error ? <span className="text-rose-300"> — {s.error}</span> : null}</li>)}
          </ol>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {p.status === 'PROPOSED' && <button type="button" disabled={!!busy} onClick={() => act(p.id, 'request-approval')} className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600">ขออนุมัติ</button>}
            {p.status === 'WAITING_APPROVAL' && <>
              <button type="button" disabled={!!busy} onClick={() => act(p.id, 'approve', { planHash: p.hash })} className="px-2 py-1 rounded bg-emerald-700 hover:bg-emerald-600">อนุมัติ</button>
              <button type="button" disabled={!!busy} onClick={() => act(p.id, 'reject')} className="px-2 py-1 rounded bg-rose-800 hover:bg-rose-700">ปฏิเสธ</button>
            </>}
            {p.status === 'APPROVED' && p.approval && <button type="button" disabled={!!busy} onClick={() => act(p.id, 'execute', { approvalId: p.approval.id })} className="px-2 py-1 rounded bg-cyan-700 hover:bg-cyan-600">รันแผน</button>}
          </div>
          {p.honestReport && <p className="mt-2 text-[11px] text-slate-300">{p.honestReport.summary}</p>}
        </div>
      ))}
    </div>
  );
}

function TreeNodes({ nodes, onOpen, depth = 0 }: { nodes: any[]; onOpen: (path: string) => void; depth?: number }) {
  return <ul>{nodes.map((n) => (
    <li key={n.path || n.name} style={{ paddingLeft: depth * 10 }}>
      {n.children ? <><div className="text-slate-400">📁 {n.name}</div><TreeNodes nodes={n.children} onOpen={onOpen} depth={depth + 1} /></>
        : <button type="button" onClick={() => onOpen(n.path || n.name)} className="text-left text-cyan-300 hover:underline">{n.name}</button>}
    </li>))}</ul>;
}

function FilesTab({ token, log }: { token: string; log: (w: string, m: string) => void }) {
  const [tree, setTree] = useState<CallResult | null>(null);
  const [file, setFile] = useState<CallResult | null>(null);
  const [open, setOpen] = useState('');
  const load = useCallback(async () => { const x = await call('/api/workspace/tree', token); setTree(x); if (!x.ok) log('GET /api/workspace/tree', x.error || ''); }, [token, log]);
  useEffect(() => { void load(); }, [load]);
  const view = async (path: string) => { setOpen(path); const x = await call(`/api/files/${encodeURIComponent(path)}`, token); setFile(x); if (!x.ok) log(`GET /api/files/${path}`, x.error || ''); };
  const nodes: any[] = tree?.ok ? (tree.data?.tree || []) : [];
  return (
    <div className="text-xs">
      <ErrorBox r={tree} />
      {tree?.ok && nodes.length === 0 && <p className="p-3 text-slate-400">Workspace ยังไม่มีไฟล์ (ไฟล์ใหม่ต้องผ่าน Diff & Approval)</p>}
      <div className="p-2 max-h-48 overflow-auto font-mono"><TreeNodes nodes={nodes} onOpen={view} /></div>
      {open && <div className="border-t border-slate-800 p-2"><div className="mb-1 font-mono text-slate-300">{open}</div><ErrorBox r={file} />{file?.ok && <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded bg-black/40 p-2 text-[11px]">{String(file.data?.file?.content ?? '').slice(0, 6000)}</pre>}</div>}
    </div>
  );
}

function DiffTab({ token, log }: { token: string; log: (w: string, m: string) => void }) {
  const [r, setR] = useState<CallResult | null>(null);
  const [busy, setBusy] = useState('');
  const load = useCallback(async () => { const x = await call('/api/proposals', token); setR(x); if (!x.ok) log('GET /api/proposals', x.error || ''); }, [token, log]);
  useEffect(() => { void load(); }, [load]);
  const act = async (id: string, action: string, body?: unknown) => {
    setBusy(id);
    const x = await call(`/api/proposals/${encodeURIComponent(id)}/${action}`, token, { method: 'POST', body: body ?? {} });
    if (!x.ok) { log(`POST /api/proposals/${id}/${action}`, x.error || ''); setR(x); } else await load();
    setBusy('');
  };
  const list: any[] = r?.ok ? (r.data?.proposals || []) : [];
  return (
    <div>
      <ErrorBox r={r} />
      {r?.ok && list.length === 0 && <p className="p-3 text-xs text-slate-400">ไม่มี proposal รออนุมัติ การเขียนไฟล์ทุกครั้งต้องสร้าง proposal และอนุมัติก่อน</p>}
      {list.map((p) => (
        <div key={p.id} className="m-2 rounded-lg border border-slate-700 bg-slate-900/60 p-2 text-xs">
          <div className="flex justify-between gap-2"><span className="font-mono text-slate-100">{p.type} {p.name}</span><Badge text={p.status} /></div>
          <div className="text-[10px] text-slate-400">ความเสี่ยง {p.riskLevel}{p.impactList?.length ? ` · กระทบ ${p.impactList.join(', ')}` : ''}</div>
          <pre className="mt-1 max-h-56 overflow-auto rounded bg-black/40 p-2 text-[11px] whitespace-pre-wrap">{p.diff}</pre>
          <div className="mt-2 flex gap-1.5">
            {p.status === 'WAITING_APPROVAL' && <>
              <button type="button" disabled={busy === p.id} onClick={() => act(p.id, 'approve', { hash: p.hash })} className="px-2 py-1 rounded bg-emerald-700 hover:bg-emerald-600">อนุมัติ</button>
              <button type="button" disabled={busy === p.id} onClick={() => act(p.id, 'reject')} className="px-2 py-1 rounded bg-rose-800 hover:bg-rose-700">ปฏิเสธ</button>
            </>}
            {p.status === 'APPROVED' && p.approval && <button type="button" disabled={busy === p.id} onClick={() => act(p.id, 'apply', { approvalId: p.approval.id })} className="px-2 py-1 rounded bg-cyan-700 hover:bg-cyan-600">เขียนไฟล์ (apply)</button>}
          </div>
        </div>
      ))}
    </div>
  );
}

const RUN_TASKS = ['syntax_check', 'typecheck', 'test', 'build'] as const;

function RunTab({ token, log }: { token: string; log: (w: string, m: string) => void }) {
  const [status, setStatus] = useState<CallResult | null>(null);
  const [runs, setRuns] = useState<{ task: string; r: CallResult }[]>([]);
  const [running, setRunning] = useState('');
  useEffect(() => { void call('/api/sandbox/status', token).then(setStatus); }, [token]);
  const run = async (task: string) => {
    setRunning(task);
    const r = await call('/api/sandbox/run', token, { method: 'POST', body: { taskType: task, timeoutMs: 30000, mode: 'code' } });
    if (!r.ok) log(`POST /api/sandbox/run ${task}`, r.error || '');
    setRuns((prev) => [{ task, r }, ...prev].slice(0, 6));
    setRunning('');
  };
  const sb = status?.ok ? status.data?.sandbox : null;
  return (
    <div className="text-xs">
      <ErrorBox r={status} />
      {sb && <p className="p-2 text-[10px] text-slate-400">sandbox: network isolated = {String(sb.networkIsolated)} · timeout {sb.resourceLimits?.timeoutMs} ms · install deps: {sb.dependenciesInstallation}</p>}
      <div className="flex flex-wrap gap-1.5 p-2">{RUN_TASKS.map((t) => <button key={t} type="button" disabled={!!running} onClick={() => run(t)} className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-50">{running === t ? `กำลังรัน ${t}…` : t}</button>)}</div>
      {runs.map((x, i) => (
        <div key={i} className="m-2 rounded-lg border border-slate-700 bg-slate-900/60 p-2">
          <div className="flex justify-between"><span className="font-mono">{x.task}</span>{x.r.ok ? <Badge text={x.r.data?.status} /> : <Badge text={`HTTP ${x.r.status}`} />}</div>
          {x.r.ok ? <>
            <div className="text-[10px] text-slate-400">exit {x.r.data?.exitCode} · {x.r.data?.durationMs} ms{x.r.data?.reason ? ` · ${x.r.data.reason}` : ''}</div>
            {(x.r.data?.stdout || x.r.data?.stderr) && <pre className="mt-1 max-h-48 overflow-auto rounded bg-black/40 p-2 text-[11px] whitespace-pre-wrap">{`${x.r.data.stdout || ''}${x.r.data.stderr ? `\n[stderr]\n${x.r.data.stderr}` : ''}`}</pre>}
          </> : <div className="text-rose-300">{x.r.error}</div>}
        </div>
      ))}
    </div>
  );
}

function StatusTab({ token, errors }: { token: string; errors: BackendErrorEntry[] }) {
  const [health, setHealth] = useState<CallResult | null>(null);
  const [pre, setPre] = useState<CallResult | null>(null);
  const refresh = useCallback(async () => { setHealth(await call('/api/health', token)); setPre(await call('/api/preflight', token)); }, [token]);
  useEffect(() => { void refresh(); }, [refresh]);
  return (
    <div className="text-xs">
      <div className="flex justify-end p-2"><button type="button" onClick={() => void refresh()} className="flex items-center gap-1 text-cyan-300"><RefreshCw size={12} /> ตรวจอีกครั้ง</button></div>
      <ErrorBox r={health} /><ErrorBox r={pre} />
      {health?.ok && <p className="px-3 text-slate-300">Core API: {health.data?.status} — {health.data?.message}</p>}
      {pre?.ok && (
        <div className="p-3">
          <div>Preflight: <Badge text={pre.data?.overall} />{pre.data?.firstFailure ? ` ล้มที่ ${pre.data.firstFailure}` : ''}</div>
          <ul className="mt-1 space-y-0.5">{(pre.data?.checks || []).map((c: any) => <li key={c.id}><Badge text={c.status} /> {c.label} <span className="text-slate-500">[{c.basis}]</span></li>)}</ul>
        </div>
      )}
      <div className="border-t border-slate-800 p-3">
        <div className="font-semibold text-slate-200">ข้อผิดพลาดจาก backend ในเซสชันนี้</div>
        {errors.length === 0 ? <p className="text-slate-400">ยังไม่มี</p> : <ul className="mt-1 space-y-1">{errors.map((e, i) => <li key={i} className="text-rose-300"><span className="text-slate-500">{e.at}</span> {e.where}: {e.message}</li>)}</ul>}
      </div>
    </div>
  );
}

export function WorkspacePanel({
  apiToken,
  tab: controlledTab,
  onTabChange,
  onClose,
  onSendBuildPrompt,
  onSendBuildPromptNow,
}: {
  apiToken: string;
  tab?: WorkspaceTab;
  onTabChange?: (t: WorkspaceTab) => void;
  onClose: () => void;
  onSendBuildPrompt?: (prompt: string) => void;
  onSendBuildPromptNow?: (prompt: string) => void;
}) {
  const [internalTab, setInternalTab] = useState<WorkspaceTab>('plan');
  const tab = controlledTab ?? internalTab;
  const setTab = onTabChange ?? setInternalTab;
  const wide = tab === 'build' || tab === 'projects';
  const [errors, setErrors] = useState<BackendErrorEntry[]>([]);
  const log = useCallback((where: string, message: string) => setErrors((p) => [{ at: new Date().toLocaleTimeString(), where, message }, ...p].slice(0, 20)), []);
  return (
    <aside data-testid="workspace-panel" aria-label="Workspace panel" className={`fixed inset-0 z-40 flex flex-col bg-[#07112B] text-slate-200 lg:static lg:inset-auto lg:z-auto ${wide ? 'lg:w-[min(960px,65vw)]' : 'lg:w-[420px]'} lg:shrink-0 lg:border-l lg:border-cyan-500/20`}>
      <div className="flex items-center justify-between gap-2 border-b border-slate-800 px-2 py-2 pt-[max(0.5rem,env(safe-area-inset-top))] sm:px-3">
        <div role="tablist" className="flex min-w-0 flex-1 gap-1 overflow-x-auto whitespace-nowrap [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {TABS.map((t) => <button key={t.id} role="tab" aria-selected={tab === t.id} type="button" onClick={() => setTab(t.id)} className={`shrink-0 px-3 py-2 rounded text-xs sm:px-2 sm:py-1 ${tab === t.id ? 'bg-cyan-600/30 text-cyan-200' : 'text-slate-400 hover:text-white'}`}>{t.label}</button>)}
        </div>
        <button type="button" onClick={onClose} aria-label="ปิดแผง Workspace" className="shrink-0 p-2 text-slate-400 hover:text-white"><X size={16} /></button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {tab === 'plan' && <PlanTab token={apiToken} log={log} />}
        {tab === 'build' && <div className="flex h-full min-h-[70vh] flex-col"><UnifiedBuildView lang="th" onSwitchToChat={onClose} onSendBuildPrompt={onSendBuildPrompt} onSendBuildPromptNow={onSendBuildPromptNow} /></div>}
        {tab === 'projects' && <ProjectsView lang="th" onOpenProjectInBuild={() => setTab('build')} />}
        {tab === 'files' && <FilesTab token={apiToken} log={log} />}
        {tab === 'diff' && <DiffTab token={apiToken} log={log} />}
        {tab === 'run' && <RunTab token={apiToken} log={log} />}
        {tab === 'status' && <StatusTab token={apiToken} errors={errors} />}
      </div>
    </aside>
  );
}

export default WorkspacePanel;
