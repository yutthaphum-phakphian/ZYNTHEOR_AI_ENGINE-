import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  UploadCloud,
  FileCode2,
  FileText,
  Image as ImageIcon,
  Download,
  Share2,
  Sparkles,
  PanelLeft,
  LayoutGrid,
  Bot,
  Zap,
  Sun,
  Moon,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  Wifi,
  WifiOff,
  Search,
  X,
  Trash2,
  ListChecks,
  MessageSquare,
} from 'lucide-react';
import { ChatSession, ChatMessage, AttachedFile, ReactionEmoji } from '../types/agent';
import { CommandInput } from './CommandInput';
import { ConversationMessageView } from './ConversationMessageView';
import { processFileToAttachedFile } from '../utils/fileHelper';
import { getVoiceSettings, speakText, playStatusChime, speakStatusNotification } from '../utils/voiceSettings';
import { AssistantTools } from './AssistantTools';
import {
  AUTO_BACKUP_INTERVAL_MS,
  createAutoBackupSnapshot,
  generateQuickReplies,
} from '../utils/newFeatureLogic';
import { CopilotPlanExecutionProgressBar } from './CopilotPlanExecutionProgressBar';
import { ChatModeSheet } from './ChatModeSheet';
import { EngineModeSelector, toChatMode, toPreferredDepth, DEFAULT_CUSTOM_UI_CONFIG, type EngineChoice, type RouteState, type CustomEngineConfig } from './EngineModeSelector';
import { SelfImprovementIndicator } from './SelfImprovementIndicator';
import { Plan as CopilotPlan } from '../../features/copilot/plans/types';

interface ChatWorkspaceProps {
  session: ChatSession;
  onUpdateSession: (updated: ChatSession) => void;
  onToggleSidebar: () => void;
  onToggleProductivity: () => void;
  isSidebarOpen: boolean;
  isProductivityOpen: boolean;
  onOpenShortcutsModal: () => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  attachedFiles?: AttachedFile[];
  onAttachedFilesChange?: (files: AttachedFile[]) => void;
}

export const ChatWorkspace: React.FC<ChatWorkspaceProps> = ({
  session,
  onUpdateSession,
  onToggleSidebar,
  onToggleProductivity,
  isSidebarOpen,
  isProductivityOpen,
  onOpenShortcutsModal,
  theme,
  onToggleTheme,
  attachedFiles: propAttachedFiles,
  onAttachedFilesChange,
}) => {
  const [localAttachedFiles, setLocalAttachedFiles] = useState<AttachedFile[]>([]);
  const attachedFiles = propAttachedFiles ?? localAttachedFiles;
  const setAttachedFiles = (filesOrUpdater: AttachedFile[] | ((prev: AttachedFile[]) => AttachedFile[])) => {
    if (typeof filesOrUpdater === 'function') {
      const next = filesOrUpdater(attachedFiles);
      if (onAttachedFilesChange) onAttachedFilesChange(next);
      else setLocalAttachedFiles(next);
    } else {
      if (onAttachedFilesChange) onAttachedFilesChange(filesOrUpdater);
      else setLocalAttachedFiles(filesOrUpdater);
    }
  };

  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [isAgentThinking, setIsAgentThinking] = useState(false);
  const dragCounter = useRef(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const activeSessionIdRef = useRef(session.id);
  const previousSessionRef = useRef(session);

  if (activeSessionIdRef.current !== session.id) {
    try {
      localStorage.setItem('sraang_active_session_recovery', JSON.stringify(previousSessionRef.current));
    } catch (error) {
      console.warn('Active session recovery save error:', error);
    }
    activeSessionIdRef.current = session.id;
  }
  previousSessionRef.current = session;

  const [autoSaveState, setAutoSaveState] = useState<'saved' | 'saving'>('saved');
  const [lastSavedAt, setLastSavedAt] = useState<number>(() => Date.now());

  // Message search within active session
  const [messageSearchQuery, setMessageSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const filteredMessages = useMemo(() => {
    const q = messageSearchQuery.trim().toLowerCase();
    if (!q) return session.messages;
    return session.messages.filter((msg) =>
      msg.content.toLowerCase().includes(q) ||
      msg.attachedFiles?.some((f) => f.name.toLowerCase().includes(q))
    );
  }, [session.messages, messageSearchQuery]);

  // Active Copilot Plan Execution State & Progress
  const [activeCopilotPlan, setActiveCopilotPlan] = useState<CopilotPlan | null>(null);
  const [isPlanExecuting, setIsPlanExecuting] = useState(false);
  const [engineChoice, setEngineChoice] = useState<EngineChoice>('auto');
  const [lastProposedPlan, setLastProposedPlan] = useState<{
    id: string;
    goal: string;
    status: string;
    hash?: string;
    riskLevel?: string;
  } | null>(null);
  const [planActionBusy, setPlanActionBusy] = useState(false);
  const [planActionMsg, setPlanActionMsg] = useState<string | null>(null);
  const [customConfig, setCustomConfig] = useState<CustomEngineConfig>(DEFAULT_CUSTOM_UI_CONFIG);
  const [routeState, setRouteState] = useState<RouteState>({ kind: 'idle' });
  const [planExecutionElapsed, setPlanExecutionElapsed] = useState(0);

  // Launch Copilot Plan execution helper
  const handleLaunchCopilotPlanExecution = async (planId?: string, rawPlan?: any) => {
    if (rawPlan) {
      const cp: CopilotPlan = {
        id: rawPlan.id || `plan-${Date.now()}`,
        title: rawPlan.title || rawPlan.goal || 'Copilot Plan',
        description: rawPlan.description || rawPlan.goal,
        status: 'active',
        progress: rawPlan.progress || 0,
        steps: (rawPlan.steps || []).map((s: any, idx: number) => ({
          id: s.id || `step-${idx + 1}`,
          title: s.title || s.id,
          status: s.status === 'succeeded' || s.status === 'done' ? 'done' : s.status === 'running' || s.status === 'in_progress' ? 'in_progress' : 'pending',
        })),
        createdAt: rawPlan.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setActiveCopilotPlan(cp);
      setIsPlanExecuting(true);
      setPlanExecutionElapsed(0);
      return;
    }

    try {
      const res = await fetch(planId ? `/api/copilot/plans/${planId}` : '/api/copilot/plans');
      if (res.ok) {
        const data = await res.json();
        const target = planId ? data.plan : (data.plans && data.plans.length > 0 ? data.plans[0] : null);
        if (target) {
          setActiveCopilotPlan(target);
          setIsPlanExecuting(true);
          setPlanExecutionElapsed(0);
          return;
        }
      }
    } catch (e) {
      console.warn('Failed to fetch copilot plan:', e);
    }

    // No sample fallback: if no real plan exists, say so instead of faking one.
    setActiveCopilotPlan(null);
    setIsPlanExecuting(false);
    console.warn('No Copilot Plan available to execute');
  };

  // Listen to external execute plan events (e.g. from TaskPlanCard or PlansStudioView)
  useEffect(() => {
    const handleExecEvent = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      handleLaunchCopilotPlanExecution(detail?.planId, detail?.plan);
    };
    window.addEventListener('zyntheor-execute-copilot-plan', handleExecEvent);
    return () => {
      window.removeEventListener('zyntheor-execute-copilot-plan', handleExecEvent);
    };
  }, []);

  // Capture plans proposed from /api/chat (Planning Mode) for in-chat approve / Build handoff
  useEffect(() => {
    const onProposed = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      const p = detail?.plan;
      if (!p?.id) return;
      setLastProposedPlan({
        id: p.id,
        goal: p.goal || detail?.planning?.goal || '',
        status: p.status || 'WAITING_APPROVAL',
        hash: p.hash,
        riskLevel: p.riskLevel || detail?.planning?.riskLevel,
      });
      setPlanActionMsg(null);
    };
    window.addEventListener('zyntheor-plan-proposed', onProposed);
    return () => window.removeEventListener('zyntheor-plan-proposed', onProposed);
  }, []);

  const handleApproveLastPlan = async () => {
    if (!lastProposedPlan?.id || !lastProposedPlan.hash) {
      setPlanActionMsg('ไม่พบ plan hash สำหรับอนุมัติ');
      return;
    }
    setPlanActionBusy(true);
    setPlanActionMsg(null);
    try {
      const res = await fetch(`/api/plans/${encodeURIComponent(lastProposedPlan.id)}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planHash: lastProposedPlan.hash }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setPlanActionMsg(data.message || data.error || `อนุมัติไม่สำเร็จ (${res.status})`);
        return;
      }
      setLastProposedPlan((prev) =>
        prev ? { ...prev, status: data.plan?.status || 'APPROVED' } : prev
      );
      setPlanActionMsg('อนุมัติแผนแล้ว — กด「ไป Build」เพื่อสร้าง diff/proposal (บทสนทนานี้ยังอยู่)');
    } catch (e: any) {
      setPlanActionMsg(e?.message || 'เครือข่ายล้มเหลว');
    } finally {
      setPlanActionBusy(false);
    }
  };

  const handleRejectLastPlan = async () => {
    if (!lastProposedPlan?.id) return;
    setPlanActionBusy(true);
    setPlanActionMsg(null);
    try {
      const res = await fetch(`/api/plans/${encodeURIComponent(lastProposedPlan.id)}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setPlanActionMsg(data.message || data.error || `ปฏิเสธไม่สำเร็จ (${res.status})`);
        return;
      }
      setLastProposedPlan((prev) =>
        prev ? { ...prev, status: data.plan?.status || 'REJECTED' } : prev
      );
      setPlanActionMsg('ปฏิเสธแผนแล้ว — ปรับเป้าหมายแล้วส่ง Planning ใหม่ได้');
    } catch (e: any) {
      setPlanActionMsg(e?.message || 'เครือข่ายล้มเหลว');
    } finally {
      setPlanActionBusy(false);
    }
  };

  const handleGoBuild = () => {
    try {
      window.dispatchEvent(
        new CustomEvent('zyntheor-navigate-mode', {
          detail: { mode: 'build', planId: lastProposedPlan?.id },
        })
      );
    } catch { /* ignore */ }
    setPlanActionMsg('ส่งคำขอเปิดแท็บ Build แล้ว — ถ้าแท็บไม่เปลี่ยน ให้คลิก Build ในแถบด้านข้าง');
  };

  // Engine API connection health (real probe — never faked)
  type EngineHealth = {
    status: 'checking' | 'online' | 'offline' | 'degraded';
    detail: string;
    lastCheckedAt: number | null;
    correlationId?: string;
  };
  const [engineHealth, setEngineHealth] = useState<EngineHealth>({
    status: 'checking',
    detail: 'กำลังตรวจสอบการเชื่อมต่อ Local Engine...',
    lastCheckedAt: null,
  });

  const probeEngineHealth = async () => {
    setEngineHealth((prev) => ({ ...prev, status: 'checking', detail: 'กำลังตรวจสอบ /api/health...' }));
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 8000);
      const res = await fetch('/api/health', { method: 'GET', signal: controller.signal });
      window.clearTimeout(timer);
      const data = await res.json().catch(() => ({}));
      if (res.ok && (data.status === 'available' || data.status === 'ok' || data.status === 'healthy')) {
        setEngineHealth({
          status: 'online',
          detail: `Engine ออนไลน์ · ${data.service || 'apphub-ai-agent'} · ${data.time || new Date().toISOString()}`,
          lastCheckedAt: Date.now(),
          correlationId: data.correlationId,
        });
      } else {
        setEngineHealth({
          status: 'degraded',
          detail: `Health ตอบกลับผิดปกติ (HTTP ${res.status}): ${data.message || data.error || data.status || 'unknown'}`,
          lastCheckedAt: Date.now(),
          correlationId: data.correlationId,
        });
      }
    } catch (err: any) {
      const reason =
        err?.name === 'AbortError'
          ? 'หมดเวลาเชื่อมต่อ (timeout 8s) — เซิร์ฟเวอร์อาจไม่ทำงาน'
          : err?.message
            ? `เครือข่ายล้มเหลว: ${err.message}`
            : 'ไม่สามารถเชื่อมต่อ Local Engine ได้ (fetch failed)';
      setEngineHealth({
        status: 'offline',
        detail: reason,
        lastCheckedAt: Date.now(),
      });
    }
  };

  useEffect(() => {
    probeEngineHealth();
    const id = window.setInterval(probeEngineHealth, 30000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    setAutoSaveState('saving');
    const snapshot = JSON.stringify(session);
    const saveRecoverySnapshot = () => {
      try {
        localStorage.setItem('sraang_active_session_recovery', snapshot);
        setAutoSaveState('saved');
        setLastSavedAt(Date.now());
      } catch (error) {
        console.warn('Active session recovery save error:', error);
      }
    };
    const timeoutId = window.setTimeout(saveRecoverySnapshot, 500);
    window.addEventListener('pagehide', saveRecoverySnapshot);
    return () => {
      window.clearTimeout(timeoutId);
      window.removeEventListener('pagehide', saveRecoverySnapshot);
    };
  }, [session]);

  // Automatic local JSON backup every five minutes. LocalStorage is the durable fallback;
  // the last snapshot can always be downloaded as a portable JSON file.
  useEffect(() => {
    const persistBackup = () => {
      try {
        localStorage.setItem('zyntheor_auto_backup', JSON.stringify(createAutoBackupSnapshot(session)));
      } catch (error) { console.warn('Automatic backup error:', error); }
    };
    persistBackup();
    const interval = window.setInterval(persistBackup, AUTO_BACKUP_INTERVAL_MS);
    return () => window.clearInterval(interval);
  }, [session]);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [session.messages, isAgentThinking]);

  // Quick Replies System: analyzes the agent's last response and suggests 3 relevant follow-ups
  const lastAgentMessage = useMemo(() => {
    const reversed = [...session.messages].reverse();
    const agentMsg = reversed.find((m) => m.sender === 'agent' || m.sender === 'system');
    return agentMsg?.content || '';
  }, [session.messages]);

  const quickReplies = useMemo(() => {
    return generateQuickReplies(lastAgentMessage, 'th');
  }, [lastAgentMessage]);

  // Drag and Drop Zone event handlers
  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current += 1;
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDraggingOver(true);
    }
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current -= 1;
    if (dragCounter.current <= 0) {
      setIsDraggingOver(false);
      dragCounter.current = 0;
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    dragCounter.current = 0;

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const newFilesList: AttachedFile[] = [];
      for (let i = 0; i < files.length; i++) {
        const processed = await processFileToAttachedFile(files[i]);
        newFilesList.push(processed);
      }
      setAttachedFiles((prev) => [...prev, ...newFilesList]);
    }
  };

  // Add files from file picker
  const handleAddFiles = (newFiles: AttachedFile[]) => {
    setAttachedFiles((prev) => [...prev, ...newFiles]);
  };

  // Remove file
  const handleRemoveFile = (fileId: string) => {
    setAttachedFiles((prev) => prev.filter((f) => f.id !== fileId));
  };

  // Toggle reaction on a message
  const handleToggleReaction = (messageId: string, emoji: ReactionEmoji) => {
    const updatedMessages = session.messages.map((msg) => {
      if (msg.id !== messageId) return msg;

      const currentReactions = { ...(msg.reactions || {}) };
      const currentUserReactions = [...(msg.userReactions || [])];
      const hasReacted = currentUserReactions.includes(emoji);

      if (hasReacted) {
        // Remove reaction
        const currentCount = currentReactions[emoji] || 1;
        if (currentCount <= 1) {
          delete currentReactions[emoji];
        } else {
          currentReactions[emoji] = currentCount - 1;
        }
        const nextUserReactions = currentUserReactions.filter((e) => e !== emoji);
        return {
          ...msg,
          reactions: currentReactions,
          userReactions: nextUserReactions,
        };
      } else {
        // Add reaction
        currentReactions[emoji] = (currentReactions[emoji] || 0) + 1;
        currentUserReactions.push(emoji);
        return {
          ...msg,
          reactions: currentReactions,
          userReactions: currentUserReactions,
        };
      }
    });

    onUpdateSession({
      ...session,
      messages: updatedMessages,
      updatedAt: Date.now(),
    });
  };

  // Send message and get Agent response
  const handleSendMessage = async (content: string, files: AttachedFile[]) => {
    const userMessage: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      sender: 'user',
      content,
      attachedFiles: [...files],
      timestamp: Date.now(),
      status: 'sent',
    };

    const updatedMessages = [...session.messages, userMessage];
    const conversationContext = {
      conversationId: session.id,
      history: session.messages
        .filter((message) => message.sender === 'user' || message.sender === 'agent')
        .slice(-39)
        .map((message) => ({
          role: message.sender === 'user' ? 'user' : 'assistant',
          content: message.content.slice(0, 8000),
        })),
      ...(toPreferredDepth(engineChoice) ? { depth: toPreferredDepth(engineChoice) } : {}),
    };
    onUpdateSession({
      ...session,
      messages: updatedMessages,
      updatedAt: Date.now(),
    });

    // Clear attached files
    setAttachedFiles([]);
    setIsAgentThinking(true);

    // Ask the engine how it would route this message (real response only; UNAVAILABLE on failure).
    void (async () => {
      try {
        const res = await fetch('/api/engine/route', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: content.slice(0, 8000),
            mode: toChatMode(engineChoice),
            ...(toPreferredDepth(engineChoice) ? { depth: toPreferredDepth(engineChoice) } : {}),
            ...(engineChoice === 'custom' ? { customConfig } : {}),
          }),
        });
        if (!res.ok) throw new Error(String(res.status));
        const data = await res.json();
        setRouteState({ kind: 'ready', decision: data.decision, connectors: data.connectors ?? [], limitations: data.limitations ?? [] });
      } catch {
        setRouteState({ kind: 'unavailable' });
      }
    })();

    try {
      let agentResponseText = '';
      let summary = '';

      if (content.match(/^\/(?:run[-_]?plan|execute[-_]?plan|copilot[-_]?run|plan[-_]?run)\b/i) || content.includes('รันแผนงาน')) {
        handleLaunchCopilotPlanExecution();
      }

      // 1. Direct Sandbox Command Execution (/test, /typecheck, /build, /syntax)
      if (content.match(/^\/(test|typecheck|build|syntax(?:_check)?|sandbox)\b/i)) {
        try {
          const res = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: content, mode: 'auto', ...conversationContext }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.assistantMessage?.content) {
              agentResponseText = data.assistantMessage.content;
              summary = `ผลการรัน Sandbox: ${data.taskType || 'task'} (${data.sandboxResult?.status || data.status || 'UNKNOWN'})`;
            }
          }
        } catch (e) {
          console.warn('Sandbox task execution error:', e);
        }
      } else if (
        content.startsWith('/') ||
        content.includes('สร้างแอป') ||
        content.includes('สร้างเว็บ') ||
        content.includes('เปลี่ยนสี') ||
        content.includes('แก้') ||
        content.includes('สร้าง') ||
        content.includes('โค้ด') ||
        content.includes('ไฟล์') ||
        content.includes('ตรวจ') ||
        content.includes('ทดสอบ') ||
        content.includes('อธิบาย') ||
        content.includes('explain') ||
        content.includes('verifyIntegrity') ||
        content.includes('agent.ts')
      ) {
        try {
          const res = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: content,
              mode: toChatMode(engineChoice),
              ...conversationContext,
              ...(engineChoice === 'custom' ? { customConfig } : {}),
            }),
          });
          const data = await res.json();
          if (res.ok) {
            if (data.assistantMessage?.content) {
              agentResponseText = data.assistantMessage.content;
              const planId = data.plan?.id ? ` · Plan ${data.plan.id}` : '';
              summary = data.status
                ? `สถานะ: ${String(data.status).toUpperCase()}${planId}`
                : (planId ? planId.trim() : '');
              if (data.plan?.id) {
                try {
                  window.dispatchEvent(
                    new CustomEvent('zyntheor-plan-proposed', { detail: { plan: data.plan, planning: data.planning } })
                  );
                } catch { /* ignore */ }
              }
            }
          } else {
            agentResponseText = `⚠️ **[${(data.status || 'BLOCKED').toUpperCase()}]**: ${data.message || 'คำสั่งถูกปฏิเสธหรือไม่สามารถดำเนินการได้'}`;
            summary = `สถานะ: ${(data.status || 'BLOCKED').toUpperCase()}${data.code ? ` (${data.code})` : ''}`;
          }
        } catch (e) {
          console.warn('Chat API error:', e);
        }
      }

      // Route unsupported prompts to the server so it can report the actual capability status.
      if (!agentResponseText) {
        try {
          const res = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: content,
              mode: toChatMode(engineChoice),
              ...conversationContext,
              ...(engineChoice === 'custom' ? { customConfig } : {}),
            }),
          });
          const data = await res.json();
          agentResponseText = data.assistantMessage?.content ||
            `[${String(data.status || 'UNAVAILABLE').toUpperCase()}] ${data.message || 'No local capability supports this request.'}`;
          const planId = data.plan?.id ? ` · Plan ${data.plan.id}` : '';
          summary = data.status ? `สถานะ: ${String(data.status).toUpperCase()}${planId}` : (planId ? planId.trim() : 'UNAVAILABLE');
          if (data.plan?.id) {
            try {
              window.dispatchEvent(
                new CustomEvent('zyntheor-plan-proposed', { detail: { plan: data.plan, planning: data.planning } })
              );
            } catch { /* ignore */ }
          }
        } catch (netErr: any) {
          const reason = netErr?.message || 'fetch failed';
          agentResponseText =
            `[NOT_AVAILABLE] ไม่สามารถเรียก Local Engine API (/api/chat) ได้\n\n` +
            `**สาเหตุจริง:** ${reason}\n` +
            `**สถานะ Engine:** ${engineHealth.status} — ${engineHealth.detail}\n\n` +
            `กดปุ่ม "ลองใหม่" ที่แถบสถานะด้านบน หรือรัน \`npm run dev\` / \`tsx server.ts\` แล้วลองอีกครั้ง`;
          summary = 'NOT_AVAILABLE (network)';
          // Re-probe so the banner reflects the real outage
          probeEngineHealth();
        }
      }

      const agentMessage: ChatMessage = {
        id: `msg_agent_${Date.now()}`,
        sender: 'agent',
        content: agentResponseText,
        timestamp: Date.now(),
        reactions: { '👍': 1, '💡': 1 },
        summary: summary || undefined,
        status: 'done',
      };

      onUpdateSession({
        ...session,
        messages: [...updatedMessages, agentMessage],
        updatedAt: Date.now(),
      });

      // Auto-read response if user enabled auto-read preferences
      try {
        const vSettings = getVoiceSettings();
        if (vSettings.enabled && vSettings.autoReadResponses) {
          const textToSpeak =
            vSettings.autoReadMode === 'summary' && agentMessage.summary
              ? agentMessage.summary
              : agentMessage.content;
          speakText(textToSpeak, vSettings);
        }
      } catch (voiceErr) {
        console.warn('Voice auto-read error:', voiceErr);
      }
    } finally {
      setIsAgentThinking(false);
    }
  };

  // Export functions
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(session, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${session.title || 'chat-session'}_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportMarkdown = () => {
    let md = `# ${session.title}\n*วันที่: ${new Date(session.createdAt).toLocaleDateString('th-TH')}*\n\n---\n\n`;
    session.messages.forEach((msg) => {
      const sender = msg.sender === 'user' ? '👤 **คุณ (User)**' : '🤖 **AI Agent**';
      const time = new Date(msg.timestamp).toLocaleTimeString('th-TH');
      md += `### ${sender} (${time})\n\n${msg.content}\n\n`;
      if (msg.attachedFiles && msg.attachedFiles.length > 0) {
        md += `*ไฟล์แนบ:* ${msg.attachedFiles.map((f) => `\`${f.name}\``).join(', ')}\n\n`;
      }
      if (msg.reactions && Object.keys(msg.reactions).length > 0) {
        md += `*ปฏิกิริยา:* ${Object.entries(msg.reactions).map(([k, v]) => `${k} (${v})`).join(' ')}\n\n`;
      }
      md += `---\n\n`;
    });

    const dataStr = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(md);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${session.title || 'chat-session'}_${Date.now()}.md`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportPDF = async () => {
    const { jsPDF } = await import('jspdf');
    const pdf = new jsPDF();
    let y = 18;
    pdf.setFontSize(16); pdf.text(session.title || 'Chat session', 14, y); y += 10;
    pdf.setFontSize(9); pdf.text(new Date(session.createdAt).toLocaleString('th-TH'), 14, y); y += 10;
    session.messages.forEach((msg) => {
      const lines = pdf.splitTextToSize(`${msg.sender === 'user' ? 'คุณ' : 'AI'}: ${msg.content.replace(/[#*_`]/g, '')}`, 180);
      if (y > 275) { pdf.addPage(); y = 18; }
      pdf.text(lines, 14, y); y += lines.length * 5 + 5;
    });
    pdf.save(`${session.title || 'chat-session'}-${Date.now()}.pdf`);
  };

  const handleClearContext = () => onUpdateSession({ ...session, messages: [], summary: 'ล้างบริบทแล้ว พร้อมรับคำสั่งใหม่', updatedAt: Date.now() });

  return (
    <div
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className="zy-immersive-chat relative flex-1 flex flex-col h-full bg-zinc-950 overflow-hidden text-zinc-100"
    >
      <AssistantTools
        session={session}
        onSendCommand={(command) => handleSendMessage(command, [])}
        onClearContext={handleClearContext}
        onExportDocument={handleExportPDF}
        onOpenShortcuts={onOpenShortcutsModal}
      />
      {/* Engine Connection Status Banner — real health only */}
      {engineHealth.status !== 'online' && (
        <div
          className={`mx-2 sm:mx-4 mt-2 rounded-xl border px-3 py-2.5 flex flex-wrap items-center gap-2 text-xs ${
            engineHealth.status === 'checking'
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              : engineHealth.status === 'degraded'
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
          role="status"
          aria-live="polite"
        >
          {engineHealth.status === 'offline' ? (
            <WifiOff className="w-4 h-4 shrink-0" />
          ) : engineHealth.status === 'checking' ? (
            <RefreshCw className="w-4 h-4 shrink-0 animate-spin" />
          ) : (
            <AlertTriangle className="w-4 h-4 shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <div className="font-semibold">
              {engineHealth.status === 'offline'
                ? 'Local Engine API ออฟไลน์'
                : engineHealth.status === 'checking'
                  ? 'กำลังตรวจสอบ Engine...'
                  : 'Engine ตอบกลับผิดปกติ'}
            </div>
            <div className="opacity-90 break-words">{engineHealth.detail}</div>
          </div>
          <button
            type="button"
            onClick={() => probeEngineHealth()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 text-zinc-200"
            title="ลองเชื่อมต่อใหม่"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            ลองใหม่
          </button>
        </div>
      )}
      {engineHealth.status === 'online' && (
        <div className="mx-2 sm:mx-4 mt-1.5 flex items-center gap-1.5 text-[10px] font-mono text-emerald-400">
          <Wifi className="w-3 h-3" />
          <span className="truncate">{engineHealth.detail}</span>
        </div>
      )}

      {/* DRAG AND DROP ZONE OVERLAY - Displays when dragging files from OS */}
      {isDraggingOver && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-8 pointer-events-none transition-all duration-200">
          <div className="w-full max-w-xl border border-dashed border-blue-400/80 bg-zinc-900/95 rounded-2xl p-8 flex flex-col items-center justify-center text-center shadow-2xl">
            <div className="w-16 h-16 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 mb-4 shadow-lg shadow-blue-500/10">
              <UploadCloud className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-zinc-100 mb-1">
              วางไฟล์ที่นี่เพื่อแนบเข้าสู่การแชททันที
            </h3>
            <p className="text-xs text-zinc-400 max-w-md mb-5 leading-relaxed">
              ปล่อยไฟล์เพื่อแนบและวิเคราะห์ร่วมกับเอเจนต์อัตโนมัติ
            </p>

            <div className="flex flex-wrap items-center justify-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-850 text-rose-300 text-[11px] font-mono border border-zinc-750">
                <FileText className="w-3.5 h-3.5 text-rose-400" /> PDF
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-850 text-blue-300 text-[11px] font-mono border border-zinc-750">
                <FileCode2 className="w-3.5 h-3.5 text-blue-400" /> JS / TS / Python
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-850 text-amber-300 text-[11px] font-mono border border-zinc-750">
                <ImageIcon className="w-3.5 h-3.5 text-amber-400" /> รูปภาพ & กราฟิก
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-850 text-emerald-300 text-[11px] font-mono border border-zinc-750">
                <FileText className="w-3.5 h-3.5 text-emerald-400" /> TXT / MD / JSON
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Top Bar Contract */}
      <header className="h-14 border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur-md px-4 flex items-center justify-between shrink-0 z-20">
        {/* Zone 1: Breadcrumbs & Title */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onToggleSidebar}
            className={`p-2 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800/80 transition-colors ${
              !isSidebarOpen ? 'bg-zinc-850 text-blue-400' : ''
            }`}
            title="สลับแถบด้านข้าง (Ctrl+B)"
            aria-label="Toggle sidebar"
          >
            <PanelLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 min-w-0 text-xs text-zinc-400">
            <span className="hidden sm:inline text-zinc-500 font-medium">Workspace</span>
            <span className="hidden sm:inline text-zinc-600">/</span>
            <h2 className="font-semibold text-zinc-100 truncate max-w-[200px] sm:max-w-xs md:max-w-md">
              {session.title || 'เซสชันใหม่'}
            </h2>
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span className="text-[11px] text-zinc-400 capitalize truncate">
              {session.category || 'development'}
            </span>
            <span aria-hidden="true" className="hidden md:inline text-zinc-600">·</span>
            <span className="hidden md:inline text-[11px] text-zinc-500 font-mono">
              {autoSaveState === 'saving' ? 'บันทึก...' : 'บันทึกแล้ว'}
            </span>
          </div>
        </div>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-1.5">
          {engineHealth.status !== 'online' && (
            <button
              onClick={() => probeEngineHealth()}
              className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/20"
              title={engineHealth.detail}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{engineHealth.status}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              setIsSearchOpen((prev) => !prev);
              if (!isSearchOpen) {
                setTimeout(() => searchInputRef.current?.focus(), 50);
              }
            }}
            className={`p-2 rounded-lg transition-colors cursor-pointer ${
              isSearchOpen || messageSearchQuery
                ? 'bg-blue-600/30 text-blue-300 border border-blue-500/40'
                : 'text-zinc-400 hover:bg-zinc-850 hover:text-zinc-100'
            }`}
            title="ค้นหาข้อความในการสนทนานี้"
            aria-label="ค้นหาข้อความ"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onToggleTheme}
            className="p-2 rounded-lg text-zinc-400 hover:bg-zinc-850 hover:text-zinc-100 transition-colors"
            title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            onClick={handleExportMarkdown}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-zinc-300 hover:bg-zinc-800 transition-colors border border-zinc-800"
            title="ส่งออกเป็น Markdown (.md)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export MD</span>
          </button>

          <button
            onClick={handleExportJSON}
            className="p-2 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-850 transition-colors"
            title="ส่งออกเป็น JSON"
            aria-label="Export JSON"
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleClearContext}
            disabled={session.messages.length === 0}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
              session.messages.length === 0
                ? 'border-zinc-800 text-zinc-600 cursor-not-allowed opacity-50'
                : 'border-rose-500/30 bg-rose-950/20 text-rose-300 hover:text-white hover:bg-rose-900/30 hover:border-rose-500/50'
            }`}
            title="Clear Conversation — ล้างข้อความในการสนทนาและเริ่มต้นใหม่"
            aria-label="Clear Conversation"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden sm:inline">Clear Conversation</span>
          </button>

          <button
            onClick={onToggleProductivity}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              isProductivityOpen
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-850 border border-zinc-800'
            }`}
            title="แผงประสิทธิภาพ (Todo, Facts, Telemetry) (Ctrl+J)"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Productivity</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (activeCopilotPlan) {
                setIsPlanExecuting(!isPlanExecuting);
              } else {
                handleLaunchCopilotPlanExecution();
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              activeCopilotPlan
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-850 border border-zinc-800'
            }`}
            title="แสดง/ควบคุมความคืบหน้าของ Copilot Plan (Visual Progress Bar / ประมวลผล 11s)"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden lg:inline">Copilot Plan</span>
            {activeCopilotPlan && (
              <span className="text-[10px] font-mono px-1 rounded bg-white/20 text-white font-bold">
                {activeCopilotPlan.progress}%
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Active Copilot Plan Execution Visual Progress Bar */}
      {activeCopilotPlan && (
        <CopilotPlanExecutionProgressBar
          plan={activeCopilotPlan}
          isExecuting={isPlanExecuting}
          initialElapsedSeconds={planExecutionElapsed}
          onUpdatePlan={(updated) => setActiveCopilotPlan(updated)}
          onClose={() => setActiveCopilotPlan(null)}
          lang="th"
        />
      )}

      <EngineModeSelector
        value={engineChoice}
        onChange={setEngineChoice}
        customConfig={customConfig}
        onCustomConfigChange={setCustomConfig}
        route={routeState}
        lang="th"
        hideModeButtons
      />
      <SelfImprovementIndicator lang="th" />

      {/* Message Search Bar within Conversation Area */}
      <div className="px-4 py-2 border-b border-zinc-800/80 bg-zinc-950/90 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-2 max-w-4xl mx-auto">
          <div className="relative flex-1 flex items-center">
            <Search className="w-3.5 h-3.5 absolute left-3 text-zinc-400 pointer-events-none" />
            <input
              ref={searchInputRef}
              type="text"
              value={messageSearchQuery}
              onChange={(e) => setMessageSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setMessageSearchQuery('');
                  setIsSearchOpen(false);
                }
              }}
              placeholder="ค้นหาข้อความในการสนทนานี้..."
              className="w-full pl-9 pr-20 py-1.5 text-xs bg-zinc-900 border border-zinc-800 focus:border-blue-500 rounded-lg text-zinc-100 placeholder-zinc-500 outline-hidden"
              aria-label="ค้นหาข้อความในการสนทนา"
            />
            {messageSearchQuery && (
              <button
                type="button"
                onClick={() => {
                  setMessageSearchQuery('');
                  searchInputRef.current?.focus();
                }}
                className="absolute right-2 px-1.5 py-0.5 rounded text-[11px] text-zinc-400 hover:text-white hover:bg-zinc-800 flex items-center gap-1 cursor-pointer"
                title="ล้างคำค้นหา"
              >
                <X className="w-3 h-3" />
                <span>ล้าง</span>
              </button>
            )}
          </div>
          {messageSearchQuery.trim() && (
            <div className="text-[11px] font-mono px-2 py-1 rounded bg-blue-950 text-blue-300 border border-blue-800 shrink-0">
              พบ {filteredMessages.length} / {session.messages.length}
            </div>
          )}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-2 sm:px-6 py-4 space-y-3">
        {session.messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 max-w-lg mx-auto">
            <div className="zy-ai-core-wrap mb-5" aria-label="ZYNTHEOR AI Core" role="img">
              <span className="zy-core-orbit zy-core-orbit-one" />
              <span className="zy-core-orbit zy-core-orbit-two" />
              <span className="zy-core-orbit zy-core-orbit-three" />
              <div className="zy-ai-core"><Bot className="w-8 h-8 text-cyan-100" /></div>
              <span className="zy-core-spark zy-core-spark-a" />
              <span className="zy-core-spark zy-core-spark-b" />
            </div>
            <div className="zy-core-eyebrow mb-2">IMMERSIVE AI WORKSPACE</div>
            <h3 className="text-base font-bold text-zinc-100 mb-1">
              ZYNTHEOR AI ENGINE
            </h3>
            <p className="text-xs text-zinc-400 mb-6 leading-relaxed max-w-sm">
              พื้นที่ทำงานของเอเจนต์วิศวกรรมซอฟต์แวร์ วางแผนงาน ตรวจสอบโค้ด และรันคำสั่งใน Sandbox แบบอัตโนมัติ
            </p>

            {/* Quick action cards */}
            <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
              <button
                onClick={() => handleSendMessage('ช่วยวิเคราะห์โครงสร้างโค้ดและแนะนำการปรับปรุง', [])}
                className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 hover:border-blue-500/50 hover:bg-zinc-850 transition-all text-xs text-zinc-300 shadow-xs cursor-pointer group"
              >
                <div className="flex items-center gap-2 mb-1.5 text-blue-400 font-semibold">
                  <Zap className="w-3.5 h-3.5 text-blue-400" />
                  <span>วิเคราะห์โปรเจกต์</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  รีวิวโค้ด สถาปัตยกรรม และตรวจสอบข้อผิดพลาด
                </p>
              </button>

              <button
                onClick={() => handleSendMessage('ช่วยวางแผนงานและสร้างรายการสิ่งที่ต้องทำ (Todo)', [])}
                className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 hover:border-blue-500/50 hover:bg-zinc-850 transition-all text-xs text-zinc-300 shadow-xs cursor-pointer group"
              >
                <div className="flex items-center gap-2 mb-1.5 text-indigo-400 font-semibold">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>วางแผนงาน (Sprint Plan)</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  สร้างแผนปฏิบัติการพร้อมลำดับความสำคัญและขั้นตอน
                </p>
              </button>
            </div>
          </div>
        ) : session.messages.length > 0 && filteredMessages.length === 0 && messageSearchQuery.trim() ? (
          <div className="flex flex-col items-center justify-center py-16 text-center text-zinc-400">
            <Search className="w-8 h-8 text-zinc-500 mb-2" />
            <p className="text-sm font-medium text-zinc-300">ไม่พบข้อความที่ตรงกับ "{messageSearchQuery}"</p>
            <button
              onClick={() => setMessageSearchQuery('')}
              className="mt-3 text-xs text-blue-400 hover:underline cursor-pointer"
            >
              ล้างการค้นหาเพื่อดูข้อความทั้งหมด
            </button>
          </div>
        ) : (
          filteredMessages.map((message) => (
            <ConversationMessageView
              key={message.id}
              message={message}
              onToggleReaction={handleToggleReaction}
              onExecutePlan={(pId) => handleLaunchCopilotPlanExecution(pId)}
            />
          ))
        )}

        {/* Agent thinking indicator */}
        {isAgentThinking && (
          <div className="flex items-center gap-3 px-4 py-3 bg-zinc-900/60 border border-zinc-800/80 rounded-xl text-xs text-zinc-300">
            <RefreshCw className="w-4 h-4 text-blue-400 animate-spin shrink-0" />
            <div className="flex items-center gap-2">
              <span className="font-medium text-zinc-200">Zyntheor Engine กำลังประมวลผลคำสั่ง...</span>
              <span className="text-[11px] text-zinc-500 font-mono">Running</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Command Input Bar with Clean Sandbox Actions */}
      <div className="p-3 sm:p-4 bg-gradient-to-t from-zinc-950 via-zinc-950/95 to-transparent shrink-0 space-y-2">
        <div className="max-w-4xl mx-auto space-y-2">
          {/* Quick Sandbox Action Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 text-[11px] font-mono">
            <span className="text-zinc-500 text-xs shrink-0 flex items-center gap-1 mr-1">
              Sandbox:
            </span>
            <button
              type="button"
              onClick={() => handleSendMessage('/test', [])}
              className="px-2.5 py-1 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800 hover:border-zinc-700 hover:text-zinc-100 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              title="รัน Unit Tests ใน Sandbox"
            >
              <span>/test</span>
            </button>
            <button
              type="button"
              onClick={() => handleSendMessage('/typecheck', [])}
              className="px-2.5 py-1 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800 hover:border-zinc-700 hover:text-zinc-100 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              title="ตรวจสอบ Type ด้วย TypeScript"
            >
              <span>/typecheck</span>
            </button>
            <button
              type="button"
              onClick={() => handleSendMessage('/build', [])}
              className="px-2.5 py-1 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800 hover:border-zinc-700 hover:text-zinc-100 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              title="ตรวจสอบความถูกต้องของ Bundle และ Manifest"
            >
              <span>/build</span>
            </button>
            <button
              type="button"
              onClick={() => handleSendMessage('/syntax', [])}
              className="px-2.5 py-1 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800 hover:border-zinc-700 hover:text-zinc-100 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              title="ตรวจสอบไวยากรณ์ JavaScript"
            >
              <span>/syntax</span>
            </button>
            <button
              type="button"
              onClick={() => handleLaunchCopilotPlanExecution()}
              className="px-2.5 py-1 rounded-md bg-blue-950/80 text-blue-300 border border-blue-800 hover:border-blue-600 hover:text-blue-200 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              title="รันแผนงาน Copilot พร้อมแสดงแถบความคืบหน้า (Visual Progress Bar / ประมวลผล 11s)"
            >
              <Sparkles className="w-3 h-3 text-blue-400" />
              <span>/plan run</span>
            </button>
            <a
              href="/api/workspace/download-zip"
              download="zyntheor-approved-project.zip"
              className="px-2.5 py-1 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800 hover:border-zinc-700 hover:text-zinc-100 transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ml-auto"
              title="ดาวน์โหลดเฉพาะไฟล์ที่ผ่านการอนุมัติแล้ว"
            >
              <Download className="w-3 h-3 text-zinc-400" />
              <span>ดาวน์โหลด ZIP</span>
            </a>
          </div>

          {/* Quick Replies System */}
          {quickReplies.length > 0 && !isAgentThinking && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              <span className="text-zinc-500 text-xs shrink-0 mr-1">
                คำตอบด่วน:
              </span>
              {quickReplies.map((qr) => (
                <button
                  key={qr.id}
                  type="button"
                  onClick={() => handleSendMessage(qr.prompt, [])}
                  className="px-2.5 py-1 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800 hover:border-zinc-700 hover:text-zinc-100 transition-colors shrink-0 cursor-pointer text-xs"
                  title={qr.prompt}
                >
                  <span>{qr.label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Last proposed plan — approve in-chat, then continue to Build */}
          {lastProposedPlan && (
            <div className="mb-2 rounded-xl border border-amber-800/60 bg-amber-950/30 px-3 py-2.5 text-xs text-amber-50 space-y-2">
              <div className="flex items-start justify-between gap-2 flex-wrap">
                <div className="min-w-0 space-y-0.5">
                  <div className="font-semibold text-amber-200 flex items-center gap-1.5">
                    <ListChecks className="w-3.5 h-3.5 shrink-0" />
                    <span>แผนล่าสุดจาก Planning Mode</span>
                  </div>
                  <p className="text-zinc-300 truncate" title={lastProposedPlan.goal}>
                    {lastProposedPlan.goal || lastProposedPlan.id}
                  </p>
                  <p className="font-mono text-[10px] text-zinc-500">
                    {lastProposedPlan.id}
                    {lastProposedPlan.riskLevel ? ` · risk ${lastProposedPlan.riskLevel}` : ''}
                    {' · '}
                    <span className="text-amber-300">{lastProposedPlan.status}</span>
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                  {(lastProposedPlan.status === 'WAITING_APPROVAL' || lastProposedPlan.status === 'PROPOSED') && (
                    <>
                      <button
                        type="button"
                        disabled={planActionBusy || !lastProposedPlan.hash}
                        onClick={() => void handleApproveLastPlan()}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-[11px] font-medium cursor-pointer"
                      >
                        {planActionBusy ? 'กำลังอนุมัติ...' : 'อนุมัติแผน'}
                      </button>
                      <button
                        type="button"
                        disabled={planActionBusy}
                        onClick={() => void handleRejectLastPlan()}
                        className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-50 text-zinc-200 border border-zinc-600 text-[11px] font-medium cursor-pointer"
                      >
                        ปฏิเสธ
                      </button>
                    </>
                  )}
                  {(lastProposedPlan.status === 'APPROVED' || lastProposedPlan.status === 'WAITING_APPROVAL') && (
                    <button
                      type="button"
                      onClick={handleGoBuild}
                      className="px-2.5 py-1 rounded-lg bg-blue-600/90 hover:bg-blue-500 text-white text-[11px] font-medium cursor-pointer"
                      title="เปิดแท็บ Build เพื่อทำ diff/proposal"
                    >
                      ไป Build
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setLastProposedPlan(null)}
                    className="px-2 py-1 rounded-lg border border-zinc-700 text-zinc-400 hover:text-zinc-200 text-[11px] cursor-pointer"
                  >
                    ปิด
                  </button>
                </div>
              </div>
              {planActionMsg && (
                <p className="text-[11px] text-emerald-300/90">{planActionMsg}</p>
              )}
              {lastProposedPlan.status === 'APPROVED' && (
                <p className="text-[11px] text-zinc-400">
                  แผนอนุมัติแล้ว — เปิดแท็บ <strong className="text-zinc-200">Build</strong> เพื่อสร้าง/แก้แอปพร้อม diff และ approval รายไฟล์ (บทสนทนานี้ยังอยู่)
                </p>
              )}
            </div>
          )}

          {/* Mode chip + bottom sheet: one conversation, mode only changes the next message's intent */}
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <ChatModeSheet value={engineChoice} onChange={setEngineChoice} disabled={isAgentThinking} />
            {engineChoice === 'planning' && (
              <span className="text-[10px] text-blue-300/90 hidden sm:inline">
                โหมดวางแผน — AI จะเสนอขั้นตอน ความเสี่ยง และวิธีทดสอบก่อนส่งไป Build
              </span>
            )}
          </div>

          <CommandInput
            onSendMessage={handleSendMessage}
            attachedFiles={attachedFiles}
            onRemoveFile={handleRemoveFile}
            onAddFiles={handleAddFiles}
            disabled={isAgentThinking}
            placeholder={
              engineChoice === 'planning'
                ? 'บอกเป้าหมายที่ต้องการวางแผน เช่น สร้างระบบสมัครสมาชิกให้โปรเจกต์นี้...'
                : 'พิมพ์คำสั่ง, สอบถามเอเจนต์, หรือลากไฟล์มาวางที่นี่... (Enter ส่ง / Shift+Enter ขึ้นบรรทัดใหม่)'
            }
          />
        </div>
      </div>
    </div>
  );
};
