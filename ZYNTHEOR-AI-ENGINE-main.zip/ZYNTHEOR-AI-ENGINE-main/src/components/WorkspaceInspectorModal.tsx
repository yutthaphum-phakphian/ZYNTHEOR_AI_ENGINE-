import React, { useState, useEffect } from 'react';
import {
  FolderGit2,
  FileCode,
  FileText,
  Database,
  Sliders,
  FileQuestion,
  RefreshCw,
  X,
  Search,
  Eye,
  ShieldCheck,
  AlertCircle,
  HardDrive
} from 'lucide-react';
import { WorkspaceInspectionResult, WorkspaceFileMetadata } from '../types';
import { inspectWorkspace, readWorkspaceFile } from '../services/api';

interface WorkspaceInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerLedgerRefresh?: () => void;
}

export const WorkspaceInspectorModal: React.FC<WorkspaceInspectorModalProps> = ({
  isOpen,
  onClose,
  onTriggerLedgerRefresh
}) => {
  const [data, setData] = useState<WorkspaceInspectionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFile, setSelectedFile] = useState<WorkspaceFileMetadata | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [readingFile, setReadingFile] = useState(false);
  const [fileError, setFileError] = useState<string | null>(null);

  const loadWorkspace = async () => {
    setLoading(true);
    try {
      const res = await inspectWorkspace();
      setData(res);
      if (onTriggerLedgerRefresh) onTriggerLedgerRefresh();
    } catch (err: any) {
      console.error('Failed to inspect workspace:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadWorkspace();
      setSelectedFile(null);
      setFileContent(null);
    }
  }, [isOpen]);

  const handlePreviewFile = async (file: WorkspaceFileMetadata) => {
    setSelectedFile(file);
    setReadingFile(true);
    setFileError(null);
    try {
      const res = await readWorkspaceFile(file.relativePath);
      if (res.success && res.content !== undefined) {
        setFileContent(res.content);
      } else {
        setFileError(res.error || 'Failed to read file');
      }
    } catch (err: any) {
      setFileError('Read error: ' + err.message);
    } finally {
      setReadingFile(false);
    }
  };

  if (!isOpen) return null;

  const filteredFiles = (data?.files || []).filter((f) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return f.name.toLowerCase().includes(term) || f.relativePath.toLowerCase().includes(term) || f.category.includes(term);
  });

  const getFileIcon = (cat: WorkspaceFileMetadata['category']) => {
    switch (cat) {
      case 'code':
        return <FileCode className="w-4 h-4 text-cyan-400" />;
      case 'config':
        return <Sliders className="w-4 h-4 text-amber-400" />;
      case 'document':
        return <FileText className="w-4 h-4 text-indigo-400" />;
      case 'data':
        return <Database className="w-4 h-4 text-emerald-400" />;
      default:
        return <FileQuestion className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-5xl max-h-[90vh] flex flex-col bg-[#090d16] border border-cyan-500/40 rounded-xl shadow-2xl shadow-cyan-950/50 overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-500/20 bg-[#0c1220]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-950/80 border border-cyan-500/30 text-cyan-400">
              <FolderGit2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-display font-semibold text-slate-100 flex items-center gap-2">
                คำสั่งพิเศษ: ตรวจสอบโครงสร้างไฟล์ .data/workspace
                <span className="px-2 py-0.5 text-xs font-mono rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  Scoped Boundary
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                ตรวจสอบรายการไฟล์ ขนาดไฟล์ และขอบเขตความปลอดภัยที่ AI ได้รับอนุญาตให้เข้าถึง
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadWorkspace}
              disabled={loading}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700 transition-all disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>สแกนใหม่</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Boundary Notice Banner */}
        <div className="px-6 py-3 bg-cyan-950/30 border-b border-cyan-500/20 flex items-center gap-3 text-xs text-cyan-200">
          <AlertCircle className="w-4 h-4 text-cyan-400 shrink-0" />
          <div>
            <span className="font-semibold text-cyan-300">สภาพแวดล้อม Cloud Container: </span>
            ไฟล์ที่แสดงทั้งหมดอยู่ภายใต้โฟลเดอร์ <code className="px-1.5 py-0.5 rounded bg-black/40 text-cyan-300 font-mono">.data/workspace/</code> ภายใน Container Sandbox เท่านั้น AI มีการป้องกัน Path Traversal และไม่สามารถอ่านหรือเข้าถึงไฟล์ส่วนตัวในเครื่องคอมพิวเตอร์จริงของผู้ใช้ได้
          </div>
        </div>

        {/* Overview Stats Bar */}
        {data && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-6 py-3 border-b border-slate-800/80 bg-[#080b13] text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="text-slate-500">จำนวนไฟล์ทั้งหมด:</span>
              <span className="text-cyan-400 font-bold">{data.totalFiles} ไฟล์</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">ขนาดรวมทั้งหมด:</span>
              <span className="text-emerald-400 font-bold">{data.totalSizeFormatted} ({data.totalSizeBytes.toLocaleString()} Bytes)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">ขอบเขตที่อนุญาต:</span>
              <span className="text-amber-300 font-bold">{data.allowedScope}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">สถานะขอบเขต:</span>
              <span className="text-emerald-400 flex items-center gap-1 font-bold">
                <ShieldCheck className="w-3.5 h-3.5" /> มีการบล็อก Path Traversal
              </span>
            </div>
          </div>
        )}

        {/* Search & Content Area */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          {/* File Table Column */}
          <div className="flex-1 flex flex-col border-r border-slate-800/80 overflow-hidden">
            {/* Search Input */}
            <div className="p-3 border-b border-slate-800/60 bg-[#0a0e1a]">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="ค้นหาตามชื่อไฟล์, นามสกุล หรือหมวดหมู่..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-900/90 border border-slate-700 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            {/* Files List Table */}
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="flex flex-col items-center justify-center h-48 text-slate-400 text-xs font-mono">
                  <RefreshCw className="w-6 h-6 animate-spin text-cyan-400 mb-2" />
                  กำลังตรวจสอบโครงสร้างไฟล์ .data/workspace...
                </div>
              ) : filteredFiles.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-slate-500 text-xs font-mono">
                  ไม่พบไฟล์ที่ตรงกับเงื่อนไขการค้นหา
                </div>
              ) : (
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#0b101c] text-slate-400 sticky top-0 border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-4">ชื่อไฟล์</th>
                      <th className="py-2.5 px-3">ที่อยู่ไฟล์ (Relative Path)</th>
                      <th className="py-2.5 px-3 text-right">ขนาดไฟล์</th>
                      <th className="py-2.5 px-3 text-right">บรรทัด</th>
                      <th className="py-2.5 px-3">หมวดหมู่</th>
                      <th className="py-2.5 px-3 text-center">สิทธิ์</th>
                      <th className="py-2.5 px-3 text-center">เรียกดู</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    {filteredFiles.map((file) => {
                      const isSelected = selectedFile?.relativePath === file.relativePath;
                      return (
                        <tr
                          key={file.relativePath}
                          className={`hover:bg-cyan-950/20 transition-colors ${
                            isSelected ? 'bg-cyan-950/40 text-cyan-200' : ''
                          }`}
                        >
                          <td className="py-2 px-4 flex items-center gap-2 font-medium">
                            {getFileIcon(file.category)}
                            <span className="truncate max-w-[160px]" title={file.name}>
                              {file.name}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-400 truncate max-w-[200px]" title={file.relativePath}>
                            {file.relativePath}
                          </td>
                          <td className="py-2 px-3 text-right font-semibold text-emerald-400 whitespace-nowrap">
                            {file.sizeFormatted}
                            <span className="text-[10px] text-slate-500 ml-1">
                              ({file.sizeBytes} B)
                            </span>
                          </td>
                          <td className="py-2 px-3 text-right text-slate-400">
                            {file.lines}
                          </td>
                          <td className="py-2 px-3">
                            <span className="px-1.5 py-0.5 rounded text-[10px] uppercase bg-slate-800 text-slate-300">
                              {file.category}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-center">
                            <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
                              ALLOWED
                            </span>
                          </td>
                          <td className="py-2 px-3 text-center">
                            <button
                              onClick={() => handlePreviewFile(file)}
                              className="px-2 py-1 text-[11px] rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/30 transition-all flex items-center gap-1 mx-auto"
                            >
                              <Eye className="w-3 h-3" />
                              ดูเนื้อหา
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* File Preview Column */}
          {selectedFile && (
            <div className="w-full md:w-[420px] bg-[#070a12] flex flex-col border-t md:border-t-0 md:border-l border-slate-800 overflow-hidden">
              <div className="p-3 border-b border-slate-800 bg-[#090d18] flex items-center justify-between">
                <div className="flex items-center gap-2 overflow-hidden">
                  {getFileIcon(selectedFile.category)}
                  <div className="truncate">
                    <div className="font-mono text-xs font-bold text-slate-200 truncate">
                      {selectedFile.name}
                    </div>
                    <div className="font-mono text-[10px] text-slate-500">
                      {selectedFile.sizeFormatted} | {selectedFile.lines} lines
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedFile(null)}
                  className="p-1 text-slate-400 hover:text-slate-100 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 p-3 overflow-y-auto font-mono text-xs text-slate-300 bg-[#04060a]">
                {readingFile ? (
                  <div className="flex items-center justify-center h-32 text-slate-400 text-xs">
                    <RefreshCw className="w-4 h-4 animate-spin text-cyan-400 mr-2" />
                    กำลังอ่านไฟล์อย่างปลอดภัย...
                  </div>
                ) : fileError ? (
                  <div className="p-3 rounded bg-red-950/40 border border-red-500/30 text-red-300 text-xs">
                    {fileError}
                  </div>
                ) : (
                  <pre className="whitespace-pre-wrap break-all leading-relaxed text-slate-200">
                    {fileContent}
                  </pre>
                )}
              </div>

              <div className="p-2 border-t border-slate-800 bg-[#080c16] text-[10px] font-mono text-slate-500 flex justify-between">
                <span>แก้ไขล่าสุด: {new Date(selectedFile.modifiedAt).toLocaleTimeString()}</span>
                <span className="text-emerald-400 font-semibold">Scope: Safe Sandbox</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-[#080c14] flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>ขอบเขตข้อมูลถูกควบคุมและบันทึกประวัติการสแกนลง Cryptographic Evidence Ledger เรียบร้อยแล้ว</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
