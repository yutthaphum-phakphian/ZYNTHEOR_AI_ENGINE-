import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Activity, ShieldCheck, Cpu, Database, Zap, RefreshCw } from 'lucide-react';
import { ClusterStatus } from '../types/orchestration';

interface HologramConsoleProps {
  clusters?: ClusterStatus[];
  activeClusterId?: string;
  onSelectCluster?: (clusterId: string) => void;
  lang?: 'en' | 'th';
}

const DEFAULT_CLUSTERS: ClusterStatus[] = [
  { id: 'c-genesis', name: 'Genesis Matrix', tier: 'Genesis', status: 'synced', hsmVerified: true, telemetryLatencyMs: 4.2, integrityScore: 99.98 },
  { id: 'c-custodian', name: 'Cosmic Custodian', tier: 'Custodian', status: 'active', hsmVerified: true, telemetryLatencyMs: 6.1, integrityScore: 100 },
  { id: 'c-cryo', name: 'Cryo Core', tier: 'Cryo', status: 'synced', hsmVerified: true, telemetryLatencyMs: 5.0, integrityScore: 99.95 },
  { id: 'c-quantum', name: 'Quantum Multiverse', tier: 'Quantum', status: 'active', hsmVerified: true, telemetryLatencyMs: 3.8, integrityScore: 99.99 },
  { id: 'c-planck', name: 'Planck Fabric', tier: 'Planck', status: 'synced', hsmVerified: true, telemetryLatencyMs: 7.4, integrityScore: 99.94 },
  { id: 'c-forensic', name: 'Forensic Ledger', tier: 'Forensic', status: 'synced', hsmVerified: true, telemetryLatencyMs: 8.5, integrityScore: 100 },
];

export const HologramConsole: React.FC<HologramConsoleProps> = ({
  clusters = DEFAULT_CLUSTERS,
  activeClusterId,
  onSelectCluster,
  lang = 'th',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedId, setSelectedId] = useState<string>(activeClusterId || clusters[0]?.id || 'c-quantum');
  const [telemetryPulse, setTelemetryPulse] = useState<number>(0);

  useEffect(() => {
    if (activeClusterId) setSelectedId(activeClusterId);
  }, [activeClusterId]);

  // Three.js 3D Hologram Setup
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight || 360;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030712, 0.035);

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    camera.position.set(0, 2, 7.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Quantum Core - Wireframe Icosahedron
    const coreGeometry = new THREE.IcosahedronGeometry(1.6, 2);
    const coreMaterial = new THREE.MeshBasicMaterial({
      color: 0x00f5ff,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
    });
    const quantumCore = new THREE.Mesh(coreGeometry, coreMaterial);
    scene.add(quantumCore);

    // Inner glowing sphere
    const innerGeo = new THREE.SphereGeometry(0.85, 16, 16);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    const innerCore = new THREE.Mesh(innerGeo, innerMat);
    scene.add(innerCore);

    // Orbital Holographic Rings
    const ringGroup = new THREE.Group();
    scene.add(ringGroup);

    const createRing = (radius: number, colorHex: number, rotX: number, rotY: number) => {
      const ringGeo = new THREE.RingGeometry(radius - 0.03, radius + 0.03, 64);
      const ringMat = new THREE.MeshBasicMaterial({
        color: colorHex,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.5,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = rotX;
      ringMesh.rotation.y = rotY;
      ringGroup.add(ringMesh);
      return ringMesh;
    };

    const ring1 = createRing(2.6, 0x00f5ff, Math.PI / 3, 0);
    const ring2 = createRing(3.2, 0xf59e0b, -Math.PI / 4, Math.PI / 6);
    const ring3 = createRing(3.8, 0x06b6d4, Math.PI / 2.2, -Math.PI / 5);

    // Cosmic Particles
    const particleCount = 280;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    const cyan = new THREE.Color(0x00f5ff);
    const amber = new THREE.Color(0xf59e0b);

    for (let i = 0; i < particleCount * 3; i += 3) {
      const r = 2.5 + Math.random() * 4.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = (Math.random() - 0.5) * Math.PI;

      positions[i] = r * Math.cos(phi) * Math.cos(theta);
      positions[i + 1] = r * Math.sin(phi);
      positions[i + 2] = r * Math.cos(phi) * Math.sin(theta);

      const mixed = Math.random() > 0.5 ? cyan : amber;
      colors[i] = mixed.r;
      colors[i + 1] = mixed.g;
      colors[i + 2] = mixed.b;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.06,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Mouse movement interaction
    let mouseX = 0;
    let mouseY = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseX = ((e.clientX - rect.left) / width - 0.5) * 1.5;
      mouseY = ((e.clientY - rect.top) / height - 0.5) * 1.5;
    };
    container.addEventListener('mousemove', handleMouseMove);

    // Animation Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      quantumCore.rotation.x = elapsed * 0.25;
      quantumCore.rotation.y = elapsed * 0.35;

      innerCore.rotation.x = -elapsed * 0.4;
      innerCore.rotation.z = elapsed * 0.2;

      ring1.rotation.z = elapsed * 0.15;
      ring2.rotation.z = -elapsed * 0.12;
      ring3.rotation.z = elapsed * 0.08;

      particles.rotation.y = elapsed * 0.04;

      // Smooth camera tilt
      camera.position.x += (mouseX * 2 - camera.position.x) * 0.05;
      camera.position.y += (-mouseY * 1.2 + 2 - camera.position.y) * 0.05;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };
    animate();

    // Pulse timer for telemetry metric animation
    const intervalId = window.setInterval(() => {
      setTelemetryPulse((p) => (p + 1) % 100);
    }, 1200);

    // Resize Observer
    let resizeRaf: number | null = null;
    const resizeObserver = new ResizeObserver(() => {
      if (resizeRaf !== null) cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(() => {
        if (!container) return;
        const newWidth = container.clientWidth;
        const newHeight = container.clientHeight || 360;
        camera.aspect = newWidth / newHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(newWidth, newHeight, false);
      });
    });
    resizeObserver.observe(container);

    return () => {
      if (resizeRaf !== null) cancelAnimationFrame(resizeRaf);
      cancelAnimationFrame(animId);
      clearInterval(intervalId);
      resizeObserver.disconnect();
      container.removeEventListener('mousemove', handleMouseMove);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      coreGeometry.dispose();
      coreMaterial.dispose();
      innerGeo.dispose();
      innerMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, []);

  const activeCluster = clusters.find((c) => c.id === selectedId) || clusters[0];

  return (
    <div className="relative rounded-2xl overflow-hidden border border-cyan-500/30 bg-gradient-to-b from-zinc-950 via-slate-950 to-zinc-950 shadow-2xl">
      {/* 3D Hologram Canvas Container */}
      <div
        ref={containerRef}
        className="w-full h-72 md:h-80 cursor-grab active:cursor-grabbing relative"
        aria-label="3D Hologram Telemetry Viewport"
      />

      {/* Hologram Header Overlay */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <span className="font-mono text-xs font-bold tracking-widest text-cyan-300 uppercase">
            SOVEREIGN HOLOGRAM MATRIX
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300">
            FROZEN-QUANTUM Ω∞
          </span>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto font-mono text-[11px] text-zinc-400">
          <span className="flex items-center gap-1 text-amber-300 font-semibold bg-amber-950/70 border border-amber-800/60 px-2 py-0.5 rounded-md">
            <ShieldCheck className="w-3.5 h-3.5" /> HSM: NOT CONNECTED
          </span>
          <span className="hidden sm:inline text-amber-300 bg-amber-950/60 border border-amber-800/50 px-2 py-0.5 rounded-md">
            VISUAL SIMULATION
          </span>
        </div>
      </div>

      {/* Holographic Cluster Selection Badges */}
      <div className="p-3 bg-zinc-950/90 border-t border-cyan-900/30 backdrop-blur-md">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[11px] font-mono uppercase font-bold text-zinc-400 tracking-wider">
            {lang === 'th' ? 'โหนดคลัสเตอร์มัลติเวิร์ส (Multiverse Nodes)' : 'Multiverse Cluster Nodes'}
          </div>
          {activeCluster && (
            <div className="text-[11px] font-mono text-cyan-400 flex items-center gap-2">
              <span>{activeCluster.tier} Tier</span>
              <span className="text-zinc-600">·</span>
              <span className="text-emerald-400 font-bold">{activeCluster.integrityScore}% Integrity (simulated)</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
          {clusters.map((cluster) => {
            const isSelected = cluster.id === selectedId;
            return (
              <button
                key={cluster.id}
                type="button"
                onClick={() => {
                  setSelectedId(cluster.id);
                  if (onSelectCluster) onSelectCluster(cluster.id);
                }}
                className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-950/70 border-cyan-400 text-cyan-200 shadow-md shadow-cyan-500/20 ring-1 ring-cyan-400/50'
                    : 'bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                }`}
                aria-label={`Select cluster ${cluster.name}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono font-bold tracking-wider">{cluster.tier}</span>
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      cluster.status === 'active' || cluster.status === 'synced'
                        ? 'bg-emerald-400'
                        : 'bg-amber-400'
                    }`}
                  />
                </div>
                <div className="text-xs font-semibold truncate text-zinc-200">{cluster.name}</div>
                <div className="text-[9px] font-mono text-cyan-400 mt-1 flex items-center justify-between">
                  <span>{cluster.telemetryLatencyMs} ms (sim)</span>
                  <span className="text-zinc-500 font-mono">PQC-5</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
