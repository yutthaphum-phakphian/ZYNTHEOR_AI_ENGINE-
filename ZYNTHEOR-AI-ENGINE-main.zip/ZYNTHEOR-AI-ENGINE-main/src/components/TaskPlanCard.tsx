import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  Clock,
  Circle,
  AlertCircle,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Play,
  RotateCcw,
  Check,
  ExternalLink,
} from 'lucide-react';

import { computePlanProgress } from '../utils/planProgress.js';

export interface SubTaskItem {
  id: string;
  title: string;
  completed: boolean;
  status?: string;
  assignedAgent?: string;
  completedAt?: string;
}

export interface PlanStepItem {
  id: string;
  title: string;
  tool?: string;
  status: 'pending' | 'in_progress' | 'done' | 'failed' | string;
  successCondition?: string;
  dependsOn?: string[];
  resultSummary?: string;
  subTasks?: SubTaskItem[];
}

export interface TaskPlanData {
  id: string;
  title: string;
  goal?: string;
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'draft' | 'active' | 'completed' | 'PROPOSED' | 'APPROVED' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | string;
  hash?: string;
  progress?: number;
  steps: PlanStepItem[];
  approvalId?: string;
}

interface TaskPlanCardProps {
  planId?: string;
  initialPlan?: TaskPlanData;
  rawText?: string;
  onApprove?: (planId: string, hash: string) => Promise<void>;
  onExecute?: (planId: string) => void;
  lang?: 'en' | 'th';
}

export const TaskPlanCard: React.FC<TaskPlanCardProps> = ({
  planId,
  initialPlan,
  rawText,
  onApprove,
  onExecute,
  lang = 'th',
}) => {
  const [plan, setPlan] = useState<TaskPlanData | null>(initialPlan || null);
  const [expanded, setExpanded] = useState(true);
  const [loading, setLoading] = useState(false);
  const [approving, setApproving] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // Parse markdown plan if rawText provided and no initial plan
  useEffect(() => {
    if (!plan && !planId && rawText) {
      const parsedSteps: PlanStepItem[] = [];
      const lines = rawText.split('\n');
      let stepCounter = 1;

      for (const line of lines) {
        const checkMatch = line.match(/^[-*]\s*\[([ xX])\]\s*(.+)/);
        if (checkMatch) {
          const isDone = checkMatch[1].toLowerCase() === 'x';
          parsedSteps.push({
            id: `step_${stepCounter++}`,
            title: checkMatch[2].trim(),
            status: isDone ? 'done' : 'pending',
          });
          continue;
        }

        const numMatch = line.match(/^(\d+)[.)]\s*(.+)/);
        if (numMatch && (line.toLowerCase().includes('step') || line.toLowerCase().includes('ขั้นตอน') || line.toLowerCase().includes('tool') || rawText.toLowerCase().includes('plan'))) {
          parsedSteps.push({
            id: `step_${numMatch[1]}`,
            title: numMatch[2].trim(),
            status: 'pending',
          });
        }
      }

      if (parsedSteps.length > 0) {
        const doneCount = parsedSteps.filter((s) => s.status === 'done' || s.status === 'SUCCEEDED').length;
        const progress = Math.round((doneCount / parsedSteps.length) * 100);
        setPlan({
          id: 'local_plan',
          title: lang === 'th' ? 'แผนการทำงาน (Task Execution Plan)' : 'Task Execution Plan',
          status: progress === 100 ? 'completed' : 'active',
          progress,
          steps: parsedSteps,
        });
      }
    }
  }, [rawText, plan, planId, lang]);

  // Fetch plan from API if planId is provided
  useEffect(() => {
    if (!planId) return;

    let isMounted = true;
    const loadPlan = async () => {
      setLoading(true);
      try {
        // Try Agent plans first (/api/plans/:id)
        const agentRes = await fetch(`/api/plans/${planId}`);
        if (agentRes.ok) {
          const data = await agentRes.json();
          if (data.plan && isMounted) {
            const p = data.plan;
            const steps: PlanStepItem[] = (p.steps || []).map((s: any) => ({
              id: s.id,
              title: s.tool ? `Tool: ${s.tool}` : s.id,
              tool: s.tool,
              status: s.status?.toLowerCase() || 'pending',
              successCondition: s.successCondition,
              dependsOn: s.dependsOn,
            }));
            const doneCount = steps.filter((s) => s.status === 'succeeded' || s.status === 'done').length;
            const progress = steps.length > 0 ? Math.round((doneCount / steps.length) * 100) : 0;
            setPlan({
              id: p.id,
              title: p.goal || `Agent Plan: ${p.id.slice(0, 8)}`,
              goal: p.goal,
              riskLevel: p.riskLevel,
              status: p.status,
              hash: p.hash,
              progress,
              steps,
              approvalId: p.approval?.id,
            });
            return;
          }
        }

        // Try Copilot plans (/api/copilot/plans/:id)
        const copilotRes = await fetch(`/api/copilot/plans/${planId}`);
        if (copilotRes.ok) {
          const data = await copilotRes.json();
          if (data.plan && isMounted) {
            const p = data.plan;
            const steps: PlanStepItem[] = (p.steps || []).map((s: any) => ({
              id: s.id,
              title: s.title,
              status: s.status,
            }));
            const doneCount = steps.filter((s) => s.status === 'done').length;
            const progress = steps.length > 0 ? Math.round((doneCount / steps.length) * 100) : 0;
            setPlan({
              id: p.id,
              title: p.title,
              goal: p.description,
              status: p.status,
              progress,
              steps,
            });
            return;
          }
        }
      } catch (err) {
        console.warn('Failed to load plan for TaskPlanCard:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    loadPlan();
    return () => {
      isMounted = false;
    };
  }, [planId]);

  if (!plan && !loading) {
    return null;
  }

  if (loading) {
    return (
      <div className="my-2 p-3 rounded-xl border border-zinc-800 bg-zinc-950/70 text-zinc-400 text-xs flex items-center gap-2">
        <Clock className="w-3.5 h-3.5 animate-spin text-cyan-400" />
        <span>{lang === 'th' ? 'กำลังโหลดรายละเอียดแผนงาน...' : 'Loading plan details...'}</span>
      </div>
    );
  }

  if (!plan) return null;

  const totalSteps = plan.steps.length;
  const completedSteps = plan.steps.filter(
    (s) => s.status === 'done' || s.status === 'succeeded' || s.status === 'SUCCEEDED'
  ).length;
  const inProgressSteps = plan.steps.filter(
    (s) => s.status === 'in_progress' || s.status === 'running' || s.status === 'RUNNING'
  ).length;
  const failedSteps = plan.steps.filter(
    (s) => s.status === 'failed' || s.status === 'FAILED'
  ).length;

  const progressInfo = computePlanProgress(plan.steps);
  const calculatedProgress = progressInfo.percent;
  const totalSubTasksCount = progressInfo.total;
  const completedSubTasksCount = progressInfo.done;

  // Handle plan approval
  const handleApprove = async () => {
    if (!plan || !plan.hash) return;
    setApproving(true);
    try {
      if (onApprove) {
        await onApprove(plan.id, plan.hash);
      } else {
        const res = await fetch(`/api/plans/${plan.id}/approve`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ planHash: plan.hash }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.plan) {
            setPlan((prev) => (prev ? { ...prev, status: data.plan.status, approvalId: data.plan.approval?.id } : prev));
            setActionFeedback(lang === 'th' ? 'อนุมัติแผนงานเรียบร้อยแล้ว' : 'Plan approved successfully');
          }
        }
      }
    } catch (e: any) {
      setActionFeedback(`Error: ${e.message}`);
    } finally {
      setApproving(false);
    }
  };

  // Toggle individual sub-task and automatically recalculate completion percentage
  const handleToggleSubTask = async (stepId: string, subTaskId: string) => {
    const updatedSteps = plan.steps.map((step) => {
      if (step.id !== stepId) return step;
      const subTasks = (step.subTasks || []).map((st) => {
        if (st.id !== subTaskId) return st;
        const nextCompleted = !st.completed;
        return {
          ...st,
          completed: nextCompleted,
          status: nextCompleted ? 'done' : 'pending',
          completedAt: nextCompleted ? new Date().toISOString() : undefined,
        };
      });

      const allDone = subTasks.length > 0 && subTasks.every((st) => st.completed);
      const anyDone = subTasks.some((st) => st.completed);
      const nextStepStatus = allDone ? 'done' : anyDone ? 'in_progress' : 'pending';

      return {
        ...step,
        subTasks,
        status: nextStepStatus,
      };
    });

    const prog = computePlanProgress(updatedSteps);
    setPlan({
      ...plan,
      steps: updatedSteps,
      progress: prog.percent,
      status: prog.percent === 100 ? 'completed' : plan.status,
    });

    // Sync to server if plan exists on server
    if (plan.id && !plan.id.startsWith('local_')) {
      try {
        await fetch(`/api/copilot/plans/${plan.id}/subtask`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stepId, subTaskId }),
        });
      } catch (err) {
        console.warn('Subtask update failed:', err);
      }
    }
  };

  // Toggle individual step locally or via API
  const handleToggleStep = async (stepId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'done' ? 'pending' : currentStatus === 'pending' ? 'in_progress' : 'done';
    // Update local state immediately with sub-task synchronization
    const updatedSteps = plan.steps.map((s) => {
      if (s.id !== stepId) return s;
      const updatedSubTasks = Array.isArray(s.subTasks)
        ? s.subTasks.map((st) => ({
            ...st,
            completed: nextStatus === 'done',
            status: nextStatus === 'done' ? 'done' : 'pending',
          }))
        : s.subTasks;
      return { ...s, status: nextStatus, subTasks: updatedSubTasks };
    });

    const prog = computePlanProgress(updatedSteps);

    setPlan({
      ...plan,
      steps: updatedSteps,
      progress: prog.percent,
      status: prog.percent === 100 ? 'completed' : plan.status,
    });

    // If it's a copilot plan, sync to server
    if (plan.id && !plan.id.startsWith('local_')) {
      try {
        await fetch(`/api/copilot/plans/${plan.id}/step`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stepId, status: nextStatus }),
        });
      } catch (err) {
        console.warn('Step update failed:', err);
      }
    }
  };

  return (
    <div className="my-3 rounded-2xl border border-zinc-700/80 bg-zinc-900/90 dark:bg-zinc-950/90 shadow-lg overflow-hidden transition-all">
      {/* Top Header Card Bar */}
      <div className="p-3.5 bg-zinc-850/80 dark:bg-zinc-900/90 border-b border-zinc-800 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-800 text-cyan-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="text-xs font-bold text-zinc-100 truncate" title={plan.title}>
                {plan.title}
              </h4>
              <span
                className={`text-[9px] font-mono px-2 py-0.5 rounded-md uppercase font-semibold shrink-0 ${
                  plan.status === 'completed' || plan.status === 'SUCCEEDED'
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                    : plan.status === 'active' || plan.status === 'RUNNING'
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800'
                    : plan.status === 'APPROVED'
                    ? 'bg-indigo-950/80 text-indigo-300 border border-indigo-800'
                    : plan.status === 'WAITING_APPROVAL' || plan.status === 'PROPOSED'
                    ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                    : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                }`}
              >
                {plan.status}
              </span>
            </div>
            {plan.hash && (
              <p className="text-[10px] font-mono text-zinc-400 truncate">
                Hash: {plan.hash.slice(0, 16)}...
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {(plan.status === 'PROPOSED' || plan.status === 'WAITING_APPROVAL') && plan.hash && !plan.approvalId && (
            <button
              type="button"
              disabled={approving}
              onClick={handleApprove}
              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-medium text-[11px] flex items-center gap-1 transition-all shadow-sm cursor-pointer"
            >
              <Check className="w-3 h-3" />
              <span>{approving ? 'กำลังอนุมัติ...' : 'อนุมัติ Plan'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              if (onExecute) onExecute(plan.id);
              window.dispatchEvent(
                new CustomEvent('zyntheor-execute-copilot-plan', {
                  detail: { planId: plan.id, plan },
                })
              );
            }}
            className="px-2.5 py-1 rounded-lg bg-blue-600/90 hover:bg-blue-500 text-white font-medium text-[11px] flex items-center gap-1 transition-all shadow-sm cursor-pointer"
            title={lang === 'th' ? 'รันแผนงานนี้ใน Chat Workspace พร้อม Progress Bar' : 'Execute Plan in Chat Workspace'}
          >
            <Play className="w-3 h-3 fill-current" />
            <span>{lang === 'th' ? 'รันแผนงาน' : 'Execute'}</span>
          </button>

          <button
            type="button"
            onClick={() => setExpanded(!expanded)}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors cursor-pointer"
            title={expanded ? 'ย่อรายละเอียด' : 'ขยายรายละเอียด'}
          >
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Visual Progress Bar Section */}
      <div className="px-4 py-3 bg-zinc-900/60 dark:bg-zinc-950/60 border-b border-zinc-800/60">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <div className="flex items-center gap-2 text-zinc-300">
            <span className="font-semibold text-zinc-200">
              {lang === 'th' ? 'ความคืบหน้าของขั้นตอน:' : 'Step Completion:'}
            </span>
            <span className="font-mono text-cyan-400 font-bold">
              {completedSteps}/{totalSteps} {lang === 'th' ? 'ขั้นตอน' : 'steps'}
            </span>
            {inProgressSteps > 0 && (
              <span className="text-[10px] text-amber-400 flex items-center gap-1">
                <Clock className="w-3 h-3 animate-pulse" /> {inProgressSteps} {lang === 'th' ? 'กำลังรัน' : 'running'}
              </span>
            )}
            {failedSteps > 0 && (
              <span className="text-[10px] text-rose-400 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> {failedSteps} {lang === 'th' ? 'ล้มเหลว' : 'failed'}
              </span>
            )}
          </div>

          <span
            className={`font-mono text-xs font-bold px-2 py-0.5 rounded-md ${
              calculatedProgress === 100
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
            }`}
          >
            {calculatedProgress}%
          </span>
        </div>

        {/* The Animated Visual Progress Bar */}
        <div className="relative h-2.5 w-full bg-zinc-800/90 rounded-full overflow-hidden p-0.5 border border-zinc-700/50">
          <div
            className={`h-full rounded-full transition-all duration-500 ease-out ${
              calculatedProgress === 100
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-sm shadow-emerald-500/50'
                : calculatedProgress > 0
                ? 'bg-gradient-to-r from-cyan-500 via-indigo-500 to-amber-500 shadow-sm shadow-cyan-500/50'
                : 'bg-transparent'
            }`}
            style={{ width: `${calculatedProgress}%` }}
          />
        </div>

        {/* Step completion tick indicators along progress */}
        {totalSteps > 1 && totalSteps <= 10 && (
          <div className="flex justify-between px-1 mt-1 text-[9px] text-zinc-500 font-mono">
            {plan.steps.map((s, idx) => (
              <span
                key={s.id || idx}
                className={`transition-colors ${
                  s.status === 'done' || s.status === 'succeeded' || s.status === 'SUCCEEDED'
                    ? 'text-emerald-400 font-bold'
                    : s.status === 'in_progress' || s.status === 'running' || s.status === 'RUNNING'
                    ? 'text-amber-400 font-bold'
                    : 'text-zinc-600'
                }`}
              >
                #{idx + 1}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Expanded Step-by-Step Breakdown */}
      {expanded && (
        <div className="p-3.5 space-y-2">
          {actionFeedback && (
            <div className="p-2 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs">
              {actionFeedback}
            </div>
          )}

          <div className="space-y-1.5">
            {plan.steps.map((step, idx) => {
              const isDone =
                step.status === 'done' || step.status === 'succeeded' || step.status === 'SUCCEEDED';
              const isRunning =
                step.status === 'in_progress' || step.status === 'running' || step.status === 'RUNNING';
              const isFailed = step.status === 'failed' || step.status === 'FAILED';

              return (
                <div
                  key={step.id || idx}
                  onClick={() => handleToggleStep(step.id, step.status)}
                  className={`flex items-start gap-2.5 p-2 rounded-xl border text-xs transition-all cursor-pointer ${
                    isDone
                      ? 'bg-emerald-950/20 border-emerald-900/40 text-zinc-300 hover:bg-emerald-950/30'
                      : isRunning
                      ? 'bg-amber-950/20 border-amber-900/40 text-amber-200 hover:bg-amber-950/30'
                      : isFailed
                      ? 'bg-rose-950/20 border-rose-900/40 text-rose-300 hover:bg-rose-950/30'
                      : 'bg-zinc-950/40 border-zinc-850 hover:bg-zinc-800/40 text-zinc-300'
                  }`}
                  title={lang === 'th' ? 'คลิกเพื่อสลับสถานะขั้นตอน' : 'Click to toggle step status'}
                >
                  <button type="button" className="shrink-0 mt-0.5">
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : isRunning ? (
                      <Clock className="w-4 h-4 text-amber-400 animate-spin" />
                    ) : isFailed ? (
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                    ) : (
                      <Circle className="w-4 h-4 text-zinc-600 hover:text-zinc-400" />
                    )}
                  </button>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`font-medium ${
                          isDone ? 'line-through text-zinc-400' : 'text-zinc-200'
                        }`}
                      >
                        {step.title}
                      </span>
                      {step.tool && (
                        <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-cyan-300 shrink-0">
                          {step.tool}
                        </span>
                      )}
                    </div>
                    {step.successCondition && (
                      <p className="text-[10px] text-zinc-500 mt-0.5 font-mono line-clamp-1">
                        Criteria: {step.successCondition}
                      </p>
                    )}

                    {/* Granular Sub-Tasks / Sub-Steps */}
                    {Array.isArray(step.subTasks) && step.subTasks.length > 0 && (
                      <div className="mt-2 pl-2 border-l border-cyan-800/40 space-y-1">
                        <div className="text-[10px] font-semibold text-cyan-400/80 uppercase tracking-wider flex items-center justify-between">
                          <span>{lang === 'th' ? 'ขั้นตอนย่อย (Sub-tasks)' : 'Sub-tasks'}</span>
                          <span className="font-mono text-[9px] text-zinc-400">
                            {step.subTasks.filter((st) => st.completed).length}/{step.subTasks.length}
                          </span>
                        </div>
                        {step.subTasks.map((subTask) => (
                          <div
                            key={subTask.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleSubTask(step.id, subTask.id);
                            }}
                            className={`flex items-center gap-2 p-1.5 rounded-lg text-[11px] transition-all cursor-pointer ${
                              subTask.completed
                                ? 'bg-emerald-950/30 text-emerald-300 line-through'
                                : 'bg-zinc-900/60 text-zinc-300 hover:bg-zinc-800/60'
                            }`}
                            role="checkbox"
                            aria-checked={subTask.completed}
                            tabIndex={0}
                            aria-label={`สลับสถานะงานย่อย ${subTask.title}`}
                          >
                            <span className="shrink-0 text-cyan-400">
                              {subTask.completed ? (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Circle className="w-3.5 h-3.5 text-zinc-500 hover:text-cyan-400" />
                              )}
                            </span>
                            <span className="flex-1 truncate">{subTask.title}</span>
                            {subTask.assignedAgent && (
                              <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-zinc-800 text-amber-300">
                                {subTask.assignedAgent}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Cryptographic Proof (Merkle Root) Verification Status Badge */}
                    <span
                      className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold shrink-0 border ${
                        isDone
                          ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80'
                          : 'bg-amber-950/80 text-amber-300 border-amber-800/80'
                      }`}
                      title={
                        isDone
                          ? 'Cryptographic proof (Merkle root) anchored to Sovereign Consensus Ledger'
                          : 'Cryptographic proof pending ledger anchoring'
                      }
                    >
                      <ShieldCheck className={`w-3 h-3 ${isDone ? 'text-emerald-400' : 'text-amber-400'}`} />
                      <span>{isDone ? 'Merkle Root Anchored' : 'Pending Ledger Anchor'}</span>
                    </span>
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-mono font-bold shrink-0 ${
                        isDone
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                          : isRunning
                          ? 'bg-amber-950 text-amber-400 border border-amber-900'
                          : isFailed
                          ? 'bg-rose-950 text-rose-400 border border-rose-900'
                          : 'bg-zinc-800 text-zinc-500'
                      }`}
                    >
                      {step.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {totalSteps === 0 && (
            <p className="text-xs text-zinc-500 italic py-2 text-center">
              {lang === 'th' ? 'ไม่มีขั้นตอนย่อยในแผนงานนี้' : 'No individual steps recorded.'}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
