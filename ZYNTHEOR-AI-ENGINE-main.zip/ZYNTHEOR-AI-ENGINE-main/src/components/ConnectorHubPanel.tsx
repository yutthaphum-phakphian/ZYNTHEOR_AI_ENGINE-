import React, { useState, useEffect, useCallback } from 'react';
import {
  Network,
  GitBranch,
  Globe,
  Database,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Search,
  FileCode2,
  ListOrdered,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  ShieldAlert,
  Loader2,
  Info,
  Sliders,
  Check,
  Radio,
} from 'lucide-react';
import type { ConnectionStatus, GitHubRepoMetadata, GitHubIssue, GitHubFileContent } from '../types/connectors';
import { gitHubConnector } from '../connectors/github';

interface ConnectorHubPanelProps {
  lang: 'en' | 'th';
}

interface ConnectorItem {
  id: string;
  label: string;
  availability: 'AVAILABLE' | 'UNAVAILABLE' | 'NOT_INSTALLED';
  declaredPermissions: string[];
  grantedPermissions: string[];
  note?: string;
  status: ConnectionStatus;
  enabled: boolean;
  isReadOnly?: boolean;
}

const DEFAULT_CONNECTORS: ConnectorItem[] = [
  {
    id: 'github',
    label: 'GitHub REST API (Read-Only)',
    availability: 'AVAILABLE',
    declaredPermissions: ['read'],
    grantedPermissions: ['read'],
    note: 'Public GitHub REST API: get_repo, list_issues, get_file',
    status: 'CONNECTED',
    enabled: true,
    isReadOnly: true,
  },
  {
    id: 'web_research',
    label: 'Web Research & Fetch',
    availability: 'AVAILABLE',
    declaredPermissions: ['read'],
    grantedPermissions: ['read'],
    note: 'Public web pages excerpt & search',
    status: 'CONNECTED',
    enabled: true,
    isReadOnly: true,
  },
  {
    id: 'sovereign',
    label: 'Sovereign API Contract',
    availability: 'AVAILABLE',
    declaredPermissions: ['read', 'call_api'],
    grantedPermissions: ['read'],
    note: 'Contract-verified local engine gateway',
    status: 'CONNECTED',
    enabled: true,
    isReadOnly: true,
  },
  {
    id: 'file_store',
    label: 'File Storage Service',
    availability: 'NOT_INSTALLED',
    declaredPermissions: ['read', 'write'],
    grantedPermissions: [],
    note: 'Declared only; no adapter installed',
    status: 'UNAVAILABLE',
    enabled: false,
    isReadOnly: false,
  },
  {
    id: 'external_api',
    label: 'External Tool API Hub',
    availability: 'NOT_INSTALLED',
    declaredPermissions: ['call_api'],
    grantedPermissions: [],
    note: 'Declared only; no adapter installed',
    status: 'UNAVAILABLE',
    enabled: false,
    isReadOnly: false,
  },
];

export const ConnectorHubPanel: React.FC<ConnectorHubPanelProps> = ({ lang }) => {
  const th = lang === 'th';

  const [connectors, setConnectors] = useState<ConnectorItem[]>(DEFAULT_CONNECTORS);
  const [isLoading, setIsLoading] = useState(false);
  const [toggleLoadingId, setToggleLoadingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [lastSyncedAt, setLastSyncedAt] = useState<string>(new Date().toLocaleTimeString());

  // Interactive GitHub Tester State
  const [isTesterOpen, setIsTesterOpen] = useState(false);
  const [testAction, setTestAction] = useState<'get_repo' | 'list_issues' | 'get_file'>('get_repo');
  const [testOwner, setTestOwner] = useState('facebook');
  const [testRepo, setTestRepo] = useState('react');
  const [testPath, setTestPath] = useState('README.md');
  const [testRef, setTestRef] = useState('main');
  const [testIssueState, setTestIssueState] = useState<'open' | 'closed' | 'all'>('open');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<any | null>(null);
  const [testError, setTestError] = useState<string | null>(null);
  const [testDuration, setTestDuration] = useState<number | null>(null);

  // Fetch registered connectors from backend Hub
  const fetchConnectors = useCallback(async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/engine/connectors');
      if (res.ok) {
        const data = await res.json();
        const rawList = Array.isArray(data.connectors) ? data.connectors : [];
        const mapped: ConnectorItem[] = rawList.map((c: any) => {
          const hasRead = (c.grantedPermissions || []).includes('read');
          const isAvailable = c.availability === 'AVAILABLE';
          let status: ConnectionStatus = 'UNAVAILABLE';
          if (c.availability === 'NOT_INSTALLED') {
            status = 'UNAVAILABLE';
          } else if (isAvailable && hasRead) {
            status = 'CONNECTED';
          } else if (isAvailable && !hasRead) {
            status = 'DISCONNECTED';
          }
          return {
            id: c.id,
            label: c.label || c.id,
            availability: c.availability,
            declaredPermissions: c.declaredPermissions || [],
            grantedPermissions: c.grantedPermissions || [],
            note: c.note,
            status,
            enabled: hasRead,
            isReadOnly: !c.declaredPermissions?.includes('write') && !c.declaredPermissions?.includes('mutate_system'),
          };
        });

        // Merge with defaults to ensure all expected connectors are represented
        const merged = DEFAULT_CONNECTORS.map((def) => {
          const found = mapped.find((m) => m.id === def.id);
          return found || def;
        });

        // Add any newly discovered connectors
        mapped.forEach((m) => {
          if (!merged.some((x) => x.id === m.id)) {
            merged.push(m);
          }
        });

        setConnectors(merged);
        setLastSyncedAt(new Date().toLocaleTimeString());
      }
    } catch (err: any) {
      console.warn('Failed to fetch connector hub status:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchConnectors();
  }, [fetchConnectors]);

  // Toggle connector enabled/disabled
  const handleToggleConnector = async (id: string, currentEnabled: boolean) => {
    setToggleLoadingId(id);
    const targetState = !currentEnabled;

    // Optimistic UI update
    setConnectors((prev) =>
      prev.map((c) =>
        c.id === id
          ? {
              ...c,
              enabled: targetState,
              status: targetState ? 'CONNECTED' : 'DISCONNECTED',
              grantedPermissions: targetState ? ['read'] : [],
            }
          : c
      )
    );

    try {
      const res = await fetch(`/api/engine/connectors/${encodeURIComponent(id)}/toggle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: targetState }),
      });
      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }
      const data = await res.json();
      if (data.connectors) {
        void fetchConnectors();
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to toggle connector');
      // Revert optimistic update on failure
      void fetchConnectors();
    } finally {
      setToggleLoadingId(null);
    }
  };

  // Run live test through Read-Only GitHub client
  const handleRunGitHubTest = async () => {
    setIsTesting(true);
    setTestError(null);
    setTestResult(null);
    const startTime = performance.now();

    try {
      if (testAction === 'get_repo') {
        const metadata = await gitHubConnector.getRepositoryMetadata(testOwner.trim(), testRepo.trim());
        setTestResult({ action: 'get_repo', data: metadata });
      } else if (testAction === 'list_issues') {
        const issues = await gitHubConnector.listIssues({
          owner: testOwner.trim(),
          repo: testRepo.trim(),
          state: testIssueState,
          perPage: 5,
        });
        setTestResult({ action: 'list_issues', data: issues });
      } else if (testAction === 'get_file') {
        const file = await gitHubConnector.getFileContent({
          owner: testOwner.trim(),
          repo: testRepo.trim(),
          path: testPath.trim(),
          ref: testRef.trim() || 'HEAD',
        });
        setTestResult({ action: 'get_file', data: file });
      }
      setTestDuration(Math.round(performance.now() - startTime));
    } catch (err: any) {
      setTestError(err.message || 'GitHub client call failed');
      setTestDuration(Math.round(performance.now() - startTime));
    } finally {
      setIsTesting(false);
    }
  };

  const getStatusBadge = (status: ConnectionStatus) => {
    switch (status) {
      case 'CONNECTED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            {th ? 'เชื่อมต่อแล้ว' : 'CONNECTED'}
          </span>
        );
      case 'AUTHENTICATING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-950/80 text-amber-300 border border-amber-800">
            <Loader2 className="w-3 h-3 animate-spin text-amber-400" />
            {th ? 'กำลังตรวจสอบสิทธิ์' : 'AUTHENTICATING'}
          </span>
        );
      case 'DISCONNECTED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-zinc-800 text-zinc-300 border border-zinc-700">
            <span className="w-1.5 h-1.5 rounded-full bg-zinc-500"></span>
            {th ? 'ปิดใช้งาน' : 'DISABLED'}
          </span>
        );
      case 'UNAVAILABLE':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-rose-950/60 text-rose-300 border border-rose-900/60">
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            {th ? 'ไม่พร้อมใช้งาน' : 'UNAVAILABLE'}
          </span>
        );
    }
  };

  const getConnectorIcon = (id: string) => {
    switch (id) {
      case 'github':
        return <GitBranch className="w-5 h-5 text-amber-400" />;
      case 'web_research':
        return <Globe className="w-5 h-5 text-cyan-400" />;
      case 'sovereign':
        return <ShieldCheck className="w-5 h-5 text-amber-400" />;
      case 'file_store':
        return <Database className="w-5 h-5 text-blue-400" />;
      default:
        return <Network className="w-5 h-5 text-zinc-400" />;
    }
  };

  const connectedCount = connectors.filter((c) => c.status === 'CONNECTED').length;

  return (
    <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-5 space-y-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-400">
            <Network className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-zinc-100">
                {th ? 'ศูนย์รวมการเชื่อมต่อภายนอก (Connector Hub)' : 'Engine Connector Hub'}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-amber-950/60 text-amber-300 border border-amber-800/80">
                {connectedCount}/{connectors.length} {th ? 'พร้อมใช้' : 'Active'}
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              {th
                ? 'จัดการการเชื่อมต่อภายนอกที่ผ่านการตรวจสอบสิทธิ์ความปลอดภัย (Authenticated Hub Agent Proxy)'
                : 'Manage external tool adapters passed strictly through the authenticated Hub Agent proxy'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <span className="text-[11px] text-zinc-500 font-mono hidden sm:inline">
            {th ? 'ซิงก์เมื่อ:' : 'Synced:'} {lastSyncedAt}
          </span>
          <button
            type="button"
            onClick={() => void fetchConnectors()}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium transition-colors disabled:opacity-50"
            title="Refresh connectors status"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-amber-400' : ''}`} />
            <span>{th ? 'รีเฟรช' : 'Refresh'}</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-rose-950/60 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMsg(null)}
            className="text-rose-400 hover:text-rose-200 text-xs"
          >
            ✕
          </button>
        </div>
      )}

      {/* Connectors List */}
      <div className="grid grid-cols-1 gap-3">
        {connectors.map((connector) => {
          const isToggling = toggleLoadingId === connector.id;
          const isGitHub = connector.id === 'github';

          return (
            <div
              key={connector.id}
              className={`p-4 rounded-xl border transition-all ${
                connector.status === 'CONNECTED'
                  ? 'bg-zinc-950/70 border-zinc-800/80 hover:border-zinc-700'
                  : 'bg-zinc-950/30 border-zinc-850 opacity-80 hover:opacity-100'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                {/* Left info */}
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 mt-0.5">
                    {getConnectorIcon(connector.id)}
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-xs text-zinc-200">{connector.label}</span>
                      {connector.isReadOnly && (
                        <span className="text-[10px] px-2 py-0.2 rounded font-mono bg-blue-950/60 text-blue-300 border border-blue-900/60">
                          {th ? 'อ่านอย่างเดียว (Read-Only)' : 'Read-Only'}
                        </span>
                      )}
                      {getStatusBadge(connector.status)}
                    </div>
                    <p className="text-[11px] text-zinc-400 mt-1">
                      {connector.note ||
                        (th
                          ? 'อะแดปเตอร์เชื่อมต่อเครื่องมือภายนอกผ่าน Hub'
                          : 'External service tool adapter connected via engine hub')}
                    </p>

                    {/* Permission scopes */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className="text-[10px] text-zinc-500 font-medium">
                        {th ? 'ขอบเขตสิทธิ์ (Scopes):' : 'Scopes:'}
                      </span>
                      {connector.declaredPermissions.length > 0 ? (
                        connector.declaredPermissions.map((scope) => {
                          const isGranted = connector.grantedPermissions.includes(scope);
                          return (
                            <span
                              key={scope}
                              className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                                isGranted
                                  ? 'bg-amber-950/70 text-amber-300 border border-amber-800/60'
                                  : 'bg-zinc-800/60 text-zinc-500 line-through'
                              }`}
                            >
                              {scope}
                            </span>
                          );
                        })
                      ) : (
                        <span className="text-[10px] text-zinc-600 font-mono">none</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right controls */}
                <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                  {/* Action button for GitHub */}
                  {isGitHub && (
                    <button
                      type="button"
                      onClick={() => setIsTesterOpen((prev) => !prev)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 text-xs font-medium border border-amber-800/60 transition-all cursor-pointer"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>{th ? 'ทดสอบ API' : 'Test Client'}</span>
                      {isTesterOpen ? (
                        <ChevronUp className="w-3 h-3 ml-0.5" />
                      ) : (
                        <ChevronDown className="w-3 h-3 ml-0.5" />
                      )}
                    </button>
                  )}

                  {/* Toggle Switch */}
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={connector.enabled}
                      disabled={connector.availability === 'NOT_INSTALLED' || isToggling}
                      onChange={() => handleToggleConnector(connector.id, connector.enabled)}
                      className="sr-only peer"
                    />
                    <div className="w-10 h-5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-600 peer-disabled:opacity-40"></div>
                  </label>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* GitHub Read-Only Interactive Testing Panel */}
      {isTesterOpen && (
        <div className="p-4 rounded-xl bg-zinc-950 border border-amber-900/40 space-y-4 transition-all">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/80">
            <div className="flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-amber-400" />
              <h4 className="font-semibold text-xs text-zinc-100">
                {th
                  ? 'ทดสอบเรียกใช้ GitHub Read-Only Client ผ่าน Hub Agent'
                  : 'Execute GitHub Read-Only Client via Hub Agent'}
              </h4>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono">
              GET https://api.github.com (Zero Mutation)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Action selector */}
            <div>
              <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                {th ? 'คำสั่งที่ต้องการทดสอบ (Action)' : 'Action'}
              </label>
              <select
                value={testAction}
                onChange={(e) => setTestAction(e.target.value as any)}
                className="w-full text-xs px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-200 focus:outline-none focus:border-amber-500"
              >
                <option value="get_repo">get_repo (ข้อมูลสรุป Repository)</option>
                <option value="list_issues">list_issues (รายการ Issues)</option>
                <option value="get_file">get_file (อ่านเนื้อหาไฟล์)</option>
              </select>
            </div>

            {/* Owner */}
            <div>
              <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                {th ? 'เจ้าของคลัง (Owner)' : 'Repository Owner'}
              </label>
              <input
                type="text"
                value={testOwner}
                onChange={(e) => setTestOwner(e.target.value)}
                placeholder="e.g. facebook"
                className="w-full text-xs px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-200 focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Repo */}
            <div>
              <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                {th ? 'ชื่อคลังโค้ด (Repo)' : 'Repository Name'}
              </label>
              <input
                type="text"
                value={testRepo}
                onChange={(e) => setTestRepo(e.target.value)}
                placeholder="e.g. react"
                className="w-full text-xs px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-200 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Additional parameter fields based on action */}
          {testAction === 'get_file' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                  {th ? 'เส้นทางไฟล์ (File Path)' : 'File Path'}
                </label>
                <input
                  type="text"
                  value={testPath}
                  onChange={(e) => setTestPath(e.target.value)}
                  placeholder="README.md"
                  className="w-full text-xs px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-200 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                  {th ? 'Ref / Branch (ค่าเริ่มต้น: HEAD)' : 'Ref / Branch (default: HEAD)'}
                </label>
                <input
                  type="text"
                  value={testRef}
                  onChange={(e) => setTestRef(e.target.value)}
                  placeholder="main or master"
                  className="w-full text-xs px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-200 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          )}

          {testAction === 'list_issues' && (
            <div className="w-full sm:w-1/3 pt-1">
              <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                {th ? 'สถานะ Issue' : 'Issue State'}
              </label>
              <select
                value={testIssueState}
                onChange={(e) => setTestIssueState(e.target.value as any)}
                className="w-full text-xs px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-750 text-zinc-200 focus:outline-none focus:border-amber-500"
              >
                <option value="open">open (เปิดอยู่)</option>
                <option value="closed">closed (ปิดแล้ว)</option>
                <option value="all">all (ทั้งหมด)</option>
              </select>
            </div>
          )}

          {/* Test Submit Button */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] text-zinc-500">
              {th
                ? 'ตรวจ Input เข้มงวด ปฏิเสธ Path Traversal'
                : 'Strict input validation rejecting path traversal & injections'}
            </span>
            <button
              type="button"
              onClick={handleRunGitHubTest}
              disabled={isTesting || !testOwner.trim() || !testRepo.trim()}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold text-xs shadow-md transition-all cursor-pointer"
            >
              {isTesting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{th ? 'กำลังเรียกผ่าน Hub Agent...' : 'Querying Hub Agent...'}</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>{th ? 'ส่งคำสั่งผ่าน Hub Agent' : 'Dispatch via Hub Agent'}</span>
                </>
              )}
            </button>
          </div>

          {/* Test Results Output */}
          {testError && (
            <div className="p-3 bg-rose-950/50 border border-rose-800 rounded-lg text-xs text-rose-300 space-y-1">
              <div className="font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>{th ? 'การเรียกใช้ไม่สำเร็จ' : 'Call Failed'}</span>
                {testDuration !== null && <span className="font-mono text-[10px]">({testDuration}ms)</span>}
              </div>
              <div className="font-mono text-[11px]">{testError}</div>
            </div>
          )}

          {testResult && (
            <div className="p-3 bg-zinc-900/90 border border-zinc-800 rounded-lg space-y-2">
              <div className="flex items-center justify-between text-xs pb-2 border-b border-zinc-800">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {th
                      ? `ผลลัพธ์จาก GitHub REST API (${testResult.action}) [VERIFIED]`
                      : `Live GitHub REST API Response (${testResult.action}) [VERIFIED]`}
                  </span>
                </div>
                {testDuration !== null && (
                  <span className="text-[10px] text-zinc-400 font-mono">
                    Latency: {testDuration}ms
                  </span>
                )}
              </div>

              {testResult.action === 'get_repo' && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div className="p-2 bg-zinc-950 rounded border border-zinc-850">
                    <span className="text-[10px] text-zinc-500 block">Repository</span>
                    <span className="font-semibold text-zinc-200 truncate block">
                      {testResult.data.fullName}
                    </span>
                  </div>
                  <div className="p-2 bg-zinc-950 rounded border border-zinc-850">
                    <span className="text-[10px] text-zinc-500 block">⭐ Stars</span>
                    <span className="font-semibold text-amber-300">
                      {testResult.data.stars?.toLocaleString() ?? 0}
                    </span>
                  </div>
                  <div className="p-2 bg-zinc-950 rounded border border-zinc-850">
                    <span className="text-[10px] text-zinc-500 block">Default Branch</span>
                    <span className="font-mono text-cyan-300">{testResult.data.defaultBranch}</span>
                  </div>
                  <div className="p-2 bg-zinc-950 rounded border border-zinc-850">
                    <span className="text-[10px] text-zinc-500 block">Language</span>
                    <span className="font-medium text-amber-300">{testResult.data.language || 'N/A'}</span>
                  </div>
                </div>
              )}

              {testResult.action === 'list_issues' && (
                <div className="space-y-1.5 text-xs">
                  <div className="text-[11px] text-zinc-400">
                    {th
                      ? `พบ ${testResult.data.count} Issues ในสถานะ "${testResult.data.state}" (ไม่รวม Pull Requests):`
                      : `Found ${testResult.data.count} issues in state "${testResult.data.state}" (excluding PRs):`}
                  </div>
                  <div className="max-h-40 overflow-y-auto space-y-1 pr-1">
                    {testResult.data.issues?.length > 0 ? (
                      testResult.data.issues.map((iss: GitHubIssue) => (
                        <div
                          key={iss.number}
                          className="p-1.5 rounded bg-zinc-950 border border-zinc-850 flex items-center justify-between text-xs"
                        >
                          <span className="font-medium text-zinc-200 truncate">
                            #{iss.number} {iss.title}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-850 text-zinc-400 shrink-0 font-mono">
                            @{iss.user || 'unknown'}
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="text-zinc-500 italic text-center py-2">
                        {th ? 'ไม่พบ Issues' : 'No issues found'}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {testResult.action === 'get_file' && (
                <div className="space-y-1 text-xs">
                  <div className="flex items-center justify-between text-[11px] text-zinc-400">
                    <span>
                      {testResult.data.path} ({testResult.data.size?.toLocaleString()} bytes)
                    </span>
                    <span className="font-mono text-[10px] text-zinc-500">
                      SHA: {testResult.data.sha?.slice(0, 10)}...
                    </span>
                  </div>
                  <pre className="p-2.5 rounded bg-zinc-950 border border-zinc-850 text-[11px] font-mono text-zinc-300 max-h-48 overflow-y-auto whitespace-pre-wrap break-all">
                    {testResult.data.content?.slice(0, 3000)}
                    {testResult.data.truncated ? '\n... (truncated for preview)' : ''}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
