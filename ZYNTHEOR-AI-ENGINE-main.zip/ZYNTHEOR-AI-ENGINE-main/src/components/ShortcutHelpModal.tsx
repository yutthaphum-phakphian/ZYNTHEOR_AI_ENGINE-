import { useEffect, useId, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent as ReactKeyboardEvent } from 'react';
import { Keyboard, Search, X } from 'lucide-react';
import type { ShortcutDef } from '../hooks/useShortcutManager';
import { filterShortcuts, splitKeys } from '../utils/shortcutHelp';

const FOCUSABLE = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';

/**
 * Modal listing every shortcut registered with useShortcutManager (it renders the same array, so it is never out of date).
 * Accessible: role=dialog + aria-modal, labelled, focus moves in and is trapped, Esc closes, focus returns to the opener.
 */
export function ShortcutHelpModal({ shortcuts, onClose }: { shortcuts: ShortcutDef[]; onClose: () => void }) {
  const titleId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState('');
  const visible = useMemo(() => filterShortcuts(shortcuts, query), [shortcuts, query]);

  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    inputRef.current?.focus();
    return () => opener?.focus?.();
  }, []);

  function onKeyDown(e: ReactKeyboardEvent<HTMLDivElement>) {
    if (e.key === 'Escape') {
      e.stopPropagation();
      onClose();
      return;
    }
    if (e.key !== 'Tab') return;
    const nodes = dialogRef.current ? Array.from(dialogRef.current.querySelectorAll<HTMLElement>(FOCUSABLE)) : [];
    if (nodes.length === 0) return;
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        data-testid="shortcut-help-modal"
        onKeyDown={onKeyDown}
        className="flex max-h-[85dvh] w-full max-w-md flex-col rounded-2xl border border-cyan-500/40 bg-[#071026] shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
          <h2 id={titleId} className="flex items-center gap-2 text-sm font-bold text-white">
            <Keyboard size={16} className="text-cyan-400" aria-hidden="true" />
            ปุ่มลัด (Keyboard Shortcuts)
          </h2>
          <button type="button" onClick={onClose} aria-label="ปิดหน้าต่างปุ่มลัด" className="rounded p-1 text-slate-400 hover:text-white">
            <X size={18} aria-hidden="true" />
          </button>
        </div>

        <div className="px-4 pt-3">
          <label className="relative block">
            <span className="sr-only">ค้นหาปุ่มลัด</span>
            <Search size={14} aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ค้นหาปุ่มลัด..."
              className="w-full rounded-lg border border-slate-700/80 bg-slate-900/60 py-2 pl-8 pr-3 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-cyan-500/60"
            />
          </label>
          <p role="status" className="mt-1.5 text-[10px] text-slate-500">
            แสดง {visible.length} จาก {shortcuts.length} รายการ
          </p>
        </div>

        <ul aria-label="รายการปุ่มลัด" className="min-h-0 flex-1 space-y-1 overflow-y-auto px-4 py-3">
          {visible.map((s) => (
            <li key={s.label + s.description} className="flex items-center justify-between gap-3 rounded-lg px-2 py-1.5 text-xs hover:bg-slate-800/40">
              <span className="text-slate-200">{s.description}</span>
              <span className="flex shrink-0 items-center gap-1" aria-label={`ปุ่ม ${s.label}`}>
                {splitKeys(s.label).map((k, i) => (
                  <kbd key={k + i} className="rounded border border-slate-600 bg-slate-800 px-1.5 py-0.5 font-mono text-[10px] text-cyan-300">
                    {k}
                  </kbd>
                ))}
              </span>
            </li>
          ))}
          {visible.length === 0 && <li className="py-4 text-center text-xs text-slate-500">ไม่พบปุ่มลัดที่ตรงกับ “{query}”</li>}
        </ul>
      </div>
    </div>
  );
}
