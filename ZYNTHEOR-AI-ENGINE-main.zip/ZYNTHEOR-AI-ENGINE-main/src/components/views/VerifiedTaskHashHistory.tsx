import React, { useState } from 'react';
import type { LedgerIntegrityReport } from './AuditLedgerView';

/**
 * Cryptographic verification history for SUCCEEDED agent tasks.
 * Real data only: rows come from GET /api/audit/verify-integrity (recordedHash vs recalculatedHash,
 * recomputed server-side). Nothing is shown as verified unless the server reports hashValid.
 * No report -> UNAVAILABLE (never an empty "all good" table).
 */
export const VerifiedTaskHashHistory: React.FC<{
  report: LedgerIntegrityReport | null;
  loading?: boolean;
  onReverify?: () => void;
  lang?: 'en' | 'th';
}> = ({ report, loading, onReverify, lang = 'th' }) => {
  const th = lang === 'th';
  const [openId, setOpenId] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const copy = async (text: string, id: string) => {
    try { await navigator.clipboard.writeText(text); setCopied(id); window.setTimeout(() => setCopied(null), 1500); } catch { /* clipboard blocked */ }
  };

  const rows = (report?.plans ?? []).filter((p) => p.status === 'SUCCEEDED');

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-xl mb-4">
      <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
        <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
          {th ? 'ประวัติการตรวจสอบ Hash ของงานที่สำเร็จ' : 'Verification history — succeeded tasks'}
        </span>
        {onReverify && (
          <button onClick={onReverify} disabled={loading} className="text-[11px] text-cyan-400 hover:text-cyan-300 disabled:opacity-50">
            {loading ? (th ? 'กำลังตรวจ…' : 'Verifying…') : (th ? 'ตรวจซ้ำ' : 'Re-verify')}
          </button>
        )}
      </div>

      {!report ? (
        <div className="p-6 text-sm text-zinc-400"><span className="font-semibold text-zinc-200">UNAVAILABLE</span> — {th ? 'ยังอ่านผลตรวจความสมบูรณ์จากเซิร์ฟเวอร์ไม่ได้' : 'integrity report could not be read from the server.'}</div>
      ) : rows.length === 0 ? (
        <div className="p-6 text-sm text-zinc-400">{th ? 'ยังไม่มีงานที่สำเร็จ (SUCCEEDED) ใน Ledger' : 'No SUCCEEDED tasks in the ledger yet.'}</div>
      ) : (
        <table className="w-full text-left text-xs font-mono">
          <thead className="border-b border-zinc-800 text-zinc-400">
            <tr><th className="p-3">Plan</th><th className="p-3">Hash</th><th className="p-3">{th ? 'ผลตรวจ' : 'Result'}</th></tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {rows.map((p) => {
              const open = openId === p.planId;
              return (
                <React.Fragment key={p.planId}>
                  <tr className="hover:bg-zinc-800/40 cursor-pointer" onClick={() => setOpenId(open ? null : p.planId)}>
                    <td className="p-3"><div className="text-zinc-200">{p.planId.slice(0, 14)}…</div><div className="text-[11px] text-zinc-400 truncate max-w-xs">{p.goal}</div></td>
                    <td className="p-3 text-zinc-300">{p.recordedHash.slice(0, 16)}…</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${p.hashValid ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                        {p.hashValid ? 'HASH MATCH' : 'MISMATCH'}
                      </span>
                    </td>
                  </tr>
                  {open && (
                    <tr className="bg-zinc-950/60">
                      <td colSpan={3} className="p-3 space-y-1 text-[11px]">
                        <div className="text-zinc-500">REC <span className="text-zinc-200 break-all">{p.recordedHash}</span>
                          <button className="ml-2 text-cyan-400" onClick={(e) => { e.stopPropagation(); copy(p.recordedHash, p.planId); }}>{copied === p.planId ? (th ? 'คัดลอกแล้ว' : 'copied') : (th ? 'คัดลอก' : 'copy')}</button></div>
                        <div className="text-zinc-500">CALC <span className={`break-all ${p.hashValid ? 'text-emerald-400' : 'text-rose-400'}`}>{p.recalculatedHash}</span></div>
                        <div className="text-zinc-500">{th ? 'หลักฐานที่ตรงกัน' : 'matched evidence'}: {p.matchedEvidenceCount} · {th ? 'อนุมัติ' : 'approval'}: {p.approvalValid ? 'VALID' : 'INVALID'} · {th ? 'ตรวจเมื่อ' : 'verified at'} {report.verifiedAt}</div>
                        {p.issues.length > 0 && <ul className="text-rose-400 list-disc pl-4">{p.issues.map((i, k) => <li key={k}>{i.message}</li>)}</ul>}
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
};
