import React, { useState, useEffect } from 'react';
import {
  Settings,
  Key,
  Bot,
  Database,
  Languages,
  RotateCcw,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Moon,
  Sun,
  ShieldAlert,
  Volume2,
  Sliders,
  Sparkles,
  Play,
  Square,
  ShieldCheck,
  Info,
  RefreshCw,
  XCircle,
  GitBranch,
  BellRing,
  Clock,
} from 'lucide-react';
import { VoiceSettingsModal } from '../VoiceSettingsModal';
import { ProjectContextMemoryPanel } from '../ProjectContextMemoryPanel';
import { ConnectorHubPanel } from '../ConnectorHubPanel';
import { GitHubRateLimitDashboard } from '../GitHubRateLimitDashboard';
import { GitHubRepoSelector } from '../GitHubRepoSelector';
import { GitHubOAuthConnectModal } from '../GitHubOAuthConnectModal';
import { GitHubActivityTimeline } from '../GitHubActivityTimeline';
import { checkEnvironmentStatus, type EnvironmentStatus } from '../../utils/checkEnvironmentStatus';
import type { GitHubOAuthUser, MonitoredRepository } from '../../types/connectors';
import {
  isAutoSyncEnabled,
  setAutoSyncEnabled,
  getAutoSyncInterval,
  setAutoSyncInterval,
  getLastSyncReport,
  checkGitHubRepoUpdates,
  type AutoSyncReport,
} from '../../utils/githubAutoSync';
import {
  VoiceSettings,
  getVoiceSettings,
  saveVoiceSettings,
  speakText,
  stopSpeaking,
  getTTSEngineState,
  clearTTSError,
  getThaiVoiceStatus,
} from '../../utils/voiceSettings';

interface Checkpoint {
  id: string;
  description: string;
  createdAt: string;
  fileCount?: number;
}

interface SettingsViewProps {
  lang: 'en' | 'th';
  onToggleLang: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  lang,
  onToggleLang,
  theme,
  onToggleTheme,
}) => {
  const [environmentStatus, setEnvironmentStatus] = useState<EnvironmentStatus | null>(null);
  useEffect(() => {
    checkEnvironmentStatus().then(setEnvironmentStatus).catch(() => setEnvironmentStatus({ status: 'unavailable', missing: [], variables: [], features: [] }));
  }, []);
  const [token, setToken] = useState(() => localStorage.getItem('zyntheor_auth_token') || '');
  const [tokenSaved, setTokenSaved] = useState(false);
  const [isOAuthModalOpen, setIsOAuthModalOpen] = useState(false);
  const [connectedGitHubUser, setConnectedGitHubUser] = useState<GitHubOAuthUser | null>(() => {
    try {
      const saved = localStorage.getItem('zyntheor_github_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [activeRepo, setActiveRepo] = useState<MonitoredRepository | null>(() => {
    try {
      if (typeof localStorage !== 'undefined') {
        const saved = localStorage.getItem('zyntheor_active_github_repo');
        if (saved) return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return null;
  });

  const [autoSync, setAutoSync] = useState<boolean>(() => isAutoSyncEnabled());
  const [syncInterval, setSyncInterval] = useState<number>(() => getAutoSyncInterval());
  const [isManualSyncing, setIsManualSyncing] = useState(false);
  const [syncReport, setSyncReport] = useState<AutoSyncReport | null>(() => getLastSyncReport());
  const [syncFeedbackMsg, setSyncFeedbackMsg] = useState<string | null>(null);

  const handleToggleAutoSync = () => {
    const next = !autoSync;
    setAutoSync(next);
    setAutoSyncEnabled(next);
  };

  const handleChangeSyncInterval = (newInterval: number) => {
    setSyncInterval(newInterval);
    setAutoSyncInterval(newInterval);
  };

  const handleManualSyncNow = async () => {
    if (!activeRepo) {
      setSyncFeedbackMsg(lang === 'th' ? 'UNAVAILABLE — ยังไม่ได้เลือก repository' : 'UNAVAILABLE — No repository selected.');
      return;
    }
    setIsManualSyncing(true);
    setSyncFeedbackMsg(null);
    try {
      const res = await checkGitHubRepoUpdates(activeRepo, token);
      setSyncReport(res.report);
      setSyncFeedbackMsg(
        lang === 'th'
          ? `ซิงก์เรียบร้อย: ${res.hasUpdates ? `พบ ${res.newIssues.length} issues และ ${res.newPRs.length} PRs ใหม่ ส่งแจ้งเตือนในแชตแล้ว` : 'ข้อมูลในคลังเป็นปัจจุบันแล้ว'}`
          : `Sync complete: ${res.hasUpdates ? `Found ${res.newIssues.length} new issues and ${res.newPRs.length} new PRs` : 'Repository is up to date'}`
      );
    } catch (err: any) {
      setSyncFeedbackMsg(err.message || 'Sync failed');
    } finally {
      setIsManualSyncing(false);
      window.setTimeout(() => setSyncFeedbackMsg(null), 4000);
    }
  };

  const handleGitHubTokenSaved = (newToken: string, user?: GitHubOAuthUser) => {
    setToken(newToken);
    setTokenSaved(true);
    localStorage.setItem('zyntheor_auth_token', newToken);
    localStorage.setItem('apphub_auth_token', newToken);
    localStorage.setItem('zyntheor_github_token', newToken);
    if (user) {
      setConnectedGitHubUser(user);
      try {
        localStorage.setItem('zyntheor_github_user', JSON.stringify(user));
      } catch { /* ignore */ }
    }
    window.dispatchEvent(new CustomEvent('zyntheor:token-updated', { detail: { token: newToken, user } }));
    window.setTimeout(() => setTokenSaved(false), 2500);
  };
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>([]);
  const [newSnapshotDesc, setNewSnapshotDesc] = useState('');
  const [checkpointMsg, setCheckpointMsg] = useState<string | null>(null);
  const [temporaryRetentionDays, setTemporaryRetentionDays] = useState(() => localStorage.getItem('zyntheor_temporary_retention_days') || '7');
  const [persistentRetention, setPersistentRetention] = useState(() => localStorage.getItem('zyntheor_persistent_memory_retention') || 'until_deleted');
  const [retentionSaved, setRetentionSaved] = useState(false);

  const saveRetentionPolicy = () => {
    localStorage.setItem('zyntheor_temporary_retention_days', temporaryRetentionDays);
    localStorage.setItem('zyntheor_persistent_memory_retention', persistentRetention);
    setRetentionSaved(true);
    window.setTimeout(() => setRetentionSaved(false), 2500);
  };

  // Load checkpoints
  const fetchCheckpoints = async () => {
    try {
      const res = await fetch('/api/checkpoints');
      if (res.ok) {
        const data = await res.json();
        setCheckpoints(data.checkpoints || []);
      }
    } catch {
      setCheckpoints([
        {
          id: 'cp_init',
          description: 'Initial workspace snapshot',
          createdAt: new Date().toISOString(),
          fileCount: 5,
        },
      ]);
    }
  };

  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(getVoiceSettings());
  const [isPlayingVoiceTest, setIsPlayingVoiceTest] = useState(false);
  const [ttsEngineState, setTtsEngineState] = useState(getTTSEngineState());
  const [thaiVoiceInfo, setThaiVoiceInfo] = useState<{ hasThaiVoice: boolean; voiceName?: string; isFallback: boolean }>({
    hasThaiVoice: false,
    isFallback: true,
  });

  useEffect(() => {
    fetchCheckpoints();

    // Check native Thai voice status
    getThaiVoiceStatus().then((info) => {
      setThaiVoiceInfo(info);
    });

    const handleVoiceUpdate = (e: any) => {
      if (e.detail) {
        setVoiceSettings(e.detail);
      } else {
        setVoiceSettings(getVoiceSettings());
      }
    };

    const handleTTSStateUpdate = (e: any) => {
      if (e.detail) {
        setTtsEngineState(e.detail);
      } else {
        setTtsEngineState(getTTSEngineState());
      }
    };

    window.addEventListener('zyntheor-voice-settings-updated', handleVoiceUpdate);
    window.addEventListener('zyntheor-tts-engine-state', handleTTSStateUpdate);

    return () => {
      window.removeEventListener('zyntheor-voice-settings-updated', handleVoiceUpdate);
      window.removeEventListener('zyntheor-tts-engine-state', handleTTSStateUpdate);
      stopSpeaking();
    };
  }, []);

  const handleToggleAutoRead = () => {
    const updated: VoiceSettings = {
      ...voiceSettings,
      autoReadResponses: !voiceSettings.autoReadResponses,
    };
    setVoiceSettings(updated);
    saveVoiceSettings(updated);
  };

  const handleToggleRestrictSensitive = () => {
    const updated: VoiceSettings = {
      ...voiceSettings,
      restrictToNonSensitive: !voiceSettings.restrictToNonSensitive,
    };
    setVoiceSettings(updated);
    saveVoiceSettings(updated);
  };

  const handleClearBufferError = () => {
    clearTTSError();
    setTtsEngineState(getTTSEngineState());
  };

  const handleTestQuickSpeech = () => {
    if (isPlayingVoiceTest) {
      stopSpeaking();
      setIsPlayingVoiceTest(false);
      return;
    }

    setIsPlayingVoiceTest(true);
    const text =
      lang === 'th'
        ? 'ทดสอบระบบเสียงสังเคราะห์ Zyntheor การตั้งค่าพร้อมใช้งานครับ'
        : 'Zyntheor voice interaction engine is active and configured.';

    speakText(
      text,
      voiceSettings,
      () => setIsPlayingVoiceTest(false),
      () => setIsPlayingVoiceTest(false)
    );
  };

  const handleSaveToken = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('zyntheor_auth_token', token.trim());
    setTokenSaved(true);
    setTimeout(() => setTokenSaved(false), 2500);
  };

  const handleCreateSnapshot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSnapshotDesc.trim()) return;

    try {
      const res = await fetch('/api/checkpoints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: newSnapshotDesc.trim() }),
      });
      if (res.ok) {
        const data = await res.json();
        setCheckpoints((prev) => [data.checkpoint, ...prev]);
        setNewSnapshotDesc('');
        setCheckpointMsg(lang === 'th' ? 'สร้าง Snapshot สำเร็จ!' : 'Snapshot created successfully!');
      }
    } catch (e: any) {
      setCheckpointMsg(`Error: ${e.message}`);
    }
  };

  const handleRestoreCheckpoint = async (id: string) => {
    if (!confirm(lang === 'th' ? 'ต้องการ Restore กลับไปยัง Snapshot นี้หรือไม่?' : 'Restore to this snapshot?')) return;
    try {
      const res = await fetch(`/api/checkpoints/${id}/restore`, { method: 'POST' });
      if (res.ok) {
        setCheckpointMsg(lang === 'th' ? 'Restore Snapshot เรียบร้อยแล้ว' : 'Snapshot restored successfully');
      }
    } catch (e: any) {
      setCheckpointMsg(`Error: ${e.message}`);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-100 overflow-y-auto p-6 space-y-6">
      {/* Header */}
      <div className="border-b border-zinc-800 pb-4">
        <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 tracking-wider uppercase mb-1">
          <Settings className="w-3.5 h-3.5" />
          <span>{lang === 'th' ? 'การกำหนดค่าระบบและสถาปัตยกรรม' : 'RUNTIME CONFIGURATION'}</span>
        </div>
        <h1 className="text-xl font-bold text-zinc-100">
          {lang === 'th' ? 'Workspace & System Settings' : 'Workspace & System Settings'}
        </h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          {lang === 'th'
            ? 'ตรวจสอบพารามิเตอร์ backend ผู้ให้บริการ AI โทเค็นความปลอดภัย และภาษาที่ใช้งาน'
            : 'Configure security tokens, assistant identity, checkpoints, and preferences'}
        </p>
      </div>

      {environmentStatus && (
        <section role="status" aria-label={lang === 'th' ? 'สถานะ environment' : 'Environment status'} className={`max-w-5xl rounded-xl border p-4 ${environmentStatus.status === 'ready' ? 'border-emerald-800 bg-emerald-950/30' : 'border-amber-700 bg-amber-950/30'}`}>
          <div className="flex items-center gap-2 font-semibold text-sm">
            {environmentStatus.status === 'ready' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <ShieldAlert className="w-4 h-4 text-amber-400" />}
            {lang === 'th' ? (environmentStatus.status === 'ready' ? 'Environment พร้อมใช้งาน' : 'Environment ต้องตั้งค่าเพิ่มเติม') : (environmentStatus.status === 'ready' ? 'Environment ready' : 'Environment needs configuration')}
          </div>
          <div className="mt-3 grid sm:grid-cols-2 gap-2 text-xs">
            {(environmentStatus.variables || []).map((item: any) => <div key={item.name} className="flex justify-between gap-3 text-zinc-300"><span className="font-mono">{item.name}{item.required ? ' · required' : ''}</span><span className={item.configured ? 'text-emerald-400' : item.required ? 'text-rose-400' : 'text-zinc-500'}>{item.configured ? 'CONFIGURED' : item.required ? 'MISSING' : 'OPTIONAL'}</span></div>)}
          </div>
          {(environmentStatus.features || []).some((feature: any) => !feature.available) && <div className="mt-3 border-t border-amber-800/60 pt-2 text-xs text-amber-200">{lang === 'th' ? 'ฟีเจอร์ที่ถูกบล็อก:' : 'BLOCKED features:'} {(environmentStatus.features || []).filter((feature: any) => !feature.available).map((feature: any) => `${feature.name} (${feature.reason})`).join(' · ')}</div>}
        </section>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl">
        {/* Section 1: Security & Bearer Token */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-zinc-200">
            <Key className="w-4 h-4 text-cyan-400" />
            <span>{lang === 'th' ? 'ความปลอดภัย & Bearer Token' : 'Security & Bearer Token'}</span>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            {lang === 'th'
              ? 'ระบบรอบคอบและปลอดภัยด้วยโทเค็น APPHUB_AUTH_TOKEN (อย่างน้อย 32 ตัวอักษร) เพื่อป้องกันการเข้าถึงจากภายนอกโดยไม่ได้รับอนุญาต'
              : 'Server security can require a bearer token (configured in APPHUB_AUTH_TOKEN, min 32 chars). Enter it once to unlock session.'}
          </p>

          <form onSubmit={handleSaveToken} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">
                Workspace Access Token
              </label>
              <input
                type="password"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="apphub-workspace-token-key-min-32-chars"
                className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-xs font-mono text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-zinc-500">
                {token.length >= 32 ? '✓ ความยาวถูกต้อง (>= 32 chars)' : '⚠️ ความยาวต่ำกว่า 32 ตัวอักษร'}
              </span>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold text-xs"
              >
                {tokenSaved ? 'บันทึกแล้ว ✓' : lang === 'th' ? 'บันทึกโทเค็น' : 'Save Token'}
              </button>
            </div>
          </form>

          {/* GitHub OAuth Account Integration */}
          <div className="pt-3 border-t border-zinc-800">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-300">
                <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
                <span>{lang === 'th' ? 'การยืนยันตัวตน GitHub OAuth' : 'GitHub OAuth Account'}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-zinc-800 text-zinc-400 border border-zinc-700">
                {connectedGitHubUser ? 'Authenticated' : 'Optional'}
              </span>
            </div>

            {connectedGitHubUser ? (
              <div className="p-3 bg-zinc-950 border border-emerald-900/40 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {connectedGitHubUser.avatarUrl ? (
                    <img
                      src={connectedGitHubUser.avatarUrl}
                      alt={connectedGitHubUser.login}
                      className="w-7 h-7 rounded-full border border-emerald-500/50"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center text-xs font-bold">
                      {connectedGitHubUser.login[0]?.toUpperCase()}
                    </div>
                  )}
                  <div>
                    <div className="text-xs font-bold text-zinc-100 flex items-center gap-1.5">
                      <span>@{connectedGitHubUser.login}</span>
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    </div>
                    <div className="text-[10px] text-zinc-500">
                      {connectedGitHubUser.name ? `${connectedGitHubUser.name} • ` : ''}
                      {lang === 'th' ? 'เชื่อมต่อแล้ว' : 'Token active'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIsOAuthModalOpen(true)}
                    className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] font-medium"
                  >
                    {lang === 'th' ? 'จัดการ' : 'Manage'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setConnectedGitHubUser(null);
                      localStorage.removeItem('zyntheor_github_user');
                      localStorage.removeItem('zyntheor_github_token');
                    }}
                    className="px-2 py-1 rounded bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 text-[11px]"
                  >
                    {lang === 'th' ? 'ตัดการเชื่อมต่อ' : 'Disconnect'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-zinc-950 border border-zinc-850 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
                <div className="space-y-0.5">
                  <div className="text-xs font-medium text-zinc-300">
                    {lang === 'th' ? 'เชื่อมต่อ GitHub เพื่อใช้งาน Token จริง' : 'Connect user GitHub token via OAuth'}
                  </div>
                  <div className="text-[10px] text-zinc-500">
                    {lang === 'th'
                      ? 'แทนที่ placeholder ของ APPHUB_AUTH_TOKEN และเพิ่ม Rate limit 5,000 req/hr'
                      : 'Replaces placeholder APPHUB_AUTH_TOKEN & unlocks 5,000 req/hr quota'}
                  </div>
                </div>
                <button
                  type="button"
                  id="open-github-oauth-btn"
                  onClick={() => setIsOAuthModalOpen(true)}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-cyan-300 font-semibold text-xs flex items-center gap-1.5 shrink-0 transition-colors"
                >
                  <Key className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{lang === 'th' ? 'เชื่อมต่อ GitHub OAuth' : 'Connect GitHub'}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Section 2: AI Identity & Architecture Rules */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-zinc-200">
            <Bot className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'th' ? 'ข้อมูลตัวตนของ AI Assistant' : 'AI Assistant Identity & Policy'}</span>
          </div>
          <div className="space-y-2 text-xs text-zinc-300">
            <div className="flex justify-between py-1 border-b border-zinc-850">
              <span className="text-zinc-500">Execution Policy:</span>
              <span className="font-semibold text-emerald-400">Zero Phantom Execution</span>
            </div>
            <div className="flex justify-between py-1 border-b border-zinc-850">
              <span className="text-zinc-500">Cryptographic Verification:</span>
              <span className="font-mono text-zinc-300">SHA-256 Plan Hashes</span>
            </div>
            <div className="flex justify-between py-1 border-b border-zinc-850">
              <span className="text-zinc-500">Review Mode Constraint:</span>
              <span className="text-amber-400">Server File Write Forbidden</span>
            </div>
          </div>
        </div>

        {/* Section 3: Workspace Snapshots & Checkpoints */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-bold text-zinc-200">
              <Database className="w-4 h-4 text-amber-400" />
              <span>{lang === 'th' ? 'Snapshots & Checkpoints' : 'Workspace Checkpoints'}</span>
            </div>
          </div>

          <form onSubmit={handleCreateSnapshot} className="flex gap-2">
            <input
              type="text"
              value={newSnapshotDesc}
              onChange={(e) => setNewSnapshotDesc(e.target.value)}
              placeholder={lang === 'th' ? 'คำอธิบาย Snapshot (e.g. ก่อนรีแฟกเตอร์)' : 'Snapshot description...'}
              className="flex-1 px-3 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-cyan-300"
            >
              + Create
            </button>
          </form>

          {checkpointMsg && (
            <div className="text-[11px] text-cyan-400">{checkpointMsg}</div>
          )}

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {checkpoints.map((cp) => (
              <div
                key={cp.id}
                className="p-2.5 bg-zinc-950 border border-zinc-850 rounded-lg text-xs flex items-center justify-between"
              >
                <div>
                  <div className="font-medium text-zinc-200">{cp.description}</div>
                  <div className="text-[10px] text-zinc-500 font-mono">
                    {new Date(cp.createdAt).toLocaleTimeString()} • ID: {cp.id}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleRestoreCheckpoint(cp.id)}
                  className="px-2 py-1 rounded bg-zinc-800 hover:bg-cyan-950 hover:text-cyan-300 text-[11px] text-zinc-400"
                >
                  Restore
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Memory retention policy */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-zinc-200"><Database className="w-4 h-4 text-cyan-400" /><span>{lang === 'th' ? 'นโยบายระยะเวลาจัดเก็บความจำ' : 'Memory Retention Policies'}</span></div>
          <p className="text-[11px] text-zinc-500">{lang === 'th' ? 'บันทึกเป็นค่ากำหนดของอินเทอร์เฟซนี้ ไม่ได้ลบข้อมูลจากเซิร์ฟเวอร์โดยอัตโนมัติจนกว่าจะมีการบังคับใช้นโยบายฝั่ง backend' : 'These are saved UI preferences. Server-side deletion is not automatic unless the backend explicitly enforces these policies.'}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="space-y-1 text-xs text-zinc-300"><span>{lang === 'th' ? 'บริบทแชตชั่วคราว' : 'Temporary chat context'}</span><select value={temporaryRetentionDays} onChange={(e) => setTemporaryRetentionDays(e.target.value)} className="w-full rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-2"><option value="1">1 day</option><option value="7">7 days</option><option value="30">30 days</option><option value="90">90 days</option></select></label>
            <label className="space-y-1 text-xs text-zinc-300"><span>{lang === 'th' ? 'ความจำระยะยาว' : 'Persistent memory'}</span><select value={persistentRetention} onChange={(e) => setPersistentRetention(e.target.value)} className="w-full rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-2"><option value="until_deleted">Until explicitly deleted</option><option value="90_days">90 days (policy preference)</option><option value="365_days">365 days (policy preference)</option></select></label>
          </div>
          <div className="flex flex-wrap items-center gap-3"><button type="button" onClick={saveRetentionPolicy} className="rounded-lg bg-cyan-700 px-3 py-2 text-xs font-semibold text-white hover:bg-cyan-600">{lang === 'th' ? 'บันทึกนโยบาย' : 'Save policy'}</button>{retentionSaved && <span role="status" className="text-xs text-emerald-400">Saved in this browser</span>}<button type="button" onClick={() => { try { Object.keys(localStorage).filter((key) => /audit.*cache|cache.*audit|ledger.*cache/i.test(key)).forEach((key) => localStorage.removeItem(key)); window.dispatchEvent(new CustomEvent('zyntheor:audit-cache-cleared')); setCheckpointMsg(lang === 'th' ? 'ล้างแคช Audit ในเครื่องแล้ว เมื่อเปิด Audit Ledger จะดึงข้อมูลใหม่' : 'Local audit cache cleared. Audit Ledger will fetch fresh data when opened.'); } catch { setCheckpointMsg(lang === 'th' ? 'ไม่สามารถเข้าถึงแคชในเครื่องได้' : 'Local storage is unavailable.'); } }} className="rounded-lg border border-amber-800 bg-amber-950/50 px-3 py-2 text-xs font-semibold text-amber-300 hover:bg-amber-900/60">{lang === 'th' ? 'ล้างแคช Audit ในเครื่อง' : 'Clear Local Audit Cache'}</button></div>
        </div>

        {/* Section 4: Language & Interface Preferences */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-zinc-200">
            <Languages className="w-4 h-4 text-cyan-400" />
            <span>{lang === 'th' ? 'ภาษาและการแสดงผล' : 'Language & Display'}</span>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-zinc-950 border border-zinc-850 rounded-lg text-xs">
              <div>
                <div className="font-semibold text-zinc-200">
                  {lang === 'th' ? 'ภาษาของอินเทอร์เฟซ' : 'Interface Language'}
                </div>
                <div className="text-zinc-500 text-[11px]">
                  {lang === 'th' ? 'ไทย (ภาษาไทย) / English' : 'Thai / English'}
                </div>
              </div>
              <button
                type="button"
                onClick={onToggleLang}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-cyan-400"
              >
                {lang === 'th' ? '🇹🇭 ภาษาไทย' : '🇺🇸 English'}
              </button>
            </div>

            <div className="flex items-center justify-between p-3 bg-zinc-950 border border-zinc-800 rounded-lg text-xs">
              <div>
                <div className="font-semibold text-zinc-200">
                  {lang === 'th' ? 'ธีมการแสดงผล' : 'Color Theme'}
                </div>
                <div className="text-zinc-500 text-[11px]">
                  {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
                </div>
              </div>
              <button
                type="button"
                onClick={onToggleTheme}
                className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                title="Toggle Theme"
              >
                {theme === 'dark' ? <Moon className="w-4 h-4 text-cyan-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
              </button>
            </div>
          </div>
        </div>

        {/* Section 5: Voice Interaction Engine & TTS Settings */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4 md:col-span-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-bold text-zinc-200">
              <div className="w-6 h-6 rounded-lg bg-cyan-950 text-cyan-400 flex items-center justify-center border border-cyan-800">
                <Volume2 className="w-3.5 h-3.5" />
              </div>
              <span>
                {lang === 'th'
                  ? 'ระบบเสียงโต้ตอบ & Text-to-Speech (Thai Voice Engine)'
                  : 'Thai Voice Interaction Engine & TTS'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {/* Real-time status badge */}
              <div
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border ${
                  ttsEngineState.bufferStatus === 'speaking'
                    ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                    : ttsEngineState.bufferStatus === 'paused'
                    ? 'bg-amber-950 text-amber-400 border-amber-800'
                    : ttsEngineState.bufferStatus === 'error'
                    ? 'bg-rose-950 text-rose-400 border-rose-800'
                    : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    ttsEngineState.bufferStatus === 'speaking'
                      ? 'bg-emerald-400 animate-pulse'
                      : ttsEngineState.bufferStatus === 'paused'
                      ? 'bg-amber-400'
                      : ttsEngineState.bufferStatus === 'error'
                      ? 'bg-rose-400'
                      : 'bg-zinc-600'
                  }`}
                />
                <span>
                  {ttsEngineState.bufferStatus === 'speaking'
                    ? lang === 'th' ? 'ACTIVE (กำลังสังเคราะห์เสียง)' : 'ACTIVE (Speaking)'
                    : ttsEngineState.bufferStatus === 'paused'
                    ? lang === 'th' ? 'PAUSED (หยุดชั่วคราว)' : 'PAUSED'
                    : ttsEngineState.bufferStatus === 'error'
                    ? lang === 'th' ? 'TTS ERROR (พบข้อผิดพลาด)' : 'TTS ERROR'
                    : lang === 'th' ? 'INACTIVE (สแตนด์บาย)' : 'INACTIVE (Idle)'}
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800">
                Web Speech API
              </span>
            </div>
          </div>

          <p className="text-xs text-zinc-400 leading-relaxed">
            {lang === 'th'
              ? 'ควบคุมโมเดลเสียงภาษาไทยและอังกฤษ ปรับความเร็วในการพูด (Speaking Rate) ระดับเสียง (Pitch/Volume) และกำหนดพฤติกรรมการอ่านคำตอบของ AI โดยอัตโนมัติ'
              : 'Configure synthesized Thai/English voice models, speaking speed, pitch, and default auto-read preferences for new agent responses.'}
          </p>

          {/* Real-time Status Card & TTS Buffer Errors Alert */}
          {ttsEngineState.lastError ? (
            <div className="p-3 bg-rose-950/40 border border-rose-900/60 rounded-xl flex items-start justify-between gap-3 text-xs text-rose-300">
              <div className="flex items-start gap-2">
                <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <div className="font-semibold text-rose-200">
                    {lang === 'th' ? 'รายงานข้อผิดพลาด TTS Buffer:' : 'Active TTS Buffer Error:'}
                  </div>
                  <div className="text-[11px] text-rose-400 leading-snug">{ttsEngineState.lastError}</div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleClearBufferError}
                className="shrink-0 px-2 py-1 rounded bg-rose-900/50 hover:bg-rose-800 text-rose-200 text-[11px] font-medium transition-colors cursor-pointer"
              >
                {lang === 'th' ? 'ล้างข้อผิดพลาด' : 'Clear Error'}
              </button>
            </div>
          ) : (
            <div className="px-3 py-2 bg-emerald-950/20 border border-emerald-900/30 rounded-xl flex items-center justify-between text-xs text-emerald-400/90">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[11px]">
                  {lang === 'th'
                    ? 'สถานะ TTS Buffer: ปกติ (ไม่มีข้อผิดพลาดคั่งค้างในคิวสังเคราะห์เสียง)'
                    : 'TTS Buffer Status: Clear and healthy (No active buffer errors)'}
                </span>
              </div>
              <span className="text-[10px] text-zinc-500 font-mono">
                {thaiVoiceInfo.hasThaiVoice
                  ? `🇹🇭 ${thaiVoiceInfo.voiceName || 'Native Thai'}`
                  : lang === 'th' ? '⚠️ ใช้โมเดลเสียงระบบสำรอง (Browser Fallback)' : '⚠️ Browser Fallback'}
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 bg-zinc-950 border border-zinc-850 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
                {lang === 'th' ? 'โมเดลเสียงไทย' : 'Thai Voice Model'}
              </span>
              <div className="text-xs font-medium text-amber-300 truncate">
                {thaiVoiceInfo.hasThaiVoice
                  ? thaiVoiceInfo.voiceName
                  : voiceSettings.thaiVoiceURI
                  ? voiceSettings.thaiVoiceURI.split('/').pop() || 'Custom Thai'
                  : 'Browser Fallback / Auto'}
              </div>
            </div>

            <div className="p-3 bg-zinc-950 border border-zinc-850 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
                {lang === 'th' ? 'โมเดลเสียงอังกฤษ' : 'English Voice Model'}
              </span>
              <div className="text-xs font-medium text-blue-300 truncate">
                {voiceSettings.englishVoiceURI ? voiceSettings.englishVoiceURI.split('/').pop() || 'Custom English' : 'Default / Auto'}
              </div>
            </div>

            <div className="p-3 bg-zinc-950 border border-zinc-850 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
                {lang === 'th' ? 'ความเร็วการอ่าน' : 'Speaking Rate'}
              </span>
              <div className="text-xs font-mono font-bold text-cyan-400">
                {voiceSettings.speakingRate.toFixed(2)}x
              </div>
            </div>

            <div className="p-3 bg-zinc-950 border border-zinc-850 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider">
                {lang === 'th' ? 'อ่านอัตโนมัติ' : 'Auto-Read'}
              </span>
              <div className="text-xs font-medium text-emerald-400">
                {voiceSettings.autoReadResponses
                  ? (voiceSettings.autoReadMode === 'summary'
                    ? (lang === 'th' ? 'เปิด (สรุปก่อน)' : 'Active (Summary)')
                    : (lang === 'th' ? 'เปิด (อ่านเต็ม)' : 'Active (Full)'))
                  : (lang === 'th' ? 'ปิดใช้งาน' : 'Disabled')}
              </div>
            </div>
          </div>

          {/* New Toggle: Restrict Voice Output to non-sensitive content */}
          <div className="p-3.5 bg-zinc-950/80 border border-zinc-850 rounded-xl flex items-center justify-between gap-4">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2 font-semibold text-xs text-zinc-200">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>
                  {lang === 'th'
                    ? 'จำกัดเสียงเฉพาะเนื้อหาที่ไม่ละเอียดอ่อน (Restrict Voice Output to non-sensitive content)'
                    : 'Restrict Voice Output to non-sensitive content'}
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-snug">
                {lang === 'th'
                  ? 'บังคับให้ระบบเสียงข้ามการอ่านออกเสียงข้อความที่มี API Keys, Bearer Tokens, รหัสผ่าน หรือ Credentials โดยอัตโนมัติ เพื่อป้องกันการได้ยินข้อมูลความลับ'
                  : 'Enforce that the voice engine skips messages containing detected secrets, tokens, or API key patterns.'}
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={voiceSettings.restrictToNonSensitive}
                onChange={handleToggleRestrictSensitive}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
            </label>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-zinc-850">
            <div className="flex items-center gap-3">
              {/* Quick Toggle Auto-Read */}
              <label className="flex items-center gap-2 cursor-pointer text-xs text-zinc-300">
                <input
                  type="checkbox"
                  checked={voiceSettings.autoReadResponses}
                  onChange={handleToggleAutoRead}
                  className="rounded bg-zinc-800 border-zinc-700 text-cyan-500 focus:ring-0"
                />
                <span>
                  {lang === 'th'
                    ? 'เปิดอ่านคำตอบอัตโนมัติ (Auto-read responses)'
                    : 'Auto-read new responses'}
                </span>
              </label>

              {/* Quick Test Speech */}
              <button
                type="button"
                onClick={handleTestQuickSpeech}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-cyan-300 text-xs font-medium transition-colors"
              >
                {isPlayingVoiceTest ? (
                  <>
                    <Square className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
                    <span>{lang === 'th' ? 'หยุดเสียง' : 'Stop'}</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
                    <span>{lang === 'th' ? 'ทดสอบเสียง' : 'Test Speech'}</span>
                  </>
                )}
              </button>
            </div>

            {/* Open Full Voice Settings Modal Button */}
            <button
              type="button"
              id="open-voice-settings-btn"
              onClick={() => setIsVoiceModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-zinc-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
            >
              <Sliders className="w-4 h-4" />
              <span>
                {lang === 'th'
                  ? 'ปรับแต่งโมเดลเสียง & ความเร็ว (Voice Settings)'
                  : 'Customize Voice Models & Rates'}
              </span>
            </button>
          </div>
        </div>

        {/* Section: External Tool Connectors & GitHub Client Hub */}
        <ConnectorHubPanel lang={lang} />

        {/* Section: Active Session GitHub Repository Selector */}
        <div className="md:col-span-2">
          <GitHubRepoSelector
            lang={lang}
            onRepoSelected={(selected) => setActiveRepo(selected)}
          />
        </div>

        {/* Section: GitHub Repository Auto-Sync & Real-Time Notification */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-4 md:col-span-2 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-400">
                <BellRing className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-zinc-100">
                    {lang === 'th'
                      ? 'ระบบซิงก์อัตโนมัติ & แจ้งเตือนแชต (GitHub Auto-Sync)'
                      : 'GitHub Auto-Sync & Chat Notification'}
                  </h3>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-mono border ${
                      autoSync
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                        : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                    }`}
                  >
                    {autoSync ? (lang === 'th' ? 'กำลังซิงก์' : 'Active') : (lang === 'th' ? 'ปิดอยู่' : 'Disabled')}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {lang === 'th'
                    ? 'ดึงประเด็นปัญหา (Issues) และ Pull Requests ใหม่จากคลังโค้ดโดยอัตโนมัติ และส่งข้อความแจ้งเตือนในห้องแชต'
                    : 'Periodically fetches new issues and pull requests from connected repository and notifies in chat'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 self-end sm:self-auto">
              <span className="text-xs font-medium text-zinc-300 hidden sm:inline">
                {autoSync ? (lang === 'th' ? 'เปิดใช้งาน' : 'Enabled') : (lang === 'th' ? 'ปิดใช้งาน' : 'Disabled')}
              </span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoSync}
                  onChange={handleToggleAutoSync}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Sync Interval */}
            <div className="p-3 bg-zinc-950/80 border border-zinc-850 rounded-xl space-y-1">
              <label className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider block">
                {lang === 'th' ? 'ความถี่ในการซิงก์ (Interval)' : 'Sync Interval'}
              </label>
              <select
                value={syncInterval}
                onChange={(e) => handleChangeSyncInterval(Number(e.target.value))}
                disabled={!autoSync}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-200 focus:outline-none focus:border-amber-500 disabled:opacity-40"
              >
                <option value={30000}>{lang === 'th' ? 'ทุก 30 วินาที' : 'Every 30 seconds'}</option>
                <option value={60000}>{lang === 'th' ? 'ทุก 1 นาที (แนะนำ)' : 'Every 1 minute (Recommended)'}</option>
                <option value={120000}>{lang === 'th' ? 'ทุก 2 นาที' : 'Every 2 minutes'}</option>
                <option value={300000}>{lang === 'th' ? 'ทุก 5 นาที' : 'Every 5 minutes'}</option>
              </select>
            </div>

            {/* Target Monitored Repo */}
            <div className="p-3 bg-zinc-950/80 border border-zinc-850 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider block">
                {lang === 'th' ? 'คลังเป้าหมายที่มอนิเตอร์' : 'Monitored Project'}
              </span>
              <div className="text-xs font-mono font-bold text-cyan-300 truncate">
                {activeRepo?.fullName || 'UNAVAILABLE'}
              </div>
              <div className="text-[10px] text-zinc-500 truncate">
                Branch: {activeRepo?.selectedBranch || activeRepo?.defaultBranch || 'UNAVAILABLE'}
              </div>
            </div>

            {/* Notification Target */}
            <div className="p-3 bg-zinc-950/80 border border-zinc-850 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-semibold text-zinc-500 tracking-wider block">
                {lang === 'th' ? 'ปลายทางแจ้งเตือน' : 'Notification Target'}
              </span>
              <div className="text-xs font-medium text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{lang === 'th' ? 'Assistant Chat' : 'Assistant Chat'}</span>
              </div>
              <div className="text-[10px] text-zinc-500">
                {lang === 'th' ? 'แจ้งเตือนเมื่อพบ Issue หรือ PR ใหม่' : 'Notifies immediately upon new Issue or PR'}
              </div>
            </div>
          </div>

          {/* Sync Trigger and Status Feedback */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-zinc-850 text-xs">
            <div className="flex items-center gap-2 text-zinc-400 text-[11px]">
              <Clock className="w-3.5 h-3.5 text-zinc-500" />
              <span>
                {syncReport?.lastSyncTime
                  ? `${lang === 'th' ? 'ซิงก์ล่าสุด:' : 'Last sync:'} ${syncReport.lastSyncTime} • ${syncReport.message || 'Up to date'}`
                  : lang === 'th' ? 'พร้อมซิงก์ข้อมูลตามกำหนดเวลา' : 'Ready for scheduled sync'}
              </span>
            </div>

            <button
              type="button"
              onClick={handleManualSyncNow}
              disabled={isManualSyncing || !activeRepo}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-300 text-xs font-semibold transition-colors disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isManualSyncing ? 'animate-spin text-amber-400' : ''}`} />
              <span>{lang === 'th' ? 'ตรวจสอบการอัปเดตเดี๋ยวนี้' : 'Sync Now'}</span>
            </button>
          </div>

          {syncFeedbackMsg && (
            <div className="p-2.5 rounded-lg bg-amber-950/60 border border-amber-800 text-amber-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{syncFeedbackMsg}</span>
            </div>
          )}
        </div>

        {/* Section: GitHub Activity Timeline (Recent Commits & Pull Request Status) */}
        <div className="md:col-span-2">
          <GitHubActivityTimeline
            lang={lang}
            monitoredRepo={activeRepo}
            githubToken={token}
          />
        </div>

        {/* Section: GitHub API Rate Limit Usage Dashboard (Recharts) */}
        <div className="md:col-span-2">
          <GitHubRateLimitDashboard lang={lang} githubToken={token} />
        </div>

        {/* Section: Project Context Engine & Persistent Memory */}
        <ProjectContextMemoryPanel lang={lang} currentWorkspaceId="default" />
      </div>

      {/* Voice Interaction Settings Modal */}
      <VoiceSettingsModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        lang={lang}
      />

      {/* GitHub OAuth Connect Modal */}
      <GitHubOAuthConnectModal
        isOpen={isOAuthModalOpen}
        onClose={() => setIsOAuthModalOpen(false)}
        lang={lang}
        onTokenSaved={handleGitHubTokenSaved}
      />
    </div>
  );
};
