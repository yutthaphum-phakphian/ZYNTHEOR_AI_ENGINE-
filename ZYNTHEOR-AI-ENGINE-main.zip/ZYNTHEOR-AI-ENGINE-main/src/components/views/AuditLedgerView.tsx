import React, { useState, useEffect, useMemo } from 'react';
import {
  ShieldCheck,
  Search,
  RotateCcw,
  Download,
  Filter,
  Clock,
  Key,
  FileCheck2,
  Lock,
  ChevronRight,
  X,
  FileText,
  Terminal,
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ShieldAlert,
  Zap,
} from 'lucide-react';

export interface LedgerMismatch {
  issueId: string;
  type: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  planId?: string;
  stepId?: string;
  eventId?: string;
  expected?: string;
  actual?: string;
  message: string;
  recordedAt?: string;
}

export interface PlanIntegrityReport {
  planId: string;
  goal: string;
  status: string;
  recordedHash: string;
  recalculatedHash: string;
  hashValid: boolean;
  approvalValid: boolean;
  evidenceConsistent: boolean;
  totalEvents: number;
  matchedEvidenceCount: number;
  issues: LedgerMismatch[];
}

export interface LedgerIntegrityReport {
  valid: boolean;
  status: 'VERIFIED' | 'FAIL' | 'TAMPERED';
  totalEventsChecked: number;
  totalPlansChecked: number;
  totalEvidenceRecordsChecked: number;
  plans: PlanIntegrityReport[];
  mismatches: LedgerMismatch[];
  summary: string;
  verifiedAt: string;
}

export interface AuditEvent {
  id?: string;
  type: string;
  planId?: string;
  hash?: string;
  timestamp: string;
  actor?: string;
  data?: Record<string, unknown>;
  details?: Record<string, unknown> | string;
}

export interface EvidenceRecord {
  id: string;
  taskId: string;
  command: string | string[];
  exitCode: number;
  outputSummary: string;
  changedFiles: string[];
  timestamp: string;
  verified: boolean;
  verificationEvidence?: Array<{
    category: string;
    statement: string;
    source: string;
    verified: boolean;
  }>;
}

interface AuditLedgerViewProps {
  lang?: 'en' | 'th';
  repoFullName?: string;
}

import {
  containsSensitiveData,
  redactSensitiveLog,
  sanitizeLogData,
} from '../../utils/auditRedaction.js';
import { VerifiedTaskHashHistory } from './VerifiedTaskHashHistory';
import { RepositoryMetrics } from '../RepositoryMetrics';
import { findHighRiskRetries } from '../../utils/newFeatureLogic';
import { derivePqcStatus, type PqcEventLike, type PqcSignatureStatus } from '../../utils/pqcStatus';

export type { PqcSignatureStatus };

export { containsSensitiveData, redactSensitiveLog, sanitizeLogData };

/** Identifiers of the registration being *requested*. They are targets, not evidence of certification. */
const GA_CERT_TARGET = {
  registrationId: 'GA-CERT-NOVA-2026-001',
  evidenceChainId: 'EV-2026-GA-CERT-NOVA-001',
  requiredCustody: 'CISO + System Architect',
  targetSeal: 'GOLD MASTER CERTIFIED',
} as const;

export function getPqcSignatureStatus(evt: AuditEvent | null | undefined): PqcSignatureStatus {
  return derivePqcStatus(evt as unknown as PqcEventLike | null | undefined);
}

export const PqcStatusBadge: React.FC<{
  status: PqcSignatureStatus;
  showLabel?: boolean;
  className?: string;
}> = ({ status, showLabel = true, className = '' }) => {
  if (status === 'Verified') {
    return (
      <span
        title="PQC Signature: Verified by server-side verification evidence"
        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800 shadow-sm ${className}`}
      >
        <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
        {showLabel && <span>Verified</span>}
      </span>
    );
  }
  if (status === 'Invalid') {
    return (
      <span
        title="PQC Quantum Signature: Invalid / Tampered Signature"
        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800 shadow-sm ${className}`}
      >
        <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
        {showLabel && <span>Invalid</span>}
      </span>
    );
  }
  return (
    <span
      title="PQC Signature: not verified (no server-side verification evidence)"
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800 shadow-sm ${className}`}
    >
      <Clock className="w-3 h-3 text-amber-400 shrink-0" />
      {showLabel && <span>Unverified</span>}
    </span>
  );
};

export const AuditLedgerView: React.FC<AuditLedgerViewProps> = ({
  lang = 'th',
  repoFullName,
}) => {
  const [activeLedgerTab, setActiveLedgerTab] = useState<'audit' | 'evidence' | 'integrity' | 'security_events'>('audit');
  const [securityEventsSubFilter, setSecurityEventsSubFilter] = useState<'ALL' | 'PQC' | 'DRIFT'>('ALL');
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [evidenceRecords, setEvidenceRecords] = useState<EvidenceRecord[]>([]);
  const [integrityReport, setIntegrityReport] = useState<LedgerIntegrityReport | null>(null);
  const [integrityLoading, setIntegrityLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('ALL');
  const [memoryConfidenceFilter, setMemoryConfidenceFilter] = useState<'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');
  const [memoryProvenanceFilter, setMemoryProvenanceFilter] = useState<'ALL' | 'VERIFIED_FACT' | 'USER_CLAIM'>('ALL');
  const [pqcFilter, setPqcFilter] = useState<'ALL' | 'Verified' | 'Pending' | 'Invalid'>('ALL');
  const [loading, setLoading] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<AuditEvent | null>(null);
  const [selectedEvidence, setSelectedEvidence] = useState<EvidenceRecord | null>(null);
  const [redactedCount, setRedactedCount] = useState<number>(0);
  const [auditUnavailable, setAuditUnavailable] = useState(false);

  const fetchIntegrityReport = async () => {
    setIntegrityLoading(true);
    try {
      const res = await fetch('/api/audit/verify-integrity');
      if (res.ok) {
        const data = await res.json();
        setIntegrityReport(data.report);
      }
    } catch (e) {
      console.warn('Failed to verify ledger integrity:', e);
    } finally {
      setIntegrityLoading(false);
    }
  };

  const fetchAuditEvents = async () => {
    setLoading(true);
    setAuditUnavailable(false);
    let detectedRedactions = 0;
    try {
      const [resAudit, resEvidence, resIntegrity] = await Promise.all([
        fetch('/api/audit'),
        fetch('/api/evidence-ledger').catch(() => null),
        fetch('/api/audit/verify-integrity').catch(() => null),
      ]);

      if (resAudit.ok) {
        const data = await resAudit.json();
        const rawEvents = data.events || [];
        const sanitizedEvents = rawEvents.map((evt: any) => {
          const rawStr = JSON.stringify(evt);
          if (containsSensitiveData(rawStr)) {
            detectedRedactions += 1;
          }
          return sanitizeLogData(evt);
        });
        setEvents(sanitizedEvents);
      } else {
        throw new Error('Audit endpoint unavailable');
      }

      if (resEvidence && resEvidence.ok) {
        const evData = await resEvidence.json();
        const rawRecords = evData.records || [];
        const sanitizedRecords = rawRecords.map((rec: any) => {
          const rawStr = JSON.stringify(rec);
          if (containsSensitiveData(rawStr)) {
            detectedRedactions += 1;
          }
          return sanitizeLogData(rec);
        });
        setEvidenceRecords(sanitizedRecords);
      }

      if (resIntegrity && resIntegrity.ok) {
        const intData = await resIntegrity.json();
        setIntegrityReport(intData.report);
      }

      setRedactedCount(detectedRedactions);
    } catch {
      setEvents([]);
      setEvidenceRecords([]);
      setIntegrityReport(null);
      setRedactedCount(0);
      setAuditUnavailable(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuditEvents();
  }, []);

  const filteredEvents = events.filter((e) => {
    const matchSearch =
      e.type.toLowerCase().includes(search.toLowerCase()) ||
      (e.planId && e.planId.toLowerCase().includes(search.toLowerCase())) ||
      (e.hash && e.hash.toLowerCase().includes(search.toLowerCase()));

    const matchType = filterType === 'ALL' || e.type === filterType;
    const data = (e.data || {}) as Record<string, unknown>;
    const isMemoryEvent = e.type.startsWith('memory_fact_');
    const confidenceTag = String(data.confidenceTag || (typeof data.confidence === 'number' ? (data.confidence >= 0.8 ? 'HIGH' : data.confidence >= 0.45 ? 'MEDIUM' : 'LOW') : 'LOW'));
    const provenance = String(data.provenanceKind || (data.verified === true ? 'VERIFIED_FACT' : 'USER_CLAIM'));
    const confidenceMatch = !isMemoryEvent || memoryConfidenceFilter === 'ALL' || confidenceTag === memoryConfidenceFilter;
    const provenanceMatch = !isMemoryEvent || memoryProvenanceFilter === 'ALL' || provenance === memoryProvenanceFilter;
    const pqcStatus = getPqcSignatureStatus(e);
    const pqcMatch = pqcFilter === 'ALL' || pqcStatus === pqcFilter;
    return matchSearch && matchType && confidenceMatch && provenanceMatch && pqcMatch;
  });

  const filteredEvidence = evidenceRecords.filter((rec) => {
    const cmdStr = Array.isArray(rec.command) ? rec.command.join(' ') : rec.command;
    return (
      rec.id.toLowerCase().includes(search.toLowerCase()) ||
      rec.taskId.toLowerCase().includes(search.toLowerCase()) ||
      cmdStr.toLowerCase().includes(search.toLowerCase()) ||
      rec.outputSummary.toLowerCase().includes(search.toLowerCase())
    );
  });

  const handleExport = () => {
    const exportData = {
      exportedAt: new Date().toISOString(),
      auditTrailRedacted: true,
      auditEvents: events.map((e) => sanitizeLogData(e)),
      memoryProvenanceLog: events.filter((e) => e.type.startsWith('memory_fact_')).map((e) => sanitizeLogData({ id: e.id, type: e.type, timestamp: e.timestamp, workspaceId: e.data?.workspaceId, factId: e.data?.factId, provenanceKind: e.data?.provenanceKind, evidence: e.data?.evidence, confidence: e.data?.confidence, confidenceTag: e.data?.confidenceTag, verified: e.data?.verified, stale: e.data?.stale })),
      evidenceRecords: evidenceRecords.map((r) => sanitizeLogData(r)),
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = `zyntheor_audit_ledger_redacted_${Date.now()}.json`;
    a.click();
  };

  // Security Events filtering (PQC Signature validation attempts & Mutation Drift alerts)
  const isPqcEvent = (evt: AuditEvent) => {
    const raw = JSON.stringify(evt).toLowerCase();
    return (
      raw.includes('pqc') ||
      raw.includes('dilithium') ||
      raw.includes('kyber') ||
      raw.includes('falcon') ||
      raw.includes('sphincs') ||
      raw.includes('quantum') ||
      raw.includes('signature') ||
      evt.type.toUpperCase().includes('PQC') ||
      Boolean((evt.data as any)?.pqcStatus)
    );
  };

  const isDriftEvent = (evt: AuditEvent) => {
    const raw = JSON.stringify(evt).toLowerCase();
    return (
      raw.includes('drift') ||
      raw.includes('mutation') ||
      raw.includes('tamper') ||
      raw.includes('integrity') ||
      raw.includes('mismatch') ||
      evt.type.toUpperCase().includes('DRIFT') ||
      evt.type.toUpperCase().includes('TAMPER')
    );
  };

  const securityEvents = useMemo(() => {
    return events.filter((evt) => isPqcEvent(evt) || isDriftEvent(evt));
  }, [events]);

  const filteredSecurityEvents = useMemo(() => {
    return securityEvents.filter((evt) => {
      if (securityEventsSubFilter === 'PQC') return isPqcEvent(evt);
      if (securityEventsSubFilter === 'DRIFT') return isDriftEvent(evt);
      return true;
    });
  }, [securityEvents, securityEventsSubFilter]);

  // The browser holds no signing keys, no digest source and no verifier. These actions therefore only
  // record that a request was made; every claim that needs evidence stays UNKNOWN / NOT_PERFORMED (No Fake).
  const postAuditEvent = async (payload: { type: string; status: string; data: Record<string, unknown> }, failLabel: string) => {
    try {
      const res = await fetch('/api/audit/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) console.warn(`${failLabel}: HTTP ${res.status}`);
    } catch (e) {
      console.warn(`${failLabel}:`, e);
    }
    void fetchAuditEvents();
  };

  const handleAnchorCertProtocol = async () => {
    await postAuditEvent({
      type: 'GLOBAL_LEDGER_REGISTRATION_REQUEST',
      status: 'UNKNOWN',
      data: {
        objective: 'คำขอลงทะเบียน GA-CERT NOVA 2026 ใน Sovereign Consensus Ledger (ยังไม่มีการรับรอง)',
        requestedRegistrationId: GA_CERT_TARGET.registrationId,
        requestedEvidenceChainId: GA_CERT_TARGET.evidenceChainId,
        requiredCustody: GA_CERT_TARGET.requiredCustody,
        merkleRootHash: null,
        dualCustodySignatures: null,
        pqcStatus: 'UNKNOWN',
        certification: 'UNKNOWN',
        statusMessage: 'บันทึกเฉพาะคำขอ: ยังไม่มี Merkle root จริง ลายเซ็น หรือผลตรวจสอบจากระบบที่ตรวจสอบได้',
      },
    }, 'Failed to record ledger registration request');
  };

  const handleTriggerPqcValidation = async () => {
    await postAuditEvent({
      type: 'PQC_SIGNATURE_VALIDATION_ATTEMPT',
      status: 'UNKNOWN',
      data: {
        algorithm: 'Dilithium-5 (ML-DSA-87)',
        validationResult: 'NOT_PERFORMED',
        pqcStatus: 'UNKNOWN',
        details: 'บันทึกคำขอตรวจ PQC เท่านั้น: ยังไม่มีตัวตรวจสอบลายเซ็นหรือ trust anchor ที่เชื่อมต่อ จึงไม่มีผลตรวจจริง',
      },
    }, 'Failed to record PQC validation request');
  };

  const handleTriggerMutationDriftScan = async () => {
    await postAuditEvent({
      type: 'MUTATION_DRIFT_SCAN_REQUEST',
      status: 'UNKNOWN',
      data: {
        target: 'System Sandbox Memory Boundary & Bytecode Digest',
        scanPerformed: false,
        driftDetected: null,
        driftPercentage: null,
        expectedDigest: null,
        observedDigest: null,
        statusMessage: 'บันทึกคำขอสแกนเท่านั้น: ยังไม่มีการวัด digest จริง จึงไม่ทราบว่ามี drift หรือไม่ (UNKNOWN)',
      },
    }, 'Failed to record drift scan request');
  };

  const highRiskEvents = findHighRiskRetries(events);

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Header */}
      <div className="border-b border-zinc-800 bg-zinc-900/50 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 tracking-wider uppercase mb-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'สมุดบันทึกตรวจสอบ (CRYPTOGRAPHIC AUDIT LEDGER)' : 'TAMPER-RESISTANT LOGS'}</span>
          </div>
          <h1 className="text-xl font-bold text-zinc-100">
            {lang === 'th' ? 'Cryptographic Audit Ledger' : 'Cryptographic Audit Ledger'}
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            {lang === 'th'
              ? 'ประวัติเหตุการณ์และหลักฐานเครื่องมือพร้อมตรวจสอบ SHA-256 Hash และระบบตัดข้อมูลลับอัตโนมัติ'
              : 'Persisted ledger events, tool execution proofs, and automatic sensitive credential redaction'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Active Auto-Redaction Badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-[11px] font-mono">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              {lang === 'th' ? 'การตัดข้อมูลลับอัตโนมัติเปิดใช้งาน (Redacted)' : 'Auto-Redaction Active'}
            </span>
          </div>

          <button
            type="button"
            onClick={() => {
              try { Object.keys(localStorage).filter((key) => /audit.*cache|cache.*audit|ledger.*cache/i.test(key)).forEach((key) => localStorage.removeItem(key)); } catch { /* storage may be unavailable */ }
              void fetchAuditEvents();
            }}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-amber-300 text-xs flex items-center gap-1.5 transition-colors"
            title={lang === 'th' ? 'ล้างแคชในเครื่องและดึง Ledger ใหม่' : 'Clear local audit cache and reload durable ledger'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'ล้างแคช Audit' : 'Clear Local Audit Cache'}</span>
          </button>
          <button
            type="button"
            onClick={fetchAuditEvents}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-300 text-xs flex items-center gap-1.5 transition-colors"
            title="Refresh"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{lang === 'th' ? 'รีเฟรช' : 'Refresh'}</span>
          </button>
          <button
            type="button"
            onClick={handleExport}
            className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-cyan-300 text-xs flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'ส่งออก Ledger ที่ตัดข้อมูลลับแล้ว' : 'Export Redacted JSON'}</span>
          </button>
        </div>
      </div>

      {auditUnavailable && (
        <div role="status" className="border-b border-amber-800/60 bg-amber-950/30 px-6 py-2 text-xs text-amber-200">
          [UNAVAILABLE] Audit data could not be loaded. No sample events are shown.
        </div>
      )}
      {highRiskEvents.length > 0 && <div className="flex items-center gap-2 border-b border-rose-800/60 bg-rose-950/50 px-6 py-2 text-xs text-rose-300"><AlertTriangle className="h-4 w-4" /><b>High-risk transition detected</b><span>พบ Retry ที่ไม่เปลี่ยน state จำนวน {highRiskEvents.length} รายการ — ควรตรวจสอบก่อนดำเนินการต่อ</span></div>}

      {/* Tabs & Redaction Notification Bar */}
      <div className="px-6 py-2.5 bg-zinc-900/60 border-b border-zinc-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
          <button
            type="button"
            onClick={() => setActiveLedgerTab('audit')}
            className={`px-3 py-1 rounded font-medium transition-colors ${
              activeLedgerTab === 'audit'
                ? 'bg-zinc-800 text-cyan-300 font-semibold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'th' ? `Audit Events (${events.length})` : `Audit Events (${events.length})`}
          </button>
          <button
            type="button"
            onClick={() => setActiveLedgerTab('evidence')}
            className={`px-3 py-1 rounded font-medium transition-colors ${
              activeLedgerTab === 'evidence'
                ? 'bg-zinc-800 text-cyan-300 font-semibold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {lang === 'th' ? `Evidence Ledger (${evidenceRecords.length})` : `Evidence Ledger (${evidenceRecords.length})`}
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveLedgerTab('integrity');
              if (!integrityReport) fetchIntegrityReport();
            }}
            className={`px-3 py-1 rounded font-medium flex items-center gap-1.5 transition-colors ${
              activeLedgerTab === 'integrity'
                ? 'bg-zinc-800 text-emerald-300 font-semibold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>
              {lang === 'th'
                ? `ตรวจสอบความสมบูรณ์ (${integrityReport ? integrityReport.status : 'Check'})`
                : `Ledger Integrity (${integrityReport ? integrityReport.status : 'Check'})`}
            </span>
            {integrityReport && (
              <span
                className={`w-2 h-2 rounded-full ${
                  integrityReport.valid ? 'bg-emerald-400' : 'bg-rose-500 animate-pulse'
                }`}
              />
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveLedgerTab('security_events')}
            className={`px-3 py-1 rounded font-medium flex items-center gap-1.5 transition-colors ${
              activeLedgerTab === 'security_events'
                ? 'bg-zinc-800 text-amber-300 font-semibold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <ShieldAlert className="w-3 h-3 text-amber-400" />
            <span>
              {lang === 'th'
                ? `Security Events (${securityEvents.length})`
                : `Security Events (${securityEvents.length})`}
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-zinc-400 font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span>
            {lang === 'th'
              ? 'ระบบตรวจจับและปิดบัง API Keys, Bearer Tokens, Passwords อัตโนมัติก่อนแสดงผล'
              : 'Auto-redaction masks API Keys, Bearer Tokens, and passwords before render'}
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-zinc-900/40 border-b border-zinc-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-md bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs">
          <Search className="w-3.5 h-3.5 text-zinc-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={
              activeLedgerTab === 'audit'
                ? lang === 'th'
                  ? 'ค้นหาตามประเภทเหตุการณ์, Plan ID, หรือ Hash...'
                  : 'Filter events by type, plan ID, or hash...'
                : lang === 'th'
                ? 'ค้นหาตาม Task ID, คำสั่ง, หรือผลลัพธ์...'
                : 'Filter evidence by task ID, command, or output...'
            }
            className="bg-transparent text-zinc-100 focus:outline-none flex-1 placeholder:text-zinc-600"
          />
        </div>

        {activeLedgerTab === 'audit' && (
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-zinc-500" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-300 focus:outline-none"
            >
              <option value="ALL">All Event Types</option>
              <option value="PLAN_PROPOSED">PLAN_PROPOSED</option>
              <option value="APPROVAL_REQUESTED">APPROVAL_REQUESTED</option>
              <option value="PLAN_APPROVED">PLAN_APPROVED</option>
              <option value="PLAN_REJECTED">PLAN_REJECTED</option>
              <option value="STEP_EXECUTED">STEP_EXECUTED</option>
              <option value="STEP_VERIFIED">STEP_VERIFIED</option>
            </select>
          </div>
        )}
      </div>

        {activeLedgerTab === 'audit' && (
          <div className="flex flex-wrap items-center gap-2">
            <label className="text-[11px] text-zinc-400">Memory confidence</label>
            <select aria-label="Memory confidence filter" value={memoryConfidenceFilter} onChange={(e) => setMemoryConfidenceFilter(e.target.value as typeof memoryConfidenceFilter)} className="bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-300">
              <option value="ALL">All confidence</option><option value="HIGH">High Confidence</option><option value="MEDIUM">Medium Confidence</option><option value="LOW">Low Confidence</option>
            </select>
            <label className="text-[11px] text-zinc-400">Provenance</label>
            <select aria-label="Memory provenance filter" value={memoryProvenanceFilter} onChange={(e) => setMemoryProvenanceFilter(e.target.value as typeof memoryProvenanceFilter)} className="bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-300">
              <option value="ALL">Verified Facts + User Claims</option><option value="VERIFIED_FACT">Verified Facts</option><option value="USER_CLAIM">User Claims</option>
            </select>
            <label className="text-[11px] text-zinc-400">PQC Signature</label>
            <select aria-label="PQC signature filter" value={pqcFilter} onChange={(e) => setPqcFilter(e.target.value as typeof pqcFilter)} className="bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-300">
              <option value="ALL">All PQC Signatures</option>
              <option value="Verified">Verified Only</option>
              <option value="Pending">Unverified Only</option>
              <option value="Invalid">Invalid / Tampered</option>
            </select>
          </div>
        )}

      {/* Content View */}
      <div className="flex-1 overflow-auto p-6 space-y-6">
        {activeLedgerTab === 'audit' && (
          <div className="space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-xl">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-zinc-850 border-b border-zinc-800 text-zinc-400">
                <tr>
                  <th className="p-3">Event Type</th>
                  <th className="p-3">PQC Signature</th>
                  <th className="p-3">Plan ID</th>
                  <th className="p-3">Cryptographic Hash</th>
                  <th className="p-3">Actor</th>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-850">
                {filteredEvents.map((evt, idx) => (
                  <tr
                    key={idx}
                    onClick={() => setSelectedEvent(evt)}
                    className="hover:bg-zinc-850/50 cursor-pointer transition-colors"
                  >
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          evt.type.includes('APPROVED')
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : evt.type.includes('VERIFIED')
                            ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                            : evt.type.includes('REJECTED')
                            ? 'bg-rose-950 text-rose-400 border border-rose-800'
                            : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {redactSensitiveLog(evt.type)}
                      </span>
                    </td>
                    <td className="p-3">
                      <PqcStatusBadge status={getPqcSignatureStatus(evt)} />
                    </td>
                    <td className="p-3 text-cyan-300">
                      {evt.planId ? redactSensitiveLog(`${evt.planId.slice(0, 8)}...`) : '-'}
                    </td>
                    <td className="p-3 text-zinc-400 truncate max-w-xs">
                      {evt.hash ? redactSensitiveLog(`${evt.hash.slice(0, 16)}...`) : '-'}
                    </td>
                    <td className="p-3 text-zinc-300 uppercase text-[11px]">
                      {redactSensitiveLog(evt.actor || 'system')}
                      {evt.type.startsWith('memory_fact_') && (
                        <div className="mt-1 flex flex-wrap gap-1 normal-case">
                          <span className={`rounded px-1.5 py-0.5 ${String(evt.data?.confidenceTag || 'LOW') === 'HIGH' ? 'bg-emerald-950 text-emerald-300' : String(evt.data?.confidenceTag || 'LOW') === 'MEDIUM' ? 'bg-amber-950 text-amber-300' : 'bg-rose-950 text-rose-300'}`}>{String(evt.data?.confidenceTag || 'LOW')} confidence</span>
                          <span className="rounded px-1.5 py-0.5 bg-zinc-800 text-zinc-300">{String(evt.data?.provenanceKind || (evt.data?.verified ? 'VERIFIED_FACT' : 'USER_CLAIM'))}</span>
                          <span title={String(evt.data?.evidence || 'Evidence source unavailable')} className="text-zinc-500 normal-case">ⓘ evidence</span>
                        </div>
                      )}
                    </td>
                    <td className="p-3 text-zinc-500 text-[11px]">
                      {new Date(evt.timestamp).toLocaleString()}
                    </td>
                    <td className="p-3 text-right">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedEvent(evt);
                        }}
                        className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 ml-auto"
                      >
                        <span>{lang === 'th' ? 'ดูข้อมูล' : 'Inspect'}</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredEvents.some((evt) => evt.type.startsWith('memory_fact_') || /PLAN.*(APPROV|EXECUT|COMPLET)|APPROVED.*PLAN/i.test(evt.type)) && (
              <section className="border-t border-zinc-800 p-4 space-y-3">
                <div className="text-xs font-semibold text-zinc-300">{lang === 'th' ? 'ไทม์ไลน์ความจำและแผนที่อนุมัติ' : 'Memory Changes & Approved Plan Timeline'}</div>
                <div className="relative ml-2 border-l border-cyan-900 pl-4 space-y-3">
                  {filteredEvents.filter((evt) => evt.type.startsWith('memory_fact_') || /PLAN.*(APPROV|EXECUT|COMPLET)|APPROVED.*PLAN/i.test(evt.type)).slice().sort((a,b) => Date.parse(a.timestamp)-Date.parse(b.timestamp)).map((evt, i) => (
                    <div key={`${evt.id || evt.type}-${i}`} className="relative rounded-lg border border-zinc-800 bg-zinc-950/70 p-3">
                      <span className={`absolute -left-[21px] top-4 h-2.5 w-2.5 rounded-full ${evt.type.startsWith('memory_fact_') ? 'bg-cyan-400' : 'bg-emerald-400'}`} />
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-[11px] font-semibold text-zinc-200">{redactSensitiveLog(evt.type)}</span>
                        <time className="text-[10px] text-zinc-500">{new Date(evt.timestamp).toLocaleString()}</time>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-2">
                        <span className="text-[10px] text-zinc-500">{evt.type.startsWith('memory_fact_') ? 'Memory state change' : 'Plan approval / execution'}{evt.planId ? ` · ${evt.planId}` : ''}</span>
                        <PqcStatusBadge status={getPqcSignatureStatus(evt)} />
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
            {filteredEvents.length === 0 && (
              <div className="text-center py-12 text-zinc-500">
                <ShieldCheck className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>{lang === 'th' ? 'ไม่พบเหตุการณ์ตามเงื่อนไขที่กำหนด' : 'No audit events found.'}</p>
              </div>
            )}
          </div>
          {repoFullName ? (
            <RepositoryMetrics lang={lang} repoFullName={repoFullName} />
          ) : (
            <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-4 text-xs text-zinc-500">
              UNAVAILABLE — {lang === 'th' ? 'ยังไม่ได้เลือก repository สำหรับ metrics' : 'No repository selected for metrics.'}
            </div>
          )}
          </div>
        )}

        {activeLedgerTab === 'evidence' && (
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-xl">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-zinc-850 border-b border-zinc-800 text-zinc-400">
                <tr>
                  <th className="p-3">Record ID</th>
                  <th className="p-3">Task ID</th>
                  <th className="p-3">Command (Redacted)</th>
                  <th className="p-3">Exit Code</th>
                  <th className="p-3">Verification</th>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-850">
                {filteredEvidence.map((rec) => {
                  const cmdStr = Array.isArray(rec.command) ? rec.command.join(' ') : rec.command;
                  return (
                    <tr
                      key={rec.id}
                      onClick={() => setSelectedEvidence(rec)}
                      className="hover:bg-zinc-850/50 cursor-pointer transition-colors"
                    >
                      <td className="p-3 text-cyan-300">{rec.id.slice(0, 10)}...</td>
                      <td className="p-3 text-zinc-300">{rec.taskId.slice(0, 12)}...</td>
                      <td className="p-3 text-zinc-400 truncate max-w-xs font-mono text-[11px]">
                        {redactSensitiveLog(cmdStr)}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            rec.exitCode === 0
                              ? 'bg-emerald-950 text-emerald-400'
                              : 'bg-rose-950 text-rose-400'
                          }`}
                        >
                          {rec.exitCode}
                        </span>
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            rec.verified
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-zinc-800 text-zinc-400'
                          }`}
                        >
                          {rec.verified ? 'VERIFIED' : 'UNVERIFIED'}
                        </span>
                      </td>
                      <td className="p-3 text-zinc-500 text-[11px]">
                        {new Date(rec.timestamp).toLocaleString()}
                      </td>
                      <td className="p-3 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedEvidence(rec);
                          }}
                          className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 ml-auto"
                        >
                          <span>{lang === 'th' ? 'ดูหลักฐาน' : 'Inspect'}</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {filteredEvidence.length === 0 && (
              <div className="text-center py-12 text-zinc-500">
                <FileCheck2 className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>
                  {lang === 'th'
                    ? 'ยังไม่มีรายการ Evidence Ledger ที่บันทึกไว้'
                    : 'No evidence ledger records found.'}
                </p>
              </div>
            )}
          </div>
        )}

        {/* View 3: Ledger Integrity Verification */}
        {activeLedgerTab === 'integrity' && (
          <div className="space-y-6">
            {/* Master Integrity Status Card */}
            <div
              className={`p-6 rounded-2xl border flex flex-wrap items-center justify-between gap-4 transition-all shadow-xl ${
                !integrityReport
                  ? 'bg-zinc-900 border-zinc-800'
                  : integrityReport.valid
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-100'
                  : integrityReport.status === 'TAMPERED'
                  ? 'bg-rose-950/40 border-rose-500/50 text-rose-100'
                  : 'bg-amber-950/30 border-amber-500/40 text-amber-100'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  {!integrityReport ? (
                    <Clock className="w-5 h-5 text-zinc-400" />
                  ) : integrityReport.valid ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  ) : integrityReport.status === 'TAMPERED' ? (
                    <XCircle className="w-6 h-6 text-rose-400" />
                  ) : (
                    <AlertTriangle className="w-6 h-6 text-amber-400" />
                  )}
                  <h2 className="text-lg font-bold">
                    {!integrityReport
                      ? lang === 'th'
                        ? 'กำลังโหลดผลการตรวจสอบ...'
                        : 'Checking Ledger Integrity...'
                      : integrityReport.status === 'VERIFIED'
                      ? lang === 'th'
                        ? '✅ ตรวจสอบยืนยันแล้ว: สมุดบันทึกและหลักฐานถูกต้องสมบูรณ์ (VERIFIED)'
                        : '✅ Ledger Verified Intact: Cryptographic Hashes & Evidence Match'
                      : integrityReport.status === 'TAMPERED'
                      ? lang === 'th'
                        ? '🛑 พบการดัดแปลงข้อมูล: Hash ไม่ตรงกับ Payload หรือหลักฐานถูกแก้ไข (TAMPERED)'
                        : '🛑 Cryptographic Tampering Detected: Plan Hash / Evidence Mismatch'
                      : lang === 'th'
                      ? '⚠️ ตรวจพบข้อผิดพลาดใน Ledger (FAIL)'
                      : '⚠️ Ledger Verification Failed (FAIL)'}
                  </h2>
                </div>
                <p className="text-xs opacity-90 max-w-3xl leading-relaxed">
                  {integrityReport?.summary ||
                    (lang === 'th'
                      ? 'ระบบจะทำการ Re-calculate SHA-256 Plan Hash ทุกฉบับและเทียบกับหลักฐานจริงเพื่อตรวจจับการปลอมแปลง'
                      : 'Recalculating all cryptographic plan hashes and verifying against recorded evidence proofs.')}
                </p>
                {integrityReport?.verifiedAt && (
                  <div className="text-[11px] opacity-70 font-mono pt-1">
                    Checked at: {new Date(integrityReport.verifiedAt).toLocaleString()}
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={fetchIntegrityReport}
                disabled={integrityLoading}
                className="px-4 py-2 rounded-xl bg-zinc-900/90 border border-zinc-700 hover:bg-zinc-800 text-xs font-semibold flex items-center gap-2 transition-all shadow"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${integrityLoading ? 'animate-spin' : ''}`} />
                <span>
                  {lang === 'th' ? 'ตรวจสอบความสมบูรณ์ซ้ำ' : 'Re-verify Ledger'}
                </span>
              </button>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl">
                <div className="text-zinc-500 text-[10px] uppercase font-semibold">Plans Re-Hashed</div>
                <div className="text-lg font-bold text-cyan-300 mt-1">
                  {integrityReport?.totalPlansChecked ?? 0}
                </div>
                <div className="text-[10px] text-zinc-500">Cryptographically verified</div>
              </div>
              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl">
                <div className="text-zinc-500 text-[10px] uppercase font-semibold">Audit Events</div>
                <div className="text-lg font-bold text-zinc-200 mt-1">
                  {integrityReport?.totalEventsChecked ?? events.length}
                </div>
                <div className="text-[10px] text-zinc-500">Sequenced in ledger</div>
              </div>
              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl">
                <div className="text-zinc-500 text-[10px] uppercase font-semibold">Evidence Proofs</div>
                <div className="text-lg font-bold text-emerald-400 mt-1">
                  {integrityReport?.totalEvidenceRecordsChecked ?? evidenceRecords.length}
                </div>
                <div className="text-[10px] text-zinc-500">Tool execution results</div>
              </div>
              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl">
                <div className="text-zinc-500 text-[10px] uppercase font-semibold">Flagged Mismatches</div>
                <div
                  className={`text-lg font-bold mt-1 ${
                    (integrityReport?.mismatches.length ?? 0) > 0 ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {integrityReport?.mismatches.length ?? 0}
                </div>
                <div className="text-[10px] text-zinc-500">Anomalies detected</div>
              </div>
            </div>

            {/* Mismatches List (if any) */}
            {integrityReport && integrityReport.mismatches.length > 0 && (
              <div className="p-5 bg-rose-950/30 border border-rose-500/40 rounded-xl space-y-3">
                <div className="flex items-center gap-2 text-rose-400 text-sm font-bold">
                  <AlertCircle className="w-4 h-4" />
                  <span>
                    {lang === 'th'
                      ? `ตรวจพบข้อผิดพลาดหรือความไม่สอดคล้อง ${integrityReport.mismatches.length} จุด (Flagged Mismatches):`
                      : `Detected ${integrityReport.mismatches.length} Mismatch(es):`}
                  </span>
                </div>
                <div className="space-y-2">
                  {integrityReport.mismatches.map((m, idx) => (
                    <div
                      key={m.issueId || idx}
                      className="p-3 bg-zinc-950/80 rounded-lg border border-rose-900/50 text-xs font-mono space-y-1"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="px-1.5 py-0.5 rounded bg-rose-900/60 text-rose-300 font-bold text-[10px]">
                          {m.type}
                        </span>
                        <span className="text-[10px] text-rose-400 uppercase font-semibold">
                          Severity: {m.severity}
                        </span>
                      </div>
                      <div className="text-zinc-200">{m.message}</div>
                      {(m.expected || m.actual) && (
                        <div className="text-[11px] text-zinc-400 grid grid-cols-2 gap-2 pt-1 border-t border-zinc-850">
                          <div>Expected: <span className="text-emerald-400 break-all">{m.expected}</span></div>
                          <div>Actual: <span className="text-rose-400 break-all">{m.actual}</span></div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <VerifiedTaskHashHistory report={integrityReport} loading={integrityLoading} onReverify={fetchIntegrityReport} lang={lang} />

            {/* Plans Cryptographic Integrity Table */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-xl">
              <div className="p-4 bg-zinc-850/60 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                    {lang === 'th' ? 'การคำนวณและเปรียบเทียบ Hash แผนงาน (SHA-256 Plan Re-hashing)' : 'Plans Re-hash & Evidence Verification'}
                  </span>
                </div>
                <span className="text-[11px] text-zinc-400 font-mono">
                  {integrityReport?.plans.length ?? 0} plans registered
                </span>
              </div>

              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-zinc-850 border-b border-zinc-800 text-zinc-400">
                  <tr>
                    <th className="p-3">Plan ID & Goal</th>
                    <th className="p-3">Recorded Hash vs Recalculated Hash</th>
                    <th className="p-3">Hash Integrity</th>
                    <th className="p-3">Approval</th>
                    <th className="p-3">Evidence Proofs</th>
                    <th className="p-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-850">
                  {(integrityReport?.plans || []).map((p) => (
                    <tr key={p.planId} className="hover:bg-zinc-850/40 transition-colors">
                      <td className="p-3">
                        <div className="font-bold text-zinc-200">{p.planId.slice(0, 14)}...</div>
                        <div className="text-[11px] text-zinc-400 truncate max-w-xs">{p.goal}</div>
                      </td>
                      <td className="p-3 font-mono text-[11px] space-y-0.5">
                        <div className="flex items-center gap-1">
                          <span className="text-zinc-500 text-[10px]">REC:</span>
                          <span className="text-zinc-300 truncate max-w-xs">{p.recordedHash.slice(0, 24)}...</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-zinc-500 text-[10px]">CALC:</span>
                          <span className={p.hashValid ? 'text-emerald-400 truncate max-w-xs' : 'text-rose-400 truncate max-w-xs'}>
                            {p.recalculatedHash.slice(0, 24)}...
                          </span>
                        </div>
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.hashValid
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                              : 'bg-rose-950 text-rose-400 border border-rose-800/60'
                          }`}
                        >
                          {p.hashValid ? '✓ HASH MATCH' : '✗ TAMPERED'}
                        </span>
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.approvalValid
                              ? 'bg-zinc-800 text-zinc-300'
                              : 'bg-rose-950 text-rose-400'
                          }`}
                        >
                          {p.approvalValid ? 'VALID' : 'INVALID'}
                        </span>
                      </td>
                      <td className="p-3 text-zinc-300">
                        {p.matchedEvidenceCount} evidence proofs
                      </td>
                      <td className="p-3 text-right">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.status === 'SUCCEEDED'
                              ? 'bg-emerald-950 text-emerald-400'
                              : p.status === 'FAILED'
                              ? 'bg-rose-950 text-rose-400'
                              : 'bg-zinc-800 text-zinc-400'
                          }`}
                        >
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {(!integrityReport?.plans || integrityReport.plans.length === 0) && (
                    <tr>
                      <td colSpan={6} className="text-center py-10 text-zinc-500">
                        {lang === 'th' ? 'ยังไม่มีแผนงานที่ถูกบันทึกลง Ledger' : 'No plans currently recorded in ledger.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SECURITY EVENTS TAB: PQC Signature Validation & Mutation Drift Alerts */}
        {activeLedgerTab === 'security_events' && (
          <div className="space-y-6">
            {/* Global Ledger Registration Protocol Card */}
            <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-5 space-y-4 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-500/20 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                      <span>Global Ledger Registration Protocol</span>
                      <span
                        data-testid="ga-cert-status"
                        title="ยังไม่มีหลักฐานการรับรอง: ไม่มี Merkle root, ลายเซ็น หรือผลตรวจสอบที่ยืนยันได้"
                        className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/60 text-amber-300 border border-amber-700/60"
                      >
                        UNKNOWN · NOT CERTIFIED
                      </span>
                    </h2>
                    <p className="text-xs text-amber-200/80">
                      Sovereign Consensus Ledger · Forensic Trace Chain · เป้าหมาย: Commercial-Grade Quantum System (ยังไม่ได้รับรอง)
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleAnchorCertProtocol}
                    className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors shadow-md shadow-amber-950 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>{lang === 'th' ? 'บันทึกคำขอ GA-CERT NOVA 2026' : 'Record GA-CERT NOVA 2026 request'}</span>
                  </button>
                </div>
              </div>

              {/* Protocol Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
                <div className="p-3 rounded-lg bg-zinc-950/80 border border-amber-500/20 space-y-1">
                  <div className="text-[10px] uppercase text-zinc-500">1. Merkle Root Anchor (เป้าหมายที่ร้องขอ)</div>
                  <div className="text-amber-300 font-bold truncate" title={GA_CERT_TARGET.registrationId}>{GA_CERT_TARGET.registrationId}</div>
                  <div className="text-[10px] text-amber-300 truncate">Root hash: UNKNOWN (ยังไม่มีหลักฐาน)</div>
                </div>
                <div className="p-3 rounded-lg bg-zinc-950/80 border border-amber-500/20 space-y-1">
                  <div className="text-[10px] uppercase text-zinc-500">2. Dual-Custody Signatures (ที่ต้องมี)</div>
                  <div className="text-zinc-200 font-bold">{GA_CERT_TARGET.requiredCustody}</div>
                  <div className="text-[10px] text-amber-300">ลายเซ็น: UNKNOWN (ยังไม่มีหลักฐาน)</div>
                </div>
                <div className="p-3 rounded-lg bg-zinc-950/80 border border-amber-500/20 space-y-1">
                  <div className="text-[10px] uppercase text-zinc-500">3. Evidence Chain ID (เป้าหมายที่ร้องขอ)</div>
                  <div className="text-cyan-300 font-bold truncate">{GA_CERT_TARGET.evidenceChainId}</div>
                  <div className="text-[10px] text-amber-300">Forensic trace: UNKNOWN</div>
                </div>
                <div className="p-3 rounded-lg bg-zinc-950/80 border border-amber-500/20 space-y-1">
                  <div className="text-[10px] uppercase text-zinc-500">4. Immutable Seal (เป้าหมาย)</div>
                  <div className="text-zinc-300 font-bold">{GA_CERT_TARGET.targetSeal}</div>
                  <div className="text-[10px] text-amber-300">สถานะ: UNKNOWN · ยังไม่ได้รับรอง</div>
                </div>
              </div>
            </div>

            {/* Sub-Filters and Test Verification Triggers */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-zinc-400 font-semibold">{lang === 'th' ? 'กรองเหตุการณ์:' : 'Filter:'}</span>
                <button
                  type="button"
                  onClick={() => setSecurityEventsSubFilter('ALL')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    securityEventsSubFilter === 'ALL'
                      ? 'bg-amber-900/80 text-amber-200 border border-amber-700/60'
                      : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  ทั้งหมด ({securityEvents.length})
                </button>
                <button
                  type="button"
                  onClick={() => setSecurityEventsSubFilter('PQC')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    securityEventsSubFilter === 'PQC'
                      ? 'bg-amber-900/80 text-amber-200 border border-amber-700/60'
                      : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <Key className="w-3.5 h-3.5 text-amber-400" />
                  <span>PQC Signature Validations ({securityEvents.filter(isPqcEvent).length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSecurityEventsSubFilter('DRIFT')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    securityEventsSubFilter === 'DRIFT'
                      ? 'bg-amber-900/80 text-amber-200 border border-amber-700/60'
                      : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Mutation Drift Alerts ({securityEvents.filter(isDriftEvent).length})</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTriggerPqcValidation}
                  className="px-3 py-1.5 bg-zinc-800 hover:bg-amber-950 hover:text-amber-300 border border-zinc-700 rounded-lg text-xs font-medium text-zinc-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="บันทึกคำขอตรวจ PQC (ยังไม่มีผลตรวจจริง)"
                >
                  <Key className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'th' ? 'บันทึกคำขอตรวจ PQC' : 'Record PQC validation request'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleTriggerMutationDriftScan}
                  className="px-3 py-1.5 bg-zinc-800 hover:bg-amber-950 hover:text-amber-300 border border-zinc-700 rounded-lg text-xs font-medium text-zinc-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="บันทึกคำขอสแกน (ยังไม่มีการวัด digest จริง)"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'th' ? 'บันทึกคำขอสแกน Drift' : 'Record drift scan request'}</span>
                </button>
              </div>
            </div>

            {/* Filtered Security Events Table */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-xl">
              <div className="p-4 bg-zinc-850/60 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
                    {securityEventsSubFilter === 'PQC'
                      ? 'PQC Signature Validation Attempts (Dilithium-5 / Kyber)'
                      : securityEventsSubFilter === 'DRIFT'
                      ? 'System Telemetry Mutation Drift Alerts'
                      : 'Security Events Log (PQC Validations & Mutation Drift Alerts)'}
                  </span>
                </div>
                <span className="text-[11px] text-zinc-400 font-mono">
                  {filteredSecurityEvents.length} events recorded
                </span>
              </div>

              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-zinc-850 border-b border-zinc-800 text-zinc-400">
                  <tr>
                    <th className="p-3">Category & Type</th>
                    <th className="p-3">PQC Validation Status</th>
                    <th className="p-3">Forensic Evidence Chain / Hash</th>
                    <th className="p-3">Actor / Target</th>
                    <th className="p-3">Timestamp</th>
                    <th className="p-3 text-right">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-850">
                  {filteredSecurityEvents.map((evt, idx) => {
                    const isPqc = isPqcEvent(evt);
                    const isDrift = isDriftEvent(evt);
                    return (
                      <tr
                        key={evt.id || idx}
                        onClick={() => setSelectedEvent(evt)}
                        className="hover:bg-zinc-850/50 cursor-pointer transition-colors"
                      >
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                isPqc
                                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                  : isDrift
                                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                  : 'bg-zinc-800 text-zinc-300'
                              }`}
                            >
                              {isPqc ? 'PQC VALIDATION' : 'MUTATION DRIFT'}
                            </span>
                            <span className="text-[11px] text-zinc-300 font-sans font-medium">
                              {redactSensitiveLog(evt.type)}
                            </span>
                          </div>
                        </td>
                        <td className="p-3">
                          <PqcStatusBadge status={getPqcSignatureStatus(evt)} />
                        </td>
                        <td className="p-3 text-cyan-300 truncate max-w-xs font-mono text-[11px]">
                          {evt.hash
                            ? redactSensitiveLog(`${evt.hash.slice(0, 18)}...`)
                            : (evt.data as any)?.merkleRootHash
                            ? String((evt.data as any).merkleRootHash).slice(0, 18) + '...'
                            : (evt.data as any)?.evidenceChainId || 'UNKNOWN (ไม่มีหลักฐาน)'}
                        </td>
                        <td className="p-3 text-zinc-300 uppercase text-[11px]">
                          {redactSensitiveLog(evt.actor || (evt.data as any)?.target || 'Quantum Core')}
                        </td>
                        <td className="p-3 text-zinc-500 text-[11px]">
                          {new Date(evt.timestamp).toLocaleString()}
                        </td>
                        <td className="p-3 text-right">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedEvent(evt);
                            }}
                            className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 ml-auto cursor-pointer"
                          >
                            <span>{lang === 'th' ? 'ดูข้อมูล' : 'Inspect'}</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredSecurityEvents.length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center py-12 text-zinc-500">
                        <ShieldAlert className="w-10 h-10 mx-auto mb-2 opacity-30 text-amber-400" />
                        <p>{lang === 'th' ? 'ไม่พบเหตุการณ์ PQC หรือ Mutation Drift ตามที่ระบุ' : 'No security events matching filter.'}</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* Modal: Audit Event Inspector with Strict Secret Redaction */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold text-zinc-100">
                  {lang === 'th' ? 'รายละเอียดเหตุการณ์ Audit (ตัดข้อมูลลับแล้ว)' : 'Redacted Audit Event Record'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedEvent(null)}
                className="p-1 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850">
                  <div className="text-zinc-500 text-[10px] uppercase">Type</div>
                  <div className="text-cyan-300 font-semibold">{redactSensitiveLog(selectedEvent.type)}</div>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850">
                  <div className="text-zinc-500 text-[10px] uppercase">Timestamp</div>
                  <div className="text-zinc-300">{new Date(selectedEvent.timestamp).toLocaleString()}</div>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850 col-span-2">
                  <div className="text-zinc-500 text-[10px] uppercase">Plan ID</div>
                  <div className="text-zinc-300 truncate">{redactSensitiveLog(selectedEvent.planId || 'N/A')}</div>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850 col-span-2">
                  <div className="text-zinc-500 text-[10px] uppercase">Cryptographic SHA-256 Hash</div>
                  <div className="text-emerald-400 break-all">{redactSensitiveLog(selectedEvent.hash || 'N/A')}</div>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850 col-span-2">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="text-zinc-500 text-[10px] uppercase flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{lang === 'th' ? 'สถานะลายเซ็นควอนตัม PQC (Post-Quantum Cryptography Signature)' : 'PQC Quantum Signature Status'}</span>
                    </div>
                    <PqcStatusBadge status={getPqcSignatureStatus(selectedEvent)} />
                  </div>
                  <div className="text-zinc-300 font-mono text-[11px] break-all bg-zinc-900/60 p-2 rounded border border-zinc-800">
                    {redactSensitiveLog(
                      String(
                        (selectedEvent as any).pqcSignature ||
                        (selectedEvent.data as any)?.pqcSignature ||
                        (selectedEvent.data as any)?.['x-zyrquen-sovereign-sig'] ||
                        (getPqcSignatureStatus(selectedEvent) === 'Invalid'
                          ? 'INVALID_OR_TAMPERED (ตามที่เหตุการณ์ระบุ)'
                          : 'ไม่มีลายเซ็นหรือหลักฐานการตรวจสอบในเหตุการณ์นี้ (UNKNOWN)')
                      )
                    )}
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                    {lang === 'th' ? 'ข้อมูล Payload ที่ตัดข้อมูลลับแล้ว (Sanitized JSON):' : 'Sanitized Payload:'}
                  </span>
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                    <Lock className="w-3 h-3" />
                    <span>Redacted</span>
                  </span>
                </div>
                <pre className="p-4 bg-zinc-950 rounded-xl border border-zinc-850 font-mono text-xs text-zinc-300 overflow-x-auto leading-relaxed">
                  {redactSensitiveLog(selectedEvent.data || selectedEvent.details || selectedEvent)}
                </pre>
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-800 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedEvent(null)}
                className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200"
              >
                {lang === 'th' ? 'ปิดหน้าต่าง' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Evidence Record Inspector with Strict Secret Redaction */}
      {selectedEvidence && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm font-bold text-zinc-100">
                  {lang === 'th' ? 'หลักฐานการรันเครื่องมือจริง (Evidence Proof)' : 'Verified Evidence Record'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedEvidence(null)}
                className="p-1 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850">
                  <div className="text-zinc-500 text-[10px] uppercase">Record ID</div>
                  <div className="text-cyan-300 truncate">{selectedEvidence.id}</div>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850">
                  <div className="text-zinc-500 text-[10px] uppercase">Exit Code</div>
                  <div className={selectedEvidence.exitCode === 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {selectedEvidence.exitCode}
                  </div>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850 col-span-2">
                  <div className="text-zinc-500 text-[10px] uppercase">Executed Command (Redacted)</div>
                  <div className="text-zinc-200 break-all font-mono text-[11px]">
                    {redactSensitiveLog(
                      Array.isArray(selectedEvidence.command)
                        ? selectedEvidence.command.join(' ')
                        : selectedEvidence.command
                    )}
                  </div>
                </div>
              </div>

              <div>
                <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1.5">
                  {lang === 'th' ? 'สรุปผลลัพธ์ (Output Summary - Redacted):' : 'Output Summary:'}
                </span>
                <pre className="p-4 bg-zinc-950 rounded-xl border border-zinc-850 font-mono text-xs text-zinc-300 overflow-x-auto whitespace-pre-wrap leading-relaxed">
                  {redactSensitiveLog(selectedEvidence.outputSummary)}
                </pre>
              </div>

              {selectedEvidence.changedFiles && selectedEvidence.changedFiles.length > 0 && (
                <div>
                  <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1.5">
                    {lang === 'th' ? 'ไฟล์ที่มีการเปลี่ยนแปลง:' : 'Changed Files:'}
                  </span>
                  <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-850 font-mono text-xs text-cyan-300 space-y-1">
                    {selectedEvidence.changedFiles.map((f, i) => (
                      <div key={i}>• {f}</div>
                    ))}
                  </div>
                </div>
              )}

              {selectedEvidence.verificationEvidence && selectedEvidence.verificationEvidence.length > 0 && (
                <div>
                  <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1.5">
                    {lang === 'th' ? 'หลักฐานยืนยันความถูกต้อง (Empirical Facts):' : 'Verification Evidence:'}
                  </span>
                  <div className="space-y-1.5">
                    {selectedEvidence.verificationEvidence.map((ev, i) => (
                      <div
                        key={i}
                        className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-850 text-xs flex items-center justify-between gap-2"
                      >
                        <div>
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 uppercase mr-2">
                            {ev.category}
                          </span>
                          <span className="text-zinc-200">{redactSensitiveLog(ev.statement)}</span>
                        </div>
                        <span className={ev.verified ? 'text-emerald-400 font-bold text-[10px]' : 'text-zinc-500 text-[10px]'}>
                          {ev.verified ? '✓ VERIFIED' : 'UNVERIFIED'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-zinc-800 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedEvidence(null)}
                className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200"
              >
                {lang === 'th' ? 'ปิดหน้าต่าง' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
