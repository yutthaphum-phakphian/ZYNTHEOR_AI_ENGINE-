import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Server,
  Zap,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Key,
  Shield,
  Layers,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Terminal,
  Activity,
} from 'lucide-react';

export interface ProviderItem {
  id: string;
  name: string;
  category: 'online' | 'local';
  models: string[];
  status: 'CONNECTED' | 'CONFIG_REQUIRED' | 'ERROR' | 'UNKNOWN';
  envVar?: string;
  endpoint?: string;
  description: string;
  requiresKey: boolean;
}

interface ModelsViewProps {
  localModelStatus?: any;
  onRefreshLocalStatus?: () => Promise<void>;
  lang?: 'en' | 'th';
}

export const ModelsView: React.FC<ModelsViewProps> = ({
  localModelStatus,
  onRefreshLocalStatus,
  lang = 'th',
}) => {
  const [activeTab, setActiveTab] = useState<'providers' | 'models'>('providers');
  const [selectedProviderId, setSelectedProviderId] = useState<string>('ollama');
  const [endpointDraft, setEndpointDraft] = useState('http://localhost:11434');
  const [testingStatus, setTestingStatus] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  // Provider configuration is reported by the server (/api/providers/status).
  // API keys are never stored or entered in the browser.
  type ServerProvider = { id: string; name: string; configured: boolean; model?: string; available?: boolean };
  const [serverProviders, setServerProviders] = useState<ServerProvider[]>([]);
  const [serverState, setServerState] = useState<'loading' | 'ready' | 'error'>('loading');

  const loadServerProviders = async () => {
    try {
      const res = await fetch('/api/providers/status');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setServerProviders(Array.isArray(data.providers) ? data.providers : []);
      setServerState('ready');
      return true;
    } catch {
      setServerState('error');
      return false;
    }
  };

  useEffect(() => { void loadServerProviders(); }, []);

  const onlineStatus = (id: string): ProviderItem['status'] => {
    if (serverState === 'error') return 'ERROR';
    if (serverState === 'loading') return 'UNKNOWN';
    const sp = serverProviders.find((x) => x.id === id);
    if (!sp || !sp.configured) return 'CONFIG_REQUIRED';
    return 'UNKNOWN'; // key is set on the server, but connectivity has not been verified
  };
  const onlineModels = (id: string): string[] => {
    const m = serverProviders.find((x) => x.id === id)?.model;
    return m ? [m] : [];
  };

  const isLocalConnected = Boolean(localModelStatus?.connected);

  const providers: ProviderItem[] = [
    {
      id: 'ollama',
      name: 'Ollama (Local Runtime)',
      category: 'local',
      models: Array.isArray(localModelStatus?.models) ? localModelStatus.models : [],
      status: localModelStatus == null ? 'UNKNOWN' : isLocalConnected ? 'CONNECTED' : 'ERROR',
      endpoint: localModelStatus?.endpoint || 'http://localhost:11434',
      description: 'ประมวลผลบนเครื่องของคุณ ไม่ส่งข้อมูลออกภายนอก',
      requiresKey: false,
    },
    {
      id: 'openai',
      name: 'OpenAI',
      category: 'online',
      models: onlineModels('openai'),
      status: onlineStatus('openai'),
      envVar: 'OPENAI_API_KEY',
      description: 'ผู้ให้บริการออนไลน์ ต้องยินยอมส่งข้อมูลออกทุกครั้งที่ใช้งาน',
      requiresKey: true,
    },
    {
      id: 'anthropic',
      name: 'Anthropic',
      category: 'online',
      models: onlineModels('anthropic'),
      status: onlineStatus('anthropic'),
      envVar: 'ANTHROPIC_API_KEY',
      description: 'ผู้ให้บริการออนไลน์ ต้องยินยอมส่งข้อมูลออกทุกครั้งที่ใช้งาน',
      requiresKey: true,
    },
  ];

  const selectedProvider = providers.find((p) => p.id === selectedProviderId) || providers[0];

  useEffect(() => { setTestResult(null); }, [selectedProviderId]);

  const handleTestConnection = async () => {
    setTestingStatus(true);
    setTestResult(null);

    try {
      if (selectedProvider.id === 'ollama') {
        if (onRefreshLocalStatus) {
          await onRefreshLocalStatus();
        }
        const res = await fetch(`/api/local-model/status?endpoint=${encodeURIComponent(endpointDraft)}`);
        const data = await res.json();
        if (data.connected) {
          setTestResult({
            ok: true,
            message: `เชื่อมต่อกับ Local Ollama สำเร็จ (${Array.isArray(data.models) ? data.models.length : 0} models found)`,
          });
        } else {
          setTestResult({
            ok: false,
            message: data.message || 'ไม่สามารถเชื่อมต่อ Local Ollama ได้ — ตรวจสอบว่า `ollama serve` กำลังรันอยู่',
          });
        }
      } else {
        // Online provider check: ask the server what it has configured.
        const ok = await loadServerProviders();
        const sp = serverProviders.find((x) => x.id === selectedProvider.id);
        if (!ok) {
          setTestResult({ ok: false, message: 'ติดต่อเซิร์ฟเวอร์เพื่อตรวจสอบการตั้งค่าไม่ได้' });
        } else if (!sp?.configured) {
          setTestResult({ ok: false, message: `เซิร์ฟเวอร์ยังไม่พบ ${selectedProvider.envVar} สำหรับ ${selectedProvider.name}` });
        } else {
          setTestResult({
            ok: true,
            message: `เซิร์ฟเวอร์ตั้งค่าคีย์ของ ${selectedProvider.name} แล้ว แต่ยังไม่ได้ยืนยันการเชื่อมต่อกับผู้ให้บริการจริง (สถานะ UNKNOWN)`,
          });
        }
      }
    } catch (err: any) {
      setTestResult({
        ok: false,
        message: `ข้อผิดพลาดในการตรวจสอบ: ${err.message || 'Network unreachable'}`,
      });
    } finally {
      setTestingStatus(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full bg-[#09090e] overflow-y-auto text-slate-200 p-4 lg:p-8">
      <div className="max-w-6xl mx-auto w-full space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-cyan-500/20">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
              <Cpu size={24} className="text-cyan-400" />
              <span>Models</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              ผู้ให้บริการ AI และสถานะการเชื่อมต่อจริง • Local Sovereign Runtime &amp; Cloud LLM
            </p>
          </div>

          {/* Segmented Control */}
          <div className="flex items-center p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setActiveTab('providers')}
              className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
                activeTab === 'providers'
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ผู้ให้บริการ
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('models')}
              className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
                activeTab === 'models'
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              โมเดลทั้งหมด
            </button>
          </div>
        </div>

        {/* Local Sovereign Notice */}
        <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs flex items-start gap-3">
          <Shield size={18} className="text-cyan-400 shrink-0 mt-0.5" />
          <div className="text-slate-300 leading-relaxed">
            <strong className="text-cyan-300 font-semibold">หลักการ Sovereign Runtime:</strong>{' '}
            ระบบ ZYNTHEOR AI ENGINE ให้ความสำคัญกับ Local Runtime (Ollama-compatible) บนเครื่องเป็นหลักเพื่อความเป็นส่วนตัว
            และรองรับ Online Providers สำหรับงานที่ต้องการพลังประมวลผลสูง โดยสถานะทั้งหมดรายงานจากหลักฐานจริง ไม่มีการจำลองข้อมูล
          </div>
        </div>

        {/* Content Section: 2 Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Providers List */}
          <div className="lg:col-span-7 space-y-3">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
              {activeTab === 'providers' ? 'รายการผู้ให้บริการ' : 'รายการโมเดลที่รองรับ'}
            </h2>

            {activeTab === 'providers' ? (
              providers.map((p) => {
                const isSelected = selectedProviderId === p.id;
                const isOnline = p.status === 'CONNECTED';
                const isOffline = p.status === 'ERROR';

                return (
                  <div
                    key={p.id}
                    onClick={() => setSelectedProviderId(p.id)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                      isSelected
                        ? 'bg-cyan-950/40 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                        : 'bg-[#101018]/70 border-slate-800/80 hover:border-slate-700 hover:bg-slate-850'
                    }`}
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          p.category === 'local'
                            ? 'bg-emerald-950/70 border border-emerald-500/40 text-emerald-300'
                            : 'bg-cyan-950/70 border border-cyan-500/40 text-cyan-300'
                        }`}
                      >
                        {p.category === 'local' ? <Server size={20} /> : <Zap size={20} />}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{p.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {p.models.slice(0, 2).join(' / ')}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 truncate mt-0.5">{p.description}</p>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-3">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-medium border ${
                          isOnline
                            ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                            : isOffline
                            ? 'bg-rose-950/60 text-rose-300 border-rose-500/40'
                            : 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            isOnline ? 'bg-emerald-400' : isOffline ? 'bg-rose-400' : 'bg-amber-400'
                          }`}
                        />
                        <span>{p.status}</span>
                      </span>
                      <ChevronRight size={16} className={isSelected ? 'text-cyan-400' : 'text-slate-600'} />
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="rounded-xl border border-slate-800 bg-[#101018]/70 overflow-hidden divide-y divide-slate-800">
                {providers.every((p) => p.models.length === 0) && (
                  <div className="p-4 text-xs text-slate-400">ยังไม่มีโมเดลที่ระบบรายงาน — ตรวจสอบ Ollama ที่หน้าผู้ให้บริการ หรือตั้งค่าคีย์ฝั่งเซิร์ฟเวอร์</div>
                )}
                {providers.flatMap((p) =>
                  p.models.map((modelName) => (
                    <div key={`${p.id}-${modelName}`} className="p-3.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-white font-mono">{modelName}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">ผ่าน {p.name} ({p.category})</div>
                      </div>
                      <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                        พร้อมเรียกใช้
                      </span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Right Column: Provider Configuration Panel */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-cyan-500/30 bg-[#091534] p-5 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Key size={16} className="text-cyan-400" />
                  <span>การตั้งค่า {selectedProvider.name}</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  {selectedProvider.category === 'local' ? 'Local Engine' : 'Cloud API'}
                </span>
              </div>

              <div className="space-y-3">
                {selectedProvider.requiresKey ? (
                  <div className="space-y-1.5 text-xs text-slate-300">
                    <p className="font-semibold">การตั้งค่า API Key</p>
                    <p className="text-slate-400 leading-relaxed">
                      ตั้งค่าคีย์ที่ฝั่งเซิร์ฟเวอร์ด้วยตัวแปรสภาพแวดล้อม{' '}
                      <code className="rounded bg-slate-900 px-1.5 py-0.5 font-mono text-cyan-300">{selectedProvider.envVar}</code>{' '}
                      แล้วรีสตาร์ตเซิร์ฟเวอร์ แอปนี้ไม่รับหรือเก็บ API Key ในเบราว์เซอร์
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Local Endpoint URL
                    </label>
                    <input
                      type="text"
                      value={endpointDraft}
                      onChange={(e) => setEndpointDraft(e.target.value)}
                      placeholder="http://localhost:11434"
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-cyan-400"
                    />
                    <p className="text-[10px] text-slate-500">
                      พอร์ตเริ่มต้นของ Ollama บนเครื่อง (ค่าปริยาย: http://localhost:11434)
                    </p>
                  </div>
                )}

                {/* Test Feedback Message */}
                {testResult && (
                  <div
                    role="status"
                    aria-live="polite"
                    className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                      testResult.ok
                        ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                        : 'bg-rose-950/60 border-rose-500/50 text-rose-300'
                    }`}
                  >
                    {testResult.ok ? (
                      <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
                    ) : (
                      <AlertTriangle size={15} className="shrink-0 mt-0.5" />
                    )}
                    <span className="leading-relaxed">{testResult.message}</span>
                  </div>
                )}

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleTestConnection}
                    disabled={testingStatus}
                    className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors cursor-pointer disabled:opacity-50"
                  >
                    <RotateCcw size={13} className={testingStatus ? 'animate-spin text-cyan-400' : ''} />
                    <span>{testingStatus ? 'กำลังตรวจสอบ...' : 'ตรวจสอบการเชื่อมต่อ'}</span>
                  </button>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
