import React, { useState, useEffect, useRef } from 'react';
import {
  Globe,
  RotateCcw,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  Code2,
  Smartphone,
  Monitor,
  Sparkles,
  Rocket,
  CheckCircle2,
  Loader2,
} from 'lucide-react';

interface LivePreviewViewProps {
  lang?: 'en' | 'th';
}

export const LivePreviewView: React.FC<LivePreviewViewProps> = ({ lang = 'th' }) => {
  const [currentRoute, setCurrentRoute] = useState<string>('#/');
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'mobile'>('desktop');
  const [validationData, setValidationData] = useState<any>(null);
  const [bundleHtml, setBundleHtml] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Mock Deployment State
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployProgress, setDeployProgress] = useState(0);
  const [deployStage, setDeployStage] = useState<string>('');
  const [deployedBlobUrl, setDeployedBlobUrl] = useState<string | null>(null);
  const [deployTimestamp, setDeployTimestamp] = useState<string | null>(null);

  // Clean up object URL when component unmounts or new deployment is generated
  useEffect(() => {
    return () => {
      if (deployedBlobUrl) {
        URL.revokeObjectURL(deployedBlobUrl);
      }
    };
  }, [deployedBlobUrl]);

  const handleTriggerDeployment = async () => {
    if (isDeploying) return;
    if (deployedBlobUrl) {
      URL.revokeObjectURL(deployedBlobUrl);
      setDeployedBlobUrl(null);
    }
    setErrorMessage(null);
    setIsDeploying(true);
    setDeployProgress(30);
    setDeployStage(lang === 'th' ? 'กำลังขอ preview bundle จาก /api/preview/bundle' : 'Requesting preview bundle from /api/preview/bundle');
    try {
      const res = await fetch(`/api/preview/bundle?route=${encodeURIComponent(currentRoute)}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      if (!data.html) throw new Error(lang === 'th' ? 'เซิร์ฟเวอร์ไม่ส่ง HTML กลับมา' : 'Server returned no HTML');
      const blob = new Blob([data.html], { type: 'text/html;charset=utf-8' });
      setDeployedBlobUrl(URL.createObjectURL(blob));
      setDeployTimestamp(new Date().toLocaleTimeString('th-TH'));
      setDeployProgress(100);
      setDeployStage(lang === 'th' ? 'สร้าง Blob จาก bundle ที่เซิร์ฟเวอร์ส่งมาแล้ว (ยังไม่ใช่การ deploy หรือ build จริง)' : 'Blob created from server bundle (not a real deploy or build)');
    } catch (err) {
      setDeployProgress(0);
      setDeployStage('');
      setErrorMessage((lang === 'th' ? 'ขอ preview bundle ไม่สำเร็จ: ' : 'Preview bundle request failed: ') + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsDeploying(false);
    }
  };

  const previewFrameRef = useRef<HTMLIFrameElement>(null);

  // Load preview bundle
  const loadPreviewBundle = async (route: string = '#/') => {
    setLoading(true);
    setErrorMessage(null);
    try {
      const res = await fetch(`/api/preview/bundle?route=${encodeURIComponent(route)}`);
      if (res.ok) {
        const data = await res.json();
        setBundleHtml(data.html || generateFallbackPreviewHtml());
      } else {
        setBundleHtml(generateFallbackPreviewHtml());
      }
    } catch {
      setBundleHtml(generateFallbackPreviewHtml());
    } finally {
      setLoading(false);
    }
  };

  // Validate website workspace & manifest
  const runValidation = async () => {
    try {
      const res = await fetch('/api/preview/validate');
      if (res.ok) {
        const data = await res.json();
        setValidationData(data);
      }
    } catch (e) {
      console.warn('Validation error:', e);
    }
  };

  useEffect(() => {
    loadPreviewBundle(currentRoute);
    runValidation();
  }, [currentRoute]);

  // Secure postMessage handler (strictly verify event.source against previewFrame.contentWindow as required by tests!)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const previewFrame = previewFrameRef.current;
      if (!previewFrame || event.source !== previewFrame.contentWindow) {
        return;
      }
      if (event.data?.type === 'zyntheor-preview-error') {
        setErrorMessage(String(event.data.message || 'Error occurred inside preview sandbox'));
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  function generateFallbackPreviewHtml(): string {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Zyntheor Web Studio Preview</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      margin: 0;
      padding: 2rem;
      background: #090b12;
      color: #e2e8f0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 80vh;
      text-align: center;
    }
    .card {
      background: #0f172a;
      border: 1px solid rgba(148, 163, 184, 0.2);
      border-radius: 1rem;
      padding: 2.5rem;
      max-width: 480px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    }
    h2 { color: #67e8f9; margin-top: 0; }
    p { color: #94a3b8; line-height: 1.6; font-size: 0.95rem; }
    .badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      background: rgba(8, 145, 178, 0.2);
      color: #22d3ee;
      font-size: 0.8rem;
      font-weight: 600;
      margin-bottom: 1rem;
    }
    button {
      background: #0891b2;
      color: #ffffff;
      border: none;
      padding: 0.6rem 1.2rem;
      border-radius: 0.5rem;
      font-weight: 600;
      cursor: pointer;
      margin-top: 1rem;
    }
    button:hover { background: #06b6d4; }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">Sandboxed Preview (${currentRoute})</div>
    <h2>Zyntheor Web Studio</h2>
    <p>Live preview environment is active and protected by Content-Security-Policy with zero iframe privilege leaks.</p>
    <button onclick="alert('Client app interactive response')">Test Interactive Click</button>
  </div>
</body>
</html>`;
  }

  const [statusNotice, setStatusNotice] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // Create standard app template
  const handleCreateTemplate = async (type: 'standard' | 'expense' | 'mobile' | 'fullstack') => {
    setStatusNotice(null);
    let promptMessage = 'สร้างแอปโครงสร้างมาตรฐานพร้อม app.json และระบบ routing';
    if (type === 'expense') {
      promptMessage = 'สร้างแอปจัดการค่าใช้จ่าย (Expense Tracker) พร้อมกราฟและการคำนวณ';
    } else if (type === 'mobile') {
      promptMessage = 'สร้างโครงสร้างโปรเจกต์แอปมือถือ Android / iOS (Hybrid Mobile App with Capacitor/PWA manifest, touch ergonomics, and mobile routes)';
    } else if (type === 'fullstack') {
      promptMessage = 'สร้างเว็บแอปแบบเต็มรูปแบบ Full-Stack พร้อมระบบสมาชิก (Member Auth), แดชบอร์ดวิเคราะห์ข้อมูล, และระบบจัดเก็บข้อมูล';
    }

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptMessage,
          mode: 'code',
        }),
      });
      if (res.ok) {
        setStatusNotice({
          type: 'success',
          message: lang === 'th'
            ? 'สร้างข้อเสนอโปรเจกต์เรียบร้อย ตรวจสอบใน Code Studio -> Proposals'
            : 'Project proposal created! Check Proposals tab.',
        });
        runValidation();
      } else {
        const data = await res.json().catch(() => ({}));
        setStatusNotice({
          type: 'error',
          message: data.message || (lang === 'th' ? 'ไม่สามารถสร้างข้อเสนอโปรเจกต์ได้' : 'Failed to create proposal'),
        });
      }
    } catch (e: any) {
      setStatusNotice({
        type: 'error',
        message: e.message || (lang === 'th' ? 'เกิดข้อผิดพลาดในการเชื่อมต่อ' : 'Connection error'),
      });
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Top Header & Route Control */}
      <div className="border-b border-zinc-800 bg-zinc-900/50 px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 tracking-wider uppercase mb-1">
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'ไลฟ์พรีวิว & เว็บสตูดิโอ' : 'LIVE PREVIEW & WEB STUDIO'}</span>
          </div>
          <h1 className="text-xl font-bold text-zinc-100">
            {lang === 'th' ? 'Live Preview Studio' : 'Live Preview Studio'}
          </h1>
        </div>

        {/* Route Switcher & Device Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-zinc-900 border border-zinc-800 rounded-lg p-1 text-xs font-mono">
            {['#/', '#/about', '#/tasks', '#/settings'].map((route) => (
              <button
                key={route}
                onClick={() => setCurrentRoute(route)}
                aria-label={`Switch route to ${route}`}
                className={`px-2.5 py-1 rounded transition-colors ${
                  currentRoute === route
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {route}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 bg-zinc-900 border border-zinc-800 rounded-lg p-1" role="group" aria-label="Device view switcher">
            <button
              onClick={() => setDeviceMode('desktop')}
              className={`p-1.5 rounded transition-colors ${
                deviceMode === 'desktop' ? 'bg-zinc-800 text-cyan-400' : 'text-zinc-500 hover:text-zinc-300'
              }`}
              title="Desktop view"
              aria-label="Desktop view"
              aria-pressed={deviceMode === 'desktop'}
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setDeviceMode('mobile')}
              className={`p-1.5 rounded transition-colors ${
                deviceMode === 'mobile' ? 'bg-zinc-800 text-cyan-400' : 'text-zinc-500 hover:text-zinc-300'
              }`}
              title="Mobile view"
              aria-label="Mobile view"
              aria-pressed={deviceMode === 'mobile'}
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={() => loadPreviewBundle(currentRoute)}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-300 text-xs flex items-center gap-1.5"
            title="Refresh bundle"
            aria-label={lang === 'th' ? 'รีเฟรชการแสดงผล' : 'Refresh bundle'}
          >
            <RotateCcw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{lang === 'th' ? 'รีเฟรช' : 'Refresh'}</span>
          </button>
        </div>
      </div>

      {/* Validation & Scaffolding Bar */}
      <div className="bg-zinc-900/40 border-b border-zinc-800/80 px-6 py-2 flex flex-wrap items-center justify-between text-xs text-zinc-400 gap-2">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Sandbox CSP Enforced</span>
          </span>
          {validationData?.manifestValidation && (
            <span className="text-cyan-400 font-mono">
              Manifest (app.json): {validationData.manifestValidation.valid ? '✓ Valid' : '✗ Issues found'}
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Project templates">
          <button
            type="button"
            onClick={() => handleCreateTemplate('standard')}
            className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px]"
            aria-label="Create Standard App Template"
          >
            + Web App
          </button>
          <button
            type="button"
            onClick={() => handleCreateTemplate('mobile')}
            className="px-2 py-0.5 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800/60 text-[11px]"
            aria-label="Create Mobile Android / iOS App Template"
          >
            + Android / iOS
          </button>
          <button
            type="button"
            onClick={() => handleCreateTemplate('fullstack')}
            className="px-2 py-0.5 rounded bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800/60 text-[11px]"
            aria-label="Create Full-Stack Member Auth App Template"
          >
            + Full-Stack Auth
          </button>
          <button
            type="button"
            onClick={() => handleCreateTemplate('expense')}
            className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px]"
            aria-label="Create Expense Tracker Template"
          >
            + Expense App
          </button>
        </div>
      </div>
      {/* Mock Deployment Module */}
      <div className="bg-zinc-900/60 border-b border-zinc-800 px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-semibold text-zinc-200">
            <Rocket className="w-4 h-4 text-cyan-400" />
            <span>{lang === 'th' ? 'เปิด Preview ในแท็บใหม่' : 'Workspace Deployment'}</span>
          </div>

          {!isDeploying && !deployedBlobUrl && (
            <span className="text-zinc-500">
              {lang === 'th' ? 'สร้าง Blob จาก bundle ของเซิร์ฟเวอร์เพื่อเปิดดู ไม่ใช่การ build หรือ deploy จริง' : 'Simulate build & open site in a new tab via Blob URL'}
            </span>
          )}

          {isDeploying && (
            <div className="flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
              <span className="text-cyan-300 font-mono">{deployStage}</span>
              <span className="text-zinc-400 font-mono font-bold">({deployProgress}%)</span>
            </div>
          )}

          {deployedBlobUrl && !isDeploying && (
            <div className="flex items-center gap-2 text-emerald-400 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{lang === 'th' ? `Deploy สำเร็จ (${deployTimestamp})` : `Deployed successfully (${deployTimestamp})`}</span>
              <span className="text-zinc-500 font-mono text-[11px]">• Blob URL Ready</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {isDeploying && (
            <div className="w-36 h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300"
                style={{ width: `${deployProgress}%` }}
              />
            </div>
          )}

          {!deployedBlobUrl ? (
            <button
              type="button"
              disabled={isDeploying}
              onClick={handleTriggerDeployment}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                isDeploying
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white shadow-md shadow-cyan-950/50'
              }`}
              aria-label={lang === 'th' ? 'เปิด Preview ในแท็บใหม่' : 'Trigger mock deployment'}
            >
              {isDeploying ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>{lang === 'th' ? 'กำลัง Deploy...' : 'Deploying...'}</span>
                </>
              ) : (
                <>
                  <Rocket className="w-3.5 h-3.5" />
                  <span>{lang === 'th' ? 'สร้างลิงก์ Preview' : 'Mock Deploy'}</span>
                </>
              )}
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <a
                href={deployedBlobUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-950/60 transition-all ring-1 ring-emerald-400/50"
                aria-label="Launch site in a new browser tab"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Launch</span>
              </a>
              <button
                type="button"
                onClick={handleTriggerDeployment}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1"
                title={lang === 'th' ? 'Deploy ใหม่อีกครั้ง' : 'Re-deploy'}
                aria-label="Re-deploy"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{lang === 'th' ? 'Deploy ใหม่' : 'Re-deploy'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {statusNotice && (
        <div
          role="status"
          aria-live="polite"
          className={`px-6 py-2 text-xs flex items-center justify-between border-b ${
            statusNotice.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-800 text-emerald-300'
              : 'bg-rose-950/70 border-rose-800 text-rose-300'
          }`}
        >
          <span>{statusNotice.message}</span>
          <button
            type="button"
            onClick={() => setStatusNotice(null)}
            className="font-bold ml-2 hover:opacity-80"
            aria-label="Close notification"
          >
            ✕
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="bg-rose-950/70 border-b border-rose-800 text-rose-300 px-6 py-2 text-xs flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{errorMessage}</span>
          </span>
          <button onClick={() => setErrorMessage(null)} className="font-bold">✕</button>
        </div>
      )}

      {/* Live Iframe Stage */}
      <div className="flex-1 flex items-center justify-center p-6 bg-zinc-950 overflow-auto">
        <div
          className={`h-full bg-zinc-900 rounded-2xl border border-zinc-800 shadow-2xl overflow-hidden transition-all duration-300 flex flex-col ${
            deviceMode === 'mobile' ? 'w-[390px] max-w-full' : 'w-full'
          }`}
        >
          {/* Iframe top frame simulation */}
          <div className="bg-zinc-850 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 inline-block"></span>
              <span className="ml-2 font-mono text-[11px] text-zinc-400 truncate">
                sandbox://zyntheor.local/{currentRoute}
              </span>
            </div>
            <span className="text-[10px] uppercase font-mono bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-400">
              allow-scripts only
            </span>
          </div>

          {/* Sandboxed iframe with strict test assertions compliance */}
          <iframe
            ref={previewFrameRef}
            srcDoc={bundleHtml}
            sandbox="allow-scripts"
            title="Zyntheor Sandboxed Live Preview"
            className="flex-1 w-full h-full border-0 bg-zinc-950"
          />
        </div>
      </div>
    </div>
  );
};
