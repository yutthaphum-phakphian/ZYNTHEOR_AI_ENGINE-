import React, { useState } from 'react';
import {
  Folder,
  Code2,
  Play,
  Monitor,
  Smartphone,
  Sparkles,
  Columns,
  Maximize2,
  FileCode,
  Layers,
  ChevronRight,
  ExternalLink,
  Package,
  Wrench,
  RotateCcw,
} from 'lucide-react';
import { CodeStudioView } from './CodeStudioView';
import { LivePreviewView } from './LivePreviewView';

interface UnifiedBuildViewProps {
  onAnalyzeCode?: (action: string, code: string, filename: string) => void;
  onSendResultToChat?: (resultMessage: string) => void;
  lang?: 'en' | 'th';
  initialProject?: string;
  onSwitchToChat?: () => void;
  onSendBuildPrompt?: (prompt: string) => void;
  /** Sends the instruction straight to the code-mode chat (same consent/safety checks as typing it there). */
  onSendBuildPromptNow?: (prompt: string) => void;
}

export const UnifiedBuildView: React.FC<UnifiedBuildViewProps> = ({
  onAnalyzeCode,
  onSendResultToChat,
  lang = 'th',
  initialProject = 'my-app',
  onSwitchToChat,
  onSendBuildPrompt,
  onSendBuildPromptNow,
}) => {
  const [layoutMode, setLayoutMode] = useState<'split' | 'code-only' | 'preview-only'>(() => (typeof window !== 'undefined' && window.innerWidth < 1024 ? 'code-only' : 'split'));
  const [currentProject, setCurrentProject] = useState(initialProject);
  const [buildPrompt, setBuildPrompt] = useState('');
  const [targetPlatform, setTargetPlatform] = useState<'Web' | 'Android' | 'iOS'>('Web');

  const buildInstruction = (): string | null => {
    const requirements = buildPrompt.trim();
    if (!requirements) return null;
    const platformLabel = targetPlatform === 'Web' ? 'Web App' : `${targetPlatform} App`;
    return [
      `ช่วยวางแผนและพัฒนาโปรเจกต์ ${platformLabel} ตามข้อกำหนดนี้:`,
      requirements,
      '',
      'ข้อกำหนดการทำงาน: ตรวจสอบโครงสร้างโปรเจกต์และ API ที่มีอยู่จริงก่อนลงมือ แสดงแผนและ diff ก่อนแก้ไฟล์ ใช้เฉพาะเครื่องมือที่ Backend รองรับจริง และรายงานผลทดสอบจากหลักฐานจริง ห้ามอ้างว่าสร้างไฟล์ ทดสอบ หรือ build สำเร็จหากไม่มีหลักฐาน หากระบบปัจจุบันไม่รองรับการเขียนไฟล์หรือสร้างแพ็กเกจจริง ให้แจ้งข้อจำกัดตรง ๆ โดยไม่จำลองผลสำเร็จ.',
    ].join('\n');
  };

  const handleBuildPromptSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const instruction = buildInstruction();
    if (!instruction || !onSendBuildPrompt) return;
    onSendBuildPrompt(instruction);
  };

  const handleBuildPromptSendNow = () => {
    const instruction = buildInstruction();
    if (!instruction || !onSendBuildPromptNow) return;
    onSendBuildPromptNow(instruction);
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full bg-[#09090e] overflow-hidden text-slate-200">
      {/* Top Workspace Header */}
      <div className="h-13 shrink-0 flex items-center justify-between px-4 lg:px-6 border-b border-cyan-500/20 bg-[#101018]/90 backdrop-blur-md">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-xs font-semibold text-cyan-300">
            <Package size={14} className="text-cyan-400" />
            <span className="font-mono">{currentProject}</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400">
            <span>Build Workspace</span>
            <span className="text-slate-600">/</span>
            <span className="text-slate-300">เขียนโค้ด ดูตัวอย่าง และทดสอบ</span>
          </div>
        </div>

        {/* Layout & View Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Segmented Layout Mode Switcher */}
          <div className="flex items-center p-0.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setLayoutMode('split')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors ${
                layoutMode === 'split'
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="แสดงโค้ดและ Preview เคียงข้างกัน (3 จอ)"
              aria-label="มุมมองแบ่งหน้าจอโค้ดและพรีวิว"
            >
              <Columns size={13} />
              <span className="hidden md:inline">โค้ด + Preview</span>
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode('code-only')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors ${
                layoutMode === 'code-only'
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="แสดง Code Studio เต็มจอ"
              aria-label="มุมมองโค้ดอย่างเดียว"
            >
              <Code2 size={13} />
              <span className="hidden md:inline">โค้ด</span>
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode('preview-only')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors ${
                layoutMode === 'preview-only'
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="แสดง Live Preview เต็มจอ"
              aria-label="มุมมองพรีวิวอย่างเดียว"
            >
              <Monitor size={13} />
              <span className="hidden md:inline">Preview</span>
            </button>
          </div>

          {onSwitchToChat && (
            <button
              type="button"
              onClick={onSwitchToChat}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800/60 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
              title="กลับไปที่หน้า Chat เพื่อสั่ง AI"
            >
              <Sparkles size={13} className="text-cyan-400" />
              <span>สั่ง AI ในแชท</span>
            </button>
          )}
        </div>
      </div>

      {/* Build request composer: explicit input for the user's app idea. */}
      <form onSubmit={handleBuildPromptSubmit} className="shrink-0 border-b border-cyan-500/20 bg-[#0b1518] p-3 sm:p-4 space-y-2" aria-label="คำสั่งสร้างแอป">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
            <Sparkles size={16} className="text-amber-300" />
            <span>คุณต้องการสร้างแอปอะไร?</span>
          </div>
          <div className="grid w-full grid-cols-3 gap-1 rounded-lg border border-slate-700 bg-slate-900/80 p-1 sm:flex sm:w-auto sm:items-center" role="group" aria-label="แพลตฟอร์มเป้าหมาย">
            {(['Web', 'Android', 'iOS'] as const).map((platform) => (
              <button
                key={platform}
                type="button"
                aria-pressed={targetPlatform === platform}
                onClick={() => setTargetPlatform(platform)}
                className={`rounded-md px-2.5 py-2 text-xs sm:py-1.5 sm:text-[11px] font-medium transition-colors ${targetPlatform === platform ? 'bg-cyan-600/25 text-cyan-200 ring-1 ring-cyan-500/50' : 'text-slate-400 hover:text-slate-200'}`}
              >
                {platform}
              </button>
            ))}
          </div>
        </div>
        <textarea
          value={buildPrompt}
          onChange={(event) => setBuildPrompt(event.target.value)}
          rows={3}
          maxLength={12000}
          placeholder="อธิบายแอปที่ต้องการ เช่น แอปจัดการงาน มีระบบสมาชิก หน้า Dashboard และบันทึกข้อมูล..."
          aria-label="รายละเอียดแอปที่ต้องการสร้าง"
          className="w-full resize-y rounded-xl border border-slate-700 bg-[#080f11] px-3 py-2.5 text-base sm:text-sm text-slate-100 placeholder:text-slate-500 outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/15"
        />
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-xl text-[10px] leading-relaxed text-slate-500">{'สั่งงานเลย = ส่งให้ AI ทันทีในโหมดเขียนโค้ด / ใส่ช่องแชทก่อน = ไปตรวจและแก้ข้อความก่อนกดส่งเอง. การสร้างไฟล์จริงขึ้นกับความสามารถของ Backend ที่เชื่อมต่อ ไม่มีการสร้างผลลัพธ์ปลอม'}</p>
          <div className="grid grid-cols-2 gap-2 sm:flex sm:shrink-0">
            <button
              type="submit"
              disabled={!buildPrompt.trim() || !onSendBuildPrompt}
              className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-600 bg-slate-800/70 px-3 py-2.5 text-xs font-semibold text-slate-200 transition-colors hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
            >
              ใส่ช่องแชทก่อน
            </button>
            <button
              type="button"
              data-testid="build-send-now"
              onClick={handleBuildPromptSendNow}
              disabled={!buildPrompt.trim() || !onSendBuildPromptNow}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-teal-700 px-3.5 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-teal-600 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Sparkles size={14} />
              สั่งงานเลย
            </button>
          </div>
        </div>
      </form>

      {/* Main Content Area */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden">
        {/* Code Studio Pane (File Tree + Code Editor) */}
        {(layoutMode === 'split' || layoutMode === 'code-only') && (
          <div
            className={`flex flex-col min-h-0 min-w-0 transition-all duration-200 ${
              layoutMode === 'split' ? 'flex-1 lg:w-3/5 border-b lg:border-b-0 lg:border-r border-cyan-500/20' : 'w-full h-full'
            }`}
          >
            <CodeStudioView
              onAnalyzeCode={onAnalyzeCode}
              onSendResultToChat={onSendResultToChat}
              lang={lang}
            />
          </div>
        )}

        {/* Live Preview Pane (Browser / Device Mockup & Mock Deployment) */}
        {(layoutMode === 'split' || layoutMode === 'preview-only') && (
          <div
            className={`flex flex-col min-h-0 min-w-0 overflow-y-auto transition-all duration-200 ${
              layoutMode === 'split' ? 'flex-1 lg:w-2/5' : 'w-full h-full'
            }`}
          >
            <LivePreviewView lang={lang} />
          </div>
        )}
      </div>
    </div>
  );
};
