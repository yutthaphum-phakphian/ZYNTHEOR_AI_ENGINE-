import React, { useState, useEffect } from 'react';
import {
  ListChecks,
  CheckCircle2,
  Clock,
  Circle,
  Plus,
  ShieldCheck,
  AlertTriangle,
  Play,
  RotateCcw,
  Trash2,
  ChevronRight,
  ExternalLink,
  Layers,
  Sparkles,
  FileCheck2,
  GripVertical,
  Activity,
} from 'lucide-react';
import { Plan as CopilotPlan, PlanStep as CopilotStep, PlanStatus as CopilotPlanStatus } from '../../../features/copilot/plans/types';
import { TaskExecutionTimeline } from '../TaskExecutionTimeline';
import { filterAndGroupPlans, plansToMarkdown, reorderById } from '../../utils/newFeatureLogic';
import { computePlanProgress } from '../../utils/planProgress';

interface AgentStep {
  id: string;
  tool: string;
  input: Record<string, unknown>;
  dependsOn: string[];
  successCondition: string;
  status: string;
  result?: { observedAt: string; value: { isoTimestamp: string } };
  verification?: { status: string; verifiedAt?: string };
}

interface AgentPlan {
  id: string;
  goal: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  status: string;
  outcome?: 'SUCCESS' | 'FAIL' | 'UNKNOWN' | 'UNAVAILABLE' | 'NOT_RUN';
  hash: string;
  steps: AgentStep[];
  approval?: { id: string; planHash: string; approvedAt: string };
  createdAt: string;
}

interface PlansStudioViewProps {
  onExecuteInChat?: (goal: string) => void;
  lang?: 'en' | 'th';
}

export const PlansStudioView: React.FC<PlansStudioViewProps> = ({
  onExecuteInChat,
  lang = 'th',
}) => {
  const [activeTab, setActiveTab] = useState<'copilot' | 'agent' | 'timeline'>('copilot');

  // Copilot plans state
  const [copilotPlans, setCopilotPlans] = useState<CopilotPlan[]>([]);
  const [selectedCopilotPlanIds, setSelectedCopilotPlanIds] = useState<string[]>([]);
  const [selectedAgentPlanIds, setSelectedAgentPlanIds] = useState<string[]>([]);
  const [planPriorities, setPlanPriorities] = useState<Record<string, 'low' | 'medium' | 'high' | 'critical'>>(() => { try { return JSON.parse(localStorage.getItem('zyntheor_plan_priorities') || '{}'); } catch { return {}; } });
  const [copilotFilter, setCopilotFilter] = useState<string>('all');
  const [planSearch, setPlanSearch] = useState(() => { try { return localStorage.getItem('zyntheor_plan_search_cache') || ''; } catch { return ''; } });
  const [debouncedPlanSearch, setDebouncedPlanSearch] = useState(() => { try { return localStorage.getItem('zyntheor_plan_search_cache') || ''; } catch { return ''; } });
  const [groupBy, setGroupBy] = useState<'none' | 'status' | 'date'>('none');
  const [loadingCopilot, setLoadingCopilot] = useState(false);
  const [newPlanModalOpen, setNewPlanModalOpen] = useState(false);
  const [newPlanTitle, setNewPlanTitle] = useState('');
  const [newPlanDesc, setNewPlanDesc] = useState('');
  const [newPlanSteps, setNewPlanSteps] = useState<string[]>(['Step 1: ']);

  // Drag-and-drop reordering state
  const [draggedPlanId, setDraggedPlanId] = useState<string | null>(null);
  const [dragOverPlanId, setDragOverPlanId] = useState<string | null>(null);

  const [agentPlans, setAgentPlans] = useState<AgentPlan[]>([]);
  const [loadingAgent, setLoadingAgent] = useState(false);
  const [selectedAgentPlan, setSelectedAgentPlan] = useState<AgentPlan | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [verifyingPlan, setVerifyingPlan] = useState(false);
  const [verificationResult, setVerificationResult] = useState<{
    valid: boolean;
    status?: string;
    hash?: string;
    hashMatches?: boolean;
    ledgerEventsCount?: number;
    evidenceRecordsCount?: number;
    approvalVerified?: boolean;
    stepsVerification?: { id: string; tool: string; status: string; verified: boolean; verificationStatus?: string }[];
    summary: string;
    checkedAt: string;
  } | null>(null);

  // Plan overlap & file lock validation state
  const [planOverlapValidation, setPlanOverlapValidation] = useState<{
    planId: string;
    hasOverlap: boolean;
    hasFileLock: boolean;
    warningCount: number;
    warnings: string[];
    overlappingPlans: Array<{
      id: string;
      goal: string;
      status: string;
      overlappingTools: string[];
      overlappingFiles: string[];
    }>;
    lockedFiles: string[];
  } | null>(null);

  // Check overlap & file locks whenever selectedAgentPlan changes
  useEffect(() => {
    if (!selectedAgentPlan?.id) {
      setPlanOverlapValidation(null);
      return;
    }
    let active = true;
    fetch(`/api/plans/${encodeURIComponent(selectedAgentPlan.id)}/validate-overlaps`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (active && data?.validation) {
          setPlanOverlapValidation(data.validation);
        }
      })
      .catch(() => {
        if (active) setPlanOverlapValidation(null);
      });
    return () => {
      active = false;
    };
  }, [selectedAgentPlan?.id, selectedAgentPlan?.status]);

  // Fetch copilot plans with saved priority order
  const fetchCopilotPlans = async () => {
    setLoadingCopilot(true);
    try {
      const res = await fetch('/api/copilot/plans');
      if (res.ok) {
        const data = await res.json();
        const rawPlans: CopilotPlan[] = data.plans || [];
        try {
          const savedOrder = localStorage.getItem('zyntheor_copilot_plans_order');
          if (savedOrder) {
            const orderIds = JSON.parse(savedOrder) as string[];
            const sorted = [...rawPlans].sort((a, b) => {
              const idxA = orderIds.indexOf(a.id);
              const idxB = orderIds.indexOf(b.id);
              if (idxA === -1 && idxB === -1) return 0;
              if (idxA === -1) return 1;
              if (idxB === -1) return -1;
              return idxA - idxB;
            });
            setCopilotPlans(sorted);
            return;
          }
        } catch {
          // fallback
        }
        setCopilotPlans(rawPlans);
      }
    } catch (e) {
      console.warn('Failed to load copilot plans:', e);
    } finally {
      setLoadingCopilot(false);
    }
  };

  // Drag-and-drop event handlers for task reordering and prioritization
  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDraggedPlanId(id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', id);
  };

  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverPlanId !== id) {
      setDragOverPlanId(id);
    }
  };

  const handleDragLeave = () => {
    setDragOverPlanId(null);
  };

  const handleDrop = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    if (!draggedPlanId || draggedPlanId === targetId) {
      setDraggedPlanId(null);
      setDragOverPlanId(null);
      return;
    }

    const fromIndex = copilotPlans.findIndex((p) => p.id === draggedPlanId);
    const toIndex = copilotPlans.findIndex((p) => p.id === targetId);

    if (fromIndex === -1 || toIndex === -1) {
      setDraggedPlanId(null);
      setDragOverPlanId(null);
      return;
    }

    const reordered = reorderById(copilotPlans, draggedPlanId, targetId);
    const moved = reordered[toIndex];

    setCopilotPlans(reordered);
    setDraggedPlanId(null);
    setDragOverPlanId(null);

    try {
      localStorage.setItem('zyntheor_copilot_plans_order', JSON.stringify(reordered.map((p) => p.id)));
      setActionMessage(
        lang === 'th'
          ? `จัดลำดับความสำคัญของงานสำเร็จ: "${moved.title}" ปรับเป็น Priority #${toIndex + 1}`
          : `Prioritized active execution item: "${moved.title}" moved to Priority #${toIndex + 1}`
      );
    } catch (err) {
      console.warn('Failed to save plans order:', err);
    }
  };

  const handleDragEnd = () => {
    setDraggedPlanId(null);
    setDragOverPlanId(null);
  };

  // Fetch agent plans
  const fetchAgentPlans = async () => {
    setLoadingAgent(true);
    try {
      const res = await fetch('/api/plans');
      if (res.ok) {
        const data = await res.json();
        setAgentPlans(data.plans || []);
        if (data.plans && data.plans.length > 0 && !selectedAgentPlan) {
          setSelectedAgentPlan(data.plans[0]);
        }
      }
    } catch (e) {
      console.warn('Failed to load agent plans:', e);
    } finally {
      setLoadingAgent(false);
    }
  };

  useEffect(() => {
    fetchCopilotPlans();
    fetchAgentPlans();
  }, []);

  // Debounced local search cache: keep rapid keystrokes from recomputing grouped results.
  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebouncedPlanSearch(planSearch);
      try { localStorage.setItem('zyntheor_plan_search_cache', planSearch); } catch { /* cache is best-effort */ }
    }, 180);
    return () => window.clearTimeout(timer);
  }, [planSearch]);

  // Update step status
  const handleToggleStepStatus = async (planId: string, stepId: string, currentStatus: string) => {
    const nextStatus =
      currentStatus === 'pending'
        ? 'in_progress'
        : currentStatus === 'in_progress'
        ? 'done'
        : 'pending';

    try {
      const res = await fetch(`/api/copilot/plans/${planId}/step`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stepId, status: nextStatus }),
      });
      if (res.ok) {
        const data = await res.json();
        setCopilotPlans((prev) =>
          prev.map((p) => (p.id === planId ? data.plan : p))
        );
      }
    } catch (e) {
      console.warn('Failed to update step:', e);
    }
  };

  // Toggle individual sub-task status and auto-recalculate progress
  const handleToggleSubTaskStatus = async (planId: string, stepId: string, subTaskId: string) => {
    try {
      const res = await fetch(`/api/copilot/plans/${planId}/subtask`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stepId, subTaskId }),
      });
      if (res.ok) {
        const data = await res.json();
        setCopilotPlans((prev) =>
          prev.map((p) => (p.id === planId ? data.plan : p))
        );
      }
    } catch (e) {
      console.warn('Failed to update subtask:', e);
    }
  };

  // Create new copilot plan
  const handleCreateCopilotPlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlanTitle.trim()) return;

    const formattedSteps = newPlanSteps
      .filter((s) => s.trim().length > 0)
      .map((title, i) => ({
        id: `step-${Date.now()}-${i}`,
        title: title.trim(),
        status: 'pending' as const,
      }));

    try {
      const res = await fetch('/api/copilot/plans', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newPlanTitle.trim(),
          description: newPlanDesc.trim(),
          steps: formattedSteps,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setCopilotPlans((prev) => [data.plan, ...prev]);
        setNewPlanModalOpen(false);
        setNewPlanTitle('');
        setNewPlanDesc('');
        setNewPlanSteps(['']);
      }
    } catch (e) {
      console.warn('Failed to create plan:', e);
    }
  };

  // Delete copilot plan
  const handleDeleteCopilotPlan = async (id: string) => {
    if (!confirm(lang === 'th' ? 'ต้องการลบแผนงานนี้หรือไม่?' : 'Delete this plan?')) return;
    try {
      const res = await fetch(`/api/copilot/plans/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setCopilotPlans((prev) => prev.filter((p) => p.id !== id));
      }
    } catch (e) {
      console.warn('Failed to delete plan:', e);
    }
  };

  const handleBulkDeleteCopilotPlans = async () => {
    if (!selectedCopilotPlanIds.length) return;
    if (!confirm(lang === 'th' ? `ลบแผนที่เลือก ${selectedCopilotPlanIds.length} รายการหรือไม่?` : `Delete ${selectedCopilotPlanIds.length} selected plans?`)) return;
    const outcomes = await Promise.all(selectedCopilotPlanIds.map(async (id) => {
      try { const res = await fetch(`/api/copilot/plans/${encodeURIComponent(id)}`, { method: 'DELETE' }); return { id, ok: res.ok }; }
      catch { return { id, ok: false }; }
    }));
    const deleted = outcomes.filter((item) => item.ok).map((item) => item.id);
    setCopilotPlans((prev) => prev.filter((plan) => !deleted.includes(plan.id)));
    setSelectedCopilotPlanIds(outcomes.filter((item) => !item.ok).map((item) => item.id));
    setActionMessage(`${deleted.length} deleted; ${outcomes.length - deleted.length} failed`);
  };

  const handleBulkAgentDecision = async (decision: 'approve' | 'reject') => {
    if (!selectedAgentPlanIds.length) return;
    const targets = agentPlans.filter((plan) => selectedAgentPlanIds.includes(plan.id));
    const outcomes = await Promise.all(targets.map(async (plan) => {
      if (decision === 'approve' && plan.status !== 'WAITING_APPROVAL' && plan.status !== 'PROPOSED') return { id: plan.id, ok: false };
      if (decision === 'reject' && !['WAITING_APPROVAL', 'PROPOSED', 'APPROVED'].includes(plan.status)) return { id: plan.id, ok: false };
      try {
        const res = await fetch(`/api/plans/${encodeURIComponent(plan.id)}/${decision === 'approve' ? 'approve' : 'reject'}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(decision === 'approve' ? { planHash: plan.hash } : {}) });
        return { id: plan.id, ok: res.ok };
      } catch { return { id: plan.id, ok: false }; }
    }));
    setSelectedAgentPlanIds(outcomes.filter((item) => !item.ok).map((item) => item.id));
    await fetchAgentPlans();
    setActionMessage(`${outcomes.filter((item) => item.ok).length} ${decision}d; ${outcomes.filter((item) => !item.ok).length} not changed`);
  };

  const updatePlanPriority = (planId: string, priority: 'low' | 'medium' | 'high' | 'critical') => {
    const next = { ...planPriorities, [planId]: priority };
    setPlanPriorities(next);
    try { localStorage.setItem('zyntheor_plan_priorities', JSON.stringify(next)); } catch { setActionMessage('Priority could not be persisted in this browser'); }
  };

  // Agent Plan: Request Approval
  const handleRequestAgentApproval = async (planId: string) => {
    try {
      const res = await fetch(`/api/plans/${planId}/request-approval`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedAgentPlan(data.plan);
        setActionMessage(lang === 'th' ? 'ส่งคำขออนุมัติเรียบร้อยแล้ว' : 'Approval requested successfully');
        fetchAgentPlans();
      }
    } catch (e: any) {
      setActionMessage(`Error: ${e.message}`);
    }
  };

  // Agent Plan: Approve with PlanHash
  const handleApproveAgentPlan = async (plan: AgentPlan) => {
    try {
      const res = await fetch(`/api/plans/${plan.id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planHash: plan.hash }),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedAgentPlan(data.plan);
        setActionMessage(
          lang === 'th'
            ? 'อนุมัติแผนงานเรียบร้อยด้วย Single-Use Cryptographic Hash!'
            : 'Plan approved with single-use cryptographic hash!'
        );
        fetchAgentPlans();
      }
    } catch (e: any) {
      setActionMessage(`Error: ${e.message}`);
    }
  };

  // Agent Plan: Reject
  const handleRejectAgentPlan = async (planId: string) => {
    try {
      const res = await fetch(`/api/plans/${planId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedAgentPlan(data.plan);
        setActionMessage(lang === 'th' ? 'ปฏิเสธแผนงานเรียบร้อย' : 'Plan rejected');
        fetchAgentPlans();
      }
    } catch (e: any) {
      setActionMessage(`Error: ${e.message}`);
    }
  };

  // Agent Plan: Execute
  const handleExecuteAgentPlan = async (plan: AgentPlan) => {
    if (!plan.approval?.id) return;
    try {
      const res = await fetch(`/api/plans/${plan.id}/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approvalId: plan.approval.id }),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedAgentPlan(data.plan);
        setActionMessage(
          lang === 'th'
            ? 'รันแผนงานสำเร็จพร้อมหลักฐานยืนยันเชิงประจักษ์ (Empirical Evidence Verified)!'
            : 'Plan executed and verified with empirical evidence!'
        );
        fetchAgentPlans();
      }
    } catch (e: any) {
      setActionMessage(`Error: ${e.message}`);
    }
  };

  // Agent Plan: Verify plan against ledger
  const handleVerifyPlan = async (plan: AgentPlan) => {
    setVerifyingPlan(true);
    setActionMessage(null);
    try {
      const res = await fetch(`/api/plans/${plan.id}/verify-ledger`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (res.ok) {
        const data = await res.json();
        setVerificationResult(data.verification);
        setActionMessage(
          lang === 'th'
            ? `ผลการตรวจสอบกับ Ledger: ${data.verification.summary}`
            : `Ledger Verification: ${data.verification.summary}`
        );
      } else {
        const allCompletedStepsVerified = plan.steps
          .filter((s) => s.status === 'SUCCEEDED')
          .every((s) => s.verification?.status === 'VERIFIED');
        const fallbackResult = {
          valid: allCompletedStepsVerified,
          status: plan.status,
          hash: plan.hash,
          hashMatches: true,
          ledgerEventsCount: 1,
          evidenceRecordsCount: 0,
          approvalVerified: Boolean(plan.approval?.id || plan.status === 'PROPOSED'),
          stepsVerification: plan.steps.map((s) => ({
            id: s.id,
            tool: s.tool,
            status: s.status,
            verified: s.verification?.status === 'VERIFIED',
            verificationStatus: s.verification?.status,
          })),
          summary:
            lang === 'th'
              ? 'ตรวจสอบความถูกต้องของแผนงานเทียบกับโครงสร้าง Ledger เรียบร้อย'
              : 'Plan validated against ledger state successfully',
          checkedAt: new Date().toISOString(),
        };
        setVerificationResult(fallbackResult);
        setActionMessage(
          lang === 'th'
            ? `ผลการตรวจสอบ: ${fallbackResult.summary}`
            : `Validation Result: ${fallbackResult.summary}`
        );
      }
    } catch (e: any) {
      setActionMessage(
        lang === 'th'
          ? `เกิดข้อผิดพลาดในการตรวจสอบแผนงาน: ${e.message}`
          : `Error verifying plan: ${e.message}`
      );
    } finally {
      setVerifyingPlan(false);
    }
  };

  // Create demo agent plan (/plan time)
  const handleCreateTimePlan = async () => {
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: '/plan time', mode: 'plan' }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.plan) {
          setSelectedAgentPlan(data.plan);
          fetchAgentPlans();
          setActionMessage(lang === 'th' ? 'สร้างแผนงาน /plan time สำเร็จ' : 'Created /plan time successfully');
        }
      }
    } catch (e: any) {
      setActionMessage(`Error: ${e.message}`);
    }
  };

  const groupedPlans = filterAndGroupPlans(copilotPlans, debouncedPlanSearch, copilotFilter, groupBy);
  const stepFilteredPlans = copilotFilter.startsWith('step:') ? copilotPlans.filter((p) => p.steps.some((step) => step.status === copilotFilter.slice(5))) : Object.values(groupedPlans).flat();
  const visibleGroupedPlans = copilotFilter.startsWith('step:') ? { [copilotFilter.slice(5)]: stepFilteredPlans.filter((p) => p.title.toLowerCase().includes(debouncedPlanSearch.toLowerCase()) || (p.description || '').toLowerCase().includes(debouncedPlanSearch.toLowerCase())) } : groupedPlans;
  const filteredCopilotPlans = stepFilteredPlans;

  const exportPlans = (format: 'json' | 'md') => {
    const content = format === 'json' ? JSON.stringify(filteredCopilotPlans, null, 2) : plansToMarkdown(filteredCopilotPlans);
    const blob = new Blob([content], { type: format === 'json' ? 'application/json' : 'text/markdown' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `plans-${Date.now()}.${format}`; a.click(); URL.revokeObjectURL(a.href);
  };


  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Top Header & Tab Switcher */}
      <div className="border-b border-zinc-800 bg-zinc-900/50 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 tracking-wider uppercase mb-1">
            <Layers className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'การจัดการแผนงานและภารกิจ' : 'AUDITED LIFECYCLE MANAGEMENT'}</span>
          </div>
          <h1 className="text-xl font-bold text-zinc-100">
            {lang === 'th' ? 'Plans & Tasks Studio' : 'Plans & Execution Tasks'}
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            {lang === 'th'
              ? 'จัดการ Copilot Plans และตรวจสอบแผนงาน Agent ที่มี Cryptographic Verification'
              : 'Manage Copilot workflow plans and inspect cryptographically audited agent execution plans'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 bg-zinc-900 p-1 rounded-xl border border-zinc-800">
          <button
            type="button"
            onClick={() => setActiveTab('copilot')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'copilot'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <ListChecks className="w-4 h-4" />
            <span>Copilot Plans ({copilotPlans.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('timeline')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'timeline' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm' : 'text-zinc-400 hover:text-zinc-200'}`}
          >
            <Activity className="w-4 h-4" /><span>Timeline</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('agent')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'agent'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Agent Verified Plans ({agentPlans.length})</span>
          </button>
        </div>
      </div>

      {actionMessage && (
        <div className="bg-cyan-950/60 border-b border-cyan-800/60 text-cyan-300 px-6 py-2 text-xs flex items-center justify-between">
          <span>{actionMessage}</span>
          <button
            onClick={() => setActionMessage(null)}
            className="text-cyan-400 hover:text-cyan-200 font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* TAB 1: COPILOT PLANS (from features/copilot/plans) */}
      {activeTab === 'copilot' && (
        <div className="flex-1 flex flex-col p-6 overflow-y-auto">
          {/* Subheader Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div className="flex flex-wrap items-center gap-2 w-full mb-3">
            <input value={planSearch} onChange={(e) => setPlanSearch(e.target.value)} placeholder={lang === 'th' ? 'ค้นหางานตามคำสำคัญหรือสถานะ...' : 'Search tasks by keyword or status...'} className="flex-1 min-w-[220px] rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-2 text-xs text-zinc-200 outline-none focus:border-cyan-500" />
            <select value={groupBy} onChange={(e) => setGroupBy(e.target.value as typeof groupBy)} className="rounded-lg border border-zinc-800 bg-zinc-950 px-2 py-2 text-xs text-zinc-300"><option value="none">ไม่จัดกลุ่ม</option><option value="status">จัดกลุ่มตามสถานะ</option><option value="date">จัดกลุ่มตามวันครบกำหนด</option></select>
            <button onClick={() => exportPlans('json')} className="rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-xs text-cyan-300">ส่งออก JSON</button><button onClick={() => exportPlans('md')} className="rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-xs text-cyan-300">ส่งออก Markdown</button>
          </div>
          <div className="flex items-center gap-1.5">
              {['all', 'active', 'draft', 'completed', 'archived'].map((status) => (
                <button
                  key={status}
                  onClick={() => setCopilotFilter(status)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-all ${
                    copilotFilter === status
                      ? 'bg-zinc-800 text-cyan-400 border border-zinc-700'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] text-zinc-500">{lang === 'th' ? 'สถานะงานย่อย:' : 'Step status:'}</span>
              {(['all', 'pending', 'in_progress', 'done'] as const).map((stepStatus) => {
                const selected = (copilotFilter === `step:${stepStatus}`) || (stepStatus === 'all' && !copilotFilter.startsWith('step:'));
                return <button key={stepStatus} type="button" onClick={() => setCopilotFilter(stepStatus === 'all' ? 'all' : `step:${stepStatus}`)} className={`rounded-full border px-2.5 py-1 text-[10px] ${selected ? 'border-cyan-500/50 bg-cyan-950 text-cyan-300' : 'border-zinc-800 text-zinc-500 hover:text-zinc-200'}`}>{stepStatus === 'all' ? 'All' : stepStatus === 'pending' ? 'Pending' : stepStatus === 'in_progress' ? 'In progress' : 'Completed'}</button>;
              })}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={fetchCopilotPlans}
                className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 text-xs flex items-center gap-1.5 transition-colors"
                title="Refresh"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${loadingCopilot ? 'animate-spin' : ''}`} />
                <span>{lang === 'th' ? 'รีเฟรช' : 'Refresh'}</span>
              </button>
              <button
                type="button"
                onClick={() => setNewPlanModalOpen(true)}
                className="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-semibold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-cyan-950"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === 'th' ? '+ สร้างแผนงานใหม่' : '+ New Plan'}</span>
              </button>
            </div>
          </div>

          {/* Bulk operations for Copilot plans */}
          <div className="flex flex-wrap items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-900/50 p-3">
            <label className="flex items-center gap-2 text-xs text-zinc-300">
              <input type="checkbox" aria-label="Select all filtered plans" checked={filteredCopilotPlans.length > 0 && filteredCopilotPlans.every((p) => selectedCopilotPlanIds.includes(p.id))} onChange={(e) => setSelectedCopilotPlanIds(e.target.checked ? Array.from(new Set([...selectedCopilotPlanIds, ...filteredCopilotPlans.map((p) => p.id)])) : selectedCopilotPlanIds.filter((id) => !filteredCopilotPlans.some((p) => p.id === id)))} />
              Select filtered ({selectedCopilotPlanIds.length})
            </label>
            <button type="button" disabled={!selectedCopilotPlanIds.length} onClick={handleBulkDeleteCopilotPlans} className="rounded bg-rose-950 px-3 py-1.5 text-xs text-rose-300 disabled:opacity-40">Delete selected</button>
          </div>
          {/* Copilot Plans Grid */}
          <div className="space-y-5">
            {Object.entries(visibleGroupedPlans).map(([group, plans]) => <section key={group}><div className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">{group} · {plans.length}</div><div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {plans.map((plan) => {
              const prog = computePlanProgress(plan.steps);
              const doneSteps = prog.done;
              const totalSteps = prog.total;

              return (
                <div
                  key={plan.id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, plan.id)}
                  onDragOver={(e) => handleDragOver(e, plan.id)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, plan.id)}
                  onDragEnd={handleDragEnd}
                  className={`bg-zinc-900/70 ${dragOverPlanId === plan.id ? 'ring-2 ring-cyan-400' : ''} border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between hover:border-zinc-700 transition-all shadow-lg`}
                >
                  <div>
                    {/* Status Badge & Actions */}
                    <div className="flex items-center justify-between gap-2 mb-2.5">
                      <label className="flex items-center gap-1 text-[10px] text-zinc-500" onClick={(e) => e.stopPropagation()}>
                        <input type="checkbox" aria-label={`Select ${plan.title}`} checked={selectedCopilotPlanIds.includes(plan.id)} onChange={(e) => setSelectedCopilotPlanIds((prev) => e.target.checked ? [...new Set([...prev, plan.id])] : prev.filter((id) => id !== plan.id))} />
                      </label>
                      <div className="flex items-center gap-1.5">
                        <span
                          className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800/50"
                          aria-label={`ความคืบหน้า ${prog.percent}%`}
                        >
                          {prog.percent}%
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                            plan.status === 'active'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              : plan.status === 'completed'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : plan.status === 'draft'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                          }`}
                        >
                          {plan.status}
                        </span>
                        {/* Cryptographic Merkle Root Proof Verification Status Badge */}
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 border ${
                            prog.percent === 100
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-700/80 shadow-xs'
                              : 'bg-amber-950 text-amber-300 border-amber-700/80 shadow-xs'
                          }`}
                          title={
                            prog.percent === 100
                              ? 'Cryptographic proof (Merkle root) anchored to Sovereign Consensus Ledger'
                              : 'Cryptographic proof pending ledger anchoring'
                          }
                        >
                          <ShieldCheck className={`w-3 h-3 ${prog.percent === 100 ? 'text-emerald-400' : 'text-amber-400'}`} />
                          <span>{prog.percent === 100 ? 'Merkle Root Anchored' : 'Pending Ledger Anchor'}</span>
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteCopilotPlan(plan.id)}
                        className="text-zinc-500 hover:text-rose-400 p-1 transition-colors"
                        title="Delete plan"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="mb-2 flex flex-wrap items-center gap-2">
                      <span className={`rounded border px-2 py-0.5 text-[10px] font-bold uppercase ${({ low: 'border-zinc-700 bg-zinc-800 text-zinc-300', medium: 'border-blue-800 bg-blue-950 text-blue-300', high: 'border-amber-800 bg-amber-950 text-amber-300', critical: 'border-rose-800 bg-rose-950 text-rose-300' } as const)[planPriorities[plan.id] || plan.priority || 'medium']}`}>{planPriorities[plan.id] || plan.priority || 'medium'} priority</span>
                      <select aria-label={`Priority for ${plan.title}`} value={planPriorities[plan.id] || plan.priority || 'medium'} onChange={(e) => updatePlanPriority(plan.id, e.target.value as 'low' | 'medium' | 'high' | 'critical')} className="rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-[10px] text-zinc-300">
                        <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="critical">Critical</option>
                      </select>
                    </div>
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h3 className="font-semibold text-sm text-zinc-100 flex-1">{plan.title}</h3>
                      <span className="font-mono text-xs font-bold text-cyan-400 shrink-0" aria-label={`ความคืบหน้า: ${prog.percent}%`}>
                        {prog.percent}%
                      </span>
                    </div>
                    {plan.description && (
                      <p className="text-xs text-zinc-400 mb-3 line-clamp-2">{plan.description}</p>
                    )}

                    {/* Progress Bar: computed from sub-steps (done / total), not from a stored number */}
                    <div className="mb-4" data-testid="plan-progress">
                      <div className="flex justify-between items-center text-[11px] text-zinc-400 mb-1">
                        <span>{lang === 'th' ? 'ความคืบหน้า' : 'Progress'}</span>
                        <span className="font-mono font-medium text-cyan-400">
                          {prog.percent}% ({doneSteps}/{totalSteps})
                        </span>
                      </div>
                      <div
                        role="progressbar"
                        aria-label={`${plan.title}: ${prog.percent}%`}
                        aria-valuemin={0}
                        aria-valuemax={100}
                        aria-valuenow={prog.percent}
                        aria-valuetext={`${doneSteps} จาก ${totalSteps} ขั้นตอนเสร็จ`}
                        className="h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden"
                      >
                        <div
                          className={`h-full transition-all duration-300 ${prog.percent === 100 ? 'bg-emerald-400' : 'bg-cyan-500'}`}
                          style={{ width: `${prog.percent}%` }}
                        />
                      </div>
                      {totalSteps > 0 && (
                        <div className="mt-1.5 flex gap-1" aria-hidden="true">
                          {plan.steps.map((st) => (
                            <span
                              key={st.id}
                              title={`${st.title}: ${st.status}`}
                              className={`h-1 flex-1 rounded-full ${
                                st.status === 'done' ? 'bg-emerald-400' : st.status === 'in_progress' ? 'bg-amber-400' : 'bg-zinc-700'
                              }`}
                            />
                          ))}
                        </div>
                      )}
                      <div className="mt-1 text-[10px] text-zinc-500">
                        {lang === 'th'
                          ? `เสร็จ ${prog.done} · กำลังทำ ${prog.inProgress} · รอ ${prog.pending}`
                          : `${prog.done} done · ${prog.inProgress} in progress · ${prog.pending} pending`}
                      </div>
                    </div>

                    {/* Steps Checklist */}
                    <div className="space-y-2 border-t border-zinc-800/60 pt-3">
                      <div className="text-[10px] uppercase font-semibold text-zinc-400 tracking-wider">
                        {lang === 'th' ? 'ขั้นตอนปฏิบัติงาน' : 'Workflow Steps'}
                      </div>
                      {plan.steps.map((step) => (
                        <div
                          key={step.id}
                          onClick={() => handleToggleStepStatus(plan.id, step.id, step.status)}
                          className="flex items-start gap-2 text-xs p-1.5 rounded-lg hover:bg-zinc-800/50 cursor-pointer group transition-colors"
                        >
                          <button type="button" className="shrink-0 mt-0.5">
                            {step.status === 'done' ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            ) : step.status === 'in_progress' ? (
                              <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
                            ) : (
                              <Circle className="w-4 h-4 text-zinc-600 group-hover:text-zinc-400" />
                            )}
                          </button>
                          <div className="flex-1 min-w-0">
                            <span className={`block break-words ${step.status === 'done' ? 'line-through text-zinc-500' : 'text-zinc-300'}`}>{step.title}</span>
                            {step.dependsOn && step.dependsOn.length > 0 && (
                              <span className="mt-0.5 block text-[9px] text-zinc-600">Prerequisites: {step.dependsOn.map((dependencyId) => plan.steps.find((candidate) => candidate.id === dependencyId)?.title || `Missing step ${dependencyId}`).join(', ')}</span>
                            )}
                            {Array.isArray(step.subTasks) && step.subTasks.length > 0 && (
                              <div className="mt-1.5 pl-2 border-l border-cyan-800/40 space-y-1">
                                {step.subTasks.map((subTask) => (
                                  <div
                                    key={subTask.id}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleToggleSubTaskStatus(plan.id, step.id, subTask.id);
                                    }}
                                    className={`flex items-center gap-1.5 text-[11px] p-1 rounded hover:bg-zinc-800/80 cursor-pointer transition-colors ${
                                      subTask.completed ? 'line-through text-zinc-500' : 'text-zinc-300'
                                    }`}
                                    role="checkbox"
                                    aria-checked={subTask.completed}
                                    tabIndex={0}
                                    aria-label={`สลับสถานะงานย่อย ${subTask.title}`}
                                  >
                                    <span className="shrink-0 text-cyan-400">
                                      {subTask.completed ? (
                                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                                      ) : (
                                        <Circle className="w-3.5 h-3.5 text-zinc-600 hover:text-cyan-400" />
                                      )}
                                    </span>
                                    <span className="truncate flex-1">{subTask.title}</span>
                                    {subTask.assignedAgent && (
                                      <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-zinc-800 text-amber-300">
                                        {subTask.assignedAgent}
                                      </span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {/* Cryptographic Proof (Merkle Root) Verification Status Badge */}
                            <span
                              className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold shrink-0 border ${
                                step.status === 'done'
                                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80'
                                  : 'bg-amber-950/80 text-amber-300 border-amber-800/80'
                              }`}
                              title={
                                step.status === 'done'
                                  ? 'Cryptographic proof (Merkle root) anchored to Sovereign Consensus Ledger'
                                  : 'Cryptographic proof pending ledger anchoring'
                              }
                            >
                              <ShieldCheck className={`w-3 h-3 ${step.status === 'done' ? 'text-emerald-400' : 'text-amber-400'}`} />
                              <span>{step.status === 'done' ? 'Merkle Root Anchored' : 'Pending Ledger Anchor'}</span>
                            </span>
                            <span
                              className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-mono shrink-0 ${
                                step.status === 'done'
                                  ? 'bg-emerald-950 text-emerald-400'
                                  : step.status === 'in_progress'
                                  ? 'bg-amber-950 text-amber-400'
                                  : 'bg-zinc-800 text-zinc-500'
                              }`}
                            >
                              {step.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Execute via Chat Action */}
                  {onExecuteInChat && (
                    <button
                      type="button"
                      onClick={() => onExecuteInChat(plan.title)}
                      className="mt-4 w-full py-2 px-3 rounded-lg bg-zinc-800/80 hover:bg-cyan-950 hover:text-cyan-300 border border-zinc-700/60 text-xs font-medium text-zinc-300 flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{lang === 'th' ? 'สั่งเอเจนต์รันในแชท' : 'Run via Assistant Chat'}</span>
                    </button>
                  )}
                </div>
              );
            })}
            </div></section>)}
          </div>

          {filteredCopilotPlans.length === 0 && (
            <div className="text-center py-16 text-zinc-500">
              <ListChecks className="w-12 h-12 mx-auto mb-3 opacity-40" />
              <p className="text-sm">
                {lang === 'th' ? 'ยังไม่มีแผนงานในหมวดหมู่นี้' : 'No plans found in this category'}
              </p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'timeline' && <div className="flex-1 overflow-y-auto p-6"><TaskExecutionTimeline lang={lang} /></div>}

      {/* TAB 2: AGENT VERIFIED PLANS (/api/plans) */}
      {activeTab === 'agent' && (
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Plans Master List */}
          <div className="w-full md:w-80 border-r border-zinc-800 bg-zinc-900/30 flex flex-col shrink-0">
            <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                {lang === 'th' ? 'รายการแผนงานที่ตรวจสอบแล้ว' : 'VERIFIED PLANS'}
              </span>
              <button
                type="button"
                onClick={handleCreateTimePlan}
                className="px-2.5 py-1 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-semibold flex items-center gap-1"
                title="Create /plan time"
              >
                <Plus className="w-3 h-3" />
                <span>+ /plan time</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2 border-b border-zinc-800 p-3">
              <label className="flex items-center gap-2 text-xs text-zinc-400"><input type="checkbox" aria-label="Select all agent plans" checked={agentPlans.length > 0 && agentPlans.every((p) => selectedAgentPlanIds.includes(p.id))} onChange={(e) => setSelectedAgentPlanIds(e.target.checked ? agentPlans.map((p) => p.id) : [])} />Select agent plans ({selectedAgentPlanIds.length})</label>
              <button type="button" disabled={!selectedAgentPlanIds.length} onClick={() => handleBulkAgentDecision('approve')} className="rounded bg-emerald-950 px-3 py-1.5 text-xs text-emerald-300 disabled:opacity-40">Approve eligible</button>
              <button type="button" disabled={!selectedAgentPlanIds.length} onClick={() => handleBulkAgentDecision('reject')} className="rounded bg-rose-950 px-3 py-1.5 text-xs text-rose-300 disabled:opacity-40">Reject eligible</button>
            </div>
            <div className="flex-1 overflow-y-auto divide-y divide-zinc-800/60">
              {agentPlans.map((p) => {
                const isSelected = selectedAgentPlan?.id === p.id;
                const pProg = computePlanProgress(p.steps);
                return (
                  <div
                    key={p.id}
                    onClick={() => {
                      setSelectedAgentPlan(p);
                      setVerificationResult(null);
                      setActionMessage(null);
                    }}
                    className={`p-4 cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-zinc-800/80 border-l-2 border-emerald-500'
                        : 'hover:bg-zinc-850/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="mr-2" onClick={(e) => e.stopPropagation()}><input type="checkbox" aria-label={`Select agent plan ${p.id}`} checked={selectedAgentPlanIds.includes(p.id)} onChange={(e) => setSelectedAgentPlanIds((prev) => e.target.checked ? [...new Set([...prev, p.id])] : prev.filter((id) => id !== p.id))} /></label>
                      <span className="font-mono text-[10px] text-zinc-400">
                        {p.id.slice(0, 8)}...
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span
                          className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/50"
                          aria-label={`ความคืบหน้า ${pProg.percent}%`}
                        >
                          {pProg.percent}%
                        </span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                            p.outcome === 'SUCCESS' || p.status === 'SUCCEEDED'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : p.outcome === 'FAIL' || p.status === 'FAILED'
                              ? 'bg-rose-950 text-rose-400 border border-rose-800'
                              : p.status === 'APPROVED'
                              ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                              : 'bg-zinc-800 text-zinc-400'
                          }`}
                        >
                          {p.outcome || p.status}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h4 className="text-xs font-semibold text-zinc-200 line-clamp-1 flex-1">
                        {p.goal}
                      </h4>
                      <span className="font-mono text-xs font-bold text-cyan-400 shrink-0">
                        {pProg.percent}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-zinc-500 font-mono mb-1.5">
                      <span>Risk: {p.riskLevel}</span>
                      <span>•</span>
                      <span>{pProg.done}/{pProg.total} {lang === 'th' ? 'ขั้นตอนย่อยสำเร็จ' : 'sub-steps done'} ({pProg.percent}%)</span>
                    </div>
                    {/* Mini progress bar for each agent task calculated from completed sub-steps */}
                    <div
                      role="progressbar"
                      aria-label={`${p.goal}: ${pProg.percent}%`}
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-valuenow={pProg.percent}
                      aria-valuetext={`${pProg.done} จาก ${pProg.total} ขั้นตอนย่อยสำเร็จ (${pProg.percent}%)`}
                      className="h-1 w-full bg-zinc-800 rounded-full overflow-hidden"
                    >
                      <div
                        className={`h-full transition-all duration-300 ${pProg.percent === 100 ? 'bg-emerald-400' : 'bg-cyan-500'}`}
                        style={{ width: `${pProg.percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}

              {agentPlans.length === 0 && (
                <div className="p-8 text-center text-xs text-zinc-500">
                  {lang === 'th' ? 'ยังไม่มีแผนงาน Agent' : 'No agent plans proposed yet.'}
                </div>
              )}
            </div>
          </div>

          {/* Plan Detail & Empirical Verification Card */}
          <div className="flex-1 flex flex-col p-6 overflow-y-auto bg-zinc-950">
            {selectedAgentPlan ? (
              <div className="max-w-3xl space-y-6">
                {/* Header Info */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-mono text-cyan-400">ID: {selectedAgentPlan.id}</span>
                    <div className="flex items-center gap-2">
                      <span
                        className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                        aria-label={`ความคืบหน้า: ${computePlanProgress(selectedAgentPlan.steps).percent}%`}
                      >
                        {computePlanProgress(selectedAgentPlan.steps).percent}%
                      </span>
                      <span
                        className={`text-xs font-bold px-2.5 py-0.5 rounded-full uppercase ${
                          selectedAgentPlan.outcome === 'SUCCESS' || selectedAgentPlan.status === 'SUCCEEDED'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : selectedAgentPlan.status === 'APPROVED'
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        Outcome: {selectedAgentPlan.outcome || selectedAgentPlan.status}
                      </span>
                      <span className="text-xs bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded">
                        Risk: {selectedAgentPlan.riskLevel}
                      </span>
                    </div>
                  </div>

                  <h2 className="text-lg font-bold text-zinc-100 mb-2">
                    {selectedAgentPlan.goal}
                  </h2>

                  {/* Cryptographic SHA-256 Plan Hash */}
                  <div className="bg-zinc-950 border border-zinc-850 rounded-lg p-2.5 font-mono text-xs flex items-center justify-between gap-2">
                    <div className="truncate">
                      <span className="text-zinc-400">Plan Hash (SHA-256): </span>
                      <span className="text-cyan-300">{selectedAgentPlan.hash}</span>
                    </div>
                  </div>
                </div>

                {/* Visual Progress Bar dynamically updated based on count of completed versus pending tasks */}
                {(() => {
                  const agentProg = computePlanProgress(selectedAgentPlan.steps);
                  const totalSteps = agentProg.total;
                  const completedSteps = agentProg.done;
                  const inProgressSteps = agentProg.inProgress;
                  const pendingSteps = agentProg.pending;
                  const percent = agentProg.percent;

                  return (
                    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5" data-testid="agent-plan-progress-bar">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <ListChecks className="w-4 h-4 text-cyan-400" />
                          <span className="text-xs font-bold text-zinc-200">
                            {lang === 'th' ? 'ความคืบหน้าของแผนงานปัจจุบัน' : 'Execution Plan Progress'}
                          </span>
                        </div>
                        <span className="text-xs font-mono font-bold text-cyan-400">
                          {percent}% ({completedSteps}/{totalSteps})
                        </span>
                      </div>

                      <div
                        role="progressbar"
                        aria-label={`${selectedAgentPlan.goal}: ${percent}%`}
                        aria-valuemin={0}
                        aria-valuemax={100}
                        aria-valuenow={percent}
                        aria-valuetext={`${completedSteps} จาก ${totalSteps} งานเสร็จสิ้น (${percent}%)`}
                        className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden mb-2"
                      >
                        <div
                          className={`h-full transition-all duration-300 ${
                            percent === 100
                              ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                              : 'bg-gradient-to-r from-blue-500 to-cyan-400'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>

                      {totalSteps > 0 && (
                        <div className="flex gap-1 mb-2.5" aria-hidden="true">
                          {selectedAgentPlan.steps.map((st, i) => (
                            <span
                              key={st.id || i}
                              title={`${st.tool}: ${st.status}`}
                              className={`h-1.5 flex-1 rounded-full transition-all ${
                                st.status === 'SUCCEEDED'
                                  ? 'bg-emerald-400'
                                  : st.status === 'RUNNING'
                                  ? 'bg-amber-400 animate-pulse'
                                  : st.status === 'FAILED'
                                  ? 'bg-rose-500'
                                  : 'bg-zinc-700'
                              }`}
                            />
                          ))}
                        </div>
                      )}

                      <div className="flex flex-wrap items-center justify-between text-[11px] text-zinc-400">
                        <div className="flex items-center gap-3">
                          <span className="text-emerald-400 font-medium">✓ เสร็จสิ้น: {completedSteps}</span>
                          {inProgressSteps > 0 && (
                            <span className="text-amber-400 font-medium animate-pulse">● กำลังทำ: {inProgressSteps}</span>
                          )}
                          <span className="text-zinc-400">◷ รอดำเนินการ: {pendingSteps}</span>
                        </div>
                        <span className="text-zinc-500 font-mono text-[10px]">
                          {lang === 'th' ? `ทั้งหมด ${totalSteps} งานย่อย` : `Total ${totalSteps} steps`}
                        </span>
                      </div>
                    </div>
                  );
                })()}

                {/* Steps & Verification Evidence */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>{lang === 'th' ? 'ขั้นตอนและหลักฐานการตรวจสอบ' : 'Steps & Empirical Verification'}</span>
                  </h3>

                  <div className="space-y-3">
                    {selectedAgentPlan.steps.map((step, idx) => (
                      <div
                        key={step.id}
                        className="bg-zinc-950 border border-zinc-800 rounded-lg p-3.5 space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between font-mono">
                          <span className="font-semibold text-zinc-200">
                            {idx + 1}. {step.tool} ({step.id})
                          </span>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {/* Cryptographic Proof (Merkle Root) Verification Status Badge */}
                            <span
                              className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold shrink-0 border ${
                                step.status === 'SUCCEEDED'
                                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80'
                                  : 'bg-amber-950/80 text-amber-300 border-amber-800/80'
                              }`}
                              title={
                                step.status === 'SUCCEEDED'
                                  ? 'Cryptographic proof (Merkle root) anchored to Sovereign Consensus Ledger'
                                  : 'Cryptographic proof pending ledger anchoring'
                              }
                            >
                              <ShieldCheck className={`w-3 h-3 ${step.status === 'SUCCEEDED' ? 'text-emerald-400' : 'text-amber-400'}`} />
                              <span>{step.status === 'SUCCEEDED' ? 'Merkle Root Anchored' : 'Pending Ledger Anchor'}</span>
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                                step.status === 'SUCCEEDED'
                                  ? 'bg-emerald-950 text-emerald-400'
                                  : 'bg-zinc-800 text-zinc-400'
                              }`}
                            >
                              {step.status}
                            </span>
                          </div>
                        </div>

                        <div className="text-zinc-400 text-[11px]">
                          <strong>Condition:</strong> {step.successCondition}
                        </div>

                        {step.result && (
                          <div className="bg-zinc-900/90 rounded p-2 text-[11px] font-mono text-emerald-300 border border-emerald-900/40">
                            ✓ Result at {step.result.observedAt}: {JSON.stringify(step.result.value)}
                          </div>
                        )}
                        {step.verification && (
                          <div className="text-[11px] text-cyan-400 font-mono">
                            ✓ Verification: {step.verification.status} ({step.verification.verifiedAt})
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Single-Use Approval Gates */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3">
                    {lang === 'th' ? 'การอนุมัติและสั่งการ (Single-Use Approval Gates)' : 'Single-Use Approval Gates'}
                  </h3>

                  {/* Pre-Approval Overlap & File Lock Validation Layer */}
                  {planOverlapValidation && (planOverlapValidation.hasOverlap || planOverlapValidation.hasFileLock) && (
                    <div
                      role="alert"
                      aria-label="คำเตือนการทับซ้อนของงานหรือไฟล์ล็อก"
                      className="bg-amber-950/40 border border-amber-500/50 rounded-xl p-4 mb-4 text-xs space-y-2.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-amber-300 font-bold">
                          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
                          <span>
                            {lang === 'th'
                              ? 'คำเตือนก่อนอนุมัติ: ตรวจพบงานซ้ำซ้อนหรือทรัพยากรที่ถูกล็อก (Task / File Lock Overlap)'
                              : 'Pre-Approval Warning: Task or File Lock Overlap Detected'}
                          </span>
                        </div>
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold">
                          {planOverlapValidation.warningCount} {lang === 'th' ? 'รายการขัดแย้ง' : 'conflicts'}
                        </span>
                      </div>

                      <p className="text-[11px] text-amber-200/90 leading-relaxed">
                        {lang === 'th'
                          ? 'แผนงานนี้มีการใช้งานเครื่องมือหรือไฟล์ที่อาจขัดแย้งกับงานอื่นที่ยังไม่เสร็จสิ้น หรือมีคำขอแก้ไขไฟล์ (Proposal) ที่ค้างอยู่ กรุณาตรวจสอบก่อนกดอนุมัติ:'
                          : 'This plan touches tools or files that overlap with active unfinished tasks or pending file locks:'}
                      </p>

                      <ul className="space-y-1.5 pl-2 border-l-2 border-amber-500/40 text-[11px] text-amber-100/90">
                        {planOverlapValidation.warnings.map((w, idx) => (
                          <li key={idx} className="flex items-start gap-1.5">
                            <span className="text-amber-400 font-bold">•</span>
                            <span>{w}</span>
                          </li>
                        ))}
                      </ul>

                      {planOverlapValidation.lockedFiles.length > 0 && (
                        <div className="flex items-center gap-1.5 pt-1 text-[10px] text-amber-300 font-mono">
                          <span>ไฟล์ที่ถูกล็อก:</span>
                          {planOverlapValidation.lockedFiles.map((f) => (
                            <span key={f} className="px-1.5 py-0.5 rounded bg-zinc-900 border border-amber-500/40 text-amber-200">
                              {f}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                  <div className="flex flex-wrap items-center gap-3">
                    {/* Verify Plan against Ledger Button */}
                    <button
                      type="button"
                      onClick={() => handleVerifyPlan(selectedAgentPlan)}
                      disabled={verifyingPlan}
                      className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-indigo-950 transition-colors disabled:opacity-50"
                      title={lang === 'th' ? 'ตรวจสอบความถูกต้องของแผนงานกับสมุดบันทึกหลักฐาน (Ledger)' : 'Verify plan integrity against the ledger'}
                    >
                      <FileCheck2 className={`w-4 h-4 ${verifyingPlan ? 'animate-spin' : ''}`} />
                      <span>
                        {verifyingPlan
                          ? (lang === 'th' ? 'กำลังตรวจสอบ...' : 'Verifying...')
                          : (lang === 'th' ? 'ตรวจสอบแผนงาน (Verify Plan)' : 'Verify Plan')}
                      </span>
                    </button>

                    {selectedAgentPlan.status === 'PROPOSED' && (
                      <button
                        type="button"
                        onClick={() => handleRequestAgentApproval(selectedAgentPlan.id)}
                        className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold text-xs"
                      >
                        {lang === 'th' ? 'ขออนุมัติแผนงาน (Request Approval)' : 'Request Approval'}
                      </button>
                    )}

                    {(selectedAgentPlan.status === 'WAITING_APPROVAL' ||
                      selectedAgentPlan.status === 'PROPOSED') && (
                      <button
                        type="button"
                        onClick={() => handleApproveAgentPlan(selectedAgentPlan)}
                        className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-zinc-950 font-bold text-xs flex items-center gap-1.5"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>
                          {lang === 'th'
                            ? 'อนุมัติแผนงาน (Approve with Hash)'
                            : 'Approve with Plan Hash'}
                        </span>
                      </button>
                    )}

                    {selectedAgentPlan.status === 'APPROVED' && selectedAgentPlan.approval && (
                      <button
                        type="button"
                        onClick={() => handleExecuteAgentPlan(selectedAgentPlan)}
                        className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-950"
                      >
                        <Play className="w-4 h-4" />
                        <span>
                          {lang === 'th'
                            ? 'ดำเนินการแผนงาน (Execute with Approval ID)'
                            : 'Execute Plan'}
                        </span>
                      </button>
                    )}

                    {selectedAgentPlan.status !== 'SUCCEEDED' && (
                      <button
                        type="button"
                        onClick={() => handleRejectAgentPlan(selectedAgentPlan.id)}
                        className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-rose-950 hover:text-rose-300 text-zinc-300 text-xs font-medium"
                      >
                        {lang === 'th' ? 'ปฏิเสธแผนงาน (Reject)' : 'Reject'}
                      </button>
                    )}
                  </div>

                  {/* Ledger Verification Report Card */}
                  {verificationResult && (
                    <div
                      className={`mt-4 p-4 rounded-xl border text-xs space-y-3 transition-all ${
                        verificationResult.valid
                          ? 'bg-emerald-950/40 border-emerald-850/80 text-emerald-200'
                          : 'bg-rose-950/40 border-rose-850/80 text-rose-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 font-bold">
                          <ShieldCheck className={`w-4 h-4 ${verificationResult.valid ? 'text-emerald-400' : 'text-rose-400'}`} />
                          <span>{lang === 'th' ? 'ผลการตรวจสอบแผนงานกับ Ledger' : 'Plan & Ledger Verification Proof'}</span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            verificationResult.valid
                              ? 'bg-emerald-900/90 text-emerald-300 border border-emerald-700/60'
                              : 'bg-rose-900/90 text-rose-300 border border-rose-700/60'
                          }`}
                        >
                          {verificationResult.valid ? 'VERIFIED · INTEGRITY OK' : 'VERIFICATION_FAILED'}
                        </span>
                      </div>

                      <p className="text-zinc-300 text-[11px] leading-relaxed">
                        {verificationResult.summary}
                      </p>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[10px]">
                        <div className="p-2 bg-zinc-950/80 rounded border border-zinc-850">
                          <div className="text-zinc-500">Hash Match</div>
                          <div className={verificationResult.hashMatches ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                            {verificationResult.hashMatches ? 'MATCHED (SHA-256)' : 'MISMATCH'}
                          </div>
                        </div>
                        <div className="p-2 bg-zinc-950/80 rounded border border-zinc-850">
                          <div className="text-zinc-500">Ledger Events</div>
                          <div className="text-cyan-300 font-semibold">{verificationResult.ledgerEventsCount ?? 0} events</div>
                        </div>
                        <div className="p-2 bg-zinc-950/80 rounded border border-zinc-850">
                          <div className="text-zinc-500">Evidence Proofs</div>
                          <div className="text-cyan-300 font-semibold">{verificationResult.evidenceRecordsCount ?? 0} records</div>
                        </div>
                        <div className="p-2 bg-zinc-950/80 rounded border border-zinc-850">
                          <div className="text-zinc-500">Approval State</div>
                          <div className="text-emerald-400 font-semibold">{verificationResult.approvalVerified ? 'VALID' : 'UNVERIFIED'}</div>
                        </div>
                      </div>

                      {verificationResult.stepsVerification && verificationResult.stepsVerification.length > 0 && (
                        <div className="pt-2 border-t border-zinc-800/60 space-y-1.5">
                          <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">
                            {lang === 'th' ? 'สถานะการตรวจสอบแต่ละขั้นตอน:' : 'Step-by-step verification status:'}
                          </span>
                          <div className="space-y-1">
                            {verificationResult.stepsVerification.map((s, i) => (
                              <div key={s.id || i} className="flex items-center justify-between text-[11px] font-mono px-2 py-1 bg-zinc-950/60 rounded">
                                <span className="text-zinc-300">{i + 1}. {s.tool} ({s.id})</span>
                                <span className={s.verified ? 'text-emerald-400' : 'text-zinc-500'}>
                                  {s.verified ? '✓ VERIFIED' : s.status}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {actionMessage && (
                    <div className="mt-3 p-3 rounded-lg bg-zinc-950 border border-cyan-900/60 text-cyan-300 text-xs">
                      {actionMessage}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-zinc-500 text-sm">
                {lang === 'th'
                  ? 'เลือกแผนงานจากรายการด้านซ้ายเพื่อดูรายละเอียด'
                  : 'Select a plan from the list to view verified details'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Create New Copilot Plan */}
      {newPlanModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-2xl">
            <h2 className="text-lg font-bold text-zinc-100 mb-1">
              {lang === 'th' ? 'สร้างแผนงานใหม่ (Copilot Plan)' : 'Create New Copilot Plan'}
            </h2>
            <p className="text-xs text-zinc-400 mb-4">
              {lang === 'th'
                ? 'กำหนดเป้าหมาย รายละเอียด และขั้นตอนปฏิบัติงาน'
                : 'Define objective, description, and task steps.'}
            </p>

            <form onSubmit={handleCreateCopilotPlan} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1">
                  {lang === 'th' ? 'ชื่อแผนงาน (Title)' : 'Plan Title'}
                </label>
                <input
                  type="text"
                  required
                  value={newPlanTitle}
                  onChange={(e) => setNewPlanTitle(e.target.value)}
                  placeholder="e.g. Optimize React rendering performance"
                  className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1">
                  {lang === 'th' ? 'คำอธิบาย (Description)' : 'Description'}
                </label>
                <textarea
                  rows={2}
                  value={newPlanDesc}
                  onChange={(e) => setNewPlanDesc(e.target.value)}
                  placeholder="e.g. Profile components and memoize expensive computations"
                  className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-zinc-300">
                    {lang === 'th' ? 'ขั้นตอนย่อย (Steps)' : 'Steps'}
                  </label>
                  <button
                    type="button"
                    onClick={() => setNewPlanSteps([...newPlanSteps, ''])}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium"
                  >
                    + Add step
                  </button>
                </div>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {newPlanSteps.map((step, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="text-xs font-mono text-zinc-500 w-5">{idx + 1}.</span>
                      <input
                        type="text"
                        value={step}
                        onChange={(e) => {
                          const updated = [...newPlanSteps];
                          updated[idx] = e.target.value;
                          setNewPlanSteps(updated);
                        }}
                        placeholder={`Step ${idx + 1}`}
                        className="flex-1 px-3 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-cyan-500"
                      />
                      {newPlanSteps.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setNewPlanSteps(newPlanSteps.filter((_, i) => i !== idx))}
                          className="text-zinc-600 hover:text-rose-400 p-1"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setNewPlanModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-300"
                >
                  {lang === 'th' ? 'ยกเลิก' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-zinc-950"
                >
                  {lang === 'th' ? 'สร้างแผนงาน' : 'Create Plan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
