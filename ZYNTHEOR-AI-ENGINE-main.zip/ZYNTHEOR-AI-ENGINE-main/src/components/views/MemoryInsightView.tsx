import React, { useEffect, useMemo, useState } from 'react';

/**
 * MemoryInsightView — real data only (GET /api/engine/memory-insight).
 * Nodes: lessons (learningLoop.ts) and workspace facts (contextEngine.ts).
 * Edges are drawn ONLY from recorded evidence:
 *   lesson–lesson : share a runId or an evidenceRef
 *   lesson–fact   : the fact's `evidence` text contains one of the lesson's evidenceRefs
 * Project goals: no goal store is linked to lessons in this codebase, so none are shown
 * (Copilot samplePlans are in-memory samples and are NOT used here).
 */
type LessonStatus = 'CANDIDATE' | 'VALIDATED' | 'REJECTED' | 'STALE';
interface Lesson {
  id: string; taskType: string; lesson: string; status: LessonStatus;
  confirmedByRuns: string[]; contradictedByRuns: string[]; evidenceRefs: string[];
  updatedAt: string; retiredReason?: string;
}
interface Fact { id: string; type: string; statement: string; verified: boolean; stale: boolean; evidence?: string }
interface Policy { persistentMemoryDays: number | null; preserveVerifiedFacts: boolean; updatedAt: string }
type State =
  | { kind: 'loading' }
  | { kind: 'unavailable' }
  | { kind: 'ready'; lessons: Lesson[]; facts: Fact[]; policy: Policy };

const STATUS_LABEL: Record<LessonStatus, { th: string; en: string; cls: string }> = {
  VALIDATED: { th: 'ยืนยันแล้ว', en: 'Validated', cls: 'text-emerald-400' },
  CANDIDATE: { th: 'รอยืนยัน', en: 'Candidate', cls: 'text-amber-400' },
  REJECTED: { th: 'ถูกปฏิเสธ', en: 'Rejected', cls: 'text-red-400' },
  STALE: { th: 'ล้าสมัย', en: 'Stale', cls: 'text-zinc-400' },
};

export const MemoryInsightView: React.FC<{ lang?: 'en' | 'th'; workspaceId: string }> = ({ lang = 'th', workspaceId }) => {
  const th = lang === 'th';
  const [state, setState] = useState<State>({ kind: 'loading' });

  useEffect(() => {
    let cancelled = false;
    setState({ kind: 'loading' });
    (async () => {
      try {
        const res = await fetch(`/api/engine/memory-insight?workspaceId=${encodeURIComponent(workspaceId)}`);
        if (!res.ok) throw new Error(String(res.status));
        const d = await res.json();
        if (!cancelled) setState({ kind: 'ready', lessons: d.lessons ?? [], facts: d.facts ?? [], policy: d.policy });
      } catch {
        if (!cancelled) setState({ kind: 'unavailable' });
      }
    })();
    return () => { cancelled = true; };
  }, [workspaceId]);

  const edges = useMemo(() => {
    if (state.kind !== 'ready') return [];
    const out: { a: string; b: string; why: string }[] = [];
    const L = state.lessons;
    for (let i = 0; i < L.length; i++) for (let j = i + 1; j < L.length; j++) {
      const runs = [...L[i].confirmedByRuns, ...L[i].contradictedByRuns];
      const sharedRun = runs.find((r) => L[j].confirmedByRuns.includes(r) || L[j].contradictedByRuns.includes(r));
      const sharedRef = L[i].evidenceRefs.find((r) => L[j].evidenceRefs.includes(r));
      if (sharedRun) out.push({ a: L[i].id, b: L[j].id, why: `${th ? 'run ร่วม' : 'shared run'}: ${sharedRun}` });
      else if (sharedRef) out.push({ a: L[i].id, b: L[j].id, why: `${th ? 'หลักฐานร่วม' : 'shared evidence'}: ${sharedRef}` });
    }
    for (const l of L) for (const f of state.facts) {
      const ref = f.evidence ? l.evidenceRefs.find((r) => f.evidence!.includes(r)) : undefined;
      if (ref) out.push({ a: l.id, b: f.id, why: `${th ? 'หลักฐานร่วม' : 'shared evidence'}: ${ref}` });
    }
    return out;
  }, [state, th]);

  const label = (id: string) => {
    if (state.kind !== 'ready') return id;
    const l = state.lessons.find((x) => x.id === id);
    if (l) return l.lesson;
    return state.facts.find((x) => x.id === id)?.statement ?? id;
  };

  const box = 'rounded-xl border border-zinc-800 bg-zinc-900/60 p-4';
  if (state.kind === 'loading') return <div className="p-6 text-sm text-zinc-400">{th ? 'กำลังโหลด…' : 'Loading…'}</div>;
  if (state.kind === 'unavailable') {
    return (
      <div className="p-6">
        <div className={box}><span className="font-semibold text-zinc-200">UNAVAILABLE</span>
          <p className="mt-1 text-sm text-zinc-400">{th ? 'อ่านข้อมูลความจำไม่ได้ จึงไม่แสดงข้อมูลใด ๆ' : 'Memory could not be read, so nothing is shown.'}</p></div>
      </div>
    );
  }

  const { lessons, facts, policy } = state;
  const groups = ['VALIDATED', 'CANDIDATE', 'REJECTED', 'STALE'] as LessonStatus[];

  return (
    <div className="h-full overflow-y-auto p-6 space-y-4 text-zinc-200">
      <h2 className="text-lg font-semibold">{th ? 'ภาพรวมความจำ (Memory Insight)' : 'Memory Insight'}</h2>

      <div className={box}>
        <h3 className="text-sm font-semibold mb-1">{th ? 'เป้าหมายโครงการ' : 'Project goals'}</h3>
        <p className="text-sm text-zinc-400">
          {th ? 'ยังไม่มีแหล่งข้อมูลเป้าหมายที่ผูกกับบทเรียนในระบบ จึงไม่แสดงเป้าหมาย (ไม่ใช้แผนตัวอย่าง)' : 'No goal store is linked to lessons yet, so no goals are shown (sample plans are not used).'}
        </p>
      </div>

      {lessons.length === 0 && facts.length === 0 && (
        <div className={box}><p className="text-sm text-zinc-400">{th ? 'ยังไม่มีบทเรียนหรือข้อเท็จจริงที่บันทึกไว้' : 'No lessons or facts have been recorded yet.'}</p></div>
      )}

      {groups.map((g) => {
        const items = lessons.filter((l) => l.status === g);
        if (!items.length) return null;
        return (
          <div key={g} className={box}>
            <h3 className={`text-sm font-semibold mb-2 ${STATUS_LABEL[g].cls}`}>{th ? STATUS_LABEL[g].th : STATUS_LABEL[g].en} ({items.length})</h3>
            <ul className="space-y-2">
              {items.map((l) => (
                <li key={l.id} className="text-sm">
                  <span className="mr-2 rounded bg-zinc-800 px-1.5 py-0.5 text-[11px] text-zinc-300">{l.taskType}</span>{l.lesson}
                  <div className="text-[11px] text-zinc-500">
                    {th ? 'ยืนยันโดย' : 'confirmed by'} {l.confirmedByRuns.length} run · {th ? 'ขัดแย้ง' : 'contradicted'} {l.contradictedByRuns.length} · {th ? 'หลักฐาน' : 'evidence'} {l.evidenceRefs.length}
                    {l.retiredReason ? ` · ${l.retiredReason}` : ''}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        );
      })}

      {facts.length > 0 && (
        <div className={box}>
          <h3 className="text-sm font-semibold mb-2">{th ? 'ข้อเท็จจริงของ Workspace' : 'Workspace facts'} ({facts.length})</h3>
          <ul className="space-y-1 text-sm">
            {facts.map((f) => (
              <li key={f.id}><span className="mr-2 text-[11px] text-zinc-500">{f.type}{f.verified ? ' · verified' : ' · unverified'}{f.stale ? ' · stale' : ''}</span>{f.statement}</li>
            ))}
          </ul>
        </div>
      )}

      <div className={box}>
        <h3 className="text-sm font-semibold mb-2">{th ? 'ความเชื่อมโยงที่มีหลักฐาน' : 'Evidence-backed connections'} ({edges.length})</h3>
        {edges.length === 0
          ? <p className="text-sm text-zinc-400">{th ? 'ยังไม่พบความเชื่อมโยงที่มี run หรือหลักฐานร่วมกัน' : 'No connections with a shared run or evidence found.'}</p>
          : <ul className="space-y-1 text-sm">{edges.map((e, i) => <li key={i}>{label(e.a)} <span className="text-zinc-500">↔</span> {label(e.b)} <span className="text-[11px] text-zinc-500">({e.why})</span></li>)}</ul>}
      </div>

      <div className="text-[11px] text-zinc-500">
        {th ? 'นโยบายเก็บความจำ' : 'Retention'}: {policy.persistentMemoryDays === null ? (th ? 'ไม่ลบตามอายุ' : 'no age-based deletion') : `${policy.persistentMemoryDays} ${th ? 'วัน' : 'days'}`} · {th ? 'เก็บข้อเท็จจริงที่ยืนยันแล้ว' : 'preserve verified facts'}: {String(policy.preserveVerifiedFacts)}
      </div>
    </div>
  );
};
