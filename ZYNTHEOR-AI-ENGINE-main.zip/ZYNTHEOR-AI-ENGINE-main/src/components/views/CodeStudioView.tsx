import React, { useState, useEffect, useMemo } from 'react';
import { notify } from '../../utils/notify';
import { appendVersion } from '../../utils/newFeatureLogic';
import Prism from 'prismjs';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-markup';
import 'prismjs/components/prism-css';
import {
  FileCode,
  Folder,
  Upload,
  Archive,
  Copy,
  Check,
  Sparkles,
  Bug,
  Wrench,
  FileText,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Terminal,
  Play,
  Send,
  Download,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Cpu,
  Search,
  ChevronDown,
  ChevronRight,
  GitCompare,
  Save,
} from 'lucide-react';

interface FileVersion { id: string; content: string; createdAt: string; note: string; }

interface WorkspaceFile {
  name: string;
  size?: number;
  content?: string;
  lastModified?: string;
}

interface ZipEntry {
  path: string;
  size: number;
  compressedSize: number;
  isDir: boolean;
}

interface Proposal {
  id: string;
  name: string;
  type: string;
  riskLevel: string;
  status: string;
  hash: string;
  diff: string;
  approvalId?: string;
}

interface CodeStudioViewProps {
  onAnalyzeCode?: (action: string, code: string, filename: string) => void;
  onSendResultToChat?: (resultMessage: string) => void;
  lang?: 'en' | 'th';
}

export const CodeStudioView: React.FC<CodeStudioViewProps> = ({
  onAnalyzeCode,
  onSendResultToChat,
  lang = 'th',
}) => {
  const [activeTab, setActiveTab] = useState<'editor' | 'zip' | 'proposals' | 'sandbox'>(() => {
    try { return (localStorage.getItem('zyntheor_code_studio_state') ? JSON.parse(localStorage.getItem('zyntheor_code_studio_state')!).activeTab : 'editor') as 'editor' | 'zip' | 'proposals' | 'sandbox'; } catch { return 'editor'; }
  });
  const [isTestReportExpanded, setIsTestReportExpanded] = useState(false);
  const [isNarrowScreen, setIsNarrowScreen] = useState(() => typeof window !== 'undefined' && window.innerWidth <= 700);
  const [isFileTreeCollapsed, setIsFileTreeCollapsed] = useState(() => typeof window !== 'undefined' && window.innerWidth <= 700);
  const [selectedTask, setSelectedTask] = useState<'syntax_check' | 'typecheck' | 'test' | 'build' | 'install_deps'>('syntax_check');
  const [isRunningSandbox, setIsRunningSandbox] = useState(false);
  const [sandboxResult, setSandboxResult] = useState<any>(null);
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<string>(() => {
    try { return JSON.parse(localStorage.getItem('zyntheor_code_studio_state') || '{}').selectedFile || 'server/agent.ts'; } catch { return 'server/agent.ts'; }
  });
  const [fileContent, setFileContent] = useState<string>('');
  const [fileMeta, setFileMeta] = useState<{ size: number; lines: number; type: string }>({
    size: 0,
    lines: 0,
    type: 'typescript',
  });
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [versionHistory, setVersionHistory] = useState<Record<string, FileVersion[]>>({});
  const [showVersions, setShowVersions] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [foldedLines, setFoldedLines] = useState<Set<number>>(new Set());
  const [compareContent, setCompareContent] = useState<string | null>(null);
  const [compareLabel, setCompareLabel] = useState('');

  const language = useMemo(() => {
    const ext = selectedFile.split('.').pop()?.toLowerCase();
    return ext === 'ts' || ext === 'tsx' ? 'typescript' : ext === 'js' || ext === 'jsx' ? 'javascript' : ext === 'json' ? 'json' : ext === 'css' ? 'css' : ext === 'html' ? 'markup' : 'none';
  }, [selectedFile]);

  const highlightedLines = useMemo(() => {
    const grammar = language === 'none' ? undefined : Prism.languages[language];
    return fileContent.split('\n').map((line, index) => ({ index, raw: line, html: grammar ? Prism.highlight(line || ' ', grammar, language) : (line || ' ') }));
  }, [fileContent, language]);

  const lineMatches = useMemo(() => {
    if (!searchQuery.trim()) return new Set<number>();
    const q = searchQuery.toLowerCase();
    return new Set(highlightedLines.filter((line) => line.raw.toLowerCase().includes(q)).map((line) => line.index));
  }, [highlightedLines, searchQuery]);

  const foldEndFor = (lineIndex: number) => {
    let depth = 0;
    for (let i = lineIndex; i < highlightedLines.length; i++) {
      depth += (highlightedLines[i].raw.match(/{/g) || []).length;
      depth -= (highlightedLines[i].raw.match(/}/g) || []).length;
      if (i > lineIndex && depth <= 0) return i;
    }
    return lineIndex;
  };

  const isHiddenByFold = (lineIndex: number) => Array.from(foldedLines).some((start) => lineIndex > start && lineIndex <= foldEndFor(start));

  // ZIP explorer state
  const [zipEntries, setZipEntries] = useState<ZipEntry[]>([]);
  const [zipArchiveName, setZipArchiveName] = useState<string>('');

  // Proposals state
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [proposalMsg, setProposalMsg] = useState<string | null>(null);
  /** Undo stack for last applied proposal (real workspace write) */
  const [undoStack, setUndoStack] = useState<Array<{ proposalId: string; name: string; previousContent: string | null; appliedAt: number }>>([]);
  const [pendingUndoProposalId, setPendingUndoProposalId] = useState<string | null>(null);


  useEffect(() => {
    try { localStorage.setItem('zyntheor_code_studio_state', JSON.stringify({ selectedFile, activeTab, zipArchiveName, savedAt: new Date().toISOString() })); } catch { /* local storage may be unavailable */ }
  }, [selectedFile, activeTab, zipArchiveName]);

  useEffect(() => {
    const updateViewport = () => setIsNarrowScreen(window.innerWidth <= 700);
    window.addEventListener('resize', updateViewport);
    return () => window.removeEventListener('resize', updateViewport);
  }, []);

  const loadVersionHistory = (name: string) => {
    try { setVersionHistory((prev) => ({ ...prev, [name]: JSON.parse(localStorage.getItem(`zyntheor_versions_${name}`) || '[]') })); } catch { /* ignore malformed local history */ }
  };

  const saveVersion = () => {
    const versions = appendVersion(versionHistory[selectedFile] || [], fileContent);
    setVersionHistory((prev) => ({ ...prev, [selectedFile]: versions }));
    localStorage.setItem(`zyntheor_versions_${selectedFile}`, JSON.stringify(versions));
  };

  const compareWithVersion = (version: FileVersion) => { setCompareContent(version.content); setCompareLabel(`Version ${new Date(version.createdAt).toLocaleString('th-TH')}`); };
  const compareWithAi = () => { const proposal = proposals[0]; if (proposal?.diff) { setCompareContent(proposal.diff); setCompareLabel(`AI refactor · ${proposal.name}`); } else setProposalMsg('ยังไม่มี AI refactor ที่พร้อมเปรียบเทียบ'); };

  const revertVersion = (version: FileVersion) => {
    setFileContent(version.content);
    setFileMeta({ size: version.content.length, lines: version.content.split('\n').length, type: selectedFile.split('.').pop() || 'text' });
    setProposalMsg(`ย้อนกลับไปยังรุ่น ${new Date(version.createdAt).toLocaleString('th-TH')} แล้ว`);
  };

  // Fetch workspace files
  const fetchWorkspaceFiles = async () => {
    try {
      const res = await fetch('/api/workspace/files');
      if (res.ok) {
        const data = await res.json();
        const list = Array.isArray(data.files) ? data.files : [];
        setFiles(list);
      } else {
        setFiles([]);
        setProposalMsg(`UNAVAILABLE: Workspace API ตอบ HTTP ${res.status}; ไม่แสดงรายการไฟล์ตัวอย่าง`);
      }
    } catch {
      setFiles([]);
      setProposalMsg('UNAVAILABLE: ไม่สามารถโหลดรายการไฟล์จาก Workspace API ได้ จึงไม่แสดงไฟล์ตัวอย่าง');
    }
  };

  // Fetch file content
  const loadFile = async (name: string) => {
    setSelectedFile(name);
    loadVersionHistory(name);
    setLoading(true);
    try {
      const res = await fetch(`/api/files/${encodeURIComponent(name)}`);
      if (res.ok) {
        const data = await res.json();
        const content = data.file?.content || '';
        setFileContent(content);
        setFileMeta({
          size: data.file?.size || content.length,
          lines: content.split('\n').length,
          type: name.split('.').pop() || 'text',
        });
      } else {
        setFileContent('');
        setFileMeta({ size: 0, lines: 0, type: name.split('.').pop() || 'text' });
        setProposalMsg('UNAVAILABLE: ไม่พบเนื้อหาไฟล์จาก Workspace API จึงไม่แสดงเนื้อหาตัวอย่าง');
      }
    } catch {
      setFileContent('');
      setFileMeta({ size: 0, lines: 0, type: name.split('.').pop() || 'text' });
      setProposalMsg('UNAVAILABLE: ไม่สามารถเชื่อมต่อ Workspace API เพื่อโหลดเนื้อหาไฟล์');
    } finally {
      setLoading(false);
    }
  };

  // Fetch proposals
  const fetchProposals = async () => {
    try {
      const res = await fetch('/api/proposals');
      if (res.ok) {
        const data = await res.json();
        setProposals(data.proposals || []);
      }
    } catch (e) {
      console.warn('Proposals fetch error:', e);
    }
  };

  useEffect(() => {
    fetchWorkspaceFiles();
    loadFile('server/agent.ts');
    fetchProposals();
  }, []);

  // Handle local file inspection
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = String(event.target?.result || '');
      setSelectedFile(file.name);
      setFileContent(content);
      setFileMeta({
        size: file.size,
        lines: content.split('\n').length,
        type: file.name.split('.').pop() || 'text',
      });
      setActiveTab('editor');
    };
    reader.readAsText(file);
  };

  // Handle ZIP upload & inspection
  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setZipArchiveName(file.name);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const res = await fetch('/api/files/inspect-zip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/zip' },
        body: arrayBuffer,
      });
      if (res.ok) {
        const data = await res.json();
        if (data.entries) {
          setZipEntries(data.entries);
        }
      } else {
        setZipEntries([]);
        setProposalMsg('UNAVAILABLE: ZIP inspection API ไม่พร้อมใช้งาน จึงไม่แสดงรายการ ZIP ตัวอย่าง');
      }
      setActiveTab('zip');
    } catch {
      notify('ตรวจสอบไฟล์ ZIP ไม่สำเร็จ', 'error');
    }
  };

  // Copy code
  const handleCopyCode = () => {
    navigator.clipboard.writeText(fileContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Approve proposal
  const handleApproveProposal = async (proposal: Proposal) => {
    try {
      const res = await fetch(`/api/proposals/${proposal.id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hash: proposal.hash }),
      });
      if (res.ok) {
        setProposalMsg(`อนุมัติข้อเสนอ ${proposal.name} สำเร็จ!`);
        fetchProposals();
      }
    } catch (e: any) {
      setProposalMsg(`Error: ${e.message}`);
    }
  };

  // Apply proposal
  const handleApplyProposal = async (proposal: Proposal) => {
    if (!proposal.approvalId) {
      notify('จำเป็นต้องได้รับการอนุมัติ (Approval ID) ก่อนเขียนไฟล์ลง Workspace', 'error');
      return;
    }
    try {
      // Snapshot current file content for Undo (best-effort)
      let previousContent: string | null = null;
      try {
        const snap = await fetch(`/api/files/${encodeURIComponent(proposal.name)}`);
        if (snap.ok) {
          const data = await snap.json();
          const content = data.content ?? data.file?.content;
          if (typeof content === 'string') previousContent = content;
        }
      } catch { /* ignore snapshot errors */ }

      const res = await fetch(`/api/proposals/${proposal.id}/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approvalId: proposal.approvalId }),
      });
      if (res.ok) {
        const isUndoProposal = proposal.id === pendingUndoProposalId;
        setUndoStack((prev) => [
          { proposalId: proposal.id, name: proposal.name, previousContent, appliedAt: Date.now() },
          ...(isUndoProposal ? prev.slice(1) : prev),
        ].slice(0, 10));
        if (isUndoProposal) setPendingUndoProposalId(null);
        setProposalMsg(`เขียนไฟล์ ${proposal.name} ลง Workspace เรียบร้อยแล้ว! (Undo พร้อมใช้)`);
        fetchProposals();
        fetchWorkspaceFiles();
      } else {
        const err = await res.json().catch(() => ({}));
        setProposalMsg(`Apply ล้มเหลว: ${err.message || err.error || res.status}`);
      }
    } catch (e: any) {
      setProposalMsg(`Error: ${e.message}`);
    }
  };

  const handleUndoLastApply = async () => {
    const last = undoStack[0];
    if (!last) {
      setProposalMsg('ไม่มีรายการ Undo');
      return;
    }
    try {
      if (last.previousContent == null) {
        setProposalMsg(`Undo ไม่พร้อม: ไม่มี snapshot เดิมของ ${last.name}`);
        return;
      }
      const res = await fetch('/api/proposals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: last.name, content: last.previousContent, type: 'edit' }),
      });
      if (res.ok) {
        const data = await res.json();
        if (typeof data.proposal?.id === 'string') setPendingUndoProposalId(data.proposal.id);
        setProposalMsg(`สร้างข้อเสนอ Undo สำหรับ ${last.name} แล้ว กรุณาตรวจ diff และอนุมัติก่อน Apply`);
        setActiveTab('proposals');
        await fetchProposals();
      } else {
        const err = await res.json().catch(() => ({}));
        setProposalMsg(`สร้างข้อเสนอ Undo ล้มเหลว: ${err.message || err.error || res.status}`);
      }
    } catch (e: any) {
      setProposalMsg(`Undo error: ${e.message}`);
    }
  };

  // Sandbox Task execution (Syntax check, TypeCheck, Tests, Build)
  const handleRunSandbox = async (task = selectedTask) => {
    setIsRunningSandbox(true);
    setSandboxResult(null);
    try {
      const res = await fetch('/api/sandbox/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskType: task }),
      });
      const data = await res.json();
      setSandboxResult(data);
    } catch (err: any) {
      setSandboxResult({
        status: 'FAIL',
        taskType: task,
        command: [task],
        exitCode: 1,
        durationMs: 0,
        filesHash: 'unknown',
        stdout: '',
        stderr: `Network or fetch error: ${err.message}`,
        networkIsolated: true,
      });
    } finally {
      setIsRunningSandbox(false);
    }
  };

  // One-click send result to ONE CHAT
  const handleSendToChat = () => {
    if (!sandboxResult) return;
    const statusEmoji = sandboxResult.status === 'VERIFIED' ? '✅' : sandboxResult.status === 'FAIL' ? '❌' : '⚠️';
    const msg = [
      `### ${statusEmoji} ผลการรัน Sandbox Task: \`${sandboxResult.taskType}\` [${sandboxResult.status}]`,
      `- **สถานะการรัน**: \`${sandboxResult.status}\`${sandboxResult.reason ? ` (${sandboxResult.reason})` : ''}`,
      `- **คำสั่งที่รัน**: \`${(sandboxResult.command || []).join(' ')}\``,
      `- **Files Hash (SHA-256)**: \`${(sandboxResult.filesHash || '').slice(0, 16)}...\``,
      `- **ระยะเวลา**: ${sandboxResult.durationMs} ms`,
      `- **การแยกเครือข่าย (Network Isolation)**: ${sandboxResult.networkIsolated ? '✓ ปิดเครือข่ายสมบูรณ์ (Linux Network Namespace)' : '✗ ไม่ได้เปิด'}`,
      '',
      '**ผลลัพธ์ (Output):**',
      '```',
      (sandboxResult.stdout || sandboxResult.stderr || 'No output produced.').trim(),
      '```',
      sandboxResult.status === 'VERIFIED'
        ? `\n💡 **ดาวน์โหลดโค้ดที่ผ่านการอนุมัติ**: [ดาวน์โหลด ZIP โครงการ](/api/workspace/download-zip)`
        : '',
    ].filter(Boolean).join('\n');

    if (onSendResultToChat) {
      onSendResultToChat(msg);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Top Header */}
      <div className="border-b border-zinc-800 bg-zinc-900/50 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 tracking-wider uppercase mb-1">
            <FileCode className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'สตูดิโอตรวจสอบโค้ด & ZIP' : 'CODEBASE INSPECTION & ANALYSIS'}</span>
          </div>
          <h1 className="text-xl font-bold text-zinc-100">
            {lang === 'th' ? 'Code & Diff Studio' : 'Code & Diff Studio'}
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            {lang === 'th'
              ? 'เปิดอ่านไฟล์ใน Workspace อัปโหลดไฟล์ ZIP ตรวจสอบโครงสร้าง และขอให้ AI วิเคราะห์'
              : 'Inspect codebase files, upload ZIP archives, and review verified file proposals'}
          </p>
        </div>

        {/* Visual test report for this workspace snapshot */}
        <section aria-live="polite" className="w-full min-w-0 rounded-xl border border-zinc-800 bg-zinc-900/70 p-2 sm:p-3">
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <button type="button" aria-expanded={isTestReportExpanded} onClick={() => setIsTestReportExpanded((expanded) => !expanded)} className="flex min-w-0 flex-1 items-center gap-2 text-left text-xs font-semibold">
              <Terminal className="h-4 w-4 shrink-0 text-cyan-400" />
              <span className="min-w-0 flex-1 truncate">{lang === 'th' ? 'รายงานทดสอบโค้ดในเซสชัน' : 'Session code test report'}</span>
              <span className={`shrink-0 rounded-full px-2 py-0.5 ${isRunningSandbox ? 'bg-cyan-950 text-cyan-300' : sandboxResult?.status === 'VERIFIED' ? 'bg-emerald-950 text-emerald-300' : sandboxResult?.status === 'FAIL' ? 'bg-rose-950 text-rose-300' : 'bg-zinc-800 text-zinc-400'}`}>{isRunningSandbox ? 'RUNNING' : sandboxResult?.status || 'NOT RUN'}</span>
              {isTestReportExpanded ? <ChevronDown className="h-4 w-4 shrink-0 text-zinc-400" /> : <ChevronRight className="h-4 w-4 shrink-0 text-zinc-400" />}
            </button>
            <button onClick={() => handleRunSandbox('test')} disabled={isRunningSandbox} className="shrink-0 rounded-lg bg-cyan-600 px-2.5 py-1.5 text-[11px] font-bold text-zinc-950 disabled:opacity-50 sm:px-3 sm:text-xs">{isRunningSandbox ? (lang === 'th' ? 'กำลังทดสอบ…' : 'Running…') : (lang === 'th' ? 'รันทดสอบโค้ด' : 'Run tests')}</button>
          </div>
          {isTestReportExpanded && sandboxResult && <div className="mt-2 min-w-0 space-y-1 text-[11px] text-zinc-400"><div className="break-all">SHA-256: <code className="text-zinc-300">{sandboxResult.filesHash || '—'}</code> · {sandboxResult.durationMs || 0} ms · exit {sandboxResult.exitCode}</div><pre className="max-h-28 max-w-full overflow-auto whitespace-pre-wrap break-words rounded bg-zinc-950 p-2 [overflow-wrap:anywhere]">{(sandboxResult.stdout || sandboxResult.stderr || 'No output').slice(-4000)}</pre></div>}
        </section>
        {/* Tab & Actions Switcher */}
        <div className="flex w-full min-w-0 flex-wrap items-center gap-2">
          <div className="flex max-w-full shrink-0 items-center gap-1 overflow-x-auto bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs">
            <button
              type="button"
              onClick={() => setActiveTab('editor')}
              className={`shrink-0 whitespace-nowrap px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'editor'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {lang === 'th' ? 'โค้ดวิวเวอร์' : 'Code Viewer'}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('zip')}
              className={`shrink-0 whitespace-nowrap px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'zip'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {lang === 'th' ? 'ZIP Explorer' : 'ZIP Explorer'}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('proposals')}
              className={`shrink-0 whitespace-nowrap px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'proposals'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Proposals ({proposals.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('sandbox')}
              className={`shrink-0 whitespace-nowrap px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                activeTab === 'sandbox'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>{lang === 'th' ? 'Sandbox Runner' : 'Sandbox Runner'}</span>
            </button>
          </div>

          <label className="shrink-0 whitespace-nowrap px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-xs text-zinc-300 cursor-pointer flex items-center gap-1.5">
            <Upload className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'เปิดไฟล์' : 'Open File'}</span>
            <input type="file" onChange={handleFileUpload} className="hidden" />
          </label>
          <label className="shrink-0 whitespace-nowrap px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-xs text-zinc-300 cursor-pointer flex items-center gap-1.5">
            <Archive className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'เปิด ZIP' : 'Open ZIP'}</span>
            <input type="file" accept=".zip" onChange={handleZipUpload} className="hidden" />
          </label>
          <a
            href="/api/workspace/download-zip"
            download="zyntheor-approved-project.zip"
            className="shrink-0 whitespace-nowrap px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800 hover:bg-emerald-900/80 text-xs text-emerald-300 flex items-center gap-1.5 font-medium transition-all"
            title="ดาวน์โหลดไฟล์โปรเจกต์ที่มีเฉพาะโค้ดที่ผ่านการอนุมัติแล้ว"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'โหลด ZIP' : 'Download ZIP'}</span>
          </a>
        </div>
      </div>

      {proposalMsg && (
        <div className="bg-emerald-950/60 border-b border-emerald-800 text-emerald-300 px-6 py-2 text-xs flex justify-between">
          <span>{proposalMsg}</span>
          <button onClick={() => setProposalMsg(null)} className="font-bold">✕</button>
        </div>
      )}

      {/* Main Workspace */}
      <div className="relative flex min-w-0 flex-1 overflow-hidden">
        {/* Left Sidebar: File Tree */}
        {isNarrowScreen && !isFileTreeCollapsed && <button type="button" aria-label={lang === 'th' ? 'ปิดเมนูไฟล์' : 'Close file menu'} onClick={() => setIsFileTreeCollapsed(true)} className="absolute inset-0 z-20 bg-black/60" />}
        {!isFileTreeCollapsed && <div className={`z-30 flex w-64 max-w-[80vw] shrink-0 flex-col border-r border-zinc-800 bg-zinc-900/95 ${isNarrowScreen ? 'absolute inset-y-0 left-0 shadow-2xl' : 'relative bg-zinc-900/30'}`}>
          <div className="p-3 border-b border-zinc-800 flex items-center justify-between text-xs font-semibold text-zinc-400 uppercase tracking-wider">
            <span>{lang === 'th' ? 'โครงสร้างไฟล์' : 'WORKSPACE FILES'}</span>
            <div className="flex items-center gap-1">
              <button type="button" onClick={() => setIsFileTreeCollapsed(true)} aria-label={lang === 'th' ? 'ปิดแถบเมนูไฟล์' : 'Close file sidebar'} className="rounded p-1 text-zinc-500 hover:text-zinc-200" title={lang === 'th' ? 'ปิดเมนูไฟล์' : 'Close file menu'}>
                <XCircle className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={fetchWorkspaceFiles}
                className="text-zinc-500 hover:text-zinc-300 p-1"
                title="Refresh"
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {files.map((file) => {
              const isSelected = selectedFile === file.name;
              return (
                <button
                  key={file.name}
                  type="button"
                  onClick={() => {
                    loadFile(file.name);
                    setActiveTab('editor');
                    if (isNarrowScreen) setIsFileTreeCollapsed(true);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center gap-2 transition-colors truncate ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 shrink-0 text-cyan-400" />
                  <span className="truncate">{file.name}</span>
                </button>
              );
            })}
          </div>
        </div>}

        {/* Center / Right Content Panel */}
        <div className="relative flex min-w-0 flex-1 flex-col overflow-hidden bg-zinc-950">
          <nav aria-label="Code Studio breadcrumb" className="flex min-w-0 shrink-0 items-center gap-1 overflow-x-auto border-b border-zinc-800 bg-zinc-900/70 px-2 py-2 text-[11px] font-mono text-zinc-400 sm:px-4">
            <button type="button" onClick={() => setIsFileTreeCollapsed((collapsed) => !collapsed)} aria-label={isFileTreeCollapsed ? (lang === 'th' ? 'เปิดแถบเมนูไฟล์' : 'Open file sidebar') : (lang === 'th' ? 'ปิดแถบเมนูไฟล์' : 'Close file sidebar')} aria-expanded={!isFileTreeCollapsed} className="flex shrink-0 items-center gap-1 rounded-md border border-zinc-700 px-2 py-1 font-sans text-[10px] text-zinc-300 hover:border-cyan-600 hover:text-cyan-300" title={isFileTreeCollapsed ? 'แสดงโครงสร้างไฟล์' : 'ซ่อนโครงสร้างไฟล์'}>
              <Folder className="h-3 w-3" />{isFileTreeCollapsed ? (lang === 'th' ? 'ไฟล์' : 'Files') : (lang === 'th' ? 'ซ่อนไฟล์' : 'Hide files')}
            </button>
            <span className="text-cyan-400">{zipArchiveName || 'Workspace'}</span>
            {selectedFile.split('/').map((part, index, parts) => <React.Fragment key={`${part}-${index}`}><ChevronRight className="h-3 w-3 shrink-0 text-zinc-600" /><span className={index === parts.length - 1 ? 'font-semibold text-zinc-100' : 'text-zinc-400'}>{part}</span></React.Fragment>)}
            <span className="ml-auto shrink-0 text-[10px] text-emerald-400">บันทึกตำแหน่งอัตโนมัติ</span>
          </nav>
          {/* TAB 1: CODE EDITOR & VIEWER */}
          {activeTab === 'editor' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Metadata Toolbar */}
              <div className="min-w-0 bg-zinc-900/80 border-b border-zinc-800 px-2 py-2 flex flex-wrap items-center justify-between gap-2 text-xs sm:px-4">
                <div className="flex min-w-0 max-w-full flex-wrap items-center gap-2 sm:gap-3">
                  <span className="max-w-full truncate font-mono font-semibold text-zinc-200">{selectedFile}</span>
                  <span className="text-zinc-500">•</span>
                  <span className="text-zinc-400 font-mono">
                    {fileMeta.lines} {lang === 'th' ? 'บรรทัด' : 'lines'}
                  </span>
                  <span className="text-zinc-500">•</span>
                  <span className="text-zinc-400 font-mono">{fileMeta.size} bytes</span>
                  <span className="text-zinc-500">•</span>
                  <span className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 uppercase text-[10px] font-mono">
                    {fileMeta.type}
                  </span>
                </div>

                <div className="flex min-w-0 flex-1 basis-full items-center gap-2 sm:min-w-[240px] sm:basis-auto">
                  <Search className="h-3.5 w-3.5 text-zinc-500" />
                  <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="ค้นหาในไฟล์ เช่น variable หรือ function" className="w-full rounded-lg border border-zinc-800 bg-zinc-950 px-2.5 py-1.5 text-xs text-zinc-200 outline-none placeholder:text-zinc-600 focus:border-cyan-500" />
                  {searchQuery && <span className="shrink-0 text-[10px] text-amber-300">{lineMatches.size} บรรทัด</span>}
                </div>

                {/* AI Analysis Buttons */}
                <div className="flex max-w-full flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onAnalyzeCode?.('explain', fileContent, selectedFile)}
                    className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    <span>{lang === 'th' ? 'อธิบายโค้ด' : 'Explain'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onAnalyzeCode?.('bugs', fileContent, selectedFile)}
                    className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1"
                  >
                    <Bug className="w-3 h-3 text-amber-400" />
                    <span>{lang === 'th' ? 'ตรวจหาบั๊ก' : 'Bugs'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onAnalyzeCode?.('refactor', fileContent, selectedFile)}
                    className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1"
                  >
                    <Wrench className="w-3 h-3 text-emerald-400" />
                    <span>{lang === 'th' ? 'เสนอปรับปรุง' : 'Refactor'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs flex items-center gap-1"
                    title="Copy code"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <button type="button" onClick={saveVersion} className="px-2.5 py-1 rounded bg-indigo-950/60 border border-indigo-800 text-indigo-300 text-xs">บันทึกรุ่น</button>
                  <button type="button" onClick={() => setShowVersions(!showVersions)} className="px-2.5 py-1 rounded bg-zinc-800 text-zinc-300 text-xs">ประวัติ ({(versionHistory[selectedFile] || []).length})</button>
                  <button type="button" onClick={compareWithAi} className="flex items-center gap-1 rounded bg-amber-950/60 px-2.5 py-1 text-xs text-amber-300"><GitCompare className="h-3 w-3" />เทียบ AI</button>
                </div>
              </div>

              {showVersions && <div className="border-b border-zinc-800 bg-zinc-900/60 p-3 space-y-2"><div className="text-[11px] uppercase font-bold text-zinc-400">Version history · ย้อนกลับได้</div>{(versionHistory[selectedFile] || []).length === 0 ? <div className="text-xs text-zinc-500">ยังไม่มีรุ่นที่บันทึก</div> : (versionHistory[selectedFile] || []).map((version) => <div key={version.id} className="flex items-center justify-between rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-2 text-xs"><span className="text-zinc-400">{new Date(version.createdAt).toLocaleString('th-TH')} · {version.content.length} bytes</span><button onClick={() => compareWithVersion(version)} className="rounded bg-cyan-950/60 px-2 py-1 text-cyan-300">เทียบ</button><button onClick={() => revertVersion(version)} className="rounded bg-amber-950/60 px-2 py-1 text-amber-300">ย้อนกลับ</button></div>)}</div>}

              {/* Prism-highlighted viewer with lightweight brace-based folding */}
              <div className="flex-1 overflow-auto bg-zinc-950 p-4 font-mono text-xs leading-relaxed text-zinc-300">
                <pre className="select-text whitespace-pre">{highlightedLines.map((line) => {
                  if (isHiddenByFold(line.index)) return null;
                  const canFold = line.raw.includes('{') && foldEndFor(line.index) > line.index;
                  const folded = foldedLines.has(line.index);
                  return <div key={line.index} className={`table-row hover:bg-zinc-900/60 ${lineMatches.has(line.index) ? 'bg-amber-500/10' : ''}`}>
                    <button type="button" disabled={!canFold} onClick={() => setFoldedLines((prev) => { const next = new Set(prev); if (next.has(line.index)) next.delete(line.index); else next.add(line.index); return next; })} className={`table-cell w-5 text-left ${canFold ? 'text-zinc-400 hover:text-cyan-300' : 'text-transparent'}`} aria-label={folded ? 'ขยายบล็อก' : 'ย่อบล็อก'}>{folded ? <ChevronRight className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}</button>
                    <span className="table-cell w-10 select-none pr-4 text-right text-zinc-600">{line.index + 1}</span>
                    <code className="table-cell" dangerouslySetInnerHTML={{ __html: folded ? `${line.html} <span class="text-zinc-500"> … }</span>` : line.html }} />
                  </div>;
                })}</pre>
              </div>
              {compareContent !== null && <div className="absolute inset-x-0 bottom-0 top-[108px] z-20 flex bg-zinc-950/95 backdrop-blur-sm">
                <div className="flex min-w-0 flex-1 flex-col border-r border-zinc-700"><div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-900 px-3 py-2 text-xs font-semibold text-cyan-300">ปัจจุบัน · {selectedFile}<button onClick={() => setCompareContent(null)} className="text-zinc-500 hover:text-zinc-200">ปิด</button></div><pre className="flex-1 overflow-auto p-4 text-xs leading-relaxed text-zinc-300">{fileContent}</pre></div>
                <div className="flex min-w-0 flex-1 flex-col"><div className="border-b border-zinc-800 bg-zinc-900 px-3 py-2 text-xs font-semibold text-amber-300">{compareLabel}</div><pre className="flex-1 overflow-auto p-4 text-xs leading-relaxed text-zinc-300">{compareContent}</pre></div>
              </div>}
            </div>
          )}

          {/* TAB 2: ZIP ARCHIVE EXPLORER */}
          {activeTab === 'zip' && (
            <div className="flex-1 flex flex-col p-6 overflow-y-auto">
              <div className="mb-4">
                <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                  <Archive className="w-4 h-4 text-cyan-400" />
                  <span>ZIP Archive: {zipArchiveName || 'No archive opened'}</span>
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {lang === 'th'
                    ? 'โครงสร้างและขนาดของไฟล์ที่ถูกบรรจุใน ZIP พร้อมอัตราการบีบอัด'
                    : 'Inspected file entries, uncompressed sizes, and compression details'}
                </p>
              </div>

              {zipEntries.length > 0 ? (
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-zinc-850 border-b border-zinc-800 text-zinc-400 font-mono">
                      <tr>
                        <th className="p-3">File Path</th>
                        <th className="p-3">Uncompressed</th>
                        <th className="p-3">Compressed</th>
                        <th className="p-3">Type</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800 font-mono">
                      {zipEntries.map((e, i) => (
                        <tr key={i} className="hover:bg-zinc-850/50">
                          <td className="p-3 text-cyan-300 flex items-center gap-2">
                            {e.isDir ? <Folder className="w-3.5 h-3.5 text-amber-400" /> : <FileText className="w-3.5 h-3.5 text-zinc-400" />}
                            <span>{e.path}</span>
                          </td>
                          <td className="p-3 text-zinc-300">{e.size} bytes</td>
                          <td className="p-3 text-zinc-400">{e.compressedSize} bytes</td>
                          <td className="p-3 text-zinc-500 uppercase">{e.isDir ? 'DIR' : 'FILE'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-16 text-zinc-500">
                  <Archive className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p className="text-xs">
                    {lang === 'th' ? 'อัปโหลดไฟล์ ZIP ด้านบนเพื่อเริ่มตรวจสอบ' : 'Upload a ZIP archive to inspect contents'}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: FILE PROPOSALS & DIFFS */}
          {activeTab === 'proposals' && (
            <div className="flex-1 flex flex-col p-6 overflow-y-auto space-y-4">
              <div>
                <h3 className="text-sm font-bold text-zinc-100">
                  {lang === 'th' ? 'ข้อเสนอการเปลี่ยนแปลงไฟล์ (File Proposals)' : 'Active File Proposals'}
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {lang === 'th'
                    ? 'การปรับแก้ไฟล์ต้องผ่านการอนุมัติก่อนเขียนลง Workspace (ป้องกัน Direct Overwrite โดยไม่ตรวจสอบ)'
                    : 'File proposals require explicit cryptographic approval before applied to the workspace.'}
                </p>
              </div>

              <div className="flex flex-wrap gap-2 mb-3">
                <button
                  type="button"
                  onClick={handleUndoLastApply}
                  disabled={undoStack.length === 0}
                  className="inline-flex items-center gap-1.5 min-h-[44px] px-3 rounded-lg text-xs font-semibold border border-amber-500/40 text-amber-300 bg-amber-500/10 disabled:opacity-40"
                  title="ย้อนการ Apply ล่าสุด"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Undo ล่าสุด {undoStack.length > 0 ? `(${undoStack[0].name})` : ''}
                </button>
              </div>
              {proposals.map((prop) => (
                <div
                  key={prop.id}
                  className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-cyan-300">{prop.name}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded uppercase font-mono bg-zinc-800 text-zinc-300">
                        {prop.type}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded uppercase font-mono bg-amber-950 text-amber-400 border border-amber-800">
                        Risk: {prop.riskLevel}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-zinc-400">Status: {prop.status}</span>
                      {prop.status === 'WAITING_APPROVAL' && (
                        <button
                          type="button"
                          onClick={() => handleApproveProposal(prop)}
                          className="px-3 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold text-xs"
                        >
                          {lang === 'th' ? 'อนุมัติข้อเสนอ' : 'Approve'}
                        </button>
                      )}
                      {prop.status === 'APPROVED' && (
                        <button
                          type="button"
                          onClick={() => handleApplyProposal(prop)}
                          className="px-3 py-1 rounded bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs"
                        >
                          {lang === 'th' ? 'นำไปใช้ (Apply to Workspace)' : 'Apply Changes'}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Diff Viewer */}
                  <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 font-mono text-xs overflow-x-auto text-zinc-300">
                    <pre>{prop.diff || '// No diff content available'}</pre>
                  </div>
                </div>
              ))}

              {proposals.length === 0 && (
                <div className="text-center py-16 text-zinc-500">
                  <CheckCircle2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p className="text-xs">
                    {lang === 'th' ? 'ไม่มีข้อเสนอที่รอการอนุมัติในขณะนี้' : 'No active file proposals pending approval'}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SANDBOX COMMAND RUNNER & TESTS (เฟส 4) */}
          {activeTab === 'sandbox' && (
            <div className="flex-1 flex flex-col p-6 overflow-y-auto space-y-5">
              {/* Header & Isolation Highlights */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                      <Terminal className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                        <span>{lang === 'th' ? 'Sandbox Runner & Test Engine (เฟส 4)' : 'Sandbox Runner & Verification'}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded uppercase font-mono bg-amber-950 text-amber-300 border border-amber-800">
                          Active Sandbox
                        </span>
                      </h3>
                      <p className="text-xs text-zinc-400 mt-0.5">
                        {lang === 'th'
                          ? 'รันคำสั่งทดสอบจริงในสภาพแวดล้อมแยก ปิดเครือข่าย ล้าง env และผูกผลลัพธ์กับ Files Hash'
                          : 'Real sandboxed test execution with network namespace isolation and clean environment'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href="/api/workspace/download-zip"
                      download="zyntheor-approved-project.zip"
                      className="px-3 py-1.5 rounded-lg bg-emerald-950/70 border border-emerald-800 hover:bg-emerald-900 text-xs text-emerald-300 flex items-center gap-1.5 font-medium transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{lang === 'th' ? 'ดาวน์โหลด ZIP โครงการ' : 'Download Approved ZIP'}</span>
                    </a>
                  </div>
                </div>

                {/* 5 Security Shields */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-2 border-t border-zinc-800/80 text-[11px] font-mono">
                  <div className="flex items-center gap-1.5 text-zinc-300 bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/50">
                    <Cpu className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span className="truncate">Child Process Isolated</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-zinc-300 bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/50">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">Network Isolated (unshare -n)</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-zinc-300 bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/50">
                    <Shield className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="truncate">Clean Env (Secrets Redacted)</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-zinc-300 bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/50">
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="truncate">10s Timeout / 64KB Cap</span>
                  </div>
                </div>
              </div>

              {/* Task Selector & Run Control */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4">
                <div className="text-xs font-semibold text-zinc-300">
                  {lang === 'th' ? 'เลือกประเภทงานที่อนุญาต (Allowlisted Tasks Only):' : 'Select Allowlisted Task Type:'}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2.5">
                  {[
                    { id: 'syntax_check', label: 'Syntax Check', desc: 'node --check (ตรวจไวยากรณ์)', icon: '🔍' },
                    { id: 'typecheck', label: 'TypeScript Types', desc: 'tsc --noEmit (ตรวจไทป์)', icon: '📐' },
                    { id: 'test', label: 'Run Tests', desc: 'node --test (รันชุดทดสอบ)', icon: '🧪' },
                    { id: 'build', label: 'Build Validation', desc: 'Validate bundle & manifest', icon: '📦' },
                    { id: 'install_deps', label: 'Install Deps', desc: 'npm install (BLOCKED by default)', icon: '🚫' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setSelectedTask(t.id as any)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        selectedTask === t.id
                          ? 'bg-amber-500/20 border-amber-500/60 text-amber-200 shadow-sm'
                          : 'bg-zinc-950 border-zinc-800 hover:border-zinc-700 text-zinc-400'
                      }`}
                    >
                      <div className="text-base mb-1">{t.icon}</div>
                      <div className="font-semibold text-xs text-zinc-200">{t.label}</div>
                      <div className="text-[10px] text-zinc-500 mt-0.5 leading-snug">{t.desc}</div>
                    </button>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-zinc-400">
                    {lang === 'th'
                      ? 'คำสั่งจะรันบนโค้ดที่ได้รับการอนุมัติในโฟลเดอร์ชั่วคราวและบันทึกผลเข้า Audit Ledger'
                      : 'Executes within ephemeral temp dir on approved workspace files.'}
                  </div>

                  <button
                    type="button"
                    disabled={isRunningSandbox}
                    onClick={() => handleRunSandbox()}
                    className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-amber-900/30 transition-all cursor-pointer"
                  >
                    {isRunningSandbox ? (
                      <>
                        <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                        <span>{lang === 'th' ? 'กำลังทดสอบใน Sandbox...' : 'Running in Sandbox...'}</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-white" />
                        <span>{lang === 'th' ? `รันงาน "${selectedTask}"` : `Run Task "${selectedTask}"`}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Execution Result Display */}
              {sandboxResult && (
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4 animate-in fade-in duration-150">
                  {/* Status Banner */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
                    <div className="flex items-center gap-3">
                      <div
                        className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-2 border ${
                          sandboxResult.status === 'VERIFIED'
                            ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
                            : sandboxResult.status === 'FAIL'
                            ? 'bg-rose-950/80 text-rose-300 border-rose-700'
                            : 'bg-amber-950/80 text-amber-300 border-amber-700'
                        }`}
                      >
                        {sandboxResult.status === 'VERIFIED' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                        {sandboxResult.status === 'FAIL' && <XCircle className="w-4 h-4 text-rose-400" />}
                        {sandboxResult.status === 'BLOCKED' && <ShieldAlert className="w-4 h-4 text-amber-400" />}
                        <span>สถานะ: {sandboxResult.status}</span>
                      </div>

                      <div className="text-xs text-zinc-400">
                        {sandboxResult.reason && <span>เหตุผล: {sandboxResult.reason}</span>}
                      </div>
                    </div>

                    {/* ONE-CLICK SEND RESULT TO CHAT BUTTON */}
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleSendToChat}
                        className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                        title="ส่งผลลัพธ์การทดสอบนี้กลับเข้าไปยังบทสนทนาใน ONE CHAT โดยตรง"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{lang === 'th' ? 'ส่งผลกลับเข้า ONE CHAT (คลิกเดียว)' : 'Send to ONE CHAT'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Metadata Chips */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
                    <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Command:</span>
                      <span className="text-zinc-300 truncate block">{(sandboxResult.command || []).join(' ')}</span>
                    </div>
                    <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Files Hash (SHA-256):</span>
                      <span className="text-cyan-400 truncate block font-bold" title={sandboxResult.filesHash}>
                        {(sandboxResult.filesHash || '').slice(0, 16)}...
                      </span>
                    </div>
                    <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Duration:</span>
                      <span className="text-zinc-300">{sandboxResult.durationMs} ms</span>
                    </div>
                    <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Network Isolated:</span>
                      <span className="text-emerald-400 font-semibold">
                        {sandboxResult.networkIsolated ? '✓ Linux unshare -n' : '✗ None'}
                      </span>
                    </div>
                  </div>

                  {/* Terminal Console Output */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-zinc-400">
                      <span>Console / Test Output:</span>
                      {sandboxResult.truncated && <span className="text-amber-400 text-[10px]">* Output truncated at 64KB</span>}
                    </div>
                    <div className="bg-black/90 border border-zinc-800 rounded-lg p-3.5 font-mono text-xs text-zinc-200 overflow-x-auto max-h-72 overflow-y-auto leading-relaxed select-text">
                      <pre className="whitespace-pre-wrap">
                        {sandboxResult.stdout || sandboxResult.stderr || '// No output produced from command.'}
                      </pre>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
