import React, { useState, useEffect } from 'react';
import {
  Folder,
  Plus,
  Search,
  ExternalLink,
  Code2,
  Smartphone,
  Globe,
  Trash2,
  Download,
  Calendar,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  X,
} from 'lucide-react';

export interface ProjectItem {
  id: string;
  name: string;
  type: 'Web App' | 'Mobile App' | 'AI Assistant' | 'Backend API';
  description: string;
  updatedAt: string;
  status: 'พร้อมใช้งาน' | 'กำลังพัฒนา' | 'กำลังทดสอบ';
  filesCount: number;
}

// No seeded sample projects: the list only shows projects the user created.
const DEFAULT_PROJECTS: ProjectItem[] = [];

interface ProjectsViewProps {
  onOpenProjectInBuild?: (project: ProjectItem) => void;
  lang?: 'en' | 'th';
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  onOpenProjectInBuild,
  lang = 'th',
}) => {
  const [projects, setProjects] = useState<ProjectItem[]>(() => {
    try {
      const saved = localStorage.getItem('zyntheor_user_projects');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_PROJECTS;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectType, setNewProjectType] = useState<'Web App' | 'Mobile App' | 'Backend API'>('Web App');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [notice, setNotice] = useState('');

  const saveProjects = (list: ProjectItem[]) => {
    setProjects(list);
    try {
      localStorage.setItem('zyntheor_user_projects', JSON.stringify(list));
    } catch {}
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newProjectName.trim();
    if (!trimmed) return;

    const newProj: ProjectItem = {
      id: `proj-${Date.now()}`,
      name: trimmed.toLowerCase().replace(/[^a-z0-9_-]/g, '-'),
      type: newProjectType,
      description: newProjectDesc.trim() || `โปรเจกต์ ${newProjectType} ที่สร้างด้วย ZYNTHEOR AI ENGINE`,
      updatedAt: 'เมื่อสักครู่',
      status: 'กำลังพัฒนา',
      filesCount: newProjectType === 'Mobile App' ? 16 : 12,
    };

    const updated = [newProj, ...projects];
    saveProjects(updated);
    setIsCreateModalOpen(false);
    setNewProjectName('');
    setNewProjectDesc('');
    setNotice(`สร้างโปรเจกต์ "${newProj.name}" สำเร็จเรียบร้อยแล้ว`);
    setTimeout(() => setNotice(''), 3500);
  };

  const handleDeleteProject = (id: string, name: string) => {
    const updated = projects.filter((p) => p.id !== id);
    saveProjects(updated);
    setNotice(`ลบโปรเจกต์ "${name}" แล้ว`);
    setTimeout(() => setNotice(''), 3000);
  };

  const filteredProjects = projects.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full bg-[#050C1B] overflow-y-auto text-slate-200 p-4 lg:p-8">
      <div className="max-w-6xl mx-auto w-full space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-cyan-500/20">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
              <Folder size={24} className="text-cyan-400" />
              <span>Projects</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              จัดการโครงการของคุณ • พัฒนาเว็บแอปและแอปมือถือด้วย AI
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-medium text-xs sm:text-sm shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all cursor-pointer shrink-0"
            aria-label="สร้างโปรเจกต์ใหม่"
          >
            <Plus size={16} />
            <span>สร้างโปรเจกต์ใหม่</span>
          </button>
        </div>

        {/* Notice Banner */}
        {notice && (
          <div className="px-4 py-2.5 rounded-xl bg-cyan-950/70 border border-cyan-500/40 text-cyan-200 text-xs flex items-center justify-between animate-in fade-in">
            <span className="flex items-center gap-2">
              <CheckCircle2 size={15} className="text-cyan-400" />
              {notice}
            </span>
            <button onClick={() => setNotice('')} className="text-slate-400 hover:text-white">
              <X size={14} />
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-3 text-slate-500" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ค้นหาโปรเจกต์..."
            aria-label="ค้นหาโปรเจกต์"
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#091534]/80 border border-slate-800 text-slate-200 placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-cyan-400 transition-colors"
          />
        </div>

        {/* Projects Table / Grid */}
        <div className="rounded-2xl border border-cyan-500/20 bg-[#08132d]/70 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="border-b border-slate-800 bg-[#060e22]/90 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4 sm:px-6">ชื่อโปรเจกต์</th>
                  <th className="py-3 px-4">ประเภท</th>
                  <th className="py-3 px-4">อัปเดตล่าสุด</th>
                  <th className="py-3 px-4">สถานะ</th>
                  <th className="py-3 px-4 sm:px-6 text-right">การกระทำ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredProjects.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-500 text-xs">
                      ไม่พบโปรเจกต์ที่ตรงกับคำค้นหา
                    </td>
                  </tr>
                ) : (
                  filteredProjects.map((p) => {
                    const isMobile = p.type === 'Mobile App';
                    return (
                      <tr
                        key={p.id}
                        className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                        onClick={() => onOpenProjectInBuild && onOpenProjectInBuild(p)}
                      >
                        <td className="py-4 px-4 sm:px-6">
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                                isMobile
                                  ? 'bg-amber-950/70 border border-amber-500/40 text-amber-300'
                                  : 'bg-cyan-950/70 border border-cyan-500/40 text-cyan-300'
                              }`}
                            >
                              {isMobile ? <Smartphone size={18} /> : <Code2 size={18} />}
                            </div>
                            <div className="min-w-0">
                              <div className="font-semibold text-white group-hover:text-cyan-300 transition-colors flex items-center gap-2">
                                <span>{p.name}</span>
                                <span className="text-[10px] text-slate-500 font-mono">({p.filesCount} files)</span>
                              </div>
                              <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{p.description}</p>
                            </div>
                          </div>
                        </td>

                        <td className="py-4 px-4">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium border ${
                              isMobile
                                ? 'bg-amber-950/40 text-amber-300 border-amber-500/30'
                                : 'bg-cyan-950/40 text-cyan-300 border-cyan-500/30'
                            }`}
                          >
                            {isMobile ? <Smartphone size={12} /> : <Globe size={12} />}
                            <span>{p.type}</span>
                          </span>
                        </td>

                        <td className="py-4 px-4 text-slate-400 font-mono text-xs">
                          {p.updatedAt}
                        </td>

                        <td className="py-4 px-4">
                          <span className="inline-flex items-center gap-1.5 text-xs">
                            <span
                              className={`w-2 h-2 rounded-full ${
                                p.status === 'พร้อมใช้งาน'
                                  ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.6)]'
                                  : 'bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.6)]'
                              }`}
                            />
                            <span className={p.status === 'พร้อมใช้งาน' ? 'text-emerald-300' : 'text-cyan-300'}>
                              {p.status}
                            </span>
                          </span>
                        </td>

                        <td className="py-4 px-4 sm:px-6 text-right">
                          <div
                            className="flex items-center justify-end gap-2"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <button
                              type="button"
                              onClick={() => onOpenProjectInBuild && onOpenProjectInBuild(p)}
                              className="px-3 py-1.5 rounded-lg bg-cyan-600/30 hover:bg-cyan-600 text-cyan-200 hover:text-white border border-cyan-500/40 text-xs font-medium transition-colors"
                              title="เปิดโปรเจกต์ในหน้า Build"
                              aria-label={`เปิดโปรเจกต์ ${p.name}`}
                            >
                              เปิดโค้ด
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteProject(p.id, p.name)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                              title="ลบโปรเจกต์"
                              aria-label={`ลบโปรเจกต์ ${p.name}`}
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Create Project Modal */}
      {isCreateModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="สร้างโปรเจกต์ใหม่"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
        >
          <div className="w-full max-w-md rounded-2xl border border-cyan-500/30 bg-[#091534] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-white font-bold text-base">
                <Folder size={18} className="text-cyan-400" />
                <span>สร้างโปรเจกต์ใหม่</span>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
                aria-label="ปิดหน้าต่าง"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateProject} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">ชื่อโปรเจกต์</label>
                <input
                  type="text"
                  required
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  placeholder="เช่น dashboard-app, store-mobile"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-400"
                  autoFocus
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">ประเภทโปรเจกต์</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewProjectType('Web App')}
                    className={`p-2.5 rounded-xl border text-left text-xs transition-colors flex items-center gap-2 ${
                      newProjectType === 'Web App'
                        ? 'bg-cyan-950/60 border-cyan-400 text-white shadow-sm'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Globe size={16} className="text-cyan-400" />
                    <div>
                      <div className="font-semibold">Web App</div>
                      <div className="text-[10px] text-slate-500">React + Vite + Tailwind</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setNewProjectType('Mobile App')}
                    className={`p-2.5 rounded-xl border text-left text-xs transition-colors flex items-center gap-2 ${
                      newProjectType === 'Mobile App'
                        ? 'bg-amber-950/60 border-amber-400 text-white shadow-sm'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Smartphone size={16} className="text-amber-400" />
                    <div>
                      <div className="font-semibold">Mobile App</div>
                      <div className="text-[10px] text-slate-500">Capacitor iOS/Android</div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">รายละเอียด (ทางเลือก)</label>
                <textarea
                  value={newProjectDesc}
                  onChange={(e) => setNewProjectDesc(e.target.value)}
                  rows={2}
                  placeholder="ระบุวัตถุประสงค์ของโปรเจกต์นี้..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-400 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3 py-2 rounded-xl text-slate-400 hover:text-white text-xs transition-colors"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-medium text-xs shadow-md transition-all cursor-pointer"
                >
                  ยืนยันสร้างโปรเจกต์
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
