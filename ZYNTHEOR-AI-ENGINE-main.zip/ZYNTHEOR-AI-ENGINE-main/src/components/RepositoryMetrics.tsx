import React, { useState, useEffect, useCallback } from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  GitCommit,
  Clock,
  CheckCircle2,
  RefreshCw,
  GitPullRequest,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import {
  fetchRepositoryMetrics,
  type RepositoryMetricsData,
} from '../utils/githubService';

interface RepositoryMetricsProps {
  repoFullName: string;
  repositoryData?: RepositoryMetricsData;
  lang?: 'en' | 'th';
  compact?: boolean;
}

export const RepositoryMetrics: React.FC<RepositoryMetricsProps> = ({
  repoFullName,
  repositoryData,
  lang = 'th',
  compact = false,
}) => {
  const th = lang === 'th';
  const [owner = '', repo = ''] = repoFullName.split('/');
  const [metrics, setMetrics] = useState<RepositoryMetricsData | null>(repositoryData ?? null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchRepositoryMetrics(repoFullName);
      setMetrics(data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to fetch repository metrics');
    } finally {
      setLoading(false);
    }
  }, [repoFullName]);

  useEffect(() => {
    if (repositoryData) {
      setMetrics(repositoryData);
      setError(null);
      setLoading(false);
      return;
    }
    void loadData();
  }, [loadData, repositoryData]);

  const commitFrequencyData = metrics?.weeklyCommits ?? [];
  const issueResolutionData = metrics?.issueResolutions ?? [];

  return (
    <div className="space-y-6 text-zinc-100">
      {/* Header & Repository Selector Bar */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <TrendingUp className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold flex items-center gap-2">
                {th ? 'เมตริกการพัฒนาคลังโค้ด GitHub' : 'GitHub Repository Analytics & Metrics'}
                <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  {metrics?.source === 'api' ? 'Live GitHub API' : 'Cached / Verified'}
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                {th
                  ? `วิเคราะห์ความถี่ Commit รายสัปดาห์ และระยะเวลาแก้ไข Issue ของ ${owner}/${repo}`
                  : `Tracking weekly commit frequency & average issue resolution duration for ${owner}/${repo}`}
              </p>
            </div>
          </div>
        </div>

        <div>
          <button
            type="button"
            onClick={() => void loadData()}
            disabled={loading}
            title={th ? 'รีเฟรชข้อมูล' : 'Refresh'}
            aria-label={th ? 'รีเฟรชข้อมูล' : 'Refresh repository metrics'}
            className="p-1.5 rounded-lg border border-zinc-700 hover:border-zinc-500 text-zinc-300 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-400' : ''}`} />
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Summary KPI Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Commits */}
        <div className="bg-zinc-900 border border-zinc-800/80 rounded-2xl p-4 shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium">
              {th ? 'Commits ทั้งหมดที่ตรวจวัด' : 'Monitored Commits'}
            </span>
            <div className="text-2xl font-black text-blue-400 mt-1 font-mono">
              {metrics ? metrics.totalCommits.toLocaleString() : '—'}
            </div>
            <span className="text-[11px] text-zinc-500 mt-0.5 block">
              {th ? 'ในช่วง 8 สัปดาห์ล่าสุด' : 'Across 8 recent weeks'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <GitCommit className="w-6 h-6" />
          </div>
        </div>

        {/* Card 2: Avg Issue Resolution Time */}
        <div className="bg-zinc-900 border border-zinc-800/80 rounded-2xl p-4 shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium">
              {th ? 'ระยะเวลาปิด Issue เฉลี่ย' : 'Avg Resolution Time'}
            </span>
            <div className="text-2xl font-black text-emerald-400 mt-1 font-mono">
              {metrics ? `${metrics.avgResolutionDays} ${th ? 'วัน' : 'days'}` : '—'}
            </div>
            <span className="text-[11px] text-zinc-500 mt-0.5 block">
              {metrics ? `~${(metrics.avgResolutionDays * 24).toFixed(0)} ชั่วโมงโดยเฉลี่ย` : '—'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        {/* Card 3: Closed Issues Analyzed */}
        <div className="bg-zinc-900 border border-zinc-800/80 rounded-2xl p-4 shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium">
              {th ? 'Issues ที่ปิดแล้วที่วิเคราะห์' : 'Closed Issues Analyzed'}
            </span>
            <div className="text-2xl font-black text-amber-400 mt-1 font-mono">
              {metrics ? metrics.closedIssuesCount : '—'}
            </div>
            <span className="text-[11px] text-zinc-500 mt-0.5 block">
              {th ? 'สกัดจาก GitHub REST API' : 'From GitHub REST API'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        {/* Card 4: Integrity Status */}
        <div className="bg-zinc-900 border border-zinc-800/80 rounded-2xl p-4 shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[11px] uppercase tracking-wider text-zinc-400 font-medium">
              {th ? 'ความสมบูรณ์ของข้อมูล' : 'Data Integrity'}
            </span>
            <div className="text-2xl font-black text-amber-300 mt-1 font-mono">
              UNKNOWN
            </div>
            <span className="text-[11px] text-zinc-500 mt-0.5 block">
              {th ? 'ยังไม่มีการตรวจความสมบูรณ์ของข้อมูลที่ยืนยันได้' : 'No verified integrity check exists'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Charts Section */}
      <div className={`grid grid-cols-1 ${compact ? 'lg:grid-cols-1' : 'lg:grid-cols-2'} gap-6`}>
        {/* Chart 1: LineChart for Weekly Commit Activity */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
              <h3 className="text-sm font-bold text-zinc-100">
                {th ? 'ความถี่ของ Commit รายสัปดาห์ (Weekly Commit Activity)' : 'Weekly Commit Activity (Frequency)'}
              </h3>
            </div>
            <span className="text-[11px] font-mono text-zinc-400">
              {th ? '8 สัปดาห์ล่าสุด' : 'Last 8 Weeks'}
            </span>
          </div>

          <div className="h-64 w-full">
            {commitFrequencyData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={commitFrequencyData}
                  margin={{ top: 10, right: 20, left: -10, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis
                    dataKey="week"
                    stroke="#71717a"
                    fontSize={11}
                    tickLine={false}
                  />
                  <YAxis
                    stroke="#71717a"
                    fontSize={11}
                    tickLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#18181b',
                      borderColor: '#3f3f46',
                      borderRadius: '0.75rem',
                      color: '#f4f4f5',
                      fontSize: '12px',
                    }}
                    labelFormatter={(val) => `สัปดาห์: ${val}`}
                    formatter={(val: any) => [`${val} commits`, th ? 'จำนวน Commit' : 'Commits']}
                  />
                  <Legend
                    verticalAlign="top"
                    align="right"
                    wrapperStyle={{ fontSize: '11px', paddingBottom: '8px' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="commits"
                    name={th ? 'จำนวน Commit' : 'Commits'}
                    stroke="#3b82f6"
                    strokeWidth={2.5}
                    dot={{ fill: '#1d4ed8', stroke: '#60a5fa', strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, fill: '#93c5fd' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-zinc-500 text-xs">
                {loading ? (th ? 'กำลังโหลดข้อมูล...' : 'Loading...') : (th ? 'ไม่พบข้อมูล' : 'No data')}
              </div>
            )}
          </div>
          <div className="text-[11px] text-zinc-400 flex items-center justify-between">
            <span>{th ? 'แหล่งข้อมูล: GitHub API (/stats/commit_activity)' : 'Source: GitHub API (/stats/commit_activity)'}</span>
            <span className="text-blue-400 font-mono">
              {th ? 'อัตราเร็วเฉลี่ย: ' : 'Velocity: '}
              {metrics ? Math.round(metrics.totalCommits / (metrics.weeklyCommits.length || 8)) : 0} commits/wk
            </span>
          </div>
        </div>

        {/* Chart 2: BarChart for Average Issue Resolution Duration */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <h3 className="text-sm font-bold text-zinc-100">
                {th ? 'ระยะเวลาเฉลี่ยในการปิด Issue (Avg Issue Resolution Duration)' : 'Average Issue Resolution Duration'}
              </h3>
            </div>
            <span className="text-[11px] font-mono text-zinc-400">
              {th ? 'หน่วย: วัน (Days)' : 'Unit: Days'}
            </span>
          </div>

          <div className="h-64 w-full">
            {issueResolutionData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={issueResolutionData}
                  margin={{ top: 10, right: 20, left: -10, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis
                    dataKey="category"
                    stroke="#71717a"
                    fontSize={10.5}
                    tickLine={false}
                    interval={0}
                  />
                  <YAxis
                    stroke="#71717a"
                    fontSize={11}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#18181b',
                      borderColor: '#3f3f46',
                      borderRadius: '0.75rem',
                      color: '#f4f4f5',
                      fontSize: '12px',
                    }}
                    formatter={(val: any, name: any, item: any) => [
                      `${val} วัน (${(val * 24).toFixed(0)} ชั่วโมง) · ${item.payload.count} issues`,
                      th ? 'ระยะเวลาปิดงานเฉลี่ย' : 'Avg Duration',
                    ]}
                  />
                  <Legend
                    verticalAlign="top"
                    align="right"
                    wrapperStyle={{ fontSize: '11px', paddingBottom: '8px' }}
                  />
                  <Bar
                    dataKey="avgDurationDays"
                    name={th ? 'ระยะเวลาเฉลี่ย (วัน)' : 'Avg Days'}
                    fill="#10b981"
                    radius={[6, 6, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-zinc-500 text-xs">
                {loading ? (th ? 'กำลังโหลดข้อมูล...' : 'Loading...') : (th ? 'ไม่พบข้อมูล' : 'No data')}
              </div>
            )}
          </div>
          <div className="text-[11px] text-zinc-400 flex items-center justify-between">
            <span>{th ? 'หมวดหมู่: จัดกลุ่มตาม Labels และประเภทคำร้อง' : 'Categories: Grouped by GitHub Labels & Issues'}</span>
            <span className="text-emerald-400 font-mono">
              {th ? 'เป้าหมาย SLA: ≤ 3.0 วัน' : 'SLA Target: ≤ 3.0 Days'}
            </span>
          </div>
        </div>
      </div>

      {/* Analytics Summary Table / Breakdown */}
      {metrics && issueResolutionData.length > 0 && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-4 bg-zinc-850/60 border-b border-zinc-800 flex items-center justify-between">
            <h4 className="text-xs font-bold text-zinc-200">
              {th ? 'สรุปรายละเอียดระยะเวลาแก้ไขปัญหาตามหมวดหมู่ (Issue Resolution Breakdown)' : 'Issue Resolution Duration Breakdown'}
            </h4>
            <a
              href={`https://github.com/${owner}/${repo}/issues?q=is%3Aissue+is%3Aclosed`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium"
            >
              <span>{th ? 'เปิดดูใน GitHub' : 'View on GitHub'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-zinc-950 text-zinc-400 border-b border-zinc-800">
              <tr>
                <th className="p-3">{th ? 'หมวดหมู่ (Category)' : 'Category'}</th>
                <th className="p-3">{th ? 'ระยะเวลาเฉลี่ย (วัน)' : 'Avg Days'}</th>
                <th className="p-3">{th ? 'ระยะเวลาเฉลี่ย (ชม.)' : 'Avg Hours'}</th>
                <th className="p-3">{th ? 'จำนวน Issue ที่วิเคราะห์' : 'Closed Issues Count'}</th>
                <th className="p-3">{th ? 'สถานะ SLA' : 'SLA Status'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80">
              {issueResolutionData.map((row) => (
                <tr key={row.category} className="hover:bg-zinc-800/40 transition-colors">
                  <td className="p-3 font-semibold text-zinc-200">{row.category}</td>
                  <td className="p-3 text-emerald-400 font-bold">{row.avgDurationDays} วัน</td>
                  <td className="p-3 text-zinc-300">{row.avgDurationHours} ชม.</td>
                  <td className="p-3 text-amber-300">{row.count} รายการ</td>
                  <td className="p-3">
                    {row.avgDurationDays <= 3.0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        ✓ Passed SLA
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/30">
                        ⚡ Extended Review
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
