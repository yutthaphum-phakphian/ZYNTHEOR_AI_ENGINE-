import React, { useState, useEffect } from 'react';
import { Globe2, ExternalLink, ShieldCheck } from 'lucide-react';
import type { UrlMetadata } from '../types/urlMetadata';

interface UrlPreviewCardProps {
  url: string;
  onOpenSafeRedirect?: (url: string) => void;
}

export const UrlPreviewCard: React.FC<UrlPreviewCardProps> = ({ url, onOpenSafeRedirect }) => {
  const [metadata, setMetadata] = useState<UrlMetadata | null>(null);
  const [loading, setLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    let isCancelled = false;
    setLoading(true);

    fetch(`/api/url-metadata?url=${encodeURIComponent(url)}`)
      .then((res) => res.json())
      .then((data: UrlMetadata) => {
        if (!isCancelled) {
          setMetadata(data);
        }
      })
      .catch(() => {
        if (!isCancelled) {
          let domain = 'external-link';
          try {
            domain = new URL(url).hostname;
          } catch {}
          setMetadata({
            url,
            domain,
            title: domain,
            description: null,
            image: null,
            status: 'FALLBACK',
          });
        }
      })
      .finally(() => {
        if (!isCancelled) setLoading(false);
      });

    return () => {
      isCancelled = true;
    };
  }, [url]);

  let domain = 'link';
  try {
    domain = new URL(url).hostname;
  } catch {}

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onOpenSafeRedirect) {
      onOpenSafeRedirect(url);
    } else {
      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  if (loading) {
    return (
      <div className="my-2.5 max-w-md rounded-xl border border-cyan-500/20 bg-slate-900/60 p-3 animate-pulse space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-3.5 h-3.5 rounded bg-slate-700" />
          <div className="w-24 h-3 rounded bg-slate-700" />
        </div>
        <div className="w-3/4 h-3.5 rounded bg-slate-700" />
        <div className="w-full h-2.5 rounded bg-slate-800" />
      </div>
    );
  }

  if (!metadata || metadata.status === 'BLOCKED') {
    return null;
  }

  const hasImage = !!metadata.image && !imageError;

  return (
    <div
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleClick(e as any);
        }
      }}
      aria-label={`พรีวิวลิงก์: ${metadata.title || domain} (คลิกเพื่อยืนยันการเปิดลิงก์ภายนอก)`}
      className="my-2.5 max-w-md rounded-xl border border-cyan-500/30 bg-[#07132e]/80 hover:bg-[#0b1c40] hover:border-cyan-400/60 shadow-md transition-all cursor-pointer overflow-hidden group select-none text-left"
    >
      {/* Visual Preview Image Banner */}
      {hasImage && (
        <div className="w-full h-36 bg-slate-950 overflow-hidden relative border-b border-slate-800">
          <img
            src={metadata.image!}
            alt={metadata.title || 'URL preview'}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={() => setImageError(true)}
          />
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-xs text-[10px] text-cyan-300 font-mono flex items-center gap-1 border border-white/10">
            {metadata.favicon ? (
              <img src={metadata.favicon} alt="" className="w-3 h-3 rounded-xs shrink-0" onError={(e) => { (e.currentTarget as HTMLElement).style.display = 'none'; }} />
            ) : (
              <Globe2 size={10} />
            )}
            <span className="truncate max-w-[160px]">{domain}</span>
          </div>
        </div>
      )}

      {/* Content Details */}
      <div className="p-3 space-y-1.5">
        {!hasImage && (
          <div className="flex items-center gap-1.5 text-[11px] text-cyan-400/90 font-mono">
            {metadata.favicon ? (
              <img src={metadata.favicon} alt="" className="w-3.5 h-3.5 rounded-xs shrink-0" onError={(e) => { (e.currentTarget as HTMLElement).style.display = 'none'; }} />
            ) : (
              <Globe2 size={12} />
            )}
            <span className="truncate font-semibold">{domain}</span>
          </div>
        )}

        <h4 className="text-xs font-bold text-slate-100 group-hover:text-cyan-300 transition-colors line-clamp-1 leading-snug">
          {metadata.title || domain}
        </h4>

        {metadata.description && (
          <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed font-sans">
            {metadata.description}
          </p>
        )}

        {/* Footer with Safe Navigation Badge */}
        <div className="pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
          <span className="flex items-center gap-1 text-emerald-400/90">
            <ShieldCheck size={11} />
            <span>Safe Redirect Protected</span>
          </span>
          <span className="flex items-center gap-1 text-cyan-400 group-hover:translate-x-0.5 transition-transform">
            <span>คลิกเพื่อเปิด</span>
            <ExternalLink size={10} />
          </span>
        </div>
      </div>
    </div>
  );
};
