import React, { useState, useEffect, useCallback } from 'react';
import {
  GitBranch,
  Search,
  CheckCircle2,
  FolderGit2,
  Star,
  Lock,
  Globe,
  RefreshCw,
  BookOpen,
  FileCode2,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import type { MonitoredRepository } from '../types/connectors';
import { gitHubConnector } from '../connectors/github';

interface GitHubRepoSelectorProps {
  lang: 'en' | 'th';
  onRepoSelected?: (repo: MonitoredRepository) => void;
}

export const GitHubRepoSelector: React.FC<GitHubRepoSelectorProps> = ({
  lang,
  onRepoSelected,
}) => {
  const th = lang === 'th';

  const [activeRepo, setActiveRepo] = useState<MonitoredRepository | null>(() => {
    try {
      if (typeof localStorage !== 'undefined') {
        const saved = localStorage.getItem('zyntheor_active_github_repo');
        if (saved) return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return null;
  });

  const [repositories, setRepositories] = useState<Array<Partial<MonitoredRepository>>>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [customInput, setCustomInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [actionPreview, setActionPreview] = useState<any | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);

  // Fetch repositories from GitHub connector endpoint
  const fetchRepositories = useCallback(async () => {
    setIsLoading(true);
    try {
      const activeToken =
        typeof localStorage !== 'undefined'
          ? localStorage.getItem('zyntheor_github_token') ||
            localStorage.getItem('zyntheor_auth_token') ||
            ''
          : '';

      const headers: Record<string, string> = { Accept: 'application/json' };
      if (activeToken) {
        headers['x-github-token'] = activeToken;
        headers['Authorization'] = `Bearer ${activeToken}`;
      }

      const res = await fetch('/api/engine/connectors/github/repositories', { headers });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.repositories)) {
          setRepositories(data.repositories);
        }
      }
    } catch {
      // Fallback
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchRepositories();
  }, [fetchRepositories]);

  // Set active monitored repository
  const handleSelectRepo = (repo: Partial<MonitoredRepository>) => {
    const updated: MonitoredRepository = {
      fullName: repo.fullName || `${repo.owner}/${repo.name}`,
      name: repo.name || '',
      owner: repo.owner || '',
      description: repo.description,
      defaultBranch: repo.defaultBranch || 'main',
      selectedBranch: repo.selectedBranch || repo.defaultBranch || 'main',
      stars: repo.stars ?? 0,
      private: !!repo.private,
      htmlUrl: repo.htmlUrl || `https://github.com/${repo.fullName}`,
      indexedAt: new Date().toLocaleTimeString(),
      monitored: true,
      openIssues: repo.openIssues ?? 0,
    };

    setActiveRepo(updated);
    try {
      localStorage.setItem('zyntheor_active_github_repo', JSON.stringify(updated));
    } catch {
      // ignore
    }

    onRepoSelected?.(updated);
    setStatusMsg(
      th
        ? `เลือกและเชื่อมโยงคลัง "${updated.fullName}" เป็นโปรเจกต์ที่มอนิเตอร์แล้ว`
        : `Monitored project set to "${updated.fullName}"`
    );
    window.setTimeout(() => setStatusMsg(null), 3000);
  };

  // Add custom owner/repo
  const handleAddCustomRepo = () => {
    const trimmed = customInput.trim();
    if (!trimmed || !trimmed.includes('/')) return;
    const [owner, name] = trimmed.split('/');
    if (!owner || !name) return;

    handleSelectRepo({
      fullName: `${owner}/${name}`,
      owner,
      name,
      defaultBranch: 'main',
      selectedBranch: 'main',
      private: false,
    });
    setCustomInput('');
  };

  // Quick action: Index README
  const handleIndexReadme = async () => {
    if (!activeRepo) return;
    setIsActionLoading(true);
    setActionPreview(null);
    try {
      const readme = await gitHubConnector.getReadme(activeRepo.owner, activeRepo.name, activeRepo.selectedBranch);
      setActionPreview({ type: 'readme', content: readme.content, sha: readme.sha, size: readme.size });
      setStatusMsg(th ? 'ดึงและตรวจสอบ README.md เรียบร้อยแล้ว' : 'README.md indexed successfully');
    } catch (err: any) {
      setStatusMsg(err.message || 'Failed to read README');
    } finally {
      setIsActionLoading(false);
    }
  };

  // Quick action: Scan Open Issues
  const handleScanIssues = async () => {
    if (!activeRepo) return;
    setIsActionLoading(true);
    setActionPreview(null);
    try {
      const res = await gitHubConnector.listIssues({
        owner: activeRepo.owner,
        repo: activeRepo.name,
        state: 'open',
        perPage: 5,
      });
      setActionPreview({ type: 'issues', issues: res.issues, count: res.count });
      setStatusMsg(th ? `พบ ${res.count} Issues ในคลังนี้` : `Found ${res.count} issues`);
    } catch (err: any) {
      setStatusMsg(err.message || 'Failed to scan issues');
    } finally {
      setIsActionLoading(false);
    }
  };

  const filtered = repositories.filter(
    (r) =>
      r.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-500/10 border border-blue-500/20 rounded-xl text-blue-400">
            <FolderGit2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-zinc-100">
                {th ? 'เลือกคลังโค้ดสำหรับมอนิเตอร์ (Project Selector)' : 'Active Project Selector'}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-blue-950/80 text-blue-300 border border-blue-800">
                Session Active
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              {th
                ? 'ระบุคลังโค้ด GitHub ที่ต้องการให้ AI Assistant เฝ้าติดตามและเข้าถึงข้อมูลในเซสชันนี้'
                : 'Select the GitHub repository the assistant should index and monitor for the current session'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => void fetchRepositories()}
          disabled={isLoading}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium self-end sm:self-auto transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-blue-400' : ''}`} />
          <span>{th ? 'รีเฟรชคลัง' : 'Refresh Repos'}</span>
        </button>
      </div>

      {statusMsg && (
        <div className="p-3 bg-amber-950/60 border border-amber-800 rounded-xl text-xs text-amber-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{statusMsg}</span>
          </div>
          <button type="button" onClick={() => setStatusMsg(null)} className="text-zinc-400 hover:text-zinc-200">
            ✕
          </button>
        </div>
      )}

      {/* Current Active Monitored Repository Card */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-blue-900/50 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
              {th ? 'คลังโค้ดที่มอนิเตอร์อยู่ในปัจจุบัน' : 'Currently Monitored Repository'}
            </span>
          </div>
          <span className="text-[11px] font-mono text-zinc-500">
            {th ? 'ซิงก์เมื่อ:' : 'Indexed at:'} {activeRepo?.indexedAt || 'UNAVAILABLE'}
          </span>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-zinc-100 font-mono">{activeRepo?.fullName || 'UNAVAILABLE'}</span>
              {activeRepo?.private ? (
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-800 flex items-center gap-1">
                  <Lock className="w-2.5 h-2.5" /> Private
                </span>
              ) : (
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-zinc-800 text-zinc-300 border border-zinc-700 flex items-center gap-1">
                  <Globe className="w-2.5 h-2.5" /> Public
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400 line-clamp-1">{activeRepo?.description || (th ? 'ยังไม่ได้เลือก repository' : 'No repository selected.')}</p>
          </div>

          {/* Branch & Open Link */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-750 text-xs font-mono text-cyan-300">
              <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
              <span>{activeRepo?.selectedBranch || activeRepo?.defaultBranch || 'UNAVAILABLE'}</span>
            </div>
            {activeRepo?.htmlUrl && (
              <a
                href={activeRepo.htmlUrl}
                target="_blank"
                rel="noreferrer"
                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800"
                title="Open on GitHub"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>

        {/* Quick Assistant Actions */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-zinc-850">
          <button
            type="button"
            onClick={handleIndexReadme}
            disabled={isActionLoading || !activeRepo}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-850 hover:bg-zinc-800 text-zinc-200 text-xs font-medium transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span>{th ? 'ดึง README.md' : 'Index README'}</span>
          </button>
          <button
            type="button"
            onClick={handleScanIssues}
            disabled={isActionLoading || !activeRepo}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-850 hover:bg-zinc-800 text-zinc-200 text-xs font-medium transition-colors"
          >
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>{th ? 'สแกน Issues ที่เปิดอยู่' : 'Scan Open Issues'}</span>
          </button>
        </div>

        {/* Action Results Preview */}
        {actionPreview && (
          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg text-xs space-y-2 mt-2">
            {actionPreview.type === 'readme' && (
              <div>
                <div className="flex items-center justify-between text-zinc-400 text-[11px] pb-1 border-b border-zinc-850">
                  <span>README.md ({actionPreview.size} bytes)</span>
                  <span className="font-mono text-[10px]">SHA: {actionPreview.sha?.slice(0, 8)}...</span>
                </div>
                <pre className="mt-2 p-2 bg-zinc-900 rounded font-mono text-[11px] text-zinc-300 max-h-36 overflow-y-auto whitespace-pre-wrap">
                  {actionPreview.content?.slice(0, 1500)}
                </pre>
              </div>
            )}
            {actionPreview.type === 'issues' && (
              <div className="space-y-1">
                <div className="text-[11px] text-zinc-400 pb-1 border-b border-zinc-850">
                  {th ? `รายการ Issues ล่าสุด (${actionPreview.count} รายการ):` : `Recent Issues (${actionPreview.count}):`}
                </div>
                {actionPreview.issues?.map((iss: any) => (
                  <div key={iss.number} className="flex items-center justify-between p-1 bg-zinc-900 rounded text-xs">
                    <span className="truncate text-zinc-200 font-medium">#{iss.number} {iss.title}</span>
                    <span className="font-mono text-[10px] text-zinc-500">@{iss.user}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Search & Custom Input Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Filter List */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-zinc-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={th ? 'ค้นหาจากรายการคลังโค้ด...' : 'Filter available repositories...'}
            className="w-full pl-9 pr-3 py-2 bg-zinc-950 border border-zinc-800 rounded-xl text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-blue-500"
          />
        </div>

        {/* Custom Input */}
        <div className="flex gap-2">
          <input
            type="text"
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            placeholder="owner/repository"
            className="flex-1 px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-xl text-xs font-mono text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-blue-500"
          />
          <button
            type="button"
            onClick={handleAddCustomRepo}
            disabled={!customInput.trim() || !customInput.includes('/')}
            className="px-3 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shrink-0 transition-colors"
          >
            {th ? 'เลือกมอนิเตอร์' : 'Monitor'}
          </button>
        </div>
      </div>

      {/* Repositories Selection Grid */}
      <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
        {filtered.map((repo) => {
          const isSelected = activeRepo?.fullName === repo.fullName;
          return (
            <div
              key={repo.fullName}
              onClick={() => handleSelectRepo(repo)}
              className={`p-3 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${
                isSelected
                  ? 'bg-blue-950/40 border-blue-700/80'
                  : 'bg-zinc-950/60 border-zinc-850 hover:border-zinc-700 hover:bg-zinc-950'
              }`}
            >
              <div className="space-y-0.5 min-w-0">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-semibold font-mono truncate ${isSelected ? 'text-blue-300' : 'text-zinc-200'}`}>
                    {repo.fullName}
                  </span>
                  {repo.stars !== undefined && repo.stars > 0 && (
                    <span className="flex items-center gap-0.5 text-[10px] text-amber-400 font-mono">
                      <Star className="w-2.5 h-2.5 fill-amber-400" />
                      {repo.stars.toLocaleString()}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-zinc-400 truncate">{repo.description || 'No description'}</p>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                {isSelected ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    {th ? 'กำลังมอนิเตอร์' : 'Active'}
                  </span>
                ) : (
                  <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-zinc-300" />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
