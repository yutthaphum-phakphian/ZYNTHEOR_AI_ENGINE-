import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ChatCoreFallback } from './ChatCoreFallback';

/**
 * Decorative 3D "AI core" for the chat empty state.
 *
 * - Real WebGL rendering via three.js (already a project dependency).
 * - Purely visual: it never displays or implies model/runtime/connection status.
 * - prefers-reduced-motion: renders a single static frame, no animation loop.
 * - No WebGL / context lost / init error: falls back to the CSS-only core (.zy-ai-core-wrap).
 * - Animation pauses while the tab is hidden or the element is off-screen.
 * - pointer-events are limited to a light parallax; touch-action keeps vertical scroll working.
 */

export function isWebGLAvailable(): boolean {
  if (typeof document === 'undefined') return false;
  try {
    const canvas = document.createElement('canvas');
    return Boolean(canvas.getContext('webgl2') || canvas.getContext('webgl'));
  } catch {
    return false;
  }
}

export const ChatCore3D: React.FC<{ label?: string }> = ({ label = 'ภาพประกอบ 3D ของ ZYNTHEOR AI Core' }) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState<boolean>(() => !isWebGLAvailable());

  useEffect(() => {
    const host = hostRef.current;
    if (failed || !host) return;

    const reduceMotion = typeof window.matchMedia === 'function'
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
    } catch {
      setFailed(true);
      return;
    }

    const size = () => ({
      w: Math.max(host.clientWidth, 1),
      h: Math.max(host.clientHeight, 1),
    });
    const initial = size();
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(initial.w, initial.h, false);
    renderer.setClearColor(0x000000, 0);
    const canvas = renderer.domElement;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.display = 'block';
    canvas.setAttribute('aria-hidden', 'true');
    host.appendChild(canvas);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, initial.w / initial.h, 0.1, 100);
    camera.position.set(0, 0.5, 8.4);

    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(item: T): T => { disposables.push(item); return item; };

    const uniforms = { uTime: { value: 0 } };

    // Glass orb: fresnel rim + slowly drifting cyan -> violet gradient (additive, so it glows on dark UI)
    const orbMat = track(new THREE.ShaderMaterial({
      uniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        varying vec3 vNormal; varying vec3 vView; varying float vY;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vView = normalize(-mv.xyz);
          vY = position.y;
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        uniform float uTime; varying vec3 vNormal; varying vec3 vView; varying float vY;
        void main() {
          float f = pow(1.0 - max(dot(normalize(vNormal), normalize(vView)), 0.0), 2.4);
          float m = 0.5 + 0.5 * sin(vY * 1.8 + uTime * 0.9);
          vec3 cyan = vec3(0.13, 0.83, 0.93);
          vec3 violet = vec3(0.55, 0.36, 0.96);
          vec3 col = mix(cyan, violet, m);
          float body = 0.16 + 0.10 * m;
          gl_FragColor = vec4(col * (body + f * 1.5), body + f * 0.9);
        }`,
    }));
    const orbGeo = track(new THREE.SphereGeometry(1.3, 64, 64));
    const orb = new THREE.Mesh(orbGeo, orbMat);
    scene.add(orb);

    // Soft atmosphere halo (back faces, additive)
    const haloMat = track(new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      side: THREE.BackSide,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        varying vec3 vNormal; varying vec3 vView;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vView = normalize(-mv.xyz);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec3 vNormal; varying vec3 vView;
        void main() {
          float f = pow(max(dot(normalize(-vNormal), normalize(vView)), 0.0), 3.0);
          gl_FragColor = vec4(vec3(0.25, 0.65, 1.0) * f, f * 0.55);
        }`,
    }));
    const halo = new THREE.Mesh(track(new THREE.SphereGeometry(1.75, 48, 48)), haloMat);
    scene.add(halo);

    // Faint inner lattice for depth
    const coreGeo = track(new THREE.IcosahedronGeometry(0.86, 1));
    const coreMat = track(new THREE.MeshBasicMaterial({ color: 0xa5f3fc, wireframe: true, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false }));
    const core = new THREE.Mesh(coreGeo, coreMat);
    scene.add(core);

    // Orbit rings, each with a glowing satellite
    const ringSpecs = [
      { radius: 2.2, color: 0x7dd3fc, tiltX: 1.15, tiltY: 0.0, speed: 0.55 },
      { radius: 2.65, color: 0xa78bfa, tiltX: 0.35, tiltY: 0.9, speed: -0.38 },
      { radius: 3.05, color: 0x67e8f9, tiltX: -0.7, tiltY: -0.5, speed: 0.27 },
    ];
    const rings = ringSpecs.map((spec) => {
      const pivot = new THREE.Group();
      pivot.rotation.set(spec.tiltX, spec.tiltY, 0);
      const ring = new THREE.Mesh(
        track(new THREE.TorusGeometry(spec.radius, 0.012, 8, 160)),
        track(new THREE.MeshBasicMaterial({ color: spec.color, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false })),
      );
      const arm = new THREE.Group();
      const sat = new THREE.Mesh(
        track(new THREE.SphereGeometry(0.075, 16, 16)),
        track(new THREE.MeshBasicMaterial({ color: 0xffffff })),
      );
      sat.position.set(spec.radius, 0, 0);
      const satGlow = new THREE.Mesh(
        track(new THREE.SphereGeometry(0.17, 16, 16)),
        track(new THREE.MeshBasicMaterial({ color: spec.color, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false })),
      );
      satGlow.position.copy(sat.position);
      arm.add(sat, satGlow);
      pivot.add(ring, arm);
      scene.add(pivot);
      return { arm, speed: spec.speed, phase: spec.radius * 2 };
    });

    // Soft round particles (generated sprite texture, deterministic layout so the static frame is stable)
    const spriteCanvas = document.createElement('canvas');
    spriteCanvas.width = 64;
    spriteCanvas.height = 64;
    const sctx = spriteCanvas.getContext('2d');
    if (sctx) {
      const grad = sctx.createRadialGradient(32, 32, 0, 32, 32, 32);
      grad.addColorStop(0, 'rgba(255,255,255,1)');
      grad.addColorStop(0.35, 'rgba(165,243,252,0.55)');
      grad.addColorStop(1, 'rgba(165,243,252,0)');
      sctx.fillStyle = grad;
      sctx.fillRect(0, 0, 64, 64);
    }
    const sprite = track(new THREE.CanvasTexture(spriteCanvas));
    const count = 140;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const cyan = new THREE.Color(0x67e8f9);
    const violet = new THREE.Color(0xc4b5fd);
    for (let i = 0; i < count; i += 1) {
      const phi = Math.acos(1 - 2 * ((i + 0.5) / count));
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      const r = 3.3 + ((i * 37) % 10) / 14;
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.cos(phi);
      positions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
      const c = cyan.clone().lerp(violet, (i % 7) / 6);
      colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b;
    }
    const pGeo = track(new THREE.BufferGeometry());
    pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    pGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const pMat = track(new THREE.PointsMaterial({ map: sprite, vertexColors: true, size: 0.2, transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending }));
    const points = new THREE.Points(pGeo, pMat);
    scene.add(points);

    // Light pointer parallax (target values, eased in the loop)
    let targetX = 0;
    let targetY = 0;
    const onPointerMove = (event: PointerEvent) => {
      const rect = host.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      targetX = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
      targetY = ((event.clientY - rect.top) / rect.height - 0.5) * 2;
    };
    const onPointerLeave = () => { targetX = 0; targetY = 0; };

    const renderFrame = (t: number) => {
      uniforms.uTime.value = t;
      orb.rotation.y = t * 0.2;
      core.rotation.x = t * 0.22;
      core.rotation.y = -t * 0.3;
      halo.scale.setScalar(1 + Math.sin(t * 1.4) * 0.025);
      rings.forEach((r) => { r.arm.rotation.z = r.phase + t * r.speed; });
      points.rotation.y = t * 0.05;
      points.rotation.x = Math.sin(t * 0.2) * 0.1;
      scene.rotation.y += (targetX * 0.5 - scene.rotation.y) * 0.06;
      scene.rotation.x += (targetY * 0.35 - scene.rotation.x) * 0.06;
      renderer.render(scene, camera);
    };

    let resizeRaf: number | null = null;
    const resize = () => {
      const { w, h } = size();
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
      if (reduceMotion) renderFrame(1.2);
    };
    const onResize = () => {
      if (resizeRaf !== null) cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(() => {
        resize();
      });
    };
    const resizeObserver = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(onResize) : null;
    resizeObserver?.observe(host);

    const onContextLost = (event: Event) => { event.preventDefault(); setFailed(true); };
    canvas.addEventListener('webglcontextlost', onContextLost);

    let rafId = 0;
    let running = false;
    let visible = true;
    const clock = new THREE.Clock();

    const loop = () => {
      rafId = requestAnimationFrame(loop);
      renderFrame(clock.getElapsedTime());
    };
    const start = () => {
      if (running || reduceMotion || !visible || document.hidden) return;
      running = true;
      clock.start();
      rafId = requestAnimationFrame(loop);
    };
    const stop = () => {
      running = false;
      cancelAnimationFrame(rafId);
    };
    const onVisibility = () => (document.hidden ? stop() : start());
    document.addEventListener('visibilitychange', onVisibility);

    const intersection = typeof IntersectionObserver !== 'undefined'
      ? new IntersectionObserver((entries) => {
        visible = entries.some((entry) => entry.isIntersecting);
        if (visible) start(); else stop();
      })
      : null;
    intersection?.observe(host);

    if (reduceMotion) {
      renderFrame(1.2); // one static frame, no loop, no pointer parallax
    } else {
      host.addEventListener('pointermove', onPointerMove);
      host.addEventListener('pointerleave', onPointerLeave);
      start();
    }

    return () => {
      if (resizeRaf !== null) cancelAnimationFrame(resizeRaf);
      stop();
      document.removeEventListener('visibilitychange', onVisibility);
      intersection?.disconnect();
      resizeObserver?.disconnect();
      host.removeEventListener('pointermove', onPointerMove);
      host.removeEventListener('pointerleave', onPointerLeave);
      canvas.removeEventListener('webglcontextlost', onContextLost);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
      if (host.contains(canvas)) host.removeChild(canvas);
    };
  }, [failed]);

  if (failed) return <ChatCoreFallback />;

  return (
    <div
      ref={hostRef}
      role="img"
      aria-label={label}
      data-testid="chat-core-3d"
      className="mx-auto h-36 w-36 shrink-0 sm:h-44 sm:w-44"
      style={{ touchAction: 'pan-y' }}
    />
  );
};

export default ChatCore3D;
