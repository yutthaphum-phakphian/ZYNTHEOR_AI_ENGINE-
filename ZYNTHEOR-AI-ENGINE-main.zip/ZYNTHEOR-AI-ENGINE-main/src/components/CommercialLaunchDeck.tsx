import React, { useState } from 'react';
import {
  AlertTriangle,
  Award,
  CheckSquare,
  Square,
  FileCheck,
  Globe2,
  HelpCircle,
  Play,
} from 'lucide-react';

/**
 * Commercial launch checklist.
 *
 * Honesty rules for this page:
 *  - Nothing here is a certificate, a signature, a ledger block or a test result. The app has no component that
 *    issues or verifies any of those, so every such field reads UNKNOWN / NOT_TESTED instead of an invented value.
 *  - The sign-off boxes are a personal checklist kept in this browser only. Ticking one does not sign anything and
 *    never changes the certification status.
 *  - No people, hashes, fingerprints, quorum counts or block numbers are shown, because none are real here.
 */

const STORAGE_KEY_CHECKLIST = 'zyntheor_launch_checklist_v2';

/** Identifier of the registration being *requested*. It is a target, not evidence of certification. */
const REQUESTED_REGISTRATION_ID = 'GA-CERT-NOVA-2026-001';

type Role = 'CISO' | 'SRE_LEAD' | 'COMPLIANCE_LEAD' | 'VP_PRODUCT';
const ROLES: { role: Role; th: string; en: string }[] = [
  { role: 'CISO', th: 'ฝ่ายความมั่นคงปลอดภัยสารสนเทศ', en: 'Information security' },
  { role: 'SRE_LEAD', th: 'ฝ่าย SRE / ความเสถียรระบบ', en: 'Site reliability' },
  { role: 'COMPLIANCE_LEAD', th: 'ฝ่ายกำกับดูแลและกฎหมาย', en: 'Compliance & legal' },
  { role: 'VP_PRODUCT', th: 'ฝ่ายผลิตภัณฑ์', en: 'Product' },
];

const PHASES: { id: string; th: string; en: string; descTh: string; descEn: string }[] = [
  { id: 'init', th: 'ขั้นที่ 1: ตรวจ Runtime', en: 'Phase 1: Runtime verification',
    descTh: 'ใช้ Preflight Check (GET /api/preflight) เพื่อตรวจ Core API, Local Runtime และโมเดลจริง',
    descEn: 'Use the Preflight Check (GET /api/preflight) to probe the Core API, local runtime and model.' },
  { id: 'verify', th: 'ขั้นที่ 2: ลายเซ็นและหลักฐาน', en: 'Phase 2: Signatures & evidence',
    descTh: 'ยังไม่มีส่วนใดในระบบที่สร้างหรือตรวจลายเซ็นฝั่ง server จึงยังทดสอบไม่ได้',
    descEn: 'No server component creates or verifies signatures yet, so this cannot be tested.' },
  { id: 'flight', th: 'ขั้นที่ 3: เปิดใช้งานเชิงพาณิชย์', en: 'Phase 3: Commercial launch',
    descTh: 'ยังไม่มีเกณฑ์หรือกระบวนการเปิดใช้งานที่ระบบตรวจสอบได้',
    descEn: 'There is no launch gate the system can verify.' },
];

function loadChecklist(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CHECKLIST);
    const parsed = raw ? JSON.parse(raw) : {};
    const out: Record<string, boolean> = {};
    for (const { role } of ROLES) out[role] = parsed?.[role] === true;
    return out;
  } catch {
    return Object.fromEntries(ROLES.map(({ role }) => [role, false]));
  }
}

const Unknown: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="text-amber-300">{children}</span>
);

export const CommercialLaunchDeck: React.FC<{ lang?: 'en' | 'th' }> = ({ lang = 'th' }) => {
  const t = (th: string, en: string) => (lang === 'th' ? th : en);
  const [checks, setChecks] = useState<Record<string, boolean>>(loadChecklist);
  const [note, setNote] = useState<string | null>(null);

  const toggle = (role: Role) => {
    const next = { ...checks, [role]: !checks[role] };
    setChecks(next);
    try {
      localStorage.setItem(STORAGE_KEY_CHECKLIST, JSON.stringify(next));
      setNote(t('จดไว้ในเบราว์เซอร์นี้เท่านั้น', 'Saved in this browser only'));
    } catch {
      setNote(t('บันทึกไม่ได้ (พื้นที่เก็บข้อมูลของเบราว์เซอร์ไม่พร้อม) ค่านี้อยู่ได้แค่ในหน้านี้', 'Could not save (browser storage unavailable); this lasts for this page only'));
    }
    window.setTimeout(() => setNote(null), 2500);
  };

  const ticked = ROLES.filter(({ role }) => checks[role]).length;

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-2xl bg-zinc-950 border border-amber-500/30 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-500/60 text-amber-300 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-sm font-bold text-zinc-100 uppercase tracking-widest font-mono">
                {t('รายการตรวจความพร้อมก่อนเปิดใช้เชิงพาณิชย์', 'Commercial launch readiness checklist')}
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-950 border border-amber-500 text-amber-300 font-bold">
                NOT CERTIFIED
              </span>
            </div>
            <p className="text-[11px] text-zinc-400">
              {t(
                'ยังไม่มีใบรับรอง ลายเซ็น หรือบันทึกใน ledger ที่ระบบนี้สร้างหรือตรวจสอบได้ หน้านี้แสดงเฉพาะสถานะจริง',
                'No certificate, signature or ledger entry exists that this system can issue or verify. This page shows real status only.',
              )}
            </p>
          </div>
        </div>
      </div>

      {note && (
        <div role="status" className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-300 text-xs">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span>{note}</span>
        </div>
      )}

      <div className="p-4 rounded-2xl bg-zinc-950/90 border border-cyan-900/40 shadow-xl space-y-3">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
          <div className="flex items-center gap-2">
            <Play className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-zinc-100 uppercase tracking-wider font-mono">
              {t('ลำดับความพร้อม 3 ขั้นตอน', '3-phase readiness sequence')}
            </h3>
          </div>
          <span className="text-[10px] font-mono text-amber-300 font-semibold bg-amber-950/70 border border-amber-800/60 px-2 py-0.5 rounded-md">
            READINESS: UNKNOWN
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {PHASES.map((p) => (
            <div key={p.id} className="p-3.5 rounded-xl border border-zinc-800 bg-zinc-900/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-zinc-200">{t(p.th, p.en)}</span>
                <HelpCircle className="w-4 h-4 text-amber-400" />
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">{t(p.descTh, p.descEn)}</p>
              <div className="text-[9px] font-mono text-amber-300 border-t border-zinc-800 pt-1.5">STATUS: NOT_TESTED</div>
            </div>
          ))}
        </div>
      </div>

      <div className="p-5 rounded-2xl bg-zinc-950 border border-amber-500/30 shadow-2xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-900/30 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-amber-300" />
              <span className="font-mono text-sm font-bold text-amber-300">{REQUESTED_REGISTRATION_ID}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-900 text-zinc-300 border border-zinc-700">
                {t('เป้าหมายที่ร้องขอ', 'Requested target')}
              </span>
            </div>
            <div className="text-xs text-zinc-400 mt-0.5">
              {t('ยังไม่มีการออกใบรับรองสำหรับรหัสนี้', 'No certificate has been issued for this identifier.')}
            </div>
          </div>
          <div className="font-mono text-xs text-amber-300 font-bold">NOT_CERTIFIED</div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-[11px]">
          {[
            ['RSA-4096 Fingerprint', t('UNKNOWN: ไม่มีกุญแจหรือหลักฐาน', 'UNKNOWN: no key or evidence')],
            ['Post-Quantum Dilithium-5 Signature', t('UNKNOWN: ไม่มีลายเซ็น', 'UNKNOWN: no signature')],
            ['Merkle Root Anchor', t('UNKNOWN: ไม่มีการ anchor', 'UNKNOWN: nothing anchored')],
            ['Compliance & Evidence Chain', t('UNKNOWN: ยังไม่มีการตรวจ', 'UNKNOWN: not assessed')],
          ].map(([label, value]) => (
            <div key={label} className="p-3 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-1">
              <span className="text-[10px] text-zinc-500 uppercase tracking-wider block">{label}:</span>
              <Unknown>{value}</Unknown>
            </div>
          ))}
        </div>

        <div className="border-t border-amber-900/30 pt-3 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="font-bold text-zinc-300 uppercase tracking-wider">
              {t('รายการติ๊กส่วนตัว (ไม่ใช่การลงนาม)', 'Personal checklist (not a sign-off)')}
            </span>
            <span className="text-zinc-400">{ticked} / {ROLES.length} {t('ติ๊กแล้ว', 'ticked')}</span>
          </div>
          <p className="text-[10px] text-zinc-500">
            {t(
              'ติ๊กเพื่อช่วยจำ เก็บในเบราว์เซอร์นี้เท่านั้น ไม่มีลายเซ็น ไม่มีชื่อผู้ลงนาม และไม่เปลี่ยนสถานะการรับรอง',
              'Ticks are a memory aid stored in this browser only. No signature, no named signer, and they never change the certification status.',
            )}
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
            {ROLES.map(({ role, th, en }) => (
              <button
                key={role}
                type="button"
                onClick={() => toggle(role)}
                role="checkbox"
                aria-checked={checks[role]}
                className={`text-left p-3 rounded-xl border text-xs transition-all ${
                  checks[role] ? 'bg-zinc-900 border-zinc-600 text-zinc-200' : 'bg-zinc-900/50 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono font-bold text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-cyan-300">{role}</span>
                  {checks[role] ? <CheckSquare className="w-4 h-4 text-zinc-300" /> : <Square className="w-4 h-4 text-zinc-600" />}
                </div>
                <div className="text-[11px] text-zinc-300 truncate">{t(th, en)}</div>
                <div className="text-[9px] font-mono text-amber-300 mt-1">
                  {t('ผู้ลงนาม: ยังไม่ได้กำหนด', 'Signer: not assigned')}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 rounded-2xl bg-zinc-950/90 border border-cyan-900/40 shadow-xl space-y-3 font-mono">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-zinc-100 uppercase tracking-wider">
              {t('การลงทะเบียนใน Global Ledger', 'Global ledger registration')}
            </h3>
          </div>
          <span className="text-[10px] text-amber-300 font-bold bg-amber-950 border border-amber-800 px-2 py-0.5 rounded">
            NOT_REGISTERED
          </span>
        </div>
        <p className="text-xs text-zinc-400">
          {t(
            'ไม่มี ledger ภายนอกที่เชื่อมต่อกับระบบนี้ จึงไม่มีบล็อก แฮช ลายเซ็น หรือผลโหวตให้แสดง ห้ามตีความหน้านี้ว่าเป็นหลักฐานทางกฎหมาย',
            'No external ledger is connected to this system, so there is no block, hash, signature or quorum to show. Do not read this page as legal evidence.',
          )}
        </p>
      </div>
    </div>
  );
};
