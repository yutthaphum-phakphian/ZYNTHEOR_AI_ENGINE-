import React, { useState } from 'react';
import { notify } from '../utils/notify';
import {
  BarChart3,
  FileSpreadsheet,
  Calculator,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sliders,
  Layers,
  HelpCircle
} from 'lucide-react';
import { executeTool } from '../services/api';

interface AnalysisModeProps {
  onLedgerUpdated?: () => void;
}

export const AnalysisMode: React.FC<AnalysisModeProps> = ({ onLedgerUpdated }) => {
  const [dataInput, setDataInput] = useState(`timestamp,event_type,latency_ms,status
2026-10-17T12:00:00Z,INFERENCE_REQUEST,420,PASS
2026-10-17T12:00:15Z,FILE_SEARCH,18,PASS
2026-10-17T12:00:30Z,CALCULATOR_EVAL,4,PASS
2026-10-17T12:01:00Z,UNSANDBOXED_RUN,0,BLOCKED
2026-10-17T12:01:10Z,WEB_SEARCH,650,PASS`);

  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<{
    totalRows: number;
    columns: string[];
    passCount: number;
    blockedCount: number;
    failCount: number;
    avgLatencyMs: number;
    assumptions: string[];
    limitations: string[];
    keyTakeaways: string[];
  } | null>(null);

  const handleAnalyzeData = async () => {
    setLoading(true);
    try {
      const lines = dataInput.trim().split('\n').filter((l) => l.trim().length > 0);
      if (lines.length < 2) {
        notify('กรุณาใส่ข้อมูลอย่างน้อย 2 บรรทัด (Header + Data)', 'error');
        setLoading(false);
        return;
      }

      const headers = lines[0].split(',').map((h) => h.trim());
      const rows = lines.slice(1).map((l) => l.split(',').map((c) => c.trim()));

      let pass = 0;
      let blocked = 0;
      let fail = 0;
      let totalLatency = 0;
      let latencyCount = 0;

      const statusColIndex = headers.findIndex((h) => h.toLowerCase().includes('status'));
      const latencyColIndex = headers.findIndex((h) => h.toLowerCase().includes('latency'));

      rows.forEach((row) => {
        if (statusColIndex !== -1 && row[statusColIndex]) {
          const st = row[statusColIndex].toUpperCase();
          if (st === 'PASS') pass++;
          else if (st === 'BLOCKED') blocked++;
          else fail++;
        }
        if (latencyColIndex !== -1 && row[latencyColIndex]) {
          const num = parseFloat(row[latencyColIndex]);
          if (!isNaN(num) && num > 0) {
            totalLatency += num;
            latencyCount++;
          }
        }
      });

      // Verification via calculator tool
      let calculatedAvg = 0;
      if (latencyCount > 0) {
        const calcRes = await executeTool('calculator', {
          expression: `(${totalLatency}) / ${latencyCount}`
        });
        calculatedAvg = calcRes.success && typeof calcRes.result === 'number' ? calcRes.result : totalLatency / latencyCount;
      }

      setAnalysis({
        totalRows: rows.length,
        columns: headers,
        passCount: pass,
        blockedCount: blocked,
        failCount: fail,
        avgLatencyMs: Math.round(calculatedAvg * 10) / 10,
        assumptions: [
          'บรรทัดแรกของชุดข้อมูลเป็น Header กำหนดชื่อฟิลด์',
          'ฟิลด์สถานะ (Status) มีค่าตามมาตรฐาน PASS / BLOCKED / FAIL',
          'ความหน่วง (Latency) มีหน่วยวัดเป็นมิลลิวินาที (ms)'
        ],
        limitations: [
          'การคำนวณสถิติอ้างอิงเฉพาะแถวข้อมูลที่สมบูรณ์เท่านั้น',
          'Zero-Fake Policy ไม่อนุญาตให้สร้างข้อมูลคาดเดาหรือแถวที่ขาดหายไป'
        ],
        keyTakeaways: [
          `ชุดข้อมูลมีจำนวนทั้งสิ้น ${rows.length} รายการ และมีอัตราผ่านเกณฑ์ ${Math.round((pass / rows.length) * 100)}%`,
          `พบเหตุการณ์ที่ถูกระงับเพื่อความปลอดภัย (BLOCKED) ${blocked} รายการ`,
          `ระยะเวลาเฉลี่ยของการประมวลผลอยู่ที่ ${Math.round(calculatedAvg * 10) / 10} ms คำนวณจริงผ่าน Safe Calculator Tool`
        ]
      });

      if (onLedgerUpdated) onLedgerUpdated();
    } catch (err) {
      console.error('Data analysis error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 font-mono text-xs space-y-6">
      {/* Title */}
      <div className="space-y-1">
        <h2 className="text-base font-display font-semibold text-slate-100 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-cyan-400" />
          Data & Document Analysis Engine
        </h2>
        <p className="text-slate-400 text-xs">
          วิเคราะห์ตารางข้อมูล เอกสาร และสถิติ พร้อมระบุข้อสมมติ (Assumptions), ข้อจำกัด และคำนวณผ่าน Tool จริง
        </p>
      </div>

      {/* Input Data Area */}
      <div className="p-4 rounded-xl bg-[#080d18] border border-cyan-500/30 space-y-3">
        <div className="flex items-center justify-between">
          <label className="font-semibold text-slate-200 flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            ข้อมูลตาราง (CSV หรือ Text Data):
          </label>
          <span className="text-[10px] text-slate-500">Zero-Fake Grounded Analysis</span>
        </div>

        <textarea
          rows={7}
          value={dataInput}
          onChange={(e) => setDataInput(e.target.value)}
          className="w-full p-3 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 font-mono text-xs focus:outline-none focus:border-cyan-400 leading-relaxed"
        />

        <button
          onClick={handleAnalyzeData}
          disabled={loading}
          className="px-5 py-2.5 rounded-lg bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 font-semibold transition-all flex items-center gap-2 disabled:opacity-50"
        >
          {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <BarChart3 className="w-4 h-4" />}
          <span>วิเคราะห์ข้อมูลจริง</span>
        </button>
      </div>

      {/* Analysis Results View */}
      {analysis && (
        <div className="space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-[#070b14] border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase">จำนวนแถวข้อมูล</span>
              <div className="text-base font-bold text-slate-200 mt-0.5">{analysis.totalRows} แถว</div>
            </div>
            <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
              <span className="text-emerald-400/80 text-[10px] uppercase">สถานะ PASS</span>
              <div className="text-base font-bold text-emerald-400 mt-0.5">{analysis.passCount} รายการ</div>
            </div>
            <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30">
              <span className="text-amber-400/80 text-[10px] uppercase">สถานะ BLOCKED</span>
              <div className="text-base font-bold text-amber-400 mt-0.5">{analysis.blockedCount} รายการ</div>
            </div>
            <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/30">
              <span className="text-cyan-400/80 text-[10px] uppercase">ความหน่วงเฉลี่ย (Avg Latency)</span>
              <div className="text-base font-bold text-cyan-300 mt-0.5">{analysis.avgLatencyMs} ms</div>
            </div>
          </div>

          {/* Key Takeaways */}
          <div className="p-4 rounded-xl bg-[#070b14] border border-slate-800 space-y-2">
            <h3 className="font-semibold text-slate-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              ข้อค้นพบสำคัญ (Key Takeaways):
            </h3>
            <ul className="space-y-1.5 list-disc list-inside text-slate-300 text-xs">
              {analysis.keyTakeaways.map((k, i) => (
                <li key={i}>{k}</li>
              ))}
            </ul>
          </div>

          {/* Assumptions & Limitations (Required by Capability 6) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#070b14] border border-slate-800 space-y-2">
              <h4 className="font-semibold text-slate-300 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                ข้อสมมติที่ใช้ (Assumptions):
              </h4>
              <ul className="space-y-1 list-disc list-inside text-slate-400 text-[11px]">
                {analysis.assumptions.map((a, i) => (
                  <li key={i}>{a}</li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-[#070b14] border border-slate-800 space-y-2">
              <h4 className="font-semibold text-slate-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                ข้อจำกัดและความแม่นยำ (Limitations):
              </h4>
              <ul className="space-y-1 list-disc list-inside text-slate-400 text-[11px]">
                {analysis.limitations.map((l, i) => (
                  <li key={i}>{l}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
