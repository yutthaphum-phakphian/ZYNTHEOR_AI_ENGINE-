import { useRef, useState } from 'react';
import { Download, LockKeyhole, Upload } from 'lucide-react';

const SETTINGS_KEYS = ['zyntheor_voice_settings', 'zyntheor_auth_token', 'apphub_auth_token', 'zyntheor_github_token'];
const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();

async function deriveKey(passphrase: string, salt: Uint8Array) {
  const material = await crypto.subtle.importKey('raw', textEncoder.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: salt as BufferSource, iterations: 310_000, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = ''; bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary);
}
function base64ToBytes(value: string) {
  return Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
}

export function SettingsSyncPanel() {
  const [passphrase, setPassphrase] = useState('');
  const [status, setStatus] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const exportEncrypted = async () => {
    if (passphrase.trim().length < 12) { setStatus('ตั้งรหัสผ่านซิงก์อย่างน้อย 12 ตัวอักษร'); return; }
    try {
      const settings = Object.fromEntries(SETTINGS_KEYS.map((key) => [key, localStorage.getItem(key)]));
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const key = await deriveKey(passphrase, salt);
      const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, textEncoder.encode(JSON.stringify({ version: 1, createdAt: new Date().toISOString(), settings })));
      const payload = JSON.stringify({ format: 'zyntheor-settings-sync', version: 1, kdf: 'PBKDF2-SHA256', iterations: 310000, salt: bytesToBase64(salt), iv: bytesToBase64(iv), ciphertext: bytesToBase64(new Uint8Array(encrypted)) }, null, 2);
      const link = document.createElement('a');
      link.href = URL.createObjectURL(new Blob([payload], { type: 'application/json' }));
      link.download = 'zyntheor-settings-sync.encrypted.json'; link.click(); URL.revokeObjectURL(link.href);
      setStatus('แพ็กเกจการตั้งค่าที่เข้ารหัสแล้ว ดาวน์โหลดสำเร็จ');
    } catch { setStatus('เข้ารหัสไม่สำเร็จ เบราว์เซอร์นี้อาจไม่รองรับ Web Crypto'); }
  };

  const importEncrypted = async (file?: File) => {
    if (!file) return;
    if (passphrase.trim().length < 12) { setStatus('ใส่รหัสผ่านซิงก์อย่างน้อย 12 ตัวอักษร'); return; }
    try {
      const payload = JSON.parse(await file.text());
      if (payload.format !== 'zyntheor-settings-sync' || payload.version !== 1) throw new Error('invalid format');
      const key = await deriveKey(passphrase, base64ToBytes(payload.salt));
      const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: base64ToBytes(payload.iv) }, key, base64ToBytes(payload.ciphertext));
      const data = JSON.parse(textDecoder.decode(plaintext));
      if (data.version !== 1 || !data.settings || typeof data.settings !== 'object') throw new Error('invalid data');
      SETTINGS_KEYS.forEach((name) => {
        const value = data.settings[name];
        if (typeof value === 'string') localStorage.setItem(name, value);
        else localStorage.removeItem(name);
      });
      window.dispatchEvent(new CustomEvent('zyntheor-settings-restored'));
      setStatus('นำเข้าการตั้งค่าแล้ว (Thai Voice และ Bearer Token) โหลดหน้าใหม่เพื่อใช้ค่าทั้งหมด');
    } catch { setStatus('ถอดรหัสไม่สำเร็จ ตรวจสอบไฟล์และรหัสผ่าน'); }
  };

  return <section className="space-y-3">
    <div className="rounded-xl border border-cyan-500/20 bg-slate-900/60 p-3 space-y-2">
      <div className="flex items-center gap-2 text-sm font-semibold text-slate-100"><LockKeyhole size={15} className="text-cyan-400" />Encrypted settings sync</div>
      <p className="text-[11px] leading-relaxed text-slate-400">ซิงก์แบบ local-first: การตั้งค่าเสียงไทยและ Bearer Token จะถูกเข้ารหัส AES-256-GCM ด้วยรหัสผ่านของคุณก่อนสร้างไฟล์ ไม่ส่งข้อมูลหรือรหัสผ่านไปยังเซิร์ฟเวอร์ ซิงก์ข้ามเครื่องโดยเก็บไฟล์นี้ในคลาวด์/ไดรฟ์ที่คุณเลือก แล้วนำเข้าอีกเครื่อง</p>
      <label className="block text-[11px] text-slate-300">รหัสผ่านเข้ารหัส (อย่างน้อย 12 ตัวอักษร)
        <input type="password" autoComplete="new-password" value={passphrase} onChange={(event) => setPassphrase(event.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white outline-none focus:border-cyan-500" placeholder="ใช้รหัสผ่านเดียวกันทุกเครื่อง" />
      </label>
      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={() => void exportEncrypted()} className="flex items-center gap-1.5 rounded-lg border border-cyan-500/30 bg-cyan-950/40 px-3 py-2 text-xs text-cyan-200 hover:bg-cyan-900/50"><Download size={13}/>สร้างไฟล์ซิงก์เข้ารหัส</button>
        <button type="button" onClick={() => fileRef.current?.click()} className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/60 px-3 py-2 text-xs text-slate-200 hover:bg-slate-700"><Upload size={13}/>นำเข้าไฟล์จากเครื่องอื่น</button>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(event) => { void importEncrypted(event.target.files?.[0]); event.currentTarget.value = ''; }} />
      </div>
      {status && <div role="status" className="text-[11px] text-cyan-300">{status}</div>}
    </div>
  </section>;
}
