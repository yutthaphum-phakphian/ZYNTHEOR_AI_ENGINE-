import React, { useState, useEffect } from 'react';
import {
  Mic,
  Sliders,
  Languages,
  RotateCcw,
  Check,
  Sparkles,
  Volume2,
  X,
  Play,
  Square,
  AlertCircle,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import {
  STTSettings,
  STT_LANGUAGES,
  getSTTSettings,
  saveSTTSettings,
  DEFAULT_STT_SETTINGS,
  deriveSensitivityLevel,
} from '../utils/sttSettings';
import { useSpeechToText } from '../hooks/useSpeechToText';

interface SpeechToTextSettingsPanelProps {
  onClose?: () => void;
  isModal?: boolean;
}

export const SpeechToTextSettingsPanel: React.FC<SpeechToTextSettingsPanelProps> = ({
  onClose,
  isModal = false,
}) => {
  const [settings, setSettings] = useState<STTSettings>(() => getSTTSettings());
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testOutput, setTestOutput] = useState('');

  // Built-in live test using hook
  const speechTest = useSpeechToText({
    lang: settings.inputLanguage,
    onFinal: (text) => {
      setTestOutput((prev) => (prev ? `${prev} ${text}` : text));
    },
  });

  useEffect(() => {
    setSettings(getSTTSettings());
  }, []);

  const handleSensitivityChange = (value: number) => {
    setSettings((prev) => ({
      ...prev,
      sensitivity: value,
      sensitivityLevel: deriveSensitivityLevel(value),
    }));
  };

  const handlePresetSensitivity = (level: 'low' | 'medium' | 'high') => {
    const val = level === 'low' ? 30 : level === 'medium' ? 65 : 90;
    handleSensitivityChange(val);
  };

  const handleSave = () => {
    saveSTTSettings(settings);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      if (onClose && isModal) onClose();
    }, 800);
  };

  const handleReset = () => {
    setSettings({ ...DEFAULT_STT_SETTINGS });
    setTestOutput('');
    if (speechTest.listening) speechTest.stop();
  };

  const content = (
    <div className="space-y-6 text-xs text-slate-300">
      {/* SECTION 1: Input Language Selection */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-slate-200 text-sm">
            <Languages className="w-4 h-4 text-cyan-400" />
            <span>ภาษาอินพุตเสียง (Input Language)</span>
          </div>
          <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
            {settings.inputLanguage}
          </span>
        </div>

        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
          <p className="text-[11px] text-slate-400 leading-relaxed">
            เลือกภาษาสำหรับการแปลงคำพูดเป็นข้อความ (Speech-to-Text) ระบบจะปรับแต่งการถอดความเสียงตามพจนานุกรมสำเนียงของภาษานั้น
          </p>

          {/* Quick Language Chips */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
            {STT_LANGUAGES.map((lang) => {
              const isSelected = settings.inputLanguage === lang.code;
              return (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, inputLanguage: lang.code }))}
                  className={`flex items-center gap-2 p-2 rounded-lg border text-left transition-all ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-200 font-semibold shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                      : 'bg-slate-900 border-slate-850 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <span className="text-base shrink-0">{lang.flag}</span>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs truncate">{lang.nativeLabel}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{lang.code}</div>
                  </div>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Fallback Custom / Dropdown Input */}
          <div className="pt-2 border-t border-slate-850">
            <label className="block text-[11px] text-slate-400 mb-1">รหัสภาษา BCP 47 อื่นๆ (กำหนดเอง):</label>
            <input
              type="text"
              value={settings.inputLanguage}
              onChange={(e) => setSettings((prev) => ({ ...prev, inputLanguage: e.target.value }))}
              placeholder="เช่น th-TH, en-US, ja-JP"
              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* SECTION 2: Continuous Listening Mode */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 font-semibold text-slate-200 text-sm">
          <Radio className="w-4 h-4 text-emerald-400" />
          <span>การฟังเสียงอย่างต่อเนื่อง (Continuous Listening)</span>
        </div>

        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1 pr-4">
              <div className="font-medium text-slate-200 text-xs">
                {settings.continuousListening
                  ? 'เปิดใช้งานการฟังต่อเนื่อง (Continuous Listening Active)'
                  : 'โหมดประโยคเดี่ยว (Single Sentence Mode)'}
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {settings.continuousListening
                  ? 'ไมโครโฟนจะทำงานต่อเนื่องแม้มีการหยุดพักพูด เหมาะสำหรับการพูดบรรยายยาวๆ หรือเขียนโค้ด'
                  : 'ไมโครโฟนจะปิดและสรุปข้อความทันทีหลังจากจบประโยคแรก เหมาะสำหรับการสั่งการสั้นๆ'}
              </p>
            </div>

            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={settings.continuousListening}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, continuousListening: e.target.checked }))
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500 shadow-inner"></div>
            </label>
          </div>
        </div>
      </div>

      {/* SECTION 3: Speech Detection Sensitivity */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-slate-200 text-sm">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>ความไวในการตรวจจับเสียงพูด (Speech Detection Sensitivity)</span>
          </div>
          <span className="font-mono text-xs font-bold text-amber-300 bg-amber-950/60 px-2.5 py-0.5 rounded border border-amber-800">
            {settings.sensitivity}% ({settings.sensitivityLevel.toUpperCase()})
          </span>
        </div>

        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-4">
          {/* Slider */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>ความไวระดับต่ำ (กรองเสียงรบกวน)</span>
              <span>ความไวระดับสูง (จับเสียงแผ่วเบา)</span>
            </div>

            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={settings.sensitivity}
              onChange={(e) => handleSensitivityChange(parseInt(e.target.value, 10))}
              className="w-full accent-amber-400 cursor-pointer h-2 bg-slate-800 rounded-lg"
            />

            {/* Presets */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              <button
                type="button"
                onClick={() => handlePresetSensitivity('low')}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium border transition-all ${
                  settings.sensitivityLevel === 'low'
                    ? 'bg-amber-600/30 border-amber-400 text-amber-200 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                ความไวต่ำ (30%)
              </button>
              <button
                type="button"
                onClick={() => handlePresetSensitivity('medium')}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium border transition-all ${
                  settings.sensitivityLevel === 'medium'
                    ? 'bg-amber-600/30 border-amber-400 text-amber-200 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                มาตรฐาน (65%)
              </button>
              <button
                type="button"
                onClick={() => handlePresetSensitivity('high')}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium border transition-all ${
                  settings.sensitivityLevel === 'high'
                    ? 'bg-amber-600/30 border-amber-400 text-amber-200 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                ความไวสูง (90%)
              </button>
            </div>
          </div>

          {/* Explanation Banner */}
          <div className="p-3 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              {settings.sensitivityLevel === 'low' && (
                <span>
                  <strong>ระดับต่ำ:</strong> เหมาะสำหรับห้องที่มีเสียงพัดลมหรือเสียงรอบข้างรบกวน ต้องออกเสียงดังชัดเจน และตัดเสียงแทรกอัตโนมัติ
                </span>
              )}
              {settings.sensitivityLevel === 'medium' && (
                <span>
                  <strong>ระดับมาตรฐาน:</strong> ค่าสมดุลสำหรับการใช้งานในออฟฟิศหรือห้องทำงานทั่วไป รับเสียงสนทนาปกติได้เป็นธรรมชาติ
                </span>
              )}
              {settings.sensitivityLevel === 'high' && (
                <span>
                  <strong>ระดับสูง:</strong> ตอบสนองต่อเสียงกระซิบหรือเสียงพูดเบาๆ ได้ทันที และแสดงผลการถอดความระหว่างพูด (Interim Results) รวดเร็วที่สุด
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 4: Live Interactive Audio & Microphone Test */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-slate-200 text-sm">
            <Mic className="w-4 h-4 text-amber-400" />
            <span>ทดสอบการรับเสียงจริง (Live Microphone Test)</span>
          </div>
          {speechTest.listening && (
            <span className="flex items-center gap-1.5 text-xs text-rose-400 animate-pulse font-mono font-bold">
              <span className="w-2 h-2 rounded-full bg-rose-500"></span> กำลังฟังเสียง...
            </span>
          )}
        </div>

        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              กดปุ่มด้านล่างแล้วลองพูดประโยคสั้นๆ เพื่อทดสอบว่าระบบถอดความได้แม่นยำหรือไม่:
            </span>
            <button
              type="button"
              onClick={speechTest.toggle}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                speechTest.listening
                  ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-[0_0_12px_rgba(244,63,94,0.4)]'
                  : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
              }`}
            >
              {speechTest.listening ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-white" />
                  <span>หยุดฟัง</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>เริ่มทดสอบพูด</span>
                </>
              )}
            </button>
          </div>

          {/* Live Preview Box */}
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg min-h-[56px] text-xs">
            {testOutput || speechTest.interim ? (
              <div className="space-y-1">
                {testOutput && <span className="text-slate-100 font-medium">{testOutput} </span>}
                {speechTest.interim && (
                  <span className="text-cyan-400/80 italic">{speechTest.interim}</span>
                )}
              </div>
            ) : (
              <span className="text-slate-500 italic text-[11px]">
                {speechTest.listening
                  ? 'กำลังรอฟังเสียงพูดของคุณ... ลองพูดว่า "สวัสดี Zyntheor"'
                  : 'ยังไม่มีข้อความทดสอบ กดปุ่ม "เริ่มทดสอบพูด" ด้านบน'}
              </span>
            )}
          </div>

          {speechTest.error && (
            <div className="text-[11px] text-rose-400 bg-rose-950/30 border border-rose-900/40 p-2 rounded-lg flex items-center gap-1.5">
              <span>⚠️ {speechTest.error}</span>
            </div>
          )}
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-medium transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>คืนค่าเริ่มต้น</span>
        </button>

        <div className="flex items-center gap-2">
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
            >
              ปิด
            </button>
          )}

          <button
            type="button"
            onClick={handleSave}
            className="flex items-center gap-1.5 px-5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 text-xs font-bold shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
          >
            {savedSuccess ? (
              <>
                <Check className="w-4 h-4" />
                <span>บันทึกแล้ว ✓</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>บันทึกการตั้งค่า STT</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="stt-modal-title"
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div
          className="relative w-full max-w-xl bg-[#071026] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#091534]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950 flex items-center justify-center shadow-lg font-bold">
                <Mic className="w-5 h-5 text-slate-950" />
              </div>
              <div>
                <h2 id="stt-modal-title" className="text-sm font-bold text-white flex items-center gap-2">
                  <span>ตั้งค่าการพิมพ์ด้วยเสียง (Speech-to-Text Settings)</span>
                </h2>
                <p className="text-[11px] text-slate-400">เลือกภาษาอินพุต การฟังต่อเนื่อง และความไวในการตรวจจับเสียง</p>
              </div>
            </div>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Body */}
          <div className="p-6 overflow-y-auto flex-1">{content}</div>
        </div>
      </div>
    );
  }

  return content;
};
