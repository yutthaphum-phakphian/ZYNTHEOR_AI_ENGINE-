import React, { useState, useEffect, useMemo } from 'react';
import {
  Brain,
  Database,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Clock,
  Trash2,
  Edit3,
  Plus,
  Search,
  RefreshCw,
  FileText,
  Lock,
  X,
  Filter,
  Check,
  Layers,
} from 'lucide-react';

export type ContextFactType = 'FACT' | 'ASSUMPTION' | 'UNKNOWN';

export interface ContextFact {
  id: string;
  workspaceId: string;
  type: ContextFactType;
  statement: string;
  source: string;
  relevantFiles: string[];
  confidence: number;
  confidenceTag?: "HIGH" | "MEDIUM" | "LOW";
  evidence?: string;
  provenanceKind?: "VERIFIED_FACT" | "USER_CLAIM" | "ASSUMPTION" | "UNKNOWN";
  verified: boolean;
  stale: boolean;
  invalidatedAt?: string;
  invalidationReason?: string;
  createdAt: string;
  updatedAt: string;
}

interface ContextSummary {
  total: number;
  facts: number;
  assumptions: number;
  unknowns: number;
  stale: number;
}

interface ProjectContextMemoryPanelProps {
  lang: 'en' | 'th';
  currentWorkspaceId?: string;
}

export const ProjectContextMemoryPanel: React.FC<ProjectContextMemoryPanelProps> = ({
  lang,
  currentWorkspaceId = 'default',
}) => {
  const [activeWorkspace, setActiveWorkspace] = useState(currentWorkspaceId);
  const [workspaces, setWorkspaces] = useState<string[]>([currentWorkspaceId]);
  const [facts, setFacts] = useState<ContextFact[]>([]);
  const [summary, setSummary] = useState<ContextSummary>({
    total: 0,
    facts: 0,
    assumptions: 0,
    unknowns: 0,
    stale: 0,
  });
  const [loading, setLoading] = useState(false);
  const [checkingFreshness, setCheckingFreshness] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<'ALL' | ContextFactType | 'STALE'>('ALL');
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Modal / Form state for Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingFact, setEditingFact] = useState<ContextFact | null>(null);
  const [formType, setFormType] = useState<ContextFactType>('FACT');
  const [formStatement, setFormStatement] = useState('');
  const [formSource, setFormSource] = useState('');
  const [formRelevantFiles, setFormRelevantFiles] = useState('');
  const [formSaving, setFormSaving] = useState(false);

  // Secret redaction preview detector
  const secretDetectedInForm = useMemo(() => {
    return /\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|Bearer\s+[A-Za-z0-9._~+/-]+)\b/i.test(
      formStatement
    );
  }, [formStatement]);

  const showNotification = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3500);
  };

  // Fetch workspaces list
  const fetchWorkspaces = async () => {
    try {
      const res = await fetch('/api/workspaces');
      if (res.ok) {
        const data = await res.json();
        const list = Array.from(new Set([currentWorkspaceId, ...(Array.isArray(data.workspaces) ? data.workspaces : [])]));
        setWorkspaces(list);
      }
    } catch {
      // Keep default
    }
  };

  // Fetch facts for active workspace
  const fetchFacts = async (wsId = activeWorkspace) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/context/${encodeURIComponent(wsId)}`);
      if (res.ok) {
        const data = await res.json();
        setFacts(data.facts || []);
        setSummary(
          data.summary || {
            total: (data.facts || []).length,
            facts: (data.facts || []).filter((f: ContextFact) => f.type === 'FACT').length,
            assumptions: (data.facts || []).filter((f: ContextFact) => f.type === 'ASSUMPTION').length,
            unknowns: (data.facts || []).filter((f: ContextFact) => f.type === 'UNKNOWN').length,
            stale: (data.facts || []).filter((f: ContextFact) => f.stale).length,
          }
        );
      }
    } catch (e: any) {
      showNotification(`Error loading context facts: ${e.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkspaces();
  }, []);

  useEffect(() => {
    fetchFacts(activeWorkspace);
  }, [activeWorkspace]);

  // Open modal to add new fact
  const handleOpenAddModal = () => {
    setEditingFact(null);
    setFormType('FACT');
    setFormStatement('');
    setFormSource(`workspace:${activeWorkspace}`);
    setFormRelevantFiles('');
    setIsModalOpen(true);
  };

  // Open modal to edit existing fact
  const handleOpenEditModal = (fact: ContextFact) => {
    setEditingFact(fact);
    setFormType(fact.type);
    setFormStatement(fact.statement);
    setFormSource(fact.source);
    setFormRelevantFiles(fact.relevantFiles.join(', '));
    setIsModalOpen(true);
  };

  // Save (Create or Update) fact
  const handleSaveFact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formStatement.trim()) return;

    setFormSaving(true);
    const relevantFiles = formRelevantFiles
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    try {
      if (editingFact) {
        // Update
        const res = await fetch(
          `/api/context/${encodeURIComponent(activeWorkspace)}/facts/${encodeURIComponent(editingFact.id)}`,
          {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              type: formType,
              statement: formStatement.trim(),
              source: formSource.trim(),
              relevantFiles,
              stale: false, // editing refreshes it
            }),
          }
        );
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || 'Failed to update context fact');
        }
        showNotification(
          lang === 'th' ? 'อัปเดตข้อเท็จจริงในบริบทโปรเจกต์สำเร็จ' : 'Context fact updated successfully'
        );
      } else {
        // Create
        const res = await fetch(`/api/context/${encodeURIComponent(activeWorkspace)}/facts`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: formType,
            statement: formStatement.trim(),
            source: formSource.trim() || `workspace:${activeWorkspace}`,
            relevantFiles,
          }),
        });
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || 'Failed to create context fact');
        }
        showNotification(
          lang === 'th' ? 'เพิ่มข้อเท็จจริงในหน่วยความจำเรียบร้อย' : 'Context fact added to memory'
        );
      }

      setIsModalOpen(false);
      fetchFacts(activeWorkspace);
    } catch (e: any) {
      showNotification(e.message, 'error');
    } finally {
      setFormSaving(false);
    }
  };

  // Delete a fact
  const handleDeleteFact = async (factId: string) => {
    const confirmMsg =
      lang === 'th' ? 'ต้องการลบข้อมูลข้อเท็จจริงนี้ออกจากหน่วยความจำหรือไม่?' : 'Delete this fact from memory?';
    if (!window.confirm(confirmMsg)) return;

    try {
      const res = await fetch(
        `/api/context/${encodeURIComponent(activeWorkspace)}/facts/${encodeURIComponent(factId)}`,
        { method: 'DELETE' }
      );
      if (res.ok) {
        showNotification(
          lang === 'th' ? 'ลบข้อเท็จจริงเรียบร้อยแล้ว' : 'Context fact deleted',
          'info'
        );
        fetchFacts(activeWorkspace);
      }
    } catch (e: any) {
      showNotification(`Error: ${e.message}`, 'error');
    }
  };

  // Re-verify / Mark fact as fresh
  const handleMarkFresh = async (fact: ContextFact) => {
    try {
      const res = await fetch(
        `/api/context/${encodeURIComponent(activeWorkspace)}/facts/${encodeURIComponent(fact.id)}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stale: false, verified: true }),
        }
      );
      if (res.ok) {
        showNotification(
          lang === 'th' ? 'ยืนยันข้อมูลใหม่และปลดสถานะเก่าเรียบร้อย' : 'Marked fact as fresh & verified'
        );
        fetchFacts(activeWorkspace);
      }
    } catch (e: any) {
      showNotification(`Error: ${e.message}`, 'error');
    }
  };

  // Run background freshness check
  const handleCheckFreshness = async () => {
    setCheckingFreshness(true);
    try {
      const res = await fetch(`/api/context/${encodeURIComponent(activeWorkspace)}/check-freshness`, {
        method: 'POST',
      });
      if (res.ok) {
        const data = await res.json();
        const invalidated = data.result?.invalidatedCount || 0;
        if (invalidated > 0) {
          showNotification(
            lang === 'th'
              ? `ตรวจพบไฟล์เปลี่ยนใน Workspace: ปรับสถานะข้อเท็จจริงที่เก่าแล้ว ${invalidated} รายการ`
              : `Found changed files: invalidated ${invalidated} outdated context facts`,
            'info'
          );
        } else {
          showNotification(
            lang === 'th'
              ? 'ตรวจสอบความใหม่ของไฟล์เรียบร้อย ข้อมูลทั้งหมดสอดคล้องกับไฟล์จริง'
              : 'Freshness verified: all context facts match current workspace files',
            'success'
          );
        }
        fetchFacts(activeWorkspace);
      }
    } catch (e: any) {
      showNotification(`Error checking freshness: ${e.message}`, 'error');
    } finally {
      setCheckingFreshness(false);
    }
  };

  // Clear all facts for this workspace
  const handleClearWorkspace = async () => {
    const confirmMsg =
      lang === 'th'
        ? `ต้องการล้างความจำทั้งหมดของ Workspace "${activeWorkspace}" หรือไม่? ข้อมูลจะไม่สามารถกู้คืนได้`
        : `Clear all memory for workspace "${activeWorkspace}"? This action cannot be undone.`;
    if (!window.confirm(confirmMsg)) return;

    try {
      const res = await fetch(`/api/context/${encodeURIComponent(activeWorkspace)}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        showNotification(
          lang === 'th' ? 'ล้างหน่วยความจำของ Workspace สำเร็จ' : 'Workspace memory cleared',
          'info'
        );
        fetchFacts(activeWorkspace);
      }
    } catch (e: any) {
      showNotification(`Error: ${e.message}`, 'error');
    }
  };

  // Filtered facts based on search and type
  const filteredFacts = useMemo(() => {
    let result = [...facts];

    if (selectedTypeFilter === 'STALE') {
      result = result.filter((f) => f.stale);
    } else if (selectedTypeFilter !== 'ALL') {
      result = result.filter((f) => f.type === selectedTypeFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (f) =>
          f.statement.toLowerCase().includes(q) ||
          f.source.toLowerCase().includes(q) ||
          f.relevantFiles.some((rf) => rf.toLowerCase().includes(q))
      );
    }

    return result;
  }, [facts, selectedTypeFilter, searchQuery]);

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-4 col-span-1 md:col-span-2">
      {/* Header and Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-zinc-100">
                {lang === 'th'
                  ? 'Zyntheor Persistent Memory & Project Context Engine'
                  : 'Project Context Engine & Persistent Memory'}
              </h2>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                <Lock className="w-2.5 h-2.5" />
                <span>{lang === 'th' ? 'กรองข้อมูลลับอัตโนมัติ' : 'Secret Redacted'}</span>
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              {lang === 'th'
                ? 'จัดเก็บและแยกข้อเท็จจริง (FACT), สมมติฐาน (ASSUMPTION) และข้อมูลที่ยังขาด (UNKNOWN) แยกตาม Workspace ไม่ปะปนข้ามโปรเจกต์'
                : 'Project-isolated memory: stores FACTs, ASSUMPTIONs, and UNKNOWNs per workspace without cross-contamination'}
            </p>
          </div>
        </div>

        {/* Workspace Selector Dropdown & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-850 px-2.5 py-1.5 rounded-lg text-xs">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-zinc-400 font-medium">{lang === 'th' ? 'Workspace:' : 'Workspace:'}</span>
            <select
              value={activeWorkspace}
              onChange={(e) => setActiveWorkspace(e.target.value)}
              className="bg-transparent text-zinc-200 font-semibold focus:outline-none cursor-pointer"
            >
              {workspaces.map((ws) => (
                <option key={ws} value={ws} className="bg-zinc-900 text-zinc-200">
                  {ws}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={handleCheckFreshness}
            disabled={checkingFreshness}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-cyan-300 text-xs font-medium border border-zinc-700/60 transition-colors disabled:opacity-50"
            title={lang === 'th' ? 'ตรวจว่ามีไฟล์ใดเปลี่ยนและทำให้ข้อมูลเก่าหรือไม่' : 'Check file freshness against disk'}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${checkingFreshness ? 'animate-spin' : ''}`} />
            <span>{lang === 'th' ? 'ตรวจความใหม่ของไฟล์' : 'Check Freshness'}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAddModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/20 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'เพิ่มข้อเท็จจริง' : 'Add Fact'}</span>
          </button>
        </div>
      </div>

      {/* Notification Banner */}
      {notification && (
        <div
          className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs ${
            notification.type === 'error'
              ? 'bg-rose-500/10 border border-rose-500/30 text-rose-300'
              : notification.type === 'info'
              ? 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-300'
              : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
          }`}
        >
          <span>{notification.message}</span>
          <button type="button" onClick={() => setNotification(null)} className="opacity-70 hover:opacity-100">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
        <button
          type="button"
          onClick={() => setSelectedTypeFilter('ALL')}
          className={`p-2.5 rounded-xl border text-left transition-all ${
            selectedTypeFilter === 'ALL'
              ? 'bg-zinc-800/80 border-zinc-600'
              : 'bg-zinc-950/60 border-zinc-850 hover:bg-zinc-900'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">
            {lang === 'th' ? 'ความจำทั้งหมด' : 'Total Facts'}
          </div>
          <div className="text-lg font-black text-zinc-100 mt-0.5">{summary.total}</div>
        </button>

        <button
          type="button"
          onClick={() => setSelectedTypeFilter('FACT')}
          className={`p-2.5 rounded-xl border text-left transition-all ${
            selectedTypeFilter === 'FACT'
              ? 'bg-emerald-950/40 border-emerald-600'
              : 'bg-zinc-950/60 border-zinc-850 hover:bg-zinc-900'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-wider text-emerald-400">
            <span>FACT</span>
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          </div>
          <div className="text-lg font-black text-emerald-300 mt-0.5">{summary.facts}</div>
        </button>

        <button
          type="button"
          onClick={() => setSelectedTypeFilter('ASSUMPTION')}
          className={`p-2.5 rounded-xl border text-left transition-all ${
            selectedTypeFilter === 'ASSUMPTION'
              ? 'bg-amber-950/40 border-amber-600'
              : 'bg-zinc-950/60 border-zinc-850 hover:bg-zinc-900'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-wider text-amber-400">
            <span>ASSUMPTION</span>
            <Clock className="w-3 h-3 text-amber-400" />
          </div>
          <div className="text-lg font-black text-amber-300 mt-0.5">{summary.assumptions}</div>
        </button>

        <button
          type="button"
          onClick={() => setSelectedTypeFilter('UNKNOWN')}
          className={`p-2.5 rounded-xl border text-left transition-all ${
            selectedTypeFilter === 'UNKNOWN'
              ? 'bg-amber-950/40 border-amber-600'
              : 'bg-zinc-950/60 border-zinc-850 hover:bg-zinc-900'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-wider text-amber-400">
            <span>UNKNOWN</span>
            <HelpCircle className="w-3 h-3 text-amber-400" />
          </div>
          <div className="text-lg font-black text-amber-300 mt-0.5">{summary.unknowns}</div>
        </button>

        <button
          type="button"
          onClick={() => setSelectedTypeFilter('STALE')}
          className={`p-2.5 rounded-xl border text-left transition-all ${
            selectedTypeFilter === 'STALE'
              ? 'bg-rose-950/40 border-rose-600'
              : 'bg-zinc-950/60 border-zinc-850 hover:bg-zinc-900'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-wider text-rose-400">
            <span>{lang === 'th' ? 'ข้อมูลเก่า (STALE)' : 'STALE (OUTDATED)'}</span>
            <AlertTriangle className="w-3 h-3 text-rose-400" />
          </div>
          <div className="text-lg font-black text-rose-300 mt-0.5">{summary.stale}</div>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              lang === 'th'
                ? 'ค้นหาข้อความ, ไฟล์อ้างอิง หรือแหล่งที่มา...'
                : 'Search statements, sources, or files...'
            }
            className="w-full pl-9 pr-3 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          {summary.total > 0 && (
            <button
              type="button"
              onClick={handleClearWorkspace}
              className="text-xs text-zinc-500 hover:text-rose-400 px-2 py-1 transition-colors"
            >
              {lang === 'th' ? 'ล้างความจำ Workspace นี้' : 'Clear Workspace Memory'}
            </button>
          )}
        </div>
      </div>

      {/* Facts List */}
      <div className="space-y-2.5 pt-1">
        {loading ? (
          <div className="py-8 text-center text-xs text-zinc-500 flex items-center justify-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
            <span>{lang === 'th' ? 'กำลังโหลดบริบทโปรเจกต์...' : 'Loading workspace context memory...'}</span>
          </div>
        ) : filteredFacts.length === 0 ? (
          <div className="py-8 px-4 border border-dashed border-zinc-800 rounded-xl text-center space-y-2">
            <Brain className="w-8 h-8 text-zinc-600 mx-auto" />
            <p className="text-xs font-semibold text-zinc-400">
              {lang === 'th'
                ? 'ยังไม่มีข้อเท็จจริงในหน่วยความจำของ Workspace นี้'
                : 'No context facts stored for this workspace yet'}
            </p>
            <p className="text-[11px] text-zinc-500 max-w-md mx-auto">
              {lang === 'th'
                ? 'กดปุ่ม "เพิ่มข้อเท็จจริง" ด้านบน เพื่อป้อนข้อเท็จจริงหรือสมมติฐาน หรือให้ AI Brain Core บันทึกจากการทำงานอัตโนมัติ'
                : 'Click "Add Fact" above to record facts, assumptions, or missing info for the AI Brain Core.'}
            </p>
          </div>
        ) : (
          filteredFacts.map((fact) => {
            const isFact = fact.type === 'FACT';
            const isAssumption = fact.type === 'ASSUMPTION';
            const isUnknown = fact.type === 'UNKNOWN';

            return (
              <div
                key={fact.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  fact.stale
                    ? 'bg-rose-950/20 border-rose-900/50'
                    : isFact
                    ? 'bg-zinc-950/80 border-emerald-950/50 hover:border-emerald-800/60'
                    : isAssumption
                    ? 'bg-zinc-950/80 border-amber-950/50 hover:border-amber-800/60'
                    : 'bg-zinc-950/80 border-amber-950/50 hover:border-amber-800/60'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1.5 flex-1">
                    {/* Header Badges */}
                    <div className="flex flex-wrap items-center gap-2 text-[10px]">
                      {/* Type Badge */}
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-bold uppercase tracking-wider ${
                          isFact
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : isAssumption
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {isFact && <CheckCircle2 className="w-2.5 h-2.5" />}
                        {isAssumption && <Clock className="w-2.5 h-2.5" />}
                        {isUnknown && <HelpCircle className="w-2.5 h-2.5" />}
                        <span>{fact.type}</span>
                      </span>

                      {/* Stale Warning Badge */}
                      {fact.stale ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-bold bg-rose-500/10 border border-rose-500/40 text-rose-300">
                          <AlertTriangle className="w-2.5 h-2.5" />
                          <span>{lang === 'th' ? 'ไฟล์เปลี่ยน (ข้อมูลอาจเก่า)' : 'Stale / Outdated'}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-zinc-500 bg-zinc-900">
                          <Check className="w-2.5 h-2.5 text-emerald-500" />
                          <span>{lang === 'th' ? 'ข้อมูลสดใหม่' : 'Fresh'}</span>
                        </span>
                      )}

                      {/* Confidence and provenance */}
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[10px] font-bold ${
                        (fact.confidenceTag || (fact.confidence >= 0.8 ? 'HIGH' : fact.confidence >= 0.45 ? 'MEDIUM' : 'LOW')) === 'HIGH'
                          ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                          : (fact.confidenceTag || (fact.confidence >= 0.45 ? 'MEDIUM' : 'LOW')) === 'MEDIUM'
                            ? 'bg-amber-950/60 border-amber-800 text-amber-300'
                            : 'bg-rose-950/60 border-rose-800 text-rose-300'
                      }`} title={`Confidence score: ${fact.confidence}`}>
                        {fact.confidenceTag || (fact.confidence >= 0.8 ? 'HIGH' : fact.confidence >= 0.45 ? 'MEDIUM' : 'LOW')} CONFIDENCE
                      </span>
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded border border-zinc-700 bg-zinc-900 text-zinc-300 text-[10px]" title={fact.evidence || fact.source}>
                        {fact.provenanceKind || (fact.verified ? 'VERIFIED_FACT' : 'USER_CLAIM')}
                      </span>

                      {/* Source Tag */}
                      <span className="inline-flex items-center gap-1 text-zinc-400 bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded">
                        <Database className="w-2.5 h-2.5 text-zinc-500" />
                        <span title={fact.evidence || fact.source}>{fact.source}</span>
                      </span>

                      {/* Secret Redacted Indicator */}
                      <span className="inline-flex items-center gap-1 text-[10px] text-zinc-500">
                        <Lock className="w-2.5 h-2.5 text-emerald-500/60" />
                        <span>Sanitized</span>
                      </span>
                    </div>

                    {/* Fact Statement */}
                    <p className="text-xs text-zinc-100 font-medium leading-relaxed">{fact.statement}</p>

                    {/* Stale Reason if any */}
                    {fact.stale && fact.invalidationReason && (
                      <div className="text-[11px] text-rose-400 bg-rose-950/40 border border-rose-900/60 rounded px-2 py-1 mt-1 flex items-center gap-1.5">
                        <AlertTriangle className="w-3 h-3 shrink-0" />
                        <span>{fact.invalidationReason}</span>
                      </div>
                    )}

                    {/* Relevant Files list */}
                    {fact.relevantFiles && fact.relevantFiles.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <span className="text-[10px] text-zinc-500">{lang === 'th' ? 'ไฟล์ที่เกี่ยวข้อง:' : 'Files:'}</span>
                        {fact.relevantFiles.map((rf) => (
                          <span
                            key={rf}
                            className="inline-flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-cyan-300"
                          >
                            <FileText className="w-2.5 h-2.5" />
                            <span>{rf}</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Actions Buttons */}
                  <div className="flex items-center gap-1 shrink-0">
                    {fact.stale && (
                      <button
                        type="button"
                        onClick={() => handleMarkFresh(fact)}
                        className="p-1.5 rounded-lg bg-zinc-850 hover:bg-emerald-950/60 text-emerald-400 transition-colors"
                        title={lang === 'th' ? 'ยืนยันข้อมูลใหม่ (ปลดสถานะเก่า)' : 'Mark as Fresh'}
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => handleOpenEditModal(fact)}
                      className="p-1.5 rounded-lg bg-zinc-850 hover:bg-zinc-800 text-zinc-300 transition-colors"
                      title={lang === 'th' ? 'แก้ไข' : 'Edit'}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDeleteFact(fact.id)}
                      className="p-1.5 rounded-lg bg-zinc-850 hover:bg-rose-950/60 text-zinc-400 hover:text-rose-400 transition-colors"
                      title={lang === 'th' ? 'ลบ' : 'Delete'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal / Dialog for Add / Edit Fact */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-lg p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <Brain className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-zinc-100">
                  {editingFact
                    ? lang === 'th'
                      ? 'แก้ไขข้อเท็จจริงในหน่วยความจำ'
                      : 'Edit Context Fact'
                    : lang === 'th'
                    ? 'เพิ่มข้อเท็จจริงใหม่ลงในหน่วยความจำ'
                    : 'Add Context Fact to Memory'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-zinc-500 hover:text-zinc-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveFact} className="space-y-3.5 text-xs">
              {/* Type Selection */}
              <div>
                <label className="block text-zinc-300 font-semibold mb-1">
                  {lang === 'th' ? 'ประเภทของข้อมูลบริบท' : 'Context Type'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormType('FACT')}
                    className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border font-bold transition-all ${
                      formType === 'FACT'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-850'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>FACT</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormType('ASSUMPTION')}
                    className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border font-bold transition-all ${
                      formType === 'ASSUMPTION'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-850'
                    }`}
                  >
                    <Clock className="w-3.5 h-3.5" />
                    <span>ASSUMPTION</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormType('UNKNOWN')}
                    className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border font-bold transition-all ${
                      formType === 'UNKNOWN'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-850'
                    }`}
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>UNKNOWN</span>
                  </button>
                </div>
              </div>

              {/* Statement Input */}
              <div>
                <label className="block text-zinc-300 font-semibold mb-1">
                  {lang === 'th' ? 'ข้อความหรือข้อเท็จจริง (Statement)' : 'Fact Statement'}
                </label>
                <textarea
                  rows={3}
                  value={formStatement}
                  onChange={(e) => setFormStatement(e.target.value)}
                  placeholder={
                    lang === 'th'
                      ? 'เช่น "ไฟล์ index.html ใช้ Tailwind CSS และมี entry point อยู่ที่ /src/main.tsx"'
                      : 'e.g. "The project uses Vite with Tailwind CSS and runs on port 3000"'
                  }
                  required
                  className="w-full p-2.5 bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                />
                {secretDetectedInForm && (
                  <div className="mt-1 flex items-center gap-1.5 text-[11px] text-amber-400">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    <span>
                      {lang === 'th'
                        ? 'ตรวจพบข้อมูลที่อาจเป็นรหัสลับ: ระบบจะกรอง [REDACTED] อัตโนมัติก่อนบันทึก'
                        : 'Detected sensitive pattern: system will automatically redact secrets before storing'}
                    </span>
                  </div>
                )}
              </div>

              {/* Source Input */}
              <div>
                <label className="block text-zinc-300 font-semibold mb-1">
                  {lang === 'th' ? 'แหล่งที่มา (Source)' : 'Source'}
                </label>
                <input
                  type="text"
                  value={formSource}
                  onChange={(e) => setFormSource(e.target.value)}
                  placeholder="e.g. file:app.json, tool:build, user:manual"
                  className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Relevant Files Input */}
              <div>
                <label className="block text-zinc-300 font-semibold mb-1">
                  {lang === 'th'
                    ? 'ไฟล์ที่เกี่ยวข้อง (คั่นด้วยจุลภาค สำหรับตรวจสอบความสดใหม่)'
                    : 'Relevant Files (comma-separated, used for freshness invalidation)'}
                </label>
                <input
                  type="text"
                  value={formRelevantFiles}
                  onChange={(e) => setFormRelevantFiles(e.target.value)}
                  placeholder="index.html, app.json, src/main.tsx"
                  className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500 font-mono text-xs"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-300 font-medium"
                >
                  {lang === 'th' ? 'ยกเลิก' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={formSaving || !formStatement.trim()}
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition-all disabled:opacity-50"
                >
                  {formSaving
                    ? lang === 'th'
                      ? 'กำลังบันทึก...'
                      : 'Saving...'
                    : lang === 'th'
                    ? 'บันทึกข้อมูล'
                    : 'Save Fact'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
