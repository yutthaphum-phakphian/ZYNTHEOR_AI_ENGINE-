import React, { useState } from 'react';
import {
  Copy,
  Check,
  Volume2,
  VolumeX,
  Smile,
  Bot,
  User,
  Sparkles,
  ChevronDown,
  Eye,
  Download,
  FileDiff,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Play,
  Pause,
  RotateCcw,
  Info,
} from 'lucide-react';
import { ChatMessage, ReactionEmoji } from '../types/agent';
import { FileIconBadge } from './FileIconBadge';
import { TaskPlanCard } from './TaskPlanCard';
import { formatFileSize } from '../utils/fileHelper';
import {
  speakText,
  stopSpeaking,
  pauseSpeaking,
  resumeSpeaking,
  isSpeakingPaused,
  getVoiceSettings,
  replayLastSpoken,
} from '../utils/voiceSettings';

const AVAILABLE_EMOJIS: ReactionEmoji[] = ['👍', '👎', '💡', '⚠️', '❤️', '🎯', '✅', '🤔'];

interface ConversationMessageViewProps {
  message: ChatMessage;
  onToggleReaction: (messageId: string, emoji: ReactionEmoji) => void;
  onRetry?: (messageId: string) => void;
  onExecutePlan?: (planId: string) => void;
}

export const ConversationMessageView: React.FC<ConversationMessageViewProps> = ({
  message,
  onToggleReaction,
  onExecutePlan,
}) => {
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [previewSnippetId, setPreviewSnippetId] = useState<string | null>(null);
  const [appliedProposals, setAppliedProposals] = useState<Record<string, boolean>>({});
  const [approvingId, setApprovingId] = useState<string | null>(null);

  const isAgent = message.sender === 'agent';
  const isSystem = message.sender === 'system';

  // Handle direct approval of proposals from ONE CHAT
  const handleApproveProposal = async (proposalId: string) => {
    setApprovingId(proposalId);
    try {
      const getRes = await fetch(`/api/proposals/${proposalId}`);
      const getData = await getRes.json();
      const hash = getData.proposal?.hash;

      const appRes = await fetch(`/api/proposals/${proposalId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ expectedHash: hash }),
      });
      const appData = await appRes.json();
      const approvalId = appData.proposal?.approval?.id;

      if (approvalId) {
        const applyRes = await fetch(`/api/proposals/${proposalId}/apply`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ approvalId }),
        });
        if (applyRes.ok) {
          setAppliedProposals((prev) => ({ ...prev, [proposalId]: true }));
        }
      }
    } catch (e) {
      console.warn('Failed to approve proposal:', e);
    } finally {
      setApprovingId(null);
    }
  };

  // Copy message text
  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const [isAudioPaused, setIsAudioPaused] = useState(false);

  // Text to speech playback using configured voice settings
  const handleTTS = (mode: 'full' | 'summary' = 'full') => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
      setIsAudioPaused(false);
    } else {
      setIsPlayingAudio(true);
      setIsAudioPaused(false);
      const settings = getVoiceSettings();

      const textToRead =
        mode === 'summary' && message.summary
          ? message.summary
          : message.content;

      speakText(
        textToRead,
        settings,
        () => {
          setIsPlayingAudio(false);
          setIsAudioPaused(false);
        },
        () => {
          setIsPlayingAudio(false);
          setIsAudioPaused(false);
        }
      );
    }
  };

  const handleTogglePause = () => {
    if (isAudioPaused) {
      resumeSpeaking();
      setIsAudioPaused(false);
    } else {
      pauseSpeaking();
      setIsAudioPaused(true);
    }
  };

  const handleReplay = () => {
    stopSpeaking();
    setIsPlayingAudio(true);
    setIsAudioPaused(false);
    speakText(
      message.content,
      getVoiceSettings(),
      () => {
        setIsPlayingAudio(false);
        setIsAudioPaused(false);
      },
      () => {
        setIsPlayingAudio(false);
        setIsAudioPaused(false);
      },
      true
    );
  };

  // Count total reactions
  const reactionsMap = message.reactions || {};
  const userReactions = message.userReactions || [];
  const totalReactionsCount = Object.values(reactionsMap).reduce((a, b) => a + b, 0);

  // Format exact timestamp (time of day) for each message bubble
  const messageDate = message.timestamp ? new Date(message.timestamp) : new Date();
  const exactTimeOfDay = !isNaN(messageDate.getTime())
    ? messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
    : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });

  return (
    <div
      className={`group relative flex gap-3.5 px-4 sm:px-6 py-4 transition-colors ${
        isAgent
          ? 'bg-zinc-900/40 border-y border-zinc-850/60'
          : 'bg-transparent'
      }`}
    >
      {/* Avatar */}
      <div className="shrink-0 mt-0.5">
        {isAgent ? (
          <div className="w-8 h-8 rounded-lg bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 flex items-center justify-center shadow-xs">
            <Bot className="w-4 h-4" />
          </div>
        ) : isSystem ? (
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
        ) : (
          <div className="w-8 h-8 rounded-lg bg-zinc-800 text-zinc-300 border border-zinc-700 flex items-center justify-center font-bold text-xs">
            <User className="w-4 h-4" />
          </div>
        )}
      </div>

      {/* Message Body */}
      <div className="flex-1 min-w-0 space-y-2">
        {/* Header with Sender Name & Exact Time of Day & Reaction Summary */}
        <div className="flex items-center flex-wrap gap-2 text-xs text-zinc-400">
          <span className="font-semibold text-zinc-200">
            {isAgent ? 'Zyntheor Engine' : isSystem ? 'ระบบ (System)' : 'คุณ (User)'}
          </span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span className="font-mono text-[11px] text-zinc-400 flex items-center gap-1 bg-zinc-800/50 px-1.5 py-0.5 rounded border border-zinc-700/40" title="เวลาที่ส่งข้อความ (Time of Day)">
            <span>{exactTimeOfDay}</span>
          </span>

          {/* Reaction count & types beside timestamp as unboxed text */}
          {totalReactionsCount > 0 && (
            <>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="inline-flex items-center gap-1.5 text-zinc-400 text-[11px]">
                <span className="flex items-center gap-1">
                  {Object.entries(reactionsMap)
                    .filter(([_, count]) => count > 0)
                    .map(([emoji, count]) => (
                      <span key={emoji} title={`${emoji} (${count})`}>
                        {emoji} {count > 1 ? count : ''}
                      </span>
                    ))}
                </span>
                <span className="text-zinc-500">({totalReactionsCount})</span>
              </span>
            </>
          )}
        </div>

        {/* Attached files preview chips with Dynamic File Type Icons */}
        {message.attachedFiles && message.attachedFiles.length > 0 && (
          <div className="flex flex-wrap gap-2 my-2">
            {message.attachedFiles.map((file) => (
              <div
                key={file.id}
                className="flex flex-col bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-2.5 shadow-xs max-w-sm hover:border-indigo-300 dark:hover:border-indigo-600 transition-all"
              >
                <div className="flex items-center gap-2.5">
                  <FileIconBadge file={file} size="md" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-gray-800 dark:text-gray-200 truncate" title={file.name}>
                      {file.name}
                    </p>
                    <p className="text-[10px] text-gray-400">
                      {formatFileSize(file.size)} • {file.extension.toUpperCase() || 'ไฟล์'}
                    </p>
                  </div>
                  {file.textSnippet && (
                    <button
                      onClick={() =>
                        setPreviewSnippetId(previewSnippetId === file.id ? null : file.id)
                      }
                      className="p-1 rounded text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                      title="ดูตัวอย่างเนื้อหาไฟล์"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Image thumbnail if available */}
                {file.previewUrl && (
                  <div className="mt-2 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 max-h-48 bg-black/5 flex items-center justify-center">
                    <img
                      src={file.previewUrl}
                      alt={file.name}
                      className="max-h-48 w-auto object-contain"
                    />
                  </div>
                )}

                {/* Text snippet view */}
                {previewSnippetId === file.id && file.textSnippet && (
                  <div className="mt-2 p-2 bg-gray-50 dark:bg-gray-900 rounded border border-gray-200 dark:border-gray-700 text-[11px] font-mono text-gray-700 dark:text-gray-300 max-h-36 overflow-y-auto whitespace-pre-wrap">
                    {file.textSnippet}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Message Content with proper markdown-style formatting, diffs, download links, and proposal approvals */}
        <div className="text-sm text-gray-800 dark:text-gray-200 leading-relaxed space-y-3 break-words">
          {(() => {
            const proposalMatches = Array.from(
              new Set(message.content.match(/proposal-[a-zA-Z0-9_-]+/g) || [])
            );

            // Extract plan matches (e.g. Plan: <id>, plan-xxx, or UUID)
            const explicitPlanMatch = message.content.match(/(?:Plan|แผนงาน|planId):\s*`?([0-9a-f-]{36}|[a-zA-Z0-9_-]+)`?/i);
            const planUuidMatches = Array.from(
              new Set(message.content.match(/\b(?:plan-[a-zA-Z0-9_-]+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b/gi) || [])
            );
            const detectedPlanIds = Array.from(
              new Set([
                ...(explicitPlanMatch ? [explicitPlanMatch[1]] : []),
                ...planUuidMatches,
              ])
            );
            const hasMarkdownChecklist =
              /[-*]\s*\[([ xX])\]/.test(message.content) ||
              ((message.content.includes('ขั้นตอน') || message.content.includes('Plan')) && /\b(?:step|\d+[.)]\s+)/i.test(message.content));

            // Parse message text into blocks: diff blocks, code blocks, and markdown text
            const parts = message.content.split(/(```[\s\S]*?```)/g);

            return (
              <>
                {parts.map((part, pIdx) => {
                  if (part.startsWith('```diff')) {
                    const diffLines = part.replace(/^```diff\r?\n/, '').replace(/\r?\n```$/, '').split('\n');
                    return (
                      <div
                        key={pIdx}
                        className="my-2 rounded-xl border border-zinc-700/80 bg-zinc-950 font-mono text-xs overflow-hidden shadow-inner"
                      >
                        <div className="bg-zinc-900 px-3 py-1.5 border-b border-zinc-800 text-[11px] font-semibold text-zinc-400 flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-cyan-400">
                            <FileDiff className="w-3.5 h-3.5" /> File Diff Inspection
                          </span>
                        </div>
                        <div className="p-3 overflow-x-auto max-h-80 overflow-y-auto space-y-0.5">
                          {diffLines.map((line, lIdx) => {
                            const isAdd = line.startsWith('+') && !line.startsWith('+++');
                            const isDel = line.startsWith('-') && !line.startsWith('---');
                            const isHunk = line.startsWith('@@');
                            return (
                              <div
                                key={lIdx}
                                className={`px-2 py-0.5 rounded leading-relaxed ${
                                  isAdd
                                    ? 'bg-emerald-950/40 text-emerald-300 font-medium'
                                    : isDel
                                    ? 'bg-rose-950/40 text-rose-300 font-medium'
                                    : isHunk
                                    ? 'text-cyan-400 font-bold bg-cyan-950/20'
                                    : 'text-zinc-400'
                                }`}
                              >
                                {line || ' '}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  }

                  if (part.startsWith('```')) {
                    const codeContent = part.replace(/^```[a-zA-Z0-9_-]*\r?\n/, '').replace(/\r?\n```$/, '');
                    return (
                      <pre
                        key={pIdx}
                        className="my-2 p-3 rounded-xl bg-zinc-950 text-zinc-200 border border-zinc-800 font-mono text-xs overflow-x-auto whitespace-pre-wrap"
                      >
                        {codeContent}
                      </pre>
                    );
                  }

                  // Standard text: parse download links or render text
                  return (
                    <div key={pIdx} className="whitespace-pre-wrap leading-relaxed">
                      {part}
                    </div>
                  );
                })}

                {/* Interactive Direct Proposal Approval Actions in Chat */}
                {proposalMatches.length > 0 && (
                  <div className="mt-3 p-3 rounded-xl bg-indigo-950/30 border border-indigo-800/60 space-y-2">
                    <div className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-indigo-400" />
                      <span>รายการข้อเสนอที่รอการอนุมัติ (Proposal Approval Gate):</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {proposalMatches.map((propId) => {
                        const isApplied = appliedProposals[propId];
                        const isBusy = approvingId === propId;
                        return (
                          <div
                            key={propId}
                            className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 p-2 rounded-lg text-xs"
                          >
                            <span className="font-mono text-zinc-300">{propId}</span>
                            {isApplied ? (
                              <span className="inline-flex items-center gap-1 text-emerald-400 font-medium text-xs px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800">
                                <CheckCircle2 className="w-3.5 h-3.5" /> อนุมัติและสร้าง Checkpoint แล้ว
                              </span>
                            ) : (
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => handleApproveProposal(propId)}
                                className="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                              >
                                {isBusy ? (
                                  <span>กำลังอนุมัติ...</span>
                                ) : (
                                  <>
                                    <Check className="w-3.5 h-3.5" />
                                    <span>อนุมัติ (Approve & Checkpoint)</span>
                                  </>
                                )}
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Visual Task & Plans Card with Step Completion Progress Bar */}
                {detectedPlanIds.length > 0 ? (
                  detectedPlanIds.map((pId) => (
                    <TaskPlanCard key={pId} planId={pId} rawText={message.content} onExecute={onExecutePlan} />
                  ))
                ) : hasMarkdownChecklist && isAgent ? (
                  <TaskPlanCard rawText={message.content} onExecute={onExecutePlan} />
                ) : null}

                {/* Prominent Download ZIP Button if approved download is suggested */}
                {message.memoryProvenance && message.memoryProvenance.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5" aria-label="Memory provenance">
                    {message.memoryProvenance.map((item, index) => (
                      <span key={`${item.provenanceKind}-${index}`} className="inline-flex items-center gap-1 rounded border px-2 py-0.5 text-[10px]" title={item.evidence || 'Evidence source unavailable'}>
                        <span className={`font-bold ${item.confidenceTag === 'HIGH' ? 'text-emerald-400' : item.confidenceTag === 'MEDIUM' ? 'text-amber-400' : 'text-rose-400'}`}>{item.confidenceTag}</span>
                        <span className="text-zinc-400">{item.provenanceKind}</span>
                        <Info className="h-3 w-3 text-zinc-500" aria-label={`Evidence: ${item.evidence}`} />
                      </span>
                    ))}
                  </div>
                )}

                {(message.content.includes('/api/workspace/download-zip') ||
                  message.content.includes('ดาวน์โหลด ZIP') ||
                  proposalMatches.length > 0) && (
                  <div className="pt-2">
                    <a
                      href="/api/workspace/download-zip"
                      download="zyntheor-approved-project.zip"
                      className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-700 hover:bg-emerald-900 text-emerald-200 text-xs font-semibold shadow-sm transition-all cursor-pointer"
                      title="ดาวน์โหลดเฉพาะโค้ดที่ได้รับการอนุมัติแล้ว (Approved Workspace Only)"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>ดาวน์โหลดโปรเจกต์เป็น ZIP (เฉพาะโค้ดที่อนุมัติแล้ว)</span>
                    </a>
                  </div>
                )}
              </>
            );
          })()}
        </div>

        {/* Summary strip under message if exists */}
        {message.summary && (
          <div className="mt-2 flex items-start gap-2 p-2.5 rounded-xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/40 text-xs text-indigo-900 dark:text-indigo-200">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 mt-0.5 shrink-0" />
            <div className="flex-1">
              <span className="font-semibold text-indigo-700 dark:text-indigo-300 mr-1.5">
                สรุปประเด็นหลัก:
              </span>
              <span>{message.summary}</span>
            </div>
          </div>
        )}

        {/* Bottom Reaction Bar & Floating Action Buttons */}
        <div className="flex items-center flex-wrap gap-2 pt-1">
          {/* Active Reaction Chips with hover scale */}
          {Object.entries(reactionsMap).map(([emoji, count]) => {
            if (count <= 0) return null;
            const hasUserReacted = userReactions.includes(emoji as ReactionEmoji);
            return (
              <button
                key={emoji}
                onClick={() => onToggleReaction(message.id, emoji as ReactionEmoji)}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border transition-all duration-150 transform hover:scale-105 ${
                  hasUserReacted
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-300 dark:border-indigo-700 text-indigo-700 dark:text-indigo-300 shadow-xs'
                    : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
                title={`คลิกเพื่อ${hasUserReacted ? 'ยกเลิก' : 'เพิ่ม'}ปฏิกิริยา`}
              >
                <span>{emoji}</span>
                <span className="text-[11px]">{count}</span>
              </button>
            );
          })}

          {/* Emoji Picker Button with Floating Menu */}
          <div className="relative">
            <button
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="p-1 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors opacity-70 group-hover:opacity-100"
              title="แสดงความรู้สึก (Reactions)"
            >
              <Smile className="w-4 h-4" />
            </button>

            {showEmojiPicker && (
              <div
                className="absolute z-30 bottom-full mb-1.5 left-0 flex items-center gap-1 p-1.5 bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 animate-in fade-in zoom-in-95 duration-150"
                onMouseLeave={() => setShowEmojiPicker(false)}
              >
                {AVAILABLE_EMOJIS.map((emoji) => {
                  const isSelected = userReactions.includes(emoji);
                  return (
                    <button
                      key={emoji}
                      onClick={() => {
                        onToggleReaction(message.id, emoji);
                        setShowEmojiPicker(false);
                      }}
                      className={`text-base p-1.5 rounded-xl hover:bg-indigo-50 dark:hover:bg-gray-700 hover:scale-125 transition-transform duration-100 ${
                        isSelected ? 'bg-indigo-100/70 dark:bg-indigo-900/50' : ''
                      }`}
                      title={emoji}
                    >
                      {emoji}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Copy Button */}
          <button
            onClick={handleCopy}
            className="p-1 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors opacity-0 group-hover:opacity-100"
            title="คัดลอกข้อความ"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          {/* Option to listen to summary if summary exists */}
          {message.summary && (
            <button
              onClick={() => handleTTS('summary')}
              className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-100 dark:hover:bg-cyan-900/60 border border-cyan-200/60 dark:border-cyan-800/60 transition-colors opacity-0 group-hover:opacity-100 flex items-center gap-1"
              title="ฟังเฉพาะสรุปสาระสำคัญ (Summary First)"
            >
              <Volume2 className="w-3 h-3" />
              <span>สรุป</span>
            </button>
          )}

          {/* Text-to-Speech Read Aloud Full Text */}
          <button
            onClick={() => handleTTS('full')}
            className={`p-1 rounded-lg transition-colors opacity-0 group-hover:opacity-100 ${
              isPlayingAudio
                ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50'
                : 'text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
            title={isPlayingAudio ? 'หยุดอ่าน' : 'อ่านออกเสียงเนื้อหาทั้งหมด'}
          >
            {isPlayingAudio ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Pause / Resume button when playing */}
          {isPlayingAudio && (
            <button
              onClick={handleTogglePause}
              className="p-1 rounded-lg text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/50 transition-colors"
              title={isAudioPaused ? 'เล่นเสียงต่อ' : 'หยุดชั่วคราว'}
            >
              {isAudioPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
            </button>
          )}

          {/* Replay button */}
          {isPlayingAudio && (
            <button
              onClick={handleReplay}
              className="p-1 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
              title="อ่านซ้ำตั้งแต่ต้น"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
