import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Clock,
  Play,
  RotateCcw,
  Zap,
  Globe2,
  Copy,
  Check,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Edit2,
  ExternalLink,
  Bell,
  Mail,
  Sliders,
  ChevronRight,
  History,
  FileCode2,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import type { Automation, AutomationTriggerType, AutomationExecutionLog } from '../types/automation';

interface AutomationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerAutomation?: (automation: Automation) => void;
}

const AVAILABLE_ICONS = ['⚡', '⏰', '🔗', '🛡️', '🤖', '🌐', '🚀', '⚙️', '🔍', '💡'];

const QUICK_TEMPLATES = [
  { label: 'ตรวจ Syntax และ Build', prompt: 'รันการตรวจสอบ syntax_check และ build ใน workspace' },
  { label: 'ตรวจสอบสถานะความปลอดภัย', prompt: 'ตรวจสอบความปลอดภัยและ Audit Ledger ของเอเจนต์' },
  { label: 'วิเคราะห์โค้ดและโครงสร้าง', prompt: 'ตรวจสอบไฟล์ทั้งหมดใน workspace และสรุปสถาปัตยกรรมระบบ' },
  { label: 'ซิงค์และตรวจสอบสุขภาพระบบ', prompt: 'ตรวจสุขภาพ local runtime และความพร้อมใช้งานของเครื่องมือ' },
];

export const AutomationsModal: React.FC<AutomationsModalProps> = ({
  isOpen,
  onClose,
  onTriggerAutomation,
}) => {
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorNotice, setErrorNotice] = useState<string>('');
  const [successNotice, setSuccessNotice] = useState<string>('');

  // Form State for Create / Edit Drawer
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formIcon, setFormIcon] = useState<string>('⚡');
  const [formName, setFormName] = useState<string>('');
  const [formTriggerType, setFormTriggerType] = useState<AutomationTriggerType>('webhook');
  const [formTriggerUrl, setFormTriggerUrl] = useState<string>('');
  const [formScheduleInterval, setFormScheduleInterval] = useState<string>('every 1 hour');
  const [formPrompt, setFormPrompt] = useState<string>('');
  const [formMode, setFormMode] = useState<'fast' | 'deep'>('fast');
  const [formPushNotif, setFormPushNotif] = useState<boolean>(true);
  const [formEmailNotif, setFormEmailNotif] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Trigger running state
  const [runningId, setRunningId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // History Drawer for a specific automation
  const [selectedHistoryAutomation, setSelectedHistoryAutomation] = useState<Automation | null>(null);

  // Load automations on modal open
  useEffect(() => {
    if (isOpen) {
      loadAutomations();
    }
  }, [isOpen]);

  const loadAutomations = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/automations');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.automations)) {
          setAutomations(data.automations);
        }
      }
    } catch (err: any) {
      console.warn('Could not load automations from server:', err);
      // Fallback to localStorage if offline
      try {
        const local = localStorage.getItem('zyntheor_automations');
        if (local) {
          setAutomations(JSON.parse(local));
        }
      } catch {}
    } finally {
      setLoading(false);
    }
  };

  const handleOpenCreateForm = () => {
    setEditingId(null);
    setFormIcon('⚡');
    setFormName('');
    setFormTriggerType('webhook');
    setFormTriggerUrl('');
    setFormScheduleInterval('every 1 hour');
    setFormPrompt('');
    setFormMode('fast');
    setFormPushNotif(true);
    setFormEmailNotif(false);
    setIsFormOpen(true);
  };

  const handleOpenEditForm = (auto: Automation) => {
    setEditingId(auto.id);
    setFormIcon(auto.icon || '⚡');
    setFormName(auto.name);
    setFormTriggerType(auto.triggerType);
    setFormTriggerUrl(auto.triggerUrl || '');
    setFormScheduleInterval(auto.scheduleInterval || 'every 1 hour');
    setFormPrompt(auto.prompt);
    setFormMode(auto.mode);
    setFormPushNotif(auto.notifications.push);
    setFormEmailNotif(auto.notifications.emailOrWebhook);
    setIsFormOpen(true);
  };

  const handleSaveAutomation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setErrorNotice('กรุณากรอกชื่อระบบอัตโนมัติ');
      setTimeout(() => setErrorNotice(''), 3000);
      return;
    }
    if (!formPrompt.trim()) {
      setErrorNotice('กรุณากรอกคำสั่งโปรเจกต์สำหรับเอเจนต์');
      setTimeout(() => setErrorNotice(''), 3000);
      return;
    }

    setIsSaving(true);
    try {
      const payload = {
        name: formName.trim(),
        icon: formIcon,
        triggerType: formTriggerType,
        triggerUrl: formTriggerUrl.trim() || undefined,
        scheduleInterval: formTriggerType === 'schedule' ? formScheduleInterval : undefined,
        prompt: formPrompt.trim(),
        mode: formMode,
        notifications: {
          push: formPushNotif,
          emailOrWebhook: formEmailNotif,
        },
      };

      if (editingId) {
        // Edit existing
        const res = await fetch(`/api/automations/${editingId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          const data = await res.json();
          setAutomations((prev) => prev.map((a) => (a.id === editingId ? data.automation : a)));
          setSuccessNotice(`บันทึกการแก้ไข "${formName}" เรียบร้อยแล้ว`);
          setIsFormOpen(false);
        } else {
          throw new Error('บันทึกไม่สำเร็จ');
        }
      } else {
        // Create new
        const res = await fetch('/api/automations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          const data = await res.json();
          setAutomations((prev) => [data.automation, ...prev]);
          setSuccessNotice(`สร้างระบบอัตโนมัติ "${formName}" สำเร็จแล้ว`);
          setIsFormOpen(false);
        } else {
          throw new Error('สร้างไม่สำเร็จ');
        }
      }
    } catch (err: any) {
      setErrorNotice(err.message || 'เกิดข้อผิดพลาดในการบันทึก');
    } finally {
      setIsSaving(false);
      setTimeout(() => {
        setSuccessNotice('');
        setErrorNotice('');
      }, 3500);
    }
  };

  const handleDeleteAutomation = async (id: string, name: string) => {
    if (!confirm(`คุณต้องการลบระบบอัตโนมัติ "${name}" ใช่หรือไม่?`)) return;
    try {
      const res = await fetch(`/api/automations/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setAutomations((prev) => prev.filter((a) => a.id !== id));
        setSuccessNotice(`ลบระบบอัตโนมัติ "${name}" แล้ว`);
        if (selectedHistoryAutomation?.id === id) {
          setSelectedHistoryAutomation(null);
        }
      }
    } catch (err) {
      setErrorNotice('ไม่สามารถลบระบบอัตโนมัติได้');
    }
    setTimeout(() => {
      setSuccessNotice('');
      setErrorNotice('');
    }, 3000);
  };

  const handleToggleEnable = async (auto: Automation) => {
    const nextState = !auto.enabled;
    try {
      const res = await fetch(`/api/automations/${auto.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: nextState }),
      });
      if (res.ok) {
        const data = await res.json();
        setAutomations((prev) => prev.map((a) => (a.id === auto.id ? data.automation : a)));
        setSuccessNotice(`${nextState ? 'เปิดใช้งาน' : 'ปิดใช้งาน'} "${auto.name}" แล้ว`);
        setTimeout(() => setSuccessNotice(''), 2500);
      }
    } catch (err) {
      setErrorNotice('ไม่สามารถเปลี่ยนสถานะได้');
      setTimeout(() => setErrorNotice(''), 2500);
    }
  };

  const handleTriggerNow = async (auto: Automation) => {
    setRunningId(auto.id);
    try {
      const res = await fetch(`/api/automations/${auto.id}/trigger`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ triggerSource: 'manual' }),
      });
      const data = await res.json();
      if (res.ok && data.automation) {
        setAutomations((prev) => prev.map((a) => (a.id === auto.id ? data.automation : a)));
        if (selectedHistoryAutomation?.id === auto.id) {
          setSelectedHistoryAutomation(data.automation);
        }
        setSuccessNotice(`สั่งรัน "${auto.name}" สำเร็จ (${data.status})`);
        if (onTriggerAutomation) {
          onTriggerAutomation(data.automation);
        }
      } else {
        throw new Error(data.message || data.error || 'การรันล้มเหลว');
      }
    } catch (err: any) {
      setErrorNotice(err.message || 'ไม่สามารถสั่งรันระบบอัตโนมัติได้');
    } finally {
      setRunningId(null);
      setTimeout(() => {
        setSuccessNotice('');
        setErrorNotice('');
      }, 4000);
    }
  };

  const handleCopyTriggerLink = (auto: Automation) => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const fullUrl = auto.triggerUrl?.startsWith('http')
      ? auto.triggerUrl
      : `${origin}${auto.triggerUrl || `/api/automations/${auto.id}/trigger`}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedId(auto.id);
    setSuccessNotice(`คัดลอกลิงก์ทริกเกอร์เรียบร้อยแล้ว: ${fullUrl}`);
    setTimeout(() => {
      setCopiedId(null);
      setSuccessNotice('');
    }, 3000);
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="automations-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-sm"
    >
      <div className="relative w-full max-w-3xl max-h-[92dvh] h-full sm:h-auto rounded-3xl bg-[#070e1e] border border-cyan-500/30 shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col overflow-hidden text-slate-100">
        
        {/* Modal Top Header (Matching Reference Video) */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-cyan-500/20 bg-[#091530]/90">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              aria-label="ปิดหน้าต่างระบบอัตโนมัติ"
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X size={20} />
            </button>
            <h2 id="automations-title" className="text-base sm:text-lg font-bold text-white tracking-wide flex items-center gap-2">
              <span>ระบบอัตโนมัติ</span>
              <span className="text-[11px] font-mono font-normal px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-300">
                {automations.length} รายการ
              </span>
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleOpenCreateForm}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all cursor-pointer"
              title="สร้างระบบอัตโนมัติใหม่"
              aria-label="สร้างระบบอัตโนมัติใหม่"
            >
              <Plus size={16} />
              <span className="hidden sm:inline">ระบบอัตโนมัติใหม่</span>
            </button>
          </div>
        </div>

        {/* Notices */}
        {errorNotice && (
          <div className="mx-4 mt-3 px-3.5 py-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2" role="alert">
            <AlertCircle size={15} className="shrink-0 text-rose-400" />
            <span className="flex-1">{errorNotice}</span>
            <button type="button" onClick={() => setErrorNotice('')} className="p-0.5 hover:text-white">
              <X size={14} />
            </button>
          </div>
        )}
        {successNotice && (
          <div className="mx-4 mt-3 px-3.5 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2" role="status">
            <CheckCircle2 size={15} className="shrink-0 text-emerald-400" />
            <span className="flex-1">{successNotice}</span>
            <button type="button" onClick={() => setSuccessNotice('')} className="p-0.5 hover:text-white">
              <X size={14} />
            </button>
          </div>
        )}

        {/* Modal Main Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400">
              <div className="w-8 h-8 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin mb-3"></div>
              <p className="text-xs">กำลังโหลดระบบอัตโนมัติ…</p>
            </div>
          ) : automations.length === 0 ? (
            /* Empty State Matching the User's Video Exactly */
            <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
              <div className="relative w-20 h-20 rounded-full border-2 border-dashed border-slate-700 flex items-center justify-center text-slate-400 mb-6 bg-slate-900/60 shadow-inner">
                <Clock size={36} className="text-slate-300 stroke-[1.5]" />
                <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 text-xs">
                  <RotateCcw size={13} className="animate-spin-slow" />
                </div>
              </div>

              <h3 className="text-base sm:text-lg font-bold text-slate-100 mb-2">
                เริ่มต้นด้วยการเพิ่มระบบอัตโนมัติ
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md leading-relaxed mb-8">
                สร้างระบบอัตโนมัติตามกำหนดเวลาหรือทริกเกอร์ลิงก์ ที่จะเริ่มทำงานเมื่อมีการเชื่อมต่อหรือคำสั่งสั่งการ
              </p>

              <button
                type="button"
                onClick={handleOpenCreateForm}
                className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-slate-800/90 hover:bg-slate-700/90 border border-slate-600 hover:border-cyan-400 text-white font-medium text-xs sm:text-sm transition-all shadow-md cursor-pointer hover:shadow-[0_0_20px_rgba(6,182,212,0.3)]"
              >
                <Plus size={16} className="text-cyan-400" />
                <span>ระบบอัตโนมัติใหม่</span>
              </button>
            </div>
          ) : (
            /* Automations List */
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>ระบบอัตโนมัติทั้งหมด ({automations.length})</span>
                <span className="text-[11px] text-cyan-400">เชื่อมต่อและสั่งการอัตโนมัติ</span>
              </div>

              <div className="grid grid-cols-1 gap-3.5">
                {automations.map((auto) => {
                  const isRunning = runningId === auto.id;
                  const isCopied = copiedId === auto.id;
                  const logCount = auto.executionLogs?.length || 0;

                  return (
                    <div
                      key={auto.id}
                      className={`p-4 rounded-2xl border transition-all ${
                        auto.enabled
                          ? 'bg-[#091530]/70 border-cyan-500/30 hover:border-cyan-400/60 shadow-sm'
                          : 'bg-slate-900/40 border-slate-800 opacity-70'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        {/* Automation Header Info */}
                        <div className="flex items-start gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-xl bg-slate-800/90 border border-slate-700 flex items-center justify-center text-xl shrink-0">
                            {auto.icon || '⚡'}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="text-sm font-bold text-white truncate max-w-[200px] sm:max-w-md">
                                {auto.name}
                              </h4>
                              <span
                                className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                                  auto.enabled
                                    ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                                    : 'bg-slate-800 border-slate-700 text-slate-400'
                                }`}
                              >
                                {auto.enabled ? 'เปิดใช้งาน' : 'ปิดชั่วคราว'}
                              </span>
                              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300">
                                {auto.mode === 'deep' ? '🧠 ละเอียด' : '⚡ เร็ว'}
                              </span>
                            </div>

                            <p className="text-xs text-slate-300 line-clamp-2 mt-1.5 font-sans leading-relaxed">
                              {auto.prompt}
                            </p>
                          </div>
                        </div>

                        {/* Top Action Toggle */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleToggleEnable(auto)}
                            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                              auto.enabled ? 'bg-cyan-600' : 'bg-slate-700'
                            }`}
                            role="switch"
                            aria-checked={auto.enabled}
                            aria-label={`เปิดหรือปิดระบบอัตโนมัติ ${auto.name}`}
                          >
                            <span
                              className={`block w-4 h-4 rounded-full bg-white transition-transform ${
                                auto.enabled ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        </div>
                      </div>

                      {/* Trigger & Link Bar */}
                      <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 truncate max-w-full sm:max-w-[70%]">
                          <span className="px-2 py-0.5 rounded bg-slate-800/90 text-cyan-400 font-mono text-[10px] border border-slate-700">
                            {auto.triggerType === 'webhook' ? '🔗 Webhook Link' : auto.triggerType === 'schedule' ? `⏰ ${auto.scheduleInterval}` : '⚡ Manual'}
                          </span>
                          <span className="font-mono text-slate-400 truncate text-[10px]" title={auto.triggerUrl}>
                            {auto.triggerUrl || `/api/automations/${auto.id}/trigger`}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 ml-auto">
                          {/* Copy Link Button */}
                          <button
                            type="button"
                            onClick={() => handleCopyTriggerLink(auto)}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-cyan-300 text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer border border-slate-700"
                            title="คัดลอกลิงก์ทริกเกอร์สำหรับเชื่อมต่อกับภายนอก (Webhook URL)"
                          >
                            {isCopied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                            <span>{isCopied ? 'คัดลอกแล้ว' : 'คัดลอกลิงก์'}</span>
                          </button>

                          {/* Trigger Now Button */}
                          <button
                            type="button"
                            onClick={() => handleTriggerNow(auto)}
                            disabled={isRunning || !auto.enabled}
                            className={`px-3 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                              isRunning
                                ? 'bg-cyan-600/50 text-cyan-200 animate-pulse'
                                : auto.enabled
                                ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                            }`}
                          >
                            {isRunning ? (
                              <>
                                <RotateCcw size={12} className="animate-spin" />
                                <span>กำลังรัน…</span>
                              </>
                            ) : (
                              <>
                                <Play size={12} className="fill-current" />
                                <span>รันตอนนี้</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Footer Info: History and Management */}
                      <div className="mt-2.5 pt-2 flex items-center justify-between text-[11px] text-slate-400">
                        <div className="flex items-center gap-2">
                          {auto.lastRunAt ? (
                            <span className="flex items-center gap-1 text-[10px]">
                              <span
                                className={`w-1.5 h-1.5 rounded-full ${
                                  auto.lastRunStatus === 'SUCCESS' ? 'bg-emerald-400' : 'bg-rose-400'
                                }`}
                              />
                              <span>รันล่าสุด: {new Date(auto.lastRunAt).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })} ({auto.lastRunStatus})</span>
                            </span>
                          ) : (
                            <span className="text-slate-500 text-[10px]">ยังไม่เคยรัน</span>
                          )}

                          <button
                            type="button"
                            onClick={() => setSelectedHistoryAutomation(auto)}
                            className="text-cyan-400 hover:underline hover:text-cyan-300 ml-1 text-[10px] flex items-center gap-0.5 cursor-pointer"
                          >
                            <History size={11} />
                            <span>ประวัติ ({logCount})</span>
                          </button>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenEditForm(auto)}
                            className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors"
                            title="แก้ไขระบบอัตโนมัติ"
                            aria-label={`แก้ไข ${auto.name}`}
                          >
                            <Edit2 size={13} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteAutomation(auto.id, auto.name)}
                            className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                            title="ลบระบบอัตโนมัตินี้"
                            aria-label={`ลบ ${auto.name}`}
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Create / Edit Drawer Overlay (Matching Bottom Sheet in Video) */}
        {isFormOpen && (
          <div className="absolute inset-0 z-50 bg-[#070e1e]/95 backdrop-blur-md flex flex-col p-4 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                  aria-label="ย้อนกลับ"
                >
                  <X size={18} />
                </button>
                <h3 className="text-sm sm:text-base font-bold text-white">
                  {editingId ? 'แก้ไขระบบอัตโนมัติ' : 'ระบบอัตโนมัติใหม่'}
                </h3>
              </div>

              <button
                type="button"
                onClick={handleSaveAutomation}
                disabled={isSaving}
                className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer disabled:opacity-50"
              >
                {isSaving ? 'กำลังบันทึก…' : editingId ? 'บันทึก' : 'สร้าง'}
              </button>
            </div>

            <form onSubmit={handleSaveAutomation} className="space-y-5 pt-4 max-w-xl mx-auto w-full">
              {/* Icon Picker */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">ไอคอนระบุระบบ</label>
                <div className="flex items-center gap-2 flex-wrap">
                  {AVAILABLE_ICONS.map((icon) => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => setFormIcon(icon)}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg transition-all ${
                        formIcon === icon
                          ? 'bg-cyan-500/20 border-2 border-cyan-400 scale-110 shadow-[0_0_10px_rgba(6,182,212,0.4)]'
                          : 'bg-slate-800/80 border border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>

              {/* Name */}
              <div>
                <label htmlFor="auto-name" className="block text-xs font-semibold text-slate-300 mb-1.5">
                  ชื่อระบบอัตโนมัติ <span className="text-rose-400">*</span>
                </label>
                <input
                  id="auto-name"
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="เช่น ตรวจสอบความถูกต้องโค้ด, ติดตามสถานะเซิร์ฟเวอร์"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-xs text-white placeholder-slate-500 outline-hidden transition-all"
                />
              </div>

              {/* Trigger Type & Link/Schedule (Matching video) */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold text-slate-300">
                  กำหนดเวลาหรือทริกเกอร์ <span className="text-rose-400">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'webhook', label: '🔗 เว็บฮุก / ลิงก์' },
                    { id: 'schedule', label: '⏰ กำหนดเวลา' },
                    { id: 'event', label: '📁 เมื่อไฟล์เปลี่ยน' },
                    { id: 'manual', label: '⚡ สั่งรันด้วยตนเอง' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setFormTriggerType(t.id as AutomationTriggerType)}
                      className={`px-2.5 py-2 rounded-xl text-center text-xs font-medium border transition-all ${
                        formTriggerType === t.id
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-xs'
                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                {formTriggerType === 'webhook' && (
                  <div>
                    <label htmlFor="auto-url" className="block text-[11px] text-slate-400 mb-1">
                      ลิงก์เชื่อมต่อภายนอก (Webhook URL / External Endpoint)
                    </label>
                    <input
                      id="auto-url"
                      type="text"
                      value={formTriggerUrl}
                      onChange={(e) => setFormTriggerUrl(e.target.value)}
                      placeholder="เช่น /api/automations/... หรือ https://your-ci-service.com/webhook"
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-xs font-mono text-cyan-300 placeholder-slate-500 outline-hidden"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">
                      💡 หากเว้นว่างไว้ ระบบจะสร้าง Sovereign Webhook Endpoint ใน Zyntheor AI Engine ให้อัตโนมัติ
                    </p>
                  </div>
                )}

                {formTriggerType === 'schedule' && (
                  <div>
                    <label htmlFor="auto-schedule" className="block text-[11px] text-slate-400 mb-1">
                      รอบเวลาการทำงาน
                    </label>
                    <select
                      id="auto-schedule"
                      value={formScheduleInterval}
                      onChange={(e) => setFormScheduleInterval(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-xs text-white outline-hidden cursor-pointer"
                    >
                      <option value="every 15 min">ทุก 15 นาที</option>
                      <option value="every 30 min">ทุก 30 นาที</option>
                      <option value="every 1 hour">ทุก 1 ชั่วโมง</option>
                      <option value="every 6 hours">ทุก 6 ชั่วโมง</option>
                      <option value="every 24 hours">ทุกวัน (วันละ 1 ครั้ง)</option>
                    </select>
                  </div>
                )}
              </div>

              {/* Project Command / Prompt (Matching video "คำสั่งโปรเจกต์") */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label htmlFor="auto-prompt" className="text-xs font-semibold text-slate-300">
                    คำสั่งโปรเจกต์ <span className="text-rose-400">*</span>
                  </label>
                  <span className="text-[10px] text-slate-500">บอกเอเจนต์ว่ามันควรทำอะไร</span>
                </div>
                <textarea
                  id="auto-prompt"
                  value={formPrompt}
                  onChange={(e) => setFormPrompt(e.target.value)}
                  rows={4}
                  placeholder="บอกเอเจนต์ว่ามันควรทำอะไร เช่น: ตรวจสอบความถูกต้องของสถาปัตยกรรมเว็บไซต์ รัน syntax_check และบันทึกหลักฐาน"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-xs text-white placeholder-slate-500 outline-hidden resize-none leading-relaxed"
                />

                {/* Quick Templates & Mode Bar */}
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] text-slate-500 font-medium">+ ด่วน:</span>
                    {QUICK_TEMPLATES.map((tmpl) => (
                      <button
                        key={tmpl.label}
                        type="button"
                        onClick={() => setFormPrompt(tmpl.prompt)}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 hover:bg-cyan-950/60 border border-slate-700 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                      >
                        {tmpl.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-1 ml-auto">
                    <span className="text-[10px] text-slate-400 mr-1">โหมด:</span>
                    <button
                      type="button"
                      onClick={() => setFormMode('fast')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold border transition-all ${
                        formMode === 'fast'
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                          : 'bg-slate-800 border-slate-700 text-slate-400'
                      }`}
                    >
                      ⚡ เร็ว
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormMode('deep')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold border transition-all ${
                        formMode === 'deep'
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : 'bg-slate-800 border-slate-700 text-slate-400'
                      }`}
                    >
                      🧠 ละเอียด
                    </button>
                  </div>
                </div>
              </div>

              {/* Notifications Section (Matching video) */}
              <div className="pt-2 border-t border-slate-800/80 space-y-3">
                <span className="block text-xs font-semibold text-slate-300">การแจ้งเตือน</span>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <Bell size={15} className="text-cyan-400" />
                    <div>
                      <div className="text-xs font-medium text-slate-200">พุช (Push Notification)</div>
                      <div className="text-[10px] text-slate-500">แจ้งเตือนในระบบทันทีเมื่อระบบอัตโนมัติทำงานเสร็จ</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormPushNotif(!formPushNotif)}
                    className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                      formPushNotif ? 'bg-cyan-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform ${
                        formPushNotif ? 'translate-x-5' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <Mail size={15} className="text-amber-400" />
                    <div>
                      <div className="text-xs font-medium text-slate-200">อีเมล / เว็บฮุกกลับ (Webhook Callback)</div>
                      <div className="text-[10px] text-slate-500">ส่งผลลัพธ์ผ่าน Webhook payload ไปยังปลายทางที่กำหนด</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormEmailNotif(!formEmailNotif)}
                    className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                      formEmailNotif ? 'bg-cyan-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform ${
                        formEmailNotif ? 'translate-x-5' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSaving ? 'กำลังบันทึก…' : editingId ? 'บันทึกการแก้ไข' : 'สร้างระบบอัตโนมัติ'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Execution History Viewer Drawer */}
        {selectedHistoryAutomation && (
          <div className="absolute inset-0 z-50 bg-[#070e1e]/95 backdrop-blur-md flex flex-col p-4 sm:p-6 overflow-hidden animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedHistoryAutomation(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                  aria-label="ย้อนกลับ"
                >
                  <X size={18} />
                </button>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5">
                    <span>{selectedHistoryAutomation.icon}</span>
                    <span>ประวัติการทำงาน: {selectedHistoryAutomation.name}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    บันทึกหลักฐานจริง {selectedHistoryAutomation.executionLogs?.length || 0} รายการ
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleTriggerNow(selectedHistoryAutomation)}
                disabled={runningId === selectedHistoryAutomation.id || !selectedHistoryAutomation.enabled}
                className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-xs transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Play size={12} className="fill-current" />
                <span>รันตอนนี้</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto pt-4 space-y-3">
              {(!selectedHistoryAutomation.executionLogs || selectedHistoryAutomation.executionLogs.length === 0) ? (
                <div className="py-20 text-center text-slate-500 text-xs">
                  ยังไม่มีประวัติการรันคำสั่งสำหรับระบบอัตโนมัตินี้
                </div>
              ) : (
                selectedHistoryAutomation.executionLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            log.status === 'SUCCESS' ? 'bg-emerald-400' : 'bg-rose-400'
                          }`}
                        />
                        <span className="font-bold text-slate-200">
                          {log.status === 'SUCCESS' ? 'สำเร็จ (VERIFIED)' : 'ล้มเหลว (FAILED)'}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          ผ่าน {log.triggerSource}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
                        <span>{log.durationMs}ms</span>
                        <span>•</span>
                        <span>{new Date(log.triggeredAt).toLocaleString('th-TH')}</span>
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-950 font-mono text-[11px] text-slate-300 leading-relaxed overflow-x-auto whitespace-pre-wrap">
                      {log.outputSummary}
                    </div>

                    {log.evidenceId && (
                      <div className="text-[10px] text-cyan-400/80 font-mono flex items-center gap-1">
                        <ShieldCheck size={11} />
                        <span>Evidence ID: {log.evidenceId}</span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
