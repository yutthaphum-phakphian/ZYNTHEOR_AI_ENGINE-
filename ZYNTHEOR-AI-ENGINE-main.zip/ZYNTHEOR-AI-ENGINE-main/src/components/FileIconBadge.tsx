import React from 'react';
import {
  FileText,
  FileCode,
  FileCode2,
  FileJson,
  Image as ImageIcon,
  FileAudio,
  FileVideo,
  Archive,
  FileSpreadsheet,
  File as GenericFile,
} from 'lucide-react';
import { AttachedFile } from '../types/agent';

interface FileIconBadgeProps {
  file: AttachedFile | { name: string; extension: string; fileTypeCategory?: string };
  size?: 'sm' | 'md' | 'lg';
  showExtensionText?: boolean;
}

export const FileIconBadge: React.FC<FileIconBadgeProps> = ({
  file,
  size = 'md',
  showExtensionText = true,
}) => {
  const ext = file.extension ? file.extension.toLowerCase() : '';

  // Determine Icon, color styling, and label
  let IconComponent = GenericFile;
  let bgClass = 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700';
  let badgeColor = 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
  let extLabel = ext.toUpperCase() || 'FILE';

  if (ext === 'pdf') {
    IconComponent = FileText;
    bgClass = 'bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 border-rose-200 dark:border-rose-800';
    badgeColor = 'bg-rose-500 text-white';
    extLabel = 'PDF';
  } else if (['js', 'jsx'].includes(ext)) {
    IconComponent = FileCode2;
    bgClass = 'bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400 border-amber-200 dark:border-amber-800';
    badgeColor = 'bg-amber-500 text-white';
    extLabel = ext.toUpperCase();
  } else if (['ts', 'tsx'].includes(ext)) {
    IconComponent = FileCode2;
    bgClass = 'bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 border-blue-200 dark:border-blue-800';
    badgeColor = 'bg-blue-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['py', 'rb', 'php', 'go', 'rs', 'c', 'cpp', 'java'].includes(ext)) {
    IconComponent = FileCode;
    bgClass = 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800';
    badgeColor = 'bg-indigo-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['html', 'css', 'scss', 'vue'].includes(ext)) {
    IconComponent = FileCode;
    bgClass = 'bg-cyan-50 text-cyan-600 dark:bg-cyan-950/40 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800';
    badgeColor = 'bg-cyan-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['json', 'yaml', 'yml', 'xml', 'toml'].includes(ext)) {
    IconComponent = FileJson;
    bgClass = 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800';
    badgeColor = 'bg-emerald-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['txt', 'md', 'markdown', 'log'].includes(ext)) {
    IconComponent = FileText;
    bgClass = 'bg-slate-50 text-slate-700 dark:bg-slate-900/60 dark:text-slate-300 border-slate-200 dark:border-slate-700';
    badgeColor = 'bg-slate-600 text-white';
    extLabel = ext === 'markdown' ? 'MD' : ext.toUpperCase();
  } else if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp'].includes(ext)) {
    IconComponent = ImageIcon;
    bgClass = 'bg-cyan-50 text-cyan-600 dark:bg-cyan-950/40 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800';
    badgeColor = 'bg-cyan-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['mp3', 'wav', 'ogg', 'm4a', 'flac'].includes(ext)) {
    IconComponent = FileAudio;
    bgClass = 'bg-teal-50 text-teal-600 dark:bg-teal-950/40 dark:text-teal-400 border-teal-200 dark:border-teal-800';
    badgeColor = 'bg-teal-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['mp4', 'webm', 'mov', 'avi'].includes(ext)) {
    IconComponent = FileVideo;
    bgClass = 'bg-pink-50 text-pink-600 dark:bg-pink-950/40 dark:text-pink-400 border-pink-200 dark:border-pink-800';
    badgeColor = 'bg-pink-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) {
    IconComponent = Archive;
    bgClass = 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border-amber-300 dark:border-amber-800';
    badgeColor = 'bg-amber-600 text-white';
    extLabel = ext.toUpperCase();
  } else if (['csv', 'xlsx', 'xls'].includes(ext)) {
    IconComponent = FileSpreadsheet;
    bgClass = 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400 border-green-300 dark:border-green-800';
    badgeColor = 'bg-green-600 text-white';
    extLabel = ext.toUpperCase();
  }

  const iconSizes = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
    lg: 'w-5 h-5',
  };

  const containerSizes = {
    sm: 'p-1 rounded',
    md: 'p-1.5 rounded-md',
    lg: 'p-2 rounded-lg',
  };

  return (
    <div className={`relative inline-flex items-center justify-center border ${containerSizes[size]} ${bgClass} shrink-0 shadow-xs transition-transform duration-150`}>
      <IconComponent className={iconSizes[size]} />
      {showExtensionText && (
        <span
          className={`absolute -bottom-1 -right-1 text-[8px] font-extrabold px-0.5 rounded shadow-xs tracking-wider leading-none uppercase ${badgeColor}`}
          style={{ transform: 'scale(0.85)' }}
        >
          {extLabel.slice(0, 4)}
        </span>
      )}
    </div>
  );
};
