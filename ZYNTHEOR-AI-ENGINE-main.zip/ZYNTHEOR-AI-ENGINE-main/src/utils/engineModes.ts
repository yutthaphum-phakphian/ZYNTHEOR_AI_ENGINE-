/**
 * Engine modes shared by the chat mode sheet and the legacy selector.
 * Only modes with real backend behavior are selectable; the rest are listed as unsupported, never as working.
 */
export type EngineChoice = 'auto' | 'fast' | 'deep' | 'coding' | 'review' | 'custom' | 'planning';

/** Values accepted by the Core's /api/chat `mode` (see server/engineRoutes.ts ALLOWED_MODES). */
export type ChatApiMode = 'auto' | 'code' | 'review' | 'custom' | 'plan';

export const toChatMode = (c: EngineChoice): ChatApiMode =>
  c === 'coding' ? 'code' : c === 'review' ? 'review' : c === 'custom' ? 'custom' : c === 'planning' ? 'plan' : 'auto';

export const toPreferredDepth = (c: EngineChoice): 'FAST' | 'DEEP' | undefined =>
  c === 'fast' ? 'FAST' : c === 'deep' ? 'DEEP' : undefined;

export interface EngineModeOption {
  id: EngineChoice;
  th: string;
  en: string;
  /** What the mode really does in the Core. */
  descriptionTh: string;
}

export const ENGINE_MODE_OPTIONS: EngineModeOption[] = [
  { id: 'auto', th: 'อัตโนมัติ', en: 'Auto', descriptionTh: 'สนทนา ถามตอบ และให้ระบบเลือกความลึกเอง' },
  { id: 'planning', th: 'วางแผน', en: 'Planning', descriptionTh: 'เสนอขั้นตอน ผลกระทบ ความเสี่ยง และการทดสอบ ให้อนุมัติก่อนส่งไป Build' },
  { id: 'coding', th: 'Coding', en: 'Coding', descriptionTh: 'ช่วยเขียนและอธิบายโค้ด' },
  { id: 'review', th: 'Review', en: 'Review', descriptionTh: 'ตรวจทานแบบอ่านอย่างเดียว ไม่แก้ไฟล์' },
  { id: 'fast', th: 'Fast', en: 'Fast', descriptionTh: 'ขอคำตอบเร็ว (เป็นคำแนะนำ ระบบอาจคงความลึกสูงตามความเสี่ยง)' },
  { id: 'deep', th: 'Deep Reasoning', en: 'Deep Reasoning', descriptionTh: 'ขอการคิดเชิงลึก (เป็นคำแนะนำ)' },
  { id: 'custom', th: 'Custom', en: 'Custom', descriptionTh: 'กำหนดนโยบายเอง: ความลึก ตัวเชื่อมต่อ การอนุมัติ' },
];

/** Listed so users see what is not available yet. Never selectable. */
export const UNSUPPORTED_MODES: Array<{ id: string; th: string }> = [
  { id: 'analyze', th: 'Analyze' },
  { id: 'research', th: 'Research' },
  { id: 'debug', th: 'Debug' },
  { id: 'creative', th: 'Creative' },
];

export const modeLabel = (id: EngineChoice): string => ENGINE_MODE_OPTIONS.find((o) => o.id === id)?.th ?? id;
