export type ChannelState = 'idle' | 'saving' | 'saved' | 'error';

export interface SaveChannel {
  state: ChannelState;
  /** epoch ms of the last successful save on this channel */
  at: number | null;
}

export type SaveTone = 'idle' | 'saving' | 'saved' | 'partial' | 'error';

export interface SaveSummary {
  tone: SaveTone;
  text: string;
  detail: string;
}

export const IDLE_CHANNEL: SaveChannel = { state: 'idle', at: null };

export function formatClock(ms: number): string {
  return new Date(ms).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}

/**
 * Combines the two persistence channels into one honest label.
 * "Saved" is only ever reported after a channel actually completed successfully.
 */
export function summarizeSaveStatus(local: SaveChannel, server: SaveChannel): SaveSummary {
  if (local.state === 'error') {
    return { tone: 'error', text: 'บันทึกไม่สำเร็จ', detail: 'บันทึกลง localStorage ไม่สำเร็จ' };
  }
  if (server.state === 'error') {
    return local.state === 'saved'
      ? { tone: 'partial', text: 'บันทึกในเครื่องแล้ว · เซิร์ฟเวอร์ไม่สำเร็จ', detail: 'localStorage สำเร็จ แต่ซิงก์ไปเซิร์ฟเวอร์ไม่สำเร็จ' }
      : { tone: 'error', text: 'ซิงก์เซิร์ฟเวอร์ไม่สำเร็จ', detail: 'ซิงก์ไปเซิร์ฟเวอร์ไม่สำเร็จ' };
  }
  if (local.state === 'saving' || server.state === 'saving') {
    return { tone: 'saving', text: 'กำลังบันทึก…', detail: 'กำลังบันทึกเซสชัน' };
  }
  const times = [local.at, server.at].filter((t): t is number => typeof t === 'number');
  if (times.length === 0) return { tone: 'idle', text: 'ยังไม่ได้บันทึก', detail: 'ยังไม่มีการบันทึกในรอบนี้' };
  const where =
    local.at !== null && server.at !== null ? 'เครื่อง + เซิร์ฟเวอร์' : local.at !== null ? 'เฉพาะในเครื่อง (localStorage)' : 'เฉพาะเซิร์ฟเวอร์';
  return { tone: 'saved', text: `บันทึกแล้ว ${formatClock(Math.max(...times))}`, detail: where };
}
