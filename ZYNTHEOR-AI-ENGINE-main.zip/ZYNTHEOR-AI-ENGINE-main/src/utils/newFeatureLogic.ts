import { ChatMessage, ChatSession } from '../types/agent';

export const AUTO_BACKUP_INTERVAL_MS = 5 * 60 * 1000;

export function createAutoBackupSnapshot(session: ChatSession, savedAt: string = new Date().toISOString()) {
  return { version: 1, savedAt, session };
}

export function filterAndGroupPlans<T extends { title: string; description?: string; status: string; updatedAt: string }>(
  plans: T[], query = '', status = 'all', groupBy: 'none' | 'status' | 'date' = 'none', locale = 'th-TH'
): Record<string, T[]> {
  const normalized = query.trim().toLowerCase();
  const filtered = plans.filter((plan) =>
    (status === 'all' || plan.status === status) &&
    (!normalized || `${plan.title} ${plan.description || ''} ${plan.status}`.toLowerCase().includes(normalized))
  );
  if (groupBy === 'none') return { 'รายการทั้งหมด': filtered };
  return filtered.reduce<Record<string, T[]>>((groups, plan) => {
    const key = groupBy === 'status' ? plan.status : new Date(plan.updatedAt).toLocaleDateString(locale);
    (groups[key] ||= []).push(plan);
    return groups;
  }, {});
}

export function reorderById<T extends { id: string }>(items: T[], draggedId: string, targetId: string): T[] {
  const from = items.findIndex((item) => item.id === draggedId);
  const to = items.findIndex((item) => item.id === targetId);
  if (from < 0 || to < 0 || from === to) return items;
  const next = [...items];
  const [moved] = next.splice(from, 1);
  next.splice(to, 0, moved);
  return next;
}

export function plansToMarkdown<T extends { title: string; status: string; progress: number; steps: Array<{ title: string; status: string }> }>(plans: T[]): string {
  return plans.map((plan) => `## ${plan.title}\nสถานะ: ${plan.status}\nความคืบหน้า: ${plan.progress}%\n\n${plan.steps.map((step) => `- [${step.status === 'done' ? 'x' : ' '}] ${step.title}`).join('\n')}`).join('\n\n');
}

export interface VersionRecord { id: string; content: string; createdAt: string; note: string; }
export function appendVersion(history: VersionRecord[], content: string, now = new Date().toISOString()): VersionRecord[] {
  return [{ id: `v_${Date.parse(now) || Date.now()}`, content, createdAt: now, note: 'บันทึกจาก Code Studio' }, ...history].slice(0, 20);
}

export interface LedgerLikeEvent {
  type: string;
  planId?: string;
  timestamp?: string;
  data?: Record<string, unknown>;
  details?: Record<string, unknown> | string;
}

function eventData(event: LedgerLikeEvent): Record<string, unknown> {
  return event.data || (typeof event.details === 'object' ? event.details : undefined) || {};
}

export function findHighRiskRetries(events: LedgerLikeEvent[]): LedgerLikeEvent[] {
  const ordered = [...events].sort((first, second) =>
    new Date(first.timestamp || 0).getTime() - new Date(second.timestamp || 0).getTime()
  );

  return ordered.filter((event, index) => {
    if (!event.type.toUpperCase().includes('RETRY')) return false;

    const payload = eventData(event);
    const fromState = String(payload.fromState || payload.previousState || payload.stateBefore || '').toUpperCase();
    const toState = String(payload.toState || payload.currentState || payload.state || '').toUpperCase();
    if (payload.stateUnchanged === true || payload.noStateChange === true || payload.retryWithoutStateChange === true) {
      return true;
    }
    if (fromState && toState) return fromState === toState;

    const eventId = event.planId || payload.taskId;
    if (!eventId || !toState) return false;
    const previous = ordered.slice(0, index).reverse().find((candidate) => {
      const candidateData = eventData(candidate);
      return (candidate.planId || candidateData.taskId) === eventId;
    });
    if (!previous) return false;

    const previousData = eventData(previous);
    const previousState = previousData.toState || previousData.state;
    return Boolean(previousState && toState === String(previousState).toUpperCase());
  });
}

export function deriveAssistantInsights(messages: ChatMessage[]) {
  const keyPoints = messages.slice(-3).map((message) => message.summary || message.content.replace(/[#*_`]/g, '').slice(0, 90)).filter(Boolean);
  const pending = messages.filter((message) => message.sender === 'user' && /สร้าง|แก้|ตรวจ|วางแผน|todo|implement/i.test(message.content)).slice(-3).map((message) => message.content.replace(/\s+/g, ' ').slice(0, 80));
  return { keyPoints, pending };
}

export function addSessionTag(existingTags: string[] | undefined, newTag: string): string[] {
  const clean = newTag.trim().replace(/^#+/, '');
  if (!clean) return existingTags ? [...existingTags] : [];
  const current = existingTags || [];
  if (current.includes(clean)) return [...current];
  return [...current, clean];
}

export function removeSessionTag(existingTags: string[] | undefined, tagToRemove: string): string[] {
  if (!existingTags) return [];
  const clean = tagToRemove.trim().replace(/^#+/, '');
  return existingTags.filter((t) => t !== clean && t !== tagToRemove);
}

export function filterSessionsByQueryAndTag(
  sessions: ChatSession[],
  query = '',
  selectedTag?: string | null
): ChatSession[] {
  const q = query.trim().toLowerCase();
  return sessions.filter((s) => {
    const matchesTag = !selectedTag || (s.tags && s.tags.includes(selectedTag));
    if (!matchesTag) return false;
    if (!q) return true;
    const inTitle = s.title.toLowerCase().includes(q);
    const inSummary = Boolean(s.summary && s.summary.toLowerCase().includes(q));
    const inTags = Boolean(s.tags && s.tags.some((t) => t.toLowerCase().includes(q)));
    return inTitle || inSummary || inTags;
  });
}

export function formatAutoSaveIndicator(
  lastSavedTimestamp: number,
  isSaving = false,
  locale = 'th-TH'
): { label: string; tooltip: string; status: 'saving' | 'saved' } {
  if (isSaving) {
    return {
      label: 'กำลังบันทึก...',
      tooltip: 'กำลังบันทึกลง localStorage',
      status: 'saving',
    };
  }
  const formattedTime = new Date(lastSavedTimestamp).toLocaleTimeString(locale, {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  return {
    label: 'บันทึกอัตโนมัติแล้ว',
    tooltip: `บันทึกลง localStorage แล้วเมื่อ ${formattedTime}`,
    status: 'saved',
  };
}

export type DateRangePreset = 'all' | 'today' | 'week' | 'month' | 'custom';

export interface SessionFilterOptions {
  query?: string;
  selectedTags?: string[];
  dateRangePreset?: DateRangePreset;
  customDateFrom?: string; // YYYY-MM-DD
  customDateTo?: string;   // YYYY-MM-DD
  now?: number;
}

export function isSessionWithinDateRange(
  createdAt: number,
  preset: DateRangePreset = 'all',
  customDateFrom?: string,
  customDateTo?: string,
  now = Date.now()
): boolean {
  if (preset === 'all') return true;

  const createdDate = new Date(createdAt);

  if (preset === 'today') {
    const nowDate = new Date(now);
    return (
      createdDate.getFullYear() === nowDate.getFullYear() &&
      createdDate.getMonth() === nowDate.getMonth() &&
      createdDate.getDate() === nowDate.getDate()
    );
  }

  if (preset === 'week') {
    const sevenDaysAgo = now - 7 * 24 * 60 * 60 * 1000;
    return createdAt >= sevenDaysAgo && createdAt <= now + 60000;
  }

  if (preset === 'month') {
    const thirtyDaysAgo = now - 30 * 24 * 60 * 60 * 1000;
    return createdAt >= thirtyDaysAgo && createdAt <= now + 60000;
  }

  if (preset === 'custom') {
    if (!customDateFrom && !customDateTo) return true;
    const fromTime = customDateFrom ? new Date(customDateFrom).setHours(0, 0, 0, 0) : 0;
    const toTime = customDateTo ? new Date(customDateTo).setHours(23, 59, 59, 999) : Infinity;
    return createdAt >= fromTime && createdAt <= toTime;
  }

  return true;
}

export function filterSessionsExtended(
  sessions: ChatSession[],
  options: SessionFilterOptions = {}
): ChatSession[] {
  const {
    query = '',
    selectedTags = [],
    dateRangePreset = 'all',
    customDateFrom,
    customDateTo,
    now = Date.now(),
  } = options;

  const q = query.trim().toLowerCase();

  return sessions.filter((s) => {
    // 1. Tag matching: if selectedTags has items, session must contain all selected tags
    if (selectedTags.length > 0) {
      const sTags = s.tags || [];
      const hasAllTags = selectedTags.every((t) => sTags.includes(t));
      if (!hasAllTags) return false;
    }

    // 2. Creation Date range matching
    if (!isSessionWithinDateRange(s.createdAt, dateRangePreset, customDateFrom, customDateTo, now)) {
      return false;
    }

    // 3. Keyword search (matches title, summary, custom tags, or messages)
    if (q) {
      const inTitle = s.title.toLowerCase().includes(q);
      const inSummary = Boolean(s.summary && s.summary.toLowerCase().includes(q));
      const inTags = Boolean(s.tags && s.tags.some((t) => t.toLowerCase().includes(q)));
      const inMessages = Boolean(s.messages && s.messages.some((m) => m.content.toLowerCase().includes(q)));
      if (!inTitle && !inSummary && !inTags && !inMessages) {
        return false;
      }
    }

    return true;
  });
}

export interface QuickReplyItem {
  id: string;
  label: string;
  prompt: string;
  icon?: string;
  category?: 'plan' | 'code' | 'test' | 'general' | 'audit';
}

export function generateQuickReplies(
  lastAgentMessage?: string,
  lang: 'th' | 'en' = 'th'
): QuickReplyItem[] {
  const isTh = lang === 'th';
  if (!lastAgentMessage || !lastAgentMessage.trim()) {
    return [
      {
        id: 'qr-plan-time',
        label: isTh ? '⏱️ วางแผนตรวจสอบเวลา (/plan time)' : '⏱️ Create Time Plan (/plan time)',
        prompt: '/plan time',
        category: 'plan',
      },
      {
        id: 'qr-run-test',
        label: isTh ? '🧪 รันการทดสอบในระบบ (/test)' : '🧪 Run Sandbox Tests (/test)',
        prompt: '/test',
        category: 'test',
      },
      {
        id: 'qr-explain-arch',
        label: isTh ? '🛡️ อธิบายโมเดลความปลอดภัย Zero Fake' : '🛡️ Explain Zero Fake Model',
        prompt: isTh
          ? 'ช่วยอธิบายสถาปัตยกรรมระบบและโมเดลความปลอดภัย Zero Fake ของ Zyntheor'
          : 'Explain the Zyntheor architecture and Zero Fake verification model',
        category: 'audit',
      },
    ];
  }

  const content = lastAgentMessage.toLowerCase();

  // Scenario 1: Plan created or discussed (/plan, plan hash, steps, sha-256)
  if (content.includes('plan:') || content.includes('/plan') || content.includes('plan hash') || content.includes('ขั้นตอน:')) {
    return [
      {
        id: 'qr-verify-ledger',
        label: isTh ? '🛡️ ตรวจสอบ Plan กับ Audit Ledger' : '🛡️ Verify Plan with Audit Ledger',
        prompt: isTh
          ? 'ช่วยตรวจสอบความสมบูรณ์ของแผนงานนี้เทียบกับ Cryptographic Audit Ledger'
          : 'Verify this plan against the Cryptographic Audit Ledger',
        category: 'audit',
      },
      {
        id: 'qr-execute-steps',
        label: isTh ? '⚡ ดำเนินการและบันทึกหลักฐานจริง' : '⚡ Execute and Record Real Evidence',
        prompt: isTh
          ? 'ขออนุมัติและดำเนินการขั้นตอนในแผนงานนี้ พร้อมบันทึกผลตรวจสอบลง Ledger'
          : 'Request approval and execute the plan steps with verifiable evidence',
        category: 'plan',
      },
      {
        id: 'qr-explain-steps',
        label: isTh ? '📋 สรุปรายละเอียดแต่ละขั้นตอน' : '📋 Summarize Step Details',
        prompt: isTh
          ? 'ช่วยสรุปรายละเอียด วัตถุประสงค์ และ Criteria ของแต่ละขั้นตอนในแผนงานนี้'
          : 'Summarize the objectives and criteria of each step in this plan',
        category: 'plan',
      },
    ];
  }

  // Scenario 2: Sandbox or test results (FAIL, VERIFIED, exitCode, syntax_check, etc.)
  if (content.includes('[fail]') || content.includes('ผลการรัน sandbox') || content.includes('[verified]') || content.includes('exitcode')) {
    if (content.includes('[fail]') || content.includes('failed')) {
      return [
        {
          id: 'qr-diagnose-root-cause',
          label: isTh ? '🔍 วินิจฉัย Root Cause และแนวทางแก้' : '🔍 Diagnose Root Cause & Fix',
          prompt: isTh
            ? 'ช่วยวินิจฉัย Root Cause ของข้อผิดพลาดนี้ และเสนอแนวทางแก้ไขที่ปลอดภัย'
            : 'Diagnose the root cause of this failure and suggest a safe fix',
          category: 'test',
        },
        {
          id: 'qr-retry-sandbox-test',
          label: isTh ? '🧪 รันการทดสอบซ้ำ (/test)' : '🧪 Re-run Sandbox Tests (/test)',
          prompt: '/test',
          category: 'test',
        },
        {
          id: 'qr-typecheck-system',
          label: isTh ? '📐 ตรวจสอบ Type ด้วย TypeScript (/typecheck)' : '📐 Typecheck with TypeScript (/typecheck)',
          prompt: '/typecheck',
          category: 'code',
        },
      ];
    }

    return [
      {
        id: 'qr-check-build',
        label: isTh ? '📦 ตรวจสอบ Build และ Manifest (/build)' : '📦 Check Build & Manifest (/build)',
        prompt: '/build',
        category: 'code',
      },
      {
        id: 'qr-download-zip',
        label: isTh ? '💾 ดาวน์โหลด ZIP โครงการที่ผ่านการรับรอง' : '💾 Download Verified Project ZIP',
        prompt: isTh
          ? 'โปรดยืนยันลิงก์ดาวน์โหลด ZIP โครงการที่ผ่านการตรวจสอบ Sandbox แล้ว'
          : 'Please confirm download link for the approved project ZIP',
        category: 'general',
      },
      {
        id: 'qr-plan-next-feature',
        label: isTh ? '🚀 วางแผนงานสำหรับฟีเจอร์ถัดไป (/plan)' : '🚀 Plan Next Feature (/plan)',
        prompt: isTh
          ? '/plan วางแผนพัฒนาระบบและปรับปรุงประสิทธิภาพต่อเนื่อง'
          : '/plan Design and implement next system feature',
        category: 'plan',
      },
    ];
  }

  // Scenario 3: Code / Function / TypeScript implementation or explanation
  if (content.includes('```') || content.includes('function') || content.includes('typescript') || content.includes('refactor') || content.includes('interface')) {
    return [
      {
        id: 'qr-unit-tests',
        label: isTh ? '🧪 เขียน Unit Test ครอบคลุม Edge Cases' : '🧪 Write Comprehensive Unit Tests',
        prompt: isTh
          ? 'ช่วยเขียน Unit Test สำหรับฟังก์ชันนี้โดยครอบคลุม edge cases และ error handling'
          : 'Write unit tests for this code covering edge cases and error handling',
        category: 'code',
      },
      {
        id: 'qr-security-audit',
        label: isTh ? '🛡️ วิเคราะห์ความปลอดภัยและการป้องกัน Injection' : '🛡️ Analyze Security & Injections',
        prompt: isTh
          ? 'ช่วยวิเคราะห์ความปลอดภัย การป้องกัน Injection และการ Redact Secret ของโค้ดนี้'
          : 'Analyze security, injection prevention, and secret redaction for this code',
        category: 'audit',
      },
      {
        id: 'qr-plan-refactor',
        label: isTh ? '⚡ สร้างแผนงาน Refactor ให้มีประสิทธิภาพยิ่งขึ้น' : '⚡ Create Refactoring Plan',
        prompt: isTh
          ? '/plan ตรวจสอบและ Refactor โค้ดนี้เพื่อเพิ่มประสิทธิภาพและความปลอดภัย'
          : '/plan Review and refactor this code for performance and security',
        category: 'plan',
      },
    ];
  }

  // Scenario 4: Unavailable or blocked
  if (content.includes('unavailable') || content.includes('blocked')) {
    return [
      {
        id: 'qr-try-plan-goal',
        label: isTh ? '⏱️ ใช้คำสั่ง /plan เพื่อทำงานแบบยืนยันหลักฐาน' : '⏱️ Use /plan for verified workflow',
        prompt: '/plan time',
        category: 'plan',
      },
      {
        id: 'qr-check-supported-tools',
        label: isTh ? '🛠️ ตรวจสอบรายการเครื่องมือที่รองรับในระบบ' : '🛠️ List Supported Tools',
        prompt: isTh
          ? 'ช่วยแสดงรายการเครื่องมือและขีดความสามารถที่รองรับในระบบปัจจุบัน'
          : 'List supported tools and capabilities in this workspace',
        category: 'general',
      },
      {
        id: 'qr-run-sandbox-check',
        label: isTh ? '🔍 ตรวจสอบความถูกต้องของโปรเจกต์ (/syntax)' : '🔍 Check Project Syntax (/syntax)',
        prompt: '/syntax',
        category: 'test',
      },
    ];
  }

  // Default scenario (always exactly 3 relevant suggestions)
  return [
    {
      id: 'qr-def-plan',
      label: isTh ? '⏱️ สร้างแผนงานตรวจสอบ (/plan time)' : '⏱️ Create Audit Plan (/plan time)',
      prompt: '/plan time',
      category: 'plan',
    },
    {
      id: 'qr-def-test',
      label: isTh ? '🧪 ตรวจสอบและรันเทสต์ใน Sandbox (/test)' : '🧪 Run Sandbox Tests (/test)',
      prompt: '/test',
      category: 'test',
    },
    {
      id: 'qr-def-arch',
      label: isTh ? '📐 วิเคราะห์สถาปัตยกรรมและไฟล์ในระบบ' : '📐 Analyze Architecture & Files',
      prompt: isTh
        ? 'ช่วยวิเคราะห์โครงสร้างไฟล์และสถาปัตยกรรมปัจจุบันของโปรเจกต์'
        : 'Analyze the project file structure and current architecture',
      category: 'code',
    },
  ];
}


