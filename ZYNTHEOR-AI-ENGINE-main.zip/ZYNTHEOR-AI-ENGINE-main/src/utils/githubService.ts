export interface WeeklyCommitMetric {
  week: string;
  commits: number;
  label?: string;
}

export interface IssueResolutionMetric {
  category: string;
  avgDurationDays: number;
  avgDurationHours: number;
  count: number;
}

export interface RepositoryMetricsData {
  owner: string;
  repo: string;
  totalCommits: number;
  avgResolutionDays: number;
  closedIssuesCount: number;
  weeklyCommits: WeeklyCommitMetric[];
  issueResolutions: IssueResolutionMetric[];
  fetchedAt: string;
  source: 'api';
}

export async function fetchRepositoryMetrics(repoFullName: string): Promise<RepositoryMetricsData> {
  const [owner, repo, ...extra] = repoFullName.trim().split('/');
  if (!owner || !repo || extra.length > 0) {
    throw new Error('Repository must be specified as owner/repo');
  }

  const query = new URLSearchParams({ owner, repo });
  const response = await fetch(`/api/engine/connectors/github/metrics?${query.toString()}`);
  if (!response.ok) {
    throw new Error(`GitHub repository metrics request failed (${response.status})`);
  }

  const data = (await response.json()) as Omit<RepositoryMetricsData, 'source'>;
  return {
    owner: data.owner,
    repo: data.repo,
    totalCommits: data.totalCommits,
    avgResolutionDays: data.avgResolutionDays,
    closedIssuesCount: data.closedIssuesCount,
    weeklyCommits: data.weeklyCommits,
    issueResolutions: data.issueResolutions,
    fetchedAt: data.fetchedAt,
    source: 'api',
  };
}