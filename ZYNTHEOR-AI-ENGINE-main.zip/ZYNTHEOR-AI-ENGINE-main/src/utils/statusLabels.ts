export type HealthState = 'loading' | 'ready' | 'error';

export interface StatusView {
  ok: boolean;
  label: string;
  tone: 'ok' | 'bad' | 'idle';
}

/** Server is "ready" only when /api/health actually answered successfully. */
export function deriveServerStatus(healthState: HealthState): StatusView {
  if (healthState === 'ready') return { ok: true, label: 'พร้อม', tone: 'ok' };
  if (healthState === 'error') return { ok: false, label: 'ไม่ตอบสนอง', tone: 'bad' };
  return { ok: false, label: 'กำลังตรวจสอบ', tone: 'idle' };
}

/**
 * Model is "ready" only with evidence from /api/local-model/status: the runtime answered
 * AND it reports at least one installed model. Server health is never used here.
 */
export function deriveModelStatus(local: { connected?: boolean; models?: unknown } | null | undefined): StatusView {
  const count = Array.isArray(local?.models) ? (local!.models as unknown[]).length : 0;
  if (local?.connected === true && count > 0) {
    return { ok: true, label: `พร้อม (${count} โมเดล)`, tone: 'ok' };
  }
  return { ok: false, label: 'UNAVAILABLE', tone: local ? 'bad' : 'idle' };
}
