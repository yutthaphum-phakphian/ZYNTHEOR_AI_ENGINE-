export interface EnvironmentVariableStatus {
  name: string;
  required: boolean;
  configured: boolean;
}
export interface EnvironmentFeatureStatus {
  name: string;
  available: boolean;
  reason: string;
}
export interface EnvironmentStatus {
  status: 'ready' | 'needs_configuration' | 'unavailable';
  variables: EnvironmentVariableStatus[];
  missing: string[];
  features: EnvironmentFeatureStatus[];
}

/** Read secret-safe environment diagnostics from the backend; values are never returned. */
export async function checkEnvironmentStatus(fetchImpl: typeof fetch = fetch): Promise<EnvironmentStatus> {
  const response = await fetchImpl('/api/environment-status', { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`Environment status unavailable (${response.status})`);
  return response.json() as Promise<EnvironmentStatus>;
}
