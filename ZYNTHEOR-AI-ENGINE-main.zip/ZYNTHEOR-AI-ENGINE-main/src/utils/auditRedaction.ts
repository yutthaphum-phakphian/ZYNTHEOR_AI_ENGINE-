/**
 * Audit Ledger Sensitive Data Detection & Redaction Engine
 * Automatically detects and redacts API keys, credentials, tokens, and passwords
 * before rendering in the Cryptographic Audit Ledger and export dumps.
 */

/**
 * Detects if a string or value contains sensitive credentials, API keys, or tokens
 */
export function containsSensitiveData(value: unknown): boolean {
  if (value === null || value === undefined) return false;
  const str = typeof value === 'string' ? value : JSON.stringify(value);
  const secretPattern =
    /(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|passwd|secret|private[_-]?key)\s*[:=]\s*[^\s,;"]+|Bearer\s+[A-Za-z0-9._~+/-]{16,})/i;
  return secretPattern.test(str);
}

/**
 * Automatically detects and redacts sensitive strings and API key patterns
 * before rendering into the audit ledger UI.
 */
export function redactSensitiveLog(value: unknown): string {
  if (value === null || value === undefined) return '';
  const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
  return text
    .replace(/\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,})\b/gi, '[REDACTED_API_KEY]')
    .replace(/\b(?:gh[pousr]_[A-Za-z0-9]{20,})\b/gi, '[REDACTED_GH_TOKEN]')
    .replace(/\b(?:AKIA[0-9A-Z]{16})\b/gi, '[REDACTED_AWS_KEY]')
    .replace(/\bBearer\s+[A-Za-z0-9._~+/-]{16,}=*/gi, 'Bearer [REDACTED_TOKEN]')
    .replace(
      /\b(([A-Za-z0-9_]*?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|passwd|secret|private[_-]?key|auth))\s*[:=]\s*)[^\s,;"]+/gi,
      '$1[REDACTED]'
    )
    .replace(
      /("?(?:apiKey|accessToken|refreshToken|clientSecret|password|secret|token|authToken)"?\s*:\s*)"[^"]+"/gi,
      '$1"[REDACTED]"'
    );
}

/**
 * Recursively deep-redacts sensitive patterns in structured event data
 */
export function sanitizeLogData<T>(data: T): T {
  if (data === null || data === undefined) return data;
  if (typeof data === 'string') {
    return redactSensitiveLog(data) as unknown as T;
  }
  if (Array.isArray(data)) {
    return data.map((item) => sanitizeLogData(item)) as unknown as T;
  }
  if (typeof data === 'object') {
    const clean: Record<string, any> = {};
    for (const [key, val] of Object.entries(data)) {
      if (
        typeof val === 'string' &&
        /(?:password|passwd|secret|apiKey|api_key|token|access_token|private_key|awsKey|githubToken)/i.test(key)
      ) {
        clean[key] = '[REDACTED]';
      } else {
        clean[key] = sanitizeLogData(val);
      }
    }
    return clean as unknown as T;
  }
  return data;
}
