/**
 * Client-side mirror of the server's chat attachment policy (GET /api/chat/attachment-policy).
 * This only gives early feedback; the server re-validates every file and is the only authority.
 */
export interface AttachmentPolicy {
  maxFiles: number;
  maxFileBytes: number;
  maxTotalBytes: number;
  allowedExtensions: string[];
  imagesSupported: boolean;
  authRequired: boolean;
  tokenState: 'configured' | 'not_configured' | 'invalid';
  available: boolean;
}

export const API_TOKEN_STORAGE_KEY = 'zyntheor.apiToken';

export function fileExtension(name: string): string {
  const base = name.split(/[\\/]/).pop() || '';
  const dot = base.lastIndexOf('.');
  if (dot > 0) return base.slice(dot).toLowerCase();
  return base.startsWith('.') ? base.toLowerCase() : '';
}

export function formatKb(bytes: number): string {
  return bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.ceil(bytes / 1024)} KB`;
}

/** Returns a Thai reason string if the file must be refused, otherwise null. */
export function validateCandidate(
  file: { name: string; size: number; type?: string },
  policy: AttachmentPolicy,
  staged: { size?: number }[],
): string | null {
  if (!policy.imagesSupported && (file.type || '').startsWith('image/')) {
    return 'ระบบยังวิเคราะห์รูปภาพไม่ได้ (ไม่มี vision model) จึงแนบรูปไม่ได้';
  }
  if (staged.length >= policy.maxFiles) return `แนบได้สูงสุด ${policy.maxFiles} ไฟล์ต่อข้อความ`;
  if (file.size === 0) return 'ไฟล์ว่างเปล่า';
  if (file.size > policy.maxFileBytes) return `ไฟล์ใหญ่เกิน ${formatKb(policy.maxFileBytes)} (ไฟล์นี้ ${formatKb(file.size)})`;
  const ext = fileExtension(file.name);
  if (!policy.allowedExtensions.includes(ext)) return `ชนิดไฟล์ ${ext || '(ไม่มีนามสกุล)'} ไม่รองรับ (รองรับเฉพาะข้อความ/โค้ด)`;
  const total = staged.reduce((n, f) => n + (f.size || 0), 0) + file.size;
  if (total > policy.maxTotalBytes) return `ขนาดรวมเกิน ${formatKb(policy.maxTotalBytes)}`;
  return null;
}
