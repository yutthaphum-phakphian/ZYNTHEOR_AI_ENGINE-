import { AttachedFile, FileExtensionType } from '../types/agent';

export function getFileExtension(filename: string): string {
  const parts = filename.split('.');
  if (parts.length <= 1) return '';
  return parts.pop()?.toLowerCase() || '';
}

export function categorizeExtension(ext: string): FileExtensionType {
  const e = ext.toLowerCase();
  if (e === 'pdf') return 'pdf';
  if (['js', 'jsx', 'ts', 'tsx', 'html', 'css', 'scss', 'py', 'go', 'rs', 'c', 'cpp', 'java', 'php', 'rb', 'sh', 'sql'].includes(e)) {
    return 'code';
  }
  if (['json', 'yaml', 'yml', 'xml', 'toml'].includes(e)) {
    return 'json';
  }
  if (['txt', 'md', 'markdown', 'rtf', 'log', 'doc', 'docx'].includes(e)) {
    return 'text';
  }
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico'].includes(e)) {
    return 'image';
  }
  if (['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'].includes(e)) {
    return 'audio';
  }
  if (['mp4', 'webm', 'mov', 'avi', 'mkv'].includes(e)) {
    return 'video';
  }
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(e)) {
    return 'archive';
  }
  if (['csv', 'xlsx', 'xls', 'tsv'].includes(e)) {
    return 'spreadsheet';
  }
  return 'generic';
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

export async function processFileToAttachedFile(file: File): Promise<AttachedFile> {
  const extension = getFileExtension(file.name);
  const fileTypeCategory = categorizeExtension(extension);
  const id = `file_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

  let textSnippet: string | undefined = undefined;
  let dataUrl: string | undefined = undefined;

  // Read preview if text or image
  if (file.type.startsWith('image/')) {
    dataUrl = await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => resolve(undefined);
      reader.readAsDataURL(file);
    });
  } else if (
    fileTypeCategory === 'code' ||
    fileTypeCategory === 'json' ||
    fileTypeCategory === 'text' ||
    file.type.startsWith('text/')
  ) {
    textSnippet = await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        const text = reader.result as string;
        resolve(text.slice(0, 1500)); // preview first 1.5k chars
      };
      reader.onerror = () => resolve(undefined);
      reader.readAsText(file.slice(0, 8000));
    });
  }

  return {
    id,
    name: file.name,
    size: file.size,
    type: file.type || 'application/octet-stream',
    extension,
    fileTypeCategory,
    dataUrl,
    previewUrl: dataUrl,
    textSnippet,
    uploadedAt: Date.now(),
    status: 'ready',
  };
}
