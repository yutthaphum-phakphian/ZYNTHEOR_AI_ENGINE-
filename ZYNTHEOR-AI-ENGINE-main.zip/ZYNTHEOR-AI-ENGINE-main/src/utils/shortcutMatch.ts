export interface ShortcutKeys {
  /** KeyboardEvent.code, e.g. 'KeyN', 'Digit1', 'Slash' (layout independent, safe with Alt on macOS). */
  code: string;
  alt?: boolean;
  ctrl?: boolean;
  shift?: boolean;
}

export function matchesShortcut(
  e: { code: string; altKey: boolean; ctrlKey: boolean; metaKey: boolean; shiftKey: boolean },
  s: ShortcutKeys,
): boolean {
  return e.code === s.code && e.altKey === !!s.alt && (e.ctrlKey || e.metaKey) === !!s.ctrl && e.shiftKey === !!s.shift;
}
