/**
 * Auto mode: pick a concrete mode from the wording of the request (deterministic, no model call).
 * Falls back to 'chat' when nothing matches. The server still makes its own FAST/DEEP decision.
 * Every choice carries the evidence it was based on, so the UI can show *why* a mode was chosen.
 */
export type DetectedMode = 'chat' | 'web' | 'files' | 'tools' | 'code' | 'analysis';

export interface ModeDetection {
  mode: DetectedMode;
  /** The wording that triggered the chosen mode; null when nothing matched (fallback to chat). */
  matched: string | null;
  /** Every category that matched, in priority order. Length > 1 means the priority order decided. */
  candidates: Array<{ mode: Exclude<DetectedMode, 'chat'>; matched: string }>;
}

/** Priority when several categories match: web > files > code > analysis > tools > chat. */
const RULES: Array<[Exclude<DetectedMode, 'chat'>, RegExp]> = [
  ['web', /(https?:\/\/|ค้นเว็บ|ค้นหาเว็บ|ค้นหาข้อมูล|ข่าวล่าสุด|search the web|google|latest news|เว็บไซต์)/i],
  ['files', /(ไฟล์ในเครื่อง|หาไฟล์|ค้นหาไฟล์|โฟลเดอร์|ในโปรเจกต์|find file|local file|folder|directory)/i],
  ['code', /(```|โค้ด|เขียนโปรแกรม|แก้บั๊ก|บั๊ก|debug|refactor|\bbug\b|function\b|typescript|javascript|python|\bcode\b|compile|unit test)/i],
  ['analysis', /(วิเคราะห์|สถิติ|เปรียบเทียบข้อมูล|กราฟ|แนวโน้ม|สรุปตัวเลข|analy[sz]e|analysis|statistics|\bcsv\b|dataset|trend)/i],
  ['tools', /(เครื่องมือ|รันคำสั่ง|สร้างแผน|ตรวจสอบระบบ|\btool\b|run command|execute|build the|\bplan\b)/i],
];

export function detectModeWithEvidence(text: string): ModeDetection {
  const t = (text ?? '').toLowerCase();
  const candidates: ModeDetection['candidates'] = [];
  for (const [mode, re] of RULES) {
    const m = re.exec(t);
    if (m) candidates.push({ mode, matched: m[0].length > 40 ? `${m[0].slice(0, 40)}…` : m[0] });
  }
  if (candidates.length === 0) return { mode: 'chat', matched: null, candidates };
  return { mode: candidates[0].mode, matched: candidates[0].matched, candidates };
}

export function detectModeFromText(text: string): DetectedMode {
  return detectModeWithEvidence(text).mode;
}

/** Thai explanation of an Auto choice, built only from the evidence actually found. */
export function explainAutoChoice(detection: ModeDetection, modeLabel: string): string {
  if (!detection.matched) return `อัตโนมัติ → แชททั่วไป (ไม่พบคำที่ชี้ไปโหมดเฉพาะ)`;
  const base = `อัตโนมัติ → โหมด ${modeLabel} (พบคำว่า "${detection.matched}")`;
  if (detection.candidates.length > 1) {
    const others = detection.candidates.slice(1).map((c) => c.mode).join(', ');
    return `${base} · ตรงหลายหมวด (${others}) เลือกตามลำดับความสำคัญ`;
  }
  return base;
}

/** Manual picks are never overridden by detection. Unknown/legacy stored values are ignored. */
export function restoreManualMode<T extends string>(stored: string | null | undefined, validIds: readonly T[]): T | null {
  return stored && (validIds as readonly string[]).includes(stored) ? (stored as T) : null;
}
