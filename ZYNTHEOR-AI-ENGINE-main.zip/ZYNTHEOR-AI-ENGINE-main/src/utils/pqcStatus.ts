export type PqcSignatureStatus = 'Verified' | 'Pending' | 'Invalid';

/** The only fields the status logic reads (kept dependency-free so it can be unit-tested without React). */
export interface PqcEventLike {
  type?: string;
  data?: Record<string, unknown>;
  [key: string]: unknown;
}

/**
 * PQC status shown to the user.
 *  - Verified: ONLY when the event carries server-side verification evidence (`data.serverVerification.verified === true`)
 *    and was not asserted by a client. Nothing in the app produces that evidence yet, so today no event can be Verified.
 *  - Invalid: an explicit failure / tamper marker (the safe direction to trust).
 *  - Pending: everything else. A signature-looking string, a "verified" word or `verified: true` in a payload is a claim,
 *    not evidence, and never upgrades the status.
 */
export function derivePqcStatus(evt: PqcEventLike | null | undefined): PqcSignatureStatus {
  if (!evt) return 'Pending';
  const data = (evt.data ?? {}) as Record<string, any>;
  const type = String(evt.type ?? '').toUpperCase();

  const rawStatus = (evt as any).pqcStatus || data.pqcStatus || data.pqc_status || data.quantumSigStatus;
  if (typeof rawStatus === 'string') {
    const s = rawStatus.toLowerCase();
    if (s.includes('fail') || s.includes('invalid') || s.includes('tamper') || s.includes('reject')) return 'Invalid';
  }
  const rawSig = (evt as any).pqcSignature || data.pqcSignature || data.signature || data.quantumSig || data['x-zyrquen-sovereign-sig'];
  if (typeof rawSig === 'string' && /INVALID|FAIL|TAMPERED|CORRUPT/i.test(rawSig)) return 'Invalid';
  if (type.includes('REJECTED') || type.includes('TAMPERED') || data.tampered === true) return 'Invalid';

  const serverVerified = data.serverVerification?.verified === true && data.origin !== 'client_asserted';
  return serverVerified ? 'Verified' : 'Pending';
}
