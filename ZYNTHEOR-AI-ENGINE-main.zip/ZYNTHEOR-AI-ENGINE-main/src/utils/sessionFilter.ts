export interface FilterableSession {
  id: string;
  title: string;
  messages: Array<{ content?: string }>;
  tags?: string[];
}

export interface SessionMatch<T extends FilterableSession> {
  session: T;
  /** Snippet of the matching message content, when the match came from content rather than the title. */
  snippet?: string;
}

/** Builds a short snippet around the first occurrence of `needle` (already lower-cased). */
export function makeSnippet(text: string, needle: string, radius = 28): string {
  const idx = text.toLowerCase().indexOf(needle);
  if (idx < 0) return '';
  const start = Math.max(0, idx - radius);
  const end = Math.min(text.length, idx + needle.length + radius);
  return `${start > 0 ? '…' : ''}${text.slice(start, end).replace(/\s+/g, ' ')}${end < text.length ? '…' : ''}`;
}

/** Case-insensitive filter over session title, message content, and tags. Empty query returns everything. */
export function filterSessions<T extends FilterableSession>(
  sessions: T[],
  query: string,
  selectedTag?: string
): SessionMatch<T>[] {
  const cleanTag = selectedTag?.trim().toLowerCase();
  const q = query.trim().toLowerCase();

  // 1. Tag filter pass if selected
  const tagFiltered = cleanTag && cleanTag !== 'all' && cleanTag !== 'ทั้งหมด'
    ? sessions.filter((s) => s.tags?.some((t) => t.toLowerCase() === cleanTag))
    : sessions;

  if (!q) return tagFiltered.map((session) => ({ session }));

  const out: SessionMatch<T>[] = [];
  for (const session of tagFiltered) {
    if (session.title.toLowerCase().includes(q)) {
      out.push({ session });
      continue;
    }
    // Match against auto tags
    if (session.tags?.some((t) => t.toLowerCase().includes(q))) {
      out.push({ session });
      continue;
    }
    for (const m of session.messages) {
      const content = m.content ?? '';
      if (content.toLowerCase().includes(q)) {
        out.push({ session, snippet: makeSnippet(content, q) });
        break;
      }
    }
  }
  return out;
}

