export interface HelpShortcut {
  label: string;
  description: string;
}

/** 'Alt + N' -> ['Alt', 'N'] so each key can be rendered in its own <kbd>. */
export function splitKeys(label: string): string[] {
  return label.split('+').map((k) => k.trim()).filter(Boolean);
}

/** Case-insensitive filter on description or key label. Empty query keeps everything. */
export function filterShortcuts<T extends HelpShortcut>(items: T[], query: string): T[] {
  const q = query.trim().toLowerCase();
  if (!q) return items;
  return items.filter((s) => s.description.toLowerCase().includes(q) || s.label.toLowerCase().includes(q));
}
