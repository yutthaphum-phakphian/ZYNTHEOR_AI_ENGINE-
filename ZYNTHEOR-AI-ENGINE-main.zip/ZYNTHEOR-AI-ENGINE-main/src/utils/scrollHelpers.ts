/** Is the viewport within `threshold` px of the bottom of a scroll container? */
export function isNearBottom(el: { scrollHeight: number; scrollTop: number; clientHeight: number }, threshold = 120): boolean {
  return el.scrollHeight - el.scrollTop - el.clientHeight <= threshold;
}
