import type { MonitoredRepository, GitHubIssue, GitHubPullRequestItem } from '../types/connectors';

export interface AutoSyncReport {
  lastSyncTime: string;
  repo: string;
  status: 'success' | 'error' | 'idle';
  message?: string;
  newIssuesCount: number;
  newPRsCount: number;
}

const AUTO_SYNC_STORAGE_KEY = 'zyntheor_github_autosync_enabled';
const AUTO_SYNC_INTERVAL_KEY = 'zyntheor_github_autosync_interval';
const AUTO_SYNC_LAST_REPORT_KEY = 'zyntheor_github_autosync_last_report';
const KNOWN_ITEMS_PREFIX = 'zyntheor_github_known_';

export function isAutoSyncEnabled(): boolean {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(AUTO_SYNC_STORAGE_KEY) === 'true';
    }
  } catch {
    // fallback
  }
  return false;
}

export function setAutoSyncEnabled(enabled: boolean): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(AUTO_SYNC_STORAGE_KEY, enabled ? 'true' : 'false');
      window.dispatchEvent(new CustomEvent('zyntheor:autosync-config-changed', { detail: { enabled } }));
    }
  } catch {
    // fallback
  }
}

export function getAutoSyncInterval(): number {
  try {
    if (typeof localStorage !== 'undefined') {
      const val = localStorage.getItem(AUTO_SYNC_INTERVAL_KEY);
      if (val) {
        const parsed = parseInt(val, 10);
        if (!isNaN(parsed) && parsed >= 15000) return parsed;
      }
    }
  } catch {
    // fallback
  }
  return 60000; // default 1 minute
}

export function setAutoSyncInterval(intervalMs: number): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(AUTO_SYNC_INTERVAL_KEY, String(intervalMs));
      window.dispatchEvent(new CustomEvent('zyntheor:autosync-config-changed', { detail: { intervalMs } }));
    }
  } catch {
    // fallback
  }
}

export function getLastSyncReport(): AutoSyncReport | null {
  try {
    if (typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem(AUTO_SYNC_LAST_REPORT_KEY);
      if (saved) return JSON.parse(saved);
    }
  } catch {
    // fallback
  }
  return null;
}

export function saveLastSyncReport(report: AutoSyncReport): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(AUTO_SYNC_LAST_REPORT_KEY, JSON.stringify(report));
    }
  } catch {
    // fallback
  }
}

/**
 * Checks for newly created issues and pull requests in the monitored repository.
 * Detects items created since the previous sync and notifies the user in chat.
 */
export async function checkGitHubRepoUpdates(
  repo: MonitoredRepository,
  customToken?: string
): Promise<{
  hasUpdates: boolean;
  newIssues: GitHubIssue[];
  newPRs: GitHubPullRequestItem[];
  report: AutoSyncReport;
}> {
  const activeToken =
    customToken ||
    (typeof localStorage !== 'undefined'
      ? localStorage.getItem('zyntheor_github_token') ||
        localStorage.getItem('zyntheor_auth_token') ||
        ''
      : '');

  const headers: Record<string, string> = { Accept: 'application/json' };
  if (activeToken) {
    headers['x-github-token'] = activeToken;
    headers['Authorization'] = `Bearer ${activeToken}`;
  }

  const knownKey = `${KNOWN_ITEMS_PREFIX}${repo.fullName}`;
  let knownIds = new Set<string>();
  let isFirstRunForRepo = false;

  try {
    if (typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem(knownKey);
      if (saved) {
        knownIds = new Set(JSON.parse(saved));
      } else {
        isFirstRunForRepo = true;
      }
    }
  } catch {
    // fallback
  }

  try {
    const res = await fetch(
      `/api/engine/connectors/github/activity?owner=${encodeURIComponent(repo.owner)}&repo=${encodeURIComponent(repo.name)}`,
      { headers }
    );

    if (!res.ok) {
      throw new Error(`Activity fetch failed: HTTP ${res.status}`);
    }

    const data = await res.json();
    const fetchedIssues: GitHubIssue[] = Array.isArray(data.issues) ? data.issues : [];
    const fetchedPRs: GitHubPullRequestItem[] = Array.isArray(data.pullRequests) ? data.pullRequests : [];

    const newIssues: GitHubIssue[] = [];
    const newPRs: GitHubPullRequestItem[] = [];

    // Collect all current IDs
    const currentIds = new Set<string>();

    fetchedIssues.forEach((issue) => {
      const idKey = `issue_${issue.number}`;
      currentIds.add(idKey);
      if (!isFirstRunForRepo && !knownIds.has(idKey)) {
        newIssues.push(issue);
      }
    });

    fetchedPRs.forEach((pr) => {
      const idKey = `pr_${pr.number}`;
      currentIds.add(idKey);
      if (!isFirstRunForRepo && !knownIds.has(idKey)) {
        newPRs.push(pr);
      }
    });

    // Save current IDs
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(knownKey, JSON.stringify(Array.from(currentIds)));
      }
    } catch {
      // fallback
    }

    const hasUpdates = newIssues.length > 0 || newPRs.length > 0;
    const report: AutoSyncReport = {
      lastSyncTime: new Date().toLocaleTimeString(),
      repo: repo.fullName,
      status: 'success',
      message: hasUpdates
        ? `Found ${newIssues.length} new issues and ${newPRs.length} new PRs`
        : 'All issues and pull requests are up to date',
      newIssuesCount: newIssues.length,
      newPRsCount: newPRs.length,
    };

    saveLastSyncReport(report);

    // If new items were detected, notify via window event for the chat session to receive
    if (hasUpdates && typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('zyntheor:github-sync-notification', {
          detail: {
            repo,
            newIssues,
            newPRs,
            timestamp: new Date().toISOString(),
          },
        })
      );
    }

    return { hasUpdates, newIssues, newPRs, report };
  } catch (err: any) {
    const report: AutoSyncReport = {
      lastSyncTime: new Date().toLocaleTimeString(),
      repo: repo.fullName,
      status: 'error',
      message: err.message || 'Auto-sync failed',
      newIssuesCount: 0,
      newPRsCount: 0,
    };
    saveLastSyncReport(report);
    return { hasUpdates: false, newIssues: [], newPRs: [], report };
  }
}
