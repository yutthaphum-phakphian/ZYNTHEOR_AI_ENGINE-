// Accessible replacement for window.alert(): publishes a message that
// <StatusBanner /> (mounted once in App) renders with aria-live.
export type NoticeKind = 'info' | 'success' | 'error';
export interface Notice { id: number; kind: NoticeKind; message: string }

type Listener = (notice: Notice) => void;
const listeners = new Set<Listener>();
let counter = 0;

export function notify(message: string, kind: NoticeKind = 'info'): void {
  const notice: Notice = { id: ++counter, kind, message };
  listeners.forEach((l) => l(notice));
}

export function subscribeNotices(listener: Listener): () => void {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}
