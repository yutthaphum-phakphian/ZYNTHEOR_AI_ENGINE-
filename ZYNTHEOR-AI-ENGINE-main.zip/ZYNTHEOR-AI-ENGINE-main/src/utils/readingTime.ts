const WORDS_PER_MINUTE = 200;

type Segment = { isWordLike?: boolean };

type SegmenterConstructor = new (
  locales?: string | string[],
  options?: { granularity?: 'grapheme' | 'word' | 'sentence' },
) => { segment: (input: string) => Iterable<Segment> };

function countWithSegmenter(text: string): number | null {
  const Segmenter = (Intl as typeof Intl & { Segmenter?: SegmenterConstructor }).Segmenter;
  if (!Segmenter) return null;

  const segmenter = new Segmenter(undefined, { granularity: 'word' });
  return Array.from(segmenter.segment(text)).filter((segment) => segment.isWordLike).length;
}

/** Count readable words across space-delimited and Thai/CJK text. */
export function countReadableWords(text: string): number {
  const normalized = text.replace(/```[\s\S]*?```/g, ' ').replace(/https?:\/\/\S+/g, ' ').trim();
  if (!normalized) return 0;

  const segmentedCount = countWithSegmenter(normalized);
  if (segmentedCount !== null) return segmentedCount;

  const westernWords = normalized.match(/[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*/g)?.length ?? 0;
  const thaiAndCjkCharacters = normalized.match(/[\u0E00-\u0E7F\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF]/g)?.length ?? 0;
  return westernWords + Math.ceil(thaiAndCjkCharacters / 6);
}

/** Return a reader-friendly whole-minute estimate. Empty replies still need a one-minute badge. */
export function estimateReadingMinutes(text: string, wordsPerMinute = WORDS_PER_MINUTE): number {
  const safeWpm = Number.isFinite(wordsPerMinute) && wordsPerMinute > 0 ? wordsPerMinute : WORDS_PER_MINUTE;
  return Math.max(1, Math.ceil(countReadableWords(text) / safeWpm));
}

export function formatReadingTime(text: string): string {
  return `อ่าน ~${estimateReadingMinutes(text)} นาที`;
}
