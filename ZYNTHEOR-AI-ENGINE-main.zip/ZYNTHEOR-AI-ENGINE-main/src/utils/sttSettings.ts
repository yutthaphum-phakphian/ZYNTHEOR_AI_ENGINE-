/**
 * Speech-to-Text (STT) Settings & Persistence Engine
 * Supports selecting input language, continuous listening toggle,
 * and adjustable speech detection sensitivity.
 */

export type STTLanguageCode = 'th-TH' | 'en-US' | 'en-GB' | 'ja-JP' | 'zh-CN' | 'de-DE' | 'fr-FR' | 'auto';
export type STTSensitivityLevel = 'low' | 'medium' | 'high';

export interface STTLanguageOption {
  code: string;
  label: string;
  nativeLabel: string;
  flag: string;
}

export const STT_LANGUAGES: STTLanguageOption[] = [
  { code: 'th-TH', label: 'Thai', nativeLabel: 'ภาษาไทย (ไทย)', flag: '🇹🇭' },
  { code: 'en-US', label: 'English (US)', nativeLabel: 'English (United States)', flag: '🇺🇸' },
  { code: 'en-GB', label: 'English (UK)', nativeLabel: 'English (United Kingdom)', flag: '🇬🇧' },
  { code: 'ja-JP', label: 'Japanese', nativeLabel: '日本語 (ญี่ปุ่น)', flag: '🇯🇵' },
  { code: 'zh-CN', label: 'Chinese (Simplified)', nativeLabel: '中文 (จีนตัวย่อ)', flag: '🇨🇳' },
  { code: 'de-DE', label: 'German', nativeLabel: 'Deutsch (เยอรมัน)', flag: '🇩🇪' },
  { code: 'fr-FR', label: 'French', nativeLabel: 'Français (ฝรั่งเศส)', flag: '🇫🇷' },
];

export interface STTSettings {
  inputLanguage: string;
  continuousListening: boolean;
  sensitivity: number; // 0 - 100%
  sensitivityLevel: STTSensitivityLevel;
  silenceTimeoutMs: number;
  autoSendOnSpeechEnd: boolean;
  filterLowConfidence: boolean;
}

export const DEFAULT_STT_SETTINGS: STTSettings = {
  inputLanguage: 'th-TH',
  continuousListening: true,
  sensitivity: 65,
  sensitivityLevel: 'medium',
  silenceTimeoutMs: 2500,
  autoSendOnSpeechEnd: false,
  filterLowConfidence: true,
};

const STORAGE_KEY = 'zyntheor_stt_settings';

export function deriveSensitivityLevel(val: number): STTSensitivityLevel {
  if (val <= 40) return 'low';
  if (val <= 75) return 'medium';
  return 'high';
}

export function deriveSilenceTimeoutMs(sensitivity: number): number {
  // Higher sensitivity = faster finalization / shorter silence threshold (1200ms - 3500ms)
  const clamped = Math.max(10, Math.min(100, sensitivity));
  return Math.round(3800 - (clamped / 100) * 2300);
}

export function getSTTSettings(): STTSettings {
  if (typeof window === 'undefined' || !window.localStorage) {
    return { ...DEFAULT_STT_SETTINGS };
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_STT_SETTINGS };
    const parsed = JSON.parse(raw);
    const sensitivity = typeof parsed.sensitivity === 'number' && parsed.sensitivity >= 0 && parsed.sensitivity <= 100
      ? parsed.sensitivity
      : DEFAULT_STT_SETTINGS.sensitivity;

    return {
      ...DEFAULT_STT_SETTINGS,
      ...parsed,
      sensitivity,
      sensitivityLevel: deriveSensitivityLevel(sensitivity),
      silenceTimeoutMs: deriveSilenceTimeoutMs(sensitivity),
      continuousListening: typeof parsed.continuousListening === 'boolean'
        ? parsed.continuousListening
        : DEFAULT_STT_SETTINGS.continuousListening,
      inputLanguage: typeof parsed.inputLanguage === 'string' && parsed.inputLanguage.trim()
        ? parsed.inputLanguage.trim()
        : DEFAULT_STT_SETTINGS.inputLanguage,
    };
  } catch {
    return { ...DEFAULT_STT_SETTINGS };
  }
}

export function saveSTTSettings(settings: Partial<STTSettings>): STTSettings {
  const current = getSTTSettings();
  const mergedSensitivity = typeof settings.sensitivity === 'number'
    ? Math.max(0, Math.min(100, settings.sensitivity))
    : current.sensitivity;

  const updated: STTSettings = {
    ...current,
    ...settings,
    sensitivity: mergedSensitivity,
    sensitivityLevel: deriveSensitivityLevel(mergedSensitivity),
    silenceTimeoutMs: deriveSilenceTimeoutMs(mergedSensitivity),
  };

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      window.dispatchEvent(new CustomEvent('zyntheor-stt-settings-updated', { detail: updated }));
    } catch (e) {
      console.warn('Failed to save STT settings to localStorage:', e);
    }
  }

  return updated;
}
