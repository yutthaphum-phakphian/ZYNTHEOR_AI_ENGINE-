/**
 * Voice Interaction & Thai Speech Synthesis Engine
 * Provides centralized configuration for Thai & English voice models, speaking rates,
 * pitch, volume, automatic response playback, secrets redaction, and speech deduplication.
 */

export interface VoiceSettings {
  enabled: boolean;
  autoReadResponses: boolean;
  autoReadMode: 'summary' | 'full';
  speakingRate: number; // 0.5 to 2.0
  pitch: number; // 0.5 to 1.5
  volume: number; // 0.0 to 1.0
  thaiVoiceURI: string;
  englishVoiceURI: string;
  preferredLang: 'th-TH' | 'en-US' | 'auto';
  alertOnBlockedOrApproval: boolean;
  restrictToNonSensitive: boolean; // Enforce skipping messages containing detected secrets or API key patterns
}

export const DEFAULT_VOICE_SETTINGS: VoiceSettings = {
  enabled: true,
  autoReadResponses: false,
  autoReadMode: 'summary',
  speakingRate: 1.0,
  pitch: 1.0,
  volume: 1.0,
  thaiVoiceURI: '',
  englishVoiceURI: '',
  preferredLang: 'auto',
  alertOnBlockedOrApproval: true,
  restrictToNonSensitive: true,
};

const STORAGE_KEY = 'zyntheor_voice_settings';

// Speech deduplication state
let lastSpokenText = '';
let lastSpokenTimestamp = 0;
const DEDUPLICATION_INTERVAL_MS = 3500;

// Real-time TTS engine status & buffer error state
let activeTTSBufferStatus: 'idle' | 'speaking' | 'paused' | 'error' = 'idle';
let activeTTSError: string | null = null;
let skippedSensitiveMessagesCount = 0;

export interface TTSEngineState {
  isSpeaking: boolean;
  isPaused: boolean;
  hasThaiVoice: boolean;
  thaiVoiceName?: string;
  lastError: string | null;
  bufferStatus: 'idle' | 'speaking' | 'paused' | 'error';
  skippedSensitiveCount: number;
}

export function getTTSEngineState(): TTSEngineState {
  const isSpeaking = typeof window !== 'undefined' && 'speechSynthesis' in window ? window.speechSynthesis.speaking : false;
  const isPaused = typeof window !== 'undefined' && 'speechSynthesis' in window ? window.speechSynthesis.paused : false;

  return {
    isSpeaking,
    isPaused,
    hasThaiVoice: false, // Updated asynchronously via getThaiVoiceStatus
    lastError: activeTTSError,
    bufferStatus: activeTTSError ? 'error' : isSpeaking ? (isPaused ? 'paused' : 'speaking') : 'idle',
    skippedSensitiveCount: skippedSensitiveMessagesCount,
  };
}

export function clearTTSError(): void {
  activeTTSError = null;
  if (activeTTSBufferStatus === 'error') {
    activeTTSBufferStatus = 'idle';
  }
  notifyTTSEngineState();
}

function notifyTTSEngineState(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('zyntheor-tts-engine-state', {
        detail: getTTSEngineState(),
      })
    );
  }
}

export function getVoiceSettings(): VoiceSettings {
  if (typeof window === 'undefined' || !window.localStorage) {
    return { ...DEFAULT_VOICE_SETTINGS };
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_VOICE_SETTINGS };
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_VOICE_SETTINGS,
      ...parsed,
      restrictToNonSensitive: typeof parsed.restrictToNonSensitive === 'boolean'
        ? parsed.restrictToNonSensitive
        : DEFAULT_VOICE_SETTINGS.restrictToNonSensitive,
      speakingRate: typeof parsed.speakingRate === 'number' && parsed.speakingRate >= 0.5 && parsed.speakingRate <= 2.0
        ? parsed.speakingRate
        : DEFAULT_VOICE_SETTINGS.speakingRate,
      pitch: typeof parsed.pitch === 'number' && parsed.pitch >= 0.5 && parsed.pitch <= 1.5
        ? parsed.pitch
        : DEFAULT_VOICE_SETTINGS.pitch,
      volume: typeof parsed.volume === 'number' && parsed.volume >= 0 && parsed.volume <= 1.0
        ? parsed.volume
        : DEFAULT_VOICE_SETTINGS.volume,
    };
  } catch {
    return { ...DEFAULT_VOICE_SETTINGS };
  }
}

export function saveVoiceSettings(settings: VoiceSettings): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    window.dispatchEvent(new CustomEvent('zyntheor-voice-settings-updated', { detail: settings }));
  } catch (err) {
    console.warn('Failed to save voice settings:', err);
  }
}

/**
 * Enumerate available speech synthesis voices asynchronously
 */
export function getAvailableVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      resolve([]);
      return;
    }

    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      resolve(voices);
      return;
    }

    const handleVoicesChanged = () => {
      window.speechSynthesis.removeEventListener('voiceschanged', handleVoicesChanged);
      resolve(window.speechSynthesis.getVoices());
    };

    window.speechSynthesis.addEventListener('voiceschanged', handleVoicesChanged);

    setTimeout(() => {
      window.speechSynthesis.removeEventListener('voiceschanged', handleVoicesChanged);
      resolve(window.speechSynthesis.getVoices());
    }, 400);
  });
}

/**
 * Check if the browser actually has a native Thai voice installed
 */
export async function getThaiVoiceStatus(): Promise<{
  hasThaiVoice: boolean;
  voiceName?: string;
  isFallback: boolean;
}> {
  const voices = await getAvailableVoices();
  const thaiVoice = voices.find(
    (v) => v.lang.toLowerCase().startsWith('th') || v.name.toLowerCase().includes('thai')
  );

  if (thaiVoice) {
    return {
      hasThaiVoice: true,
      voiceName: thaiVoice.name,
      isFallback: false,
    };
  }

  return {
    hasThaiVoice: false,
    voiceName: undefined,
    isFallback: true,
  };
}

/**
 * Detect language based on presence of Thai Unicode block
 */
export function detectLanguage(text: string): 'th-TH' | 'en-US' {
  const thaiRegex = /[\u0E00-\u0E7F]/;
  return thaiRegex.test(text) ? 'th-TH' : 'en-US';
}

/**
 * Detect if text contains sensitive keys, tokens, or credentials
 */
export function containsDetectedSecrets(value: string): boolean {
  if (!value) return false;
  const secretPattern = /(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password)\s*[:=]\s*[^\s,;]+|Bearer\s+[A-Za-z0-9._~+/-]{16,})/i;
  return secretPattern.test(value);
}

/**
 * Redact API keys, tokens, and passwords to prevent secret leakage via TTS
 */
export function redactSecretsForSpeech(value: string): string {
  if (!value) return '';
  return value
    .replace(/\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})\b/gi, 'ข้อมูลลับที่ถูกปกปิด')
    .replace(/\b(([A-Z0-9_]*?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|secret))\s*[:=]\s*)[^\s,;]+/gi, '$1ข้อมูลลับ')
    .replace(/\bBearer\s+[A-Za-z0-9._~+/-]+=*/gi, 'Bearer โทเค็นความปลอดภัย');
}

/**
 * Filter and clean text for natural speech (removes markdown symbols, code fences, and secrets)
 */
export function cleanTextForSpeech(text: string): string {
  if (!text) return '';
  const sanitized = redactSecretsForSpeech(text);

  return sanitized
    .replace(/```[\s\S]*?```/g, 'บล็อกโค้ดตัวอย่าง') // replace code blocks
    .replace(/`([^`]+)`/g, '$1') // inline code
    .replace(/[*_~#>-]/g, '') // markdown punctuation
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // links
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Play speech synthesis using configured voice settings with deduplication,
 * sensitive content restriction, and real-time TTS buffer status tracking.
 */
export function speakText(
  text: string,
  options?: Partial<VoiceSettings>,
  onEnd?: () => void,
  onError?: (err: any) => void,
  forcePlay = false
): () => void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    if (onEnd) onEnd();
    return () => {};
  }

  const settings = { ...getVoiceSettings(), ...(options || {}) };
  if (!settings.enabled) {
    if (onEnd) onEnd();
    return () => {};
  }

  // Safety gate: Restrict Voice Output to non-sensitive content
  if (settings.restrictToNonSensitive && containsDetectedSecrets(text)) {
    skippedSensitiveMessagesCount += 1;
    activeTTSError = 'ข้ามการอ่านออกเสียง: ข้อความมีข้อมูลลับหรือ API Keys ที่อาจไม่ปลอดภัยต่อความเป็นส่วนตัว (Sensitive Content Skipped)';
    activeTTSBufferStatus = 'idle';
    notifyTTSEngineState();
    if (onEnd) onEnd();
    return () => {};
  }

  const cleaned = cleanTextForSpeech(text);
  if (!cleaned) {
    if (onEnd) onEnd();
    return () => {};
  }

  // Deduplication guard
  const now = Date.now();
  if (!forcePlay && cleaned === lastSpokenText && now - lastSpokenTimestamp < DEDUPLICATION_INTERVAL_MS) {
    if (onEnd) onEnd();
    return () => {};
  }

  lastSpokenText = cleaned;
  lastSpokenTimestamp = now;

  window.speechSynthesis.cancel();
  activeTTSError = null;
  activeTTSBufferStatus = 'speaking';
  notifyTTSEngineState();

  const utterance = new SpeechSynthesisUtterance(cleaned);
  const lang = settings.preferredLang === 'auto'
    ? detectLanguage(cleaned)
    : settings.preferredLang;

  utterance.lang = lang;
  utterance.rate = settings.speakingRate;
  utterance.pitch = settings.pitch;
  utterance.volume = settings.volume;

  // Resolve voice
  const allVoices = window.speechSynthesis.getVoices();
  const targetURI = lang.startsWith('th') ? settings.thaiVoiceURI : settings.englishVoiceURI;

  if (targetURI) {
    const matched = allVoices.find((v) => v.voiceURI === targetURI);
    if (matched) utterance.voice = matched;
  }

  if (!utterance.voice) {
    const langPrefix = lang.split('-')[0].toLowerCase();
    const fallback = allVoices.find((v) => v.lang.toLowerCase().startsWith(langPrefix));
    if (fallback) utterance.voice = fallback;
  }

  utterance.onstart = () => {
    activeTTSBufferStatus = 'speaking';
    activeTTSError = null;
    notifyTTSEngineState();
  };

  utterance.onpause = () => {
    activeTTSBufferStatus = 'paused';
    notifyTTSEngineState();
  };

  utterance.onresume = () => {
    activeTTSBufferStatus = 'speaking';
    notifyTTSEngineState();
  };

  utterance.onend = () => {
    activeTTSBufferStatus = 'idle';
    notifyTTSEngineState();
    if (onEnd) onEnd();
  };

  utterance.onerror = (e) => {
    activeTTSBufferStatus = 'error';
    activeTTSError = e.error ? `ข้อผิดพลาด TTS: ${e.error}` : 'เกิดข้อผิดพลาดในการสังเคราะห์เสียง';
    notifyTTSEngineState();
    if (onError) onError(e);
    else if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);

  return () => {
    window.speechSynthesis.cancel();
    activeTTSBufferStatus = 'idle';
    notifyTTSEngineState();
  };
}

export function stopSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function pauseSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.pause();
  }
}

export function resumeSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.resume();
  }
}

export function isSpeakingPaused(): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false;
  return window.speechSynthesis.paused;
}

export function isSpeakingActive(): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false;
  return window.speechSynthesis.speaking;
}

export function replayLastSpoken(): void {
  if (lastSpokenText) {
    speakText(lastSpokenText, undefined, undefined, undefined, true);
  }
}

/**
 * Spoken alert for status transitions (WAITING_APPROVAL, BLOCKED, FAIL, VERIFIED)
 */
export function speakStatusNotification(
  status: 'WAITING_APPROVAL' | 'BLOCKED' | 'FAIL' | 'VERIFIED'
): void {
  playStatusChime(status === 'BLOCKED' ? 'blocked' : status === 'WAITING_APPROVAL' ? 'waiting' : 'done');

  const settings = getVoiceSettings();
  if (!settings.enabled || !settings.alertOnBlockedOrApproval) return;

  const messages: Record<string, string> = {
    WAITING_APPROVAL: 'มีข้อเสนอที่รอการอนุมัติจากคุณก่อนลงมือทำครับ',
    BLOCKED: 'คำสั่งถูกระงับเนื่องจากนโยบายความปลอดภัยครับ',
    FAIL: 'การตรวจสอบพบข้อผิดพลาด กรุณาตรวจสอบรายละเอียดครับ',
    VERIFIED: 'การตรวจสอบเสร็จสิ้น ยืนยันผลสำเร็จแล้วครับ',
  };

  const text = messages[status];
  if (text) {
    speakText(text, settings, undefined, undefined, true);
  }
}

/**
 * Simple audio tone chime for status notification (works without TTS voice installed)
 */
export function playStatusChime(type: 'done' | 'blocked' | 'waiting' = 'done'): void {
  if (typeof window === 'undefined') return;
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextClass) return;

  try {
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    if (type === 'done') {
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.setValueAtTime(880, now + 0.1); // A5
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'blocked') {
      osc.frequency.setValueAtTime(330, now); // E4
      osc.frequency.setValueAtTime(220, now + 0.12); // A3
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.35);
    } else {
      osc.frequency.setValueAtTime(440, now); // A4
      osc.frequency.setValueAtTime(554.37, now + 0.1); // C#5
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    }
  } catch {
    // Ignore audio context errors if user hasn't interacted
  }
}
