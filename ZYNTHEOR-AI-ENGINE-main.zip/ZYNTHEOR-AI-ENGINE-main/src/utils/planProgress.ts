export interface ProgressSubTask {
  id?: string;
  title?: string;
  completed?: boolean;
  status?: string;
}

export interface ProgressStep {
  id?: string;
  title?: string;
  status: string;
  subTasks?: ProgressSubTask[];
  subSteps?: ProgressSubTask[];
}

export interface PlanProgress {
  total: number;
  done: number;
  inProgress: number;
  pending: number;
  /** 0-100, computed from completed sub-steps only (never from a stored number). */
  percent: number;
}

export function computePlanProgress(steps: ProgressStep[] | undefined | null): PlanProgress {
  const list = Array.isArray(steps) ? steps : [];
  if (list.length === 0) {
    return {
      total: 0,
      done: 0,
      inProgress: 0,
      pending: 0,
      percent: 0,
    };
  }

  // Check if any step contains granular sub-tasks or sub-steps
  const hasSubTasks = list.some(
    (s) =>
      (Array.isArray(s.subTasks) && s.subTasks.length > 0) ||
      (Array.isArray(s.subSteps) && s.subSteps.length > 0)
  );

  if (hasSubTasks) {
    let totalSubTasks = 0;
    let doneSubTasks = 0;
    let inProgressSubTasks = 0;

    for (const step of list) {
      const subItems =
        Array.isArray(step.subTasks) && step.subTasks.length > 0
          ? step.subTasks
          : Array.isArray(step.subSteps) && step.subSteps.length > 0
          ? step.subSteps
          : null;

      if (subItems && subItems.length > 0) {
        for (const sub of subItems) {
          totalSubTasks++;
          const isDone =
            sub.completed === true ||
            sub.status === 'done' ||
            sub.status === 'SUCCEEDED' ||
            sub.status === 'completed';
          const isInProgress = sub.status === 'in_progress' || sub.status === 'RUNNING';

          if (isDone) {
            doneSubTasks++;
          } else if (isInProgress) {
            inProgressSubTasks++;
          }
        }
      } else {
        totalSubTasks++;
        const isDone =
          step.status === 'done' ||
          step.status === 'SUCCEEDED' ||
          step.status === 'completed';
        const isInProgress = step.status === 'in_progress' || step.status === 'RUNNING';

        if (isDone) {
          doneSubTasks++;
        } else if (isInProgress) {
          inProgressSubTasks++;
        }
      }
    }

    return {
      total: totalSubTasks,
      done: doneSubTasks,
      inProgress: inProgressSubTasks,
      pending: Math.max(0, totalSubTasks - doneSubTasks - inProgressSubTasks),
      percent: totalSubTasks === 0 ? 0 : Math.round((doneSubTasks / totalSubTasks) * 100),
    };
  }

  // Standard step-level calculation
  const total = list.length;
  const done = list.filter(
    (s) => s.status === 'done' || s.status === 'SUCCEEDED' || s.status === 'completed'
  ).length;
  const inProgress = list.filter(
    (s) => s.status === 'in_progress' || s.status === 'RUNNING'
  ).length;

  return {
    total,
    done,
    inProgress,
    pending: Math.max(0, total - done - inProgress),
    percent: total === 0 ? 0 : Math.round((done / total) * 100),
  };
}
