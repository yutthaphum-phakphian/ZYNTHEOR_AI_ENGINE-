export type AutoTag =
  | 'React'
  | 'TypeScript'
  | 'Bug'
  | 'Architecture'
  | 'Security'
  | 'UI/UX'
  | 'Database'
  | 'API';

export interface TagRule {
  tag: AutoTag;
  label: string;
  color: string;
  bg: string;
  border: string;
  regex: RegExp;
}

export const AUTO_TAG_RULES: TagRule[] = [
  {
    tag: 'React',
    label: 'React',
    color: 'text-cyan-400',
    bg: 'bg-cyan-950/80',
    border: 'border-cyan-500/40',
    regex: /\b(react|jsx|tsx|usestate|useeffect|usememo|useref|component|hooks?|props|virtual\s*dom)\b/i,
  },
  {
    tag: 'TypeScript',
    label: 'TypeScript',
    color: 'text-blue-400',
    bg: 'bg-blue-950/80',
    border: 'border-blue-500/40',
    regex: /\b(typescript|tsc|interface|type\s+[A-Z]|generics?|tsconfig|strict\s*type)\b/i,
  },
  {
    tag: 'Bug',
    label: 'Bug',
    color: 'text-rose-400',
    bg: 'bg-rose-950/80',
    border: 'border-rose-500/40',
    regex: /\b(bug|error|exception|crash|traceback|fix|failed)\b|แก้บั๊ก|ข้อผิดพลาด|พัง|ปัญหา/i,
  },
  {
    tag: 'Architecture',
    label: 'Architecture',
    color: 'text-amber-400',
    bg: 'bg-amber-950/80',
    border: 'border-amber-500/40',
    regex: /\b(arch|architecture|microservices?|sandbox|isolation|ledger|hash|cryptographic)\b|โครงสร้าง|สถาปัตยกรรม/i,
  },
  {
    tag: 'Security',
    label: 'Security',
    color: 'text-amber-400',
    bg: 'bg-amber-950/80',
    border: 'border-amber-500/40',
    regex: /\b(security|auth|token|jwt|permission|redact|secret|bearer)\b|ความปลอดภัย|สิทธิ์/i,
  },
  {
    tag: 'UI/UX',
    label: 'UI/UX',
    color: 'text-pink-400',
    bg: 'bg-pink-950/80',
    border: 'border-pink-500/40',
    regex: /\b(css|tailwind|theme|responsive|modal|layout|navbar|sidebar|drawer|100dvh)\b|หน้าตา|สไตล์/i,
  },
  {
    tag: 'Database',
    label: 'Database',
    color: 'text-emerald-400',
    bg: 'bg-emerald-950/80',
    border: 'border-emerald-500/40',
    regex: /\b(database|sql|postgres|sqlite|query|table|schema|migration)\b|ฐานข้อมูล/i,
  },
  {
    tag: 'API',
    label: 'API',
    color: 'text-indigo-400',
    bg: 'bg-indigo-950/80',
    border: 'border-indigo-500/40',
    regex: /\b(api|endpoint|rest|http|fetch|axios|route|post|get|request|response)\b/i,
  },
];

/**
 * Analyzes conversation message contents and automatically assigns relevant tags
 * like 'React', 'TypeScript', or 'Bug' to the chat session for easier filtering.
 */
export function analyzeSessionTags(messages: Array<{ content?: string }>): AutoTag[] {
  if (!messages || messages.length === 0) return [];
  const fullText = messages.map((m) => m.content || '').join('\n');
  if (!fullText.trim()) return [];

  const matchedTags: AutoTag[] = [];

  for (const rule of AUTO_TAG_RULES) {
    if (rule.regex.test(fullText)) {
      matchedTags.push(rule.tag);
    }
  }

  return matchedTags;
}
