export interface SubTask {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  assignedAgent?: string;
  estimatedMinutes?: number;
  completedAt?: string;
}

export interface ExecutionStep {
  id: string;
  stepNumber: number;
  title: string;
  description: string;
  phase: 'intent' | 'reasoning' | 'execution' | 'verification';
  subTasks: SubTask[];
  status: 'pending' | 'in_progress' | 'completed' | 'blocked';
}

export interface ExecutionPlan {
  id: string;
  title: string;
  goal: string;
  targetCluster: string;
  steps: ExecutionStep[];
  createdAt: string;
  updatedAt: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface AgentDialogueMessage {
  id: string;
  agentName: string;
  agentRole: 'Planner' | 'Executor' | 'Verifier' | 'Arbitrator' | 'CyberDefense' | 'DevOps';
  avatarColor: string;
  message: string;
  timestamp: string;
  consensusVote?: 'approve' | 'reject' | 'abstain';
}

export interface ClusterStatus {
  id: string;
  name: string;
  tier: 'Genesis' | 'Custodian' | 'Cryo' | 'Quantum' | 'Planck' | 'Forensic';
  status: 'active' | 'synced' | 'standby' | 'alert';
  hsmVerified: boolean;
  telemetryLatencyMs: number;
  integrityScore: number;
}

export interface DigitalPassport {
  agentId: string;
  agentName: string;
  role: string;
  securityClearance: 'Class-1' | 'Class-2' | 'Class-3' | 'Omniversal';
  pqcSignature: string;
  issuedAt: string;
  assuranceScore: number;
}

/**
 * Calculates the exact completion percentage and counts of sub-steps within an ExecutionPlan.
 * Adheres to strict real data principles: 0% if no sub-tasks, accurately calculated.
 */
export function calculatePlanProgress(plan: ExecutionPlan): {
  totalSubTasks: number;
  completedSubTasks: number;
  percentage: number;
  completedSteps: number;
  totalSteps: number;
} {
  if (!plan || !Array.isArray(plan.steps) || plan.steps.length === 0) {
    return {
      totalSubTasks: 0,
      completedSubTasks: 0,
      percentage: 0,
      completedSteps: 0,
      totalSteps: 0,
    };
  }

  let totalSubTasks = 0;
  let completedSubTasks = 0;
  let completedSteps = 0;

  for (const step of plan.steps) {
    const subTasks = Array.isArray(step.subTasks) ? step.subTasks : [];
    const stepTotal = subTasks.length;
    const stepCompleted = subTasks.filter((st) => st.completed).length;

    totalSubTasks += stepTotal;
    completedSubTasks += stepCompleted;

    if (stepTotal > 0 && stepCompleted === stepTotal) {
      completedSteps += 1;
    } else if (stepTotal === 0 && step.status === 'completed') {
      completedSteps += 1;
    }
  }

  const percentage =
    totalSubTasks > 0 ? Math.round((completedSubTasks / totalSubTasks) * 100) : 0;

  return {
    totalSubTasks,
    completedSubTasks,
    percentage,
    completedSteps,
    totalSteps: plan.steps.length,
  };
}

/**
 * Immutable toggle of a sub-task within an ExecutionPlan.
 */
export function toggleSubTaskInPlan(
  plan: ExecutionPlan,
  stepId: string,
  subTaskId: string
): ExecutionPlan {
  const updatedSteps = plan.steps.map((step) => {
    if (step.id !== stepId) return step;

    const updatedSubTasks = step.subTasks.map((st) => {
      if (st.id !== subTaskId) return st;
      const nextCompleted = !st.completed;
      return {
        ...st,
        completed: nextCompleted,
        completedAt: nextCompleted ? new Date().toISOString() : undefined,
      };
    });

    // Check if all subtasks in this step are now completed
    const allCompleted =
      updatedSubTasks.length > 0 && updatedSubTasks.every((st) => st.completed);
    const anyInProgress = updatedSubTasks.some((st) => st.completed);

    const nextStatus = allCompleted
      ? ('completed' as const)
      : anyInProgress
      ? ('in_progress' as const)
      : ('pending' as const);

    return {
      ...step,
      subTasks: updatedSubTasks,
      status: nextStatus,
    };
  });

  return {
    ...plan,
    steps: updatedSteps,
    updatedAt: new Date().toISOString(),
  };
}
