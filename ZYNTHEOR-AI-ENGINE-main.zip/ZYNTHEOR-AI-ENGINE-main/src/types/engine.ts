export interface ServerStatus {
  connected: boolean;
  host: string;
  version?: string;
  latencyMs?: number;
  error?: string;
  checkedAt: string;
}

export interface ModelDetails {
  parent_model?: string;
  format?: string;
  family?: string;
  families?: string[];
  parameter_size?: string;
  quantization_level?: string;
}

export interface ModelInfo {
  name: string;
  model?: string;
  modified_at?: string;
  size?: number;
  digest?: string;
  details?: ModelDetails;
}

export interface RunningModelInfo {
  name: string;
  model?: string;
  size?: number;
  size_vram?: number;
  expires_at?: string;
}

export interface ModelStatus {
  connected: boolean;
  models: ModelInfo[];
  runningModels: RunningModelInfo[];
  checkedAt: string;
  error?: string;
}

export interface InferenceMetrics {
  totalDurationMs?: number;
  loadDurationMs?: number;
  promptEvalCount?: number;
  promptEvalDurationMs?: number;
  evalCount?: number;
  evalDurationMs?: number;
  tokensPerSecond?: number;
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  systemPrompt: string;
  userPromptTemplate: string;
  category: 'coding' | 'analysis' | 'creative' | 'system' | 'utility';
  updatedAt: string;
}

export interface ToolDefinition {
  id: string;
  name: string;
  description: string;
  parametersJson: string; // JSON schema string
  handlerCode: string;
  category: string;
}

export interface EngineSettings {
  host: string;
  authToken: string;
  defaultModel: string;
  timeoutMs: number;
}
