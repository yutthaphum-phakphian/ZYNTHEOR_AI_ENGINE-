export interface UrlMetadata {
  url: string;
  domain: string;
  title: string | null;
  description: string | null;
  image: string | null;
  favicon?: string | null;
  status: 'SUCCESS' | 'FALLBACK' | 'BLOCKED';
  error?: string;
}
