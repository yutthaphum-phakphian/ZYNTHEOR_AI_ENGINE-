export type FileExtensionType =
  | 'pdf'
  | 'code'
  | 'text'
  | 'json'
  | 'image'
  | 'audio'
  | 'video'
  | 'archive'
  | 'spreadsheet'
  | 'generic';

export interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string; // MIME type e.g. application/pdf, text/javascript
  extension: string; // e.g. 'pdf', 'js', 'ts', 'txt', 'json'
  fileTypeCategory: FileExtensionType;
  dataUrl?: string;
  previewUrl?: string;
  textSnippet?: string;
  uploadedAt: number;
  status: 'uploading' | 'ready' | 'error';
  errorMessage?: string;
}

export type ReactionEmoji = '👍' | '👎' | '💡' | '⚠️' | '❤️' | '🎯' | '✅' | '🤔';

export interface MessageReaction {
  emoji: ReactionEmoji;
  count: number;
  userReacted: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent' | 'system';
  content: string;
  timestamp: number;
  attachedFiles?: AttachedFile[];
  reactions?: Record<string, number>;
  userReactions?: ReactionEmoji[];
  summary?: string;
  isStreaming?: boolean;
  status?: 'sent' | 'processing' | 'done' | 'error';
  memoryProvenance?: Array<{ evidence: string; confidenceTag: 'HIGH' | 'MEDIUM' | 'LOW'; provenanceKind: 'VERIFIED_FACT' | 'USER_CLAIM' | 'ASSUMPTION' | 'UNKNOWN' }>;
}

export type MissionCategory = 'development' | 'research' | 'content' | 'data' | 'general';

export interface MissionCategoryMeta {
  id: MissionCategory;
  label: string;
  color: string;
  bgLight: string;
  borderLight: string;
}

export interface ChatSession {
  id: string;
  title: string;
  customTitle?: boolean;
  summary?: string;
  createdAt: number;
  updatedAt: number;
  category: MissionCategory;
  messages: ChatMessage[];
  pinned?: boolean;
  archived?: boolean;
  syncedAt?: string;
  tags?: string[];
}

export interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
  priority?: 'low' | 'medium' | 'high';
}

export interface ExpenseItem {
  id: string;
  title: string;
  amount: number;
  category: 'food' | 'transport' | 'software' | 'hardware' | 'other';
  date: string;
}

export interface PomodoroSettings {
  workMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  sessionsBeforeLongBreak: number;
}

export type PomodoroMode = 'work' | 'shortBreak' | 'longBreak';
