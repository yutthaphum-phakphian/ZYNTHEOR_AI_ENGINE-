export type AutomationTriggerType = 'webhook' | 'schedule' | 'event' | 'manual';

export interface AutomationExecutionLog {
  id: string;
  triggeredAt: string;
  triggerSource: 'manual' | 'webhook' | 'schedule' | 'event';
  status: 'SUCCESS' | 'FAILED' | 'RUNNING';
  durationMs: number;
  outputSummary: string;
  error?: string;
  evidenceId?: string;
}

export interface Automation {
  id: string;
  name: string;
  icon: string;
  description?: string;
  triggerType: AutomationTriggerType;
  // Link or URL connection for the trigger (e.g. external webhook URL or internal trigger path)
  triggerUrl?: string;
  // Cron schedule or interval string (e.g. 'every 1 hour', 'every 15 min', '0 * * * *')
  scheduleInterval?: string;
  // The command / prompt instructing the agent what to do
  prompt: string;
  // Reasoning depth: fast or deep
  mode: 'fast' | 'deep';
  // Notification preferences
  notifications: {
    push: boolean;
    emailOrWebhook: boolean;
  };
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
  lastRunAt?: string;
  lastRunStatus?: 'SUCCESS' | 'FAILED' | 'RUNNING';
  executionLogs: AutomationExecutionLog[];
}
