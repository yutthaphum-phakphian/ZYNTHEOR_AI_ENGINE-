export interface ZyrquenKernelSpec {
  kernelName: string;
  codename: string;
  tier: 'APEX ULTIMATE';
  version: 'Frozen v1.2 LTS';
  genesisBlockNumber: 849202;
  totalSealsCount: 14902;
  hsmQuorum: '10/10 HSM Quorum Verified';
  pqcAlgorithm: 'Dilithium-5 + SPHINCS+ Hybrid';
  mutationDrift: number; // 0.00%
  entropyCoherence: number; // 99.999%
  isolationStatus: 'VERIFIED_ISOLATED';
  genesisTimestamp: string;
}

export interface TruthSealRecord {
  sealIndex: number;
  sealId: string;
  sealType: 'GENESIS' | 'KERNEL_INTEGRITY' | 'HSM_CONSENSUS' | 'PQC_SIGNATURE' | 'FORENSIC_ANCHOR';
  blockNumber: number;
  merkleProof: string;
  signature: string;
  verified: boolean;
  timestamp: string;
}

export interface TruthMatrixChannel {
  channelId: string;
  name: string;
  description: string;
  status: 'SYNCHRONIZED' | 'LOCKED' | 'IMMUTABLE';
  sealRange: string;
  integrityScore: number;
}
