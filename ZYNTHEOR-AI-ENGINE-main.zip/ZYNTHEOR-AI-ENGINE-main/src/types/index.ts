export interface LedgerEvent {
  id: string;
  index: number;
  timestamp: string;
  eventType: 'INFERENCE_REQUEST' | 'WORKSPACE_SCAN' | 'WEB_RESEARCH' | 'TOOL_INVOCATION' | 'SECURITY_VALIDATION' | 'AUDIT_EXPORT' | 'DIAGNOSTICS_CHECK' | 'CODE_ANALYSIS';
  pipelineStage: 'INPUT_SANITIZATION' | 'POLICY_VERIFICATION' | 'CORE_INFERENCE' | 'TOOL_EXECUTION' | 'OUTPUT_VERIFICATION' | 'LEDGER_COMMIT';
  actor: 'USER' | 'AI_CORE' | 'TOOL_REGISTRY' | 'SECURITY_BARRIER' | 'AUDIT_SUBSYSTEM';
  status: 'PASS' | 'FAIL' | 'BLOCKED' | 'NOT_TESTED' | 'UNAVAILABLE';
  target: string;
  details: string;
  latencyMs: number;
  payloadHash: string;
  previousHash: string;
  ledgerHash: string;
}

export interface WorkspaceFileMetadata {
  name: string;
  relativePath: string;
  absolutePath: string;
  sizeBytes: number;
  sizeFormatted: string;
  extension: string;
  lines: number;
  modifiedAt: string;
  isReadable: boolean;
  category: 'code' | 'config' | 'document' | 'data' | 'other';
}

export interface WorkspaceInspectionResult {
  totalFiles: number;
  totalSizeBytes: number;
  totalSizeFormatted: string;
  allowedScope: string;
  environment: string;
  scannedAt: string;
  files: WorkspaceFileMetadata[];
  boundaryEnforced: boolean;
}

export interface SystemDiagnostics {
  platform: string;
  osType: string;
  arch: string;
  nodeVersion: string;
  uptimeSeconds: number;
  systemUptimeSeconds: number;
  containerEnvironment: boolean;
  containerScope: string;
  hostNotice: string;
  resourceSource: string;
  memory: {
    rssBytes: number;
    rssFormatted: string;
    heapTotalBytes: number;
    heapTotalFormatted: string;
    heapUsedBytes: number;
    heapUsedFormatted: string;
    systemTotalBytes: number;
    systemTotalFormatted: string;
    systemFreeBytes: number;
    systemFreeFormatted: string;
  };
  cpu: {
    count: number;
    model: string;
    speedMHz: number;
    loadAvg: number[];
  };
  gpu: {
    detected: boolean;
    device: string | null;
    model?: string | null;
    vramBytes: number;
    vramFormatted: string;
    status: string;
  };
}

export interface LocalRuntimeProbe {
  connected: boolean;
  endpoint: string;
  models: string[];
  latencyMs: number;
  message: string;
}

export interface WebSearchResultItem {
  title: string;
  snippet: string;
  url: string;
  timestamp: string;
}

export interface WebResearchResponse {
  success: boolean;
  query: string;
  provider: string;
  timestamp: string;
  results: WebSearchResultItem[];
  error?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  engineUsed?: 'LOCAL_MODEL' | 'NONE';
  modelName?: string;
  latencyMs?: number;
  tokensEstimate?: number;
  ledgerHash?: string;
  isError?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
  tags?: string[];
}
