/**
 * Engine Connectors Standard Interface & Types
 * Defines the standard contracts, connection states, authorization scopes,
 * and metadata schemas for all AI Engine external connectors.
 */

export type ConnectionStatus =
  | 'CONNECTED'
  | 'UNAVAILABLE'
  | 'AUTHENTICATING'
  | 'DISCONNECTED';

export type AuthorizationScope =
  | 'read'
  | 'write'
  | 'call_api'
  | 'mutate_system';

export type ConnectorAvailability =
  | 'AVAILABLE'
  | 'UNAVAILABLE'
  | 'NOT_INSTALLED';

export interface ConnectorMetadata {
  id: string;
  name: string;
  description: string;
  version: string;
  category: 'code_repository' | 'search_research' | 'storage' | 'external_api' | 'sovereign';
  isReadOnly: boolean;
  supportedActions: readonly string[];
  requiredScopes: readonly AuthorizationScope[];
  icon?: string;
  documentationUrl?: string;
}

export interface ConnectorStatusView {
  id: string;
  label: string;
  status: ConnectionStatus;
  availability: ConnectorAvailability;
  enabled: boolean;
  declaredPermissions: AuthorizationScope[];
  grantedPermissions: AuthorizationScope[];
  note?: string;
  lastCheckedAt?: string;
}

export interface ConnectorResponse<T = unknown> {
  status: 'SUCCESS' | 'FAILED' | 'UNAVAILABLE' | 'TIMEOUT' | 'DENIED';
  connectorId: string;
  action: string;
  durationMs: number;
  message: string;
  data?: T;
  reason?: string;
  correlationId?: string;
}

/**
 * Universal interface for all engine connectors.
 * Any connector integrated into the AI Engine must implement this contract.
 */
export interface EngineConnector<
  TAction extends string = string,
  TInput extends Record<string, unknown> = Record<string, unknown>,
  TResult = unknown
> {
  readonly metadata: ConnectorMetadata;
  getStatus(): Promise<ConnectionStatus>;
  checkHealth(): Promise<{ status: ConnectionStatus; message?: string }>;
  invoke(
    action: TAction,
    input: TInput,
    options?: { signal?: AbortSignal; timeoutMs?: number }
  ): Promise<ConnectorResponse<TResult>>;
}

/* ------------------------------------------------------------------------- */
/* GitHub Read-Only Connector Specific Contracts                             */
/* ------------------------------------------------------------------------- */

export interface GitHubRepoMetadata {
  fullName: string;
  description: string | null;
  defaultBranch: string;
  stars: number;
  forks: number;
  openIssues: number;
  language: string | null;
  private: boolean;
  htmlUrl: string;
  fetchedAt: string;
}

export interface GitHubIssue {
  number: number;
  title: string;
  state: 'open' | 'closed' | string;
  user: string | null;
  htmlUrl: string;
  createdAt: string;
}

export interface GitHubListIssuesResult {
  owner: string;
  repo: string;
  state: string;
  count: number;
  issues: GitHubIssue[];
  fetchedAt: string;
}

export interface GitHubFileContent {
  owner: string;
  repo: string;
  path: string;
  ref: string;
  size: number;
  sha: string;
  htmlUrl: string;
  content: string;
  truncated: boolean;
  fetchedAt: string;
}

export interface GitHubListIssuesParams {
  owner: string;
  repo: string;
  state?: 'open' | 'closed' | 'all';
  perPage?: number;
}

export interface GitHubGetFileParams {
  owner: string;
  repo: string;
  path: string;
  ref?: string;
}

export interface GitHubGetRepoParams {
  owner: string;
  repo: string;
}

export interface GitHubSearchParams {
  owner: string;
  repo: string;
  query: string;
  type?: 'issues' | 'files' | 'all';
  perPage?: number;
}

export interface GitHubSearchIssueItem {
  number: number;
  title: string;
  state: 'open' | 'closed' | string;
  isPullRequest?: boolean;
  user: string | null;
  htmlUrl: string;
  createdAt: string;
  comments?: number;
}

export interface GitHubSearchFileItem {
  name: string;
  path: string;
  sha?: string;
  htmlUrl: string;
}

export interface GitHubSearchResult {
  owner: string;
  repo: string;
  query: string;
  type: 'issues' | 'files' | 'all';
  count: number;
  issueCount: number;
  fileCount: number;
  issues: GitHubSearchIssueItem[];
  files: GitHubSearchFileItem[];
  fetchedAt: string;
}

export interface GitHubCommitItem {
  sha: string;
  shortSha: string;
  message: string;
  author: string;
  authorAvatar?: string;
  date: string;
  htmlUrl: string;
}

export interface GitHubPullRequestItem {
  id: number;
  number: number;
  title: string;
  state: 'open' | 'closed' | 'merged' | string;
  user: string;
  userAvatar?: string;
  createdAt: string;
  updatedAt: string;
  mergedAt?: string | null;
  htmlUrl: string;
  labels: string[];
}

export interface GitHubActivityItem {
  id: string;
  type: 'commit' | 'pull_request';
  timestamp: string;
  commit?: GitHubCommitItem;
  pullRequest?: GitHubPullRequestItem;
}

/**
 * Read-Only GitHub Client interface
 * Provides access to GitHub REST API via authenticated Hub Agent proxy.
 */
export interface ReadOnlyGitHubClient {
  readonly connectorId: string;
  checkStatus(): Promise<ConnectionStatus>;
  getRepositoryMetadata(owner: string, repo: string): Promise<GitHubRepoMetadata>;
  listIssues(params: GitHubListIssuesParams): Promise<GitHubListIssuesResult>;
  getFileContent(params: GitHubGetFileParams): Promise<GitHubFileContent>;
  getReadme(owner: string, repo: string, ref?: string): Promise<GitHubFileContent>;
  search(params: GitHubSearchParams): Promise<GitHubSearchResult>;
  searchIssues(owner: string, repo: string, query: string): Promise<GitHubSearchIssueItem[]>;
  searchFiles(owner: string, repo: string, query: string): Promise<GitHubSearchFileItem[]>;
}

/* ------------------------------------------------------------------------- */
/* GitHub Rate Limit & Monitoring Interfaces                                 */
/* ------------------------------------------------------------------------- */

export interface GitHubRateLimitResource {
  limit: number;
  used: number;
  remaining: number;
  reset: number; // Unix timestamp in seconds
}

export interface GitHubRateLimitReport {
  status: string;
  authenticated: boolean;
  resources: {
    core: GitHubRateLimitResource;
    search: GitHubRateLimitResource;
    graphql?: GitHubRateLimitResource;
    code_search?: GitHubRateLimitResource;
  };
  rate: GitHubRateLimitResource;
  fetchedAt: string;
}

export interface MonitoredRepository {
  fullName: string;
  name: string;
  owner: string;
  description?: string | null;
  defaultBranch: string;
  selectedBranch: string;
  stars?: number;
  private: boolean;
  htmlUrl?: string;
  indexedAt?: string;
  monitored: boolean;
  fileCount?: number;
  openIssues?: number;
}

export interface GitHubOAuthUser {
  login: string;
  name?: string | null;
  avatarUrl?: string;
  htmlUrl?: string;
  publicRepos?: number;
}

export interface GitHubOAuthState {
  status: ConnectionStatus;
  user: GitHubOAuthUser | null;
  token: string | null;
  connectedAt: string | null;
  rateLimit: GitHubRateLimitReport | null;
}

