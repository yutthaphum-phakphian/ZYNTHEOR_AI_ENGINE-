export interface QuantumCoreParameters {
  frequencyGhz: number;
  pulseIntensity: number;
  entropyDamping: number;
  quantumState: 'COHERENT' | 'ENTANGLED' | 'SUPERPOSITION' | 'RESONANT';
  chaosHealStatus: 'ACTIVE' | 'STANDBY' | 'HEALING';
  uptimePercentage: number;
  telemetryLatencyMs: number;
}

export interface BoardSignoff {
  role: 'CISO' | 'SRE_LEAD' | 'COMPLIANCE_LEAD' | 'VP_PRODUCT';
  title: string;
  signeeName: string;
  signed: boolean;
  signedAt?: string;
  signatureHash?: string;
}

export interface GlobalAssuranceCert {
  certificateId: string;
  edition: string;
  issuedTo: string;
  status: 'PENDING_SIGNOFF' | 'VERIFIED' | 'GOLD_MASTER_CERTIFIED';
  rsaKeyFingerprint: string;
  dilithiumSignature: string;
  merkleRoot: string;
  slsaComplianceLevel: string;
  evidenceChainId: string;
  issuedAt: string;
  boardSignoffs: BoardSignoff[];
}

export interface GlobalLedgerBlock {
  blockNumber: number;
  blockHash: string;
  previousHash: string;
  merkleRoot: string;
  evidenceChainId: string;
  timestamp: string;
  cisoSignature: string;
  systemArchitectSignature: string;
  consensusQuorum: string;
  immutableStatus: 'GOLD_MASTER_CERTIFIED' | 'ANCHORED';
}

export interface LaunchPhase {
  id: 'init' | 'verify' | 'flight';
  phaseNumber: number;
  name: string;
  description: string;
  status: 'idle' | 'running' | 'completed' | 'failed';
  completedAt?: string;
}
