import test from 'node:test';
import assert from 'node:assert';
import {
  calculatePlanProgress,
  toggleSubTaskInPlan,
  ExecutionPlan,
} from './types/orchestration';

test('calculatePlanProgress calculates percentage accurately for empty plan', () => {
  const emptyPlan: ExecutionPlan = {
    id: 'plan-1',
    title: 'แผนทดสอบ',
    goal: 'ทดสอบ',
    targetCluster: 'Quantum',
    steps: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    priority: 'medium',
  };

  const progress = calculatePlanProgress(emptyPlan);
  assert.strictEqual(progress.totalSubTasks, 0);
  assert.strictEqual(progress.completedSubTasks, 0);
  assert.strictEqual(progress.percentage, 0);
  assert.strictEqual(progress.completedSteps, 0);
});

test('calculatePlanProgress calculates 25%, 50%, and 100% correctly', () => {
  const plan: ExecutionPlan = {
    id: 'plan-2',
    title: 'แผนทดสอบขั้นตอนย่อย',
    goal: 'ทดสอบการคำนวณ',
    targetCluster: 'Genesis',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    priority: 'high',
    steps: [
      {
        id: 'step-1',
        stepNumber: 1,
        title: 'ขั้นตอนที่ 1',
        description: 'รายละเอียด',
        phase: 'intent',
        status: 'in_progress',
        subTasks: [
          { id: 'sub-1', title: 'งานย่อย 1', completed: true },
          { id: 'sub-2', title: 'งานย่อย 2', completed: false },
        ],
      },
      {
        id: 'step-2',
        stepNumber: 2,
        title: 'ขั้นตอนที่ 2',
        description: 'รายละเอียด',
        phase: 'execution',
        status: 'pending',
        subTasks: [
          { id: 'sub-3', title: 'งานย่อย 3', completed: false },
          { id: 'sub-4', title: 'งานย่อย 4', completed: false },
        ],
      },
    ],
  };

  // 1 out of 4 completed = 25%
  const p1 = calculatePlanProgress(plan);
  assert.strictEqual(p1.totalSubTasks, 4);
  assert.strictEqual(p1.completedSubTasks, 1);
  assert.strictEqual(p1.percentage, 25);

  // Complete another subtask: 2 out of 4 = 50%
  const updatedPlan1 = toggleSubTaskInPlan(plan, 'step-1', 'sub-2');
  const p2 = calculatePlanProgress(updatedPlan1);
  assert.strictEqual(p2.completedSubTasks, 2);
  assert.strictEqual(p2.percentage, 50);
  assert.strictEqual(p2.completedSteps, 1); // step-1 is now completely done

  // Complete all: 4 out of 4 = 100%
  const updatedPlan2 = toggleSubTaskInPlan(updatedPlan1, 'step-2', 'sub-3');
  const updatedPlan3 = toggleSubTaskInPlan(updatedPlan2, 'step-2', 'sub-4');
  const p3 = calculatePlanProgress(updatedPlan3);
  assert.strictEqual(p3.completedSubTasks, 4);
  assert.strictEqual(p3.percentage, 100);
  assert.strictEqual(p3.completedSteps, 2);
});

test('toggleSubTaskInPlan updates completion state and completedAt immutably', () => {
  const plan: ExecutionPlan = {
    id: 'plan-3',
    title: 'ทดสอบการ Toggle',
    goal: 'ความถูกต้องของข้อมูล',
    targetCluster: 'Planck',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    priority: 'low',
    steps: [
      {
        id: 'step-x',
        stepNumber: 1,
        title: 'ขั้นตอนหลัก',
        description: 'ทดสอบ',
        phase: 'execution',
        status: 'pending',
        subTasks: [{ id: 'sub-x', title: 'งานเดี่ยว', completed: false }],
      },
    ],
  };

  const toggled = toggleSubTaskInPlan(plan, 'step-x', 'sub-x');
  assert.strictEqual(toggled.steps[0].subTasks[0].completed, true);
  assert.ok(toggled.steps[0].subTasks[0].completedAt);
  assert.strictEqual(toggled.steps[0].status, 'completed');

  // Toggle back to false
  const toggledBack = toggleSubTaskInPlan(toggled, 'step-x', 'sub-x');
  assert.strictEqual(toggledBack.steps[0].subTasks[0].completed, false);
  assert.strictEqual(toggledBack.steps[0].subTasks[0].completedAt, undefined);
  assert.strictEqual(toggledBack.steps[0].status, 'pending');
});

test('Server and Model status separation principle', () => {
  // Verifies that a server status object does not contain or infer model state
  const mockServerStatus = {
    serverConnected: true,
    host: 'http://127.0.0.1:11434',
    version: '0.4.1',
    latencyMs: 12,
  };

  const mockModelStatus = {
    connected: false,
    models: [],
    runningModels: [],
  };

  // Statuses are independent: server can be connected while model has 0 loaded
  assert.strictEqual(mockServerStatus.serverConnected, true);
  assert.strictEqual(mockModelStatus.models.length, 0);
  assert.strictEqual(mockModelStatus.connected, false);
});

test('Sandbox security rejects dangerous system execution commands', () => {
  const forbiddenPatterns = [
    /child_process/i,
    /process\./i,
    /fs\./i,
    /require\(/i,
    /import\(/i,
    /__dirname/i,
    /__filename/i,
    /eval\(/i,
  ];

  const maliciousCode = `
    const cp = require('child_process');
    process.exit(1);
  `;

  let blocked = false;
  for (const pattern of forbiddenPatterns) {
    if (pattern.test(maliciousCode)) {
      blocked = true;
      break;
    }
  }

  assert.strictEqual(blocked, true, 'Malicious code must be detected and blocked');
});
