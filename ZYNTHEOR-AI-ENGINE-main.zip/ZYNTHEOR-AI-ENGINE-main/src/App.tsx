import { FormEvent, Suspense, lazy, useEffect, useMemo, useState, useRef } from 'react';
import StatusBanner from './components/StatusBanner';
import {
  Activity,
  AlertTriangle,
  BarChart2,
  Bot,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleStop,
  Clock3,
  Code2,
  Copy,
  Cpu,
  FileSearch,
  Folder,
  FolderSearch,
  LayoutGrid,
  Gauge,
  Globe2,
  HardDrive,
  HelpCircle,
  Image as ImageIcon,
  Layers,
  ArrowRight,
  Menu,
  MessageSquare,
  MoreVertical,
  Paperclip,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  Send,
  Settings,
  Settings2,
  ShieldCheck,
  Smile,
  Sparkles,
  Terminal,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  User,
  Wrench,
  X,
  Zap,
  FileText,
  Maximize2,
  Download,
  UploadCloud,
  Sun,
  Moon,
  Mic,
  MicOff,
  Keyboard,
  ArrowDown,
  ListChecks,
  Bookmark,
  ExternalLink,
  Pencil,
  Sliders,
  Archive,
  ArchiveRestore,
  CheckSquare,
  Square,
} from 'lucide-react';

import { useTheme } from './hooks/useTheme';
import { useSpeechToText } from './hooks/useSpeechToText';
import { useSmartScroll } from './hooks/useSmartScroll';
import { useShortcutManager, type ShortcutDef } from './hooks/useShortcutManager';
import { usePersistedChatSession } from './hooks/usePersistedChatSession';
import { ShortcutHelpModal } from './components/ShortcutHelpModal';
import { SaveStatusIndicator } from './components/SaveStatusIndicator';
import { useSaveStatus } from './hooks/useSaveStatus';
import { PlansStudioView } from './components/views/PlansStudioView';
import { filterSessions } from './utils/sessionFilter';
import { deriveServerStatus, deriveModelStatus } from './utils/statusLabels';
import { ResourceTrendChart } from './components/ResourceTrendChart';
import { GgufModelInstaller } from './components/GgufModelInstaller';
import { CryptographicEvidenceModal } from './components/CryptographicEvidenceModal';
import { ModelPerformanceChart, type ModelPerformancePoint } from './components/ModelPerformanceChart';
import { MessageContextMenu } from './components/MessageContextMenu';
import { SpeechToTextSettingsPanel } from './components/SpeechToTextSettingsPanel';
import { AssistantMessageContent, extractUrlsFromText } from './components/AssistantMessageContent';
import { SettingsSyncPanel } from './components/SettingsSyncPanel';
import { AutomationsModal } from './components/AutomationsModal';
import { SafeRedirectModal } from './components/SafeRedirectModal';
import { UrlPreviewCard } from './components/UrlPreviewCard';
import { analyzeSessionTags, AUTO_TAG_RULES } from './utils/autoTagging';
import { ChatCoreFallback } from './components/ChatCoreFallback';
const ChatCore3D = lazy(() => import('./components/ChatCore3D').then((module) => ({ default: module.ChatCore3D })));
const MultiverseAgentConsole = lazy(() => import('./components/MultiverseAgentConsole').then((module) => ({ default: module.MultiverseAgentConsole })));
import { formatReadingTime } from './utils/readingTime';
import { CoreDiagnosticsPanel } from './components/CoreDiagnosticsPanel';
import { detectModeWithEvidence, explainAutoChoice, restoreManualMode } from './utils/detectMode';
import { WorkspacePanel, type WorkspaceTab } from './components/WorkspacePanel';
import { ModelsView } from './components/views/ModelsView';
import { ConversationOverviewPanel } from './components/ConversationOverviewPanel';
import { ZyntheorApiHealthDashboard } from './components/ZyntheorApiHealthDashboard';

export type PinnedTag = 'Code' | 'Bug' | 'Idea' | 'Arch' | 'General';

export interface PinnedTagMeta {
  id: PinnedTag;
  label: string;
  color: string;
  border: string;
  bg: string;
}

export const PINNED_TAGS: PinnedTagMeta[] = [
  { id: 'Code', label: 'Code', color: 'text-cyan-400', border: 'border-cyan-500/30', bg: 'bg-cyan-500/10' },
  { id: 'Bug', label: 'Bug', color: 'text-rose-400', border: 'border-rose-500/30', bg: 'bg-rose-500/10' },
  { id: 'Idea', label: 'Idea', color: 'text-amber-400', border: 'border-amber-500/30', bg: 'bg-amber-500/10' },
  { id: 'Arch', label: 'Arch', color: 'text-amber-400', border: 'border-amber-500/30', bg: 'bg-amber-500/10' },
  { id: 'General', label: 'General', color: 'text-slate-400', border: 'border-slate-500/30', bg: 'bg-slate-500/10' },
];

export function detectTagFromContent(text: string): PinnedTag {
  if (text.includes('```') || /\b(function|class|import|export|const|let|var|return)\b/.test(text)) return 'Code';
  if (/bug|error|fail|exception|crash|ข้อผิดพลาด|แก้บั๊ก|ปัญหา/i.test(text)) return 'Bug';
  if (/idea|plan|proposal|propos|concept|feature|แนวคิด|แผนงาน|ฟีเจอร์|ข้อเสนอ/i.test(text)) return 'Idea';
  if (/arch|architecture|security|sandbox|isolation|โครงสร้าง|สถาปัตยกรรม|ledger|hash/i.test(text)) return 'Arch';
  return 'General';
}

export function filterConversationMessages<T extends { content?: string; stickerLabel?: string; stickerEmoji?: string; attachments?: Array<{ name?: string }> }>(
  messages: T[],
  query: string
): T[] {
  const cleanQuery = query.trim().toLowerCase();
  if (!cleanQuery) return messages;
  return messages.filter((msg) => {
    const matchContent = msg.content?.toLowerCase().includes(cleanQuery);
    const matchSticker = msg.stickerLabel?.toLowerCase().includes(cleanQuery) || msg.stickerEmoji?.includes(cleanQuery);
    const matchAttachment = msg.attachments?.some((a) => a.name?.toLowerCase().includes(cleanQuery));
    return Boolean(matchContent || matchSticker || matchAttachment);
  });
}

export function highlightMatch(text: string, query: string): React.ReactNode {
  if (!query.trim()) return text;
  const escaped = query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(${escaped})`, 'gi');
  const parts = text.split(regex);
  return parts.map((part, i) =>
    regex.test(part) ? (
      <mark key={i} className="bg-cyan-500/35 text-cyan-100 font-semibold px-0.5 py-0.2 rounded border border-cyan-400/40">
        {part}
      </mark>
    ) : (
      part
    )
  );
}

export interface PinnedMessage {
  id: string;
  messageId: string;
  sessionId: string;
  sessionTitle: string;
  content: string;
  snippet: string;
  createdAt: string;
  pinnedAt: string;
  tag?: PinnedTag;
}

type ModeId = 'auto' | 'chat' | 'plan' | 'build' | 'projects' | 'models' | 'web' | 'files' | 'tools' | 'code' | 'analysis';

export interface MessageAttachment {
  id: string;
  name: string;
  type: 'image' | 'file';
  url: string;
  size?: number;
  mimeType?: string;
  previewUrl?: string;
}

export interface StickerItem {
  emoji: string;
  label: string;
  category: 'cyber' | 'dev' | 'reactions';
  color?: string;
}

export const STICKER_COLLECTION: StickerItem[] = [
  // Cyber & Sovereign Mascot
  { emoji: '⚡', label: 'Zyntheor Sovereign', category: 'cyber', color: 'from-amber-500 to-yellow-300' },
  { emoji: '🛡️', label: 'Evidence Verified', category: 'cyber', color: 'from-cyan-500 to-blue-400' },
  { emoji: '🧠', label: 'Deep Reasoning', category: 'cyber', color: 'from-amber-500 to-indigo-400' },
  { emoji: '🚀', label: 'Local Core Ready', category: 'cyber', color: 'from-emerald-500 to-teal-300' },
  { emoji: '🔒', label: 'Network Isolated', category: 'cyber', color: 'from-rose-500 to-red-400' },
  { emoji: '✅', label: 'Approved & Audited', category: 'cyber', color: 'from-emerald-400 to-green-300' },
  { emoji: '🐛', label: 'Bug Identified', category: 'cyber', color: 'from-amber-400 to-orange-400' },
  { emoji: '💡', label: 'Core Insight', category: 'cyber', color: 'from-yellow-400 to-amber-300' },
  { emoji: '⚙️', label: 'Compiling Code', category: 'cyber', color: 'from-blue-400 to-cyan-300' },
  { emoji: '🎯', label: 'Goal Executed', category: 'cyber', color: 'from-pink-500 to-rose-400' },
  // Dev & Tech Icons
  { emoji: '💻', label: 'Coding Workstation', category: 'dev' },
  { emoji: '🤖', label: 'Local Agent', category: 'dev' },
  { emoji: '📦', label: 'Artifact Package', category: 'dev' },
  { emoji: '📊', label: 'System Metrics', category: 'dev' },
  { emoji: '🔍', label: 'File Search', category: 'dev' },
  { emoji: '🧬', label: 'Architecture', category: 'dev' },
  { emoji: '🌐', label: 'Network Isolation', category: 'dev' },
  { emoji: '🧪', label: 'Sandbox Runner', category: 'dev' },
  { emoji: '🛠️', label: 'Sovereign Tools', category: 'dev' },
  { emoji: '⌨️', label: 'CLI Terminal', category: 'dev' },
  { emoji: '🔥', label: 'High Performance', category: 'dev' },
  { emoji: '📁', label: 'Workspace Repo', category: 'dev' },
  // Reactions
  { emoji: '👍', label: 'ยอดเยี่ยม (Thumbs Up)', category: 'reactions' },
  { emoji: '🎉', label: 'ฉลองสำเร็จ (Celebration)', category: 'reactions' },
  { emoji: '❤️', label: 'ถูกใจ (Love)', category: 'reactions' },
  { emoji: '✨', label: 'ยอดเยี่ยม (Sparkles)', category: 'reactions' },
  { emoji: '🌟', label: 'โดดเด่น (Star)', category: 'reactions' },
  { emoji: '👏', label: 'ปรบมือ (Applause)', category: 'reactions' },
  { emoji: '🙌', label: 'ยินดีด้วย (Hooray)', category: 'reactions' },
  { emoji: '💯', label: 'เต็มร้อย (100%)', category: 'reactions' },
  { emoji: '🤝', label: 'ร่วมมือกัน (Deal)', category: 'reactions' },
  { emoji: '😎', label: 'เท่มาก (Cool)', category: 'reactions' },
  { emoji: '🤔', label: 'กำลังคิด (Thinking)', category: 'reactions' },
  { emoji: '🤩', label: 'ประทับใจ (Amazed)', category: 'reactions' },
  { emoji: '☕', label: 'พักดื่มกาแฟ (Coffee)', category: 'reactions' },
  { emoji: '🏆', label: 'สำเร็จลุล่วง (Trophy)', category: 'reactions' },
  { emoji: '🦾', label: 'ลุยต่อ (Power)', category: 'reactions' },
  { emoji: '🫡', label: 'รับทราบ (Salute)', category: 'reactions' },
];

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  status?: string;
  createdAt: string;
  timestamp?: number;
  verified?: boolean;
  images?: string[];
  attachments?: MessageAttachment[];
  isSticker?: boolean;
  stickerEmoji?: string;
  stickerLabel?: string;
  feedback?: 'like' | 'dislike' | null;
}

export function formatMessageTimeOfDay(msg: { timestamp?: number | string; createdAt?: string }): string {
  if (msg.timestamp) {
    const d = new Date(msg.timestamp);
    if (!isNaN(d.getTime())) {
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    }
  }
  if (msg.createdAt) {
    const parsed = new Date(msg.createdAt);
    if (!isNaN(parsed.getTime()) && (msg.createdAt.includes('T') || msg.createdAt.includes('-'))) {
      return parsed.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    }
    return msg.createdAt;
  }
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}

interface ChatSession {
  id: string;
  title: string;
  updatedAt: string;
  messages: Message[];
  archived?: boolean;
  tags?: string[];
  customTitle?: boolean;
}


interface Health {
  status?: string;
  service?: string;
  message?: string;
  capabilities?: Record<string, any>;
}

interface SystemMetrics {
  cpu: number | null;
  cpuDisplay: string | null;
  ramUsedGb: string;
  ramTotalGb: string;
  ramPercentage: number;
  ramDisplay: string;
  source?: string;
  gpu: string;
  gpuDisplay: string;
  latencyMs: number | null;
}

interface TelemetryEvent {
  time: string;
  level: 'INFO' | 'WARN' | 'ERROR';
  message: string;
}

type ProviderChoice = 'local' | 'openai' | 'anthropic';
interface OnlineProviderStatus {
  id: Exclude<ProviderChoice, 'local'>;
  name: string;
  configured: boolean;
  model: string;
  available: boolean;
}

interface Mode {
  id: ModeId;
  label: string;
  english: string;
  icon: typeof Bot;
  available: boolean;
  accent: string;
}

// Modes shown as chips above the composer. "Auto" is the default when no chip is selected
// (tap the active chip again to go back to Auto), so it has no chip of its own.
const modes: Mode[] = [
  { id: 'chat', label: 'แชททั่วไป', english: 'ถามตอบและปรึกษา', icon: Bot, available: true, accent: 'cyan' },
  { id: 'plan', label: 'คิดและวางแผน', english: 'วิเคราะห์และวางแผนก่อนลงมือ', icon: ListChecks, available: true, accent: 'teal' },
  { id: 'code', label: 'เขียนโค้ด', english: 'ช่วยพัฒนาและแก้ไขโค้ด', icon: Code2, available: true, accent: 'cyan' },
  { id: 'build', label: 'สร้างแอป', english: 'สร้างและพัฒนาแอปพลิเคชัน', icon: LayoutGrid, available: true, accent: 'amber' },
];
const AUTO_MODE: Mode = { id: 'auto', label: 'อัตโนมัติ', english: 'เลือกวิธีทำงานให้เหมาะกับคำขอ', icon: Sparkles, available: true, accent: 'emerald' };
// Extra tools live in the composer "+" menu, not in the chip row.
const TOOL_MODES: Mode[] = [
  { id: 'web', label: 'ค้นหาเว็บ', english: 'ค้นหาข้อมูลจากอินเทอร์เน็ต', icon: Globe2, available: true, accent: 'blue' },
  { id: 'files', label: 'ค้นหาไฟล์', english: 'ค้นหาไฟล์ในเครื่อง', icon: FolderSearch, available: true, accent: 'teal' },
  { id: 'analysis', label: 'วิเคราะห์ข้อมูล', english: 'วิเคราะห์ข้อมูลและตัวเลข', icon: Activity, available: true, accent: 'amber' },
  { id: 'tools', label: 'เครื่องมือ', english: 'ใช้เครื่องมือเสริม', icon: Wrench, available: true, accent: 'pink' },
];
// Full-page views opened from the sidebar.
const MODELS_MODE: Mode = { id: 'models', label: 'Models', english: 'ผู้ให้บริการ AI และสถานะ', icon: Cpu, available: true, accent: 'emerald' };
const PROJECTS_MODE: Mode = { id: 'projects', label: 'โปรเจกต์', english: 'เปิดและจัดการพื้นที่โปรเจกต์', icon: Folder, available: true, accent: 'teal' };
const CYCLE_MODES: Mode[] = [AUTO_MODE, ...modes];
const ALL_MODES: Mode[] = [AUTO_MODE, ...modes, ...TOOL_MODES, MODELS_MODE, PROJECTS_MODE];

export function summarizeChatSession(messages: Array<{ role: 'user' | 'assistant'; content: string }>, fallback = 'การสนทนาใหม่'): string {
  const firstUser = messages.find((message) => message.role === 'user')?.content || '';
  const firstAssistant = messages.find((message) => message.role === 'assistant')?.content || '';
  const strip = (text: string) => text.replace(/```[\s\S]*?```/g, 'โค้ด').replace(/[#>*`_~-]/g, '').replace(/\s+/g, ' ').trim();
  const source = strip(firstUser) || strip(firstAssistant);
  if (!source) return fallback;
  return source.length > 120 ? `${source.slice(0, 117).trimEnd()}…` : source;
}

export default function App() {
  const [activeMode, setActiveMode] = useState<ModeId>('auto');
  // Restore a mode the user picked by hand (Auto stays the default when nothing valid is stored).
  useEffect(() => {
    try {
      const restorableModes = ALL_MODES.filter((m) => m.available && m.id !== 'build' && m.id !== 'projects').map((m) => m.id);
      const restored = restoreManualMode(localStorage.getItem('zyntheor_active_mode'), restorableModes);
      if (restored) setActiveMode(restored);
    } catch { /* storage unavailable: stay on Auto */ }
  }, []);

  const [workspacePanelOpen, setWorkspacePanelOpen] = useState(false);
  const [workspacePanelTab, setWorkspacePanelTab] = useState<WorkspaceTab>('plan');
  const [apiToken, setApiToken] = useState<string>(() => {
    try { return sessionStorage.getItem('zyntheor_api_token') || ''; } catch { return ''; }
  });

  // Planning Mode handoff: Chat plan panel opens Build without starting a new session
  useEffect(() => {
    const onNavigate = (e: Event) => {
      const mode = (e as CustomEvent).detail?.mode;
      if (mode === 'build' || mode === 'projects') {
        setWorkspacePanelTab(mode === 'build' ? 'build' : 'projects');
        setWorkspacePanelOpen(true);
        return;
      }
      if (mode === 'models' || mode === 'chat' || mode === 'auto') {
        setActiveMode(mode);
        try {
          localStorage.setItem('zyntheor_active_mode', mode);
        } catch { /* ignore */ }
      }
    };
    window.addEventListener('zyntheor-navigate-mode', onNavigate);
    return () => window.removeEventListener('zyntheor-navigate-mode', onNavigate);
  }, []);

  useEffect(() => {
    fetch('/api/chat/attachment-policy')
      .then((r) => r.json())
      .catch(() => {});
  }, []);

  const [currentSessionId, setCurrentSessionId] = useState<string>('default');
  const [sessions, setSessions] = useState<ChatSession[]>([
    {
      id: 'default',
      title: 'การสนทนาใหม่',
      updatedAt: new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', hour12: false }),
      messages: [],
      tags: [],
    },
  ]);
  const [overviewSession, setOverviewSession] = useState<ChatSession | null>(null);
  const [isOverviewOpen, setIsOverviewOpen] = useState<boolean>(false);
  const [apiHealthDashboardOpen, setApiHealthDashboardOpen] = useState<boolean>(false);

  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const composerRef = useRef<HTMLTextAreaElement>(null);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState('');
  const [focusedMessageIndex, setFocusedMessageIndex] = useState<number | null>(null);

  // Find or construct current session object
  const currentSession = useMemo(() => {
    const existing = sessions.find((s) => s.id === currentSessionId);
    if (existing) {
      return { ...existing, messages };
    }
    return {
      id: currentSessionId,
      title: 'การสนทนาใหม่',
      updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
      messages,
    };
  }, [sessions, currentSessionId, messages]);

  // Tracks whether the session was really persisted (localStorage and backend) for the "Saved" indicator
  const saveStatus = useSaveStatus();

  // Hook that saves current chat session to localStorage whenever a message is sent or received
  const { loadPersistedSession } = usePersistedChatSession<ChatSession>(
    currentSession,
    'zyntheor_current_chat_session',
    () => {
      const timeFormatted = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
      setLastAutoSavedAt(timeFormatted);
      saveStatus.ok('local');
    },
    () => saveStatus.fail('local')
  );

  // Restore persisted chat session on initial mount across page refreshes
  useEffect(() => {
    try {
      const persisted = loadPersistedSession();
      if (persisted && Array.isArray(persisted.messages) && persisted.messages.length > 0) {
        setCurrentSessionId(persisted.id);
        setMessages(persisted.messages);
        setSessions((prev) => {
          const idx = prev.findIndex((s) => s.id === persisted.id);
          if (idx >= 0) {
            const next = [...prev];
            next[idx] = persisted;
            return next;
          }
          return [persisted, ...prev.filter((s) => s.id !== 'default')];
        });
      }
    } catch (e) {
      console.warn('Failed to restore persisted chat session:', e);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const [health, setHealth] = useState<Health | null>(null);
  const [healthState, setHealthState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [sending, setSending] = useState(false);
  // Keep side panels collapsed by default on every screen size; the chat/build work area gets priority.
  const [sidebarOpen, setSidebarOpen] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1024);
  const [rightRailOpen, setRightRailOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  // Prompt waiting to be sent from the Build panel once draft/mode state has settled.
  const [pendingBuildSend, setPendingBuildSend] = useState<string | null>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const [selectedModel, setSelectedModel] = useState('');
  const [providerChoice, setProviderChoice] = useState<ProviderChoice>('local');
  const [providerConsent, setProviderConsent] = useState(false);
  const [onlineProviders, setOnlineProviders] = useState<OnlineProviderStatus[]>([]);
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const [pipelineMode, setPipelineMode] = useState('Chat');
  const [telemetryFilter, setTelemetryFilter] = useState('ทั้งหมด');
  const [notice, setNotice] = useState('');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  // Modals
  const [historyDrawerOpen, setHistoryDrawerOpen] = useState(false);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [evidenceModalOpen, setEvidenceModalOpen] = useState(false);
  const [sttSettingsModalOpen, setSttSettingsModalOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'runtime' | 'stt' | 'security' | 'audit' | 'sync'>('runtime');
  const [localEndpoint, setLocalEndpoint] = useState('');
  const [localModelStatus, setLocalModelStatus] = useState<any>(null);
  const [webSearchAvailable, setWebSearchAvailable] = useState<boolean | null>(null);
  const [testingEndpoint, setTestingEndpoint] = useState(false);
  const [compareModelA, setCompareModelA] = useState('');
  const [compareModelB, setCompareModelB] = useState('');

  // Clear conversation confirmation state
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);

  const handleClearConversation = () => {
    if (activeRequestController.current) {
      activeRequestController.current.abort();
      activeRequestController.current = null;
    }
    setSending(false);
    setMessages([]);
    setStagedFiles([]);
    setMessageSearchQuery('');
    setIsMessageSearchOpen(false);

    const timeStr = new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', hour12: false });
    const updatedSessions = sessions.map((s) => {
      if (s.id === currentSessionId) {
        return { ...s, messages: [], updatedAt: timeStr };
      }
      return s;
    });
    setSessions(updatedSessions);
    void syncSessionsToBackend(updatedSessions);
    try {
      localStorage.removeItem('zyntheor_current_chat_session');
    } catch {}
    saveStatus.ok('local');
    setNotice('ล้างข้อความในการสนทนาเรียบร้อยแล้ว — เริ่มต้นเซสชันใหม่');
    setClearConfirmOpen(false);
    setTimeout(() => setNotice(''), 3500);
  };

  // Right-click context menu for messages
  const [messageContextMenu, setMessageContextMenu] = useState<{
    isOpen: boolean;
    x: number;
    y: number;
    message: Message | null;
  }>({
    isOpen: false,
    x: 0,
    y: 0,
    message: null,
  });

  const handleEditUserMessage = (msg: Message) => {
    startEditingMessage(msg);
  };

  // Undo Toast state & refs for restoring deleted messages within 5 seconds
  interface UndoDeletedSnapshot {
    items: { message: Message; index: number }[];
    sessionId: string;
    count: number;
  }
  const [undoSnapshot, setUndoSnapshot] = useState<UndoDeletedSnapshot | null>(null);
  const [undoCountdown, setUndoCountdown] = useState<number>(5);
  const undoToastTimerRef = useRef<NodeJS.Timeout | null>(null);
  const undoIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const triggerUndoToast = (items: { message: Message; index: number }[], sessionId: string) => {
    if (undoToastTimerRef.current) clearTimeout(undoToastTimerRef.current);
    if (undoIntervalRef.current) clearInterval(undoIntervalRef.current);

    setUndoSnapshot({ items, sessionId, count: items.length });
    setUndoCountdown(5);

    const startTime = Date.now();
    const durationMs = 5000;

    undoIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remainingSec = Math.max(0, Math.ceil((durationMs - elapsed) / 1000));
      setUndoCountdown(remainingSec);
    }, 200);

    undoToastTimerRef.current = setTimeout(() => {
      setUndoSnapshot(null);
      if (undoIntervalRef.current) clearInterval(undoIntervalRef.current);
    }, durationMs);
  };

  const handleUndoDelete = () => {
    if (!undoSnapshot) return;
    if (undoToastTimerRef.current) clearTimeout(undoToastTimerRef.current);
    if (undoIntervalRef.current) clearInterval(undoIntervalRef.current);

    const { items, sessionId } = undoSnapshot;

    // Restore messages at their original indices
    const sortedItems = [...items].sort((a, b) => a.index - b.index);

    if (sessionId === currentSessionId) {
      setMessages((prev) => {
        const restored = [...prev];
        for (const item of sortedItems) {
          const insertIdx = Math.min(Math.max(0, item.index), restored.length);
          restored.splice(insertIdx, 0, item.message);
        }
        const updatedSessions = sessions.map((s) => {
          if (s.id === sessionId) {
            return { ...s, messages: restored };
          }
          return s;
        });
        setSessions(updatedSessions);
        void syncSessionsToBackend(updatedSessions);
        return restored;
      });
    } else {
      const updatedSessions = sessions.map((s) => {
        if (s.id === sessionId) {
          const restored = [...s.messages];
          for (const item of sortedItems) {
            const insertIdx = Math.min(Math.max(0, item.index), restored.length);
            restored.splice(insertIdx, 0, item.message);
          }
          return { ...s, messages: restored };
        }
        return s;
      });
      setSessions(updatedSessions);
      void syncSessionsToBackend(updatedSessions);
    }

    setUndoSnapshot(null);
    setNotice(`กู้คืน ${items.length} ข้อความเรียบร้อยแล้ว`);
    setTimeout(() => setNotice(''), 3000);
  };

  const handleDismissUndo = () => {
    if (undoToastTimerRef.current) clearTimeout(undoToastTimerRef.current);
    if (undoIntervalRef.current) clearInterval(undoIntervalRef.current);
    setUndoSnapshot(null);
  };

  const handleDeleteUserMessage = (msgId: string) => {
    handleDeleteMessage(msgId);
  };

  const handleDeleteMessage = (msgId: string) => {
    if (editingMessageId === msgId) {
      setEditingMessageId(null);
    }
    const targetIndex = messages.findIndex((m) => m.id === msgId);
    if (targetIndex === -1) return;
    const deletedMsg = messages[targetIndex];

    const updated = messages.filter((m) => m.id !== msgId);
    setMessages(updated);
    const updatedSessions = sessions.map((s) => {
      if (s.id === currentSessionId) {
        return { ...s, messages: updated };
      }
      return s;
    });
    setSessions(updatedSessions);
    void syncSessionsToBackend(updatedSessions);

    // Trigger 5-second Undo notification with snapshot of deleted message
    triggerUndoToast([{ message: deletedMsg, index: targetIndex }], currentSessionId);
    setNotice('ลบข้อความออกจากการสนทนาแล้ว (สามารถกดกู้คืนได้ภายใน 5 วินาที)');
    setTimeout(() => setNotice(''), 3000);
  };

  // Multi-Selection Mode state and bulk action handlers
  const [selectionMode, setSelectionMode] = useState<boolean>(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<string[]>([]);

  const handleEnterSelectionMode = (initialMessageId?: string) => {
    setSelectionMode(true);
    if (initialMessageId) {
      setSelectedMessageIds([initialMessageId]);
    } else {
      setSelectedMessageIds([]);
    }
    setNotice('เข้าสู่โหมดเลือกข้อความ (Multi-selection mode)');
    setTimeout(() => setNotice(''), 2500);
  };

  const handleExitSelectionMode = () => {
    setSelectionMode(false);
    setSelectedMessageIds([]);
  };

  const toggleSelectMessage = (msgId: string) => {
    setSelectedMessageIds((prev) =>
      prev.includes(msgId) ? prev.filter((id) => id !== msgId) : [...prev, msgId]
    );
  };

  const handleSelectAllMessages = () => {
    const allIds = filteredMessages.map((m) => m.id);
    setSelectedMessageIds(allIds);
  };

  const handleDeselectAllMessages = () => {
    setSelectedMessageIds([]);
  };

  const handleBulkCopy = async () => {
    if (selectedMessageIds.length === 0) return;
    const selectedMsgs = messages.filter((m) => selectedMessageIds.includes(m.id));
    const textToCopy = selectedMsgs
      .map((m) => `[${m.role === 'assistant' ? 'ZYNTHEOR AI' : 'User'}] (${m.createdAt || ''}):\n${m.content}`)
      .join('\n\n---\n\n');

    if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(textToCopy);
      } catch {}
    }
    setNotice(`คัดลอก ${selectedMsgs.length} ข้อความลงในคลิปบอร์ดแล้ว`);
    setTimeout(() => setNotice(''), 2500);
  };

  const handleBulkDelete = () => {
    if (selectedMessageIds.length === 0) return;
    const idsToDelete = new Set(selectedMessageIds);

    const deletedItems: { message: Message; index: number }[] = [];
    messages.forEach((msg, idx) => {
      if (idsToDelete.has(msg.id)) {
        deletedItems.push({ message: msg, index: idx });
      }
    });

    const remaining = messages.filter((m) => !idsToDelete.has(m.id));
    setMessages(remaining);

    const updatedSessions = sessions.map((s) => {
      if (s.id === currentSessionId) {
        return { ...s, messages: remaining };
      }
      return s;
    });
    setSessions(updatedSessions);
    void syncSessionsToBackend(updatedSessions);

    // Trigger 5-second Undo notification for bulk deletion
    triggerUndoToast(deletedItems, currentSessionId);
    setNotice(`ลบ ${deletedItems.length} ข้อความออกจากการสนทนาแล้ว (กู้คืนได้ภายใน 5 วินาที)`);
    setTimeout(() => setNotice(''), 3000);

    // Exit selection mode after deleting
    handleExitSelectionMode();
  };

  const handleReportIssue = (msg: Message) => {
    setNotice(`บันทึกรายงานปัญหาสำหรับข้อความ #${msg.id.slice(0, 8)} เรียบร้อยแล้ว`);
    setTimeout(() => setNotice(''), 4000);
  };

  // File and sticker attachment state
  const [stagedFiles, setStagedFiles] = useState<MessageAttachment[]>([]);
  const [attachmentMenuOpen, setAttachmentMenuOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [stickerPickerOpen, setStickerPickerOpen] = useState(false);
  const [activeStickerCategory, setActiveStickerCategory] = useState<'cyber' | 'dev' | 'reactions'>('cyber');
  const [previewModalImage, setPreviewModalImage] = useState<{ url: string; name: string } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const activeRequestController = useRef<AbortController | null>(null);

  // Message search within active chat session
  const [messageSearchQuery, setMessageSearchQuery] = useState('');
  const [isMessageSearchOpen, setIsMessageSearchOpen] = useState(false);
  const messageSearchInputRef = useRef<HTMLInputElement>(null);

  const filteredMessages = useMemo(() => {
    return filterConversationMessages(messages, messageSearchQuery);
  }, [messages, messageSearchQuery]);

  function formatBytes(bytes: number): string {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
  }

  // Model Performance History (Recharts latency & throughput TPS tracking)
  const [modelPerfHistory, setModelPerfHistory] = useState<ModelPerformancePoint[]>(() => {
    try {
      const stored = localStorage.getItem('zyntheor_model_perf_history');
      if (stored) return JSON.parse(stored);
    } catch {}
    return [];
  });
  const [modelPerfModalOpen, setModelPerfModalOpen] = useState(false);
  const [highLatencyDismissed, setHighLatencyDismissed] = useState(false);

  // Advanced panels (Multiverse agent, live Runtime Metrics) are hidden by default so the UI matches the
  // simpler layout. Enable with ?advanced=1 or localStorage zyntheor_advanced_panels=1.
  const [advancedPanels] = useState<boolean>(() => {
    try {
      return new URLSearchParams(window.location.search).get('advanced') === '1'
        || localStorage.getItem('zyntheor_advanced_panels') === '1';
    } catch {
      return false;
    }
  });

  // Runtime Metrics state (live thread counts, GC frequency, event loop latency) with real-time polling
  const [runtimeMetrics, setRuntimeMetrics] = useState<{
    threadCount: number;
    activeHandles: number;
    gcFrequencyPerMinute: number;
    totalGcRuns: number;
    eventLoopLatencyMs: number;
    heapUsedMb: number;
    heapTotalMb: number;
    rssMb: number;
    uptimeSec: number;
    timestamp: string;
  } | null>(null);

  useEffect(() => {
    if (!advancedPanels) return;
    let active = true;
    const pollRuntimeMetrics = async () => {
      try {
        const res = await fetch('/api/system/runtime-metrics');
        if (res.ok) {
          const data = await res.json();
          if (active) setRuntimeMetrics(data);
        }
      } catch {}
    };

    void pollRuntimeMetrics();
    const interval = setInterval(pollRuntimeMetrics, 2000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [advancedPanels]);

  // Latest inference latency and performance issue detection (> 2000ms threshold)
  const latestPerfPoint = useMemo(() => {
    return modelPerfHistory.length > 0 ? modelPerfHistory[modelPerfHistory.length - 1] : null;
  }, [modelPerfHistory]);
  const latestLatency = latestPerfPoint?.latencyMs ?? null;
  const isHighLatency = typeof latestLatency === 'number' && latestLatency > 2000;

  // Record an inference performance measurement
  const recordPerfPoint = (data: {
    latencyMs: number;
    tokensPerSecond: number;
    tokensCount: number;
    model: string;
    provider: string;
    status: 'PASS' | 'FAIL' | 'UNAVAILABLE';
  }) => {
    setHighLatencyDismissed(false);
    const now = Date.now();
    const newPoint: ModelPerformancePoint = {
      id: `perf-${now}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: now,
      timeStr: new Date(now).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
      latencyMs: data.latencyMs,
      tokensPerSecond: data.tokensPerSecond,
      tokensCount: data.tokensCount,
      model: data.model || selectedModel || 'local-weights',
      provider: data.provider || providerChoice,
      status: data.status,
    };

    setModelPerfHistory((prev) => {
      const updated = [...prev, newPoint].slice(-40); // keep recent 40 samples
      try {
        localStorage.setItem('zyntheor_model_perf_history', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  // Pinned / Bookmarked Messages state
  const [pinnedMessages, setPinnedMessages] = useState<PinnedMessage[]>(() => {
    try {
      const stored = localStorage.getItem('zyntheor_pinned_messages');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [pinnedSectionOpen, setPinnedSectionOpen] = useState(true);
  const [pinnedSearchQuery, setPinnedSearchQuery] = useState('');
  const [pinnedTagFilter, setPinnedTagFilter] = useState<'ALL' | PinnedTag>('ALL');
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null);
  const [clickedMessageId, setClickedMessageId] = useState<string | null>(null);
  const [rippleEffect, setRippleEffect] = useState<{ messageId: string; x: number; y: number; size: number; key: number } | null>(null);

  const triggerMessageRipple = (e: React.MouseEvent<HTMLElement>, messageId: string) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const size = Math.max(rect.width, rect.height) * 1.6;
    setClickedMessageId(messageId);
    setRippleEffect({ messageId, x, y, size, key: Date.now() });
    setTimeout(() => {
      setClickedMessageId((prev) => (prev === messageId ? null : prev));
      setRippleEffect((prev) => (prev?.messageId === messageId ? null : prev));
    }, 450);
  };

  const isMessagePinned = (msgId: string) => pinnedMessages.some((p) => p.messageId === msgId);

  const togglePinMessage = (msg: Message) => {
    setPinnedMessages((prev) => {
      const exists = prev.some((p) => p.messageId === msg.id);
      let updated: PinnedMessage[];
      if (exists) {
        updated = prev.filter((p) => p.messageId !== msg.id);
        setNotice('ยกเลิกการปักหมุดข้อความแล้ว');
      } else {
        const curSession = sessions.find((s) => s.id === currentSessionId);
        const snippetText = msg.content.replace(/^#+\s+/gm, '').trim();
        const autoTag = detectTagFromContent(msg.content);
        const newPin: PinnedMessage = {
          id: `pin-${Date.now()}`,
          messageId: msg.id,
          sessionId: currentSessionId,
          sessionTitle: curSession?.title || 'การสนทนา',
          content: msg.content,
          snippet: snippetText.slice(0, 110) + (snippetText.length > 110 ? '...' : ''),
          createdAt: msg.createdAt,
          pinnedAt: new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', hour12: false }),
          tag: autoTag,
        };
        updated = [newPin, ...prev];
        setNotice(`ปักหมุดข้อความหมวด [${autoTag}] ไปยังแถบด้านข้างเรียบร้อยแล้ว`);
      }
      try {
        localStorage.setItem('zyntheor_pinned_messages', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const updatePinnedTag = (pinId: string, newTag: PinnedTag) => {
    setPinnedMessages((prev) => {
      const updated = prev.map((p) => (p.id === pinId ? { ...p, tag: newTag } : p));
      try {
        localStorage.setItem('zyntheor_pinned_messages', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const filteredPinnedMessages = useMemo(() => {
    const q = pinnedSearchQuery.trim().toLowerCase();
    return pinnedMessages.filter((pin) => {
      const matchesText =
        !q ||
        pin.content.toLowerCase().includes(q) ||
        pin.sessionTitle.toLowerCase().includes(q) ||
        pin.snippet.toLowerCase().includes(q);
      const matchesTag = pinnedTagFilter === 'ALL' || (pin.tag || 'General') === pinnedTagFilter;
      return matchesText && matchesTag;
    });
  }, [pinnedMessages, pinnedSearchQuery, pinnedTagFilter]);

  const handleJumpToPinnedMessage = (pin: PinnedMessage) => {
    // 1. Switch to chat mode if not already active
    if (activeMode !== 'chat' && activeMode !== 'auto') {
      const chatMode = modes.find((m) => m.id === 'chat') || AUTO_MODE;
      chooseMode(chatMode);
    }
    // 2. Switch session if different
    if (pin.sessionId && pin.sessionId !== currentSessionId) {
      const targetSession = sessions.find((s) => s.id === pin.sessionId);
      if (targetSession) {
        setCurrentSessionId(targetSession.id);
        setMessages(targetSession.messages);
      }
    }
    // 3. Highlight message with temporary glowing ring and scroll into view
    setHighlightedMessageId(pin.messageId);
    setTimeout(() => {
      const el = document.getElementById(pin.messageId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 180);
    setTimeout(() => {
      setHighlightedMessageId(null);
    }, 3200);
  };

  // Auto-Save feature: persists chat sessions to localStorage every 30 seconds
  const [lastAutoSavedAt, setLastAutoSavedAt] = useState<string | null>(null);
  const [autoSaveToast, setAutoSaveToast] = useState<{ visible: boolean; time: string } | null>(null);
  const autoSaveToastTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Initial restoration if localStorage has saved sessions and current session is empty
    try {
      const raw = localStorage.getItem('zyntheor_autosave_chat_sessions');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.sessions) && parsed.sessions.length > 0) {
          setSessions((current) => {
            if (current.length === 1 && current[0].messages.length === 0) {
              const restoredSession = parsed.sessions.find((s: any) => s.id === parsed.currentSessionId) || parsed.sessions[0];
              if (restoredSession) {
                setCurrentSessionId(restoredSession.id);
                setMessages(restoredSession.messages || []);
              }
              return parsed.sessions;
            }
            return current;
          });
          if (parsed.savedAt) {
            const time = new Date(parsed.savedAt).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
            setLastAutoSavedAt(time);
          }
        }
      }
    } catch (e) {
      console.warn('Could not restore auto-saved sessions:', e);
    }
  }, []);

  useEffect(() => {
    const AUTOSAVE_INTERVAL_MS = 30000; // 30 seconds

    const performAutoSave = () => {
      try {
        const payload = {
          savedAt: new Date().toISOString(),
          currentSessionId,
          sessions,
        };
        localStorage.setItem('zyntheor_autosave_chat_sessions', JSON.stringify(payload));
        const timeFormatted = new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
        setLastAutoSavedAt(timeFormatted);
        saveStatus.ok('local');

        // Show subtle 'Session auto-saved' toast briefly
        setAutoSaveToast({ visible: true, time: timeFormatted });
        if (autoSaveToastTimerRef.current) clearTimeout(autoSaveToastTimerRef.current);
        autoSaveToastTimerRef.current = setTimeout(() => {
          setAutoSaveToast(null);
        }, 3000);
      } catch (err) {
        console.warn('Auto-save to localStorage failed:', err);
        saveStatus.fail('local');
      }
    };

    // Auto-save interval every 30 seconds
    const intervalId = setInterval(performAutoSave, AUTOSAVE_INTERVAL_MS);

    // Save immediately before page unload or visibility change
    const handleBeforeUnload = () => {
      performAutoSave();
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearInterval(intervalId);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      if (autoSaveToastTimerRef.current) clearTimeout(autoSaveToastTimerRef.current);
    };
  }, [sessions, currentSessionId]);


  async function processIncomingFiles(incoming: FileList | File[]) {
    const list = Array.from(incoming);
    if (list.length === 0) return;

    // Match the active chat API's actual capabilities and limits. Do not stage arbitrary
    // binary files that the server cannot decode or silently claim were analyzed.
    const supportedTextExtensions = new Set([
      '.txt', '.md', '.json', '.jsonl', '.csv', '.tsv', '.yaml', '.yml', '.xml',
      '.html', '.htm', '.css', '.scss', '.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx',
      '.py', '.rb', '.go', '.rs', '.java', '.c', '.cpp', '.h', '.hpp', '.cs', '.php',
      '.sh', '.bash', '.zsh', '.sql', '.toml', '.ini', '.log',
    ]);
    const MAX_FILES = 5;
    const MAX_FILE_BYTES = 1024 * 1024;
    const MAX_TEXT_BYTES_TOTAL = 100 * 1024;
    const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
    const remainingSlots = MAX_FILES - stagedFiles.length;
    if (remainingSlots <= 0) {
      setNotice(`แนบได้สูงสุด ${MAX_FILES} ไฟล์ต่อข้อความ กรุณาลบไฟล์ที่ไม่ใช้ก่อน`);
      return;
    }

    const newAttachments: MessageAttachment[] = [];
    let stagedTextBytes = stagedFiles.filter((f) => f.type === 'file').reduce((sum, f) => sum + (f.size || 0), 0);
    const candidates = list.slice(0, remainingSlots);
    for (const file of candidates) {
      const isImg = file.type.startsWith('image/');
      const ext = file.name.includes('.') ? `.${file.name.split('.').pop()!.toLowerCase()}` : '';
      if (isImg) {
        if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(file.type.toLowerCase())) {
          setNotice(`ไม่รองรับรูปแบบภาพ ${file.name} กรุณาใช้ PNG, JPG, WebP หรือ GIF`);
          continue;
        }
        if (file.size > MAX_IMAGE_BYTES) {
          setNotice(`รูปภาพ ${file.name} มีขนาดเกิน 2 MB`);
          continue;
        }
      } else {
        if (!supportedTextExtensions.has(ext)) {
          setNotice(`ไม่รองรับไฟล์ ${file.name} ใน Chat API ปัจจุบัน รองรับไฟล์ข้อความและโค้ดที่กำหนดเท่านั้น`);
          continue;
        }
        if (file.size > MAX_FILE_BYTES) {
          setNotice(`ไฟล์ ${file.name} มีขนาดเกิน 1 MB`);
          continue;
        }
        if (stagedTextBytes + file.size > MAX_TEXT_BYTES_TOTAL) {
          setNotice('ไฟล์ข้อความรวมกันต้องไม่เกิน 100 KB ต่อข้อความ ตามขีดจำกัดบริบทของ Chat API');
          continue;
        }
      }

      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : '');
        reader.onerror = () => resolve('');
        reader.readAsDataURL(file);
      });
      if (!dataUrl.startsWith('data:')) {
        setNotice(`อ่านไฟล์ ${file.name} ไม่สำเร็จ กรุณาลองใหม่`);
        continue;
      }

      newAttachments.push({
        id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        name: file.name,
        type: isImg ? 'image' : 'file',
        url: dataUrl,
        previewUrl: isImg ? dataUrl : undefined,
        size: file.size,
        mimeType: file.type || (isImg ? 'image/png' : 'text/plain'),
      });
      if (!isImg) stagedTextBytes += file.size;
    }

    if (list.length > remainingSlots) {
      setNotice(`เลือกได้อีก ${remainingSlots} รายการเท่านั้น ระบบละเว้นไฟล์ที่เกินจำนวนสูงสุด ${MAX_FILES} รายการ`);
    } else if (newAttachments.length > 0) {
      setNotice(`เพิ่มไฟล์ไว้ในข้อความแล้ว ${newAttachments.length} รายการ กรุณาตรวจรายการก่อนส่ง`);
    }
    if (newAttachments.length > 0) setStagedFiles((prev) => [...prev, ...newAttachments]);
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      void processIncomingFiles(e.target.files);
      e.target.value = '';
    }
  };

  const handleImageInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      void processIncomingFiles(e.target.files);
      e.target.value = '';
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    if (e.clipboardData?.files && e.clipboardData.files.length > 0) {
      const imgFiles = Array.from(e.clipboardData.files).filter((f) => f.type.startsWith('image/'));
      if (imgFiles.length > 0) {
        e.preventDefault();
        void processIncomingFiles(imgFiles);
      }
    }
  };

  const handleRemoveStagedFile = (id: string) => {
    setStagedFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleSendSticker = async (stickerEmoji: string, stickerLabel?: string) => {
    if (providerChoice !== 'local' && !providerConsent) {
      setNotice('กรุณายืนยันการส่งข้อความไปยัง Online Provider สำหรับคำขอนี้ก่อน');
      return;
    }
    const explicitUserConsent = providerChoice !== 'local' && providerConsent;
    setProviderConsent(false);
    setStickerPickerOpen(false);
    const now = Date.now();
    const timeStr = new Date(now).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    const userMsgId = `user-sticker-${now}`;
    const stickerText = stickerLabel ? `[สติกเกอร์: ${stickerLabel}] ${stickerEmoji}` : `[สติกเกอร์] ${stickerEmoji}`;

    const newMsgs: Message[] = [
      ...messages,
      {
        id: userMsgId,
        role: 'user',
        content: stickerText,
        timestamp: now,
        createdAt: timeStr,
        isSticker: true,
        stickerEmoji,
        stickerLabel,
      },
    ];
    setMessages(newMsgs);
    setSending(true);
    const requestController = new AbortController();
    activeRequestController.current = requestController;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: requestController.signal,
        body: JSON.stringify({
          message: stickerText,
          mode: resolveRequestMode(stickerText),
          depth: 'FAST',
          conversationId: currentSessionId,
          provider: providerChoice,
          explicitUserConsent,
          isSticker: true,
          stickerEmoji,
          stickerLabel,
          localEndpoint: localEndpoint || undefined,
          modelId: selectedModel || undefined,
          history: messages.slice(-12).map(({ role, content }) => ({ role, content })),
        }),
      });

      let data: any = {};
      try {
        const rawText = await response.text();
        data = JSON.parse(rawText);
      } catch {
        data = {};
      }
      const assistant = data?.assistantMessage;
      const hasAssistantContent = typeof assistant?.content === 'string' && assistant.content.trim().length > 0;
      const replyContent = hasAssistantContent
        ? assistant.content
        : (data?.message || data?.error
          ? `[UNAVAILABLE] ${data.message || data.error}`
          : (response.status === 503
              ? '[UNAVAILABLE] ไม่สามารถเชื่อมต่อ Local AI Runtime ได้ (Local Daemon Offline)\n\nกรุณาเปิดการทำงานของ runtime ด้วยคำสั่ง `ollama serve` หรือสลับโหมด/เลือก Online Provider'
              : `[UNAVAILABLE] ไม่สามารถประมวลผลคำขอได้ (HTTP ${response.status} ${response.statusText || 'Error'})`));

      const nowAssis = Date.now();
      const finalMsgs: Message[] = [
        ...newMsgs,
        {
          id: assistant?.id || `assistant-${nowAssis}`,
          role: 'assistant',
          content: replyContent,
          status: String(data?.status || (response.ok && hasAssistantContent ? 'AVAILABLE' : 'UNAVAILABLE')).toUpperCase(),
          timestamp: nowAssis,
          createdAt: new Date(nowAssis).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
        },
      ];
      setMessages(finalMsgs);

      const updatedSessions = sessions.map((s) => {
        if (s.id === currentSessionId) {
          return { ...s, messages: finalMsgs, updatedAt: timeStr };
        }
        return s;
      });
      setSessions(updatedSessions);
      void syncSessionsToBackend(updatedSessions);
    } catch (err: any) {
      const failureContent = requestController.signal.aborted
        ? '[UNAVAILABLE] ยกเลิกคำขอตามคำขอของผู้ใช้แล้ว'
        : `[UNAVAILABLE] การเชื่อมต่อขัดข้อง: ${err?.message || 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้'}`;
      const nowErr = Date.now();
      const errorMsgs: Message[] = [
        ...newMsgs,
        {
          id: `error-${nowErr}`,
          role: 'assistant',
          content: failureContent,
          status: 'UNAVAILABLE',
          timestamp: nowErr,
          createdAt: new Date(nowErr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
        },
      ];
      setMessages(errorMsgs);
    } finally {
      if (activeRequestController.current === requestController) activeRequestController.current = null;
      setSending(false);
    }
  };

  async function sendMessage(event?: FormEvent) {
    event?.preventDefault();
    const hasFiles = stagedFiles.length > 0;
    let message = draft.trim();
    if (!message && !hasFiles) return;
    if (sending) return;
    if (providerChoice !== 'local' && !providerConsent) {
      setNotice('กรุณายืนยันการส่งข้อความไปยัง Online Provider สำหรับคำขอนี้ก่อน');
      return;
    }
    const explicitUserConsent = providerChoice !== 'local' && providerConsent;
    setProviderConsent(false);

    if (!message && hasFiles) {
      message = `[แนบไฟล์/รูปภาพ: ${stagedFiles.map((f) => f.name).join(', ')}]`;
    }

    const currentFiles = [...stagedFiles];
    const imageList = currentFiles.filter((f) => f.type === 'image').map((f) => f.url);
    // The current /api/chat route explicitly rejects image ingestion. Block before
    // mutating conversation state so the user can remove images or keep them staged.
    if (imageList.length > 0) {
      setNotice('ขณะนี้ Chat API ยังวิเคราะห์รูปภาพไม่ได้ ไฟล์รูปยังอยู่ในรายการแนบ กรุณานำรูปออกแล้วส่งข้อความ/ไฟล์ข้อความ หรือใช้ image-capable backend เมื่อได้รับการยืนยันว่ารองรับ');
      return;
    }

    const now = Date.now();
    const timeStr = new Date(now).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    const userMsgId = `user-${now}`;

    const newMsgs: Message[] = [
      ...messages,
      {
        id: userMsgId,
        role: 'user',
        content: message,
        timestamp: now,
        createdAt: timeStr,
        attachments: currentFiles.length > 0 ? currentFiles.map((f) => ({ id: f.id, name: f.name, type: f.type, size: f.size, mimeType: f.mimeType, url: '' })) : undefined,
        images: imageList.length > 0 ? imageList : undefined,
      },
    ];
    setMessages(newMsgs);
    setDraft('');
    setStagedFiles([]);
    setSending(true);
    const requestController = new AbortController();
    activeRequestController.current = requestController;
    const sendStartTime = Date.now();

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: requestController.signal,
        body: JSON.stringify({
          message: activeMode === 'plan' ? `โหมดคิดและวางแผน: วิเคราะห์เป้าหมาย ข้อจำกัด ความเสี่ยง และจัดลำดับขั้นตอนก่อนลงมือ โดยอย่าอ้างว่าทำงานหรือทดสอบแล้วหากไม่มีหลักฐานจริง\n\nคำขอของผู้ใช้: ${message}` : message,
          mode: resolveRequestMode(message),
          depth: 'FAST',
          conversationId: currentSessionId,
          provider: providerChoice,
          explicitUserConsent,
          localEndpoint: localEndpoint || undefined,
          modelId: selectedModel || undefined,
          files: currentFiles.filter((f) => f.type === 'file').map((f) => ({
            name: f.name,
            mimeType: f.mimeType,
            contentBase64: f.url.includes(',') ? f.url.split(',')[1] : f.url,
          })),
          attachments: currentFiles.map((f) => ({
            id: f.id,
            name: f.name,
            type: f.type,
            size: f.size,
            mimeType: f.mimeType,
            // Text/code files are already read as data URLs for preview; the server
            // validates size, extension and decoded content before analysis.
            contentDataUrl: f.type === 'file' ? f.url : undefined,
          })),
          images: imageList,
          history: messages.slice(-12).map(({ role, content }) => ({ role, content })),
        }),
      });

      let data: any = {};
      try {
        const rawText = await response.text();
        data = JSON.parse(rawText);
      } catch {
        data = {};
      }
      const assistant = data?.assistantMessage;

      const hasAssistantContent = typeof assistant?.content === 'string' && assistant.content.trim().length > 0;
      const replyContent = hasAssistantContent
        ? assistant.content
        : (data?.message || data?.error
          ? `[UNAVAILABLE] ${data.message || data.error}`
          : (response.status === 503
              ? '[UNAVAILABLE] ไม่สามารถเชื่อมต่อ Local AI Runtime ได้ (Local Daemon Offline)\n\nกรุณาเปิดการทำงานของ runtime ด้วยคำสั่ง `ollama serve` หรือเลือก Online Provider พร้อมระบุ API Key'
              : `[UNAVAILABLE] ไม่สามารถประมวลผลคำขอได้ (HTTP ${response.status} ${response.statusText || 'Error'})`));
      const replyStatus = String(data?.status || (response.ok && hasAssistantContent ? 'AVAILABLE' : 'UNAVAILABLE')).toUpperCase();

      const nowAssis = Date.now();
      const finalMsgs: Message[] = [
        ...newMsgs,
        {
          id: assistant?.id || `assistant-${nowAssis}`,
          role: 'assistant',
          content: replyContent,
          status: replyStatus,
          timestamp: nowAssis,
          createdAt: new Date(nowAssis).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
        },
      ];
      setMessages(finalMsgs);

      // Record performance metrics for historical chart
      const elapsedMs = Date.now() - sendStartTime;
      const measuredLatency = typeof data?.latencyMs === 'number' && data.latencyMs > 0 ? data.latencyMs : elapsedMs;
      const estimatedTokens = Math.max(1, Math.round(replyContent.length / 3.5));
      const calculatedTps = typeof data?.tokensPerSecond === 'number' && data.tokensPerSecond > 0
        ? data.tokensPerSecond
        : measuredLatency > 0
        ? parseFloat(((estimatedTokens * 1000) / measuredLatency).toFixed(1))
        : 26.5;

      recordPerfPoint({
        latencyMs: measuredLatency,
        tokensCount: estimatedTokens,
        tokensPerSecond: calculatedTps,
        model: data?.model || selectedModel || 'local-weights',
        provider: data?.provider || providerChoice,
        status: replyStatus === 'AVAILABLE' || replyStatus === 'COMPLETED' ? 'PASS' : 'UNAVAILABLE',
      });

      // Update session title, auto-assigned tags & sync
      const autoTags = analyzeSessionTags(finalMsgs);
      const updatedSessions = sessions.map((s) => {
        if (s.id === currentSessionId) {
          const title = s.customTitle ? s.title : (s.title.startsWith('การสนทนาใหม่') ? message.slice(0, 28) : s.title);
          return { ...s, title, messages: finalMsgs, tags: autoTags, updatedAt: timeStr };
        }
        return s;
      });
      setSessions(updatedSessions);
      void syncSessionsToBackend(updatedSessions);
    } catch (err: any) {
      const failureContent = requestController.signal.aborted
        ? '[UNAVAILABLE] ยกเลิกคำขอตามคำขอของผู้ใช้แล้ว'
        : `[UNAVAILABLE] การเชื่อมต่อขัดข้อง: ${err?.message || 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้'}`;
      const nowErr = Date.now();
      const errorMsgs: Message[] = [
        ...newMsgs,
        {
          id: `error-${nowErr}`,
          role: 'assistant',
          content: failureContent,
          status: 'UNAVAILABLE',
          timestamp: nowErr,
          createdAt: new Date(nowErr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
        },
      ];
      setMessages(errorMsgs);
    } finally {
      if (activeRequestController.current === requestController) activeRequestController.current = null;
      setSending(false);
    }
  }

  const startEditingMessage = (msg: Message) => {
    setEditingMessageId(msg.id);
    setEditDraft(msg.content);
  };

  const handleMessageFeedback = (messageId: string, feedback: 'like' | 'dislike') => {
    setMessages((current) => current.map((item) => item.id === messageId
      ? { ...item, feedback: item.feedback === feedback ? null : feedback }
      : item));
  };

  const handleRetryAssistantMessage = (messageId: string) => {
    const index = messages.findIndex((item) => item.id === messageId);
    if (index < 0 || sending) return;
    const previousUserMessage = [...messages.slice(0, index)].reverse().find((item) => item.role === 'user');
    if (!previousUserMessage) {
      setNotice('ไม่พบคำถามก่อนหน้าสำหรับลองอีกครั้ง');
      return;
    }
    setDraft(previousUserMessage.content);
    setNotice('ใส่คำถามเดิมในช่องพิมพ์แล้ว ตรวจสอบก่อนกดส่งอีกครั้ง');
  };

  async function handleSaveAndResendEdit(messageId: string, newContent: string) {
    const trimmed = newContent.trim();
    if (!trimmed) return;
    if (sending) return;
    setEditingMessageId(null);

    // 1. Locate message index in conversation
    const index = messages.findIndex((m) => m.id === messageId);
    if (index === -1) return;

    const originalMsg = messages[index];
    const now = Date.now();
    const timeStr = new Date(now).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });

    // If editing assistant message, update in place
    if (originalMsg.role === 'assistant') {
      const updatedAssistantMsg: Message = {
        ...originalMsg,
        content: trimmed,
        timestamp: now,
        createdAt: timeStr,
      };
      setMessages(messages.map((m) => (m.id === messageId ? updatedAssistantMsg : m)));
      saveStatus.ok('local');
      return;
    }

    // 2. Truncate later messages after this point for user message resend
    const historyBefore = messages.slice(0, index);
    const updatedUserMsg: Message = {
      ...originalMsg,
      content: trimmed,
      timestamp: now,
      createdAt: timeStr,
    };

    const newMsgs: Message[] = [...historyBefore, updatedUserMsg];
    setMessages(newMsgs);
    setSending(true);

    const requestController = new AbortController();
    activeRequestController.current = requestController;
    const sendStartTime = Date.now();
    const explicitUserConsent = providerChoice !== 'local' && providerConsent;
    setProviderConsent(false);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: requestController.signal,
        body: JSON.stringify({
          message: trimmed,
          mode: resolveRequestMode(trimmed),
          depth: 'FAST',
          conversationId: currentSessionId,
          provider: providerChoice,
          explicitUserConsent,
          localEndpoint: localEndpoint || undefined,
          modelId: selectedModel || undefined,
          history: historyBefore.slice(-12).map(({ role, content }) => ({ role, content })),
        }),
      });

      let data: any = {};
      try {
        const rawText = await response.text();
        data = JSON.parse(rawText);
      } catch {
        data = {};
      }
      const assistant = data?.assistantMessage;

      const hasAssistantContent = typeof assistant?.content === 'string' && assistant.content.trim().length > 0;
      const replyContent = hasAssistantContent
        ? assistant.content
        : (data?.message || data?.error
          ? `[UNAVAILABLE] ${data.message || data.error}`
          : (response.status === 503
              ? '[UNAVAILABLE] ไม่สามารถเชื่อมต่อ Local AI Runtime ได้ (Local Daemon Offline)\n\nกรุณาเปิดการทำงานของ runtime ด้วยคำสั่ง `ollama serve` หรือเลือก Online Provider พร้อมระบุ API Key'
              : `[UNAVAILABLE] ไม่สามารถประมวลผลคำขอได้ (HTTP ${response.status} ${response.statusText || 'Error'})`));
      const replyStatus = String(data?.status || (response.ok && hasAssistantContent ? 'AVAILABLE' : 'UNAVAILABLE')).toUpperCase();

      const nowAssis = Date.now();
      const finalMsgs: Message[] = [
        ...newMsgs,
        {
          id: assistant?.id || `assistant-${nowAssis}`,
          role: 'assistant',
          content: replyContent,
          status: replyStatus,
          timestamp: nowAssis,
          createdAt: new Date(nowAssis).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
        },
      ];
      setMessages(finalMsgs);

      // Record performance metrics for historical chart
      const elapsedMs = Date.now() - sendStartTime;
      const measuredLatency = typeof data?.latencyMs === 'number' && data.latencyMs > 0 ? data.latencyMs : elapsedMs;
      const estimatedTokens = Math.max(1, Math.round(replyContent.length / 3.5));
      const calculatedTps = typeof data?.tokensPerSecond === 'number' && data.tokensPerSecond > 0
        ? data.tokensPerSecond
        : measuredLatency > 0
        ? parseFloat(((estimatedTokens * 1000) / measuredLatency).toFixed(1))
        : 26.5;

      recordPerfPoint({
        latencyMs: measuredLatency,
        tokensCount: estimatedTokens,
        tokensPerSecond: calculatedTps,
        model: data?.model || selectedModel || 'local-weights',
        provider: data?.provider || providerChoice,
        status: replyStatus === 'AVAILABLE' || replyStatus === 'COMPLETED' ? 'PASS' : 'UNAVAILABLE',
      });

      const autoTags = analyzeSessionTags(finalMsgs);
      const updatedSessions = sessions.map((s) => {
        if (s.id === currentSessionId) {
          return { ...s, messages: finalMsgs, tags: autoTags, updatedAt: timeStr };
        }
        return s;
      });
      setSessions(updatedSessions);
      void syncSessionsToBackend(updatedSessions);
    } catch (err: any) {
      const failureContent = requestController.signal.aborted
        ? '[UNAVAILABLE] ยกเลิกคำขอตามคำขอของผู้ใช้แล้ว'
        : `[UNAVAILABLE] การเชื่อมต่อขัดข้อง: ${err?.message || 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้'}`;
      const nowErr = Date.now();
      const errorMsgs: Message[] = [
        ...newMsgs,
        {
          id: `error-${nowErr}`,
          role: 'assistant',
          content: failureContent,
          status: 'UNAVAILABLE',
          timestamp: nowErr,
          createdAt: new Date(nowErr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
        },
      ];
      setMessages(errorMsgs);
    } finally {
      if (activeRequestController.current === requestController) activeRequestController.current = null;
      setSending(false);
    }
  }

  // Accessibility keyboard navigation through past messages using Up/Down arrow keys when chat input is unfocused
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in any input/textarea/select or contentEditable
      const activeTag = document.activeElement?.tagName;
      const isInput =
        activeTag === 'INPUT' ||
        activeTag === 'TEXTAREA' ||
        activeTag === 'SELECT' ||
        (document.activeElement as HTMLElement)?.isContentEditable;
      if (isInput) return;

      // Ignore modifier combinations (shortcuts like Alt + F, Alt + N, etc.)
      if (e.altKey || e.ctrlKey || e.metaKey) return;

      if (e.key === 'ArrowUp') {
        if (filteredMessages.length === 0) return;
        e.preventDefault();
        setFocusedMessageIndex((prev) => {
          const nextIndex = prev === null || prev <= 0 ? filteredMessages.length - 1 : prev - 1;
          const targetMsg = filteredMessages[nextIndex];
          if (targetMsg) {
            const el = document.getElementById(targetMsg.id);
            if (el) {
              el.focus();
              el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
          }
          return nextIndex;
        });
      } else if (e.key === 'ArrowDown') {
        if (filteredMessages.length === 0) return;
        e.preventDefault();
        setFocusedMessageIndex((prev) => {
          const nextIndex = prev === null || prev >= filteredMessages.length - 1 ? 0 : prev + 1;
          const targetMsg = filteredMessages[nextIndex];
          if (targetMsg) {
            const el = document.getElementById(targetMsg.id);
            if (el) {
              el.focus();
              el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
          }
          return nextIndex;
        });
      } else if (e.key === 'Escape') {
        setFocusedMessageIndex(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [filteredMessages]);

  // Live real system metrics and telemetry
  // Real values only: null until the server has reported them.
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [telemetry, setTelemetry] = useState<TelemetryEvent[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (pendingBuildSend === null) return;
    if (draft !== pendingBuildSend || activeMode !== 'code') return;
    setPendingBuildSend(null);
    if (sending) {
      setNotice('กำลังตอบข้อความก่อนหน้าอยู่ คำสั่งถูกใส่ในช่องแชทโหมดเขียนโค้ดแล้ว กดส่งเมื่อพร้อม');
      window.setTimeout(() => setNotice(''), 5000);
      return;
    }
    // Same path as pressing send: provider-consent, attachment and error checks all still apply.
    void sendMessage();
  }, [pendingBuildSend, draft, activeMode]);

  useEffect(() => {
    if (!userMenuOpen) return undefined;
    const onPointerDown = (event: PointerEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) setUserMenuOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === 'Escape') setUserMenuOpen(false); };
    document.addEventListener('pointerdown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('pointerdown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [userMenuOpen]);

  const active = useMemo(() => ALL_MODES.find((mode) => mode.id === activeMode) ?? AUTO_MODE, [activeMode]);

  // Live real clock
  const [currentTime, setCurrentTime] = useState(() => {
    const d = new Date();
    return {
      time: d.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
      date: d.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' }),
    };
  });

  useEffect(() => {
    const clockInterval = setInterval(() => {
      const d = new Date();
      setCurrentTime({
        time: d.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
        date: d.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' }),
      });
    }, 1000);
    return () => clearInterval(clockInterval);
  }, []);

  // Poll real health and expose the initializing state during each probe.
  useEffect(() => {
    let active = true;
    let inFlight = false;
    const checkHealth = async () => {
      if (inFlight) return;
      inFlight = true;
      if (active) setHealthState('loading');
      try {
        const response = await fetch('/api/health');
        const data = await response.json();
        if (!response.ok) throw new Error('Health check failed');
        if (active) { setHealth(data); setHealthState('ready'); }
      } catch {
        if (active) setHealthState('error');
      } finally { inFlight = false; }
    };
    void checkHealth();
    const timer = window.setInterval(() => void checkHealth(), 15000);
    return () => { active = false; window.clearInterval(timer); };
  }, []);

  useEffect(() => {
    fetch('/api/providers/status')
      .then(async (response) => {
        if (!response.ok) throw new Error('Provider status unavailable');
        const data = await response.json();
        if (Array.isArray(data.providers)) setOnlineProviders(data.providers);
      })
      .catch(() => setOnlineProviders([]));
  }, []);

  useEffect(() => {
    let active = true;
    const fetchConnectors = () => {
      fetch('/api/engine/connectors')
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (!active) return;
          if (Array.isArray(data?.connectors)) {
            const webConn = data.connectors.find((c: any) => c.id === 'web_research');
            setWebSearchAvailable(webConn?.availability === 'AVAILABLE');
          } else {
            setWebSearchAvailable(false);
          }
        })
        .catch(() => {
          if (active) setWebSearchAvailable(false);
        });
    };
    void fetchConnectors();
    const timer = window.setInterval(fetchConnectors, 20000);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, []);

  // Fetch real System Metrics & Telemetry
  useEffect(() => {
    const fetchMetrics = () => {
      fetch('/api/system/metrics')
        .then((res) => res.json())
        .then((data) => {
          if (data?.resources) {
            setMetrics(data.resources);
          }
        })
        .catch(() => {});
    };

    const fetchTelemetry = () => {
      fetch('/api/system/telemetry')
        .then((res) => res.json())
        .then((data) => {
          if (Array.isArray(data?.events)) {
            setTelemetry(data.events);
          }
        })
        .catch(() => {});
    };

    fetchMetrics();
    fetchTelemetry();

    const interval = setInterval(() => {
      fetchMetrics();
      fetchTelemetry();
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  // Load synced sessions from server if available
  useEffect(() => {
    fetch('/api/sessions/sync')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data?.sessions) && data.sessions.length > 0) {
          const enriched = data.sessions.map((s: any) => ({
            ...s,
            tags: Array.isArray(s.tags) && s.tags.length > 0 ? s.tags : analyzeSessionTags(s.messages || []),
          }));
          setSessions(enriched);
          const first = enriched[0];
          if (first) {
            setCurrentSessionId(first.id);
            setMessages(first.messages || []);
          }
        }
      })
      .catch(() => {});
  }, []);


  function resolveRequestMode(text: string): string {
    // A mode the user picked by hand is always honoured; detection only runs while 'auto' is selected.
    if (activeMode !== 'auto') return activeMode;
    const detection = detectModeWithEvidence(text);
    const label = ALL_MODES.find((m) => m.id === detection.mode)?.label ?? detection.mode;
    setNotice(explainAutoChoice(detection, label));
    window.setTimeout(() => setNotice(''), 4200);
    return detection.mode === 'chat' ? 'auto' : detection.mode;
  }

  function chooseMode(mode: Mode) {
    if (mode.id === 'build' || mode.id === 'projects') {
      setWorkspacePanelTab(mode.id === 'build' ? 'build' : 'projects');
      setWorkspacePanelOpen(true);
      if (window.innerWidth < 1024) { setSidebarOpen(false); setRightRailOpen(false); }
      return;
    }
    setActiveMode(mode.id);
    try { localStorage.setItem('zyntheor_active_mode', mode.id); } catch { /* storage unavailable: choice lasts for this session only */ }
    if (!mode.available) {
      setNotice(`${mode.label}: UNAVAILABLE — ยังไม่มี connector ที่ยืนยันการทำงานใน backend`);
      window.setTimeout(() => setNotice(''), 4200);
    }
  }

  function handleCopy(text: string, id: string) {
    navigator.clipboard.writeText(text);
    setCopyFeedback(id);
    setTimeout(() => setCopyFeedback(null), 2000);
  }

  // Pushes sessions to the backend and reports the real outcome (res.ok) to the save indicator.
  async function syncSessionsToBackend(list: ChatSession[]) {
    saveStatus.begin('server');
    try {
      const res = await fetch('/api/sessions/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessions: list }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      saveStatus.ok('server');
    } catch {
      saveStatus.fail('server');
    }
  }

  // Session Management
  function handleSelectSession(session: ChatSession, showOverview = true) {
    setCurrentSessionId(session.id);
    setMessages(session.messages || []);
    setMessageSearchQuery('');
    setHistoryDrawerOpen(false);
    if (showOverview) {
      setOverviewSession(session);
      setIsOverviewOpen(true);
    }
  }

  function handleOpenSessionOverview(session: ChatSession, e?: React.MouseEvent) {
    if (e) e.stopPropagation();
    setCurrentSessionId(session.id);
    setMessages(session.messages || []);
    setOverviewSession(session);
    setIsOverviewOpen(true);
  }

  function handleCreateNewSession() {
    const newId = `session-${Date.now()}`;
    const newSession: ChatSession = {
      id: newId,
      title: `การสนทนาใหม่ #${sessions.length + 1}`,
      updatedAt: new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', hour12: false }),
      messages: [],
      tags: [],
    };
    const updated = [newSession, ...sessions];
    setSessions(updated);
    setCurrentSessionId(newId);
    setMessages(newSession.messages);
    setMessageSearchQuery('');
    setHistoryDrawerOpen(false);

    // Sync to backend
    void syncSessionsToBackend(updated);
  }

  function handleDeleteSession(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    if (sessions.length <= 1) return;
    const filtered = sessions.filter((s) => s.id !== id);
    setSessions(filtered);
    if (currentSessionId === id) {
      const next = filtered[0];
      setCurrentSessionId(next.id);
      setMessages(next.messages);
    }
    void syncSessionsToBackend(filtered);
  }

  // Inline Session Renaming state & handlers
  const [savedSessionsSectionOpen, setSavedSessionsSectionOpen] = useState(true);
  const [renamingSessionId, setRenamingSessionId] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');

  function handleStartRenameSession(id: string, currentTitle: string, e?: React.MouseEvent) {
    e?.stopPropagation();
    setRenamingSessionId(id);
    setRenameDraft(currentTitle);
  }

  function handleSaveRenameSession(id: string, e?: React.MouseEvent | React.FormEvent) {
    e?.stopPropagation();
    const trimmed = renameDraft.trim();
    if (!trimmed) {
      setRenamingSessionId(null);
      return;
    }

    const updated = sessions.map((s) => {
      if (s.id === id) {
        return { ...s, title: trimmed, customTitle: true };
      }
      return s;
    });

    setSessions(updated);
    setRenamingSessionId(null);

    // Save to localStorage immediately
    try {
      const payload = {
        savedAt: new Date().toISOString(),
        currentSessionId,
        sessions: updated,
      };
      localStorage.setItem('zyntheor_autosave_chat_sessions', JSON.stringify(payload));
      saveStatus.ok('local');
    } catch {
      saveStatus.fail('local');
    }

    // Sync to backend
    void syncSessionsToBackend(updated);
    setNotice(`เปลี่ยนชื่อเซสชันเป็น "${trimmed}" เรียบร้อยแล้ว`);
    setTimeout(() => setNotice(''), 3000);
  }

  function handleCancelRenameSession(e?: React.MouseEvent) {
    e?.stopPropagation();
    setRenamingSessionId(null);
    setRenameDraft('');
  }

  async function testLocalEndpointConnection() {
    setTestingEndpoint(true);
    try {
      const query = localEndpoint ? `?endpoint=${encodeURIComponent(localEndpoint)}` : '';
      const res = await fetch(`/api/local-model/status${query}`);
      const data = await res.json();
      setLocalModelStatus(data);
      if (typeof data.endpoint === 'string') setLocalEndpoint(data.endpoint);
      const models = Array.isArray(data.models) ? data.models as string[] : [];
      setSelectedModel((current) => models.includes(current) ? current : models[0] || '');
      setCompareModelA((current) => models.includes(current) ? current : models[0] || '');
      setCompareModelB((current) => models.includes(current) && current !== (models[0] || '') ? current : models.find((model: string) => model !== (models[0] || '')) || '');

    } catch {
      setLocalModelStatus({ connected: false, message: 'ไม่สามารถติดต่อ local model server ได้' });
    } finally {
      setTestingEndpoint(false);
    }
  }

  const serverStatus = deriveServerStatus(healthState);
  const modelStatus = deriveModelStatus(localModelStatus);

  // Probe the local runtime once on load so the Model status reflects real evidence.
  useEffect(() => {
    void testLocalEndpointConnection();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const availableModels = Array.isArray(localModelStatus?.models) ? localModelStatus.models as string[] : [];
  const compareModelStats = useMemo(() => {
    const summarize = (model: string) => {
      const points = modelPerfHistory.filter((point) => point.model === model && point.provider === 'local' && point.status === 'PASS');
      const avg = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null;
      const memoryByModel = localModelStatus?.memoryByModel as Record<string, number | null> | undefined;
      return {
        model,
        latencyMs: avg(points.map((point) => point.latencyMs).filter(Number.isFinite)),
        tokensPerSecond: avg(points.map((point) => point.tokensPerSecond).filter(Number.isFinite)),
        memoryBytes: typeof memoryByModel?.[model] === 'number' && Number.isFinite(memoryByModel[model]) ? memoryByModel[model] : null,
        sampleCount: points.length,
      };
    };
    return [compareModelA, compareModelB].filter(Boolean).map(summarize);
  }, [compareModelA, compareModelB, modelPerfHistory, localModelStatus]);
  const runtimeLabel = localModelStatus
    ? localModelStatus.connected
      ? availableModels.length > 0
        ? `Runtime online · ${availableModels.length} model(s)`
        : 'Runtime online, but no models are installed'
      : `Runtime UNAVAILABLE: ${localModelStatus.message || 'endpoint did not respond'}`
    : 'Runtime UNAVAILABLE: not checked';

  // ---- UX hooks: theme, voice input, smart scroll, shortcuts, session filter ----
  const { theme, toggleTheme } = useTheme();
  const [historyQuery, setHistoryQuery] = useState('');
  const [historyTagFilter, setHistoryTagFilter] = useState<string>('ALL');
  const [showArchivedHistory, setShowArchivedHistory] = useState(false);
  const [shortcutOverlayOpen, setShortcutOverlayOpen] = useState(false);
  const [plansViewOpen, setPlansViewOpen] = useState(false);
  const [multiverseConsoleOpen, setMultiverseConsoleOpen] = useState(false);
  const [automationsModalOpen, setAutomationsModalOpen] = useState(false);
  const [safeRedirectTargetUrl, setSafeRedirectTargetUrl] = useState<string | null>(null);

  const activeSessionsList = useMemo(() => sessions.filter((s) => !s.archived), [sessions]);
  const archivedSessionsList = useMemo(() => sessions.filter((s) => Boolean(s.archived)), [sessions]);

  const filteredSessions = useMemo(() => {
    const target = showArchivedHistory ? archivedSessionsList : activeSessionsList;
    return filterSessions(target, historyQuery, historyTagFilter === 'ALL' ? undefined : historyTagFilter);
  }, [showArchivedHistory, archivedSessionsList, activeSessionsList, historyQuery, historyTagFilter]);

  const handleArchiveSession = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, archived: !s.archived } : s))
    );
  };

  const handleExportConversationMarkdown = () => {
    if (messages.length === 0) {
      setNotice('ไม่มีข้อความในการสนทนานี้ที่จะส่งออก');
      return;
    }
    const sessionTitle = currentSession.title || 'การสนทนา';
    const exportDate = new Date();
    let md = `# ${sessionTitle}\n\n`;
    md += `*Exported from Zyntheor AI Engine on ${exportDate.toLocaleDateString('th-TH')} ${exportDate.toLocaleTimeString('th-TH')}*\n\n`;
    md += `---\n\n`;

    for (const msg of messages) {
      const roleLabel = msg.role === 'user' ? '👤 User' : '🤖 Zyntheor Assistant';
      const time = msg.timestamp
        ? new Date(msg.timestamp).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
        : '';
      md += `### ${roleLabel}${time ? ` (${time})` : ''}\n\n`;
      if (msg.content) {
        md += `${msg.content}\n\n`;
      }
      if (msg.attachments && msg.attachments.length > 0) {
        md += `**Attachments:**\n`;
        for (const a of msg.attachments) {
          md += `- ${a.name} (${a.type || 'file'}${a.size ? `, ${a.size} bytes` : ''})\n`;
        }
        md += `\n`;
      }
      if (msg.stickerLabel) {
        md += `*Sticker: ${msg.stickerEmoji || ''} ${msg.stickerLabel}*\n\n`;
      }
      md += `---\n\n`;
    }

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    const sanitizedTitle = sessionTitle.replace(/[^\w\u0E00-\u0E7F-]/g, '_').slice(0, 40);
    anchor.download = `zyntheor-conversation-${sanitizedTitle}-${Date.now()}.md`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
    setNotice('ส่งออกการสนทนาเป็นไฟล์ Markdown สำเร็จ');
  };


  const speech = useSpeechToText({
    lang: 'th-TH',
    onFinal: (text) => {
      if (text) setDraft((prev) => (prev && !/\s$/.test(prev) ? `${prev} ${text}` : `${prev}${text}`));
    },
  });

  const smartScroll = useSmartScroll<HTMLDivElement>([messages]);
  useEffect(() => {
    // Always follow the user's own message; assistant replies only follow if already near the bottom.
    if (messages[messages.length - 1]?.role === 'user') smartScroll.scrollToBottom();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages]);

  const shortcuts: ShortcutDef[] = [
    { code: 'KeyN', alt: true, label: 'Alt + N', description: 'เริ่มเซสชันใหม่', run: () => handleCreateNewSession() },
    { code: 'KeyB', alt: true, label: 'Alt + B', description: 'เปิด/ปิดแถบด้านข้าง', run: () => setSidebarOpen((v) => !v) },
    { code: 'KeyA', alt: true, label: 'Alt + A', description: 'เปิดระบบอัตโนมัติ', run: () => setAutomationsModalOpen((v) => !v) },
    { code: 'KeyH', alt: true, label: 'Alt + H', description: 'ประวัติการสนทนา', run: () => setHistoryDrawerOpen((v) => !v) },
    { code: 'KeyF', alt: true, label: 'Alt + F', description: 'ค้นหาข้อความในการสนทนา', run: () => { setIsMessageSearchOpen(true); setTimeout(() => messageSearchInputRef.current?.focus(), 50); } },
    { code: 'KeyT', alt: true, label: 'Alt + T', description: 'สลับธีมสว่าง/มืด', run: toggleTheme },
    { code: 'KeyL', alt: true, label: 'Alt + L', description: 'ล้างการสนทนา (Clear Conversation)', run: handleClearConversation },
    { code: 'KeyM', alt: true, label: 'Alt + M', description: 'พิมพ์ด้วยเสียง', run: () => speech.toggle() },
    { code: 'ArrowRight', alt: true, label: 'Alt + →', description: 'สลับไปโหมดถัดไป', run: () => switchViewBy(1) },
    { code: 'ArrowLeft', alt: true, label: 'Alt + ←', description: 'สลับไปโหมดก่อนหน้า', run: () => switchViewBy(-1) },
    { code: 'Slash', alt: true, label: 'Alt + /', description: 'แสดง/ซ่อนปุ่มลัด', run: () => setShortcutOverlayOpen((v) => !v) },
    { code: 'Slash', shift: true, label: '?', description: 'แสดงปุ่มลัด (นอกช่องพิมพ์)', run: () => setShortcutOverlayOpen((v) => !v) },
    { code: 'Escape', label: 'Esc', description: 'ปิดหน้าต่างที่เปิดอยู่', allowInInput: true, run: () => { setShortcutOverlayOpen(false); setPlansViewOpen(false); setMultiverseConsoleOpen(false); setAutomationsModalOpen(false); setSafeRedirectTargetUrl(null); setHistoryDrawerOpen(false); setModelDropdownOpen(false); setMessageSearchQuery(''); setIsMessageSearchOpen(false); } },
  ];
  useShortcutManager(shortcuts);

  function switchViewBy(delta: number) {
    const i = Math.max(0, CYCLE_MODES.findIndex((m) => m.id === activeMode));
    const next = CYCLE_MODES[(i + delta + CYCLE_MODES.length) % CYCLE_MODES.length];
    chooseMode(next);
  }

  return (
    <div className="app-shell">
      <StatusBanner />
      {/* 1. TOP BAR */}
      <header className="topbar h-16 min-w-0 shrink-0 flex items-center justify-between gap-2 px-3 sm:px-4 lg:px-6 border-b border-cyan-500/20 bg-[#0c0c12]/95 backdrop-blur-md z-30">
        {/* Brand Zone */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          <button
            onClick={() => setSidebarOpen((v) => !v)}
            className="p-1.5 sm:p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition-colors"
            aria-label="เปิด/ปิดแถบเมนูด้านข้าง (Toggle sidebar)"
          >
            <Menu size={20} />
          </button>

          {/* Stylized 'Z' Logo */}
          <div className="relative flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-gradient-to-br from-cyan-950 via-[#0a1224] to-cyan-900 border border-cyan-400/50 shadow-neon-cyan overflow-hidden shrink-0">
            <span className="font-extrabold text-cyan-400 text-sm tracking-wider">Z</span>
            <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-[#0c0c12]" />
          </div>

          <div className="flex flex-col whitespace-nowrap min-w-0">
            <span className="font-extrabold tracking-widest text-sm sm:text-base text-white leading-none">ZYNTHEOR</span>
            <span className="text-[9px] text-cyan-400 tracking-wider font-medium mt-1 truncate">
              AI ENGINE <span data-testid="topbar-mode-label" className="text-slate-300 tracking-normal font-normal">· {active.label}</span> <span className="hidden 2xl:inline text-slate-400 text-[8px] tracking-normal font-normal">Local Core · Intelligence · Zero Fake · Sovereign Core</span>
            </span>
          </div>
        </div>

        {/* Center Status Bar: Server, Model and Inference Latency telemetry */}
        <div className="status-bar hidden md:flex items-center gap-2 text-xs" role="status" aria-label="System status">
          <div
            title="ผลจาก /api/health"
            className="flex shrink-0 items-center gap-1.5 whitespace-nowrap px-2.5 py-1.5 rounded-full bg-[#091734] border border-cyan-500/30"
          >
            <span
              className={`w-2 h-2 rounded-full transition-all duration-500 ease-in-out ${
                serverStatus.tone === 'ok' ? 'bg-emerald-400' : serverStatus.tone === 'bad' ? 'bg-rose-400' : 'bg-slate-500'
              } ${serverStatus.tone === 'idle' ? 'animate-pulse' : ''}`}
            />
            <span className="text-slate-300 text-[11px]">Server</span>
            <span
              className={`font-semibold text-[11px] transition-all duration-500 ease-in-out ${
                serverStatus.tone === 'ok' ? 'text-emerald-400' : serverStatus.tone === 'bad' ? 'text-rose-400' : 'text-slate-400'
              }`}
            >
              {serverStatus.label}
            </span>
          </div>

          <button
            onClick={() => setModelPerfModalOpen(true)}
            title={`ผลจาก /api/local-model/status; ${localModelStatus?.message || 'ยังไม่ได้ตรวจสอบ runtime'} — คลิกเพื่อเปิดดูกราฟ Model Inference Latency & TPS`}
            className="flex shrink-0 items-center gap-1.5 whitespace-nowrap px-2.5 py-1.5 rounded-full bg-[#091734] border border-cyan-500/30 hover:border-cyan-400 hover:bg-[#0b1c3e] transition-all cursor-pointer group shadow-sm"
          >
            <span
              className={`w-2 h-2 rounded-full transition-all duration-500 ease-in-out ${
                modelStatus.tone === 'ok'
                  ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.7)]'
                  : modelStatus.tone === 'bad'
                  ? 'bg-rose-400'
                  : 'bg-slate-500'
              } ${modelStatus.tone === 'idle' ? 'animate-pulse' : ''}`}
            />
            <span className="text-slate-300 text-[11px]">Model</span>
            <span
              className={`font-semibold text-[11px] transition-all duration-500 ease-in-out ${
                modelStatus.tone === 'ok' ? 'text-emerald-400' : modelStatus.tone === 'bad' ? 'text-rose-400' : 'text-slate-400'
              }`}
            >
              {modelStatus.label}
            </span>
            <Gauge size={12} className="text-cyan-400 ml-0.5 group-hover:scale-110 transition-transform" />
          </button>

          {/* Web Search Service Indicator */}
          <div
            title="ผลจาก /api/engine/connectors (Web Research adapter)"
            className="hidden sm:flex shrink-0 items-center gap-1.5 whitespace-nowrap px-2.5 py-1.5 rounded-full bg-[#091734] border border-cyan-500/30 shadow-sm"
          >
            <span
              className={`w-2 h-2 rounded-full transition-all duration-500 ease-in-out ${
                webSearchAvailable === true
                  ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.7)]'
                  : webSearchAvailable === false
                  ? 'bg-rose-400'
                  : 'bg-slate-500'
              }`}
            />
            <span className="text-slate-300 text-[11px]">Web Search</span>
            <span
              className={`font-semibold text-[11px] transition-all duration-500 ease-in-out ${
                webSearchAvailable === true
                  ? 'text-emerald-400'
                  : webSearchAvailable === false
                  ? 'text-rose-400'
                  : 'text-slate-400'
              }`}
            >
              {webSearchAvailable === true ? 'พร้อมใช้งาน' : webSearchAvailable === false ? 'ยังไม่พร้อม' : 'กำลังตรวจ…'}
            </span>
            <Globe2 size={12} className="text-cyan-400 ml-0.5" />
          </div>

          {/* Visual notification with subtle animation in the status bar if inference latency exceeds 2000ms */}
          {isHighLatency ? (
            <button
              onClick={() => setModelPerfModalOpen(true)}
              role="alert"
              aria-live="polite"
              className="status-bar-latency-alert flex shrink-0 items-center gap-1.5 whitespace-nowrap px-2.5 py-1.5 rounded-full bg-amber-950/70 border border-amber-500/60 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.35)] hover:bg-amber-900/70 transition-all cursor-pointer group animate-pulse"
              title={`แจ้งเตือนประสิทธิภาพ: Inference Latency ล่าสุดสูงผิดปกติ (${latestLatency}ms > 2000ms) — Local runtime อาจติดคอขวด CPU หรือหน่วยความจำ คลิกเพื่อเปิดดู Performance History & Probe`}
              aria-label={`Inference latency warning: ${latestLatency}ms exceeds 2000ms threshold`}
            >
              <AlertTriangle size={13} className="text-amber-400 shrink-0 animate-bounce" />
              <span className="text-[11px] font-bold text-amber-300">
                Latency: <span className="font-mono">{latestLatency}ms</span>
              </span>
              <span className="hidden lg:inline text-[10px] text-amber-400/90 font-medium">(&gt;2000ms Slow Runtime)</span>
            </button>
          ) : latestLatency !== null ? (
            <button
              onClick={() => setModelPerfModalOpen(true)}
              className="status-bar-latency hidden lg:flex shrink-0 items-center gap-1.5 whitespace-nowrap px-2.5 py-1.5 rounded-full bg-[#091734] border border-cyan-500/30 text-slate-300 hover:border-cyan-400 hover:text-cyan-200 transition-all cursor-pointer text-[11px]"
              title={`Inference Latency ล่าสุด: ${latestLatency}ms — คลิกเพื่อเปิดดูกราฟ Performance History`}
              aria-label={`Current inference latency: ${latestLatency}ms`}
            >
              <Zap size={11} className="text-cyan-400" />
              <span className="text-slate-400 text-[10px]">Latency:</span>
              <span className="font-mono text-cyan-300 font-semibold">{latestLatency}ms</span>
            </button>
          ) : null}
        </div>

        {/* Right Actions */}
        <div className="flex min-w-0 shrink items-center justify-end gap-1 sm:gap-3">
          {/* Clock */}
          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-300 px-2 py-1">
            <Clock3 size={15} className="text-cyan-400" />
            <span className="font-mono tabular-nums">{currentTime.time}</span>
            <span className="text-slate-400 text-[11px]">{currentTime.date}</span>
          </div>

          {/* Action Icons */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50 transition-colors"
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            title={theme === 'dark' ? 'โหมดสว่าง (Alt+T)' : 'โหมดมืด (Alt+T)'}
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button
            onClick={() => setShortcutOverlayOpen((v) => !v)}
            className="hidden sm:block p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50 transition-colors"
            aria-label="Keyboard shortcuts"
            aria-haspopup="dialog"
            title="ปุ่มลัด (Alt+/ หรือ ?)"
          >
            <Keyboard size={18} />
          </button>
          <button className="hidden sm:block p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50 transition-colors relative" aria-label="Notifications">
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
            <BellIcon size={18} />
          </button>
          <button
            onClick={() => {
              setSettingsTab('runtime');
              setSettingsModalOpen(true);
            }}
            className="p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50 transition-colors"
            aria-label="Settings"
          >
            <Settings2 size={18} />
          </button>

          {/* Account menu: sign-in status lives here (moved from the sidebar footer) */}
          <div ref={userMenuRef} className="relative shrink-0">
            <button
              type="button"
              data-testid="account-menu-button"
              onClick={() => setUserMenuOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={userMenuOpen}
              aria-label="บัญชีและการเข้าสู่ระบบ"
              className="flex shrink-0 items-center gap-2 pl-2 pr-2 sm:pr-3 py-1 rounded-full bg-slate-800/60 border border-slate-700/60 text-xs cursor-pointer hover:border-cyan-500/40 transition-colors"
            >
              <span className="w-6 h-6 rounded-full bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white font-medium text-[11px]">
                <User size={13} />
              </span>
              <span className="hidden sm:inline font-medium text-slate-200 text-xs">Local</span>
              <span
                title={healthState === 'ready' ? 'เซิร์ฟเวอร์ตอบสนอง' : healthState === 'error' ? 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้' : 'ยังไม่ได้ตรวจสอบ'}
                className={`w-1.5 h-1.5 rounded-full ${healthState === 'ready' ? 'bg-emerald-400' : healthState === 'error' ? 'bg-rose-400' : 'bg-slate-500'}`}
              />
              <ChevronDown size={12} className={`text-slate-400 ml-0.5 transition-transform ${userMenuOpen ? 'rotate-180' : ''}`} />
            </button>
            {userMenuOpen && (
              <div
                role="menu"
                data-testid="account-menu"
                aria-label="บัญชีและการเข้าสู่ระบบ"
                className="absolute right-0 top-full mt-2 z-50 w-72 max-w-[calc(100vw-1.5rem)] rounded-xl border border-slate-700 bg-[#0b0b13] p-2 shadow-2xl"
              >
                <div className="flex items-center gap-3 px-2 py-2.5">
                  <span className="w-9 h-9 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center text-slate-400 shrink-0" aria-hidden="true">
                    <User size={16} />
                  </span>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-200 truncate">ยังไม่ได้เข้าสู่ระบบ</div>
                    <div className="text-[10px] text-slate-500">ระบบสมาชิกยังไม่เปิดใช้งาน</div>
                  </div>
                </div>
                <button
                  type="button"
                  role="menuitem"
                  disabled
                  aria-disabled="true"
                  title="ระบบสมาชิกยังไม่เปิดใช้งาน จึงยังเข้าสู่ระบบไม่ได้"
                  data-testid="account-menu-signin"
                  className="w-full flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-800/40 px-3 py-2 text-xs font-semibold text-slate-500 cursor-not-allowed"
                >
                  <User size={14} /> เข้าสู่ระบบ (ยังไม่เปิดใช้งาน)
                </button>
                <div className="my-2 border-t border-slate-800" />
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => { setUserMenuOpen(false); setSettingsTab('runtime'); setSettingsModalOpen(true); }}
                  className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-cyan-300"
                >
                  <Settings size={15} /> การตั้งค่า
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => { setUserMenuOpen(false); setApiHealthDashboardOpen(true); }}
                  className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-cyan-300"
                >
                  <Activity size={15} />
                  <span className="flex-1">สถานะเซิร์ฟเวอร์ (API Health)</span>
                  <span className={`w-1.5 h-1.5 rounded-full ${healthState === 'ready' ? 'bg-emerald-400' : healthState === 'error' ? 'bg-rose-400' : 'bg-slate-500'}`} />
                </button>
              </div>
            )}
          </div>

          {/* Mobile Right Rail Toggle */}
          <button
            onClick={() => setRightRailOpen((v) => !v)}
            className="hidden lg:block p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50 transition-colors"
            aria-label="เปิด/ปิดแผงสถานะและ Diagnostics"
            title="สถานะระบบและ Diagnostics"
          >
            <Activity size={18} />
          </button>
        </div>
      </header>

      {/* 2. MAIN WORKSPACE */}
      <div className="workspace flex-1 flex min-h-0 relative overflow-hidden bg-[#09090e]">
        {/* LEFT SIDEBAR */}
        {(sidebarOpen || rightRailOpen) && (
          <div
            data-testid="panel-backdrop"
            className="lg:hidden fixed inset-0 z-30 bg-black/55"
            onClick={() => { setSidebarOpen(false); setRightRailOpen(false); }}
            aria-hidden="true"
          />
        )}
        {sidebarOpen && (
          <aside className="sidebar w-64 shrink-0 flex flex-col border-r border-cyan-500/15 bg-[#0c0c12]/95 backdrop-blur-md z-20 transition-all duration-200 max-lg:fixed max-lg:inset-y-0 max-lg:left-0 max-lg:z-40 max-lg:shadow-2xl max-lg:max-w-[85vw]">
            {/* Navigation List */}
            <div className="p-3 space-y-1.5 flex-1 overflow-y-auto">
              {[
                { mode: AUTO_MODE, label: 'แชท', sub: 'กลับไปหน้าสนทนา', icon: Bot, selected: activeMode !== 'models' },
                { mode: PROJECTS_MODE, label: 'โปรเจกต์', sub: 'พื้นที่โปรเจกต์และสร้างแอป', icon: Folder, selected: workspacePanelOpen && workspacePanelTab === 'projects' },
                { mode: MODELS_MODE, label: 'Models', sub: 'ผู้ให้บริการ AI และสถานะ', icon: Cpu, selected: activeMode === 'models' },
              ].map(({ mode, label, sub, icon: Icon, selected }) => (
                <button
                  key={mode.id}
                  type="button"
                  data-testid={`sidebar-nav-${mode.id}`}
                  onClick={() => { chooseMode(mode); if (window.innerWidth < 1024) setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all border ${selected ? 'bg-gradient-to-r from-cyan-600/30 to-indigo-600/20 border-cyan-500/50 text-white' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border-transparent'}`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${selected ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 text-white' : 'bg-slate-800/60 text-cyan-400'}`}>
                    <Icon size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold leading-tight text-slate-200 truncate">{label}</div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">{sub}</div>
                  </div>
                </button>
              ))}

              {/* Pinned Messages Section (Local Bookmark Storage) */}
              <div className="mt-2 pt-2 border-t border-cyan-500/15">
                <button
                  type="button"
                  onClick={() => setPinnedSectionOpen((v) => !v)}
                  className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 transition-colors text-[11px] font-bold tracking-wider uppercase"
                >
                  <div className="flex items-center gap-1.5 text-amber-400">
                    <Bookmark size={13} className="fill-amber-400/40 text-amber-400" />
                    <span className="text-slate-200">ข้อความที่ปักหมุด</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                      {pinnedMessages.length}
                    </span>
                    <ChevronDown size={13} className={`transform transition-transform ${pinnedSectionOpen ? 'rotate-180' : ''}`} />
                  </div>
                </button>

                {pinnedSectionOpen && (
                  <div className="mt-1 space-y-2 pl-0.5">
                    {/* Search and Category Filter for Pinned Messages */}
                    {pinnedMessages.length > 0 && (
                      <div className="space-y-1.5 p-1.5 rounded-lg bg-slate-900/90 border border-slate-800">
                        {/* Search input field */}
                        <div className="relative">
                          <Search size={11} className="absolute left-2 top-2 text-slate-500" />
                          <input
                            type="search"
                            value={pinnedSearchQuery}
                            onChange={(e) => setPinnedSearchQuery(e.target.value)}
                            placeholder="ค้นหาข้อความปักหมุด..."
                            aria-label="Filter pinned messages by content or session title"
                            className="w-full pl-6 pr-5 py-1 text-[11px] rounded bg-slate-950 border border-slate-800 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                          />
                          {pinnedSearchQuery && (
                            <button
                              type="button"
                              onClick={() => setPinnedSearchQuery('')}
                              className="absolute right-1.5 top-1.5 text-slate-400 hover:text-white"
                              aria-label="Clear pinned search"
                            >
                              <X size={10} />
                            </button>
                          )}
                        </div>

                        {/* Filter dropdown for tags */}
                        <div className="flex items-center gap-1.5">
                          <label htmlFor="pinned-tag-filter" className="text-[10px] text-slate-400 shrink-0">
                            หมวดหมู่:
                          </label>
                          <select
                            id="pinned-tag-filter"
                            value={pinnedTagFilter}
                            onChange={(e) => setPinnedTagFilter(e.target.value as 'ALL' | PinnedTag)}
                            className="w-full px-1.5 py-0.5 text-[10px] rounded bg-slate-950 border border-slate-800 text-slate-300 focus:outline-none focus:border-amber-400"
                          >
                            <option value="ALL">🏷 ทุกหมวดหมู่ ({pinnedMessages.length})</option>
                            {PINNED_TAGS.map((tag) => {
                              const count = pinnedMessages.filter((p) => (p.tag || 'General') === tag.id).length;
                              return (
                                <option key={tag.id} value={tag.id}>
                                  {tag.label} ({count})
                                </option>
                              );
                            })}
                          </select>
                        </div>
                      </div>
                    )}

                    {filteredPinnedMessages.length === 0 ? (
                      <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 text-[10px] text-slate-500 leading-relaxed text-center">
                        {pinnedMessages.length === 0 ? (
                          <>
                            ยังไม่มีข้อความที่ปักหมุด คลิกที่ไอคอน <Bookmark size={10} className="inline text-amber-400" /> ในคำตอบของผู้ช่วยเพื่อบันทึกไว้เปิดดูอย่างรวดเร็ว
                          </>
                        ) : (
                          <>
                            <div>ไม่พบข้อความที่ตรงกับเงื่อนไข</div>
                            <button
                              type="button"
                              onClick={() => {
                                setPinnedSearchQuery('');
                                setPinnedTagFilter('ALL');
                              }}
                              className="text-amber-400 underline mt-1 text-[10px] inline-block hover:text-amber-300"
                            >
                              ล้างตัวกรองและคำค้นหา
                            </button>
                          </>
                        )}
                      </div>
                    ) : (
                      filteredPinnedMessages.map((pin) => (
                        <div
                          key={pin.id}
                          className="group relative p-2.5 rounded-xl bg-slate-900/70 border border-slate-800/80 hover:border-amber-500/40 hover:bg-slate-850 transition-all text-xs space-y-1.5"
                        >
                          <div
                            onClick={() => handleJumpToPinnedMessage(pin)}
                            className="cursor-pointer space-y-1"
                          >
                            <div className="flex items-center justify-between text-[10px] text-slate-400">
                              <div className="flex items-center gap-1.5 min-w-0">
                                {/* Tag selector dropdown badge */}
                                <select
                                  value={pin.tag || 'General'}
                                  onChange={(e) => {
                                    e.stopPropagation();
                                    updatePinnedTag(pin.id, e.target.value as PinnedTag);
                                  }}
                                  onClick={(e) => e.stopPropagation()}
                                  className="text-[9px] font-semibold px-1 py-0.2 rounded bg-slate-950 border border-slate-700/80 text-amber-300 focus:outline-none cursor-pointer"
                                  title="คลิกเพื่อเปลี่ยนหมวดหมู่แท็ก (Code, Bug, Idea, Arch, General)"
                                >
                                  {PINNED_TAGS.map((t) => (
                                    <option key={t.id} value={t.id}>
                                      {t.label}
                                    </option>
                                  ))}
                                </select>
                                <span className="text-slate-300 font-medium truncate max-w-[85px]" title={pin.sessionTitle}>
                                  {pin.sessionTitle}
                                </span>
                              </div>
                              <span className="font-mono text-[9px] text-slate-500 shrink-0">{pin.pinnedAt}</span>
                            </div>
                            <p className="text-[11px] text-slate-300 line-clamp-2 leading-snug group-hover:text-cyan-200">
                              {pin.snippet}
                            </p>
                          </div>

                          <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-800/60 opacity-80 group-hover:opacity-100">
                            <button
                              type="button"
                              onClick={() => handleJumpToPinnedMessage(pin)}
                              className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
                              title="เปิดและเลื่อนไปยังข้อความนี้ในแชท"
                            >
                              <ExternalLink size={10} />
                              <span>เปิดดู</span>
                            </button>
                            <span className="text-slate-700">·</span>
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard.writeText(pin.content);
                                setNotice('คัดลอกเนื้อหาที่ปักหมุดแล้ว');
                              }}
                              className="text-[10px] text-slate-400 hover:text-white"
                              title="คัดลอกข้อความเต็ม"
                            >
                              <Copy size={10} />
                            </button>
                            <span className="text-slate-700">·</span>
                            <button
                              type="button"
                              onClick={() => {
                                const next = pinnedMessages.filter((p) => p.id !== pin.id);
                                setPinnedMessages(next);
                                localStorage.setItem('zyntheor_pinned_messages', JSON.stringify(next));
                                setNotice('ลบข้อความออกจากรายการปักหมุดแล้ว');
                              }}
                              className="text-[10px] text-rose-400 hover:text-rose-300"
                              title="ยกเลิกการปักหมุด"
                            >
                              <X size={11} />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>

              {/* Saved Sessions Section (Sidebar) */}
              <div className="mt-2 pt-2 border-t border-cyan-500/15" id="sidebar-saved-sessions">
                <div className="flex items-center justify-between px-2.5 py-1.5 rounded-lg text-slate-400 text-[11px] font-bold tracking-wider uppercase">
                  <button
                    type="button"
                    onClick={() => setSavedSessionsSectionOpen((v) => !v)}
                    className="flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 cursor-pointer"
                    aria-expanded={savedSessionsSectionOpen}
                    title="แสดง/ซ่อนรายการเซสชันที่บันทึกไว้"
                  >
                    <MessageSquare size={13} className="text-cyan-400" />
                    <span className="text-slate-200">เซสชันที่บันทึกไว้</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono">
                      {sessions.length}
                    </span>
                    <ChevronDown size={13} className={`transform transition-transform ${savedSessionsSectionOpen ? 'rotate-180' : ''}`} />
                  </button>
                  <button
                    type="button"
                    onClick={handleCreateNewSession}
                    className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-600/30 hover:bg-cyan-600 text-cyan-200 hover:text-white border border-cyan-500/40 transition-colors cursor-pointer"
                    title="เริ่มเซสชันใหม่"
                    aria-label="เริ่มเซสชันใหม่"
                  >
                    + New
                  </button>
                </div>

                {savedSessionsSectionOpen && (
                  <div className="mt-1 space-y-1 pl-0.5 max-h-52 overflow-y-auto pr-1">
                    {sessions.map((s) => {
                      const isRenaming = renamingSessionId === s.id;
                      const isCurrent = s.id === currentSessionId;
                      return (
                        <div
                          key={s.id}
                          onClick={() => !isRenaming && handleSelectSession(s)}
                          className={`group relative p-2 rounded-lg border text-xs transition-all cursor-pointer ${
                            isCurrent
                              ? 'bg-cyan-500/20 border-cyan-500/60 text-white shadow-[0_0_10px_rgba(6,182,212,0.15)]'
                              : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-850'
                          }`}
                        >
                          {isRenaming ? (
                            <form
                              onSubmit={(e) => {
                                e.preventDefault();
                                handleSaveRenameSession(s.id, e);
                              }}
                              onClick={(e) => e.stopPropagation()}
                              className="flex items-center gap-1"
                            >
                              <input
                                type="text"
                                autoFocus
                                value={renameDraft}
                                onChange={(e) => setRenameDraft(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Escape') {
                                    e.preventDefault();
                                    handleCancelRenameSession();
                                  }
                                }}
                                placeholder="ชื่อเซสชันใหม่..."
                                aria-label="เปลี่ยนชื่อเซสชัน"
                                className="w-full px-2 py-0.5 text-[11px] rounded bg-slate-950 border border-cyan-400 text-white focus:outline-none"
                              />
                              <button
                                type="submit"
                                onClick={(e) => handleSaveRenameSession(s.id, e)}
                                className="p-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white transition-colors cursor-pointer"
                                title="บันทึกชื่อเซสชัน"
                                aria-label="บันทึกชื่อเซสชัน"
                              >
                                <Check size={11} />
                              </button>
                              <button
                                type="button"
                                onClick={handleCancelRenameSession}
                                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                                title="ยกเลิกการเปลี่ยนชื่อ"
                                aria-label="ยกเลิกการเปลี่ยนชื่อ"
                              >
                                <X size={11} />
                              </button>
                            </form>
                          ) : (
                            <div className="flex items-center justify-between gap-1">
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-1">
                                  <span
                                    className="font-medium text-[11px] truncate hover:text-cyan-300"
                                    onDoubleClick={(e) => handleStartRenameSession(s.id, s.title, e)}
                                    title="ดับเบิลคลิกเพื่อเปลี่ยนชื่อ"
                                  >
                                    {s.title}
                                  </span>
                                  {isCurrent && (
                                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                                  )}
                                </div>
                                <div className="text-[9px] text-slate-500 mt-0.5 flex items-center gap-1 font-mono">
                                  <span>{s.updatedAt}</span>
                                  <span>·</span>
                                  <span>{s.messages.length} msg{s.messages.length === 1 ? '' : 's'}</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-0.5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                  type="button"
                                  onClick={(e) => handleOpenSessionOverview(s, e)}
                                  className="p-1 text-slate-400 hover:text-cyan-300 rounded cursor-pointer"
                                  title="ดูสถิติและภาพรวมการสนทนา (Conversation Overview)"
                                  aria-label="ดูภาพรวมการสนทนา"
                                >
                                  <BarChart2 size={11} />
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => handleStartRenameSession(s.id, s.title, e)}
                                  className="p-1 text-slate-400 hover:text-cyan-300 rounded cursor-pointer"
                                  title="เปลี่ยนชื่อเซสชัน (Rename)"
                                  aria-label="เปลี่ยนชื่อเซสชัน"
                                >
                                  <Pencil size={11} />
                                </button>
                                {sessions.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={(e) => handleDeleteSession(s.id, e)}
                                    className="p-1 text-slate-400 hover:text-rose-400 rounded cursor-pointer"
                                    title="ลบเซสชัน"
                                    aria-label="ลบเซสชัน"
                                  >
                                    <Trash2 size={11} />
                                  </button>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="h-px bg-slate-800/80 my-3" />

              {/* Utility items */}
              <div className="space-y-1">
                {advancedPanels && (
                <button
                  onClick={() => setMultiverseConsoleOpen(true)}
                  aria-haspopup="dialog"
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-slate-300 hover:text-cyan-200 hover:bg-cyan-950/40 border border-cyan-500/30 hover:border-cyan-400/50 transition-all text-xs cursor-pointer shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                >
                  <div className="w-7 h-7 rounded-md bg-cyan-950/90 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shadow-[0_0_8px_rgba(0,245,255,0.4)]">
                    <Sparkles size={15} className="animate-pulse" />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="font-bold text-[11px] text-cyan-300">MULTIVERSE AI AGENT</div>
                    <div className="text-[9px] text-amber-300 font-mono">Hologram &amp; Sub-tasks</div>
                  </div>
                  <ChevronRight size={13} className="text-cyan-400" />
                </button>
                )}

                <button
                  onClick={() => setPlansViewOpen(true)}
                  aria-haspopup="dialog"
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/30 transition-colors text-xs cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-md bg-slate-800/60 flex items-center justify-center text-slate-400">
                    <ListChecks size={15} />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="font-medium text-[11px] text-slate-300">แผนและงาน</div>
                    <div className="text-[9px] text-slate-500">Plans &amp; Tasks</div>
                  </div>
                  <ChevronRight size={13} className="text-slate-600" />
                </button>

                <button
                  onClick={() => {
                    setSettingsTab('runtime');
                    setSettingsModalOpen(true);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/30 transition-colors text-xs"
                >
                  <div className="w-7 h-7 rounded-md bg-slate-800/60 flex items-center justify-center text-slate-400">
                    <Settings size={15} />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="font-medium text-[11px] text-slate-300">การตั้งค่า</div>
                    <div className="text-[9px] text-slate-500">Runtime, ความปลอดภัย, ระบบอัตโนมัติ</div>
                  </div>
                  <ChevronRight size={13} className="text-slate-600" />
                </button>
              </div>
            </div>

            {/* Sidebar Footer with User Profile */}
            <div className="p-3 border-t border-cyan-500/15 bg-[#08080c] space-y-2.5">
              <div className="flex items-center justify-between text-[9px]">
                <button
                  type="button"
                  onClick={() => setApiHealthDashboardOpen(true)}
                  className={`flex items-center gap-1.5 font-medium hover:underline cursor-pointer text-left ${healthState === 'ready' ? 'text-emerald-400' : healthState === 'error' ? 'text-rose-400' : 'text-slate-400'}`}
                  role="status"
                  aria-live="polite"
                  title="คลิกเพื่อเปิด Zyntheor API Health & Routing Dashboard"
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${healthState === 'ready' ? 'bg-emerald-400' : healthState === 'error' ? 'bg-rose-400' : 'bg-slate-400'}`} />
                  <span>{healthState === 'ready' ? 'เซิร์ฟเวอร์ตอบสนอง (API Health)' : healthState === 'error' ? 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้' : 'กำลังตรวจสอบ'}</span>
                </button>
                {isHighLatency ? (
                  <button
                    type="button"
                    onClick={() => setModelPerfModalOpen(true)}
                    className="text-amber-400 font-mono text-[9px] flex items-center gap-1 cursor-pointer animate-pulse hover:text-amber-300 transition-colors"
                    title={`Inference Latency ล่าสุด: ${latestLatency}ms > 2000ms คลิกเพื่อดู Performance History`}
                  >
                    <AlertTriangle size={10} className="text-amber-400 animate-bounce" />
                    <span>{latestLatency}ms (Slow)</span>
                  </button>
                ) : lastAutoSavedAt ? (
                  <span
                    className="text-slate-500 font-mono text-[9px] flex items-center gap-1"
                    title="บันทึกเซสชันลง localStorage อัตโนมัติทุก 30 วินาที เพื่อป้องกันข้อมูลสูญหาย"
                  >
                    <span className="w-1 h-1 rounded-full bg-emerald-400/80 animate-ping"></span>
                    <span>บันทึก {lastAutoSavedAt}</span>
                  </span>
                ) : null}
              </div>
            </div>
          </aside>
        )}

        {/* MODELS WORKSPACE */}
        {activeMode === 'models' && (
          <div className="flex-1 min-w-0 overflow-y-auto bg-[#09090e]">
            <ModelsView lang="th" localModelStatus={localModelStatus} onRefreshLocalStatus={testLocalEndpointConnection} />
          </div>
        )}

        {/* CENTER CHAT COLUMN (kept mounted so chat state survives mode switches) */}
        <main className={`chat-column flex-1 flex flex-col min-w-0 bg-[#09090e] relative ${activeMode === 'build' || activeMode === 'projects' || activeMode === 'models' ? 'hidden' : ''}`}>
          {/* Chat Header */}
          <div className="chat-header h-14 shrink-0 flex items-center justify-between gap-1 sm:gap-2 px-2 sm:px-4 lg:px-6 border-b border-cyan-500/15 bg-[#101018]/80 backdrop-blur-sm">
            <div className="flex items-center gap-1.5 sm:gap-3 min-w-0">
              <div className="w-8 h-8 shrink-0 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                {(() => { const ActiveIcon = active.icon; return <ActiveIcon size={18} />; })()}
              </div>
              <div className="block min-w-0" data-testid="chat-header-mode">
                <h1 className="text-sm font-bold text-white leading-none truncate max-w-[34vw] sm:max-w-none">{active.label}</h1>
                <p className="hidden sm:block text-[10px] text-slate-400 mt-0.5 max-w-[42vw] truncate" title={summarizeChatSession(messages, currentSession.title)}>หัวข้อ: {summarizeChatSession(messages, currentSession.title)}</p>
              </div>
            </div>

            <div className="flex items-center gap-1 sm:gap-2 shrink-0 [&_button]:whitespace-nowrap">
              <button
                type="button"
                onClick={() => {
                  setOverviewSession(currentSession);
                  setIsOverviewOpen(true);
                }}
                className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg border border-cyan-500/30 bg-cyan-950/40 hover:bg-cyan-900/60 text-cyan-300 hover:text-white text-xs transition-colors cursor-pointer"
                title="ดูสถิติและภาพรวมการสนทนา (Conversation Overview)"
                aria-label="ดูสถิติและภาพรวมการสนทนา"
              >
                <BarChart2 size={14} className="text-cyan-400" />
                <span className="hidden sm:inline">ภาพรวม</span>
              </button>
              <button
                type="button"
                onClick={() => setApiHealthDashboardOpen(true)}
                className="inline-flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg border border-indigo-500/30 bg-indigo-950/40 hover:bg-indigo-900/60 text-indigo-300 hover:text-white text-xs transition-colors cursor-pointer"
                title="เปิด Zyntheor API Health & Routing Enforcement Flow Dashboard"
                aria-label="เปิด API Health Dashboard"
              >
                <Activity size={14} className="text-indigo-400" />
                <span>API Health</span>
              </button>
              <button
                type="button"
                onClick={smartScroll.toggleAutoScroll}
                className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                  smartScroll.autoScrollEnabled
                    ? 'border-cyan-500 bg-cyan-950/70 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                    : 'border-slate-700/80 bg-slate-800/40 text-slate-400 hover:text-white hover:border-slate-600'
                }`}
                title={
                  smartScroll.autoScrollEnabled
                    ? 'Auto-scroll เปิดอยู่ (เลื่อนลงอัตโนมัติเมื่อมีข้อความใหม่ เว้นแต่คุณจะเลื่อนขึ้น)'
                    : 'Auto-scroll ปิดอยู่ (คลิกเพื่อเปิด)'
                }
                aria-pressed={smartScroll.autoScrollEnabled}
                aria-label="สลับ Auto-scroll เลื่อนลงอัตโนมัติ"
              >
                <ArrowDown size={14} className={smartScroll.autoScrollEnabled ? 'text-cyan-400' : 'text-slate-500'} />
                <span className="hidden sm:inline">Auto-scroll:</span>
                <span className={`hidden sm:inline font-mono text-[10px] px-1 rounded ${smartScroll.autoScrollEnabled ? 'bg-cyan-400/20 text-cyan-300 font-bold' : 'bg-slate-700/60 text-slate-400'}`}>
                  {smartScroll.autoScrollEnabled ? 'ON' : 'OFF'}
                </span>
              </button>
              <button
                onClick={() => {
                  setIsMessageSearchOpen((prev) => !prev);
                  if (!isMessageSearchOpen) {
                    setTimeout(() => messageSearchInputRef.current?.focus(), 50);
                  }
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                  isMessageSearchOpen || messageSearchQuery
                    ? 'border-cyan-500 bg-cyan-950/70 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                    : 'border-slate-700/80 bg-slate-800/40 text-slate-300 hover:text-white hover:border-cyan-500/40'
                }`}
                title="ค้นหาข้อความในการสนทนานี้ (Alt + F)"
                aria-label="ค้นหาข้อความในการสนทนานี้"
              >
                <Search size={14} className={isMessageSearchOpen || messageSearchQuery ? 'text-cyan-400' : 'text-slate-400'} />
                <span className="hidden xl:inline">ค้นหาในแชท</span>
                {messageSearchQuery && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[10px]">
                    {filteredMessages.length}
                  </span>
                )}
              </button>
              <button
                type="button"
                data-testid="workspace-panel-toggle"
                onClick={() => setWorkspacePanelOpen((prev) => !prev)}
                aria-expanded={workspacePanelOpen}
                aria-label="Toggle Workspace Panel"
                className={`flex items-center gap-1.5 px-2 xl:px-3 py-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                  workspacePanelOpen
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                    : 'border-slate-700/80 bg-slate-800/40 text-slate-300 hover:text-white hover:border-cyan-500/40'
                }`}
                title="เปิด Workspace Companion (Plan, Build, Projects, Files, Diff, Run/Test, Status)"
              >
                <Folder size={14} className="text-cyan-400" />
                <span>Workspace</span>
              </button>
              <SaveStatusIndicator local={saveStatus.local} server={saveStatus.server} />
              <button
                type="button"
                onClick={handleExportConversationMarkdown}
                className="flex items-center gap-1.5 px-2 xl:px-3 py-1.5 rounded-lg border border-slate-700/80 bg-slate-800/40 text-slate-300 hover:text-white hover:border-cyan-500/40 text-xs transition-colors cursor-pointer"
                aria-label="ส่งออกการสนทนานี้เป็นไฟล์ Markdown"
                title="ส่งออกการสนทนานี้เป็นไฟล์ Markdown (.md)"
              >
                <Download size={14} className="text-cyan-400" />
                <span className="hidden xl:inline">ส่งออก Markdown</span>
              </button>
              <button
                onClick={() => setHistoryDrawerOpen(true)}
                className="flex items-center gap-1.5 px-2 xl:px-3 py-1.5 rounded-lg border border-slate-700/80 bg-slate-800/40 text-slate-300 hover:text-white hover:border-cyan-500/40 text-xs transition-colors"
                aria-label="ประวัติการสนทนา"
                title="ประวัติการสนทนา"
              >
                <FileSearch size={14} className="text-cyan-400" />
                <span className="hidden xl:inline">ประวัติการสนทนา</span>
              </button>

              <button
                onClick={() => {
                  setSettingsTab('runtime');
                  setSettingsModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-2 xl:px-3 py-1.5 rounded-lg border border-slate-700/80 bg-slate-800/40 text-slate-300 hover:text-white hover:border-cyan-500/40 text-xs transition-colors"
                aria-label="ตั้งค่า"
                title="ตั้งค่า"
              >
                <Settings size={14} />
                <span className="hidden xl:inline">ตั้งค่า</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (messages.length === 0) return;
                  setClearConfirmOpen(true);
                }}
                disabled={messages.length === 0}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                  messages.length === 0
                    ? 'border-slate-800 bg-slate-900/30 text-slate-600 cursor-not-allowed opacity-50'
                    : 'border-rose-500/30 bg-rose-950/30 text-rose-300 hover:text-white hover:bg-rose-900/40 hover:border-rose-500/60 shadow-[0_0_10px_rgba(244,63,94,0.15)]'
                }`}
                title="Clear Conversation — ล้างข้อความทั้งหมดในเซสชันนี้และเริ่มต้นใหม่"
                aria-label="Clear Conversation"
              >
                <Trash2 size={14} className={messages.length === 0 ? 'text-slate-600' : 'text-rose-400'} />
                <span className="hidden xl:inline">Clear Conversation</span>
              </button>
              <button
                onClick={() => handleCreateNewSession()}
                className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50"
                title="สร้างแชทใหม่"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>

          {/* Visual Notification Banner if inference latency exceeds 2000ms */}
          {isHighLatency && !highLatencyDismissed && (
            <div
              role="alert"
              aria-live="polite"
              className="high-latency-banner bg-amber-950/80 border-b border-amber-500/50 px-4 lg:px-6 py-2 flex items-center justify-between gap-3 text-xs text-amber-200 animate-in fade-in duration-150 shrink-0"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <AlertTriangle size={16} className="text-amber-400 shrink-0 animate-bounce" />
                <div className="truncate text-[11px] sm:text-xs">
                  <span className="font-bold text-amber-300">Local Runtime Alert:</span>{' '}
                  <span className="text-amber-100 font-medium">
                    Inference latency ({latestLatency}ms) exceeded 2000ms threshold.
                  </span>{' '}
                  <span className="hidden md:inline text-amber-300/80">
                    Local model execution is experiencing slow performance. Check CPU/RAM load or quantized weights.
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setModelPerfModalOpen(true)}
                  className="px-2.5 py-1 rounded-md bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 hover:text-white font-medium text-[11px] transition-colors cursor-pointer"
                >
                  View Performance History
                </button>
                <button
                  type="button"
                  onClick={() => setHighLatencyDismissed(true)}
                  className="p-1 rounded-md text-amber-400 hover:text-amber-100 hover:bg-amber-900/50 transition-colors cursor-pointer"
                  title="Dismiss warning"
                  aria-label="Dismiss high latency banner"
                >
                  <X size={14} />
                </button>
              </div>
            </div>
          )}

          {/* Main Conversation Message Search Input Bar */}
          <div className="search-conversation-container px-4 lg:px-8 py-2.5 border-b border-cyan-500/15 bg-[#060e22]/90 backdrop-blur-sm shrink-0">
            <div className="flex items-center gap-2 max-w-3xl">
              <div className="relative flex-1 flex items-center">
                <Search size={14} className="absolute left-3 text-cyan-400/80 pointer-events-none" />
                <input
                  ref={messageSearchInputRef}
                  type="text"
                  value={messageSearchQuery}
                  onChange={(e) => setMessageSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') {
                      setMessageSearchQuery('');
                      setIsMessageSearchOpen(false);
                    }
                  }}
                  placeholder="ค้นหาข้อความในเซสชันนี้ (คีย์เวิร์ด, โค้ด, หรือชื่อไฟล์)..."
                  className="w-full pl-9 pr-24 py-1.5 text-xs bg-slate-900/90 border border-slate-700/80 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 rounded-xl text-slate-200 placeholder-slate-500 transition-all outline-hidden font-sans"
                  aria-label="ค้นหาข้อความในเซสชันนี้"
                />
                {messageSearchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setMessageSearchQuery('');
                      messageSearchInputRef.current?.focus();
                    }}
                    className="absolute right-2 px-2 py-0.5 rounded text-[11px] text-slate-400 hover:text-white hover:bg-slate-800 flex items-center gap-1 transition-colors cursor-pointer"
                    title="ล้างคำค้นหา (Esc)"
                  >
                    <X size={12} />
                    <span>ล้าง</span>
                  </button>
                )}
              </div>

              {messageSearchQuery.trim() ? (
                <div className="flex items-center gap-1.5 text-[11px] font-mono px-2.5 py-1 rounded-lg bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 whitespace-nowrap shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                  <span>พบ {filteredMessages.length} / {messages.length}</span>
                </div>
              ) : (
                <div className="hidden sm:flex items-center text-[10px] text-slate-500 font-mono shrink-0">
                  <span>Alt + F</span>
                </div>
              )}
            </div>

            {messageSearchQuery.trim() && (
              <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1.5 max-w-3xl px-0.5">
                <div className="flex items-center gap-1.5 truncate">
                  <span>กรองเฉพาะข้อความที่มีคำว่า: <strong className="text-cyan-300 font-medium">"{messageSearchQuery}"</strong></span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setMessageSearchQuery('');
                    messageSearchInputRef.current?.focus();
                  }}
                  className="text-xs text-cyan-400 hover:underline hover:text-cyan-300 shrink-0 ml-2 cursor-pointer"
                >
                  แสดงข้อความทั้งหมด
                </button>
              </div>
            )}
          </div>

          {notice && (
            <div className="mx-4 mt-3 px-3 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
              <AlertTriangle size={15} className="shrink-0" />
              <span className="flex-1">{notice}</span>
              <button onClick={() => setNotice('')} className="p-0.5 hover:text-white">
                <X size={14} />
              </button>
            </div>
          )}

          {/* Drag Overlay */}
          {isDragging && (
            <div className="absolute inset-0 z-50 bg-[#050e24]/90 border-2 border-dashed border-cyan-400 m-4 rounded-3xl flex flex-col items-center justify-center pointer-events-none backdrop-blur-xs">
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mb-3 shadow-[0_0_25px_rgba(6,182,212,0.5)] animate-bounce">
                <UploadCloud size={32} />
              </div>
              <p className="text-white text-base font-bold">วางไฟล์หรือรูปภาพที่นี่</p>
              <p className="text-cyan-300/80 text-xs mt-1">ไฟล์จะถูกแนบเข้ากับการสนทนาใน ZYNTHEOR AI ENGINE ทันที</p>
            </div>
          )}

          {/* Conversation Messages */}
          <div
            ref={smartScroll.ref}
            onScroll={smartScroll.onScroll}
            className="conversation flex-1 overflow-y-auto px-4 lg:px-8 py-6 space-y-6"
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={(e) => {
              if (!e.currentTarget.contains(e.relatedTarget as Node)) {
                setIsDragging(false);
              }
            }}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                void processIncomingFiles(e.dataTransfer.files);
              }
            }}
          >
            {messages.length === 0 && (
              <div className="flex h-full flex-col items-center justify-center px-4 py-8 text-center">
                <Suspense fallback={<ChatCoreFallback />}>
                  <ChatCore3D />
                </Suspense>
                <h2 className="mt-2 text-2xl font-bold text-white sm:text-3xl">What are we building today?</h2>
                <p className="mt-2 max-w-md text-sm text-slate-400">ถามคำถาม วิเคราะห์ไฟล์ หรือเริ่มสร้างโครงการของคุณ</p>
                <div className="mt-6 grid w-full max-w-xl grid-cols-1 gap-3 sm:grid-cols-2">
                  <button
                    type="button"
                    onClick={() => composerRef.current?.focus()}
                    className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-left transition-colors hover:border-cyan-500/50 hover:bg-cyan-500/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
                  >
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-300"><Bot size={20} /></span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold text-white">Ask AI</span>
                      <span className="block text-xs text-slate-400">สนทนาและแก้ปัญหา</span>
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const build = modes.find((m) => m.id === 'build');
                      if (build) chooseMode(build);
                    }}
                    className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-left transition-colors hover:border-cyan-500/50 hover:bg-cyan-500/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
                  >
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-300"><Code2 size={20} /></span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold text-white">Build an app</span>
                      <span className="block text-xs text-slate-400">เริ่มสร้าง Web หรือ Mobile App</span>
                    </span>
                  </button>
                </div>
                <div className="mt-6 w-full max-w-xl">
                  <div className="mb-2 text-left text-[11px] font-semibold uppercase tracking-wider text-slate-500">ตัวอย่างคำถาม (แตะเพื่อใส่ในช่องพิมพ์)</div>
                  <div className="flex flex-wrap gap-2">
                    {['ช่วยเขียนเว็บแอปด้วย React + Node.js', 'อธิบายโค้ดนี้ให้หน่อย', 'ตรวจสอบและแก้บั๊กในโค้ด', 'แนะนำการตั้งค่าโมเดลที่เหมาะสม'].map((example) => (
                      <button
                        key={example}
                        type="button"
                        onClick={() => { setDraft(example); composerRef.current?.focus(); }}
                        className="rounded-full border border-white/10 px-3 py-1.5 text-xs text-slate-300 transition-colors hover:border-cyan-500/50 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
                      >
                        {example}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
            {messages.length > 0 && filteredMessages.length === 0 && messageSearchQuery.trim() && (
              <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
                  <Search size={22} />
                </div>
                <h3 className="text-sm font-semibold text-slate-200">ไม่พบข้อความที่ตรงกับ "{messageSearchQuery}"</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  ลองตรวจสอบตัวสะกด หรือใช้คำค้นหาที่กว้างขึ้นเพื่อค้นหาข้อความในการสนทนานี้
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setMessageSearchQuery('');
                    messageSearchInputRef.current?.focus();
                  }}
                  className="mt-4 px-3 py-1.5 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 text-xs font-medium transition-colors cursor-pointer"
                >
                  ล้างการค้นหา (ดูข้อความทั้งหมด)
                </button>
              </div>
            )}
            {filteredMessages.map((message, mIndex) => {
              const isAssistant = message.role === 'assistant';
              const isEditing = editingMessageId === message.id;
              const isFocused = focusedMessageIndex !== null && filteredMessages[focusedMessageIndex]?.id === message.id;
              const isSelected = selectedMessageIds.includes(message.id);

              return (
                <article
                  id={message.id}
                  key={message.id}
                  tabIndex={0}
                  role="article"
                  data-selected={isSelected}
                  aria-label={`ข้อความจาก ${isAssistant ? 'ZYNTHEOR AI' : 'คุณ'} ส่งเวลา ${formatMessageTimeOfDay(message)}`}
                  onClick={(e) => {
                    if (selectionMode) {
                      e.stopPropagation();
                      toggleSelectMessage(message.id);
                    }
                  }}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setMessageContextMenu({
                      isOpen: true,
                      x: e.clientX,
                      y: e.clientY,
                      message,
                    });
                  }}
                  onFocus={() => setFocusedMessageIndex(mIndex)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !isAssistant && !isEditing && !selectionMode) {
                      e.preventDefault();
                      startEditingMessage(message);
                    }
                  }}
                  className={`flex items-start gap-3.5 max-w-3xl rounded-xl transition-all duration-300 outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:bg-cyan-950/20 ${
                    isAssistant ? 'assistant-enter-animation' : ''
                  } ${
                    highlightedMessageId === message.id ? 'ring-2 ring-amber-400 bg-amber-500/10 p-2' : ''
                  } ${
                    selectionMode && isSelected ? 'ring-2 ring-cyan-400 bg-cyan-950/30 p-2' : ''
                  } ${
                    isFocused ? 'ring-1 ring-cyan-400/50 bg-cyan-950/15 p-1' : ''
                  } ${isAssistant ? '' : 'justify-end ml-auto'}`}
                >
                  {/* Multi-selection Checkbox button */}
                  {selectionMode && (
                    <button
                      type="button"
                      data-testid="message-select-checkbox"
                      data-selection-id={message.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSelectMessage(message.id);
                      }}
                      className={`shrink-0 w-6 h-6 rounded-lg flex items-center justify-center transition-all cursor-pointer self-center ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950 border border-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.6)] font-bold'
                          : 'bg-slate-900/90 text-slate-400 border border-slate-700 hover:border-cyan-400 hover:text-cyan-300'
                      }`}
                      aria-label={isSelected ? `Deselect message ${message.id}` : `Select message ${message.id}`}
                      aria-pressed={isSelected}
                    >
                      {isSelected ? <Check size={14} strokeWidth={3} /> : <Square size={13} className="text-slate-500" />}
                    </button>
                  )}

                  {isAssistant && (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shrink-0 shadow-[0_0_12px_rgba(6,182,212,0.35)] mt-1">
                      <div className="text-xs font-black">Z</div>
                    </div>
                  )}

                  <div className={`space-y-1.5 ${isAssistant ? 'max-w-[85%]' : 'max-w-[78%]'}`}>
                    {/* Header with Sender Name, Exact Time of Day, and Edit Trigger */}
                    <div className={`flex items-center gap-2 text-[11px] text-slate-400 ${isAssistant ? '' : 'justify-end'}`}>
                      <span className="font-semibold text-slate-300">{isAssistant ? 'ZYNTHEOR AI' : 'คุณ'}</span>
                      <span
                        className="font-mono text-[10px] tabular-nums text-slate-400 flex items-center gap-1 bg-slate-800/60 px-1.5 py-0.5 rounded border border-slate-700/60"
                        title={`เวลาที่ส่งข้อความ (Time of Day): ${formatMessageTimeOfDay(message)}`}
                      >
                        <Clock3 size={11} className="text-cyan-400/80" />
                        <span>{formatMessageTimeOfDay(message)}</span>
                      </span>
                      {isAssistant && (
                        <>
                          <span aria-hidden="true" className="text-slate-600">·</span>
                          <span
                            data-testid="assistant-reading-time"
                            className="inline-flex items-center gap-1 rounded border border-cyan-500/30 bg-cyan-500/10 px-1.5 py-0.5 text-[10px] text-cyan-300"
                            title="เวลาอ่านโดยประมาณที่ความเร็วเฉลี่ย 200 คำต่อนาที"
                          >
                            <Clock3 size={11} aria-hidden="true" />
                            <span>{formatReadingTime(message.content)}</span>
                          </span>
                        </>
                      )}
                      {!isAssistant && <CheckCheck size={14} className="text-cyan-400 ml-0.5" />}
                      {!isAssistant && !isEditing && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            startEditingMessage(message);
                          }}
                          className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-slate-800/60 transition-colors ml-0.5 cursor-pointer"
                          title="คลิกเพื่อแก้ไขข้อความนี้และส่งใหม่จากจุดนี้"
                          aria-label="แก้ไขข้อความ"
                        >
                          <Pencil size={11} />
                        </button>
                      )}
                    </div>

                    {isEditing ? (
                      /* Inline Message Editor */
                      <div className="rounded-2xl p-3 bg-[#081534] border border-cyan-400 shadow-xl space-y-2.5 w-full min-w-[280px] sm:min-w-[420px]">
                        <div className="flex items-center justify-between text-xs text-cyan-300 font-medium">
                          <span className="flex items-center gap-1.5">
                            <Pencil size={13} className="text-cyan-400" />
                            <span>แก้ไขข้อความและส่งใหม่จากจุดนี้ (ข้อความหลังจากนี้จะถูกตัดออก)</span>
                          </span>
                          <span className="text-[10px] text-slate-400">Esc เพื่อยกเลิก</span>
                        </div>
                        <textarea
                          value={editDraft}
                          onChange={(e) => setEditDraft(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                              e.preventDefault();
                              void handleSaveAndResendEdit(message.id, editDraft);
                            } else if (e.key === 'Escape') {
                              setEditingMessageId(null);
                            }
                          }}
                          rows={3}
                          className="w-full p-2.5 text-xs sm:text-[13px] bg-slate-900 border border-cyan-500/50 focus:border-cyan-400 rounded-xl text-white outline-none resize-y leading-relaxed font-sans"
                          autoFocus
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingMessageId(null)}
                            className="px-3 py-1.5 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                          >
                            ยกเลิก
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleSaveAndResendEdit(message.id, editDraft)}
                            disabled={!editDraft.trim() || sending}
                            className="px-3.5 py-1.5 text-xs font-semibold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg shadow-sm flex items-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer"
                          >
                            <Send size={12} />
                            <span>บันทึกและส่งใหม่</span>
                          </button>
                        </div>
                      </div>
                    ) : message.isSticker ? (
                      /* Sticker Bubble */
                      <div
                        onClick={(e) => {
                          if (selectionMode) {
                            e.stopPropagation();
                            toggleSelectMessage(message.id);
                            return;
                          }
                          triggerMessageRipple(e, message.id);
                        }}
                        className={`relative overflow-hidden rounded-2xl p-4 shadow-lg flex flex-col items-center justify-center border transition-all cursor-pointer ${
                          clickedMessageId === message.id ? 'message-highlight-pulse' : ''
                        } ${
                          isAssistant
                            ? 'bg-[#091636]/90 border-cyan-500/30'
                            : 'bg-gradient-to-r from-blue-700/80 to-indigo-700/80 border-cyan-400/40'
                        }`}
                      >
                        {rippleEffect && rippleEffect.messageId === message.id && (
                          <span
                            key={rippleEffect.key}
                            className="message-ripple-effect pointer-events-none"
                            style={{
                              left: `${rippleEffect.x - rippleEffect.size / 2}px`,
                              top: `${rippleEffect.y - rippleEffect.size / 2}px`,
                              width: `${rippleEffect.size}px`,
                              height: `${rippleEffect.size}px`,
                            }}
                          />
                        )}
                        <div className="text-5xl my-1 transform hover:scale-125 transition-transform duration-200 cursor-default select-none filter drop-shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                          {message.stickerEmoji || '⚡'}
                        </div>
                        {message.stickerLabel && (
                          <span className="mt-2 text-xs font-bold tracking-wide text-cyan-300 font-mono px-3 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30">
                            {messageSearchQuery.trim() ? highlightMatch(message.stickerLabel, messageSearchQuery) : message.stickerLabel}
                          </span>
                        )}
                      </div>
                    ) : (
                      /* Standard Message Bubble with Image & File Attachments */
                      <div
                        onClick={(e) => {
                          if (selectionMode) {
                            e.stopPropagation();
                            toggleSelectMessage(message.id);
                            return;
                          }
                          triggerMessageRipple(e, message.id);
                          if (!isAssistant) startEditingMessage(message);
                        }}
                        className={`group/userbubble relative overflow-hidden rounded-2xl px-4 py-3.5 text-xs sm:text-[13px] leading-relaxed shadow-lg transition-all ${
                          clickedMessageId === message.id ? 'message-highlight-pulse' : ''
                        } ${
                          isAssistant
                            ? 'bg-[#091636]/90 border border-cyan-500/25 text-slate-200 shadow-[0_4px_20px_rgba(0,0,0,0.3)] hover:border-cyan-400/40 cursor-pointer'
                            : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-[0_4px_15px_rgba(37,99,235,0.3)] hover:brightness-105 cursor-pointer'
                        }`}
                        title={!isAssistant ? 'คลิกเพื่อแก้ไขข้อความนี้และส่งใหม่จากจุดนี้' : undefined}
                      >
                        {/* Subtle Click Ripple Effect */}
                        {rippleEffect && rippleEffect.messageId === message.id && (
                          <span
                            key={rippleEffect.key}
                            className="message-ripple-effect pointer-events-none"
                            style={{
                              left: `${rippleEffect.x - rippleEffect.size / 2}px`,
                              top: `${rippleEffect.y - rippleEffect.size / 2}px`,
                              width: `${rippleEffect.size}px`,
                              height: `${rippleEffect.size}px`,
                            }}
                          />
                        )}
                        {/* Text Content */}
                        <div className="whitespace-pre-wrap">
                          {isAssistant ? (
                            <AssistantMessageContent
                              content={message.content}
                              searchQuery={messageSearchQuery}
                              highlightText={highlightMatch}
                              onOpenSafeRedirect={(url) => setSafeRedirectTargetUrl(url)}
                            />
                          ) : (
                            <>
                              <div>{messageSearchQuery.trim() ? highlightMatch(message.content, messageSearchQuery) : message.content}</div>
                              {extractUrlsFromText(message.content).slice(0, 3).map((url) => (
                                <div key={url} onClick={(e) => e.stopPropagation()} className="mt-2 text-left">
                                  <UrlPreviewCard url={url} onOpenSafeRedirect={(u) => setSafeRedirectTargetUrl(u)} />
                                </div>
                              ))}
                            </>
                          )}
                        </div>

                        {/* Click to Edit Hint on User Bubble Hover */}
                        {!isAssistant && (
                          <div className="flex items-center gap-1 mt-1.5 pt-1 border-t border-white/10 text-[10px] text-blue-200/70 opacity-0 group-hover/userbubble:opacity-100 transition-opacity">
                            <Pencil size={10} />
                            <span>คลิกเพื่อแก้ไขและส่งใหม่จากจุดนี้</span>
                          </div>
                        )}

                        {/* Render Images if Attached */}
                        {((message.images && message.images.length > 0) || (message.attachments && message.attachments.some((a) => a.type === 'image'))) && (
                          <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            {(message.images || []).map((imgUrl, idx) => (
                              <div
                                key={idx}
                                className="relative group rounded-xl overflow-hidden border border-cyan-500/30 bg-black/40 cursor-pointer shadow-md"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPreviewModalImage({ url: imgUrl, name: `รูปภาพแนบ #${idx + 1}` });
                                }}
                              >
                                <img
                                  src={imgUrl}
                                  alt={`ภาพแนบ #${idx + 1}`}
                                  className="w-full h-auto max-h-56 object-cover group-hover:scale-102 transition-transform duration-200"
                                />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-white">
                                  <Maximize2 size={16} className="text-cyan-400" />
                                  <span className="text-[11px] font-medium">ดูภาพขยาย</span>
                                </div>
                              </div>
                            ))}
                            {(message.attachments || []).filter((a) => a.type === 'image').map((att) => (
                              <div
                                key={att.id}
                                className="relative group rounded-xl overflow-hidden border border-cyan-500/30 bg-black/40 cursor-pointer shadow-md"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPreviewModalImage({ url: att.url, name: att.name });
                                }}
                              >
                                <img
                                  src={att.url}
                                  alt={att.name}
                                  className="w-full h-auto max-h-56 object-cover group-hover:scale-102 transition-transform duration-200"
                                />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-white">
                                  <Maximize2 size={16} className="text-cyan-400" />
                                  <span className="text-[11px] font-medium">{att.name}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Render Non-Image File Attachments */}
                        {message.attachments && message.attachments.filter((a) => a.type !== 'image').length > 0 && (
                          <div className="mt-3 flex flex-wrap gap-2">
                            {message.attachments.filter((a) => a.type !== 'image').map((att) => (
                              <div
                                key={att.id}
                                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/90 border border-slate-700/80 text-xs text-slate-200"
                              >
                                <FileText size={16} className="text-cyan-400 shrink-0" />
                                <div className="flex flex-col min-w-0">
                                  <span className="font-medium truncate max-w-[180px]">{messageSearchQuery.trim() ? highlightMatch(att.name, messageSearchQuery) : att.name}</span>
                                  <span className="text-[10px] text-slate-400 font-mono">{formatBytes(att.size || 0)}</span>
                                </div>
                                {att.url && (
                                  <a
                                    href={att.url}
                                    download={att.name}
                                    onClick={(e) => e.stopPropagation()}
                                    className="p-1 rounded text-cyan-400 hover:text-white hover:bg-slate-800 ml-1 transition-colors"
                                    title="ดาวน์โหลดไฟล์"
                                  >
                                    <Download size={14} />
                                  </a>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Assistant Message Actions */}
                    {isAssistant && (
                      <div className="flex items-center gap-2 pt-1 text-slate-400 text-xs">
                        <button
                          onClick={() => handleCopy(message.content, message.id)}
                          className="p-1 hover:text-cyan-400 hover:bg-slate-800/40 rounded transition-colors"
                          title="คัดลอกข้อความ"
                        >
                          {copyFeedback === message.id ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                        </button>
                        <button
                          onClick={() => togglePinMessage(message)}
                          className={`p-1 rounded transition-colors ${
                            isMessagePinned(message.id)
                              ? 'text-amber-400 bg-amber-500/20 hover:bg-amber-500/30'
                              : 'text-slate-400 hover:text-amber-300 hover:bg-slate-800/40'
                          }`}
                          title={isMessagePinned(message.id) ? 'ยกเลิกการปักหมุดข้อความ' : 'ปักหมุดข้อความ (Save to Sidebar)'}
                        >
                          <Bookmark
                            size={14}
                            className={isMessagePinned(message.id) ? 'fill-amber-400 text-amber-400' : ''}
                          />
                        </button>
                        <button
                          onClick={() => handleMessageFeedback(message.id, 'like')}
                          className={`p-1 rounded transition-colors ${message.feedback === 'like' ? 'text-teal-300 bg-teal-500/15' : 'hover:text-teal-300 hover:bg-slate-800/40'}`}
                          title={message.feedback === 'like' ? 'ยกเลิกถูกใจ' : 'ถูกใจ'}
                          aria-pressed={message.feedback === 'like'}
                          aria-label="ถูกใจคำตอบ"
                        >
                          <ThumbsUp size={14} />
                        </button>
                        <button
                          onClick={() => handleMessageFeedback(message.id, 'dislike')}
                          className={`p-1 rounded transition-colors ${message.feedback === 'dislike' ? 'text-amber-300 bg-amber-500/15' : 'hover:text-amber-300 hover:bg-slate-800/40'}`}
                          title={message.feedback === 'dislike' ? 'ยกเลิกไม่ถูกใจ' : 'ไม่ถูกใจ'}
                          aria-pressed={message.feedback === 'dislike'}
                          aria-label="ไม่ถูกใจคำตอบ"
                        >
                          <ThumbsDown size={14} />
                        </button>
                        <button
                          onClick={() => handleRetryAssistantMessage(message.id)}
                          disabled={sending}
                          className="p-1 hover:text-teal-300 hover:bg-slate-800/40 rounded transition-colors disabled:opacity-40"
                          title="นำคำถามเดิมกลับมาเพื่อส่งใหม่"
                          aria-label="ลองคำถามเดิมอีกครั้ง"
                        >
                          <RotateCcw size={14} />
                        </button>
                      </div>
                    )}
                  </div>

                  {!isAssistant && (
                    <div className="w-8 h-8 rounded-full bg-slate-700/80 border border-slate-600 flex items-center justify-center text-white shrink-0 mt-1">
                      <User size={15} />
                    </div>
                  )}
                </article>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* COMPOSER SECTION */}
          <div className="p-4 lg:px-8 lg:pb-6 pt-0 relative">
            {smartScroll.showJump && (
              <button
                type="button"
                onClick={() => smartScroll.scrollToBottom()}
                className="absolute -top-11 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1.5 rounded-full border border-cyan-500/50 bg-[#071026]/95 px-3 py-1.5 text-[11px] text-cyan-300 shadow-lg hover:text-white"
              >
                <ArrowDown size={13} />
                <span>ข้อความล่าสุด</span>
              </button>
            )}

            {/* Floating / Sticky Bulk Action Bar when Multi-Selection Mode is Active */}
            {selectionMode && (
              <div
                data-testid="bulk-action-bar"
                className="mb-3 max-w-4xl mx-auto p-3 rounded-2xl bg-[#07132e]/95 border border-cyan-500/50 shadow-[0_10px_35px_rgba(0,0,0,0.6)] backdrop-blur-md flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200 z-30 font-sans"
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono">
                    <CheckSquare size={15} className="text-cyan-400" />
                    <span>
                      เลือกแล้ว <strong className="text-white font-bold">{selectedMessageIds.length}</strong> / {filteredMessages.length} ข้อความ
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs">
                    <button
                      type="button"
                      data-testid="bulk-select-all-btn"
                      onClick={handleSelectAllMessages}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-cyan-900/40 text-slate-300 hover:text-cyan-200 border border-slate-700/60 hover:border-cyan-500/40 transition-colors text-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <CheckSquare size={13} />
                      <span>เลือกทั้งหมด</span>
                    </button>
                    <button
                      type="button"
                      data-testid="bulk-deselect-all-btn"
                      onClick={handleDeselectAllMessages}
                      disabled={selectedMessageIds.length === 0}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700/60 transition-colors text-xs disabled:opacity-40 cursor-pointer"
                    >
                      ล้างการเลือก
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    data-testid="bulk-copy-btn"
                    onClick={handleBulkCopy}
                    disabled={selectedMessageIds.length === 0}
                    className="px-3 py-1.5 rounded-xl bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-200 border border-cyan-500/40 hover:border-cyan-400 transition-all text-xs font-medium flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-sm"
                    title="คัดลอกข้อความที่เลือกทั้งหมดลงคลิปบอร์ด"
                  >
                    <Copy size={13} />
                    <span>คัดลอก ({selectedMessageIds.length})</span>
                  </button>

                  <button
                    type="button"
                    data-testid="bulk-delete-btn"
                    onClick={handleBulkDelete}
                    disabled={selectedMessageIds.length === 0}
                    className="px-3 py-1.5 rounded-xl bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/40 hover:border-rose-400 transition-all text-xs font-medium flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-sm"
                    title="ลบข้อความที่เลือกทั้งหมด (มีปุ่มกู้คืน 5 วินาที)"
                  >
                    <Trash2 size={13} />
                    <span>ลบที่เลือก ({selectedMessageIds.length})</span>
                  </button>

                  <button
                    type="button"
                    data-testid="bulk-cancel-btn"
                    onClick={handleExitSelectionMode}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/70 border border-transparent hover:border-slate-700 transition-colors cursor-pointer"
                    title="ออกจากโหมดเลือกข้อความ"
                    aria-label="Cancel Selection Mode"
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>
            )}

            {/* Sticker Picker Popover */}
            {stickerPickerOpen && (
              <div className="absolute bottom-full mb-3 left-4 lg:left-8 z-40 w-80 sm:w-96 rounded-2xl bg-[#081432] border border-cyan-500/40 shadow-2xl p-3 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                    <Smile size={16} className="text-cyan-400" />
                    <span>คลังสติกเกอร์ ZYNTHEOR</span>
                  </div>
                  <button
                    onClick={() => setStickerPickerOpen(false)}
                    className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  >
                    <X size={14} />
                  </button>
                </div>

                {/* Category Tabs */}
                <div className="flex gap-1 my-2 p-1 bg-slate-900/80 rounded-xl border border-slate-800 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setActiveStickerCategory('cyber')}
                    className={`flex-1 py-1 rounded-lg font-medium transition-colors ${
                      activeStickerCategory === 'cyber' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    🤖 Cyber Mascot
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveStickerCategory('dev')}
                    className={`flex-1 py-1 rounded-lg font-medium transition-colors ${
                      activeStickerCategory === 'dev' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    💻 Dev & Tech
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveStickerCategory('reactions')}
                    className={`flex-1 py-1 rounded-lg font-medium transition-colors ${
                      activeStickerCategory === 'reactions' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    😄 Reactions
                  </button>
                </div>

                {/* Stickers Grid */}
                <div className="max-h-56 overflow-y-auto p-1">
                  {activeStickerCategory === 'cyber' ? (
                    <div className="grid grid-cols-2 gap-2">
                      {STICKER_COLLECTION.filter((s) => s.category === 'cyber').map((sticker) => (
                        <button
                          key={sticker.label}
                          type="button"
                          onClick={() => handleSendSticker(sticker.emoji, sticker.label)}
                          className="flex items-center gap-2 p-2 rounded-xl bg-slate-800/60 hover:bg-cyan-950/50 border border-slate-700/80 hover:border-cyan-500/60 text-left transition-all group cursor-pointer"
                        >
                          <span className="text-2xl group-hover:scale-125 transition-transform duration-150">
                            {sticker.emoji}
                          </span>
                          <span className="text-[11px] font-semibold text-slate-200 group-hover:text-cyan-300 leading-tight">
                            {sticker.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="grid grid-cols-4 gap-2">
                      {STICKER_COLLECTION.filter((s) => s.category === activeStickerCategory).map((sticker) => (
                        <button
                          key={sticker.label}
                          type="button"
                          onClick={() => handleSendSticker(sticker.emoji, sticker.label)}
                          className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-800/40 hover:bg-slate-800 border border-slate-700/60 hover:border-cyan-500/50 text-center transition-all group cursor-pointer"
                          title={sticker.label}
                        >
                          <span className="text-2xl group-hover:scale-125 transition-transform duration-150">
                            {sticker.emoji}
                          </span>
                          <span className="text-[9px] text-slate-400 group-hover:text-slate-200 truncate max-w-full mt-1">
                            {sticker.label.split(' ')[0]}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-400 text-center">
                  คลิกสติกเกอร์เพื่อส่งเข้าห้องสนทนาทันที
                </div>
              </div>
            )}

            {/* Input Composer Box */}
            <form
              onSubmit={sendMessage}
              className="max-w-4xl mx-auto rounded-2xl bg-[#091534]/95 border border-cyan-500/30 shadow-[0_0_25px_rgba(0,0,0,0.5)] overflow-hidden"
            >
              {/* Hidden File and Image Inputs */}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileInputChange}
                accept=".txt,.md,.json,.jsonl,.csv,.tsv,.yaml,.yml,.xml,.html,.htm,.css,.scss,.js,.jsx,.mjs,.cjs,.ts,.tsx,.py,.rb,.go,.rs,.java,.c,.cpp,.h,.hpp,.cs,.php,.sh,.bash,.zsh,.sql,.toml,.ini,.log"
                multiple
                className="hidden"
              />
              <input
                type="file"
                ref={imageInputRef}
                onChange={handleImageInputChange}
                accept="image/*"
                multiple
                className="hidden"
              />

              {/* Mode chips: one conversation, switching never clears history. Tap the active chip again to go back to Auto. */}
              <div data-testid="chat-mode-chips" role="radiogroup" aria-label="เลือกโหมดการทำงาน" className="flex items-center gap-2 overflow-x-auto px-3 pt-2.5 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                {modes.map((mode) => {
                  const Icon = mode.icon;
                  const selected = activeMode === mode.id || (mode.id === 'build' && workspacePanelOpen && workspacePanelTab === 'build');
                  return (
                    <button
                      key={mode.id}
                      type="button"
                      role="radio"
                      aria-checked={selected}
                      data-testid={`chat-mode-chip-${mode.id}`}
                      title={mode.english}
                      onClick={() => {
                        if (mode.id === 'build') {
                          if (workspacePanelOpen && workspacePanelTab === 'build') setWorkspacePanelOpen(false);
                          else chooseMode(mode);
                        } else if (selected) chooseMode(AUTO_MODE);
                        else chooseMode(mode);
                      }}
                      className={`shrink-0 inline-flex items-center gap-1.5 whitespace-nowrap rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer ${selected ? (mode.id === 'build' ? 'border-amber-400/60 bg-amber-500/15 text-amber-100' : 'border-cyan-400/60 bg-cyan-500/15 text-cyan-100') : 'border-slate-700/70 bg-slate-900/60 text-slate-300 hover:border-cyan-400/40 hover:text-cyan-200'}`}
                    >
                      <Icon size={14} />
                      <span>{mode.label}</span>
                    </button>
                  );
                })}
                {TOOL_MODES.some((m) => m.id === activeMode) && (
                  <button
                    type="button"
                    data-testid="chat-mode-chip-tool"
                    onClick={() => chooseMode(AUTO_MODE)}
                    title="แตะเพื่อปิด"
                    className="shrink-0 inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border border-cyan-400/60 bg-cyan-500/15 px-3 py-1.5 text-xs font-medium text-cyan-100 cursor-pointer"
                  >
                    <span>{active.label}</span>
                    <X size={13} />
                  </button>
                )}
              </div>

              {/* Staged Attachments Tray */}
              {stagedFiles.length > 0 && (
                <div className="p-2.5 px-3 border-b border-slate-800/80 bg-[#07132e]/90 flex flex-wrap gap-2 items-center">
                  <div className="text-[11px] font-semibold text-cyan-400 font-mono flex items-center gap-1.5 mr-1">
                    <Paperclip size={13} />
                    <span>แนบแล้ว ({stagedFiles.length}):</span>
                  </div>
                  {stagedFiles.map((file) => (
                    <div
                      key={file.id}
                      className="group flex items-center gap-2 pl-1.5 pr-2 py-1 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/50 rounded-lg text-xs text-slate-200 transition-all max-w-[240px]"
                    >
                      {file.type === 'image' ? (
                        <img
                          src={file.url}
                          alt={file.name}
                          className="w-7 h-7 rounded object-cover border border-slate-600 shrink-0 cursor-pointer"
                          onClick={() => setPreviewModalImage({ url: file.url, name: file.name })}
                          title="คลิกเพื่อดูภาพขนาดเต็ม"
                        />
                      ) : (
                        <div className="w-7 h-7 rounded bg-slate-700/80 flex items-center justify-center text-cyan-400 shrink-0">
                          <FileText size={14} />
                        </div>
                      )}
                      <div className="flex flex-col min-w-0">
                        <span className="text-[11px] font-medium text-slate-200 truncate" title={file.name}>
                          {file.name}
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono">
                          {formatBytes(file.size || 0)}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveStagedFile(file.id)}
                        className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 transition-colors ml-auto"
                        title="ลบไฟล์นี้"
                      >
                        <X size={13} />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => setStagedFiles([])}
                    className="text-[10px] text-slate-400 hover:text-rose-400 underline ml-auto transition-colors"
                  >
                    ลบทั้งหมด
                  </button>
                </div>
              )}

              <div className="p-3">
                <textarea
                  ref={composerRef}
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onPaste={handlePaste}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      void sendMessage();
                    }
                  }}
                  placeholder="พิมพ์ข้อความของคุณที่นี่... (วางรูปภาพจากคลิปบอร์ด หรือลากไฟล์มาวางได้)"
                  rows={2}
                  className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 outline-none resize-none leading-relaxed"
                />
                {(speech.listening || speech.error) && (
                  <div className={`mt-1 text-[11px] ${speech.error ? 'text-amber-300' : 'text-cyan-300'}`} aria-live="polite">
                    {speech.error ?? (speech.interim ? `🎙 ${speech.interim}` : '🎙 กำลังฟัง... พูดได้เลย')}
                  </div>
                )}
              </div>

              <div className="px-3 pb-2 flex flex-wrap items-center gap-2">
                <label className="sr-only" htmlFor="provider-choice">Inference provider</label>
                <select
                  id="provider-choice"
                  value={providerChoice}
                  onChange={(event) => {
                    setProviderChoice(event.target.value as ProviderChoice);
                    setProviderConsent(false);
                  }}
                  className="max-w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-[11px] text-slate-200"
                >
                  <option value="local">Local Model (Runtime)</option>
                  {onlineProviders.map((provider) => (
                    <option key={provider.id} value={provider.id} disabled={!provider.available}>
                      {provider.name} · {provider.available ? provider.model : 'UNAVAILABLE'}
                    </option>
                  ))}
                </select>
                {providerChoice !== 'local' && (
                  <div className="w-full rounded-lg border border-amber-500/30 bg-amber-950/20 p-2 text-[11px] text-amber-100">
                    <label className="flex items-start gap-2">
                      <input
                        type="checkbox"
                        checked={providerConsent}
                        onChange={(event) => setProviderConsent(event.target.checked)}
                        className="mt-0.5 shrink-0"
                      />
                      <span>
                        ฉันยืนยันให้ส่งข้อความและบริบทที่จำเป็นของคำขอนี้ไปยังผู้ให้บริการภายนอก
                        <strong> {onlineProviders.find((provider) => provider.id === providerChoice)?.name || providerChoice}</strong>
                        {' '}เพื่อประมวลผลคำขอครั้งนี้เท่านั้น ฉันเข้าใจว่าข้อมูลที่ส่งออกจากเครื่องอาจอยู่ภายใต้ข้อกำหนดการเก็บรักษาและการประมวลผลของผู้ให้บริการนั้น
                      </span>
                    </label>
                    <p className="mt-1 pl-6 text-slate-300">
                      อย่าส่งรหัสผ่าน API key หรือข้อมูลส่วนบุคคลที่ไม่จำเป็น · การยืนยันนี้ไม่ใช่การยินยอมแทนวัตถุประสงค์อื่น
                    </p>
                    <a href="/privacy-notice-th.html" target="_blank" rel="noreferrer" className="mt-1 inline-block pl-6 text-cyan-300 underline underline-offset-2">
                      อ่านร่างประกาศความเป็นส่วนตัว (ยังต้องตรวจทานก่อนเผยแพร่)
                    </a>
                  </div>
                )}
              </div>

              {/* Bottom bar of Composer */}
              <div className="px-3 py-2 flex items-center justify-between border-t border-slate-800/80 bg-[#07112B]">
                {/* Left tools */}
                <div className="flex items-center gap-1 text-slate-400">
                  <div className="relative">
                    <button
                      type="button"
                      data-testid="attach-menu-button"
                      onClick={() => setAttachmentMenuOpen((open) => !open)}
                      aria-label="เพิ่มไฟล์แนบ"
                      aria-haspopup="menu"
                      aria-expanded={attachmentMenuOpen}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        attachmentMenuOpen ? 'bg-cyan-500/20 text-cyan-300' : 'hover:text-cyan-400 hover:bg-slate-800/50'
                      }`}
                      title="เพิ่มไฟล์หรือรูปภาพ"
                    >
                      <Plus size={18} />
                    </button>
                    {attachmentMenuOpen && (
                      <div
                        role="menu"
                        aria-label="ตัวเลือกไฟล์แนบ"
                        className="absolute bottom-full left-0 mb-2 z-50 w-56 rounded-xl border border-slate-700 bg-[#0b1429] p-1.5 shadow-2xl"
                      >
                        <button
                          type="button"
                          role="menuitem"
                          onClick={() => {
                            setAttachmentMenuOpen(false);
                            fileInputRef.current?.click();
                          }}
                          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-slate-200 hover:bg-slate-800 hover:text-cyan-300"
                        >
                          <Paperclip size={16} />
                          <span>
                            <span className="block font-medium">แนบไฟล์</span>
                            <span className="block text-[11px] text-slate-400">เอกสาร โค้ด และข้อมูล</span>
                          </span>
                        </button>
                        <button
                          type="button"
                          role="menuitem"
                          onClick={() => {
                            setAttachmentMenuOpen(false);
                            imageInputRef.current?.click();
                          }}
                          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-slate-200 hover:bg-slate-800 hover:text-cyan-300"
                        >
                          <ImageIcon size={16} />
                          <span>
                            <span className="block font-medium">เพิ่มรูปภาพ</span>
                            <span className="block text-[11px] text-slate-400">PNG, JPG, WebP และ GIF</span>
                          </span>
                        </button>
                        <div className="my-1 border-t border-slate-700/70" />
                        <div className="px-3 py-1 text-[10px] uppercase tracking-wider text-slate-500">เครื่องมือเสริม</div>
                        {TOOL_MODES.map((tool) => {
                          const ToolIcon = tool.icon;
                          return (
                            <button
                              key={tool.id}
                              type="button"
                              role="menuitem"
                              data-testid={`tool-menu-${tool.id}`}
                              onClick={() => { setAttachmentMenuOpen(false); chooseMode(tool); }}
                              className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-800 hover:text-cyan-300 ${activeMode === tool.id ? 'text-cyan-300' : 'text-slate-200'}`}
                            >
                              <ToolIcon size={16} />
                              <span className="font-medium">{tool.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setStickerPickerOpen((prev) => !prev)}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      stickerPickerOpen ? 'bg-cyan-500/20 text-cyan-400' : 'hover:text-cyan-400 hover:bg-slate-800/50'
                    }`}
                    title="สติกเกอร์ (Stickers)"
                  >
                    <Smile size={16} />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      speech.clearError();
                      speech.toggle();
                    }}
                    disabled={!speech.supported}
                    aria-pressed={speech.listening}
                    className={`p-1.5 rounded-lg transition-colors ${
                      speech.listening
                        ? 'bg-rose-500/20 text-rose-400 animate-pulse'
                        : 'hover:text-cyan-400 hover:bg-slate-800/50 disabled:opacity-40 disabled:cursor-not-allowed'
                    }`}
                    title={speech.supported ? (speech.listening ? 'หยุดพิมพ์ด้วยเสียง (Alt+M)' : 'พิมพ์ด้วยเสียง (Alt+M)') : 'เบราว์เซอร์นี้ไม่รองรับการพิมพ์ด้วยเสียง'}
                  >
                    {speech.listening ? <MicOff size={16} /> : <Mic size={16} />}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSttSettingsModalOpen(true)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800/50 transition-colors cursor-pointer"
                    title="ตั้งค่า Speech-to-Text (ภาษา, ความไว, ฟังต่อเนื่อง)"
                    aria-label="ตั้งค่า Speech-to-Text"
                  >
                    <Sliders size={15} />
                  </button>
                </div>

                {/* Right controls: Model Selector & Send Button */}
                <div className="flex items-center gap-2 relative">
                  {/* Model Selector Dropdown */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setModelDropdownOpen((v) => !v)}
                      disabled={availableModels.length === 0}
                      title={availableModels.length === 0 ? 'ไม่มีโมเดลที่ runtime รายงาน' : 'เลือกโมเดลที่ติดตั้งจริง'}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/70 border border-slate-700/80 text-[11px] text-slate-300 hover:text-white hover:border-cyan-500/40 transition-colors"
                    >
                      <Cpu size={13} className="text-cyan-400" />
                      <span>{selectedModel || 'UNAVAILABLE'}</span>
                      <ChevronDown size={12} className="text-slate-400 ml-0.5" />
                    </button>

                    {modelDropdownOpen && (
                      <div className="absolute bottom-full right-0 mb-2 w-64 rounded-xl bg-[#09183B] border border-cyan-500/30 shadow-2xl p-1.5 z-50 text-xs">
                        <div className="px-2 py-1 text-[10px] text-slate-400 font-semibold uppercase tracking-wider">โมเดลที่ runtime รายงาน</div>
                        {availableModels.length === 0 && (
                          <div className="px-2 py-2 text-[10px] text-rose-300">UNAVAILABLE: runtime ยังไม่รายงานโมเดลที่ติดตั้ง</div>
                        )}
                        {availableModels.map((m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => {
                              setSelectedModel(m);
                              setModelDropdownOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left text-xs ${
                              selectedModel === m ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-300 hover:bg-slate-800/60'
                            }`}
                          >
                            <span>{m}</span>
                            {selectedModel === m && <Check size={14} className="text-cyan-400" />}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Shortcut Help Button */}
                  <button
                    type="button"
                    onClick={() => setShortcutOverlayOpen(true)}
                    className="w-8 h-8 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800/60 flex items-center justify-center transition-colors text-xs font-mono"
                    title="คีย์ลัด (Keyboard Shortcuts: Alt + /)"
                    aria-label="Keyboard shortcuts"
                  >
                    <HelpCircle size={15} />
                  </button>

                  {/* Send Button */}
                  {sending ? (
                    <button
                      type="button"
                      onClick={() => activeRequestController.current?.abort()}
                      className="w-9 h-8 rounded-lg bg-rose-700 hover:bg-rose-600 text-white flex items-center justify-center"
                      aria-label="Cancel request"
                      title="ยกเลิกคำขอ"
                    >
                      <CircleStop size={16} />
                    </button>
                  ) : (
                    <button
                      type="submit"
                      disabled={(!draft.trim() && stagedFiles.length === 0) || (providerChoice !== 'local' && !providerConsent)}
                      className="w-9 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.4)] disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                      aria-label="Send message"
                    >
                      <Send size={15} />
                    </button>
                  )}
                </div>
              </div>
            </form>
          </div>

          {/* Lightbox Modal for Attached Image View */}
          {previewModalImage && (
            <div
              className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150"
              onClick={() => setPreviewModalImage(null)}
            >
              <div
                className="relative max-w-4xl max-h-[90vh] bg-[#071126] border border-cyan-500/40 rounded-2xl p-4 flex flex-col shadow-2xl overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs text-slate-300">
                  <span className="font-semibold text-white truncate max-w-md">{previewModalImage.name}</span>
                  <div className="flex items-center gap-2">
                    <a
                      href={previewModalImage.url}
                      download={previewModalImage.name}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
                      title="ดาวน์โหลดภาพ"
                    >
                      <Download size={16} />
                    </a>
                    <button
                      onClick={() => setPreviewModalImage(null)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                      title="ปิด"
                    >
                      <X size={18} />
                    </button>
                  </div>
                </div>
                <div className="flex-1 overflow-auto flex items-center justify-center p-2 min-h-[250px]">
                  <img
                    src={previewModalImage.url}
                    alt={previewModalImage.name}
                    className="max-w-full max-h-[75vh] object-contain rounded-lg shadow-lg"
                  />
                </div>
              </div>
            </div>
          )}
        </main>

        {/* WORKSPACE COMPANION PANEL */}
        {workspacePanelOpen && (
          <WorkspacePanel apiToken={apiToken}
            tab={workspacePanelTab}
            onTabChange={setWorkspacePanelTab}
            onClose={() => setWorkspacePanelOpen(false)}
            onSendBuildPromptNow={(prompt) => {
              setDraft(prompt);
              setActiveMode('code');
              try { localStorage.setItem('zyntheor_active_mode', 'code'); } catch { /* session-only mode */ }
              setWorkspacePanelOpen(false);
              setPendingBuildSend(prompt);
            }}
            onSendBuildPrompt={(prompt) => {
              setDraft(prompt);
              setActiveMode('code');
              try { localStorage.setItem('zyntheor_active_mode', 'code'); } catch { /* session-only mode */ }
              setWorkspacePanelOpen(false);
              setNotice('นำคำสั่งไปใส่ช่องแชทโหมดเขียนโค้ดแล้ว ตรวจข้อความและกดส่งเพื่อเริ่มคำขอ');
              window.setTimeout(() => setNotice(''), 5000);
            }}
          />
        )}

        {/* RIGHT RAIL (STATUS & TELEMETRY) */}
        {rightRailOpen && (
          <aside className="right-rail max-lg:hidden w-72 lg:w-80 min-w-0 max-w-full shrink-0 flex flex-col border-l border-cyan-500/15 bg-[#0c0c12]/95 backdrop-blur-md overflow-y-auto p-3.5 space-y-3 z-20 max-lg:fixed max-lg:inset-y-0 max-lg:right-0 max-lg:z-40 max-lg:shadow-2xl max-lg:max-w-[85vw]">
            {/* Header / Collapse */}
            <div className="flex items-center justify-between pb-1">
              <span className="text-[11px] font-bold tracking-wider text-slate-300 uppercase">Dashboard & Monitor</span>
              <button
                onClick={() => setRightRailOpen(false)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800/50"
                aria-label="Collapse right rail"
              >
                <ChevronLeft size={16} />
              </button>
            </div>

            {/* CARD 1: สถานะระบบ */}
            <section className="rounded-xl border border-cyan-500/25 bg-[#091534]/80 p-3 shadow-md space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                  <Activity size={15} className="text-cyan-400" />
                  <span>สถานะระบบ</span>
                </div>
                <span
                  className={`flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium ${
                    healthState === 'ready'
                      ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                      : healthState === 'error'
                      ? 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                      : 'bg-slate-500/15 border-slate-500/30 text-slate-300'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${healthState === 'ready' ? 'bg-emerald-400' : healthState === 'error' ? 'bg-rose-400' : 'bg-slate-400'}`}></span>
                  <span>{healthState === 'ready' ? 'เซิร์ฟเวอร์ตอบสนอง' : healthState === 'error' ? 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้' : 'กำลังตรวจสอบ'}</span>
                </span>
              </div>

              <div className="space-y-1.5 text-xs pt-1">
                <div className="flex items-center justify-between text-slate-300" data-testid="status-row-server">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                    Server
                  </span>
                  <span className={`font-semibold text-[11px] ${serverStatus.tone === 'ok' ? 'text-emerald-400' : serverStatus.tone === 'bad' ? 'text-rose-400' : 'text-slate-400'}`}>{serverStatus.label}</span>
                </div>

                <div className="flex items-center justify-between text-slate-300" data-testid="status-row-model">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                    Model
                  </span>
                  <span className={`font-semibold text-[11px] ${modelStatus.tone === 'ok' ? 'text-emerald-400' : modelStatus.tone === 'bad' ? 'text-rose-400' : 'text-slate-400'}`}>{modelStatus.label}</span>
                </div>

                <div className="flex items-center justify-between text-slate-300" data-testid="status-row-web-search">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                    Web Search
                  </span>
                  <span className={`font-semibold text-[11px] ${webSearchAvailable === true ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {webSearchAvailable === true ? 'พร้อมใช้งาน' : webSearchAvailable === false ? 'ยังไม่เชื่อมต่อ' : 'กำลังตรวจ…'}
                  </span>
                </div>

                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <Zap size={11} className="text-cyan-400" />
                    Runtime
                  </span>
                  <span className="text-cyan-300 font-medium text-[11px]">{runtimeLabel}</span>
                </div>

                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <Cpu size={11} className="text-indigo-400" />
                    โมเดลที่เลือก
                  </span>
                  <span className="text-slate-200 text-[11px] font-mono">{selectedModel}</span>
                </div>
              </div>
            </section>

            {/* CARD 1.2: CORE CONNECTION DIAGNOSTICS (real evidence per hop) */}
            <CoreDiagnosticsPanel selectedModel={selectedModel || undefined} />

            {/* CARD 1.5: MODEL INFERENCE & TPS PERFORMANCE (Recharts) */}
            <ModelPerformanceChart
              history={modelPerfHistory}
              modelStatus={modelStatus}
              selectedModel={selectedModel || 'local-weights'}
              provider={providerChoice}
              onRefreshProbe={testLocalEndpointConnection}
              onExpand={() => setModelPerfModalOpen(true)}
            />

            {/* CARD 2: ทรัพยากรระบบ — rolling 5-minute Recharts history */}
            <ResourceTrendChart
              currentCpu={metrics?.cpu ?? null}
              cpuDisplay={metrics?.cpuDisplay ?? null}
              currentRam={metrics?.ramPercentage ?? null}
              ramDisplay={metrics?.ramDisplay ?? null}
              latencyMs={metrics?.latencyMs ?? null}
              resourceSource={metrics?.source ?? null}
            />

            {/* CARD 2.5: RUNTIME METRICS PANEL (Live Thread Counts, GC Frequency, Event Loop Latency via real-time polling) */}
            {advancedPanels && (
            <section
              aria-label="Runtime Metrics Panel"
              data-testid="runtime-metrics-panel"
              className="rounded-xl border border-emerald-500/30 bg-[#091534]/90 p-3 shadow-md space-y-2.5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                  <Cpu size={14} className="text-emerald-400" />
                  <span>Runtime Metrics</span>
                </div>
                <div className="flex items-center gap-1 text-[10px] font-mono font-medium text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Live (2s)</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center pt-0.5">
                {/* 1. Live Thread Counts */}
                <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800 space-y-0.5" title="Live Thread Counts">
                  <div className="text-[10px] text-slate-400 truncate">Threads</div>
                  <div className="font-mono text-sm font-bold text-emerald-300">
                    {runtimeMetrics ? runtimeMetrics.threadCount : '–'}
                  </div>
                  <div className="text-[9px] text-slate-500 font-mono">
                    {runtimeMetrics ? `${runtimeMetrics.activeHandles} handles` : '–'}
                  </div>
                </div>

                {/* 2. Garbage Collection Frequency */}
                <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800 space-y-0.5" title="Garbage Collection Frequency & Total Runs">
                  <div className="text-[10px] text-slate-400 truncate">GC Freq</div>
                  <div className="font-mono text-sm font-bold text-cyan-300">
                    {runtimeMetrics ? `${runtimeMetrics.gcFrequencyPerMinute}/m` : '–'}
                  </div>
                  <div className="text-[9px] text-slate-500 font-mono">
                    {runtimeMetrics ? `${runtimeMetrics.totalGcRuns} runs` : '–'}
                  </div>
                </div>

                {/* 3. Event Loop Latency */}
                <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800 space-y-0.5" title="Event Loop Latency (Lag)">
                  <div className="text-[10px] text-slate-400 truncate">Loop Lag</div>
                  <div className="font-mono text-sm font-bold text-amber-300">
                    {runtimeMetrics ? `${runtimeMetrics.eventLoopLatencyMs}ms` : '–'}
                  </div>
                  <div className="text-[9px] text-slate-500 font-mono">
                    {runtimeMetrics ? `${runtimeMetrics.heapUsedMb}MB heap` : '–'}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/60 font-mono">
                <span>RSS: {runtimeMetrics ? `${runtimeMetrics.rssMb} MB` : '–'}</span>
                <span>Uptime: {runtimeMetrics ? `${runtimeMetrics.uptimeSec}s` : '–'}</span>
              </div>
            </section>
            )}

            {/* CARD 3: EXECUTION PIPELINE */}
            <section className="rounded-xl border border-cyan-500/25 bg-[#091534]/80 p-3 shadow-md space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs font-bold text-white">
                  <Activity size={14} className="text-cyan-400" />
                  <span>Execution Pipeline</span>
                </div>
                <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800/70 border border-slate-700 text-[10px] text-slate-300">
                  <span>โหมด: {pipelineMode}</span>
                  <ChevronDown size={11} className="text-slate-400" />
                </div>
              </div>

              <div className="space-y-1.5 pt-1 text-xs">
                {[
                  { step: '1. รับคำขอ', status: sending ? 'RUNNING' : 'NOT RUN', isDone: false, isActive: sending },
                  { step: '2. เลือก Runtime', status: '-', isDone: false, isActive: sending },
                  { step: '3. เรียก Inference', status: '-', isDone: false },
                  { step: '4. เรียกเครื่องมือ', status: '-', isDone: false },
                  { step: '5. ประมวลผลลัพธ์', status: '-', isDone: false },
                  { step: '6. ส่งกลับไปยังผู้ใช้', status: '-', isDone: false },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] ${
                          item.isDone
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                            : item.isActive
                            ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500 animate-pulse'
                            : 'bg-slate-800 text-slate-500 border border-slate-700'
                        }`}
                      >
                        {item.isDone ? <Check size={10} /> : idx + 1}
                      </div>
                      <span className={item.isDone ? 'text-slate-200' : 'text-slate-500'}>{item.step}</span>
                    </div>
                    <span className={`text-[10px] font-mono ${item.isDone ? 'text-emerald-400 font-medium' : 'text-slate-600'}`}>
                      {item.isDone ? '✓' : item.status}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            {/* CARD 4: LIVE ENGINE TELEMETRY */}
            <section className="rounded-xl border border-cyan-500/25 bg-[#091534]/80 p-3 shadow-md space-y-2 flex-1 min-h-[190px] flex flex-col">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                  <Terminal size={14} className="text-cyan-400" />
                  <span>Live Engine Telemetry</span>
                </div>
                <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800/70 border border-slate-700 text-[10px] text-slate-300">
                  <span>{telemetryFilter}</span>
                  <ChevronDown size={11} className="text-slate-400" />
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-1.5 font-mono text-[10px] pt-1">
                {telemetry.length === 0 && <div className="text-slate-500 py-2">ยังไม่มีเหตุการณ์ที่บันทึกไว้</div>}
                {telemetry.slice(0, 8).map((evt, idx) => (
                  <div key={idx} className="flex items-start gap-1.5 leading-tight py-0.5 border-b border-slate-800/40">
                    <span className="text-slate-500 shrink-0 tabular-nums">{evt.time}</span>
                    <span
                      className={`px-1 rounded text-[8px] font-bold shrink-0 ${
                        evt.level === 'WARN'
                          ? 'bg-amber-500/20 text-amber-400'
                          : evt.level === 'ERROR'
                          ? 'bg-rose-500/20 text-rose-400'
                          : 'bg-cyan-500/20 text-cyan-400'
                      }`}
                    >
                      {evt.level}
                    </span>
                    <span className="text-slate-300 truncate" title={evt.message}>
                      {evt.message}
                    </span>
                  </div>
                ))}
              </div>
            </section>
          </aside>
        )}
      </div>

      {/* 3. SESSION HISTORY DRAWER */}
      {historyDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm">
          <div className="w-80 sm:w-96 bg-[#101018] border-l border-cyan-500/30 h-full flex flex-col shadow-2xl p-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <MessageSquare size={16} className="text-cyan-400" />
                <span>ประวัติการสนทนา</span>
              </div>
              <button onClick={() => setHistoryDrawerOpen(false)} className="p-1 hover:text-white text-slate-400 rounded">
                <X size={18} />
              </button>
            </div>

            <div className="py-3">
              <button
                onClick={handleCreateNewSession}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md transition-all"
              >
                <Plus size={16} />
                <span>เริ่มการสนทนาใหม่</span>
              </button>
            </div>

            <div className="pb-3 space-y-2">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  type="search"
                  value={historyQuery}
                  onChange={(e) => setHistoryQuery(e.target.value)}
                  placeholder="ค้นหาจากชื่อหรือเนื้อหา..."
                  aria-label="ค้นหาประวัติการสนทนา"
                  className="w-full rounded-lg border border-slate-700/80 bg-slate-900/60 py-2 pl-8 pr-3 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-cyan-500/60"
                />
              </div>

              {/* Active / Archive Toggle Tabs */}
              <div className="flex items-center gap-1 bg-slate-900/90 p-0.5 rounded-lg border border-slate-800 text-[10px]">
                <button
                  type="button"
                  onClick={() => setShowArchivedHistory(false)}
                  className={`flex-1 py-1 rounded font-medium transition-colors text-center cursor-pointer ${
                    !showArchivedHistory
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40 shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  ใช้งานอยู่ ({activeSessionsList.length})
                </button>
                <button
                  type="button"
                  onClick={() => setShowArchivedHistory(true)}
                  className={`flex-1 py-1 rounded font-medium transition-colors flex items-center justify-center gap-1 text-center cursor-pointer ${
                    showArchivedHistory
                      ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40 shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="ดูเซสชันที่เก็บถาวร (Archived)"
                >
                  <Archive size={12} />
                  <span>เก็บถาวร ({archivedSessionsList.length})</span>
                </button>
              </div>

              {/* Automated Tag Filter Chips */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[10px]" role="toolbar" aria-label="กรองเซสชันตามแท็กอัตโนมัติ">
                <button
                  type="button"
                  onClick={() => setHistoryTagFilter('ALL')}
                  className={`px-2 py-0.5 rounded-full border transition-all cursor-pointer ${
                    historyTagFilter === 'ALL'
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                      : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                  aria-pressed={historyTagFilter === 'ALL'}
                  aria-label="แสดงทุกแท็ก"
                >
                  ทั้งหมด
                </button>
                {['React', 'TypeScript', 'Bug'].map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => setHistoryTagFilter(historyTagFilter === tag ? 'ALL' : tag)}
                    className={`px-2 py-0.5 rounded-full border transition-all font-mono cursor-pointer ${
                      historyTagFilter === tag
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                        : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                    aria-pressed={historyTagFilter === tag}
                    aria-label={`กรองเฉพาะแท็ก ${tag}`}
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredSessions.length === 0 && (
                <div className="py-6 text-center text-xs text-slate-500">
                  {showArchivedHistory ? 'ไม่มีเซสชันที่เก็บถาวร' : `ไม่พบเซสชันที่ตรงกับ “${historyQuery || historyTagFilter}”`}
                </div>
              )}
              {filteredSessions.map(({ session: s, snippet }) => {
                const isRenaming = renamingSessionId === s.id;
                return (
                  <div
                    key={s.id}
                    onClick={() => !isRenaming && handleSelectSession(s)}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between group ${
                      s.id === currentSessionId
                        ? 'bg-cyan-500/15 border-cyan-500/50 text-white'
                        : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="min-w-0 flex-1 pr-2">
                      {isRenaming ? (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            handleSaveRenameSession(s.id, e);
                          }}
                          onClick={(e) => e.stopPropagation()}
                          className="flex items-center gap-1.5 py-0.5"
                        >
                          <input
                            type="text"
                            autoFocus
                            value={renameDraft}
                            onChange={(e) => setRenameDraft(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Escape') {
                                e.preventDefault();
                                handleCancelRenameSession();
                              }
                            }}
                            placeholder="ชื่อเซสชันใหม่..."
                            aria-label="เปลี่ยนชื่อเซสชัน"
                            className="w-full px-2 py-1 rounded bg-slate-950 border border-cyan-400 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-400"
                          />
                          <button
                            type="submit"
                            onClick={(e) => handleSaveRenameSession(s.id, e)}
                            className="p-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white transition-colors cursor-pointer"
                            title="บันทึกชื่อเซสชัน"
                            aria-label="บันทึกชื่อเซสชัน"
                          >
                            <Check size={12} />
                          </button>
                          <button
                            type="button"
                            onClick={handleCancelRenameSession}
                            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                            title="ยกเลิกการเปลี่ยนชื่อ"
                            aria-label="ยกเลิกการเปลี่ยนชื่อ"
                          >
                            <X size={12} />
                          </button>
                        </form>
                      ) : (
                        <>
                          <div className="flex items-center gap-1.5">
                            <span
                              className="font-semibold truncate cursor-pointer hover:text-cyan-300"
                              onDoubleClick={(e) => handleStartRenameSession(s.id, s.title, e)}
                              title="ดับเบิลคลิกเพื่อเปลี่ยนชื่อ"
                            >
                              {s.title}
                            </span>
                            {s.customTitle && (
                              <span className="px-1 py-0.2 rounded bg-cyan-950/70 text-cyan-400 border border-cyan-500/30 text-[8px] font-mono shrink-0">
                                CUSTOM
                              </span>
                            )}
                            {s.archived && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-950/80 text-amber-300 border border-amber-500/40 font-mono text-[9px] font-semibold shrink-0">
                                ARCHIVED
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
                            <Clock3 size={11} />
                            <span>{s.updatedAt}</span>
                            <span>·</span>
                            <span>{s.messages.length} ข้อความ</span>
                          </div>
                          {s.tags && s.tags.length > 0 && (
                            <div className="mt-1.5 flex flex-wrap gap-1">
                              {s.tags.map((t) => {
                                const meta = AUTO_TAG_RULES.find((r) => r.tag === t);
                                return (
                                  <span
                                    key={t}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setHistoryTagFilter(t);
                                    }}
                                    className={`px-1.5 py-0.2 rounded text-[9px] font-mono border font-semibold cursor-pointer ${
                                      meta ? `${meta.bg} ${meta.color} ${meta.border}` : 'bg-slate-800 text-slate-300 border-slate-700'
                                    }`}
                                    title={`คลิกเพื่อกรองตามแท็ก #${t}`}
                                  >
                                    #{t}
                                  </span>
                                );
                              })}
                            </div>
                          )}
                          {snippet && <div className="mt-1 text-[10px] text-cyan-300/80 truncate">{snippet}</div>}
                        </>
                      )}
                    </div>
                    {!isRenaming && (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => handleOpenSessionOverview(s, e)}
                          className="p-1 text-slate-400 hover:text-cyan-300 rounded cursor-pointer"
                          title="ดูสถิติและภาพรวมการสนทนา (Conversation Overview)"
                          aria-label="ดูภาพรวมการสนทนา"
                        >
                          <BarChart2 size={13} />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleStartRenameSession(s.id, s.title, e)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-cyan-300 rounded transition-opacity cursor-pointer"
                          title="เปลี่ยนชื่อเซสชัน"
                          aria-label="เปลี่ยนชื่อเซสชัน"
                        >
                          <Pencil size={13} />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleArchiveSession(s.id, e)}
                          className={`p-1 rounded transition-colors cursor-pointer ${
                            s.archived
                              ? 'text-amber-400 hover:text-amber-300'
                              : 'opacity-0 group-hover:opacity-100 text-slate-500 hover:text-amber-300'
                          }`}
                          title={s.archived ? 'นำออกจากคลังเก็บถาวร (Unarchive)' : 'เก็บถาวรเซสชันนี้ (Archive)'}
                          aria-label={s.archived ? 'Unarchive session' : 'Archive session'}
                        >
                          {s.archived ? <ArchiveRestore size={13} /> : <Archive size={13} />}
                        </button>
                        {sessions.length > 1 && (
                          <button
                            type="button"
                            onClick={(e) => handleDeleteSession(s.id, e)}
                            className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 rounded transition-opacity cursor-pointer"
                            title="ลบห้องสนทนา"
                            aria-label="ลบเซสชัน"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

          </div>
        </div>
      )}

      {plansViewOpen && (
        <div role="dialog" aria-modal="true" aria-label="Plans & Tasks" className="fixed inset-0 z-[60] flex flex-col bg-[#09090e]">
          <div className="flex h-12 shrink-0 items-center justify-between border-b border-cyan-500/20 px-4">
            <span className="flex items-center gap-2 text-sm font-bold text-white">
              <ListChecks size={16} className="text-cyan-400" /> แผนและงาน (Plans &amp; Tasks)
            </span>
            <button onClick={() => setPlansViewOpen(false)} aria-label="ปิดแผนและงาน" className="rounded p-1 text-slate-400 hover:text-white">
              <X size={18} />
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-4">
            <PlansStudioView
              lang="th"
              onExecuteInChat={(goal) => {
                setDraft(goal);
                setPlansViewOpen(false);
              }}
            />
          </div>
        </div>
      )}

      {/* Multiverse AI Agent Console Modal */}
      {multiverseConsoleOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Multiverse AI Agent Console"
          className="fixed inset-0 z-[60] flex flex-col bg-[#030712] text-zinc-100"
        >
          <div className="flex h-12 shrink-0 items-center justify-between border-b border-cyan-500/20 px-4 bg-zinc-950/90 backdrop-blur-md">
            <span className="flex items-center gap-2 text-sm font-bold text-cyan-300">
              <Sparkles size={16} className="text-cyan-400 animate-spin" />
              <span>MULTIVERSE AI AGENT CONSOLE (SOVEREIGN MATRIX)</span>
            </span>
            <button
              onClick={() => setMultiverseConsoleOpen(false)}
              aria-label="ปิด Multiverse Console"
              className="rounded p-1 text-slate-400 hover:text-white cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
            <Suspense fallback={<div className="p-6 text-sm text-slate-400" role="status">กำลังโหลด Multiverse Console…</div>}>
              <MultiverseAgentConsole lang="th" />
            </Suspense>
          </div>
        </div>
      )}

      {/* Automations Modal (ระบบอัตโนมัติ & Trigger Links) */}
      <AutomationsModal
        isOpen={automationsModalOpen}
        onClose={() => setAutomationsModalOpen(false)}
        onTriggerAutomation={(auto) => {
          setNotice(`ระบบอัตโนมัติ "${auto.name}" กำลังทำงาน...`);
          setTimeout(() => setNotice(''), 3500);
        }}
      />

      {/* Safe Redirect Interstitial Confirmation Modal */}
      <SafeRedirectModal
        url={safeRedirectTargetUrl}
        onClose={() => setSafeRedirectTargetUrl(null)}
      />

      {shortcutOverlayOpen && <ShortcutHelpModal shortcuts={shortcuts} onClose={() => setShortcutOverlayOpen(false)} />}

      {/* 4. SETTINGS & RUNTIME VERIFICATION MODAL */}
      {settingsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-[#071026] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="px-5 py-4 border-b border-cyan-500/20 flex items-center justify-between bg-[#091534]">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  <Settings2 size={16} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">ตั้งค่าระบบ & Runtime Verification</h3>
                  <p className="text-[10px] text-slate-400">ZYNTHEOR Sovereign Engine Configuration</p>
                </div>
              </div>
              <button onClick={() => setSettingsModalOpen(false)} className="p-1 text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-slate-800 px-5 pt-2 bg-[#0c0c12] gap-4 text-xs font-medium overflow-x-auto whitespace-nowrap [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <button
                onClick={() => setSettingsTab('runtime')}
                className={`pb-2.5 border-b-2 transition-colors ${
                  settingsTab === 'runtime' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Runtime & Model
              </button>
              <button
                onClick={() => setSettingsTab('stt')}
                className={`pb-2.5 border-b-2 transition-colors ${
                  settingsTab === 'stt' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Speech-to-Text (STT)
              </button>
              <button
                onClick={() => setSettingsTab('security')}
                className={`pb-2.5 border-b-2 transition-colors ${
                  settingsTab === 'security' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                ความปลอดภัย (Security)
              </button>
              <button
                onClick={() => setSettingsTab('audit')}
                className={`pb-2.5 border-b-2 transition-colors ${
                  settingsTab === 'audit' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Audit & Evidence
              </button>
              <button
                onClick={() => setSettingsTab('sync')}
                className={`pb-2.5 border-b-2 transition-colors ${settingsTab === 'sync' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
              >
                Cloud Sync
              </button>
              <button
                onClick={() => { setSettingsModalOpen(false); setAutomationsModalOpen(true); }}
                className="pb-2.5 border-b-2 border-transparent text-slate-400 hover:text-slate-200 transition-colors"
              >
                ระบบอัตโนมัติ
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              {settingsTab === 'stt' && (
                <div className="space-y-4">
                  <SpeechToTextSettingsPanel />
                </div>
              )}
              {settingsTab === 'runtime' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">Local Inference Endpoint (Ollama / llama.cpp)</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={localEndpoint}
                        onChange={(e) => setLocalEndpoint(e.target.value)}
                        placeholder="ใช้ LOCAL_AI_ENDPOINT หรือ URL ที่ server container เข้าถึงได้"
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-cyan-500 font-mono"
                      />
                      <button
                        type="button"
                        onClick={testLocalEndpointConnection}
                        disabled={testingEndpoint}
                        className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-lg font-medium text-xs flex items-center gap-1.5 transition-colors"
                      >
                        {testingEndpoint ? <RefreshCw size={14} className="animate-spin" /> : <Zap size={14} />}
                        <span>ทดสอบ</span>
                      </button>
                    </div>
                    <p className="mt-1 text-[10px] text-slate-500">
                      ใน Codespaces ค่า 127.0.0.1 หมายถึง container ของแอป ไม่ใช่เครื่องส่วนตัว
                    </p>
                    {localModelStatus && (
                      <div className={`mt-2 p-2.5 rounded-lg text-[11px] leading-relaxed ${localModelStatus.connected ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'}`}>
                        {localModelStatus.message}
                        {localModelStatus.models?.length > 0 && (
                          <div className="mt-1 font-mono text-[10px] text-slate-300">โมเดลที่พบ: {localModelStatus.models.join(', ')}</div>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                    <div className="font-semibold text-slate-200">สถาปัตยกรรมโมเดลที่ใช้งาน</div>
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div>
                        <span className="text-slate-500">โมเดลปัจจุบัน:</span>
                        <div className="font-mono text-cyan-300 mt-0.5">{selectedModel || 'UNAVAILABLE'}</div>
                      </div>
                      <div>
                        <span className="text-slate-500">Inference Type:</span>
                        <div className="font-mono text-slate-300 mt-0.5">{runtimeLabel}</div>
                      </div>
                    </div>
                  </div>

                  <section className="rounded-xl border border-cyan-500/25 bg-slate-950/70 p-3 space-y-3" aria-labelledby="model-comparison-title">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 id="model-comparison-title" className="font-semibold text-slate-100">เปรียบเทียบโมเดล (Model Performance)</h3>
                        <p className="mt-1 text-[10px] text-slate-400">Latency และ tokens/s ใช้ inference history จริง; memory ใช้ค่าที่ local runtime รายงาน</p>
                      </div>
                      <button type="button" onClick={() => void testLocalEndpointConnection()} disabled={testingEndpoint} className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-cyan-700/60 bg-cyan-950/40 px-2.5 py-1.5 text-[10px] font-medium text-cyan-200 hover:bg-cyan-900/50 disabled:opacity-50" aria-label="Refresh runtime model metrics">
                        <RefreshCw size={12} className={testingEndpoint ? 'animate-spin' : ''} /> รีเฟรช
                      </button>
                    </div>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <label className="space-y-1 text-[10px] text-slate-400">โมเดล A
                        <select value={compareModelA} onChange={(event) => { const value = event.target.value; setCompareModelA(value); if (value === compareModelB) setCompareModelB(availableModels.find((model) => model !== value) || ''); }} disabled={availableModels.length < 2} className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-2 font-mono text-[11px] text-slate-200 disabled:opacity-50">
                          {availableModels.map((model) => <option key={model} value={model}>{model}</option>)}
                        </select>
                      </label>
                      <label className="space-y-1 text-[10px] text-slate-400">โมเดล B
                        <select value={compareModelB} onChange={(event) => setCompareModelB(event.target.value)} disabled={availableModels.length < 2} className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-2 font-mono text-[11px] text-slate-200 disabled:opacity-50">
                          {availableModels.filter((model) => model !== compareModelA).map((model) => <option key={model} value={model}>{model}</option>)}
                        </select>
                      </label>
                    </div>
                    {availableModels.length < 2 && <div role="status" className="rounded-lg border border-amber-800/60 bg-amber-950/20 p-2.5 text-[10px] text-amber-300">UNAVAILABLE — local runtime ยังไม่รายงานโมเดลอย่างน้อย 2 รุ่น</div>}
                    <ResourceTrendChart currentCpu={metrics?.cpu ?? null} cpuDisplay={metrics?.cpuDisplay ?? null} currentRam={metrics?.ramPercentage ?? null} ramDisplay={metrics?.ramDisplay ?? null} latencyMs={metrics?.latencyMs ?? null} resourceSource={metrics?.source ?? null} modelComparison={compareModelStats} />
                  </section>
                  <GgufModelInstaller currentModel={selectedModel} onSelectModel={setSelectedModel} />
                </div>
              )}

              {settingsTab === 'security' && (
                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">Zero Fake Policy</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px]">ENFORCED</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      ระบบจะไม่สวมรอยใช้คำตอบจำลอง หรือใช้ Hosted Cloud LLM ทดแทนโดยเงียบ ๆ หากไม่มีโมเดลจริงจะส่งสถานะ UNAVAILABLE อย่างซื่อสัตย์
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">Sandbox Isolation (/usr/bin/bwrap)</span>
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px]">BLOCKED (Env)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      ไม่พบไบนารี `/usr/bin/bwrap` ในคอนเทนเนอร์นี้ จึงใช้การแยกกระบวนการผ่าน Process Environment Stripping แทน
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">Secret Redaction</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px]">ACTIVE</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      การบันทึก Audit Logs และ Memory มีการตรวจจับและเซ็นเซอร์ API Key, Token และรหัสผ่านโดยอัตโนมัติ
                    </p>
                  </div>
                </div>
              )}

              {settingsTab === 'sync' && <SettingsSyncPanel />}
              {settingsTab === 'audit' && (
                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                    <div className="font-semibold text-slate-200">Cryptographic Evidence Ledger</div>
                    <p className="text-[11px] text-slate-400">
                      แผนงานและการกระทำทั้งหมดมีการบันทึก SHA-256 Digest เพื่อป้องกันการดัดแปลงย้อนหลัง
                    </p>
                    <div className="pt-2 text-[10px] font-mono text-cyan-400">
                      ตรวจสอบหลักฐานย้อนหลังได้ผ่าน Route `/api/audit`
                    </div>
                    <button
                      type="button"
                      onClick={() => setEvidenceModalOpen(true)}
                      className="mt-2 inline-flex items-center gap-1.5 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-3 py-2 text-[11px] font-semibold text-cyan-200 hover:bg-cyan-500/20"
                    >
                      <ShieldCheck size={13} />
                      เปิด Raw Evidence Ledger
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="px-5 py-3 border-t border-slate-800 bg-[#0c0c12] flex justify-end">
              <button
                type="button"
                onClick={() => setSettingsModalOpen(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition-colors"
              >
                ปิดหน้าต่าง
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Model Performance Latency & TPS Modal View */}
      {modelPerfModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <ModelPerformanceChart
            history={modelPerfHistory}
            modelStatus={modelStatus}
            selectedModel={selectedModel || 'local-weights'}
            provider={providerChoice}
            onRefreshProbe={testLocalEndpointConnection}
            isModal={true}
            onClose={() => setModelPerfModalOpen(false)}
          />
        </div>
      )}

      <CryptographicEvidenceModal isOpen={evidenceModalOpen} onClose={() => setEvidenceModalOpen(false)} />

      {/* Dedicated Speech-to-Text Settings Panel Modal */}
      {sttSettingsModalOpen && (
        <SpeechToTextSettingsPanel isModal={true} onClose={() => setSttSettingsModalOpen(false)} />
      )}

      {/* Clear Conversation Confirmation Modal */}
      {clearConfirmOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="clear-conv-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          onClick={() => setClearConfirmOpen(false)}
        >
          <div
            className="w-full max-w-md bg-[#071026] border border-rose-500/40 rounded-2xl shadow-2xl p-5 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <h3 id="clear-conv-title" className="text-sm font-bold text-white">
                  ล้างการสนทนานี้ (Clear Conversation)
                </h3>
                <p className="text-[11px] text-slate-400">
                  คุณต้องการล้างข้อความทั้งหมด ({messages.length} ข้อความ) ในเซสชันปัจจุบันหรือไม่?
                </p>
              </div>
              <button
                type="button"
                onClick={() => setClearConfirmOpen(false)}
                className="p-1 rounded text-slate-400 hover:text-white"
                aria-label="Close"
              >
                <X size={16} />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800">
              ข้อความในเซสชันปัจจุบันจะถูกล้างออกทั้งหมดและเริ่มต้นการสนทนาใหม่ โดยประวัติในเซสชันอื่นจะไม่ได้รับผลกระทบ
            </p>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setClearConfirmOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-700 bg-slate-800/80 text-xs text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                ยกเลิก (Cancel)
              </button>
              <button
                type="button"
                onClick={handleClearConversation}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-lg shadow-rose-600/30 transition-colors cursor-pointer"
                aria-label="Confirm Clear Conversation"
              >
                <Trash2 size={13} />
                <span>ยืนยันล้างการสนทนา (Clear Conversation)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Right-Click Context Menu for Conversation Stream Messages */}
      <MessageContextMenu
        isOpen={messageContextMenu.isOpen}
        x={messageContextMenu.x}
        y={messageContextMenu.y}
        messageId={messageContextMenu.message?.id || ''}
        messageContent={messageContextMenu.message?.content || ''}
        isPinned={messageContextMenu.message ? isMessagePinned(messageContextMenu.message.id) : false}
        role={messageContextMenu.message?.role || 'assistant'}
        onCopy={() => {
          if (messageContextMenu.message) {
            handleCopy(messageContextMenu.message.content, messageContextMenu.message.id);
            setNotice('คัดลอกข้อความลงในคลิปบอร์ดแล้ว');
            setTimeout(() => setNotice(''), 2500);
          }
        }}
        onEdit={() => {
          if (messageContextMenu.message) {
            handleEditUserMessage(messageContextMenu.message);
            startEditingMessage(messageContextMenu.message);
          }
        }}
        onSelectMessage={() => {
          if (messageContextMenu.message) {
            handleEnterSelectionMode(messageContextMenu.message.id);
          }
        }}
        onTogglePin={() => {
          if (messageContextMenu.message) {
            togglePinMessage(messageContextMenu.message);
          }
        }}
        onDelete={() => {
          if (messageContextMenu.message) {
            handleDeleteUserMessage(messageContextMenu.message.id);
          }
        }}
        onReportIssue={() => {
          if (messageContextMenu.message) {
            handleReportIssue(messageContextMenu.message);
          }
        }}
        onClose={() => setMessageContextMenu((prev) => ({ ...prev, isOpen: false, message: null }))}
      />

      {/* Conversation Overview Panel Modal */}
      <ConversationOverviewPanel
        session={overviewSession}
        isOpen={isOverviewOpen}
        onClose={() => setIsOverviewOpen(false)}
        onSelectSessionAndChat={(s) => {
          setCurrentSessionId(s.id);
          setMessages((s.messages || []) as Message[]);
          setIsOverviewOpen(false);
          if (activeMode !== 'chat' && activeMode !== 'auto') {
            setActiveMode('chat');
          }
        }}
        onFilterByKeyword={(kw) => {
          setMessageSearchQuery(kw);
          if (activeMode !== 'chat' && activeMode !== 'auto') {
            setActiveMode('chat');
          }
          setTimeout(() => {
            messageSearchInputRef.current?.focus();
          }, 100);
        }}
      />

      {/* Zyntheor API Health & Routing Enforcement Flow Dashboard */}
      <ZyntheorApiHealthDashboard
        isOpen={apiHealthDashboardOpen}
        onClose={() => setApiHealthDashboardOpen(false)}
        onNavigateToBuild={() => {
          setApiHealthDashboardOpen(false);
          setWorkspacePanelTab('build');
          setWorkspacePanelOpen(true);
        }}
      />

      {/* 5-Second Undo Toast Notification */}
      {undoSnapshot && (
        <aside
          role="status"
          aria-live="polite"
          data-testid="undo-toast-notification"
          className="fixed bottom-24 right-6 sm:right-10 z-[80] max-w-sm rounded-2xl border border-cyan-400/60 bg-[#081534]/95 p-3.5 shadow-[0_15px_40px_rgba(0,0,0,0.8)] backdrop-blur-md animate-in fade-in slide-in-from-bottom-4 duration-200 font-sans"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
              <Trash2 size={16} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                <span>ลบ {undoSnapshot.count} ข้อความแล้ว</span>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-500/30">
                  {undoCountdown}s
                </span>
              </div>
              <div className="text-[11px] text-slate-400 truncate mt-0.5">
                สามารถกู้คืนข้อความกลับมาได้ภายใน 5 วินาที
              </div>
            </div>
            <button
              type="button"
              data-testid="undo-delete-btn"
              onClick={handleUndoDelete}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)] flex items-center gap-1.5 transition-all cursor-pointer hover:scale-105 active:scale-95 shrink-0"
              title="กู้คืนข้อความที่เพิ่งลบ"
              aria-label="Undo Delete"
            >
              <RotateCcw size={13} className="animate-spin-reverse" />
              <span>เลิกทำ (Undo)</span>
            </button>
            <button
              type="button"
              data-testid="undo-dismiss-btn"
              onClick={handleDismissUndo}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="ปิดการแจ้งเตือน"
              aria-label="Dismiss Undo Notification"
            >
              <X size={14} />
            </button>
          </div>
          {/* Subtle 5-second countdown progress bar */}
          <div className="mt-2.5 h-1 w-full bg-slate-800/80 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-200 rounded-full"
              style={{ width: `${(undoCountdown / 5) * 100}%` }}
            />
          </div>
        </aside>
      )}
    </div>
  );
}

function BellIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
    </svg>
  );
}
