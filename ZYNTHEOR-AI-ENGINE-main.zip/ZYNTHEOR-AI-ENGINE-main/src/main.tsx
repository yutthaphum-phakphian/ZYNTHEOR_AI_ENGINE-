import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
import './zyntheor-theme.css';

// Intercept and absorb benign browser ResizeObserver notification loop events
if (typeof window !== 'undefined') {
  const isResizeObserverError = (msg: unknown) =>
    typeof msg === 'string' &&
    (msg.includes('ResizeObserver loop completed with undelivered notifications') ||
     msg.includes('ResizeObserver loop limit exceeded'));

  window.addEventListener(
    'error',
    (e) => {
      if (isResizeObserverError(e.message)) {
        e.stopImmediatePropagation();
        e.preventDefault();
      }
    },
    true
  );

  window.addEventListener(
    'unhandledrejection',
    (e) => {
      const reason = e.reason;
      const msg = typeof reason === 'string' ? reason : reason?.message;
      if (isResizeObserverError(msg)) {
        e.stopImmediatePropagation();
        e.preventDefault();
      }
    },
    true
  );
}

createRoot(document.getElementById('root')!).render(<App />);
