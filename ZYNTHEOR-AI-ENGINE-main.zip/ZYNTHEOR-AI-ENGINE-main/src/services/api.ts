import {
  LedgerEvent,
  WorkspaceInspectionResult,
  SystemDiagnostics,
  LocalRuntimeProbe,
  WebResearchResponse
} from '../types';

export async function fetchHealth(): Promise<{ status: string; engine: string; zeroFakePolicy: boolean; diagnostics: SystemDiagnostics }> {
  const res = await fetch('/api/health');
  if (!res.ok) throw new Error('Health check failed: ' + res.statusText);
  return res.json();
}

export async function inspectWorkspace(): Promise<WorkspaceInspectionResult> {
  const res = await fetch('/api/workspace/inspect');
  if (!res.ok) throw new Error('Workspace inspection failed: ' + res.statusText);
  return res.json();
}

export async function readWorkspaceFile(path: string): Promise<{ success: boolean; content?: string; error?: string }> {
  const res = await fetch(`/api/workspace/file?path=${encodeURIComponent(path)}`);
  return res.json();
}

export async function fetchLedgerEvents(): Promise<{ events: LedgerEvent[] }> {
  const res = await fetch('/api/ledger/events');
  if (!res.ok) throw new Error('Failed to fetch ledger events: ' + res.statusText);
  return res.json();
}

export async function verifyLedger(): Promise<{
  isValid: boolean;
  totalEvents: number;
  brokenIndex?: number;
  message: string;
  genesisHash: string;
  latestHash: string;
}> {
  const res = await fetch('/api/ledger/verify');
  if (!res.ok) throw new Error('Failed to verify ledger integrity: ' + res.statusText);
  return res.json();
}

export async function fetchRuntimeStatus(endpoint?: string): Promise<{
  diagnostics: SystemDiagnostics;
  localProbe: LocalRuntimeProbe;
}> {
  const query = endpoint ? `?endpoint=${encodeURIComponent(endpoint)}` : '';
  const res = await fetch(`/api/runtime/status${query}`);
  if (!res.ok) throw new Error('Failed to fetch runtime status: ' + res.statusText);
  return res.json();
}

export async function probeEndpoint(endpoint: string): Promise<LocalRuntimeProbe> {
  const res = await fetch('/api/runtime/probe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ endpoint })
  });
  return res.json();
}

export async function executeWebResearch(query: string): Promise<WebResearchResponse> {
  const res = await fetch('/api/web/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query })
  });
  return res.json();
}

export async function executeTool(tool: string, args: any): Promise<any> {
  const res = await fetch('/api/tools/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tool, args })
  });
  return res.json();
}

export async function analyzeCode(code: string, language: string = 'typescript'): Promise<{
  success: boolean;
  linesCount: number;
  characterCount: number;
  issues: string[];
  status: string;
  executionStatus: string;
}> {
  const res = await fetch('/api/code/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code, language })
  });
  return res.json();
}

export async function fetchProviders(): Promise<{
  defaultProvider: string;
  providers: Array<{ id: string; name: string; isLocal: boolean; defaultEndpoint: string }>;
}> {
  const res = await fetch('/api/providers');
  if (!res.ok) throw new Error('Failed to fetch providers: ' + res.statusText);
  return res.json();
}

export interface ChatInferenceResponse {
  success: boolean;
  statusCode: number;
  errorCode?: 'local_runtime_unavailable' | 'model_not_found' | 'provider_missing_key' | 'runtime_timeout' | 'inference_error';
  provider: string;
  modelId: string;
  endpoint: string;
  response: string;
  latencyMs: number;
  tokensEstimate: number;
  status: 'PASS' | 'FAIL' | 'UNAVAILABLE' | 'BLOCKED' | 'NOT_TESTED';
  message?: string;
}

export async function sendChatMessage(params: {
  prompt: string;
  systemInstruction?: string;
  provider?: string;
  modelId?: string;
  endpoint?: string;
}): Promise<ChatInferenceResponse> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  });
  const data = await res.json();
  data.statusCode = res.status;
  return data;
}

export interface CoreDiagnosticStage {
  id: string;
  label: string;
  status: 'PASS' | 'FAIL' | 'UNKNOWN' | 'NOT_TESTED';
  code: string | null;
  evidence: string;
  latencyMs: number | null;
}

export interface CoreDiagnosticsReport {
  generatedAt: string;
  endpoint: string;
  runtimeKind: 'ollama' | 'openai-compatible' | null;
  models: string[];
  overall: 'PASS' | 'FAIL' | 'PARTIAL';
  firstFailure: string | null;
  stages: CoreDiagnosticStage[];
}

/** A failed fetch of /api/diagnostics/core means the Frontend -> Core API link itself is down. */
export async function fetchCoreDiagnostics(options: { infer?: boolean; model?: string } = {}): Promise<CoreDiagnosticsReport> {
  const params = new URLSearchParams();
  if (options.infer) params.set('infer', '1');
  if (options.model) params.set('model', options.model);
  const query = params.toString() ? `?${params.toString()}` : '';
  const res = await fetch(`/api/diagnostics/core${query}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export interface PreflightCheckResult {
  id: string;
  label: string;
  status: 'PASS' | 'FAIL' | 'UNKNOWN' | 'NOT_TESTED';
  basis: 'observed' | 'invariant' | 'not_tested';
  blocking: boolean;
  code: string | null;
  evidence: string;
  latencyMs: number | null;
}

export interface PreflightReportResult {
  generatedAt: string;
  endpoint: string;
  runtimeKind: 'ollama' | 'openai-compatible' | null;
  models: string[];
  overall: 'READY' | 'PARTIAL' | 'NOT_READY';
  firstFailure: string | null;
  notTested: string[];
  checks: PreflightCheckResult[];
}

/** Preflight is read-only: it reports the cause and never switches model or provider. */
export async function fetchPreflight(options: { infer?: boolean; model?: string } = {}): Promise<PreflightReportResult> {
  const params = new URLSearchParams();
  if (options.infer) params.set('infer', '1');
  if (options.model) params.set('model', options.model);
  const query = params.toString() ? `?${params.toString()}` : '';
  const res = await fetch(`/api/preflight${query}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
