import { useCallback, useEffect, useRef, useState } from 'react';
import { getSTTSettings, saveSTTSettings, type STTSettings } from '../utils/sttSettings';

// Minimal typings: the Web Speech API is not in lib.dom for all TS versions.
type RecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: any) => void) | null;
  onerror: ((e: any) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};

function getCtor(): (new () => RecognitionLike) | null {
  if (typeof window === 'undefined') return null;
  const w = window as any;
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export interface UseSpeechToTextOptions {
  lang?: string;
  /** Called with each finalized phrase. */
  onFinal: (text: string) => void;
}

/** Voice-to-text using the browser's native Web Speech API. No audio leaves the app code. */
export function useSpeechToText({ lang, onFinal }: UseSpeechToTextOptions) {
  const supported = getCtor() !== null;
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [sttSettings, setSttSettings] = useState<STTSettings>(() => getSTTSettings());

  const recRef = useRef<RecognitionLike | null>(null);
  const onFinalRef = useRef(onFinal);
  onFinalRef.current = onFinal;
  const settingsRef = useRef(sttSettings);
  settingsRef.current = sttSettings;

  // Sync settings when updated globally
  useEffect(() => {
    const handleSettingsUpdate = (e: Event) => {
      const customEvt = e as CustomEvent<STTSettings>;
      if (customEvt.detail) {
        setSttSettings(customEvt.detail);
      } else {
        setSttSettings(getSTTSettings());
      }
    };

    window.addEventListener('zyntheor-stt-settings-updated', handleSettingsUpdate);
    return () => {
      window.removeEventListener('zyntheor-stt-settings-updated', handleSettingsUpdate);
    };
  }, []);

  const effectiveLang = lang || sttSettings.inputLanguage || 'th-TH';

  const stop = useCallback(() => {
    recRef.current?.stop();
  }, []);

  const start = useCallback(() => {
    const Ctor = getCtor();
    if (!Ctor) {
      setError('เบราว์เซอร์นี้ไม่รองรับการพิมพ์ด้วยเสียง (ลองใช้ Chrome หรือ Edge)');
      return;
    }
    if (recRef.current) return;
    setError(null);
    const rec = new Ctor();
    rec.lang = effectiveLang;
    rec.continuous = settingsRef.current.continuousListening;
    rec.interimResults = true;

    rec.onresult = (e: any) => {
      let live = '';
      const sensitivity = settingsRef.current.sensitivity; // 0 - 100
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        const item = r[0];
        const text = item?.transcript ?? '';
        const confidence = typeof item?.confidence === 'number' ? item.confidence : 1.0;

        // Apply sensitivity filter if confidence is provided by the engine
        if (confidence > 0 && sensitivity < 40 && confidence < 0.4) {
          // Low sensitivity requires higher confidence
          continue;
        }

        if (r.isFinal) {
          onFinalRef.current(text.trim());
        } else {
          live += text;
        }
      }
      setInterim(live);
    };

    rec.onerror = (e: any) => {
      const code = String(e?.error || 'unknown');
      if (code === 'not-allowed' || code === 'service-not-allowed') {
        setError('ไม่ได้รับอนุญาตให้ใช้ไมโครโฟน กรุณาอนุญาตในเบราว์เซอร์');
      } else if (code === 'no-speech') {
        setError('ไม่ได้ยินเสียงพูด');
      } else if (code !== 'aborted') {
        setError(`ข้อผิดพลาดไมโครโฟน: ${code}`);
      }
    };

    rec.onend = () => {
      recRef.current = null;
      setListening(false);
      setInterim('');
    };

    recRef.current = rec;
    try {
      rec.start();
      setListening(true);
    } catch {
      recRef.current = null;
      setError('เริ่มบันทึกเสียงไม่สำเร็จ');
    }
  }, [effectiveLang]);

  const toggle = useCallback(() => (recRef.current ? stop() : start()), [start, stop]);

  useEffect(() => () => recRef.current?.abort(), []);

  const updateSettings = useCallback((newSettings: Partial<STTSettings>) => {
    const updated = saveSTTSettings(newSettings);
    setSttSettings(updated);
  }, []);

  return {
    supported,
    listening,
    interim,
    error,
    start,
    stop,
    toggle,
    clearError: () => setError(null),
    settings: sttSettings,
    updateSettings,
  };
}
