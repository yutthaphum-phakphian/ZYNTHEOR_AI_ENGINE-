import { useCallback, useEffect, useRef, useState } from 'react';
import { isNearBottom } from '../utils/scrollHelpers';


/**
 * Keeps the latest message in view only while the user is already near the bottom.
 * If they scrolled up to read history, new messages never yank them back down;
 * `showJump` becomes true so the UI can offer a "jump to latest" button.
 * Includes an 'Auto-scroll to bottom' toggle feature that can be enabled/disabled.
 */
export function useSmartScroll<T extends HTMLElement>(
  deps: unknown[],
  threshold = 120,
  initialAutoScroll = true
) {
  const ref = useRef<T | null>(null);
  const stickRef = useRef(true);
  const [autoScrollEnabled, setAutoScrollEnabled] = useState(initialAutoScroll);
  const [showJump, setShowJump] = useState(false);
  const [isUserScrolledUp, setIsUserScrolledUp] = useState(false);

  const scrollToBottom = useCallback((smooth = true) => {
    const el = ref.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
    stickRef.current = true;
    setShowJump(false);
    setIsUserScrolledUp(false);
  }, []);

  const onScroll = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    const near = isNearBottom(el, threshold);
    stickRef.current = near;
    setIsUserScrolledUp(!near);
    setShowJump(!near);
  }, [threshold]);

  const toggleAutoScroll = useCallback(() => {
    setAutoScrollEnabled((prev) => {
      const next = !prev;
      if (next) {
        scrollToBottom(true);
      }
      return next;
    });
  }, [scrollToBottom]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Auto-scroll keeps view at latest message unless user manually scrolled up
    if (autoScrollEnabled && stickRef.current) {
      el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
      setShowJump(false);
    } else if (!stickRef.current) {
      setShowJump(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return {
    ref,
    onScroll,
    showJump,
    scrollToBottom,
    autoScrollEnabled,
    setAutoScrollEnabled,
    toggleAutoScroll,
    isUserScrolledUp,
  };
}
