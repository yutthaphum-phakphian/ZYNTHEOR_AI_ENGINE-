import { useEffect, useRef } from 'react';

export interface UsePersistedChatSessionOptions<T> {
  session: T | null | undefined;
  storageKey?: string;
  onSave?: (session: T) => void;
}

/**
 * Hook that saves the current chat session to localStorage whenever a message is sent or received,
 * ensuring state persists across page refreshes.
 */
export function usePersistedChatSession<T extends { id: string; messages: any[] }>(
  session: T | null | undefined,
  storageKey: string = 'zyntheor_persisted_chat_session',
  onSave?: (session: T) => void,
  onError?: (err: unknown) => void
) {
  const prevMsgLengthRef = useRef<number>(-1);
  const prevSessionIdRef = useRef<string | null>(null);

  // Save whenever a message is sent or received (messages length changes, or session changes)
  useEffect(() => {
    if (!session) return;
    const msgCount = Array.isArray(session.messages) ? session.messages.length : 0;
    const isNewSession = prevSessionIdRef.current !== session.id;
    const messagesChanged = prevMsgLengthRef.current !== msgCount;

    if (isNewSession || messagesChanged) {
      try {
        localStorage.setItem(storageKey, JSON.stringify(session));
        if (onSave) {
          onSave(session);
        }
      } catch (err) {
        console.warn('Failed to save chat session to localStorage:', err);
        onError?.(err);
      }
      prevMsgLengthRef.current = msgCount;
      prevSessionIdRef.current = session.id;
    }
  }, [session, session?.id, session?.messages?.length, storageKey, onSave]);

  const loadPersistedSession = (): T | null => {
    try {
      const data = localStorage.getItem(storageKey);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  };

  const clearPersistedSession = () => {
    try {
      localStorage.removeItem(storageKey);
    } catch {}
  };

  return {
    loadPersistedSession,
    clearPersistedSession,
  };
}
