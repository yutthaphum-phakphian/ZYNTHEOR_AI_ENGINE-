import { useEffect, useRef } from 'react';
import { matchesShortcut } from '../utils/shortcutMatch';

export interface ShortcutDef {
  /** KeyboardEvent.code, e.g. 'KeyN', 'Digit1', 'Slash' (layout independent, safe with Alt on macOS). */
  code: string;
  alt?: boolean;
  ctrl?: boolean;
  shift?: boolean;
  /** Human label for the overlay, e.g. 'Alt + N'. */
  label: string;
  description: string;
  run: () => void;
  /** If true, still fires while typing in an input/textarea. */
  allowInInput?: boolean;
}


function isTypingTarget(t: EventTarget | null): boolean {
  const el = t as HTMLElement | null;
  if (!el || !el.tagName) return false;
  return el.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName);
}

/** Registers one global keydown listener for the given shortcuts. */
export function useShortcutManager(shortcuts: ShortcutDef[]) {
  const ref = useRef(shortcuts);
  ref.current = shortcuts;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.defaultPrevented || e.repeat) return;
      for (const s of ref.current) {
        if (!matchesShortcut(e, s)) continue;
        if (isTypingTarget(e.target) && !s.allowInInput && !s.alt && !s.ctrl) continue;
        e.preventDefault();
        s.run();
        return;
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
}
