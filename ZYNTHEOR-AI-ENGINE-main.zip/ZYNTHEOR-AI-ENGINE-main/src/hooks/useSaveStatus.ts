import { useCallback, useState } from 'react';
import { IDLE_CHANNEL, type SaveChannel } from '../utils/saveStatus';

export type SaveChannelName = 'local' | 'server';

/** Tracks whether the current session was really persisted to localStorage and to the backend. */
export function useSaveStatus() {
  const [local, setLocal] = useState<SaveChannel>(IDLE_CHANNEL);
  const [server, setServer] = useState<SaveChannel>(IDLE_CHANNEL);
  const set = (ch: SaveChannelName) => (ch === 'local' ? setLocal : setServer);

  const begin = useCallback((ch: SaveChannelName) => set(ch)((p) => ({ ...p, state: 'saving' })), []);
  const ok = useCallback((ch: SaveChannelName) => set(ch)({ state: 'saved', at: Date.now() }), []);
  const fail = useCallback((ch: SaveChannelName) => set(ch)((p) => ({ ...p, state: 'error' })), []);

  return { local, server, begin, ok, fail };
}
