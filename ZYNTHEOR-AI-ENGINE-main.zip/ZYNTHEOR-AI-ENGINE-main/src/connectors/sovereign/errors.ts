/**
 * Sovereign Connector — result statuses and error mapping.
 *
 * The five statuses are deliberately disjoint:
 *  SUCCESS      the call completed AND the response satisfied the verified contract
 *  FAILED       the call reached a decision but did not succeed (bad request, upstream 4xx/500,
 *               response violating the contract). Not retried.
 *  TIMEOUT      no response within the configured deadline
 *  DENIED       Sovereign (or local policy) refused the credentials/permission (401/403)
 *  UNAVAILABLE  the integration cannot be used right now: no verified contract, not configured,
 *               network down, or upstream reports it is unavailable (429/502/503)
 */
export type SovereignStatus = "SUCCESS" | "FAILED" | "TIMEOUT" | "DENIED" | "UNAVAILABLE";

/** REAL = produced by a real HTTP call. MOCK = produced by an injected test transport. */
export type SovereignOrigin = "REAL" | "MOCK";

export type SovereignReason =
  | "NO_CONTRACT"
  | "CONTRACT_INVALID"
  | "NOT_CONFIGURED"
  | "UNKNOWN_OPERATION"
  | "REQUEST_INVALID"
  | "RESPONSE_CONTRACT_VIOLATION"
  | "INVALID_JSON"
  | "NETWORK"
  | "DEADLINE_EXCEEDED"
  | "UPSTREAM_DENIED"
  | "UPSTREAM_UNAVAILABLE"
  | "UPSTREAM_ERROR";

export interface SovereignResult<T = unknown> {
  status: SovereignStatus;
  origin: SovereignOrigin;
  operation: string;
  correlationId: string;
  attempts: number;
  durationMs: number;
  httpStatus?: number;
  reason?: SovereignReason;
  /** Present only when status === "SUCCESS". */
  data?: T;
  /** Human-readable, never contains credentials. */
  message: string;
}

export function mapHttpStatus(code: number): { status: SovereignStatus; reason?: SovereignReason } {
  if (code >= 200 && code < 300) return { status: "SUCCESS" };
  if (code === 401 || code === 403) return { status: "DENIED", reason: "UPSTREAM_DENIED" };
  if (code === 408 || code === 504) return { status: "TIMEOUT", reason: "DEADLINE_EXCEEDED" };
  if (code === 429 || code === 502 || code === 503) return { status: "UNAVAILABLE", reason: "UPSTREAM_UNAVAILABLE" };
  return { status: "FAILED", reason: "UPSTREAM_ERROR" };
}

/** Only transient conditions are retryable; DENIED and FAILED never are. */
export function isRetryableStatus(status: SovereignStatus, reason?: SovereignReason): boolean {
  if (status === "TIMEOUT") return true;
  if (status === "UNAVAILABLE") return reason === "UPSTREAM_UNAVAILABLE" || reason === "NETWORK";
  return false;
}
