/**
 * Sovereign Connector — public entry point.
 * Environment:
 *   SOVEREIGN_CONTRACT_PATH  path to a verified contract JSON (see docs/sovereign-api-contract.md)
 *   SOVEREIGN_API_TOKEN      bearer token (>= 16 chars)
 *   SOVEREIGN_TIMEOUT_MS     default 5000
 *   SOVEREIGN_MAX_RETRIES    default 2
 *   SOVEREIGN_AUDIT_PATH     optional JSONL file for audit evidence
 * With no contract the client reports UNAVAILABLE and never touches the network.
 */
import { loadSovereignAuth } from "./auth.js";
import { SovereignAuditLog } from "./audit.js";
import { loadContractFromFile } from "./contract.js";
import { SovereignClient, type SovereignTransport } from "./client.js";

export * from "./errors.js";
export * from "./contract.js";
export { loadSovereignAuth, redactCredentials, type SovereignAuth } from "./auth.js";
export { SovereignAuditLog, type SovereignAuditRecord } from "./audit.js";
export { SovereignClient, type SovereignClientOptions, type SovereignTransport, type FetchLike } from "./client.js";

const intFrom = (v: string | undefined, fallback: number) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
};

export async function createSovereignClientFromEnv(
  env: Record<string, string | undefined>,
  deps: { transport?: SovereignTransport } = {},
): Promise<SovereignClient> {
  const path = env.SOVEREIGN_CONTRACT_PATH?.trim();
  const loaded = path ? await loadContractFromFile(path) : null;
  return new SovereignClient({
    contract: loaded?.valid ? loaded.contract! : null,
    contractProblem: loaded && !loaded.valid ? loaded.errors : undefined,
    auth: loadSovereignAuth(env),
    audit: new SovereignAuditLog(env.SOVEREIGN_AUDIT_PATH?.trim() || undefined),
    timeoutMs: intFrom(env.SOVEREIGN_TIMEOUT_MS, 5000),
    maxRetries: intFrom(env.SOVEREIGN_MAX_RETRIES, 2),
    transport: deps.transport,
  });
}
