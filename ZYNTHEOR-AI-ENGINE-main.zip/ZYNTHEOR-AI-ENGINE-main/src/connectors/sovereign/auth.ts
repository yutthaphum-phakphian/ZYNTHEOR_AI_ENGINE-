/**
 * Sovereign Connector — authentication.
 * Bearer token from SOVEREIGN_API_TOKEN. The token is never logged, returned in results or audited.
 */
export interface SovereignAuth {
  headers(): Record<string, string>;
  /** Safe description for logs. */
  describe(): string;
}

export function loadSovereignAuth(env: Record<string, string | undefined>): SovereignAuth | null {
  const token = env.SOVEREIGN_API_TOKEN?.trim();
  if (!token || token.length < 16) return null; // too short to be a real credential → treat as not configured
  return {
    headers: () => ({ Authorization: `Bearer ${token}` }),
    describe: () => "bearer-token(redacted)",
  };
}

/** Removes credential-looking values from free text before it is stored or returned. */
export function redactCredentials(text: string): string {
  return text
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [REDACTED]")
    .replace(/(token|api[_-]?key|password|secret)(["'\s:=]+)[^\s"',}]+/gi, "$1$2[REDACTED]");
}
