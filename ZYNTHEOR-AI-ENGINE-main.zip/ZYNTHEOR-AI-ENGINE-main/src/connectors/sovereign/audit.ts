/**
 * Sovereign Connector — audit evidence.
 * One record per call, hash-chained (each record carries the previous record's hash) so truncation
 * or edits are detectable. Records hold metadata only: no request/response bodies, no credentials.
 */
import { createHash } from "node:crypto";
import { appendFile } from "node:fs/promises";
import type { SovereignOrigin, SovereignReason, SovereignStatus } from "./errors.js";
import { redactCredentials } from "./auth.js";

export interface SovereignAuditRecord {
  seq: number;
  at: string;
  correlationId: string;
  operation: string;
  origin: SovereignOrigin;
  status: SovereignStatus;
  reason?: SovereignReason;
  httpStatus?: number;
  attempts: number;
  durationMs: number;
  contractVersion?: string;
  prevHash: string;
  hash: string;
}

const GENESIS = "0".repeat(64);
const hashOf = (r: Omit<SovereignAuditRecord, "hash">) => createHash("sha256").update(JSON.stringify(r)).digest("hex");

export class SovereignAuditLog {
  private readonly records: SovereignAuditRecord[] = [];
  constructor(private readonly filePath?: string) {}

  async record(entry: Omit<SovereignAuditRecord, "seq" | "at" | "prevHash" | "hash"> & { at?: string }): Promise<SovereignAuditRecord> {
    const prev = this.records[this.records.length - 1];
    const base: Omit<SovereignAuditRecord, "hash"> = {
      seq: this.records.length + 1,
      at: entry.at ?? new Date().toISOString(),
      correlationId: entry.correlationId,
      operation: entry.operation,
      origin: entry.origin,
      status: entry.status,
      reason: entry.reason,
      httpStatus: entry.httpStatus,
      attempts: entry.attempts,
      durationMs: entry.durationMs,
      contractVersion: entry.contractVersion,
      prevHash: prev ? prev.hash : GENESIS,
    };
    const rec: SovereignAuditRecord = { ...base, hash: hashOf(base) };
    this.records.push(rec);
    if (this.filePath) {
      try {
        await appendFile(this.filePath, redactCredentials(JSON.stringify(rec)) + "\n", "utf8");
      } catch {
        // Persistence failure must not change the call outcome; in-memory chain still holds the record.
      }
    }
    return rec;
  }

  list(): readonly SovereignAuditRecord[] {
    return this.records;
  }

  /** Recomputes the chain; false means a record was altered, removed or reordered. */
  verifyChain(records: readonly SovereignAuditRecord[] = this.records): boolean {
    let prevHash = GENESIS;
    for (let i = 0; i < records.length; i++) {
      const { hash, ...rest } = records[i];
      if (rest.prevHash !== prevHash || rest.seq !== i + 1 || hashOf(rest) !== hash) return false;
      prevHash = hash;
    }
    return true;
  }
}
