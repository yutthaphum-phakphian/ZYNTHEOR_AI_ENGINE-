/**
 * Sovereign Connector — verified API contract.
 *
 * No endpoint is hard-coded here. A contract is accepted ONLY when it is supplied from a verified
 * source (OpenAPI document, SDK interface, or a live probe) and carries `verifiedAt`.
 * Without it the client reports UNAVAILABLE/NO_CONTRACT and performs no network call.
 */
import { readFile } from "node:fs/promises";

export interface SovereignOperation {
  method: "GET" | "POST";
  /** Absolute path on the contract's baseUrl, e.g. "/v1/something". */
  path: string;
  /** Explicit idempotency. GET is idempotent by default; POST only if declared. */
  idempotent?: boolean;
  /** Top-level request fields that must be present. */
  requestRequired?: string[];
  /** Top-level response fields that must be present for SUCCESS. */
  responseRequired: string[];
}

export interface SovereignContract {
  contractVersion: string;
  source: "openapi" | "sdk" | "live-probe";
  /** ISO timestamp of when the contract was verified against the real system. */
  verifiedAt: string;
  baseUrl: string;
  operations: Record<string, SovereignOperation>;
}

export interface ContractValidation {
  valid: boolean;
  errors: string[];
  contract?: SovereignContract;
}

const isObject = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);
const isStringArray = (v: unknown): v is string[] => Array.isArray(v) && v.every((x) => typeof x === "string" && x.length > 0);

function isLoopback(host: string): boolean {
  return host === "localhost" || host === "127.0.0.1" || host === "[::1]";
}

export function validateContract(input: unknown): ContractValidation {
  const errors: string[] = [];
  if (!isObject(input)) return { valid: false, errors: ["contract must be an object"] };

  if (typeof input.contractVersion !== "string" || !input.contractVersion) errors.push("contractVersion is required");
  if (!["openapi", "sdk", "live-probe"].includes(String(input.source))) errors.push("source must be openapi | sdk | live-probe");
  if (typeof input.verifiedAt !== "string" || Number.isNaN(Date.parse(input.verifiedAt))) {
    errors.push("verifiedAt must be an ISO timestamp (contract is unverified without it)");
  }

  if (typeof input.baseUrl !== "string") {
    errors.push("baseUrl is required");
  } else {
    try {
      const u = new URL(input.baseUrl);
      if (u.username || u.password) errors.push("baseUrl must not embed credentials");
      if (u.protocol !== "https:" && !(u.protocol === "http:" && isLoopback(u.hostname))) {
        errors.push("baseUrl must be https (http only for loopback)");
      }
    } catch {
      errors.push("baseUrl is not a valid URL");
    }
  }

  if (!isObject(input.operations) || Object.keys(input.operations).length === 0) {
    errors.push("operations must be a non-empty object");
  } else {
    for (const [name, raw] of Object.entries(input.operations)) {
      if (!isObject(raw)) { errors.push(`operation ${name}: must be an object`); continue; }
      if (raw.method !== "GET" && raw.method !== "POST") errors.push(`operation ${name}: method must be GET or POST`);
      if (typeof raw.path !== "string" || !raw.path.startsWith("/") || raw.path.startsWith("//") || raw.path.includes("..") || raw.path.includes("://")) {
        errors.push(`operation ${name}: path must be an absolute path without '..' or scheme`);
      }
      if (!isStringArray(raw.responseRequired)) errors.push(`operation ${name}: responseRequired must be a string array`);
      if (raw.requestRequired !== undefined && !isStringArray(raw.requestRequired)) errors.push(`operation ${name}: requestRequired must be a string array`);
      if (raw.idempotent !== undefined && typeof raw.idempotent !== "boolean") errors.push(`operation ${name}: idempotent must be boolean`);
    }
  }

  return errors.length === 0
    ? { valid: true, errors, contract: input as unknown as SovereignContract }
    : { valid: false, errors };
}

export async function loadContractFromFile(path: string): Promise<ContractValidation> {
  let raw: string;
  try {
    raw = await readFile(path, "utf8");
  } catch {
    return { valid: false, errors: ["contract file could not be read"] };
  }
  try {
    return validateContract(JSON.parse(raw));
  } catch {
    return { valid: false, errors: ["contract file is not valid JSON"] };
  }
}

export function isIdempotent(op: SovereignOperation): boolean {
  return op.idempotent ?? op.method === "GET";
}

export function missingFields(payload: unknown, required: string[] | undefined): string[] {
  if (!required || required.length === 0) return [];
  if (!isObject(payload)) return [...required];
  return required.filter((f) => !(f in payload) || payload[f] === undefined);
}
