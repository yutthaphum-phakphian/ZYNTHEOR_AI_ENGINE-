/**
 * Sovereign Connector — HTTP client.
 *
 * Boundaries:
 *  - Talks to Sovereign ONLY through operations declared in a verified contract.
 *  - Contains no Sovereign Core / Kernel / HSM / Treasury / Forensic logic.
 *  - Never fabricates a success: SUCCESS requires a 2xx AND a response satisfying the contract.
 *  - A MOCK transport can be injected for tests; every result it produces is labelled origin "MOCK".
 */
import { randomUUID } from "node:crypto";
import type { SovereignAuth } from "./auth.js";
import { SovereignAuditLog } from "./audit.js";
import {
  isIdempotent,
  missingFields,
  type SovereignContract,
} from "./contract.js";
import {
  isRetryableStatus,
  mapHttpStatus,
  type SovereignOrigin,
  type SovereignReason,
  type SovereignResult,
  type SovereignStatus,
} from "./errors.js";

export type FetchLike = (url: string, init: { method: string; headers: Record<string, string>; body?: string; signal: AbortSignal }) => Promise<{
  status: number;
  text(): Promise<string>;
}>;

export type SovereignTransport = { kind: "REAL"; fetch: FetchLike } | { kind: "MOCK"; fetch: FetchLike };

export interface SovereignClientOptions {
  contract: SovereignContract | null;
  /** Why the contract is missing/invalid, for the UNAVAILABLE message. */
  contractProblem?: string[];
  auth: SovereignAuth | null;
  audit: SovereignAuditLog;
  timeoutMs?: number;
  maxRetries?: number;
  backoffMs?: number;
  /** Defaults to the platform fetch (REAL). Tests inject { kind: "MOCK" }. */
  transport?: SovereignTransport;
  sleep?: (ms: number) => Promise<void>;
}

const realTransport = (): SovereignTransport => ({
  kind: "REAL",
  fetch: (url, init) => fetch(url, init) as unknown as ReturnType<FetchLike>,
});

export class SovereignClient {
  private readonly timeoutMs: number;
  private readonly maxRetries: number;
  private readonly backoffMs: number;
  private readonly transport: SovereignTransport;
  private readonly sleep: (ms: number) => Promise<void>;

  constructor(private readonly opts: SovereignClientOptions) {
    this.timeoutMs = opts.timeoutMs ?? 5000;
    this.maxRetries = Math.max(0, opts.maxRetries ?? 2);
    this.backoffMs = opts.backoffMs ?? 200;
    this.transport = opts.transport ?? realTransport();
    this.sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
  }

  async call<T = Record<string, unknown>>(
    operation: string,
    input?: Record<string, unknown>,
    options: { correlationId?: string } = {},
  ): Promise<SovereignResult<T>> {
    const correlationId = options.correlationId ?? randomUUID();
    const started = Date.now();
    const origin: SovereignOrigin = this.transport.kind;
    const contract = this.opts.contract;

    const finish = async (
      status: SovereignStatus,
      message: string,
      extra: { reason?: SovereignReason; httpStatus?: number; attempts?: number; data?: T } = {},
    ): Promise<SovereignResult<T>> => {
      const attempts = extra.attempts ?? 0;
      const durationMs = Date.now() - started;
      const labelled = origin === "MOCK" ? `[MOCK — not from Sovereign] ${message}` : message;
      await this.opts.audit.record({
        correlationId, operation, origin, status, reason: extra.reason, httpStatus: extra.httpStatus,
        attempts, durationMs, contractVersion: contract?.contractVersion,
      });
      return { status, origin, operation, correlationId, attempts, durationMs, httpStatus: extra.httpStatus, reason: extra.reason, data: extra.data, message: labelled };
    };

    // 1. No verified contract → stop. Never guess an endpoint.
    if (!contract) {
      const why = this.opts.contractProblem?.length ? `invalid contract: ${this.opts.contractProblem.join("; ")}` : "no verified API contract was provided";
      return finish("UNAVAILABLE", `Sovereign connection disabled — ${why}.`, {
        reason: this.opts.contractProblem?.length ? "CONTRACT_INVALID" : "NO_CONTRACT",
      });
    }

    const op = contract.operations[operation];
    if (!op) return finish("FAILED", `Operation "${operation}" is not part of the verified contract.`, { reason: "UNKNOWN_OPERATION" });

    const missingIn = missingFields(input ?? {}, op.requestRequired);
    if (missingIn.length > 0) return finish("FAILED", `Request is missing required fields: ${missingIn.join(", ")}.`, { reason: "REQUEST_INVALID" });

    if (!this.opts.auth) return finish("UNAVAILABLE", "Sovereign credentials are not configured.", { reason: "NOT_CONFIGURED" });

    // 2. Build request from contract only.
    let url = contract.baseUrl.replace(/\/+$/, "") + op.path;
    let body: string | undefined;
    if (op.method === "GET" && input) {
      const q = new URLSearchParams();
      for (const [k, v] of Object.entries(input)) if (["string", "number", "boolean"].includes(typeof v)) q.set(k, String(v));
      const qs = q.toString();
      if (qs) url += `?${qs}`;
    } else if (op.method === "POST") {
      body = JSON.stringify(input ?? {});
    }
    const headers: Record<string, string> = {
      Accept: "application/json",
      "X-Correlation-Id": correlationId,
      ...this.opts.auth.headers(),
      ...(body ? { "Content-Type": "application/json" } : {}),
    };

    // 3. Attempt loop. Retry only transient outcomes, and only for idempotent operations.
    const canRetry = isIdempotent(op);
    let attempts = 0;
    for (;;) {
      attempts += 1;
      const outcome = await this.attempt(op.method, url, headers, body);

      if (outcome.status === "SUCCESS") {
        const missingOut = missingFields(outcome.json, op.responseRequired);
        if (outcome.invalidJson) {
          return finish("FAILED", "Sovereign returned a non-JSON response.", { reason: "INVALID_JSON", httpStatus: outcome.httpStatus, attempts });
        }
        if (missingOut.length > 0) {
          return finish("FAILED", `Response violates the contract; missing: ${missingOut.join(", ")}.`, {
            reason: "RESPONSE_CONTRACT_VIOLATION", httpStatus: outcome.httpStatus, attempts,
          });
        }
        return finish("SUCCESS", "Sovereign call completed and matched the verified contract.", {
          httpStatus: outcome.httpStatus, attempts, data: outcome.json as T,
        });
      }

      if (canRetry && attempts <= this.maxRetries && isRetryableStatus(outcome.status, outcome.reason)) {
        await this.sleep(this.backoffMs * 2 ** (attempts - 1));
        continue;
      }
      return finish(outcome.status, outcome.message, { reason: outcome.reason, httpStatus: outcome.httpStatus, attempts });
    }
  }

  private async attempt(method: string, url: string, headers: Record<string, string>, body?: string): Promise<{
    status: SovereignStatus; reason?: SovereignReason; httpStatus?: number; message: string; json?: unknown; invalidJson?: boolean;
  }> {
    const controller = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, this.timeoutMs);
    try {
      const res = await this.transport.fetch(url, { method, headers, body, signal: controller.signal });
      const mapped = mapHttpStatus(res.status);
      if (mapped.status !== "SUCCESS") {
        return { status: mapped.status, reason: mapped.reason, httpStatus: res.status, message: `Sovereign responded with HTTP ${res.status}.` };
      }
      const text = await res.text();
      try {
        return { status: "SUCCESS", httpStatus: res.status, message: "ok", json: text ? JSON.parse(text) : {} };
      } catch {
        return { status: "SUCCESS", httpStatus: res.status, message: "invalid json", invalidJson: true };
      }
    } catch {
      return timedOut
        ? { status: "TIMEOUT", reason: "DEADLINE_EXCEEDED", message: `No response within ${this.timeoutMs}ms.` }
        : { status: "UNAVAILABLE", reason: "NETWORK", message: "Could not reach Sovereign (network error)." };
    } finally {
      clearTimeout(timer);
    }
  }
}
