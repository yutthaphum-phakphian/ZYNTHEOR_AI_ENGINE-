/**
 * Read-Only GitHub Client
 *
 * Implements the standard ReadOnlyGitHubClient and EngineConnector contracts.
 * All API calls are passed through the authenticated Hub Agent proxy endpoint
 * (/api/engine/connectors/github) to guarantee zero direct unauthenticated traffic,
 * strict input validation, secret redaction, and centralized audit logging.
 */

import type {
  ConnectionStatus,
  ConnectorMetadata,
  ConnectorResponse,
  EngineConnector,
  GitHubFileContent,
  GitHubGetFileParams,
  GitHubListIssuesParams,
  GitHubListIssuesResult,
  GitHubRepoMetadata,
  GitHubSearchParams,
  GitHubSearchResult,
  GitHubSearchIssueItem,
  GitHubSearchFileItem,
  ReadOnlyGitHubClient,
} from '../../types/connectors';

export interface GitHubClientOptions {
  baseUrl?: string;
  authToken?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

export class GitHubClientError extends Error {
  constructor(
    message: string,
    public readonly status?: string,
    public readonly statusCode?: number,
    public readonly reason?: string
  ) {
    super(message);
    this.name = 'GitHubClientError';
  }
}

export const GITHUB_METADATA: ConnectorMetadata = {
  id: 'github',
  name: 'GitHub (Read-Only)',
  description:
    'Public GitHub REST API connector with strict input validation for repositories, file contents, and issue tracking.',
  version: '1.0.0',
  category: 'code_repository',
  isReadOnly: true,
  supportedActions: ['get_repo', 'get_file', 'list_issues', 'search'] as const,
  requiredScopes: ['read'] as const,
  icon: 'github',
  documentationUrl: 'https://docs.github.com/en/rest',
};

export class GitHubConnectorClient
  implements ReadOnlyGitHubClient, EngineConnector<'get_repo' | 'get_file' | 'list_issues' | 'search'>
{
  readonly connectorId = 'github';
  readonly metadata = GITHUB_METADATA;

  private readonly baseUrl: string;
  private readonly getAuthToken: () => string;
  private readonly fetchImpl: typeof fetch;
  private readonly defaultTimeoutMs: number;

  constructor(options: GitHubClientOptions = {}) {
    this.baseUrl = options.baseUrl ?? '';
    this.defaultTimeoutMs = options.timeoutMs ?? 12_000;
    this.fetchImpl = options.fetchImpl ?? (typeof window !== 'undefined' ? window.fetch.bind(window) : fetch);

    if (options.authToken) {
      const token = options.authToken;
      this.getAuthToken = () => token;
    } else {
      this.getAuthToken = () => {
        try {
          if (typeof localStorage !== 'undefined') {
            return (
              localStorage.getItem('zyntheor_auth_token') ||
              localStorage.getItem('apphub_auth_token') ||
              ''
            );
          }
        } catch {
          // ignore storage errors
        }
        return '';
      };
    }
  }

  /**
   * Invokes an action through the authenticated Hub Agent endpoint.
   */
  async invoke<T = unknown>(
    action: 'get_repo' | 'get_file' | 'list_issues' | 'search',
    input: Record<string, unknown>,
    options: { signal?: AbortSignal; timeoutMs?: number } = {}
  ): Promise<ConnectorResponse<T>> {
    const controller = new AbortController();
    const timeout = options.timeoutMs ?? this.defaultTimeoutMs;
    const timer = setTimeout(() => controller.abort(), timeout);

    if (options.signal) {
      options.signal.addEventListener('abort', () => controller.abort());
    }

    try {
      const token = this.getAuthToken();
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await this.fetchImpl(`${this.baseUrl}/api/engine/connectors/github`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ action, input }),
        signal: controller.signal,
      });

      const body = (await response.json()) as ConnectorResponse<T>;

      if (!response.ok || body.status !== 'SUCCESS') {
        const errorMsg = body.message || `Hub connector request failed with status ${response.status}`;
        throw new GitHubClientError(errorMsg, body.status, response.status, body.reason);
      }

      return body;
    } catch (err: unknown) {
      if (err instanceof GitHubClientError) {
        throw err;
      }
      const isAbort = controller.signal.aborted;
      const msg = isAbort
        ? 'GitHub Hub connector request timed out or was aborted.'
        : err instanceof Error
        ? err.message
        : 'Unknown GitHub connector error';

      throw new GitHubClientError(msg, isAbort ? 'TIMEOUT' : 'FAILED', isAbort ? 504 : 500);
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Check connection status with the engine connector hub.
   */
  async checkStatus(): Promise<ConnectionStatus> {
    try {
      const token = this.getAuthToken();
      const headers: Record<string, string> = { Accept: 'application/json' };
      if (token) headers.Authorization = `Bearer ${token}`;

      const res = await this.fetchImpl(`${this.baseUrl}/api/engine/connectors`, { headers });
      if (!res.ok) {
        return 'UNAVAILABLE';
      }
      const data = (await res.json()) as { connectors?: Array<{ id: string; availability: string; grantedPermissions?: string[] }> };
      const gh = (data.connectors || []).find((c) => c.id === 'github');

      if (!gh) return 'UNAVAILABLE';
      if (gh.availability === 'AVAILABLE' && (gh.grantedPermissions || []).includes('read')) {
        return 'CONNECTED';
      }
      if (gh.availability === 'AVAILABLE') {
        return 'DISCONNECTED';
      }
      return 'UNAVAILABLE';
    } catch {
      return 'UNAVAILABLE';
    }
  }

  async getStatus(): Promise<ConnectionStatus> {
    return this.checkStatus();
  }

  async checkHealth(): Promise<{ status: ConnectionStatus; message?: string }> {
    const status = await this.checkStatus();
    return {
      status,
      message:
        status === 'CONNECTED'
          ? 'GitHub Connector active and granted read scope through authenticated hub'
          : status === 'DISCONNECTED'
          ? 'GitHub Connector registered but read scope is disabled/revoked'
          : 'GitHub Connector is currently unavailable or unconfigured',
    };
  }

  /**
   * Fetch public repository metadata (stars, forks, description, default branch, etc.)
   */
  async getRepositoryMetadata(owner: string, repo: string): Promise<GitHubRepoMetadata> {
    if (!owner?.trim() || !repo?.trim()) {
      throw new GitHubClientError('Owner and repo are required for getRepositoryMetadata', 'FAILED', 400);
    }

    const response = await this.invoke<GitHubRepoMetadata>('get_repo', {
      owner: owner.trim(),
      repo: repo.trim(),
    });

    return response.data!;
  }

  /**
   * List public repository issues (excluding pull requests).
   */
  async listIssues(params: GitHubListIssuesParams): Promise<GitHubListIssuesResult> {
    if (!params.owner?.trim() || !params.repo?.trim()) {
      throw new GitHubClientError('Owner and repo are required for listIssues', 'FAILED', 400);
    }

    const response = await this.invoke<GitHubListIssuesResult>('list_issues', {
      owner: params.owner.trim(),
      repo: params.repo.trim(),
      state: params.state || 'open',
      perPage: params.perPage || 10,
    });

    return response.data!;
  }

  /**
   * Read file content from a repository via the Contents API.
   */
  async getFileContent(params: GitHubGetFileParams): Promise<GitHubFileContent> {
    if (!params.owner?.trim() || !params.repo?.trim() || !params.path?.trim()) {
      throw new GitHubClientError('Owner, repo, and path are required for getFileContent', 'FAILED', 400);
    }

    const response = await this.invoke<GitHubFileContent>('get_file', {
      owner: params.owner.trim(),
      repo: params.repo.trim(),
      path: params.path.trim(),
      ref: params.ref || 'HEAD',
    });

    return response.data!;
  }

  /**
   * Shortcut to read the repository README.md file.
   */
  async getReadme(owner: string, repo: string, ref: string = 'HEAD'): Promise<GitHubFileContent> {
    return this.getFileContent({ owner, repo, path: 'README.md', ref });
  }

  /**
   * Search for specific issues or files across the connected repository.
   */
  async search(params: GitHubSearchParams): Promise<GitHubSearchResult> {
    if (!params.owner?.trim() || !params.repo?.trim() || !params.query?.trim()) {
      throw new GitHubClientError('Owner, repo, and query are required for search', 'FAILED', 400);
    }

    const response = await this.invoke<GitHubSearchResult>('search', {
      owner: params.owner.trim(),
      repo: params.repo.trim(),
      query: params.query.trim(),
      type: params.type || 'all',
      perPage: params.perPage || 10,
    });

    return response.data!;
  }

  /**
   * Shortcut to query for specific issues in the repository.
   */
  async searchIssues(owner: string, repo: string, query: string): Promise<GitHubSearchIssueItem[]> {
    const res = await this.search({ owner, repo, query, type: 'issues' });
    return res.issues;
  }

  /**
   * Shortcut to query for specific files/code in the repository.
   */
  async searchFiles(owner: string, repo: string, query: string): Promise<GitHubSearchFileItem[]> {
    const res = await this.search({ owner, repo, query, type: 'files' });
    return res.files;
  }
}

export const gitHubConnector = new GitHubConnectorClient();
