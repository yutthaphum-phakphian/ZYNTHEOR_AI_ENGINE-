# สถานะงาน: File Proposal Persistence

วันที่ตรวจ: 2026-10-24
สถานะรวม: `PARTIAL / SOURCE_REVIEW_REQUIRED`

## เปลี่ยนแปลง
- เพิ่ม persistence สำหรับ File Proposal ลง JSON snapshot ที่ `FILE_PROPOSALS_STORE_PATH` หรือ `.data/file-proposals.json`
- โหลดสถานะ proposal แบบ lazy ก่อนเรียก create/list/get/approve/apply/reject
- บันทึกสถานะหลัง create, request approval, approve, apply และ reject
- ใช้ temp file + rename เพื่อหลีกเลี่ยงการเขียนทับไฟล์ snapshot แบบครึ่งไฟล์
- กำหนด permission `0600` ให้ไฟล์ชั่วคราว
- หาก JSON ที่จัดเก็บเสียหายหรือมีรูปแบบไม่ถูกต้อง จะ fail closed แทนการเริ่มระบบด้วยสถานะว่าง
- audit script แยกสถานะ `IMPLEMENTED_SOURCE_REVIEW_REQUIRED` ออกจากการยืนยันผล runtime

## หลักฐานที่มี
- `node scripts/audit-essential-capabilities.mjs`: รันสำเร็จ; ตรวจพบ source persistence และระบุ runtime tests ที่ยังขาด
- `node scripts/verify-next-local-config.mjs`: PASS; เป็น source-level check เท่านั้น
- TypeScript `transpileModule` สำหรับ `server/files.ts`: 0 transpile diagnostics
- ZIP integrity/path checks: ดูผลจากแพ็กเกจส่งมอบ

## ข้อจำกัดที่ยังไม่ปิด
- ยังไม่ได้รัน unit/integration test suite เนื่องจากไม่มี `node_modules`
- ยังไม่ได้ทดสอบ restart persistence จริงด้วย process แยก
- JSON snapshot persistence ไม่ใช่ฐานข้อมูล transaction; multi-process write coordination ยังไม่รับประกัน
- proposal persistence ยังไม่มี owner/workspace binding รายผู้ใช้
- crash ระหว่างผลกระทบ workspace และการบันทึก proposal status ยังต้องมี recovery reconciliation ที่ทดสอบจริง
- ระบบสมัครสมาชิก/เข้าสู่ระบบแบบอีเมลและรหัสผ่านยังไม่ได้ implement
- App Builder end-to-end ยังไม่ผ่านการทดสอบจริง

ห้ามใช้รายงานนี้อ้างว่า production-ready หรือว่าผ่าน full tests/build.

## การตั้งค่า

- ค่าเริ่มต้น: `.data/file-proposals.json`
- สามารถกำหนดตำแหน่งด้วย `FILE_PROPOSALS_STORE_PATH` ใน environment ได้ (เพิ่มตัวอย่างไว้ใน `.env.example`)
- ไฟล์นี้เก็บ proposal/approval state เท่านั้น ไม่ใช่ฐานข้อมูลผู้ใช้ และยังไม่มีการแยกสิทธิ์ตาม user/workspace ในชั้น persistence
- การเขียนแบบ temp-file + rename และ queue ป้องกันการเขียนทับกันเฉพาะภายใน process เดียว ไม่ใช่ distributed lock หรือ transaction ข้ามหลาย process

## รอบตรวจสอบเพิ่มเติม — 2026-10-24
- เพิ่มการตรวจ duplicate proposal IDs ระหว่างโหลด snapshot; หากพบ ID ซ้ำจะ fail closed แทนการเขียนทับข้อมูลเดิมเงียบ ๆ
- เพิ่ม validation สำหรับ SHA-256 hash, timestamp, path/diff และชนิดข้อมูล optional ก่อนนำ record เข้า memory
- สถานะยังเป็น `PARTIAL`: เป็นการ hardening จากการตรวจซอร์ส ยังไม่ได้ทดสอบ restart/multi-process จริง และไม่ได้แทนฐานข้อมูลธุรกรรม

## Additional test coverage (2026-10-24)

- Added `tests/file-proposal-persistence.test.ts` to verify a created proposal is written to the configured JSON snapshot with restrictive file permissions, and that concurrent proposal creations retain their records in the final snapshot.
- Added `npm run test:persistence` as a focused test command.
- Execution status: `NOT_TESTED` in this environment. Attempted `npm run test:persistence`; it exited with code 127 because `tsx` is not installed (`sh: 1: tsx: not found`). The test is source-added only and must be run after dependencies are installed.
- This test does not yet prove process-restart recovery, corrupted-store fail-closed behavior, or multi-process safety. Those remain outstanding.
- Follow-up: added isolated child-process tests for snapshot reload after a fresh process starts and fail-closed behavior when the snapshot JSON is corrupt. These tests are authored but remain `NOT_TESTED` because local `tsx` dependencies are unavailable; do not treat test presence as runtime evidence.

## รอบ hardening เพิ่มเติม — 2026-10-24
- เพิ่มการตรวจ baseline SHA-256, approval proposalHash, timestamp ของ approval/usedAt, checkpointId และ impactList ก่อนนำ snapshot เข้า memory
- ตรวจ consistency ของ proposal hash โดยคำนวณซ้ำจาก id/name/type/content/diff/baselineHash; record ที่แก้ไขหรือเสียหายจะถูกปฏิเสธแทนการนำเข้า
- สถานะเป็น `SOURCE_CHANGED_NOT_RUNTIME_TESTED`: ยังไม่ได้รันทดสอบเพราะ `tsx` ไม่อยู่ใน environment และการติดตั้ง dependencies หมดเวลา
