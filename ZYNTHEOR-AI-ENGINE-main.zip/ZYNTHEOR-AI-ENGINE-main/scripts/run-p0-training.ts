import { ZyntheorTrainingRunnerAdapter } from "../training/runner.js";

async function main() {
  console.log("=== ZYNTHEOR P0 TRAINING ADAPTER RUNNER ===");
  const runner = new ZyntheorTrainingRunnerAdapter();

  console.log("Loading manifest and dataset...");
  const manifest = await runner.loadManifest();
  console.log(`Manifest loaded: ${manifest.manifest_id} (${manifest.name})`);

  console.log("Executing deterministic training loop...");
  const result = await runner.runTraining({ emitArtifacts: true });

  console.log("\n------------------------------------------------------------");
  console.log(`Run ID:            ${result.run_id}`);
  console.log(`Status:            ${result.status}`);
  console.log(`Epochs Completed:  ${result.epochs_completed}`);
  console.log(`Total Samples:     ${result.total_samples}`);
  console.log(`Final Train Loss:  ${result.final_metrics.train_loss}`);
  console.log(`Final Val Loss:    ${result.final_metrics.val_loss}`);
  console.log(`Perplexity:        ${result.final_metrics.perplexity}`);
  console.log(`Weights Hash:      ${result.sha256_weights_mock}`);
  console.log(`Checkpoint Path:   ${result.checkpoint_path}`);
  console.log(`Evidence Manifest: ${result.evidence_manifest_path}`);
  console.log("------------------------------------------------------------\n");
  console.log("✅ Training run successfully completed and artifacts stored.");
}

main().catch((err) => {
  console.error("Training run failed:", err);
  process.exit(1);
});
