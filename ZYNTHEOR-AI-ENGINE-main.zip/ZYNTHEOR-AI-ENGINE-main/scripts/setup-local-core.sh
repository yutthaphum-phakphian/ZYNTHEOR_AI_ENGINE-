#!/usr/bin/env bash
set -Eeuo pipefail

workspace="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
archive="${1:-$workspace/zyrquen-ai-engine.zip}"
project="$workspace/extras/zyntheor-ai-engine"
target="$workspace/extras/zyntheor-ai-engine-from-zip"

if [[ "$archive" != /* ]]; then
  archive="$workspace/$archive"
fi

for command_name in node npm; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    printf 'Required command not found: %s\n' "$command_name" >&2
    exit 1
  fi
done

if [[ -L "$project" ]]; then
  printf 'Refusing to use a symlink as the project directory: %s\n' "$project" >&2
  exit 1
fi

if [[ -f "$project/package.json" ]]; then
  app_dir="$project"
elif [[ -L "$target" ]]; then
  printf 'Refusing to use a symlink as the setup target: %s\n' "$target" >&2
  exit 1
elif [[ -e "$target" ]]; then
  if [[ ! -d "$target" || ! -f "$target/package.json" ]]; then
    printf 'Setup target already exists and is not an app directory; leaving it untouched: %s\n' "$target" >&2
    exit 1
  fi
  app_dir="$target"
else
  if [[ ! -f "$archive" ]]; then
    printf 'Archive not found: %s\nRestore or add the ZIP, then run this task again.\n' "$archive" >&2
    exit 1
  fi
  if ! command -v unzip >/dev/null 2>&1; then
    printf 'Required command not found: unzip\n' >&2
    exit 1
  fi

  stage="$(mktemp -d "$workspace/.zyntheor-setup.XXXXXX")"
  cleanup() {
    if [[ -n "${stage:-}" && -d "$stage" ]]; then
      rm -r -- "$stage"
    fi
  }
  trap cleanup EXIT

  unpacked="$stage/unpacked"
  mkdir -- "$unpacked"
  unzip -q "$archive" -d "$unpacked"

  if [[ -f "$unpacked/package.json" ]]; then
    package_json="$unpacked/package.json"
  else
    mapfile -d '' -t manifests < <(
      find "$unpacked" -type f -name package.json \
        ! -path '*/node_modules/*' \
        ! -path '*/.vite/*' \
        -print0
    )
    if [[ "${#manifests[@]}" -ne 1 ]]; then
      printf 'Expected one app package.json in the ZIP, found %s.\n' "${#manifests[@]}" >&2
      exit 1
    fi
    package_json="${manifests[0]}"
  fi
  app_dir="$(dirname -- "$package_json")"

  if [[ -e "$target" ]]; then
    printf 'Setup target appeared during extraction; refusing to overwrite it: %s\n' "$target" >&2
    exit 1
  fi
  mv -T -- "$app_dir" "$target"
  app_dir="$target"
fi

node - "$app_dir/package.json" <<'NODE'
const fs = require("node:fs");
const manifest = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));

if (typeof manifest.scripts?.start !== "string" || !manifest.scripts.start.trim()) {
  console.error("The app package.json must define a non-empty scripts.start command.");
  process.exit(1);
}
NODE

printf 'Installing dependencies in %s\n' "$app_dir"
npm --prefix "$app_dir" install

printf 'Starting ZYNTHEOR AI ENGINE in %s\n' "$app_dir"
cd -- "$app_dir"
npm run start
