import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const checks = [];
const check = (name, ok, detail) => checks.push({ name, status: ok ? 'PASS' : 'FAIL', detail });

let pkg;
try { pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')); }
catch { pkg = null; }
check('package.json readable', Boolean(pkg), pkg ? 'Parsed package metadata.' : 'Missing or invalid package.json.');
check('test scripts declared', Boolean(pkg?.scripts?.['test:unit'] && pkg?.scripts?.['test:integration']), 'Unit and integration test scripts must both exist.');
check('build script declared', Boolean(pkg?.scripts?.build), 'Build script must be defined.');
check('TypeScript check declared', Boolean(pkg?.scripts?.typecheck || pkg?.scripts?.lint), 'A typecheck/lint script must be defined.');
check('Phase 21 integration test exists', existsSync(join(root, 'tests/phase21-runtime-verification.integration.test.ts')), 'Runtime verification API contract test file.');
check('Phase 19 recovery test exists', existsSync(join(root, 'tests/phase19-recovery-e2e.integration.test.ts')), 'Recovery end-to-end test file.');
check('Human review deliverable exists', existsSync(join(root, 'docs/phases/PHASE-17-DELIVERABLE.md')) || existsSync(join(root, 'docs/phases/PHASE-16-DELIVERABLE.md')), 'Historical deliverable evidence is present.');
const nodeModules = existsSync(join(root, 'node_modules')) && statSync(join(root, 'node_modules')).isDirectory();
checks.push({ name: 'dependencies installed', status: nodeModules ? 'PASS' : 'NOT_VERIFIED', detail: nodeModules ? 'node_modules directory exists; this check does not prove dependency integrity.' : 'node_modules missing; runtime tests, build, and typecheck were not executed by this gate.' });

const results = { generatedAt: new Date().toISOString(), project: pkg?.name ?? 'UNKNOWN', checks, summary: { pass: checks.filter(x => x.status === 'PASS').length, fail: checks.filter(x => x.status === 'FAIL').length, notVerified: checks.filter(x => x.status === 'NOT_VERIFIED').length }, releaseDecision: checks.some(x => x.status === 'FAIL') ? 'BLOCKED' : (checks.some(x => x.status === 'NOT_VERIFIED') ? 'NOT_VERIFIED' : 'STRUCTURE_ONLY_PASS') };
console.log(JSON.stringify(results, null, 2));
if (results.summary.fail > 0) process.exitCode = 1;
