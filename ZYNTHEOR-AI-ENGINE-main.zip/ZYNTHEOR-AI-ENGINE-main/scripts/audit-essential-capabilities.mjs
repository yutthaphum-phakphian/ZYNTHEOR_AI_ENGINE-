import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const read = (p) => { try { return readFileSync(join(root, p), 'utf8'); } catch { return ''; } };
const server = read('server.ts');
const files = read('server/files.ts');
const app = read('src/App.tsx');
const pkg = read('package.json');
const checks = [];
const add = (id, status, evidence, risk) => checks.push({ id, status, evidence, risk });

const hasSignup = /app\.(post|put)\(['"`]\/api\/(auth\/)?(signup|register)['"`]/i.test(server);
const hasLogin = /app\.(post|put)\(['"`]\/api\/(auth\/)?(login|signin)['"`]/i.test(server);
add('member_signup_route', hasSignup ? 'FOUND_REQUIRES_REVIEW' : 'NOT_IMPLEMENTED', hasSignup ? 'A matching route pattern exists; runtime behavior not verified.' : 'No generic email/password signup route pattern found in server.ts.', 'Without member accounts, the single shared bearer token is not per-user identity.');
add('member_login_route', hasLogin ? 'FOUND_REQUIRES_REVIEW' : 'NOT_IMPLEMENTED', hasLogin ? 'A matching route pattern exists; runtime behavior not verified.' : 'No generic email/password login route pattern found in server.ts.', 'Do not claim complete member authentication.');
const proposalsMemory = /inMemoryProposals[^\n]*=\s*new Map/.test(files);
const proposalPersistence = /ensureProposalsLoaded/.test(files) && /persistProposals/.test(files) && /FILE_PROPOSALS_STORE_PATH/.test(files);
add('proposal_durable_persistence', proposalPersistence ? 'IMPLEMENTED_SOURCE_REVIEW_REQUIRED' : proposalsMemory ? 'NOT_IMPLEMENTED' : 'NOT_DETECTED', proposalPersistence ? 'JSON snapshot persistence, atomic rename, and fail-closed loading are present in source; restart behavior and concurrency need runtime tests.' : proposalsMemory ? 'File proposals are stored in an in-memory Map without detected persistence.' : 'Proposal store pattern not detected.', 'Durability is not tenant isolation; multi-process locking, crash consistency across workspace effects, and per-user ownership still require tests.');
const sessionSync = /app\.(get|post)\(['"`]\/api\/sessions\/sync['"`]/.test(server);
const strictAuth = /APPHUB_REQUIRE_AUTH/.test(server) && /app\.use\('\/api'/.test(server);
add('session_sync_auth', sessionSync && strictAuth ? 'CONDITIONAL_GUARD_ONLY' : sessionSync ? 'REVIEW_REQUIRED' : 'NOT_DETECTED', sessionSync ? 'Session sync route exists; generic API guard is opt-in via APPHUB_REQUIRE_AUTH, and the route has no evident per-user ownership check.' : 'Session sync route not detected.', 'Enable strict auth as an interim barrier; shared token still does not isolate each user.');
const workspaceOwner = /workspaceId|tenantId|userId/.test(server) && /req\.user|req\.auth|authenticatedUser/.test(server);
add('server_verified_workspace_ownership', workspaceOwner ? 'PATTERN_FOUND_REQUIRES_REVIEW' : 'NOT_VERIFIED', workspaceOwner ? 'Some identity/workspace terms appear; route-by-route ownership is not proven by this static check.' : 'No obvious server-authenticated user-to-workspace binding pattern found in server.ts.', 'Every workspace read/write must be bound to server-verified identity, not a client-supplied ID.');
const hasAppBuilderRoute = /app\.(post|put)\(['"`]\/api\/(build|builder|projects\/build)/i.test(server);
add('app_builder_generation_route', hasAppBuilderRoute ? 'FOUND_REQUIRES_RUNTIME_TEST' : 'NOT_DETECTED', hasAppBuilderRoute ? 'A candidate build route exists; generated output and platform builds are not verified.' : 'No matching canonical app-builder generation route pattern found.', 'Must generate real project files, show diff, and run allowlisted validation before claiming build support.');
const lockfile = existsSync(join(root, 'package-lock.json')) || existsSync(join(root, 'pnpm-lock.yaml')) || existsSync(join(root, 'yarn.lock'));
add('dependency_lockfile', lockfile ? 'PRESENT_NOT_VALIDATED' : 'MISSING', lockfile ? 'A package-manager lockfile exists; dependency integrity has not been verified.' : 'No npm/pnpm/yarn lockfile found at repository root.', 'Reproducible install and npm ci cannot be established without a canonical lockfile.');
const depsInstalled = existsSync(join(root, 'node_modules'));
add('runtime_test_environment', depsInstalled ? 'DEPENDENCIES_PRESENT_NOT_TESTED' : 'NOT_AVAILABLE', depsInstalled ? 'node_modules exists; tests/build still need to be executed.' : 'node_modules is absent in this environment.', 'Full tests, typecheck, build and live runtime remain unverified.');

const report = {
  generatedAt: new Date().toISOString(),
  project: JSON.parse(pkg || '{}').name || 'UNKNOWN',
  policy: 'Zero-Fake: static pattern detection is not runtime proof.',
  checks,
  summary: Object.fromEntries(['NOT_IMPLEMENTED','REVIEW_REQUIRED','NOT_VERIFIED','MISSING','NOT_AVAILABLE'].map(s => [s, checks.filter(c => c.status === s).length])),
  overall: 'PARTIAL',
};
writeFileSync(join(root, 'ESSENTIAL_CAPABILITY_AUDIT.json'), JSON.stringify(report, null, 2) + '\n');
writeFileSync(join(root, 'ESSENTIAL_CAPABILITY_AUDIT_TH.md'), `# Essential Capability Audit (Static)\n\nGenerated: ${report.generatedAt}\nProject: ${report.project}\nOverall: **${report.overall}**\n\n> This is a static source-pattern audit, not proof of runtime behavior. A pattern match does not establish correctness; a missing pattern can miss indirect implementations.\n\n| Capability | Status | Evidence | Risk / next requirement |\n|---|---|---|---|\n${checks.map(c => `| ${c.id} | \`${c.status}\` | ${c.evidence.replaceAll('|','\\|')} | ${c.risk.replaceAll('|','\\|')} |`).join('\n')}\n`);
for (const c of checks) console.log(`${c.status}\t${c.id}\t${c.evidence}`);
console.log(`OVERALL: ${report.overall} (static audit only)`);
