#!/usr/bin/env bash
# ZYNTHEOR AI ENGINE - GPU Hardware Acceleration Detection & Setup
set -Eeuo pipefail

printf '===================================================\n'
printf ' ZYNTHEOR AI ENGINE - GPU Setup & Hardware Probe   \n'
printf '===================================================\n\n'

has_nvidia=0
has_rocm=0
has_dri=0

# 1. Probe hardware devices in /dev
if [[ -d "/dev" ]]; then
  if ls /dev/nvidia* >/dev/null 2>&1; then
    has_nvidia=1
    printf '[✓] ตรวจพบอุปกรณ์ NVIDIA GPU ใน /dev/nvidia*\n'
  fi
  if [[ -e "/dev/kfd" ]]; then
    has_rocm=1
    printf '[✓] ตรวจพบอุปกรณ์ AMD ROCm Compute Node ใน /dev/kfd\n'
  fi
  if [[ -d "/dev/dri" ]]; then
    has_dri=1
    printf '[i] ตรวจพบโหนดแสดงผล /dev/dri\n'
  fi
fi

# 2. Check for nvidia-smi tool and driver
if command -v nvidia-smi >/dev/null 2>&1; then
  printf '\n[✓] พบคำสั่ง nvidia-smi; ตรวจสอบสถานะ GPU จริง:\n'
  nvidia-smi --query-gpu=name,memory.total,memory.free,driver_version --format=csv || true
  has_nvidia=1
else
  printf '\n[-] ไม่พบคำสั่ง nvidia-smi ในระบบนี้\n'
fi

# 3. Assess environment
if [[ $has_nvidia -eq 0 && $has_rocm -eq 0 ]]; then
  printf '\n[!] ข้อสังเกต: สภาพแวดล้อมปัจจุบัน (คอนเทนเนอร์/แซนด์บ็อกซ์) ไม่มีฮาร์ดแวร์ GPU เชื่อมต่ออยู่\n'
  printf '    ZYNTHEOR AI ENGINE จะทำงานด้วยโหมด CPU Inference สำหรับโมเดลขนาดเล็กอย่างปลอดภัย\n\n'
  printf 'หากต้องการเปิดใช้งาน GPU ในเครื่องโฮสต์จริง (NVIDIA Host):\n'
  printf '1. ติดตั้ง NVIDIA Container Toolkit บนโฮสต์:\n'
  printf '   sudo apt-get update && sudo apt-get install -y nvidia-container-toolkit\n'
  printf '   sudo nvidia-ctk runtime configure --runtime=docker\n'
  printf '   sudo systemctl restart docker\n\n'
  printf '2. รันคอนเทนเนอร์ด้วย GPU Profile:\n'
  printf '   docker compose -f docker-compose.yml -f docker-compose.gpu.yml up -d\n'
else
  printf '\n[✓] สภาพแวดล้อมมีฮาร์ดแวร์ตัวเร่งความเร็วพร้อมใช้งาน\n'
  printf '    สามารถสตาร์ทบริการผ่าน: docker compose -f docker-compose.yml -f docker-compose.gpu.yml up -d\n'
fi

printf '\nเสร็จสิ้นการตรวจสอบ GPU\n'
