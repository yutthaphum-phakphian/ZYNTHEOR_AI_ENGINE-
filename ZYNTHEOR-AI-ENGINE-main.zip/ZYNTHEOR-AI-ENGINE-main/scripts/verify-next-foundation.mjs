import fs from 'node:fs';
import assert from 'node:assert/strict';
const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const provider = read('server/provider.ts');
const api = read('server/api.ts');
const server = read('server.ts');
const files = read('server/files.ts');
const env = read('.env.example');

// Local inference timeout: bounded and consistent across provider and core API.
assert.match(provider, /LOCAL_AI_TIMEOUT_MS\s*\|\|\s*90000/);
assert.match(provider, /Math\.max\(10000, Math\.min\(Math\.floor\(parsed\), 180000\)\)/);
assert.match(api, /process\.env\.LOCAL_AI_TIMEOUT_MS\s*\|\|\s*90000/);
assert.match(api, /Math\.max\(10000, Math\.min\(requestedTimeout, 180000\)\)/);
assert.match(provider, /No hosted fallback was attempted/);
assert.match(env, /^LOCAL_AI_TIMEOUT_MS=90000$/m);

// API auth fails closed when configured as required; token comparison is constant-time.
assert.match(server, /APPHUB_REQUIRE_AUTH/);
assert.match(server, /auth_not_configured/);
assert.match(server, /timingSafeEqual\(candidateBytes, expectedBytes\)/);

// Workspace writes must flow through file proposals and approval; direct write stays blocked.
assert.match(server, /app\.post\('\/api\/files\/write',[\s\S]{0,250}proposal_approval_required/);
assert.match(server, /app\.post\('\/api\/proposals',[\s\S]{0,350}createFileProposal/);
assert.match(server, /app\.post\('\/api\/proposals\/:id\/approve'/);
assert.match(server, /app\.post\('\/api\/proposals\/:id\/apply'/);
assert.match(files, /validateWorkspaceRelativePath\(input\.name\)/);
assert.match(files, /assertSafeWorkspacePath/);
assert.match(files, /isBlockedFilename/);
assert.match(files, /isExecutableExtension/);

console.log('PASS: bounded Local AI timeout config is present in Provider and Core API.');
console.log('PASS: fail-closed API token guard and constant-time token comparison are present.');
console.log('PASS: workspace mutation is proposal/approval-gated with path and file-type checks.');
console.log('LIMITATION: static source assertions only; this script does not prove runtime behavior, full member accounts, app generation, or build/test status.');
