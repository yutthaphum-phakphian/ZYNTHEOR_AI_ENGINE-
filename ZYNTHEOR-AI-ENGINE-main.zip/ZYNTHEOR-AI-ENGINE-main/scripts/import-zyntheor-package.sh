#!/usr/bin/env bash
set -Eeuo pipefail

usage() {
  cat <<'USAGE'
Usage: ./import-zyntheor-package.sh [archive.zip] [--dry-run] [--stage]

Overlay a validated ZYNTHEOR package ZIP into ./zyntheor-engine.
Ignored local data, dependencies, build output, and environment files are preserved.
Use --stage to stage the imported project with Git; this does not commit or push.
USAGE
}

repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
archive="$repo_root/zyntheor-engine-package.zip"
archive_provided=false
dry_run=false
stage=false

for arg in "$@"; do
  case "$arg" in
    --help|-h)
      usage
      exit 0
      ;;
    --dry-run)
      dry_run=true
      ;;
    --stage)
      stage=true
      ;;
    -*)
      printf 'Unknown option: %s\n' "$arg" >&2
      usage >&2
      exit 2
      ;;
    *)
      if [[ "$archive_provided" == true ]]; then
        printf 'Only one archive path may be provided.\n' >&2
        usage >&2
        exit 2
      fi
      archive="$arg"
      archive_provided=true
      ;;
  esac
done

if [[ "$dry_run" == true && "$stage" == true ]]; then
  printf '%s\n' '--dry-run cannot be combined with --stage.' >&2
  exit 2
fi

if ! git -C "$repo_root" rev-parse --show-toplevel >/dev/null 2>&1; then
  printf 'Not inside a Git repository: %s\n' "$repo_root" >&2
  exit 1
fi
if [[ ! -f "$archive" ]]; then
  printf 'ZIP archive not found: %s\n' "$archive" >&2
  exit 1
fi

python3 - "$archive" <<'PY'
import stat
import sys
import zipfile

archive = sys.argv[1]
required_manifest = "zyntheor-engine/package.json"

try:
    with zipfile.ZipFile(archive) as package:
        names = set()
        for entry in package.infolist():
            name = entry.filename
            if (
                not name.startswith("zyntheor-engine/")
                or name.startswith("/")
                or "\\" in name
                or any(part in ("", ".", "..") for part in name.rstrip("/").split("/"))
            ):
                raise ValueError(f"Unexpected or unsafe ZIP path: {name!r}")
            if stat.S_ISLNK(entry.external_attr >> 16):
                raise ValueError(f"Symbolic links are not allowed in the ZIP: {name!r}")
            names.add(name)

        if required_manifest not in names:
            raise ValueError(f"ZIP is missing {required_manifest}")
except (OSError, zipfile.BadZipFile, ValueError) as error:
    print(f"Invalid package ZIP: {error}", file=sys.stderr)
    sys.exit(1)
PY

if ! unzip -tqq "$archive"; then
  printf 'ZIP integrity check failed: %s\n' "$archive" >&2
  exit 1
fi

temp_dir="$(mktemp -d)"
trap 'rm -rf -- "$temp_dir"' EXIT
unzip -q "$archive" -d "$temp_dir"

sync_options=(
  --archive
  --itemize-changes
  --exclude=/.data/
  --exclude=/node_modules/
  --exclude=/dist/
  --exclude=/build/
  --exclude=/.env
  --exclude=/.env.*.local
)
if [[ "$dry_run" == true ]]; then
  sync_options+=(--dry-run)
fi

mkdir -p "$repo_root/zyntheor-engine"
rsync "${sync_options[@]}" "$temp_dir/zyntheor-engine/" "$repo_root/zyntheor-engine/"

if [[ "$dry_run" == true ]]; then
  printf 'Dry run complete; no project files were changed.\n'
elif [[ "$stage" == true ]]; then
  git -C "$repo_root" add -- zyntheor-engine
  printf 'Imported and staged zyntheor-engine. Review the staged diff before committing.\n'
else
  printf 'Imported package into zyntheor-engine. Review the diff before staging or committing.\n'
fi
