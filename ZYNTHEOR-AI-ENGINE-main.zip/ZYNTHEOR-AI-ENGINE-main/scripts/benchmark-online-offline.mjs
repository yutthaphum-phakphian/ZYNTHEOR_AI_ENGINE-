#!/usr/bin/env node
/** Evidence-only benchmark. Hosted calls require explicit opt-in and a key. */
import { writeFile } from 'node:fs/promises';
const now = () => new Date().toISOString();
const localUrl = (process.env.LOCAL_AI_ENDPOINT || 'http://127.0.0.1:11434').replace(/\/+$/, '');
const localModel = process.env.LOCAL_AI_MODEL || '';
const timeoutMs = Math.max(1000, Math.min(Number(process.env.BENCHMARK_TIMEOUT_MS || 120000), 180000));
const prompt = 'Reply with exactly this token: ZYNTHEOR_BENCHMARK_OK';
const report = { schemaVersion: 1, startedAt: now(), policy: { hostedRequiresExplicitOptIn: true, fallbackAttempted: false }, results: [] };
async function timedRequest(provider, url, init, parse) {
  const started = performance.now(); const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const body = await response.json().catch(() => ({})); const elapsedMs = Math.round(performance.now() - started);
    const result = parse(body);
    report.results.push({ provider, status: response.ok && result.outputPresent ? 'COMPLETED' : 'FAILED', httpStatus: response.status, elapsedMs, outputPresent: Boolean(result.outputPresent), expectedTokenMatched: Boolean(result.expectedTokenMatched), errorCode: response.ok ? (result.outputPresent ? null : 'empty_or_unexpected_response') : `http_${response.status}` });
  } catch (error) {
    report.results.push({ provider, status: 'UNAVAILABLE', elapsedMs: Math.round(performance.now() - started), outputPresent: false, expectedTokenMatched: false, errorCode: error?.name === 'AbortError' ? 'timeout' : 'connection_or_parse_error' });
  } finally { clearTimeout(timer); }
}
await timedRequest('local_ollama', `${localUrl}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...(localModel ? { model: localModel } : {}), messages: [{ role: 'user', content: prompt }], stream: false, options: { num_predict: 32, temperature: 0 } }) }, body => { const output = body?.message?.content || body?.response || ''; return { outputPresent: typeof output === 'string' && !!output.trim(), expectedTokenMatched: typeof output === 'string' && output.includes('ZYNTHEOR_BENCHMARK_OK') }; });
if (process.env.RUN_ONLINE_BENCHMARK === 'true' && process.env.GROQ_API_KEY?.trim()) {
  report.results.push({ provider: 'online_groq', status: 'NOT_RUN', reason: 'external_provider_removed: Groq external provider removed. Zero network requests allowed.' });
} else report.results.push({ provider: 'online_groq', status: 'NOT_RUN', reason: 'requires RUN_ONLINE_BENCHMARK=true and GROQ_API_KEY; no hosted request was made' });
report.finishedAt = now(); report.summary = { local: report.results.find(x => x.provider === 'local_ollama')?.status || 'NOT_RUN', online: report.results.find(x => x.provider.startsWith('online_groq'))?.status || 'NOT_RUN' };
const outputPath = process.env.BENCHMARK_REPORT_PATH || 'benchmark-online-offline-report.json';
await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, { mode: 0o600 });
console.log(JSON.stringify({ reportPath: outputPath, summary: report.summary, results: report.results }, null, 2));
