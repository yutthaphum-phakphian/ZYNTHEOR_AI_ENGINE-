#!/usr/bin/env python3
"""Update the managed README section and package a project into a safe ZIP."""

from __future__ import annotations

import argparse
import os
import re
import stat
import sys
import tempfile
import zipfile
from pathlib import Path

START_MARKER = "<!-- README-MANAGED:CODE-STUDIO:START -->"
END_MARKER = "<!-- README-MANAGED:CODE-STUDIO:END -->"
ENV_SAMPLE_NAMES = {".env.example", ".env.sample", ".env.template"}
EXCLUDED_DIRS = {
    ".git",
    ".next",
    ".nuxt",
    ".turbo",
    ".venv",
    ".vite",
    ".cache",
    ".pytest_cache",
    "__pycache__",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "venv",
}
EXCLUDED_NAMES = {
    ".ds_store",
    ".netrc",
    ".npmrc",
    ".pypirc",
    "thumbs.db",
    "credentials.json",
}
EXCLUDED_SUFFIXES = {".key", ".log", ".p12", ".pfx", ".pem", ".swp", ".tmp"}


def parse_args() -> argparse.Namespace:
    default_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description="Update the managed README section from a Markdown file and create a project ZIP."
    )
    parser.add_argument(
        "--project-dir",
        type=Path,
        default=default_root,
        help=f"Project root (default: {default_root})",
    )
    parser.add_argument(
        "--section-file",
        type=Path,
        help="Markdown content to place between the managed README markers (default: <project>/docs/readme-managed-section.md)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="ZIP destination (default: sibling <project-name>-package.zip)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate inputs and report the planned README/ZIP changes without writing files.",
    )
    return parser.parse_args()


def atomic_write(path: Path, content: str, mode: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
        if mode is not None:
            os.chmod(temp_path, stat.S_IMODE(mode))
        os.replace(temp_path, path)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def replace_managed_section(readme: str, section: str) -> str:
    if not section.strip():
        raise ValueError("The README section file is empty.")
    if START_MARKER in section or END_MARKER in section:
        raise ValueError("The section file must not contain the README managed markers.")
    if readme.count(START_MARKER) != 1 or readme.count(END_MARKER) != 1:
        raise ValueError(
            "README.md must contain exactly one START and END managed marker. "
            "No README changes were made."
        )

    pattern = re.compile(
        re.escape(START_MARKER) + r"\r?\n.*?\r?\n" + re.escape(END_MARKER),
        re.DOTALL,
    )
    matches = list(pattern.finditer(readme))
    if len(matches) != 1:
        raise ValueError("README managed markers are out of order or malformed.")
    replacement = f"{START_MARKER}\n{section.strip()}\n{END_MARKER}"
    return pattern.sub(lambda _match: replacement, readme, count=1)


def is_excluded(relative_path: Path) -> bool:
    parts = [part.lower() for part in relative_path.parts]
    name = parts[-1]

    if any(part in EXCLUDED_DIRS for part in parts[:-1]):
        return True
    if name == ".env" or (name.startswith(".env.") and name not in ENV_SAMPLE_NAMES):
        return True
    if name in EXCLUDED_NAMES:
        return True
    if name.startswith("service-account") and name.endswith(".json"):
        return True
    if Path(name).suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if name.endswith("~"):
        return True
    return False


def collect_files(root: Path, archive_path: Path) -> list[tuple[Path, Path]]:
    result: list[tuple[Path, Path]] = []
    archive_resolved = archive_path.resolve()
    for path in sorted(root.rglob("*")):
        if path.is_symlink() or not path.is_file():
            continue
        if path.resolve() == archive_resolved:
            continue
        relative = path.relative_to(root)
        if is_excluded(relative):
            continue
        result.append((path, relative))
    return result


def create_zip(root: Path, archive_path: Path, files: list[tuple[Path, Path]]) -> None:
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{archive_path.stem}.", suffix=".tmp", dir=archive_path.parent
    )
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        with zipfile.ZipFile(temp_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for source, relative in files:
                archive.write(source, arcname=Path(root.name) / relative)
        with zipfile.ZipFile(temp_path, "r") as archive:
            bad_member = archive.testzip()
            if bad_member:
                raise OSError(f"ZIP integrity check failed at {bad_member}.")
        os.replace(temp_path, archive_path)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def main() -> int:
    args = parse_args()
    root = args.project_dir.expanduser().resolve()
    readme_path = root / "README.md"
    section_path = (args.section_file or root / "docs" / "readme-managed-section.md").expanduser().resolve()
    archive_path = (args.output or root.parent / f"{root.name}-package.zip").expanduser().resolve()

    if not root.is_dir():
        print(f"Project directory does not exist: {root}", file=sys.stderr)
        return 2
    if not readme_path.is_file():
        print(f"README.md not found in project: {root}", file=sys.stderr)
        return 2
    if not section_path.is_file():
        print(f"README section template not found: {section_path}", file=sys.stderr)
        return 2
    if archive_path == readme_path or archive_path == section_path:
        print("ZIP output cannot overwrite README.md or the section template.", file=sys.stderr)
        return 2

    original_readme = readme_path.read_text(encoding="utf-8")
    section = section_path.read_text(encoding="utf-8")
    try:
        updated_readme = replace_managed_section(original_readme, section)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 2

    files = collect_files(root, archive_path)
    print(f"Project: {root}")
    print(f"README source: {section_path}")
    print(f"ZIP destination: {archive_path}")
    print(f"Files to package: {len(files)} (secrets, dependencies, build and cache files excluded)")

    if args.dry_run:
        print("Dry run: no files were changed.")
        return 0

    if updated_readme != original_readme:
        atomic_write(readme_path, updated_readme, readme_path.stat().st_mode)
    try:
        # Collect again so the ZIP always contains the updated README.
        files = collect_files(root, archive_path)
        create_zip(root, archive_path, files)
    except Exception as error:
        if updated_readme != original_readme:
            atomic_write(readme_path, original_readme, readme_path.stat().st_mode)
        print(f"Packaging failed; README was restored. Reason: {error}", file=sys.stderr)
        return 1

    print(f"README updated: {readme_path}")
    print(f"ZIP created and verified: {archive_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
