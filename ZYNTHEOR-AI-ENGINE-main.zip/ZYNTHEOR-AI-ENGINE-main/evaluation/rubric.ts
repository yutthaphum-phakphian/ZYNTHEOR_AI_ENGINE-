import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { z } from "zod";

export const RubricCriterionSchema = z.object({
  id: z.string(),
  name: z.string(),
  weight: z.number().min(0).max(1),
  description: z.string(),
});

export const RubricCategorySchema = z.object({
  weight: z.number().min(0).max(1),
  minimum_score: z.number().min(0).max(100),
  description: z.string(),
  criteria: z.array(RubricCriterionSchema),
});

export const RubricSchema = z.object({
  version: z.string(),
  name: z.string(),
  description: z.string(),
  minimum_composite_score: z.number().min(0).max(100),
  categories: z.record(z.string(), RubricCategorySchema),
});

export type Rubric = z.infer<typeof RubricSchema>;
export type RubricCategory = z.infer<typeof RubricCategorySchema>;

export interface ScoreCriterionResult {
  criterion_id: string;
  score: number; // 0 to 100
  notes?: string;
}

export interface CategoryScoreResult {
  category: string;
  weight: number;
  score: number;
  minimum_score: number;
  passed: boolean;
  criteria_breakdown: ScoreCriterionResult[];
}

export interface CompositeEvaluationResult {
  timestamp: string;
  rubric_version: string;
  composite_score: number;
  minimum_composite_score: number;
  passed: boolean;
  category_scores: Record<string, CategoryScoreResult>;
}

export async function loadRubric(rubricPath?: string): Promise<Rubric> {
  const p = resolve(process.cwd(), rubricPath || "evaluation/rubric.json");
  const content = await readFile(p, "utf-8");
  return RubricSchema.parse(JSON.parse(content));
}

/**
 * Calculates category score from criteria results using rubric weights
 */
export function calculateCategoryScore(
  categoryKey: string,
  categoryDef: RubricCategory,
  results: ScoreCriterionResult[]
): CategoryScoreResult {
  let weightedSum = 0;
  let totalWeight = 0;

  for (const crit of categoryDef.criteria) {
    const res = results.find((r) => r.criterion_id === crit.id);
    const score = res ? Math.max(0, Math.min(100, res.score)) : 0;
    weightedSum += score * crit.weight;
    totalWeight += crit.weight;
  }

  const normalizedScore = totalWeight > 0 ? Number((weightedSum / totalWeight).toFixed(2)) : 0;
  const passed = normalizedScore >= categoryDef.minimum_score;

  return {
    category: categoryKey,
    weight: categoryDef.weight,
    score: normalizedScore,
    minimum_score: categoryDef.minimum_score,
    passed,
    criteria_breakdown: results,
  };
}

/**
 * Calculates overall composite score
 */
export function calculateCompositeScore(
  rubric: Rubric,
  categoryScores: Record<string, CategoryScoreResult>
): CompositeEvaluationResult {
  let compositeWeightedSum = 0;
  let totalCategoryWeight = 0;
  let allCategoriesPassed = true;

  for (const [key, catDef] of Object.entries(rubric.categories)) {
    const scoreRes = categoryScores[key];
    const score = scoreRes ? scoreRes.score : 0;
    compositeWeightedSum += score * catDef.weight;
    totalCategoryWeight += catDef.weight;

    if (!scoreRes || !scoreRes.passed) {
      allCategoriesPassed = false;
    }
  }

  const compositeScore = totalCategoryWeight > 0
    ? Number((compositeWeightedSum / totalCategoryWeight).toFixed(2))
    : 0;

  const passed = allCategoriesPassed && compositeScore >= rubric.minimum_composite_score;

  return {
    timestamp: new Date().toISOString(),
    rubric_version: rubric.version,
    composite_score: compositeScore,
    minimum_composite_score: rubric.minimum_composite_score,
    passed,
    category_scores: categoryScores,
  };
}
