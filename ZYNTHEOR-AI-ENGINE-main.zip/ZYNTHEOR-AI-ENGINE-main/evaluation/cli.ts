import { ZyntheorEvaluationRunner } from "./runner.js";

async function main() {
  console.log("=== ZYNTHEOR EVALUATION RUNNER (PHASE P0/P1) ===");
  const args = process.argv.slice(2);
  const saveBaseline = args.includes("--save-baseline");

  const runner = new ZyntheorEvaluationRunner();
  await runner.init();

  console.log("Running benchmark across 4 core criteria (Reasoning, Coding, Debugging, Instruction Following)...");
  const report = await runner.runBenchmark();

  console.log("\n------------------------------------------------------------");
  console.log(`Run ID:            ${report.run_id}`);
  console.log(`Timestamp:         ${report.timestamp}`);
  console.log(`Git Commit:        ${report.git_commit_hash}`);
  console.log(`Composite Score:   ${report.composite_score}%`);
  console.log(`Status:            ${report.passed ? "✅ PASS" : "❌ FAIL"}`);
  console.log(`Evidence SHA-256:  ${report.evidence_sha256}`);
  console.log("------------------------------------------------------------\n");

  console.log("CATEGORY BREAKDOWN:");
  for (const [cat, data] of Object.entries(report.categories)) {
    const symbol = data.passed ? "✅" : "❌";
    console.log(`  ${symbol} ${cat.padEnd(22)}: ${data.score}% (${data.items_evaluated} items)`);
    for (const item of data.details) {
      console.log(`      • [${item.id}] ${item.name}: ${item.score}%`);
    }
  }

  if (saveBaseline) {
    const baselinePath = await runner.saveReport(report, true);
    console.log(`\n✅ Baseline benchmark saved to: ${baselinePath}`);
  }

  const evidencePath = await runner.saveReport(report, false);
  console.log(`📁 Evidence log saved to: ${evidencePath}\n`);

  if (!report.passed) {
    process.exit(1);
  }
}

if (process.argv[1]?.endsWith("cli.ts") || process.argv[1]?.endsWith("cli.js")) {
  main().catch((err) => {
    console.error("Evaluation CLI failed:", err);
    process.exit(1);
  });
}
