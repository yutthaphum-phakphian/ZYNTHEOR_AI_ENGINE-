# ZYNTHEOR AI ENGINE — Restart and Verification Notes

## Source and scope
- Base: `zyntheor-engine-main-fixed.zip` (existing ZYNTHEOR codebase).
- Preserved the existing React/TypeScript application, components, routes, tests, and security documentation.
- Applied a visual refresh using a midnight-navy base with violet and cyan accents.
- Added the generated dashboard image as a design reference only; it is not runtime output.

## Required operating rules
- Local model inference must be verified with a real model/runtime process before being labelled available.
- Do not use a hosted LLM API as the production reasoning engine.
- Web search, local file search, and tools must show unavailable/blocked when their real connector is not configured.
- UI metrics, latency, token counts, and logs must come from real events, never fixed decorative values.
- File writes, deletes, shell execution, and other consequential tools must be permission-gated.

## Verification checklist
- [ ] Install dependencies from the lockfile/package manifest.
- [ ] Run `npm run typecheck`.
- [ ] Run `npm run build`.
- [ ] Run `npm run test:all` and record exact counts and failures.
- [ ] Start the application and verify health/API endpoints.
- [ ] Start a supported local model runtime and record the model identifier and runtime version.
- [ ] Send a prompt through the app UI and verify the response came from local inference, not a fixture or hosted provider.
- [ ] Verify disabled/unconfigured modes report `UNAVAILABLE` or `BLOCKED`.

## Current status
Packaging and CSS edits are complete. Runtime/model inference and test execution are **NOT TESTED** in this packaging step. Do not interpret the design reference or any dashboard status as evidence of a successful inference run.
