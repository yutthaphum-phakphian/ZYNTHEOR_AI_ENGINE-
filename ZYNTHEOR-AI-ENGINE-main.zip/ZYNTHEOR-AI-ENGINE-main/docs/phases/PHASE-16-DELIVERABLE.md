# Phase 16 — Human Approval & Recovery UX

## Implemented
- Added a Human Review Queue based on actual Agent plan status/outcome (`WAITING_APPROVAL`, `BLOCKED`, `FAILED`, `ERROR`). It shows the current count and lets the operator select a plan for inspection.
- Added a pre-approval checklist for goal, risk/tools, dependencies/prerequisites, plan hash, and ledger evidence.
- Added explicit confirmation before approve/reject API calls, showing the plan goal, risk, and hash when approving.
- Approval/rejection now surfaces non-2xx API error responses instead of silently appearing to do nothing.
- Existing cryptographic hash approval and server-side approval/execute endpoints are retained; this UI does not bypass them.

## Verification boundary
- TSX syntax transpilation and ZIP integrity should be run for this artifact.
- Full Vite build and all project tests are not claimed unless executed successfully in an environment with dependencies installed.
- The queue is a view over existing plan states, not a new durable recovery service. It does not automatically resume blocked work or change backend retry policy.
- No Git operations were performed. `ZYRQUEN-1.2-LTS` was not modified.
