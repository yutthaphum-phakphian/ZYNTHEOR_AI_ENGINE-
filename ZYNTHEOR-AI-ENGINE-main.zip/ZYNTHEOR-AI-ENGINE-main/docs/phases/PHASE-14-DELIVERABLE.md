# Phase 14 — Timeline Investigation UX

## Implemented
- Added timeline keyword search across task ID, state, task type, reason, and ISO timestamp.
- Added timeline time-window filters: all time, last 24 hours, and last 7 days.
- Timeline metrics now reflect the active filters and the UI reports how many events are shown.
- Added explicit empty-filter state with a one-click clear-filters action instead of rendering an empty chart without guidance.
- Added visible refresh failures and last-successful-refresh time; no synthetic timeline events are generated.
- Audit Ledger now listens for the Settings page's `zyntheor:audit-cache-cleared` event and reloads audit data immediately when the local cache is cleared.
- Kept existing API-backed data and approval boundaries; no fabricated event data or automatic execution was introduced.

## Verification
- Syntax transpilation checks were run for the modified TSX files.
- ZIP archive integrity was checked after packaging.
- Full build, project typecheck, and complete test suite were not run because `node_modules` is absent in this environment.
- No Git commands were run. The separate `ZYRQUEN-1.2-LTS` system was not modified.

## Limitations
- Timeline filters operate on the records returned by the existing APIs; they do not add server-side pagination or retention.
- Last refresh is a local UI timestamp, not a server timestamp.
