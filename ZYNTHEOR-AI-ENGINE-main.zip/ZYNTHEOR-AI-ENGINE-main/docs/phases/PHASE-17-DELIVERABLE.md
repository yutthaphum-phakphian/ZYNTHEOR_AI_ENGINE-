# Phase 17 — Canonical Human Review Queue API

## Implemented
- Added `GET /api/plans/review-queue` as a read-only projection of the canonical agent plan store.
- Queue includes plans in `PROPOSED`, `WAITING_APPROVAL`, `APPROVED`, `FAILED`, `BLOCKED`, and `UNKNOWN` states.
- Response contains real plan identity/status/risk/hash/revision/timestamps, approval metadata, step status/dependencies/errors/verification, and existing audit acknowledgement.
- Sensitive approval data is limited to fields required for review; no synthetic approval or execution status is generated.
- Route is registered before `/api/plans/:id` so the static path is not captured as a plan ID.
- Existing approval and execution endpoints are unchanged: `request-approval`, `approve`, `reject`, `execute`, and `verify-ledger`.

## Verification
- TypeScript syntax transpilation for the changed `server.ts`: PASS.
- ZIP integrity: PASS.
- Full project typecheck, build, and API integration tests: NOT RUN (project dependencies are not installed in this workspace).

## Boundaries
- This phase adds a canonical review-queue read API; it does not claim to add an automatic resume/retry endpoint. Approval and execution remain separate operations and continue to use the existing hash-checked server routes.
- No Git commands were run. `ZYRQUEN-1.2-LTS` was not modified.
