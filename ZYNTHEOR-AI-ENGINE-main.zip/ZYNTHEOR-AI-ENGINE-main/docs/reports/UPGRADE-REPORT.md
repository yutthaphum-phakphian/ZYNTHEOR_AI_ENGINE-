# Zyntheor AI Dev Engine — รายงานอัปเกรด

## สรุปสถานะตามข้อ

### 1) แก้ "Local engine API is unavailable" — **ทำเสร็จจริง**
**ไฟล์ที่แก้**
- `src/components/ChatWorkspace.tsx`
- `server.ts`

**สิ่งที่ทำ**
- เพิ่ม probe จริงไปที่ `GET /api/health` ทุก 30 วินาที + ปุ่ม **ลองใหม่**
- แสดงแบนเนอร์สถานะจริง: online / offline / degraded / checking พร้อมสาเหตุ (timeout, fetch failed, HTTP status)
- เมื่อ fetch `/api/chat` ล้มเหลว → แสดง `[NOT_AVAILABLE]` พร้อมเหตุผลเครือข่ายจริง **ไม่ใช้คำตอบสำเร็จรูป**
- ขยาย `/api/health` ให้รายงาน capabilities และสถานะ `OPENAI_API_KEY` (`configured` / `NOT_CONFIGURED`)
- `/api/chat` ตอบ `assistantMessage` เสมอแม้ error; รองรับ `/help`, เวลาจาก server จริง, และ provider ถ้ามี key
- คำถามทั่วไปที่ไม่มีความสามารถท้องถิ่นยังได้ `UNAVAILABLE` ตามนโยบาย zero-phantom (ไม่จำลอง LLM)

### 2) เลย์เอาต์มือถือ (~390px) — **ทำได้บางส่วน**
**ไฟล์ที่แก้**
- `src/index.css`

**สิ่งที่ทำ**
- เพิ่ม media query `max-width: 420px`: กัน overflow แนวนอน, ปุ่ม min-height 44px, pre/code/table เลื่อนในกล่องตัวเอง
- หลาย view ใช้ Tailwind `grid-cols-1` / `md:flex-row` อยู่แล้ว (stack บนจอแคบ)

**ข้อจำกัด**
- ยังไม่ได้ไล่ปรับทุก panel ของ public vanilla UI (`public/styles.css` มี media 390px เดิมอยู่แล้ว)
- ควรทดสอบจริงบนอุปกรณ์ 390px หลังรัน dev server

### 3) Persistent Memory Engine — **ทำเสร็จจริง (ส่วน core)**
**ไฟล์ที่แก้**
- `server/contextEngine.ts` — เพิ่ม type `STALE`
- `server.ts` — หลัง chat (time / plan / reasoning) บันทึก FACT/ASSUMPTION ลง Workspace memory จริงผ่าน `addContextFact`

**ที่มีอยู่แล้วในโปรเจกต์**
- เก็บถาวรใน `.data/memory/*.json` (ไม่หายเมื่อรีเฟรช)
- UI `ProjectContextMemoryPanel`: ค้นหา / แก้ไข / ลบ / นับจาก API จริง / ฟิลเตอร์ STALE

### 4) เชื่อม Plans & Tasks กับ Agent — **ทำเสร็จจริง**
**ไฟล์ที่แก้**
- `server.ts` (เส้นทาง `/plan` ใน `/api/chat`)

**สิ่งที่ทำ**
- หลังสร้างแผน → `requestPlanApproval` → สถานะ **WAITING_APPROVAL**
- ข้อความตอบกลับแจ้งชัด + ชี้ไป Approve/Reject ที่ Plans & Tasks
- บันทึก FACT ลง memory; audit ผ่าน lifecycle ของ `server/agent.ts` เดิม

**ที่มีอยู่แล้ว**
- `PlansStudioView`: ปุ่ม Approve (พร้อม Plan Hash) / Reject เมื่อ `WAITING_APPROVAL`
- Audit ledger สำหรับเปลี่ยนสถานะแผน

### 5) Code & Diff Studio — **ทำเสร็จจริง (Apply + Undo)**
**ไฟล์ที่แก้**
- `src/components/views/CodeStudioView.tsx`
- `server.ts` — เพิ่ม `POST /api/files/write` + audit `FILE_WRITTEN`

**สิ่งที่ทำ**
- ก่อน Apply: แสดง diff เดิมของ proposal (มีอยู่แล้ว)
- Apply เขียน Workspace จริงผ่าน API เดิม + snapshot สำหรับ Undo
- ปุ่ม **Undo ล่าสุด** คืนเนื้อหาเดิมผ่าน `/api/files/write` และบันทึก audit
- Apply/Reject รายไฟล์มีอยู่แล้วใน UI

---

## วิธีรัน
```bash
cd zyntheor-upgrade
npm install   # หรือ pnpm install
npm run dev   # tsx server.ts + Vite
```

ตั้ง `OPENAI_API_KEY` ใน `.env` ถ้าต้องการคำตอบจาก LLM — ไม่มี key จะได้เฉพาะความสามารถท้องถิ่น + `UNAVAILABLE` ตามจริง

## หมายเหตุนโยบาย
ระบบ**ไม่จำลอง**ผล LLM / sandbox / plan verification — ถ้าความสามารถยังไม่พร้อมจะรายงาน `NOT_AVAILABLE` / `NOT_CONFIGURED` / `UNAVAILABLE` พร้อมเหตุผล
