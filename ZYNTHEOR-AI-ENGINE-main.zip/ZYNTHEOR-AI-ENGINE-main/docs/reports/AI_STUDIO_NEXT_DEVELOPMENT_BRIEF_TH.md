# ZYNTHEOR AI ENGINE — AI Studio Development Brief

สถานะเริ่มต้น: DEVELOPMENT ONLY — ห้ามอ้างว่า production-ready หรือพร้อมใช้งานจริงโดยไม่มีหลักฐานทดสอบ

## เป้าหมายรอบนี้
พัฒนาความสามารถและเครื่องมือของ ZYNTHEOR AI ENGINE จากโค้ดฐานที่อัปโหลดให้ โดยเริ่มจาก **AI Core + Tool System** ก่อน ยังไม่ต้องทำ release ZIP สำหรับผู้ใช้ปลายทาง และไม่ต้องเพิ่มระบบสมัครสมาชิกในรอบนี้

## ข้อกำหนดที่ห้ามละเมิด
1. รักษาชื่อและขอบเขต `ZYNTHEOR AI ENGINE` แยกจาก `ZYRQUEN Ω∞` อย่างเด็ดขาด ห้ามนำโค้ด สถานะ หรือความสามารถของสองระบบมาปะปนกัน
2. Local Runtime เป็นเส้นทางประมวลผล AI เพียงเส้นทางเดียวในขอบเขตปัจจุบัน เช่น Ollama ที่ `http://127.0.0.1:11434` หรือค่าที่ตั้งผ่าน environment
3. ห้ามเรียก OpenAI, Anthropic, Groq, Gemini หรือ Hosted AI ใด ๆ; ห้าม fallback ออกอินเทอร์เน็ตโดยอัตโนมัติ หาก Local Runtime ไม่พร้อม ให้ส่งสถานะจริง `UNAVAILABLE` หรือ `CONFIG_REQUIRED`
4. ห้ามสร้างผล AI ปลอม, mock metrics ที่แสดงเหมือนข้อมูลจริง, fake session หรือ fake tool success
5. ห้ามลบหรือปิดการทดสอบเพื่อทำให้ผลผ่าน ห้ามลดความเข้มงวดของ guard, authorization, isolation หรือ validation
6. รักษาความสามารถ Chat, Planning, Build, projects, local runtime, agent, sandbox และ audit ที่มีอยู่ เว้นแต่พิสูจน์ได้ว่ารายการใดเป็นโค้ดซ้ำหรือเป็นเส้นทาง provider ภายนอกที่ต้องถอดออก
7. ก่อนแก้ไฟล์ ให้ตรวจโครงสร้างและ dependencies; แก้เฉพาะส่วนที่จำเป็นและรักษา API compatibility เท่าที่ทำได้

## งานที่ต้องทำตามลำดับ

### Phase A — ตรวจฐานและรายงานก่อนแก้
- ตรวจ `package.json`, scripts, entry points, local runtime, tool execution, tests และเส้นทาง provider ทั้งหมด
- ระบุไฟล์และ call sites ที่เกี่ยวข้องด้วยชื่อไฟล์/บรรทัดเมื่อทำได้
- แยกสิ่งที่ยืนยันจากโค้ดได้ กับสิ่งที่ยังไม่ได้ทดสอบ
- สร้าง baseline ของ typecheck, tests และ build ก่อนแก้ หากคำสั่งรันไม่ได้ให้รายงานเหตุผลจริง

### Phase B — AI Core / Reasoning Orchestrator
ออกแบบและพัฒนาตัว orchestrator ที่มีสัญญาการทำงานชัดเจน:
- รับ user request พร้อม project/workspace context ที่ผ่านการตรวจสอบ
- สร้างแผนเป็น tasks ที่มี ID, input, dependencies, state และ acceptance criteria
- สถานะงานต้องมี transitions ที่ตรวจสอบได้ เช่น `PENDING → RUNNING → SUCCEEDED | FAILED | BLOCKED`; ห้ามเปลี่ยน `RUNNING → RUNNING` ผ่าน retry โดยไม่มีกลไกที่ถูกต้อง
- จำกัดจำนวนรอบและจำนวน tool calls; ป้องกัน infinite loop และ duplicate execution
- ทุกการเปลี่ยนสถานะต้องมี audit/event ที่อธิบายได้
- ถ้าไม่มี Local Runtime ให้หยุดอย่างชัดเจน ห้ามจำลองคำตอบจากโมเดล

### Phase C — Tool Registry / Tool Executor
สร้างหรือปรับ tool system ให้มี:
- tool registry พร้อม `name`, `description`, input schema, permission level และ timeout
- ตรวจ schema ก่อนรัน; ปฏิเสธ input ผิดรูปแบบอย่างปลอดภัย
- tool execution มี execution ID, cancellation/timeout, structured result และ error codes
- แยก read-only tools ออกจาก write/execute tools; การเขียนไฟล์ต้องใช้ workspace root ที่กำหนดและป้องกัน path traversal
- shell/build/test execution ต้องอยู่ใน sandbox/ข้อจำกัดที่มีอยู่; ห้ามเปิดสิทธิ์กว้างขึ้นเพื่อให้ทดสอบผ่าน
- ห้ามให้โมเดลส่งชื่อ tool หรือ arguments ที่ข้าม authorization checks
- บันทึกผลจริง: `SUCCEEDED`, `FAILED`, `BLOCKED`, `TIMEOUT`, `CANCELLED`, `NOT_TESTED` ตามผลที่เกิดขึ้น

### Phase D — เครื่องมือพื้นฐานที่มีประโยชน์
เริ่มจากเครื่องมือขนาดเล็กที่ตรวจสอบได้:
1. `list_workspace_files` — แสดงไฟล์ภายใน workspace ที่อนุญาต
2. `read_file` — อ่านไฟล์ที่อยู่ใน workspace เท่านั้น
3. `search_code` — ค้นหาข้อความ/สัญลักษณ์ในไฟล์โค้ด
4. `propose_file_edit` — เสนอ patch/diff โดยยังไม่เขียนทับไฟล์
5. `apply_file_edit` — ใช้ patch หลังผ่านการตรวจสิทธิ์และ validation ที่มีอยู่
6. `run_typecheck` และ `run_tests` — รันคำสั่งที่ allowlist ไว้และคืน exit code/output จริง

ห้ามอ้างว่ามีเครื่องมือใดทำงานได้จนกว่าจะตรวจพบ implementation และมีการทดสอบที่เกี่ยวข้อง

### Phase E — เชื่อม Chat และ Planning
- Chat mode และ Planning mode ต้องอยู่ในพื้นที่ Chat ตามทิศทาง UI ที่กำหนด ไม่สร้าง sidebar mode ซ้ำซ้อน
- Planning ต้องแสดงแผนและสถานะ task จริง; การอนุมัติของผู้ใช้ต้องเกิดก่อนการกระทำที่เปลี่ยนไฟล์หรือมีผลข้างเคียง หากระบบปัจจุบันกำหนดไว้
- แสดงผล tool execution พร้อม output/error จริง ไม่แสดงข้อความสำเร็จล่วงหน้า
- ให้ผู้ใช้ตรวจ diff ก่อนบันทึกการเปลี่ยนแปลง

### Phase F — Tests / Evidence
เพิ่มหรือปรับ tests โดยไม่ลบ tests เดิมเพื่อให้ผ่าน อย่างน้อยต้องทดสอบ:
- Local Runtime unavailable → ไม่มี inference ปลอมและไม่มี external fallback
- provider ID ภายนอกถูกปฏิเสธ และไม่มีการส่ง request ไปยังโดเมน provider ภายนอก
- schema validation และ authorization ของทุก tool
- path traversal / workspace isolation
- timeout, cancellation, duplicate execution และ invalid state transitions
- patch preview/apply และผลลัพธ์ที่ตรงกับไฟล์จริง
- tool output/exit code ถูกส่งกลับอย่างถูกต้อง

รัน scripts ที่มีอยู่ فعلياًใน `package.json` เช่น typecheck, tests และ build โดยไม่เดาคำสั่ง หาก dependency/network ไม่พร้อม ให้ระบุ `BLOCKED` และเหตุผล

## ข้อกำหนดการรายงานผล
ส่งสรุปสุดท้ายด้วยรูปแบบ:
- `CHANGED`: ไฟล์ที่แก้และเหตุผล
- `VERIFIED`: คำสั่งที่รันจริง พร้อม exit code และผลสรุป
- `FAILED`: การทดสอบที่ล้มเหลวจริง
- `BLOCKED`: สิ่งที่ยังตรวจไม่ได้และสาเหตุ
- `NOT_TESTED`: สิ่งที่ยังไม่ได้รัน
- `REMAINING_RISKS`: ความเสี่ยงที่ยังเหลือ

ห้ามใช้คำว่า `PASS`, `SUCCESS`, `READY`, `production-ready` หรืออ้างว่าตัด external providers ออกหมดแล้ว หากไม่มีหลักฐานจาก source scan และ tests ยืนยัน

## ขอบเขตที่ยังไม่ทำในรอบนี้
- ยังไม่ต้องเพิ่มสมัครสมาชิก/เข้าสู่ระบบ
- ยังไม่ต้องเพิ่ม hosted AI provider หรือ API key UI
- ยังไม่ต้องทำ release/production packaging
- ห้ามเปลี่ยนหรือแก้ไขระบบหลัก ZYRQUEN Ω∞

## วิธีเริ่ม
1. ตรวจและรายงาน baseline ก่อน
2. ทำ Phase B และ Phase C เป็น vertical slice เล็ก ๆ
3. เชื่อมเครื่องมือพื้นฐานทีละรายการ
4. เพิ่ม tests และรันจริง
5. หากพบ blocker ให้หยุดตรงจุดนั้นและรายงาน ไม่สร้างผลลัพธ์จำลองเพื่อข้าม blocker
