# ZYNTHEOR AI ENGINE — Online/Offline Capability Plan (TH)

สถานะ: `PARTIAL` — เป็นแผนและการปรับค่า Local Runtime ไม่ใช่หลักฐานว่าโมเดลฉลาดขึ้นหรือ Online inference ใช้งานได้จริงแล้ว

## Offline (Local-first)
- ใช้ Local/Ollama เป็นค่าเริ่มต้น และตรวจ `/api/tags` ก่อนส่ง inference
- ปรับได้ผ่าน environment: `LOCAL_AI_NUM_CTX`, `LOCAL_AI_NUM_PREDICT`, `LOCAL_AI_TEMPERATURE`, `LOCAL_AI_TOP_P`, `LOCAL_AI_KEEP_ALIVE`, `LOCAL_AI_TIMEOUT_MS`
- ค่า numeric ถูกจำกัดช่วงใน adapter; `keep_alive` รับเฉพาะรูปแบบ duration ที่อนุญาต
- ถ้า Local runtime/model ไม่พร้อม ให้คืน `UNAVAILABLE`/`local_runtime_unavailable`; ห้ามสลับไป Online อัตโนมัติ
- การเพิ่ม context/จำนวน token เพิ่มการใช้ RAM/VRAM และเวลาได้ ต้อง benchmark บนเครื่องจริงก่อนเลือกค่า production

## Online (Explicit opt-in)
- OpenAI/Groq/Anthropic credentials ไม่ทำให้ provider ถูกเลือกเอง
- การเรียก Online ต้องผ่าน request scope ที่มี consent ชัดเจนของผู้ใช้
- ถ้า consent, key, network หรือ quota ไม่พร้อม ให้แจ้ง error ตามจริง; `fallbackTriggered: false`
- ต้องตรวจ privacy notice, vendor terms/DPA, data retention, redaction และ logging ก่อนใช้งานข้อมูลส่วนบุคคลจริง

## Quality improvements after runtime tuning
1. สร้าง benchmark ที่ตรึงชุด prompt สำหรับภาษาไทย, coding, tool-use, and error repair
2. วัด first-token/total latency, tokens/sec, RAM/VRAM, timeout rate, correctness และ regression
3. เพิ่ม project retrieval/RAG พร้อมแหล่งอ้างอิงและขอบเขต workspace หลังระบบ owner isolation พร้อม
4. เพิ่ม tool execution loop ที่ตรวจผลจริง และไม่ยอมรับข้อความโมเดลว่า “ผ่าน” แทน test output
5. เปรียบเทียบ Local กับ Online ด้วยชุดทดสอบเดียวกัน; ไม่อ้างว่า Online ดีกว่าหรือฉลาดกว่าโดยไม่มีผลวัด

## Verification boundary
- Unit test ที่ mock HTTP ตรวจ payload/guard logic ได้ แต่ไม่ยืนยันว่า Ollama ทำงานหรือโมเดลตอบถูก
- Live local inference: `NOT_TESTED` เว้นแต่มี log จาก runtime จริง
- Live hosted inference: `NOT_TESTED` เว้นแต่ผู้ใช้กำหนด credentials และยินยอมทดสอบ
- Full build/typecheck: ต้องรายงานผลจาก environment ที่ติดตั้ง dependencies ครบเท่านั้น

## Benchmark runner (added)

Run `npm run benchmark:online-offline` to write an evidence-only JSON report. The runner probes local Ollama first and records latency, HTTP status, whether output exists, and whether a fixed benchmark token was returned. This is a small smoke benchmark, not a broad intelligence score.

Hosted inference is **not run by default**. To explicitly opt in, set `RUN_ONLINE_BENCHMARK=true` and provide `GROQ_API_KEY`; the runner sends only the fixed benchmark prompt and never writes credentials into the report. It does not fall back between providers. The report records `fallbackAttempted: false`.

Latest sandbox run: Local Ollama `UNAVAILABLE` (connection error); Online `NOT_RUN` (no explicit opt-in/key). Therefore no real inference quality or speed comparison is available from that run.
