# Chat mode sheet — status

Scope: move mode selection into the Chat page as one compact chip + bottom sheet (like the model picker pattern).
No new pages, no sidebar changes.

## Done (code)
| Item | Status |
|------|--------|
| `src/utils/engineModes.ts`: single source for modes, `toChatMode`, depth mapping | Done |
| `ChatModeSheet.tsx`: chip above input + bottom sheet (Esc / overlay / close button) | Done |
| Replaced the old Chat \| Planning tab strip (it duplicated the top mode bar) | Done |
| Top `EngineModeSelector` keeps only Custom config + route info (`hideModeButtons`) | Done |
| Choosing Custom in the sheet opens its config panel | Done |
| Analyze / Research / Debug / Creative listed as unsupported, not selectable | Done |
| Mode change does not touch history, attachments or auth/workspace logic | Done (source-checked) |
| Added missing `package-lock.json` (root and `extras/zyntheor-ai-engine`) — CI `setup-node` failure cause | Done |

## Verification
| Check | Status |
|-------|--------|
| `tests/chat-mode-sheet.test.ts` (8 tests), run with Node type-stripping | PASS |
| Syntax check of changed TS/TSX files | PASS |
| `npm ci`, typecheck, full `test:unit`, build | BLOCKED (no node_modules / network in the authoring sandbox) |
| Rendered check on a phone, local model inference, authenticated E2E | NOT TESTED |

## Not done on purpose
- The "+" attach menu from the reference video (separate step).
- Analyze / Research / Debug: no backend workflow exists yet.

Overall: **PARTIAL**.

## Addendum — plan steps 2 and 3 (verified in this snapshot)
| Item | Status |
|------|--------|
| Auto Mode picks a mode from the message and shows the evidence (`tests/auto-mode.test.ts`, 17 tests) | PASS (run with Node type-stripping) |
| Manual mode choice is honoured and persisted | PASS (same tests) |
| Preflight (`server/preflight.ts`, `GET /api/preflight`, `tests/preflight.test.ts`, 8 tests) | PASS (mock servers) |
| Preflight shown in the existing diagnostics panel: button, per-check basis (observed / invariant / not_tested), untested list | Done (`tests/preflight-ui.test.ts`, 5 tests, PASS) |
| Preflight never switches model or provider; it only reports the cause | Done (source-checked) |

Not done on purpose: Preflight does not block sending. A read-only report is shown on request; blocking every send on an
unproven check could stop a working setup.

Still BLOCKED / NOT TESTED: `npm ci`, full typecheck, full `test:unit`, build, phone rendering, real local-model inference,
authenticated E2E, CI run. Overall: **PARTIAL**.
