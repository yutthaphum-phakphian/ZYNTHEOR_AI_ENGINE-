# Single Workspace integration — verification report (round 2)

Source of truth: the working tree from round 1 (v3 + "+" attachment menu). No project was recreated; no ZIP was unpacked again.

## What changed
| File | Change |
|---|---|
| `src/components/WorkspacePanel.tsx` (new) | Companion panel inside the Chat page with tabs Plan / Files / Diff & Approval / Run & Test / Status. Every tab calls an existing route; real HTTP status and error text are shown on failure and collected in the Status tab. |
| `src/App.tsx` | "Workspace" toggle in the chat header; panel mounts beside the chat (full-screen overlay on mobile, 420 px column on desktop). Chat state is untouched (chat stays mounted). Sidebar not modified. |
| `tests/workspace-panel.test.ts` (new) | 10 source-level checks. No existing test edited or removed. |

## Tab -> real backend
| Tab | Routes | Notes |
|---|---|---|
| Plan | `GET /api/plans`, `POST /api/plans/:id/{request-approval,approve,reject,execute}` | Uses the approval-gated agent plan store. Approve sends the plan hash; execute sends the approval id. |
| Files | `GET /api/workspace/tree`, `GET /api/files/:filename` (bearer token) | Read-only. Nested file paths may not open because the existing route takes a single path segment (existing limitation, unchanged). |
| Diff & Approval | `GET /api/proposals`, `POST /api/proposals/:id/{approve,reject,apply}` | Shows the server-generated diff, risk and impact; apply is only offered after approval. Direct writes stay blocked (`/api/files/write` -> 403). |
| Run & Test | `GET /api/sandbox/status`, `POST /api/sandbox/run` (syntax_check, typecheck, test, build) | Shows VERIFIED/FAIL/BLOCKED/NOT_VERIFIED, exit code, stdout/stderr as returned. `install_deps` is not offered. |
| Status | `GET /api/health`, `GET /api/preflight`, session error log | Preflight basis (observed/invariant/not_tested) is shown per check. |

## Evidence
| Check | Result |
|---|---|
| `tests/workspace-panel.test.ts` | PASS 9/9 (run) — every API path used by the panel resolves to a route in `server.ts` |
| Full unit suite runnable here | 445 pass / 20 fail. The failing set is identical to the pre-change baseline; every failing file was re-run alone and fails with `ERR_MODULE_NOT_FOUND` for `express` (18), `recharts` (2) or `dotenv` (1) |
| Typecheck of the new/changed files | NOT_VERIFIED as a whole project; the only error attributed to the new component is the same missing `lucide-react` module as the rest of the app |
| Lint, production build, integration tests | NOT_VERIFIED (npm registry blocked in this sandbox) |
| Panel in a browser against a live backend | NOT_VERIFIED |
| Mobile / desktop layout | NOT_VERIFIED (classes use `fixed inset-0` below `lg`, static column at `lg`; never rendered here) |

## Not done / limits (stated honestly)
- Build and Projects were folded into the panel (round 3, with the user's approval to touch the sidebar): they are removed from the sidebar mode list and from the page switch; the existing `UnifiedBuildView` and `ProjectsView` are reused unchanged inside the panel (it widens on those tabs). The sidebar "Workspace" button, the welcome "Build an app" card and the legacy `zyntheor-navigate-mode` event (`build`/`projects`) now open the panel. No original test pinned the sidebar entries; only my own earlier test `workspace-panel.test.ts` was updated to the new structure (10/10 PASS). Rendering of the wide panel/mobile overlay was NOT_VERIFIED.
- The panel cannot create plans or proposals; it lists and drives the ones that exist. Creation happens through chat/API.
- **Pre-existing fake data found and fixed:** `features/copilot/plans/plans.ts` shipped two hard-coded sample plans ("Launch onboarding flow", "Improve workspace dashboard") served by `/api/copilot/plans` to the Plans studio and TaskPlanCard. The store now starts empty (`samplePlans = []`); plans appear only when created. No existing test depended on them (`src/engine.test.ts` uses its own fixtures). New test: `tests/copilot-plans-no-sample-data.test.ts` (2/2 PASS). UI empty states already exist in PlansStudioView ("ยังไม่มีแผนงาน...") but were not seen rendered here (NOT_VERIFIED).
- Auth is still a single shared token (`APPHUB_AUTH_TOKEN`); `/api/plans`, `/api/sandbox/*`, `/api/preflight` are unauthenticated unless `APPHUB_REQUIRE_AUTH=1`.

## Verify in a full environment
```
npm ci
npm run typecheck && npm test && npm run build
APPHUB_AUTH_TOKEN=$(openssl rand -hex 24) npm run dev
```
Then open the Chat page -> "Workspace" -> each tab; put the token in the "+" menu for Files/Diff.
