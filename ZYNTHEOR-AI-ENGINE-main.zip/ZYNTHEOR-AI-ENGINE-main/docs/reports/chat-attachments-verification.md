# Chat "+" attachment menu — verification report

Source: zyntheor-ai-engine-v3.zip. Date: 2026-10-22. Sidebar untouched.

## What changed (existing systems reused)
| File | Change |
|---|---|
| `server/chatAttachments.ts` (new) | Thin adapter over the existing `inspectFile` (limits, blocklists, UTF-8/null-byte checks, secret redaction all come from `server/files.ts`). Policy + all-or-nothing ingestion. |
| `server/files.ts` | +1 export `listSupportedTextExtensions()` (no behaviour change). |
| `server.ts` | `GET /api/chat/attachment-policy`; `/api/chat` accepts `files:[{name,mimeType,contentBase64}]`: bearer-token auth (`requireWorkspaceApiAuth`, fail-closed) -> validation -> text appended to the model prompt at the 3 existing model call sites. Legacy `attachments`/`images` -> 503 `attachment_ingestion_unavailable` is unchanged. |
| `src/utils/attachmentPolicy.ts` (new) | Client mirror of the policy (UX only). |
| `src/App.tsx` | "+" menu (replaces the paperclip button) -> existing hidden file input; validation in `processIncomingFiles` (also covers paste/drop); staged tray with per-file remove (existing); error list; token field (sessionStorage); files sent as base64; staged files returned if the server rejects; file bytes are no longer stored in the session message (avoids the sync 413). |
| `tests/chat-attachments.test.ts`, `tests/chat-attachments.integration.test.ts` (new) | No existing test was edited or removed. |

## Behaviour
- Text/source files only, max 5 files, 1 MB each, 3 MB total (constants from `files.ts`; the UI reads them from the server).
- Images/binaries/.env/keys/executables are rejected (no vision/OCR component exists). The old image button was removed because it could only ever be rejected.
- Auth: the server requires `APPHUB_AUTH_TOKEN` (>=32 chars) and a matching `Authorization: Bearer`. Without a configured token the feature is reported unavailable (503), never open.
- Isolation: files are decoded in memory for one request and never written to disk or shared; nothing can leak across workspaces/conversations. NOTE: auth is a single shared token, there is no per-user isolation (pre-existing gap).
- Any invalid file rejects the whole message: nothing reaches the model.

## Evidence
| Check | Result | Evidence |
|---|---|---|
| New unit tests `tests/chat-attachments.test.ts` | PASS 14/14 | run here with tsx |
| All other unit tests runnable here | PASS (433 of 453 total; 0 failures attributable to this change) | the 20 failures are `ERR_MODULE_NOT_FOUND` for `express` (18), `recharts` (2), `dotenv` (1) — each failing file re-run individually and the missing package confirmed |
| `tests/chat-attachments.integration.test.ts` (HTTP: 401/503/422, content reaches a stand-in runtime, legacy 503) | NOT_VERIFIED | needs `express`; npm registry is blocked in this sandbox |
| Existing integration tests | NOT_VERIFIED | same reason |
| Typecheck | NOT_VERIFIED for the whole project (`express`, `lucide-react`, `React` types missing); no TS error mentions any identifier added by this change | scratch `tsc` |
| Lint (`tsc --noEmit`) | NOT_VERIFIED | same as typecheck |
| Production build (`vite build`) | NOT_VERIFIED | vite/deps not installable here |
| Real upload in a browser | NOT_VERIFIED | needs the running app |

## Known limits
- The "+" file text is sent with the current turn only; it is not re-sent in later turns' history.
- Early-return chat branches (e.g. `/plan`, web search, help) do not pass the files to a model; only the reasoning, hosted-provider and local-inference paths do.
- The stand-in runtime in the integration test proves routing of the file text, not model quality.

## Verify in a full environment
```
npm ci
npm run typecheck && npm run lint
npm test
npm run build
APPHUB_AUTH_TOKEN=$(openssl rand -hex 24) npm run dev   # then "+" -> token field -> pick a .txt/.ts file -> send
```
