# Project Structure and Duplicate Audit

## Pre-cleanup findings

This report was created before any file was moved or deleted.

### Canonical project determination

The canonical source is the post-Gemini project currently under `archive-extracted/`.
The canonical destination is the repository root (`.`), so the active project has
one obvious root and does not remain nested under an extraction-folder name.

Evidence:

- It is the only runnable project directory currently present on disk; its
  `package.json` defines `pnpm dev` and `pnpm start` as `tsx server.ts`,
  `pnpm build` as `vite build`, and unit/integration tests through `tsx --test`.
- Its README documents the local-only/no-default-model behavior and its test,
  typecheck, and build commands. Its manifest and `pnpm-lock.yaml` are the
  active pnpm dependency pair.
- Its manifest has no `@google/genai` dependency. The ZIP's root-level project
  variant has that dependency, an allow-build entry for it, and no
  `tests/server-runtime.test.ts`; this is the older Gemini-enabled variant.
- The ZIP also contains another nested `apphub-ai-agent/` variant with its own
  `package.json` and npm lockfile. These are preserved as part of the original
  archive, not merged into the canonical source.
- The extracted source differs from the ZIP's root-level variant in 16 files
  and adds `tests/server-runtime.test.ts`; these are version differences, not
  safe deletion candidates.
- Gemini references in the extracted source are limited to negative/runtime
  regression tests and secret-key redaction. No Gemini implementation or
  dependency was found in the current source.

### Repository shape before cleanup

- Root: tracked `apphub-ai-agent.zip` and the Git metadata.
- Runnable source: `archive-extracted/` (81 files outside `node_modules/`).
- Generated dependency directory: `archive-extracted/node_modules/`.
- No `dist/`, `build/`, `coverage/`, or cache output directories were found.
- No `ZYRQUEN-1.2-LTS` path was found.

### Archive and candidate checksums

SHA-256 is used for individual files. The `node_modules/` digest is a deterministic
tree inventory hash over each relative path and each file/symlink's content hash.

| Path | Size | SHA-256 / inventory SHA-256 | Reason and disposition |
|---|---:|---|---|
| `apphub-ai-agent.zip` | 4,017,322 bytes | `f1a1252974d7f8a1497ee157f269529de2a3662a1bf76d05f4af7b0f682bfd2c` | Original archive; preserve unchanged. |
| `archive-extracted/node_modules/` | 350 MiB allocated; 312,279,986 file-content bytes | `0206f8f136eb5ac6d39f9a6caac493b79ce061915ec562e845cc21d96278f190` | 24,941 files and 910 symlinks; generated dependencies, reconstructible by frozen install. Cleanup candidate after tests. |
| `archive-extracted/package.json` | 1,525 bytes | `b3271014857657ea3af8c3c0ee16d6a18a1f77ff3547bc93c123c5fdfe4796ac` | Active pnpm manifest. |
| `archive-extracted/pnpm-lock.yaml` | 129,817 bytes | `fe82170063cb4029dafc5653f46efd9cb9fb43fe0b8b2c5c976e6a71a3d86da4` | Active lock candidate; frozen install will verify. |
| `archive-extracted/pnpm-workspace.yaml` | 64 bytes | `126c02c6486677847619efe13f36ce9baed2d26fa3cf04aaf3451e2ef542b2e1` | Current pnpm build-script policy. |
| `archive-extracted/bun.lock` | 0 bytes | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | Empty, unused lockfile beside pnpm config; retain separately rather than delete. |
| `archive-extracted/tests/agent-reasoning.test.ts` | 7,919 bytes | `fcf7ec8e1188be04e9ab2ba05430b85d58f29e2b277e2feb2de4dd74a7108744` | Byte-identical to the `src/tests/` counterpart; retained because `../server/reasoning.js` resolves to different runtime modules from the two locations. |
| `archive-extracted/src/tests/agent-reasoning.test.ts` | 7,919 bytes | `fcf7ec8e1188be04e9ab2ba05430b85d58f29e2b277e2feb2de4dd74a7108744` | Byte-identical test counterpart; retained for the source re-export/client test entry point. |

### ZIP root variant versus extracted files

Each ZIP path below is rooted at the archive's top level. The ZIP remains
untouched. These same-logical-path files have different content and are
preserved; no version is discarded based on its name.

| ZIP path (size; SHA-256) | Extracted path (size; SHA-256) |
|---|---|
| `.env.example` (163; `d50d4e38a55df88ab1c4ace08eb9bc268742e7e40d808e6686faf0f47950eb71`) | `archive-extracted/.env.example` (149; `121aa0ae8d66c2d7569700c1c85fcc5cfca2180fac06f51301c3b841afedefdd`) |
| `README.md` (6,364; `0659cf41fa2eeb689438dd575f8ddb9bc05db30c897fe88b0fff6c2ca2cc1a6d`) | `archive-extracted/README.md` (6,010; `e337985ca416f6ba2d701064b04f97d8b5ecd69c86641464b3ea5494a81a6607`) |
| `metadata.json` (292; `e66f5835c9b3cf7f24d92f1eb38db65f0e09b040b3830e08e30feb4721b7d111`) | `archive-extracted/metadata.json` (251; `f274fc179b4aebb5521564124a4d799de70274a2cbfa80f8c492627367aa0b9a`) |
| `package.json` (1,557; `c0b96accd94347e6ae3619aaf4b440d8065399e8cd5f7d5fcc56539e53657905`) | `archive-extracted/package.json` (1,525; `b3271014857657ea3af8c3c0ee16d6a18a1f77ff3547bc93c123c5fdfe4796ac`) |
| `pnpm-lock.yaml` (138,402; `17f7e35ed49b959563f2cc98c7c9ae4cd1f2795f2ad59f67842e86212fe6176d`) | `archive-extracted/pnpm-lock.yaml` (129,817; `fe82170063cb4029dafc5653f46efd9cb9fb43fe0b8b2c5c976e6a71a3d86da4`) |
| `pnpm-workspace.yaml` (88; `447f7df0775ffbed54e44471fe2ed61820393a4880deab85080f4ee9dc8aee71`) | `archive-extracted/pnpm-workspace.yaml` (64; `126c02c6486677847619efe13f36ce9baed2d26fa3cf04aaf3451e2ef542b2e1`) |
| `server.ts` (32,235; `fcb1893185ba428894cb36485c28dd44c0093027358e6d3e5ee76f038b60d5b7`) | `archive-extracted/server.ts` (29,780; `1bbf1eccd3d91771f221eb37586b3bd7780c22bd60cbe70ae3c4e698f817f5ed`) |
| `server/provider.ts` (18,168; `b73ce36ba5fea9dba3d54f3c23c53b7ddbc78d39e4ba15e01128fbbedf877b62`) | `archive-extracted/server/provider.ts` (13,815; `d55a0b2c18d0a9609404cf9f99cb1a0050c6d38d806937e4583c90ec06de093b`) |
| `src/components/ChatWorkspace.tsx` (34,122; `bf759e15d5f3d686190463e9ff3466ef34625312ba3db981d390f3ed7d99c18f`) | `archive-extracted/src/components/ChatWorkspace.tsx` (29,762; `1f698af02d9012c8847f5a8b0a5a660f6c3b29f46542ef219461791f3aabc5ec`) |
| `src/components/views/AuditLedgerView.tsx` (48,212; `425792170809a994b1ad4d5a01e481bbadcc09a67d4ef7ef5e740c7b39a6e09a`) | `archive-extracted/src/components/views/AuditLedgerView.tsx` (46,364; `24dfb2ed10a10f3ccb50a99cc98b4f326393216d7e916e6244f7876089b1fab4`) |
| `src/components/views/SettingsView.tsx` (29,357; `943732ee7612498735f06253dadc283a6987e1b5f01f263bff6a6c7ea0bd74e0`) | `archive-extracted/src/components/views/SettingsView.tsx` (29,108; `8602f7b492e12777744a216e10a99d78072ac999ffa25a05e85886170eb5ccc3`) |
| `src/utils/newFeatureLogic.ts` (3,263; `0f8b1978eb6ee1d727a63507890253c4548158417ca0cf69e6970f9c63bc7509`) | `archive-extracted/src/utils/newFeatureLogic.ts` (4,522; `dcb14afac3ea6290600ebefe8eb0554449be39d3af26d86e3632d61020f31dd3`) |
| `tests/new-features.test.ts` (4,186; `8104062a7861174fa00796b493d1f97c848cd3c059447615b173853ae5d3c41c`) | `archive-extracted/tests/new-features.test.ts` (4,849; `fa060ad96e0104a2c2edbdb3596edb379f92ca470ec9c9174296821255c8d4d8`) |
| `tests/provider.test.ts` (4,429; `48edbb264b6ec05dd7c4ee3d180041e091b6c87632947c927fd2ddb4e54b10e2`) | `archive-extracted/tests/provider.test.ts` (5,178; `209d3e84b065f52b6f70382fe87d9834d3576fd2371c414c567bc7edf6bc449`) |
| `tests/workspace.test.ts` (63,582; `deac452d491964dcfad76416216b6c569e76060957034cfc61e31f50714de19`) | `archive-extracted/tests/workspace.test.ts` (63,801; `d106f9c881f49fab6d12000f8a827793425cde8f3b76fc48fca61599251f5459`) |
| `tests/zyntheor-regression.test.ts` (33,758; `4d89ea4ee86a321628c345fa1a5c6b094d7cfac9c45441c96a23f77e1a478eea`) | `archive-extracted/tests/zyntheor-regression.test.ts` (33,708; `1060edd3f42842c0e38a65c9ca0ff1eb9fba7ae078fb77ec8d70f979554526a0`) |

The extracted-only `tests/server-runtime.test.ts` is 3,909 bytes
(`885fe66de5a8b79a04c0c01194d8739e44d157b09f22e3ec1d905f2ce225dab7`).
It exercises the local server's no-Gemini behavior and is part of the canonical
test suite.

### Planned cleanup and validation

After this report is recorded:

1. Move the selected source tree to the repository root without merging it with
   either ZIP-contained version; retain the original ZIP unchanged.
2. Move the empty `bun.lock` to a clearly separate retained-unused-files area.
   Do not delete source, tests, configs, or locks based only on matching names.
3. Install using the frozen pnpm lockfile, then run typecheck, unit/integration
   tests, production build, and a runtime smoke test from the root only.
4. Recheck Gemini references and imports/path references; remove only
   successfully verified generated build/dependency artifacts, if safe.

No files have been moved or deleted yet.

## Post-audit migration update

The active tracked project files have since been moved from `archive-extracted/`
to the repository root, preserving their relative paths. The empty, unused
`bun.lock` is retained at `retained-unused-files/bun.lock`.

Pre-existing ignored `.data/`, `dist/`, and `node_modules/` directories under
`archive-extracted/` were left untouched. A frozen pnpm install and production
build also created ignored `node_modules/` and `dist/` directories at the root.

Validation from the repository root:

- `pnpm install --frozen-lockfile` — passed.
- `pnpm typecheck` — passed.
- `pnpm test` — passed: 159 tests, 0 failures.
- `pnpm build` — passed. Vite reported the existing large-chunk warning for
  the 1.53 MB minified application bundle.

The migration has not been committed or pushed.
