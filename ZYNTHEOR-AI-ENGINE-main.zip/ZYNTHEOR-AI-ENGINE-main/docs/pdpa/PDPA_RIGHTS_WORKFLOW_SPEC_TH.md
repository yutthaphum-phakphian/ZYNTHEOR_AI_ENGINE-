# ZYNTHEOR AI ENGINE — PDPA Data Subject Rights Workflow

**สถานะ: `SPECIFIED / NOT_IMPLEMENTED / NOT_RUNTIME_VERIFIED`**

เอกสารนี้กำหนดสัญญาการทำงานก่อนเขียน API จริง ไม่ใช่หลักฐานว่ามี endpoint หรือระบบจัดการคำขอแล้ว

## 1. ห้ามเปิด endpoint จนกว่าจะผ่าน prerequisite

- มีบัญชีผู้ใช้ที่เซิร์ฟเวอร์ยืนยันตัวตนได้ ไม่เชื่อ `userId` จาก request body/query
- ทุกระเบียนมีเจ้าของที่ตรวจสอบได้และทุก storage ระบุวิธีค้นหา/ลบ/ส่งออก
- มี session/token revocation, rate limit, CSRF protection เมื่อใช้ cookie, audit redaction และ authorization tests
- มีฐานข้อมูล/ที่เก็บคำขอที่รองรับการเขียนแบบ atomic และการกู้คืน; ห้ามใช้ไฟล์ JSON แบบ process-local เป็น ledger หลักเมื่อมีหลาย instance
- กำหนดผู้รับผิดชอบและกระบวนการตรวจตัวตนโดยไม่เก็บสำเนาเอกสารยืนยันตัวตนเกินจำเป็น

## 2. Workflow ที่ต้องรองรับ

1. `RECEIVED` — รับคำขอและออก `requestId` ที่สุ่มคาดเดาไม่ได้
2. `IDENTITY_REVIEW` — ตรวจตัวตนตามความเสี่ยง; ยังไม่เปิดเผยว่ามีข้อมูลของบุคคลนั้นหรือไม่ให้ผู้ร้องที่ยังไม่ผ่านการตรวจ
3. `SCOPE_REVIEW` — แยกประเภทคำขอ: access/copy, rectification, erasure, restriction/objection where applicable, consent withdrawal หรือ complaint
4. `IN_PROGRESS` — ระบุระบบต้นทางและผู้รับผิดชอบของแต่ละ data store
5. `PARTIALLY_FULFILLED` — ใช้เมื่อมีข้อมูลบางส่วนต้องเก็บต่อด้วยเหตุที่ตรวจสอบได้ หรือ backup ยังไม่หมดรอบ; ระบุข้อยกเว้นและกำหนดเวลาที่ตรวจยืนยันแล้ว
6. `FULFILLED` — ใช้ได้เมื่อมีหลักฐานยืนยันครบตามขอบเขตที่อนุมัติเท่านั้น
7. `REJECTED` — ต้องมีเหตุผลที่ตรวจสอบได้และแจ้งช่องทางทบทวน/ร้องเรียนตามกระบวนการที่องค์กรกำหนด

ห้ามมีสถานะ `FULFILLED` อัตโนมัติเมื่อสร้างคำขอ ห้ามแสดงว่าลบแล้วเพียงเพราะลบจากฐานข้อมูลหลัก และห้ามลบหลักฐานที่ต้องเก็บตามกฎหมายโดยไม่ผ่านการทบทวนผู้รับผิดชอบ

## 3. ข้อมูลขั้นต่ำในคำขอ

- `requestId`, `requestType`, `status`, `createdAt`, `updatedAt`
- ผู้ร้องผูกกับ identity ที่ยืนยันจาก server; ไม่เก็บ user ID ที่ผู้ใช้ส่งมาเป็นหลักฐาน
- `scope` เป็นรายการ data stores ที่เกี่ยวข้อง โดยไม่ใส่ prompt, เนื้อหาไฟล์, รหัสผ่าน, token หรือข้อมูลอ่อนไหวใน audit log
- `decisionCode`, `decisionRationale`, `assignedReviewer`, `evidenceReferences`, `retentionReviewAt` เมื่อเกี่ยวข้อง
- บันทึกการเปลี่ยนสถานะและผู้ดำเนินการทุกครั้ง โดยจำกัดสิทธิอ่าน

## 4. API contract เป้าหมาย (ยังไม่เปิดใช้งาน)

- `POST /api/privacy/requests` — รับคำขอจากผู้ใช้ที่ผ่าน authentication; request body ไม่มี `userId` ที่ใช้กำหนดเจ้าของ
- `GET /api/privacy/requests/:requestId` — เจ้าของคำขอหรือเจ้าหน้าที่ที่ได้รับมอบหมายเท่านั้น
- `POST /api/privacy/requests/:requestId/evidence` — เฉพาะผู้ตรวจสอบที่ได้รับสิทธิ; รับเฉพาะ reference ไม่ใช่เนื้อหาข้อมูลดิบ
- `POST /api/privacy/requests/:requestId/decision` — เจ้าหน้าที่ที่ได้รับสิทธิพร้อมเหตุผลและหลักฐาน
- `POST /api/privacy/consent/withdrawal` — ถอนความยินยอมตามวัตถุประสงค์/provider ที่ระบุ และบังคับใช้กับคำขอใหม่ทันทีเมื่อใช้ฐานความยินยอมนั้น; ไม่อ้างว่าย้อนลบข้อมูลที่ส่งให้ vendor ไปแล้วได้โดยอัตโนมัติ

ห้ามติดตั้ง endpoint เหล่านี้ก่อนมี identity, authorization, persistence และ tests ครบ ไม่ควรคืน `200 fulfilled` หากยังไม่ดำเนินการจริง

## 5. Release acceptance tests

- ไม่มี authentication หรือ identity ไม่ถูกต้อง → ปฏิเสธโดยไม่เปิดเผยข้อมูลส่วนบุคคล
- ผู้ใช้ A อ่าน/ส่งออก/เปลี่ยนคำขอของผู้ใช้ B → `403` หรือการตอบสนองแบบไม่เปิดเผยการมีอยู่ของทรัพยากรตามนโยบาย
- `userId` ที่ส่งมาใน body ไม่สามารถเปลี่ยนเจ้าของคำขอได้
- การถอนความยินยอมไม่ถูกใช้เป็น consent สำหรับคำขอถัดไป และไม่ทำให้ Local→Hosted fallback เกิดขึ้น
- คำขอลบต้องมีผลตรวจจากแต่ละ store และรายงานข้อยกเว้น/backup อย่างตรงไปตรงมา
- Audit logs ไม่มี prompt, file content, passwords, bearer tokens หรือ API keys
- การ retry ซ้ำไม่สร้างคำขอซ้ำโดยไม่จำเป็น และการเปลี่ยนสถานะต้อง atomic
- สถานะ `FULFILLED` ต้องอ้างถึงหลักฐานที่ตรวจสอบได้; หากหลักฐานไม่ครบให้คง `IN_PROGRESS` หรือ `PARTIALLY_FULFILLED`

## 6. Current blockers

- Signup/login แบบสมาชิกทั่วไป: `NOT_IMPLEMENTED`
- Server-verified user/workspace ownership: `NOT_VERIFIED`
- Runtime rights-request API: `NOT_IMPLEMENTED`
- End-to-end export/deletion across stores and backups: `NOT_TESTED`
- Legal review: `NOT_CERTIFIED`

**ห้ามเปลี่ยนสถานะเหล่านี้เป็น PASS จากการมีเอกสารนี้เพียงอย่างเดียว**
