# ZYNTHEOR AI ENGINE — PDPA Readiness & Implementation Plan (Thailand)

**สถานะปัจจุบัน: `PARTIAL / NOT_LEGAL_CERTIFICATION`**  
เอกสารนี้เป็นข้อกำหนดทางวิศวกรรมและรายการตรวจสอบ ไม่ใช่คำปรึกษากฎหมาย ไม่ใช่ประกาศความเป็นส่วนตัวฉบับเผยแพร่ และไม่ใช่หลักฐานว่าระบบปฏิบัติตาม PDPA ครบถ้วน ผู้ควบคุมข้อมูลต้องตรวจข้อเท็จจริงของบริการ ผู้ประมวลผลข้อมูล สถานที่ประมวลผล และระยะเวลาเก็บจริงก่อนเผยแพร่ โดยให้ผู้เชี่ยวชาญกฎหมายไทยตรวจทาน

## 1. หลักการที่ห้ามลดทอน

- ห้ามแสดง `PDPA_COMPLIANT`, `CERTIFIED` หรือ `PASS` เพียงเพราะมีหน้า UI หรือเอกสารนี้
- แยกการยินยอมส่ง prompt/files ให้ Online AI ออกจากฐานกฎหมายและวัตถุประสงค์ในการประมวลผลข้อมูลส่วนบุคคลโดยรวม
- ห้ามส่งข้อมูลไปยังผู้ให้บริการออนไลน์จนกว่าผู้ใช้จะเลือกผู้ให้บริการและยืนยันการส่งข้อมูลอย่างชัดแจ้งต่อคำขอนั้น (`explicitUserConsent: true`); ห้าม fallback จาก Local ไป Hosted เอง
- เก็บหลักฐานการตัดสินใจเท่าที่จำเป็น โดยไม่บันทึก prompt, เนื้อหาไฟล์, รหัสผ่าน, token, API key หรือข้อมูลอ่อนไหวลง audit log
- อย่าอ้างว่าการใช้ Local AI ทำให้ไม่มีการประมวลผลข้อมูลส่วนบุคคล: ข้อมูลยังอาจอยู่ใน log, history, backup, browser หรือเครื่องของผู้ใช้
- การกด “ยอมรับทั้งหมด” ไม่ใช่ทางลัดแทนการแจ้งรายละเอียดที่เข้าใจได้ และความยินยอมต้องไม่ถูกบังคับหรือผูกกับสิ่งที่ไม่จำเป็น

## 2. ข้อมูลที่ต้องจัดทำก่อนเปิดใช้จริง

1. **บทบาทและการไหลของข้อมูล** — ระบุผู้ควบคุมข้อมูล, ผู้ประมวลผล, ผู้รับข้อมูล, ผู้ให้บริการ AI, hosting, analytics และผู้รับโอนข้อมูล (ถ้ามี) ตามสัญญาและการใช้งานจริง
2. **บัญชีรายการประมวลผล** — ประเภทข้อมูล, เจ้าของข้อมูล, วัตถุประสงค์, ฐานกฎหมายที่เลือกพร้อมเหตุผล, ผู้รับข้อมูล, ที่เก็บ, ระยะเวลาเก็บ และมาตรการความปลอดภัย
3. **Privacy Notice ภาษาไทย** — ตัวตน/ช่องทางติดต่อผู้ควบคุมข้อมูล, วัตถุประสงค์, ฐานกฎหมาย, ข้อมูลที่จำเป็น/ผลหากไม่ให้, ผู้รับข้อมูล/การโอนต่างประเทศ, ระยะเวลาเก็บหรือเกณฑ์กำหนด, สิทธิและช่องทางร้องขอ
4. **Consent records (เมื่อใช้ฐานความยินยอม)** — บันทึกเวอร์ชันข้อความ, วัตถุประสงค์, เวลา, การกระทำที่ชัดเจน, สถานะถอนความยินยอม และขอบเขต; ห้ามใช้ค่าเริ่มต้นที่ติ๊กไว้
5. **Retention & deletion schedule** — กำหนดแยกสำหรับบัญชี, conversations, uploaded files, generated files, audit/security logs, consent records และ backups; ไม่ตั้งระยะเวลาโดยเดา
6. **สิทธิของเจ้าของข้อมูล** — ช่องทางรับคำขอเข้าถึง/สำเนา/แก้ไข/ลบ/จำกัดหรือคัดค้านตามกรณี/ถอนความยินยอม/ร้องเรียน พร้อมขั้นตอนตรวจตัวตนและบันทึกการจัดการคำขอ
7. **เหตุละเมิดข้อมูล** — กระบวนการตรวจจับ ประเมินความเสี่ยง กักกัน เก็บหลักฐาน แจ้งผู้เกี่ยวข้อง และประเมินหน้าที่แจ้งสำนักงาน/เจ้าของข้อมูลภายในกรอบเวลาที่กฎหมายกำหนด โดยให้ผู้รับผิดชอบตรวจข้อเท็จจริงและกำหนดเวลา
8. **ผู้ประมวลผลและการโอนข้อมูล** — ตรวจ DPA/สัญญา, sub-processors, region, การโอนข้อมูลออกนอกประเทศ และกลไกคุ้มครองที่ใช้จริงก่อนเปิด provider นั้น
9. **DPIA / ข้อมูลอ่อนไหว** — ประเมินความจำเป็นและความเสี่ยงตามลักษณะการประมวลผล; ห้ามให้ผู้ใช้ป้อนข้อมูลส่วนบุคคลอ่อนไหวโดยไม่มีเหตุและมาตรการรองรับที่ผ่านการทบทวน
10. **ผู้รับผิดชอบ** — ประเมินว่าต้องแต่งตั้ง DPO หรือไม่ตามข้อเท็จจริงและเกณฑ์กฎหมาย; ระบุช่องทางติดต่อที่ใช้งานได้จริง

## 3. ข้อกำหนดทางเทคนิคสำหรับระบบนี้

- **Identity / tenant isolation:** ห้ามเชื่อ `userId` หรือ `workspaceId` จาก body เป็นหลักฐานสิทธิ; ผูกทุก read/write/export/delete กับ identity ที่ server ตรวจสอบแล้ว ก่อนเปิดระบบสมาชิกต้องระบุเป็น `NOT_IMPLEMENTED` ไม่ใช่แสดงว่าแยกข้อมูลได้
- **Access control:** least privilege, session/token expiration and revocation, rate limits, admin access logging; ห้ามเก็บ token แบบ plaintext หากมีการเก็บ token
- **Data minimization:** ไม่ส่งไฟล์ทั้งชุดหรือข้อมูลประกอบที่ไม่จำเป็นให้ provider; แสดงชื่อ provider และชนิดข้อมูลที่จะส่งก่อนยืนยัน
- **Encryption & secrets:** TLS สำหรับการรับส่ง, encryption at rest ตาม threat model, secret manager/env configuration ที่ไม่ถูก commit, จำกัดการเข้าถึง backup
- **Logs:** redact secrets และเนื้อหาส่วนบุคคลโดยค่าเริ่มต้น; กำหนด retention และสิทธิอ่าน log; audit log ต้องบันทึกการเข้าถึง/การเปลี่ยนแปลงที่สำคัญโดยไม่ทำสำเนาข้อมูลเกินจำเป็น
- **User controls:** export/delete ต้องตรวจสิทธิฝั่ง server; deletion workflow ต้องระบุข้อยกเว้นตามกฎหมาย, retention ที่ยังจำเป็น, backup expiry และสถานะจริง ห้ามแสดง “ลบแล้ว” จนกว่าจะตรวจยืนยัน
- **Online AI:** แสดง disclosure แยกต่างหากและขอ opt-in รายคำขอ; บันทึกเฉพาะ metadata ที่จำเป็น เช่น provider, timestamp, policy version, consent decision และ request correlation ID โดยไม่บันทึก prompt/files
- **Incident readiness:** มีผู้รับผิดชอบ, ช่องทางแจ้งเหตุ, incident register, tabletop exercise และเก็บหลักฐานที่ตรวจสอบย้อนหลังได้

## 4. สถานะหลักฐานจาก source review ปัจจุบัน

| หัวข้อ | สถานะ | เหตุผล |
|---|---|---|
| Online AI consent gate | `SOURCE_PRESENT / RUNTIME_NOT_VERIFIED` | พบ guard ที่ต้องการ `explicitUserConsent === true`; ต้องทดสอบ HTTP จริงและเส้นทาง provider ทุกแบบ |
| Consent ledger | `REVIEW_REQUIRED` | พบไฟล์ตัวอย่าง route ที่ใช้ PermissionGate แต่ต้องยืนยันว่า route นี้ถูก mount จริง, identity มาจาก server และมี persistence/retention |
| Signup/login | `NOT_IMPLEMENTED` | audit ปัจจุบันไม่พบ route สมัคร/เข้าสู่ระบบแบบสมาชิกทั่วไป |
| Server-verified workspace ownership | `NOT_VERIFIED` | ยังไม่มีหลักฐานตรวจสิทธิครบทุก route |
| Privacy notice / rights request workflow | `NOT_VERIFIED` | ต้องตรวจหน้าใช้งานจริงและ API สำหรับรับ/ติดตามคำขอ |
| Retention/deletion across backups | `NOT_VERIFIED` | ยังไม่มีหลักฐานทดสอบการลบครบทุก storage layer |
| Vendor transfer/DPA review | `NOT_VERIFIED` | ต้องยืนยัน provider, region, subprocessors และสัญญาจริง |
| PDPA legal compliance/certification | `NOT_CERTIFIED` | เอกสารหรือ self-check ไม่ใช่การรับรองทางกฎหมาย |

## 5. Acceptance tests ก่อนเปลี่ยนสถานะ

- Online provider request without consent returns blocked; confirms `fallbackTriggered: false`; no prompt/file reaches hosted provider.
- Consent is scoped to the explicit request/provider/data scope and cannot be replayed by another user or workspace.
- Consent withdrawal is persisted and respected; audit metadata does not contain prompt/file contents or secrets.
- Cross-user and cross-workspace read/write/export/delete attempts are denied at the server.
- Data export contains only the authenticated user's authorized data; deletion workflow reports partial retention honestly and has test evidence for each store and backup policy.
- Retention expiry and deletion are exercised against conversations, uploads, proposals, audit records and backups, with exceptions documented.
- Provider transfer disclosure matches the actual configured vendor and region.
- Incident-response tabletop and access-control review are recorded.
- Thai Privacy Notice and processing bases are reviewed by qualified Thai counsel/privacy lead before production use.

## 6. Release gate

Until evidence for each applicable control is attached to a dated review, the overall result must remain **`PARTIAL / NOT_LEGAL_CERTIFICATION`**. This checklist does not itself establish compliance. Never store real personal data in test fixtures; use clearly labeled synthetic data.

## 7. Operational templates added

- `PDPA_DATA_INVENTORY_TEMPLATE_TH.md` — ทะเบียนกิจกรรม/ข้อมูล/ผู้รับ/ฐานกฎหมาย/retention; ทุกช่องที่ยังไม่มีหลักฐานคง `NOT_COMPLETED` หรือ `NOT_VERIFIED`
- `PDPA_INCIDENT_RUNBOOK_TH.md` — ขั้นตอนตอบสนองเหตุและแบบบันทึก incident; คง `NOT_EXERCISED` จนกว่าจะมีการซ้อมจริง
- `tests/pdpa-readiness-doc.test.mjs` — ตรวจเอกสารและเงื่อนไขจาก source เท่านั้น ไม่ใช่การทดสอบ runtime หรือการรับรองทางกฎหมาย
