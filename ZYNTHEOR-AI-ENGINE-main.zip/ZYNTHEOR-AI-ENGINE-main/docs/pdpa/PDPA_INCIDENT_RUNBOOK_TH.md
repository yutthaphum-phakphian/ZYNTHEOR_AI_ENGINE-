# Runbook รับมือเหตุข้อมูลส่วนบุคคล — ZYNTHEOR AI ENGINE

สถานะ: `PROCEDURE_TEMPLATE / NOT_EXERCISED` — ต้องกำหนดผู้รับผิดชอบและซ้อมก่อนนำไปใช้จริง

## 1. เมื่อสงสัยว่ามีเหตุ

1. เปิด incident ID และบันทึกเวลา ผู้พบเหตุ ระบบที่เกี่ยวข้อง และข้อเท็จจริงที่ยืนยันแล้ว
2. แจ้งผู้รับผิดชอบด้านความปลอดภัยและผู้ควบคุมข้อมูลผ่านช่องทางภายในที่กำหนดไว้จริง
3. จำกัดการเข้าถึงหรือปิดเส้นทางที่ได้รับผลกระทบ หากทำได้โดยไม่ทำลายหลักฐาน
4. เก็บหลักฐานแบบจำกัดสิทธิ์: log ที่ redact แล้ว, request IDs, ช่วงเวลา, deployment/version และ hash ของหลักฐาน
5. ห้ามคัดลอก prompt, ไฟล์ส่วนตัว, password, session token หรือ API keys ลง ticket/chat ทั่วไป

## 2. ประเมินขอบเขต

- ข้อมูล/เจ้าของข้อมูล/จำนวนรายการที่อาจได้รับผลกระทบ (ระบุว่าเป็นค่าประมาณหากยังไม่ยืนยัน)
- การเข้าถึงโดยไม่ได้รับอนุญาต การเปิดเผย การแก้ไข หรือการสูญหาย
- ระบบที่เกี่ยวข้อง: accounts, conversations, uploads, generated files, logs, proposals, backups, processors
- ช่วงเวลาที่เกิดเหตุและเวลาที่ตรวจพบ
- มาตรการกักกันที่ทำแล้ว และผลข้างเคียง
- ข้อมูลที่ยังไม่ทราบให้บันทึก `UNKNOWN` ห้ามเติมจากการคาดเดา

## 3. การตัดสินใจแจ้งเหตุ

ผู้ควบคุมข้อมูลและที่ปรึกษากฎหมาย/ผู้เชี่ยวชาญความเป็นส่วนตัวต้องประเมินข้อเท็จจริง ความเสี่ยง และหน้าที่แจ้งหน่วยงาน/เจ้าของข้อมูลตามกฎหมายและกรอบเวลาที่ใช้บังคับจริง รวมทั้งบันทึกเหตุผลหากเห็นว่าไม่ต้องแจ้ง ห้าม hard-code ข้อสรุปทางกฎหมายโดยไม่มีการทบทวน

## 4. ปิดเหตุและติดตาม

- ตรวจว่าการกักกันได้ผลจากหลักฐานทางเทคนิค ไม่ใช่แค่เปลี่ยนป้ายสถานะ
- บันทึก root cause, affected versions, corrective actions, owner และ due date
- ตรวจว่าข้อมูลถูกลบ/กู้คืน/จำกัดสิทธิจริงตามแต่กรณี และระบุสิ่งที่ยังค้าง
- ทบทวนสัญญา processor และแจ้งผู้เกี่ยวข้องตามหน้าที่
- จัด tabletop exercise และเก็บผล; จนกว่าจะซ้อม ให้คงสถานะ `NOT_EXERCISED`

## 5. Incident record template

| Field | Value |
|---|---|
| Incident ID / opened at | `NOT_COMPLETED` |
| Reporter / incident owner | `NOT_COMPLETED` |
| Systems / processors | `UNKNOWN` |
| Data categories / affected persons | `UNKNOWN` |
| Confirmed facts vs estimates | `NOT_COMPLETED` |
| Containment and evidence references | `NOT_COMPLETED` |
| Legal/privacy review and notification decision | `NOT_COMPLETED` |
| Corrective actions / owners / dates | `NOT_COMPLETED` |
| Closure evidence / tabletop date | `NOT_COMPLETED` |
