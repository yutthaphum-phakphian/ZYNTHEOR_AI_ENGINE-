# External Tools (real adapters)

## Connectors (ConnectorHub)

| ID | Status | Actions | Notes |
|----|--------|---------|-------|
| `web_research` | **AVAILABLE** | `fetch_page`, `search` | Search via DuckDuckGo HTML (no API key). Private hosts blocked. |
| `github` | **AVAILABLE** | `get_repo`, `list_issues`, `get_file`, `get_readme` | Public API. Optional `GITHUB_TOKEN` for higher rate limits / private. |
| `file_store` | NOT_INSTALLED | — | Placeholder |
| `external_api` | NOT_INSTALLED | — | Placeholder |

## Agent tools (plan steps)

| Tool | Maps to | Permission |
|------|---------|------------|
| `web_fetch` | `web_research.fetch_page` | `read:web` |
| `web_search` | `web_research.search` | `read:web` |
| `github_get_repo` | `github.get_repo` | `read:github` |
| `github_list_issues` | `github.list_issues` | `read:github` |
| `github_get_file` | `github.get_file` | `read:github` |
| `github_get_readme` | `github.get_readme` | `read:github` |

All are on the SAFE_TOOLS allowlist (read-only).

## Auto-planning

`planTask()` inspects the goal text and may append:

- `web_search` when the user asks to search/research the web
- `web_fetch` when a concrete `http(s)://` URL is present
- `github_*` when a GitHub repo is mentioned

## Files added/changed

- `server/connectors/webResearch.ts` — real fetch + DuckDuckGo search
- `server/connectors/github.ts` — real GitHub read API
- `server/engineRoutes.ts` — registers adapters + tools
- `server/agent.ts` — `registerWebFetchTool`, `registerWebSearchTool`, `registerGitHubTools`; widened `ToolResult`
- `server/reasoning.ts` — SAFE_TOOLS expanded; classify + planTask auto-suggest
- `tests/connectors/web-research.test.ts`
- `tests/connectors/github.test.ts`
- `tests/learning-and-routes.test.ts` — expects AVAILABLE

## Quick check (Node.js)

```bash
# after pnpm install
pnpm test:connector
# or
npx tsx --test tests/connectors/**/*.test.ts
```
