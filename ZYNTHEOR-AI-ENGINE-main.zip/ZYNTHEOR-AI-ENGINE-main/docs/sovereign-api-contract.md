# Sovereign API Contract

**Status: NOT VERIFIED.** No OpenAPI document, SDK interface, or live Sovereign API was available when this
connector was written, so **no endpoint is defined anywhere in this repository**. Nothing here claims that a
connection to ZYRQUEN Ω∞ Sovereign works.

## Rule

The connector (`src/connectors/sovereign/`) calls Sovereign only through operations declared in a contract file that:

1. comes from a verified source (`openapi`, `sdk`, or `live-probe`),
2. carries a real ISO `verifiedAt`, and
3. passes `validateContract()` (https base URL — http only for loopback; absolute paths; no `..`; no embedded credentials).

If the contract is missing or invalid the client returns `UNAVAILABLE` (`NO_CONTRACT` / `CONTRACT_INVALID`) and makes **no network call**.

## How to supply a contract

1. Obtain the real API description from the Sovereign owner.
2. Copy `docs/sovereign-api-contract.template.json`, fill every `REPLACE` value from that description, set `verifiedAt`.
3. Set `SOVEREIGN_CONTRACT_PATH`, `SOVEREIGN_API_TOKEN` (see `.env.example`).
4. Run `npm run test:connector`, then a real probe against a test tenant before any production use.

## Status semantics

| Status | Meaning | Retried |
|---|---|---|
| `SUCCESS` | 2xx **and** response contains every `responseRequired` field | – |
| `FAILED` | Unknown operation, bad request, 4xx/500, non-JSON, or contract-violating response | never |
| `TIMEOUT` | No response within `SOVEREIGN_TIMEOUT_MS` (or HTTP 408/504) | idempotent ops only |
| `DENIED` | HTTP 401/403 | never |
| `UNAVAILABLE` | No/invalid contract, no credentials, network error, HTTP 429/502/503 | idempotent ops only (network/429/502/503) |

Every result carries `origin`: `REAL` (real HTTP) or `MOCK` (injected test transport). MOCK results are prefixed
`[MOCK — not from Sovereign]` and are recorded as `MOCK` in the audit log.

## Audit evidence

One hash-chained record per call (`seq`, `correlationId`, `operation`, `origin`, `status`, `reason`, `httpStatus`,
`attempts`, `durationMs`, `contractVersion`, `prevHash`, `hash`). No request/response bodies and no credentials are stored.
`SovereignAuditLog.verifyChain()` detects edited, removed or reordered records.

## Out of scope (must never be copied here)

Sovereign Core, Kernel, HSM, Treasury, Forensic Pipeline. The isolation test fails if the connector imports anything
outside itself or if any `server/*.ts` file imports the connector.
