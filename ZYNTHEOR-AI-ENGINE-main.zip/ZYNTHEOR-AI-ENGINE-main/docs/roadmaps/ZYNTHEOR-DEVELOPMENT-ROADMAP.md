# ZYNTHEOR AI ENGINE — Development Roadmap & Milestones

**สถานะเอกสาร:** แผนเสนอสำหรับการพัฒนาต่อเนื่อง  
**หลักการ:** ปิด blocker และยืนยันการอัปเดตที่ใช้งานได้จริงก่อนขยาย Core; พัฒนาใน ZYNTHEOR เท่านั้น; ไม่แก้ไขหรือรวมโค้ดเข้ากับ ZYRQUEN  
**กรอบเวลาอ้างอิง:** ประมาณ 12–16 สัปดาห์สำหรับทีมขนาดเล็ก 2–3 คนที่ทำงานต่อเนื่อง ระยะเวลาเป็นค่าประมาณและให้ปรับตามผล audit, provider/runtime ที่เข้าถึงได้ และทรัพยากรจริง

## 1. เป้าหมายและผลลัพธ์ปลายทาง

พัฒนา ZYNTHEOR จาก prototype ให้เป็น AI engine ที่มีวงจรการทำงานตรวจสอบได้ ตั้งแต่รับคำขอ → วิเคราะห์/วางแผน → เรียกเครื่องมือที่อนุญาต → ตรวจหลักฐาน → สรุปผลอย่างตรงไปตรงมา และเรียนรู้จากผลที่ยืนยันได้ โดยรองรับการเลือกใช้งาน local runtime หรือ online provider อย่างชัดเจน

ความสำเร็จไม่ได้วัดจากจำนวนหน้าจอหรือจำนวนบรรทัดโค้ด แต่ต้องแสดงหลักฐานว่า:

1. คำขอถูกจำแนกและเลือกแนวทางทำงานเหมาะสม ไม่มีการแอบสลับ provider/runtime
2. การเรียกเครื่องมือเป็นไปตาม schema, permission และ approval ที่ผูกกับแผนเวอร์ชัน/hash จริง
3. Memory แยกขอบเขตข้อมูล ลดความเสี่ยงจากข้อมูลผิด/ข้อมูลข้าม workspace และใช้เฉพาะความรู้ที่ผ่าน validation
4. ข้อเสนอ self-development ถูกทดสอบใน sandbox, เปรียบเทียบกับ baseline และไม่แก้ source หลักโดยไม่มีการอนุมัติ
5. คุณภาพ ภาษาไทย ความถูกต้อง การใช้ tools ความปลอดภัย และความเสถียรดีขึ้นตาม benchmark ที่กำหนดไว้ก่อนทดลอง

## 2. สถานะตั้งต้นและสิ่งที่มีอยู่แล้ว

อ้างอิง `docs/ARCHITECTURE.md`, `docs/phases/PHASE-22-DELIVERABLE.md`, `docs/RESTART-AND-VERIFICATION.md` และโค้ดปัจจุบัน:

- มี plan lifecycle แบบ PROPOSED → approval → run, plan revision/hash, allowlisted tool registry และ verifier ที่ต้องยึด persisted evidence
- มี deterministic intent gate, FAST/DEEP routing, workspace-scoped verified memory และ verified-lesson loop ซึ่งบทเรียนเริ่มต้นเป็น candidate และต้องยืนยันจากหลาย run ก่อนใช้
- มี self-improvement workflow ที่คัดลอก workspace ไปยังพื้นที่ทดลอง, รันชุดตรวจจำกัด, สร้าง hash-bound proposal และต้องอนุมัติแยกก่อน apply
- มี frontend chat/runtime performance history และการเลือก local/online provider บางส่วน แต่ตัวชี้วัด UI ไม่ใช่หลักฐานของ inference จริงโดยลำพัง
- สถาปัตยกรรมยังระบุว่า package runtime `server.ts` เป็น localhost prototype; ไม่มี authentication, multi-user identity/RBAC, durable transactional storage, cross-process lock, rate limiting หรือ deployment hardening
- `server/index.ts` กับ package runtime เป็น API entry point คนละชุดและมี capability/auth ต่างกัน จึงต้องยืนยัน runtime ที่เป็น authoritative ก่อนเปิดใช้งานหรือเผยแพร่
- Memory ใช้ workspace ID สำหรับ scope แต่ ID ดังกล่าวยังไม่ใช่ authorization boundary; ledger ปัจจุบันยังไม่มี tamper-evident chain
- Self-improvement proposal ยังอยู่ใน memory และหมดอายุได้; การทำงาน end-to-end ยังต้องยืนยันด้วย provider ที่ตั้งค่าจริง การยินยอมส่ง source อย่างชัดแจ้ง และหลักฐานการทดสอบ
- สถานะ release readiness ที่เก็บใน JSON เป็น snapshot เก่า (2026-10-15) และไม่ใช่ผลตรวจปัจจุบัน ต้องรัน release gate ใหม่ก่อนใช้ตัดสินใจ

## 3. ลำดับระยะและ Milestones

### Phase 0 — ปิด blocker และยืนยันฐานการทำงาน

**ประมาณการ:** 1–2 สัปดาห์  
**เป้าหมาย:** ทำให้สถานะ repository, runtime, test suite และ release gate เชื่อถือได้ ก่อนเพิ่ม feature ที่กระทบ Core

**งานหลัก**

- สร้าง inventory ของ package scripts, tests, routes, runtime entry points, adapters, feature flags และเอกสาร phase; ทำ baseline จาก clean install/lockfile
- รัน `node scripts/release-readiness.mjs`, `npm run typecheck`, `npm run build`, `npm run test:unit`, `npm run test:integration` และบันทึกผลจริงแยก PASS/FAIL/NOT_VERIFIED
- จัดกลุ่ม test failures เป็น regression, environment/setup, flaky หรือ test/source mismatch; ทุก failure ต้องมี owner, reproduction steps และ issue
- ทบทวน API contract ระหว่าง `server.ts` กับ `server/index.ts`; กำหนด runtime/API ที่เป็น source of truth และจัดทำ migration plan โดยไม่ลบ compatibility ก่อนมี tests
- ยืนยันว่า setup ใน CI ใช้ Node/package manager/lockfile เดียวกับ release และผลทดสอบไม่พึ่ง fixture ที่ปลอมเป็น provider/runtime จริง
- ตรวจว่าขอบเขต ZYNTHEOR ไม่แก้ `ZYRQUEN-1.2-LTS` หรือ repository/โฟลเดอร์ของ ZYRQUEN

**Milestone M0 — Verified Baseline**

- มี baseline report ที่ระบุ commit/source snapshot, runtime entry point, command, exit code, test counts, known failures และวันเวลารัน
- Typecheck/build ผ่าน หรือ blocker ทุกข้อถูกจัดลำดับและมีเหตุผลที่พิสูจน์ซ้ำได้
- มีรายการ test ที่แยก real integration ออกจาก mock/fixture อย่างชัดเจน
- ไม่มีการกล่าวว่า release-ready หาก runtime inference จริงยังไม่ผ่าน

**Gate:** ยังไม่เริ่มทดลอง self-modification กับ Core จน M0 มี baseline ที่ทำซ้ำได้

### Phase 1 — ยืนยันการอัปเดตจริงและกำหนด trust boundary

**ประมาณการ:** 1–2 สัปดาห์  
**เป้าหมาย:** ส่งมอบการอัปเดตใน environment เป้าหมายอย่างตรวจสอบย้อนกลับได้ และกำหนดเส้นแบ่งความปลอดภัยให้ชัด

**งานหลัก**

- กำหนดเจ้าของและ environment ของ deployment/test; ระบุวิธีส่งมอบ, rollback, health check และวิธีพิสูจน์เวอร์ชันที่รัน
- สร้าง release manifest ที่มี source hash/build ID/dependency lock hash และ endpoint/version ที่ตอบกลับจาก runtime
- ทดลอง deploy/update ใน environment ที่ได้รับอนุญาตก่อน; ตรวจ health, API contract, local model endpoint, provider selection และ behavior เมื่อ dependency unavailable
- แก้ความเสี่ยงก่อนใช้งานนอก localhost: authentication/authorization, CORS/CSRF policy ตาม deployment, rate limit, secrets handling, network exposure, SSRF/DNS policy, audit และ backup/restore
- ตัดสินใจ architecture ว่าจะรวม API entry points หรือรักษาแยก พร้อม migration tests ป้องกัน route behavior ต่างกัน
- ระบุข้อมูลที่ส่งออกไป external provider ชัดเจน; ปิด external code sharing เป็นค่าเริ่มต้นและแสดง consent ต่อ run

**Milestone M1 — Update Proven**

- ผู้ตรวจสอบอิสระยืนยัน runtime ที่รันมี build ID/source hash ตรงกับ package ที่ส่งมอบ
- health/API tests ผ่าน และ runtime แสดงสถานะ UNAVAILABLE เมื่อ local model/provider ไม่พร้อม แทนการสร้างผลปลอม/สลับบริการเงียบ ๆ
- มี rollback procedure และบันทึกผลการทดลอง deploy
- ก่อน public exposure ต้องมี security review ผ่าน; หากยังเป็น prototype ให้จำกัด localhost และระบุข้อห้าม deployment อย่างชัดเจน

**Gate:** ห้ามเริ่ม rollout สาธารณะหากยังไม่มี identity/auth, threat model และ security sign-off

### Phase 2 — Reasoning Core และ orchestration ที่คุมได้

**ประมาณการ:** 2–3 สัปดาห์  
**เป้าหมาย:** ทำให้ Core คิดเป็น workflow ที่ตรวจสอบได้ โดยต่อยอด plan/intent/tool infrastructure ที่มี ไม่เปิดช่องให้ model เรียกเครื่องมือโดยตรง

**งานหลัก**

- กำหนด schema กลางของ `TaskRequest`, `PlanProposal`, `ToolCall`, `Evidence`, `VerificationResult` และ `FinalReport` พร้อม versioning
- ระบุ state machine ที่ชัดเจน: classify → plan → validate → propose → approval → execute → verify → report; failure state ต้องแยก FAILED/BLOCKED/UNAVAILABLE/UNKNOWN
- คงโมเดลเป็น planner/proposer เท่านั้น: JSON proposal ต้องผ่าน schema, allowlist, permission, dependency graph, risk และ success-criteria validation ก่อนบันทึก
- ผูก approval กับ hash ของ goal/risk/tools/criteria/step inputs และ revision; เปลี่ยนแผนแล้ว invalidate approval เดิม; token/approval ใช้ครั้งเดียวและมี expiry
- ทำ tool registry ให้มี availability จริง, timeout, cancellation, bounded output, idempotency semantics และ verifier contract; ห้าม arbitrary shell/URL โดยไม่มี design review และ capability gate
- แยก planning context ออกจาก tool execution; tool output เป็น untrusted data, ไม่ใช่ instruction; ป้องกัน prompt injection จากเว็บ/ไฟล์/ผล connector
- เพิ่ม structured trace ด้วย correlation ID ครอบคลุม planner, router, connector, verifier และ final response โดย redact secret ก่อน persist
- ทำ UX ให้แสดงสิ่งที่กำลังจะทำ, permission, data-sharing, evidence, จุดที่ต้องอนุมัติ และสิ่งที่ไม่ได้ทำ

**Milestone M2 — Controlled Reasoning Loop**

- Test ครอบคลุม plan valid/invalid, unknown tool, schema mismatch, dependency cycle, stale hash, reused/expired approval, permission denied, tool timeout, missing evidence และ verifier failure
- ไม่มีเส้นทางที่โมเดลข้าม approval หรือเรียก tool โดยตรง
- `SUCCESS` เกิดได้เมื่อ verifier ตรวจ persisted evidence ตามเงื่อนไขทุก step เท่านั้น; status `UNKNOWN` ไม่ถูกเปลี่ยนเป็น success โดย fallback
- Scenario ภาษาไทยและภาษาอังกฤษผ่าน end-to-end ด้วย provider/runtime ที่ระบุชื่อและเก็บหลักฐานได้

### Phase 3 — Memory & Knowledge ที่มี provenance และการควบคุมข้อมูล

**ประมาณการ:** 2–3 สัปดาห์ (ทำคู่ขนานได้หลัง M1 บางส่วน)  
**เป้าหมาย:** จัดเก็บความรู้ที่ค้นกลับมาใช้ได้ แต่ไม่ปะปนผู้ใช้/workspace และไม่ยกระดับคำตอบที่ยังไม่ผ่านการตรวจเป็นข้อเท็จจริง

**งานหลัก**

- ออกแบบ memory entity: workspace/user/tenant scope, fact, source/evidence refs, confidence/verification state, created/updated/expiry, provenance, supersedes/contradicts links
- สร้าง identity boundary ก่อนเปิด multi-user; workspace ID จาก client ห้ามใช้แทน authorization; ตรวจ owner/ACL ฝั่ง server ทุก read/write
- แยก verified facts, candidate lessons, transient session context และ user preferences; ระบุ retention, deletion/export และการลบตามคำขอ
- สร้าง retrieval แบบ scoped, relevance-ranked, stale-aware และ bounded; แนบ provenance ให้ model เป็น reference data ไม่ใช่ system instruction
- กำหนดการ capture: บันทึกเฉพาะผลที่มี evidence; candidate lesson ต้องได้รับการยืนยันจากอย่างน้อย 2 distinct runs ตามหลักฐานที่ไม่ซ้ำ; มี conflict/rejection/stale lifecycle
- เพิ่ม migrations, backup/restore, transaction semantics, locking และ corruption recovery policy หากเปลี่ยนจาก JSONL/file store ไปฐานข้อมูล
- ป้องกัน data exfiltration จาก memory ไป external provider ด้วย consent policy, secret redaction และ per-provider controls

**Milestone M3 — Scoped Verified Memory**

- Tests พิสูจน์ว่า workspace/user A อ่านข้อมูลของ B ไม่ได้ แม้เดา ID ได้
- Retrieval ไม่คืน candidate/unverified/stale facts เป็นข้อเท็จจริง; มี source/evidence และขอบเขตใน trace
- ลบข้อมูลแล้วไม่หลงเหลือใน index/cache/backup เกิน policy ที่ประกาศ
- Conflict test สร้างสถานะ unresolved/rejected แทนการเลือกข้อเท็จจริงตามความถี่อย่างเงียบ ๆ

### Phase 4 — Self-Development Engine แบบทดลอง ปลอดภัย และอนุมัติก่อนใช้

**ประมาณการ:** 2–3 สัปดาห์ หลัง M0, M1 และ M2  
**เป้าหมาย:** ให้ระบบวิเคราะห์ปัญหา สร้าง candidate patch ในพื้นที่แยก ทดสอบเทียบ baseline และเสนอผู้ใช้อนุมัติ โดยไม่แก้ engine/Core อัตโนมัติ

**งานหลัก**

- กำหนด allowed targets/forbidden paths, patch size limit, file type, symlink/path traversal protection, dependency policy และ untrusted patch review
- ทำ sandbox isolation ให้ fail closed: read-only source baseline, writable temporary copy/cache แยก, network namespace off, resource/time limits, stripped credentials, process cleanup และ no host writes
- ป้องกัน test tampering: candidate patch แก้ tests/manifests/security policy/Core/Kernel ไม่ได้; test suite ที่ใช้ประเมินต้องเชื่อถือจาก baseline ที่ pin ไว้
- ใช้ pipeline: baseline reproduce → issue diagnosis → candidate patch → static checks → unit/integration/security/build → differential comparison → evidence bundle → proposal/hash → human approval → apply/rollback
- Patch generation ที่ส่ง source ออก provider ต้อง require per-run explicit consent; ระบุไฟล์/เนื้อหาที่ส่งและรองรับ analysis-only เมื่อไม่อนุญาต
- จัดเก็บ proposal/evidence/checkpoints แบบ durable, access-controlled และ audit; ไม่พึ่ง in-memory proposal หากต้องคงสถานะข้าม restart
- เพิ่ม rollback/recovery: เก็บ preimage, postimage hash, apply journal; verify หลัง apply และ rollback เมื่อไม่ผ่าน
- แยก “self-improvement ของ workspace” ออกจาก “การแก้โค้ด engine ตัวเอง”; การแตะ Core ต้องเป็นโครงการ/approval/security review แยก

**Milestone M4 — Safe Patch Proposal**

- ทดสอบ sandbox isolation และยืนยันว่าไม่เขียนนอกพื้นที่ทดลอง/ไม่ออก network/ไม่เห็น provider secrets
- Candidate ที่แก้ไฟล์ต้องห้ามหรือ test จะถูกปฏิเสธก่อน run; patch ที่ผ่านจะมี baseline/candidate logs, hashes และผลเทียบ
- ไม่มี auto-apply; approval ต้องผูกกับ exact diff/hash และหมดอายุ/ใช้ซ้ำไม่ได้
- ทดสอบ rollback และ recovery เมื่อ apply ถูกขัดจังหวะ
- Demo end-to-end ต้องใช้ configured provider จริงหรือระบุ `UNAVAILABLE`; ห้ามรายงาน success จาก mock เท่านั้น

### Phase 5 — Evaluation, Benchmark และหลักฐานการดีขึ้น

**ประมาณการ:** 2–3 สัปดาห์เพื่อเริ่มต้น จากนั้นเป็นงานต่อเนื่อง  
**เป้าหมาย:** วัดว่าความสามารถดีขึ้นจริง ไม่ใช่อนุมานจากการเพิ่ม code/tools หรือคะแนนที่โมเดลให้ตัวเอง

**งานหลัก**

- สร้าง versioned benchmark set ที่แยก hidden holdout ออกจากชุดพัฒนา และมี rubric/expected evidence ระบุล่วงหน้า
- ครอบคลุมอย่างน้อย: Thai/English comprehension, multi-step reasoning, code generation/test repair, tool selection/schema correctness, citation/research faithfulness, memory scoping, uncertainty calibration, refusal/safety, prompt injection, privacy leakage
- มีทั้ง deterministic unit tests, scenario integration tests กับ local runtime, provider tests, adversarial/security tests และ human-rated sample; fixtures แยกชัดจาก real inference
- กำหนด metric: task success with verifier evidence, unsafe action rate (เป้าหมาย 0 ในชุด acceptance), hallucinated success rate, tool/schema error rate, grounded citation rate, Thai rubric score, regression count, latency P50/P95, tokens/s และ availability
- ทำ paired A/B evaluation candidate vs baseline ด้วย dataset/seed/config เดียวกัน; ห้าม candidate pass จากค่าเฉลี่ยหาก safety metric แย่ลง
- บันทึก model/runtime/provider version, prompt/policy version, dataset hash, run seed, test output และ evaluator version
- กำหนด minimum sample size และเกณฑ์ยอมรับก่อนรัน; ผลไม่พอให้ระบุ INCONCLUSIVE ไม่ใช่ PASS

**Milestone M5 — Evidence-Based Improvement Gate**

- Benchmark reproducible จากคำสั่งเดียวและสร้าง report ที่ trace กลับไปยัง artifacts ได้
- การเปลี่ยนแปลงต้องไม่ลด safety/faithfulness gate; ผล quality ต้องดีขึ้นเกิน threshold ที่กำหนดไว้ล่วงหน้า หรือระบุ inconclusive
- ไม่มีการใช้ LLM judge เป็นผู้ตัดสินเพียงอย่างเดียว; ต้องมี deterministic checks/human review ใน metric ที่สำคัญ
- Release report แยก improvement ใน target task ออกจาก regression/uncertainty และแสดง confidence/จำนวนตัวอย่าง

### Phase 6 — Continuous operation, release และการปรับปรุงเป็นวงรอบ

**ประมาณการ:** เริ่มหลัง M5; ดำเนินการต่อเนื่อง  
**เป้าหมาย:** ทำให้วงจรตรวจจับ → เสนอ → ทดสอบ → review → approve → deploy → observe → rollback ใช้ซ้ำได้โดยมีคนรับผิดชอบ

**งานหลัก**

- กำหนด release train, owner, code review, security review, signing/provenance และ staged rollout
- ติดตาม inference latency/throughput/error/availability, safety events, tool outcomes, memory retrieval quality และ rollback signals จาก event จริง; หลีกเลี่ยง metric ที่ตกแต่งหรือคำนวณจากข้อมูลปลอม
- ตั้ง error budget/alert threshold และ stop condition; เมื่อพบ safety regression ให้หยุด rollout โดยอัตโนมัติแต่ไม่รัน side effects ซ้ำโดยไม่มี approval
- ใช้ Triggers/Schedule เฉพาะงาน monitor/read-only ที่กำหนดชัด; automation ที่ mutate system ต้องใช้ approval และ idempotency
- ทำ backup/restore drill, incident response, key rotation, data retention review และ periodic access review
- ทบทวน benchmark, threat model, tool allowlist และ privacy policy ตามการเปลี่ยนแปลง connector/model/runtime

**Milestone M6 — Controlled Continuous Improvement**

- มี release evidence pack, staged rollout/rollback, monitoring dashboard และผู้รับผิดชอบ incident
- ทุก change ที่สร้างโดย self-development ผ่านการ review และ approval ตาม policy
- มีการทดสอบ restore/rollback จริงและบันทึก RTO/RPO ที่ทำได้
- ไม่มีการเปลี่ยนแปลง ZYRQUEN และแสดง boundary check ใน release checklist

## 4. Dependencies และ Critical Path

1. **M0 → M1:** ต้องรู้ baseline และ authoritative runtime ก่อนพิสูจน์ update
2. **M1 security boundary → M2 external/runtime integrations:** ไม่เปิด public integration ก่อน identity/authorization/security review
3. **M2 schemas/verification → M3 memory retrieval:** memory ต้องเชื่อม evidence และ owner scope ก่อนส่งเข้า reasoning context
4. **M0 + M2 → M4 self-development:** sandbox tests ต้องเชื่อถือได้ และ proposal/approval flow ต้องไม่ bypass
5. **M0 → M5 benchmark baseline; M2/M3/M4 → M5:** benchmark ใช้วัดระบบจริงและการเปลี่ยนแปลงทุก phase
6. **M4 + M5 + M1 → M6 rollout:** ห้าม continuous rollout หาก patch safety, improvement gate หรือ deployment proof ยังไม่พร้อม

งานที่ทำคู่ขนานได้หลัง Phase 0: ออกแบบ benchmark taxonomy, threat model, data classification, UI/observability specification และ acceptance scenarios; แต่ไม่ควรเริ่ม apply code change หรือเพิ่มสิทธิ์ tools จน gate ที่เกี่ยวข้องผ่าน

## 5. Definition of Done สำหรับทุก Milestone

ทุก milestone ต้องมี:

- ขอบเขต/assumptions/known limits และ acceptance criteria ที่เขียนก่อน implement
- implementation และ tests ใน repository ZYNTHEOR พร้อม test category ที่แยก unit/mock/integration/real provider
- command, environment, exact result counts, artifacts/logs และ hash ที่ทำซ้ำได้
- negative tests สำหรับ unavailable, permission denied, timeout, malformed data, stale state และ recovery
- security/privacy review ตามระดับความเสี่ยง; redaction ของ token/credentials ใน logs/report
- ผู้ตรวจสอบที่ไม่ใช่ผู้เขียนหลักสำหรับ M1, M4, M5 และ release gate
- เอกสาร rollback และการระบุสิ่งที่ยังไม่ได้พิสูจน์; ห้ามใช้คำว่า “เรียนรู้สำเร็จ/ฉลาดขึ้น” หาก benchmark ไม่แสดงผล

## 6. ความเสี่ยงและมาตรการควบคุม

| ความเสี่ยง | ผลกระทบ | มาตรการ/เกณฑ์หยุด |
|---|---|---|
| Runtime entry points ทำงานไม่เหมือนกัน | patch/test ผ่านชุดหนึ่งแต่ production ใช้อีกชุด | M0 inventory และ M1 contract parity; หยุด rollout จนเลือก authoritative runtime |
| Workspace ID ถูกเข้าใจผิดว่าเป็น authorization | ข้อมูล memory ข้ามผู้ใช้/ข้าม workspace | identity/ACL ฝั่ง server และ cross-tenant tests ก่อน multi-user |
| Prompt injection ผ่าน web/tool/memory | tool misuse หรือ disclosure | แยก instruction/data, validate allowlist, approval และ adversarial tests |
| Self-patch เปลี่ยน test เพื่อให้ตัวเองผ่าน | ประเมินผลปลอม | pin tests/policy, ป้องกัน test/manifest path และทำ candidate diff review |
| Baseline ไม่ผ่าน/ไม่คงที่ | เทียบแล้วสรุป improvement ไม่ได้ | quarantine flaky tests, reproduce baseline, ระบุ INCONCLUSIVE แทน PASS |
| Provider sharing ส่ง source/secret ออก | privacy/security incident | deny-by-default, redact, preview exact scope, per-run consent และ audit |
| Latency/TPS/UI metric เป็นค่าประมาณ | ตัดสินใจผิดเรื่อง runtime/model | label source, record measured vs estimated, real inference test แยก |
| Persistent store/ledger เสียหายหรือ concurrent write | สูญเสีย state/approval ซ้ำ | transactional store/locking, backup, corruption tests, idempotent operation |
| ขอบเขต ZYRQUEN ปะปนกับงาน | ความเสี่ยงต่อระบบแยก | repo/path ownership checks, explicit exclusion ใน CI/release approval |

## 7. Release decision rubric

- **BLOCKED:** มี test/security failure, evidence ขาด, approval/hash mismatch, หรือ cross-workspace access ที่ไม่ปลอดภัย
- **NOT_VERIFIED:** ยังไม่ได้รัน real inference/deployment/provider test, จำนวนตัวอย่างไม่พอ หรือไม่มี independent review
- **STRUCTURE_ONLY_PASS:** build/structural tests ผ่าน แต่ real runtime หรือ integration ยังไม่พิสูจน์
- **READY_FOR_LIMITED_ROLLOUT:** gates M0–M5 ผ่าน, security sign-off ผ่าน, real runtime verified, rollback tested; จำกัด audience/traffic และเฝ้าดู
- **READY_FOR_GENERAL_RELEASE:** ผ่าน limited rollout โดยไม่มี safety/availability regression เกิน threshold, monitoring/incident response พร้อม และมีการอนุมัติ release อย่างเป็นทางการ

> ไม่ควรประกาศ “production-ready” จาก typecheck/build หรือ mock suite เพียงอย่างเดียว

## 8. สรุปลำดับที่แนะนำ

**ปิด blocker ของชุด 1 และทำ baseline ให้ทำซ้ำได้ → ส่งและพิสูจน์ update จริง → ยืนยัน trust boundary/runtime → พัฒนา Reasoning Core โดยต่อยอด orchestration ที่มี → ทำ Memory ให้ scoped และมี provenance → ขยาย self-development ใน sandbox โดย approval-only → วัดผลด้วย benchmark ก่อน/หลัง → rollout แบบจำกัดและปรับปรุงต่อเนื่อง**

การพัฒนาและ deployment ทั้งหมดในแผนนี้จำกัดอยู่ใน **ZYNTHEOR**; **ZYRQUEN-1.2-LTS ไม่อยู่ในขอบเขตและห้ามแก้ไข**.
