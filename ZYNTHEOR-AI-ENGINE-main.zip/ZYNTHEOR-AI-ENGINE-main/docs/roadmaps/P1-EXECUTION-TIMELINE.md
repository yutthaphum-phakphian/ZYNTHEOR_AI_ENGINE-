# Zyntheor P1 Execution Timeline & Deliverables Roadmap

Phase P1 ต่อยอดจากสนามทดสอบ (Training/Evaluation Pipeline ใน Phase P0) ไปสู่การสร้าง **Foundation Model & Intelligence Layer** ที่ใช้งานจริง พร้อมการควบคุมเชิงประจักษ์ (Evidence-Backed Control) 

---

## 🗓️ Weekly Execution Timeline

| สัปดาห์ | Milestone | กิจกรรมหลัก | ผลงานส่งมอบ (Deliverables) | เกณฑ์การผ่าน (Gate Criteria) |
|---|---|---|---|---|
| **Week 1** | **Milestone 1 — Model Integration** | • เชื่อม Training Runner เข้ากับ Local GGUF / Safe Runtime Model weights<br>• กำหนด Format Checkpoint (.gguf / safetensors)<br>• บันทึก Config & Run Metadata อัตโนมัติ | • `features/model-integration/adapter.ts`<br>• `training/weights-manifest.json`<br>• Automated weight checksum verification | Checksum ตรงกับ manifest 100% และโหลดเข้า memory สำเร็จ |
| **Week 2** | **Milestone 2 — Advanced Evaluation** | • เพิ่มชุดทดสอบ Multi-Turn Reasoning (บทสนทนาต่อเนื่อง)<br>• เพิ่ม Benchmark Plan Generation & Execution<br>• เพิ่ม Fixtures ด้าน Autonomous Tool Use & Permission Boundary | • `evaluation/fixtures/multi_turn.json`<br>• `evaluation/fixtures/tool_use.json`<br>• `evaluation/evaluator-advanced.ts`<br>• Advanced Rubric v1.1 | Composite Score >= 85.0% ใน multi-turn และ zero-violation ใน tool gates |
| **Week 3** | **Milestone 3 — Feature Expansion** | • พัฒนา Agent Orchestration ใน `features/`<br>• ขยาย Copilot Plan Execution กับ Workspace Memory<br>• ผูก Learning Loop กับ Context Fact Ledger | • `features/orchestration/agentCoordinator.ts`<br>• `features/copilot/plans/advancedPlanner.ts`<br>• Unit & Integration Tests ครอบคลุม | Test coverage >= 90% ใน features ใหม่ โดยไม่กระทบ `server/reasoning.ts` |
| **Week 4** | **Milestone 4 — Deployment Readiness** | • เตรียม Docker GPU profile (`docker-compose.gpu.yml`)<br>• ตรวจสอบ Memory Swapping & Local AI Keep-Alive<br>• ทดสอบ Reproducibility บน Linux/Containerized environment | • `scripts/benchmark-p1-runtime.mjs`<br>• `docs/DEPLOYMENT-P1-GUIDE.md`<br>• Verified Container Runbook | Latency P95 <= 350ms, Zero memory leaks หลัง 500 requests |
| **Week 5** | **Milestone 5 — Evidence Continuity** | • รวม Evidence Report ต่อเนื่องจาก P0 → P1<br>• สร้าง Merkle Tree Audit Trail ของ Model Artifacts<br>• จัดทำ Final P1 Verification Report | • `docs/reports/P1-EVIDENCE-REPORT.md`<br>• `docs/reports/P1-AUDIT-TRAIL.json`<br>• Cryptographic Release Manifest | ทุก Artifacts มี SHA-256 เชื่อมโยงถึง P0 baseline พร้อมลงนาม |

---

## 🧩 Architectural Separation & Protection

1. **Reasoning Immutability**:
   - `server/reasoning.ts` ยังคงทำหน้าที่เป็น Decision & Risk Engine ที่ไม่ถูกดัดแปลง
   - Model weights และ Training/Eval ทำหน้าที่เป็น Provider Layer เสริมพลังด้านล่าง
2. **Layer Isolation**:
   - **Layer 1: Software Logic** (`src/`, `server/`, `features/`)
   - **Layer 2: Model & Weights Pipeline** (`training/`, `evaluation/`)
   - **Layer 3: Evidence & Audit Ledger** (`docs/reports/`, `.data/training/evidence/`)
3. **Continuous Reproducibility**:
   - ทุกครั้งที่รัน `npm run p0:verify` หรือ `npm run p1:verify` ผลลัพธ์จะต้องสอดคล้องกับ Baseline เสมอ

---

## 🎯 Next Immediate Action
- รันคำสั่ง `npm run p0:verify` เพื่อยืนยันว่า Pipeline P0 พร้อมส่งมอบ
- เปิดทางสู่ Week 1 ของ Phase P1 ทันทีเมื่อผู้ใช้งานพร้อม
