import test from "node:test";
import assert from "node:assert/strict";
import { validateCustomConfig, DEFAULT_CUSTOM_CONFIG } from "../server/customConfig.js";
import { selectEngineMode } from "../server/modeSelector.js";
import { handleRoute, handleValidateCustomConfig } from "../server/engineRoutes.js";
import { ConnectorHub } from "../server/connectorHub.js";

test("Custom config schema: accepts valid full configuration", () => {
  const result = validateCustomConfig({
    depth: "DEEP",
    allowedConnectors: ["github", "web_research"],
    requiresApproval: true,
    allowFileModifications: false,
    maxSteps: 15,
    strictness: "strict",
  });
  assert.equal(result.ok, true);
  if (result.ok) {
    assert.equal(result.config.depth, "DEEP");
    assert.deepEqual(result.config.allowedConnectors, ["github", "web_research"]);
    assert.equal(result.config.requiresApproval, true);
    assert.equal(result.config.allowFileModifications, false);
    assert.equal(result.config.maxSteps, 15);
    assert.equal(result.config.strictness, "strict");
  }
});

test("Custom config schema: rejects invalid depth values like TURBO", () => {
  const result = validateCustomConfig({ depth: "TURBO" });
  assert.equal(result.ok, false);
  if (!result.ok) {
    assert.equal(result.code, "invalid_custom_config");
    assert.ok(result.errors.some((e) => e.includes("Invalid 'depth'")));
  }
});

test("Custom config schema: rejects unknown or malicious connectors", () => {
  const result = validateCustomConfig({
    allowedConnectors: ["github", "unauthorized_remote_shell"],
  });
  assert.equal(result.ok, false);
  if (!result.ok) {
    assert.equal(result.code, "invalid_custom_config");
    assert.ok(result.errors.some((e) => e.includes("Unknown connector 'unauthorized_remote_shell'")));
  }
});

test("Custom config schema: rejects invalid maxSteps (negative, zero, >20, or non-integer)", () => {
  assert.equal(validateCustomConfig({ maxSteps: 0 }).ok, false);
  assert.equal(validateCustomConfig({ maxSteps: -5 }).ok, false);
  assert.equal(validateCustomConfig({ maxSteps: 25 }).ok, false);
  assert.equal(validateCustomConfig({ maxSteps: 3.14 }).ok, false);
  assert.equal(validateCustomConfig({ maxSteps: 10 }).ok, true);
});

test("Custom config schema: rejects unrecognized extra properties", () => {
  const result = validateCustomConfig({ depth: "FAST", unapprovedField: 123 });
  assert.equal(result.ok, false);
  if (!result.ok) {
    assert.ok(result.errors.some((e) => e.includes("Unrecognized property: 'unapprovedField'")));
  }
});

test("Backend enforcement: custom requiresApproval=true forces DEEP depth and approval on low-risk request", () => {
  const decision = selectEngineMode("สวัสดี", "custom", undefined, {
    requiresApproval: true,
  });
  assert.equal(decision.depth, "DEEP");
  assert.equal(decision.requiresApproval, true);
  assert.ok(decision.reasons.some((r) => r.includes("mandatory approval enforced")));
});

test("Backend enforcement: custom allowedConnectors restricts hinted connectors", () => {
  // Prompt asks for GitHub and Web Research
  const prompt = "ค้นหาข้อมูลใน github และ ค้นเว็บ ข่าวล่าสุด";
  const withAll = selectEngineMode(prompt, "custom", undefined, {
    allowedConnectors: ["github", "web_research"],
  });
  assert.ok(withAll.connectorHints.includes("github"));
  assert.ok(withAll.connectorHints.includes("web_research"));

  // Only github allowed
  const onlyGithub = selectEngineMode(prompt, "custom", undefined, {
    allowedConnectors: ["github"],
  });
  assert.ok(onlyGithub.connectorHints.includes("github"));
  assert.ok(!onlyGithub.connectorHints.includes("web_research"));
  assert.ok(onlyGithub.reasons.some((r) => r.includes("connector 'web_research' blocked by allowedConnectors policy")));
});

test("Backend enforcement: allowFileModifications=false blocks code/file changes", () => {
  const decision = selectEngineMode("แก้ไฟล์ index.html ให้หน่อย", "custom", undefined, {
    allowFileModifications: false,
  });
  assert.equal(decision.supported, false);
  assert.ok(decision.reasons.some((r) => r.includes("file modifications disabled (read-only enforced)")));
});

test("handleRoute: accepts customConfig and includes custom policy in limitations", async () => {
  const hub = new ConnectorHub();
  const res = await handleRoute(
    {
      message: "ตรวจสอบโค้ด",
      mode: "custom",
      customConfig: {
        depth: "DEEP",
        requiresApproval: true,
        allowFileModifications: false,
      },
    },
    hub
  );
  assert.equal(res.status, 200);
  const body = res.body as { decision: { depth: string; requiresApproval: boolean }; limitations: string[] };
  assert.equal(body.decision.depth, "DEEP");
  assert.equal(body.decision.requiresApproval, true);
  assert.ok(body.limitations.some((l) => l.includes("custom mode active: enforcing user-defined policy")));
});

test("handleRoute: rejects invalid customConfig with HTTP 400 and invalid_custom_config code", async () => {
  const hub = new ConnectorHub();
  const res = await handleRoute(
    {
      message: "ตรวจสอบโค้ด",
      mode: "custom",
      customConfig: {
        depth: "INVALID_DEPTH_NAME",
      },
    },
    hub
  );
  assert.equal(res.status, 400);
  const body = res.body as { status: string; code: string; errors: string[] };
  assert.equal(body.status, "blocked");
  assert.equal(body.code, "invalid_custom_config");
  assert.ok(body.errors.length > 0);
});

test("handleValidateCustomConfig: endpoint validator returns 200 for valid and 400 for invalid", async () => {
  const validRes = await handleValidateCustomConfig({
    depth: "FAST",
    requiresApproval: false,
  });
  assert.equal(validRes.status, 200);

  const invalidRes = await handleValidateCustomConfig({
    depth: "BOGUS",
  });
  assert.equal(invalidRes.status, 400);
});
