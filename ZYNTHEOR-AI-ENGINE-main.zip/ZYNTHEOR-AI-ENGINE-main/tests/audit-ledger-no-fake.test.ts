import test, { describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const src = readFileSync(new URL('../src/components/views/AuditLedgerView.tsx', import.meta.url), 'utf8');

/** Returns the body of `const <name> = async () => { ... };` up to the next top-level handler. */
function handlerBody(name: string): string {
  const start = src.indexOf(`const ${name} = async () => {`);
  assert.ok(start > 0, `${name} must exist`);
  const next = src.indexOf('\n  const ', start + 10);
  return src.slice(start, next > 0 ? next : start + 2000);
}

describe('AuditLedgerView: No Fake (no certification or SUCCESS without evidence)', () => {
  const handlers = ['handleAnchorCertProtocol', 'handleTriggerPqcValidation', 'handleTriggerMutationDriftScan'];

  for (const name of handlers) {
    test(`${name} never posts SUCCESS, "Verified" or invented hashes/signatures`, () => {
      const body = handlerBody(name);
      assert.ok(/status:\s*'UNKNOWN'/.test(body), 'must record UNKNOWN');
      assert.ok(!/status:\s*'SUCCESS'/.test(body), 'must not post SUCCESS');
      assert.ok(!/pqcStatus:\s*'Verified'/.test(body), 'must not claim pqcStatus Verified');
      assert.ok(!/validationResult:\s*'VALID'/.test(body), 'must not claim a VALID result');
      assert.ok(!/0x[0-9a-f]{4,}/i.test(body), 'must not embed hard-coded digests');
      assert.ok(!/sha(256|3-512):/i.test(body), 'must not embed hard-coded certificate hashes');
      assert.ok(!/_sig_[0-9a-f]{8,}/i.test(body), 'must not embed sample signatures');
      assert.ok(!/GOLD MASTER CERTIFIED/.test(body), 'must not post a certification seal');
    });
  }

  test('drift scan request does not assert "no drift" without a measurement', () => {
    const body = handlerBody('handleTriggerMutationDriftScan');
    assert.ok(/scanPerformed:\s*false/.test(body));
    assert.ok(/driftDetected:\s*null/.test(body));
    assert.ok(!/driftDetected:\s*false/.test(body));
    assert.ok(!/driftPercentage:\s*0(\.0+)?\b/.test(body));
  });

  test('PQC validation request reports NOT_PERFORMED', () => {
    assert.ok(/validationResult:\s*'NOT_PERFORMED'/.test(handlerBody('handleTriggerPqcValidation')));
  });

  test('security card shows UNKNOWN, not a certified badge, and no fabricated root hash', () => {
    assert.ok(src.includes('data-testid="ga-cert-status"'));
    assert.ok(src.includes('UNKNOWN · NOT CERTIFIED'));
    assert.ok(!src.includes('0x7b58f9611d04ea3e'));
    assert.ok(!/Certified Commercial-Grade Quantum System/.test(src));
  });

  test('events without evidence do not fall back to a fabricated evidence-chain id', () => {
    assert.ok(!/evidenceChainId \|\| 'EV-2026-GA-CERT-NOVA-001'/.test(src));
  });

  test('useMemo is imported (file would crash at runtime otherwise)', () => {
    assert.ok(/import React, \{[^}]*\buseMemo\b[^}]*\} from 'react'/.test(src));
  });

  test('the file keeps its existing exports and tabs (no feature removed)', () => {
    for (const token of ["export function getPqcSignatureStatus", 'export const PqcStatusBadge', 'export const AuditLedgerView', "'security_events'", 'isPqcEvent', 'isDriftEvent']) {
      assert.ok(src.includes(token), `missing ${token}`);
    }
  });
});
