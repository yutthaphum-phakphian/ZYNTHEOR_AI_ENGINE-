import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeSessionTags } from '../src/utils/autoTagging.js';

const tags = (content: string) => analyzeSessionTags([{ content }]);

test('Thai keywords assign tags (JS \\b is ASCII-only, so Thai must not rely on it)', () => {
  assert.ok(tags('ช่วยแก้บั๊กให้หน่อย').includes('Bug'));
  assert.ok(tags('โค้ดพังตอนรัน').includes('Bug'));
  assert.ok(tags('อธิบายสถาปัตยกรรมระบบ').includes('Architecture'));
  assert.ok(tags('ตรวจความปลอดภัย').includes('Security'));
  assert.ok(tags('ปรับหน้าตาให้สวย').includes('UI/UX'));
  assert.ok(tags('ออกแบบฐานข้อมูล').includes('Database'));
});

test("short form 'Arch' tags Architecture, but not words that merely contain it", () => {
  assert.ok(tags('Arch review of the service').includes('Architecture'));
  assert.ok(!tags('the search march parch').includes('Architecture'));
});

test('existing English matching is unchanged and empty input yields no tags', () => {
  assert.ok(tags('fix the bug').includes('Bug'));
  assert.deepEqual(tags('hello'), []);
  assert.deepEqual(analyzeSessionTags([]), []);
});
