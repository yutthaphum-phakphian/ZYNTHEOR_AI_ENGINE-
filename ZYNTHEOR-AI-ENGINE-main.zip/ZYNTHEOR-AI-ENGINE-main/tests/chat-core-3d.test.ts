import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { isWebGLAvailable } from '../src/components/ChatCore3D';

const core = readFileSync(new URL('../src/components/ChatCore3D.tsx', import.meta.url), 'utf8');
const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');

test('the chat empty state mounts the real WebGL core, lazily, with a CSS fallback while loading', () => {
  assert.match(app, /const ChatCore3D = lazy\(\(\) => import\('\.\/components\/ChatCore3D'\)/);
  assert.match(app, /<Suspense fallback=\{<ChatCoreFallback \/>\}>\s*<ChatCore3D \/>/);
  const emptyState = app.indexOf('<ChatCore3D />');
  assert.ok(emptyState > 0 && emptyState < app.indexOf('What are we building today?'), 'core sits above the heading');
});

test('3D core renders through three.js WebGLRenderer, not a static icon', () => {
  assert.match(core, /new THREE\.WebGLRenderer\(/);
  assert.match(core, /new THREE\.IcosahedronGeometry\(/);
  assert.match(core, /renderer\.render\(scene, camera\)/);
});

test('3D core honours prefers-reduced-motion and pauses when hidden or off-screen', () => {
  assert.match(core, /prefers-reduced-motion: reduce/);
  assert.match(core, /if \(running \|\| reduceMotion/);
  assert.match(core, /visibilitychange/);
  assert.match(core, /IntersectionObserver/);
});

test('3D core falls back gracefully and cleans up GPU resources', () => {
  assert.match(core, /isWebGLAvailable\(\)/);
  assert.match(core, /webglcontextlost/);
  assert.match(core, /catch \{\s*setFailed\(true\);/);
  assert.match(core, /renderer\.dispose\(\)/);
  assert.match(core, /disposables\.forEach/);
});

test('3D core is decorative: no runtime, model, latency or connection claims', () => {
  const code = core.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.doesNotMatch(code, /latency|connected|online|offline|UNAVAILABLE|status/i);
});

test('isWebGLAvailable is false without a DOM and respects canvas context support', () => {
  assert.equal(isWebGLAvailable(), false, 'no document in node');
  const g = globalThis as unknown as { document?: unknown };
  const original = g.document;
  try {
    g.document = { createElement: () => ({ getContext: (kind: string) => (kind === 'webgl' ? {} : null) }) };
    assert.equal(isWebGLAvailable(), true);
    g.document = { createElement: () => ({ getContext: () => null }) };
    assert.equal(isWebGLAvailable(), false);
    g.document = { createElement: () => { throw new Error('boom'); } };
    assert.equal(isWebGLAvailable(), false);
  } finally {
    if (original === undefined) delete g.document; else g.document = original;
  }
});
