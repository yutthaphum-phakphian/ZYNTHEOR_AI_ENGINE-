import test, { after } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  classifyTaskRequest,
  validateTaskTypeEvidence,
  REQUIRED_EVIDENCE_BY_TASK_TYPE,
  runFullAgentTaskFlow,
  type EvidenceItem,
} from "../server/reasoning.js";
import {
  createAutonomousTask,
  executeAutonomousTask,
  transitionTaskState,
  approveTask,
  type TaskStep,
} from "../server/taskExecutor.js";
import {
  createPlan,
  executePlan,
  requestPlanApproval,
  approvePlan,
  registerTool,
  unregisterTool,
  grantPermission,
  revokePermission,
  listTools,
  type PlanDraft,
  type ToolAdapter,
} from "../server/agent.js";
import { loadAgentEvents } from "../server/store.js";

const previousStorePath = process.env.CHAT_STORE_PATH;
const tempDir = await mkdtemp(join(tmpdir(), "zyrquen-tool-intelligence-test-"));
process.env.CHAT_STORE_PATH = join(tempDir, "ledger.jsonl");

after(async () => {
  if (previousStorePath === undefined) delete process.env.CHAT_STORE_PATH;
  else process.env.CHAT_STORE_PATH = previousStorePath;
  await rm(tempDir, { recursive: true, force: true });
});

test("Phase 5: Task classification distinguishes supported vs unsupported task routing", () => {
  // 1. Unsupported requests must NOT be routed into random tools or claim success
  const unsupportedK8s = classifyTaskRequest("deploy to kubernetes cluster in production");
  assert.equal(unsupportedK8s.supported, false);
  assert.equal(unsupportedK8s.taskType, "unsupported");
  assert.match(unsupportedK8s.ambiguityReason || "", /not supported/);

  const unsupportedCrypto = classifyTaskRequest("mine crypto bitcoin on server");
  assert.equal(unsupportedCrypto.supported, false);
  assert.equal(unsupportedCrypto.taskType, "unsupported");

  // 2. Supported tasks must route to explicit contracts
  const syntaxCheck = classifyTaskRequest("รัน syntax_check ตรวจสอบความถูกต้อง");
  assert.equal(syntaxCheck.supported, true);
  assert.equal(syntaxCheck.taskType, "syntax_check");
  assert.equal(syntaxCheck.toolSelected, "syntax_check");

  const testTask = classifyTaskRequest("run tests for unit and regression");
  assert.equal(testTask.supported, true);
  assert.equal(testTask.taskType, "test");
  assert.equal(testTask.toolSelected, "test");

  const explainTask = classifyTaskRequest("ให้อธิบายโค้ด server/agent.ts verifyIntegrity");
  assert.equal(explainTask.supported, true);
  assert.equal(explainTask.taskType, "explain_code");
  assert.equal(explainTask.requiresApproval, false);
});

test("Phase 5: Missing arguments and schema validation detect ambiguities and invalid inputs", async () => {
  // 1. Missing target file for code modification
  const vagueCodeChange = classifyTaskRequest("ช่วยเขียนโค้ดและแก้ไขระบบให้หน่อย", "code");
  assert.equal(vagueCodeChange.supported, true);
  assert.equal(vagueCodeChange.taskType, "code_change");
  assert.equal(vagueCodeChange.needsClarification, true);
  assert.ok(vagueCodeChange.missingInputs.includes("targetFile"));
  assert.ok(vagueCodeChange.clarificationPrompt?.length);

  // 2. Autonomous task execution with invalid targetFiles for inspection
  const inspectResult = await runFullAgentTaskFlow({
    task: {
      id: "inspect_invalid_args",
      goal: "Inspect invalid files",
      taskType: "inspect",
      targetFiles: [""], // Invalid empty string
    },
  });
  assert.equal(inspectResult.state, "BLOCKED");
  assert.match(inspectResult.error || "", /inspection target list is invalid/);
  assert.ok(inspectResult.honestReport);
  assert.equal(inspectResult.honestReport.finalStatus, "BLOCKED");
  assert.ok(inspectResult.honestReport.actionsNotPerformed.length > 0);
});

test("Phase 5: Tool registry distinguishes configured, reachable, and permission-denied tools", async () => {
  const customToolName = "custom_unreachable_tool";
  const customPerm = "execute:custom";

  const unreachableTool: ToolAdapter = {
    name: customToolName,
    description: "Custom tool that is reachable=false",
    permission: customPerm,
    risk: "LOW",
    available: true,
    configured: true,
    reachable: false,
    inputSchema: { type: "object", properties: {}, required: [], additionalProperties: false },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string" },
        value: { type: "object", required: ["isoTimestamp"], additionalProperties: false, properties: { isoTimestamp: { type: "string" } } }
      }
    },
    successCondition: "result is verified",
    async execute() {
      return { observedAt: new Date().toISOString(), value: { isoTimestamp: new Date().toISOString() } };
    },
    verify() {
      return { status: "VERIFIED", checkedAt: new Date().toISOString(), evidence: "Custom verified" };
    }
  };

  registerTool(unreachableTool);
  grantPermission(customPerm);

  try {
    const tools = listTools();
    const found = tools.find((t) => t.name === customToolName);
    assert.ok(found);
    assert.equal(found.reachable, false);
    assert.equal(found.configured, true);

    const draft: PlanDraft = {
      goal: "Test unreachable tool execution",
      riskLevel: "LOW",
      successCriteria: ["Tool executes"],
      steps: [
        {
          id: "step_unreachable",
          tool: customToolName,
          input: {},
          dependsOn: [],
          successCondition: unreachableTool.successCondition,
        },
      ],
    };

    const plan = await createPlan(draft);
    await requestPlanApproval(plan.id);
    const approved = await approvePlan(plan.id, plan.hash);
    const executed = await executePlan(plan.id, approved.approval?.id);

    // Unreachable tool must be BLOCKED
    assert.equal(executed.status, "BLOCKED");
    assert.equal(executed.steps[0].status, "BLOCKED");
    assert.ok(executed.honestReport);
    assert.equal(executed.honestReport.isPartial, false);
    assert.ok(executed.honestReport.actionsNotPerformed.some((a) => a.tool === customToolName));
  } finally {
    unregisterTool(customToolName);
    revokePermission(customPerm);
  }
});

test("Phase 5: Plan-hash and approval binding rejects tampered plan context and expired approvals", async () => {
  const task = createAutonomousTask({
    goal: "Verify strict approval binding",
    riskLevel: "HIGH",
    steps: [
      { id: "s1", title: "Unsafe Action", tool: "custom_risky_op", requiresApproval: true },
    ],
  });

  // 1. Approval with wrong hash must throw
  assert.throws(
    () => approveTask(task.id, "0".repeat(64)),
    /Hash mismatch/
  );

  // 2. Expired approval must be rejected when attempting to execute
  const approved = approveTask(task.id, task.hash, {
    expiresAt: new Date(Date.now() - 1000).toISOString(), // Expired 1 second ago
  });

  assert.equal(approved.approval?.taskHash, task.hash);

  // Attempting to transition to RUNNING with expired approval throws
  assert.throws(
    () => transitionTaskState(task, "RUNNING"),
    /Approval expired/
  );
});

test("Phase 5: Real execution output vs claimed output - failed exitCode produces FAILED without false VERIFIED", async () => {
  const task = createAutonomousTask({
    goal: "Verify failed sandbox tool produces FAILED status",
    steps: [
      { id: "s1", title: "Build step", tool: "build" },
    ],
  });

  // Note: executeAutonomousTask with build when index.html / package.json build fails or succeeds
  // If exitCode !== 0, task state must be FAILED, never false VERIFIED
  const executed = await executeAutonomousTask(task.id);
  assert.ok(["COMPLETED", "FAILED"].includes(executed.state));
  if (executed.state === "FAILED") {
    assert.equal(executed.steps[0].status, "FAILED");
    assert.ok(executed.evidence.some((e) => e.exitCode !== 0 || e.verificationStatus === "FAILED"));
    assert.ok(executed.honestReport);
    assert.equal(executed.honestReport.finalStatus, "FAILED");
  } else {
    // If completed, verified evidence must be non-empty
    assert.ok(executed.evidence.length > 0);
    assert.ok(executed.evidence.every((e) => e.verificationStatus === "VERIFIED"));
  }
});

test("Phase 5: Partial completion is explicitly tracked with honest action breakdown", async () => {
  // Task with 2 steps: step 1 is safe get_time (succeeds), step 2 is unallowlisted (blocked)
  const task = createAutonomousTask({
    goal: "Verify partial completion tracking",
    steps: [
      { id: "step1", title: "Get time", tool: "get_time" },
      { id: "step2", title: "Unallowlisted op", tool: "unauthorized_remote_action" },
    ],
  });

  // Step 2 requires approval because unauthorized tool is unsafe
  assert.equal(task.steps[1].requiresApproval, true);

  // Approve the task hash so step 1 can execute and step 2 will hit the unallowlisted execution gate
  approveTask(task.id, task.hash);

  const executed = await executeAutonomousTask(task.id);

  // Overall status must be BLOCKED
  assert.equal(executed.state, "BLOCKED");
  assert.equal(executed.steps[0].status, "VERIFIED");
  assert.equal(executed.steps[1].status, "BLOCKED");

  // Honest report must be present and report partial execution
  assert.ok(executed.honestReport, "Must generate honest report");
  assert.equal(executed.honestReport.isPartial, true, "Must flag isPartial = true");
  assert.equal(executed.honestReport.actionsPerformed.length, 1);
  assert.equal(executed.honestReport.actionsPerformed[0].stepId, "step1");
  assert.equal(executed.honestReport.actionsNotPerformed.length, 1);
  assert.equal(executed.honestReport.actionsNotPerformed[0].stepId, "step2");
  assert.match(executed.honestReport.summary, /Partial/);
});

test("Phase 5: Missing or contradictory evidence rejects VERIFIED and COMPLETED transitions", () => {
  // 1. Evidence validator detects missing required evidence
  const emptyEvidence: EvidenceItem[] = [];
  const syntaxCheckValidation = validateTaskTypeEvidence("syntax_check", emptyEvidence);
  assert.equal(syntaxCheckValidation.valid, false);
  assert.match(syntaxCheckValidation.missingRequirement || "", /syntax check must execute/);

  // 2. Contradictory evidence (verified: false) fails validation
  const failedEvidence: EvidenceItem[] = [
    {
      id: "ev_fail",
      category: "fact",
      statement: "syntax check failed",
      source: "sandbox:syntax_check",
      verified: false,
    },
  ];
  const contradictoryValidation = validateTaskTypeEvidence("syntax_check", failedEvidence);
  assert.equal(contradictoryValidation.valid, false);

  // 3. State machine forbids transition to COMPLETED without empirical evidence in taskExecutor
  const task = createAutonomousTask({
    goal: "Verify evidence gate",
    steps: [{ id: "step1", title: "Read clock", tool: "get_time" }],
  });

  task.state = "VERIFYING";
  // Without evidence, cannot transition to COMPLETED
  assert.throws(
    () => transitionTaskState(task, "COMPLETED"),
    /Verification Gate: Cannot transition task to COMPLETED without empirical verification evidence/
  );
});

test("Phase 5: Prerequisite failure propagation blocks downstream dependent steps", async () => {
  // Plan where step 2 depends on step 1
  const draft: PlanDraft = {
    goal: "Verify prerequisite failure propagation",
    riskLevel: "LOW",
    successCriteria: ["Step 2 executes only if step 1 succeeds"],
    steps: [
      {
        id: "step_one",
        tool: "get_time",
        input: {},
        dependsOn: [],
        successCondition: "result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt",
      },
      {
        id: "step_two",
        tool: "get_time",
        input: {},
        dependsOn: ["step_one"],
        successCondition: "result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt",
      },
    ],
  };

  const plan = await createPlan(draft);
  await requestPlanApproval(plan.id);
  const approved = await approvePlan(plan.id, plan.hash);

  // Execute plan normally - both should succeed
  const executed = await executePlan(plan.id, approved.approval?.id);
  assert.equal(executed.status, "SUCCEEDED");
  assert.equal(executed.steps[0].status, "SUCCEEDED");
  assert.equal(executed.steps[1].status, "SUCCEEDED");
  assert.ok(executed.honestReport);
  assert.equal(executed.honestReport.isPartial, false);
  assert.equal(executed.honestReport.actionsPerformed.length, 2);
  assert.equal(executed.honestReport.actionsNotPerformed.length, 0);
});

test("Phase 5: Truthful final response contract accurately reports goal, actions performed, and not performed", async () => {
  // Seed real workspace content so inspect has empirical files (empty workspace correctly BLOCKS)
  const { writeWorkspaceFile } = await import("../server/files.js");
  await writeWorkspaceFile("phase5-inspect-fixture.txt", "phase5 evidence fixture\n", "code");

  // Run full agent task flow for inspect
  const result = await runFullAgentTaskFlow({
    task: {
      id: "inspect_truthful_report",
      goal: "Inspect workspace codebase truthfully",
      taskType: "inspect",
    },
  });

  assert.ok(result.honestReport, "Result must contain honestReport");
  assert.equal(result.honestReport.goal, "Inspect workspace codebase truthfully");
  assert.ok(["COMPLETED", "VERIFIED"].includes(result.honestReport.finalStatus) || result.state === "COMPLETED");
  assert.ok(result.honestReport.actionsPerformed.length > 0);
  assert.ok(result.honestReport.actionsPerformed[0].evidence.length > 0);

  // Check audit ledger events for correlation
  const events = await loadAgentEvents();
  const taskEvents = events.filter((e) => e.runId === "inspect_truthful_report" || (e.data && (e.data as any).taskId === "inspect_truthful_report"));
  assert.ok(taskEvents.length > 0, "Audit ledger must record task events with correlation");
});
