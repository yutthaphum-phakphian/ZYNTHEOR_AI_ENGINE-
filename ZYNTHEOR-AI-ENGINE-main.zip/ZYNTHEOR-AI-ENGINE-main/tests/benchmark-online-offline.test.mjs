import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

 test('benchmark never calls hosted provider without explicit opt-in and key', () => {
  const dir = mkdtempSync(join(tmpdir(), 'zyntheor-benchmark-'));
  try {
    const reportPath = join(dir, 'report.json');
    const result = spawnSync(process.execPath, ['scripts/benchmark-online-offline.mjs'], {
      cwd: process.cwd(), encoding: 'utf8', timeout: 10000,
      env: { ...process.env, LOCAL_AI_ENDPOINT: 'http://127.0.0.1:1', RUN_ONLINE_BENCHMARK: '', GROQ_API_KEY: '', BENCHMARK_TIMEOUT_MS: '1000', BENCHMARK_REPORT_PATH: reportPath },
    });
    assert.equal(result.status, 0, result.stderr || result.stdout);
    const report = JSON.parse(readFileSync(reportPath, 'utf8'));
    assert.equal(report.policy.hostedRequiresExplicitOptIn, true);
    assert.equal(report.policy.fallbackAttempted, false);
    assert.equal(report.results.find((x) => x.provider === 'online_groq')?.status, 'NOT_RUN');
    assert.equal(report.results.find((x) => x.provider === 'local_ollama')?.status, 'UNAVAILABLE');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
