import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calculateConversationStats, extractWordCloud } from '../src/utils/conversationStats.js';

test('calculateConversationStats calculates message counts and reading time accurately', () => {
  const sampleMessages = [
    {
      id: 'm1',
      role: 'user' as const,
      content: 'Can you explain the React component architecture and TypeScript types?',
      timestamp: 1000,
      createdAt: '10:00:00',
    },
    {
      id: 'm2',
      role: 'assistant' as const,
      content: 'Certainly! React components use modular functional design, hooks, and TypeScript interfaces for strong typing.',
      timestamp: 1500, // 500ms latency
      createdAt: '10:00:01',
    },
    {
      id: 'm3',
      role: 'user' as const,
      content: 'How do we optimize latency and handle performance bottlenecks?',
      timestamp: 2000,
      createdAt: '10:00:02',
    },
    {
      id: 'm4',
      role: 'assistant' as const,
      content: 'To optimize latency, use memoization, streaming responses, and local caching. Database queries should be indexed.',
      timestamp: 2450, // 450ms latency
      createdAt: '10:00:03',
    },
  ];

  const stats = calculateConversationStats(sampleMessages);

  assert.equal(stats.totalMessages, 4);
  assert.equal(stats.userMessagesCount, 2);
  assert.equal(stats.assistantMessagesCount, 2);
  assert.ok(stats.avgResponseLatencyMs > 0, 'Average latency should be positive');
  assert.ok(stats.totalWords > 0, 'Word count should be positive');
  assert.ok(stats.totalTokens > 0, 'Token count should be positive');
  assert.ok(stats.estimatedReadingMinutes >= 1, 'Reading minutes should be at least 1');
  assert.equal(stats.turnLatencies.length, 2, 'Should record 2 turn latencies');
});

test('extractWordCloud extracts technical terms and groups into word cloud weights', () => {
  const sampleMessages = [
    {
      id: 'm1',
      role: 'user' as const,
      content: 'Let us build a React TypeScript application with Docker and Tailwind CSS for the API.',
    },
    {
      id: 'm2',
      role: 'assistant' as const,
      content: 'We can configure Vite, TypeScript, React components, and Docker containers for deployment and security.',
    },
    {
      id: 'm3',
      role: 'user' as const,
      content: 'Please check the architecture and security of the API endpoints.',
    },
  ];

  const cloud = extractWordCloud(sampleMessages, 15);

  assert.ok(cloud.length > 0, 'Word cloud should not be empty');

  // Verify technical keywords are detected and weighted
  const cloudWords = cloud.map((c) => c.text);
  assert.ok(
    cloudWords.includes('React') ||
    cloudWords.includes('TypeScript') ||
    cloudWords.includes('API') ||
    cloudWords.includes('Architecture') ||
    cloudWords.includes('Security'),
    'Should include prominent technical concepts'
  );

  for (const item of cloud) {
    assert.ok(item.weight >= 1 && item.weight <= 5, 'Weight should be between 1 and 5');
    assert.ok(item.count >= 1, 'Frequency count should be at least 1');
    assert.ok(['tech', 'action', 'concept', 'general'].includes(item.category), 'Category should be valid');
  }
});

test('calculateConversationStats provides fallback topics and metrics for empty or new sessions', () => {
  const emptyStats = calculateConversationStats([]);

  assert.equal(emptyStats.totalMessages, 0);
  assert.equal(emptyStats.userMessagesCount, 0);
  assert.equal(emptyStats.assistantMessagesCount, 0);
  assert.ok(emptyStats.avgResponseLatencyMs > 0);
  assert.ok(Array.isArray(emptyStats.wordCloud));
  assert.ok(emptyStats.wordCloud.length > 0, 'Default word cloud fallback provided for empty session');
});
