import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import type { Server } from 'node:http';
import { createApp } from '../server.js';

const saved = { token: process.env.APPHUB_AUTH_TOKEN, strict: process.env.APPHUB_REQUIRE_AUTH };
const token = 'api-hardening-token-long-enough-for-validation-1234';
process.env.APPHUB_AUTH_TOKEN = token;
delete process.env.APPHUB_REQUIRE_AUTH;

const app = await createApp({ skipVite: true });
const server: Server = app.listen(0, '127.0.0.1');
await new Promise<void>((resolve, reject) => { server.once('listening', resolve); server.once('error', reject); });
const address = server.address();
assert.ok(address && typeof address === 'object');
const base = `http://127.0.0.1:${address.port}`;
const auth = { Authorization: `Bearer ${token}` };

after(async () => {
  await new Promise<void>((resolve, reject) => server.close((e) => (e ? reject(e) : resolve())));
  if (saved.token === undefined) delete process.env.APPHUB_AUTH_TOKEN; else process.env.APPHUB_AUTH_TOKEN = saved.token;
  if (saved.strict === undefined) delete process.env.APPHUB_REQUIRE_AUTH; else process.env.APPHUB_REQUIRE_AUTH = saved.strict;
});

test('status and probe routes refuse a caller-supplied non-loopback endpoint (no SSRF)', async () => {
  for (const path of ['/api/local-model/status', '/api/runtime/status']) {
    const res = await fetch(`${base}${path}?endpoint=${encodeURIComponent('http://169.254.169.254/latest')}`);
    assert.equal(res.status, 400, path);
    assert.equal(((await res.json()) as any).code, 'local_endpoint_not_allowed');
  }
  const probe = await fetch(`${base}/api/runtime/probe`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: 'http://example.com' }) });
  assert.equal(probe.status, 400);
  assert.equal(((await probe.json()) as any).code, 'local_endpoint_not_allowed');
});

test('/api/chat refuses a caller-supplied non-loopback runtime instead of sending the prompt there', async () => {
  const res = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: 'hello there', mode: 'chat', endpoint: 'http://example.com:11434' }) });
  assert.equal(res.status, 400);
  const body = (await res.json()) as any;
  assert.equal(body.code, 'local_endpoint_not_allowed');
  assert.equal(body.fallbackTriggered, false);
});

test('strict mode: every /api route except /api/health needs the bearer token; off by default', async () => {
  // Off by default: an unauthenticated read is not blocked by the strict guard.
  assert.notEqual((await fetch(`${base}/api/audit`)).status, 401);

  process.env.APPHUB_REQUIRE_AUTH = '1';
  try {
    assert.equal((await fetch(`${base}/api/health`)).status, 200, 'health stays open');
    for (const [method, path] of [['GET', '/api/audit'], ['POST', '/api/sandbox/run'], ['GET', '/api/workspace/download-zip'], ['GET', '/api/preflight'], ['POST', '/api/chat']] as const) {
      const res = await fetch(`${base}${path}`, { method, headers: { 'Content-Type': 'application/json' }, body: method === 'POST' ? '{}' : undefined });
      assert.equal(res.status, 401, `${method} ${path}`);
    }
    const wrong = await fetch(`${base}/api/audit`, { headers: { Authorization: 'Bearer wrong-token' } });
    assert.equal(wrong.status, 401);
    const good = await fetch(`${base}/api/audit`, { headers: auth });
    assert.notEqual(good.status, 401);
    assert.notEqual(good.status, 503);

    delete process.env.APPHUB_AUTH_TOKEN; // strict mode with no token configured must fail closed
    const noToken = await fetch(`${base}/api/audit`, { headers: auth });
    assert.equal(noToken.status, 503);
    assert.equal(((await noToken.json()) as any).code, 'auth_not_configured');
  } finally {
    process.env.APPHUB_AUTH_TOKEN = token;
    delete process.env.APPHUB_REQUIRE_AUTH;
  }
});
