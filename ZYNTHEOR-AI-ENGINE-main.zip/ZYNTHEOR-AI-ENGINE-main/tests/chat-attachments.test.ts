import test, { describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { getChatAttachmentPolicy, ingestChatFiles, MAX_CHAT_ATTACHMENT_FILES } from '../server/chatAttachments.js';
import { MAX_INDIVIDUAL_FILE_SIZE } from '../server/files.js';
import { validateCandidate, fileExtension, type AttachmentPolicy } from '../src/utils/attachmentPolicy.js';

const b64 = (s: string | Buffer) => Buffer.from(s).toString('base64');
const file = (name: string, content: string | Buffer, mimeType = 'text/plain') => ({ name, mimeType, contentBase64: b64(content) });

describe('server: ingestChatFiles (adapter over inspectFile)', () => {
  test('accepts a text file and puts its content in the model context, marked as data', () => {
    const r = ingestChatFiles([file('notes.md', 'hello MARKER-123')]);
    assert.equal(r.ok, true);
    assert.match(r.context, /MARKER-123/);
    assert.match(r.context, /not instructions/);
  });

  test('empty list is a no-op, non-array is rejected', () => {
    assert.equal(ingestChatFiles([]).ok, true);
    assert.equal(ingestChatFiles('x').ok, false);
    assert.equal(ingestChatFiles('x').httpStatus, 400);
  });

  test('sensitive filenames and executables are rejected by the existing blocklists', () => {
    for (const name of ['.env', 'id_rsa', 'server.pem', 'run.exe']) {
      const r = ingestChatFiles([file(name, 'x')]);
      assert.equal(r.ok, false, name);
      assert.equal(r.code, 'attachment_rejected');
      assert.equal(r.context, '');
    }
  });

  test('all-or-nothing: one bad file means no file text reaches the context', () => {
    const r = ingestChatFiles([file('ok.txt', 'SECRET-OK-CONTENT'), file('.env', 'KEY=1')]);
    assert.equal(r.ok, false);
    assert.equal(r.context, '');
    assert.equal(r.files.length, 2);
  });

  test('binary content and unsupported types are rejected', () => {
    assert.equal(ingestChatFiles([file('pic.png', Buffer.from([0x89, 0x50, 0x4e, 0x47, 0, 0, 0, 1]), 'image/png')]).ok, false);
    assert.equal(ingestChatFiles([file('a.txt', Buffer.from([0x61, 0, 0x62]))]).ok, false);
  });

  test('per-file size limit comes from files.ts and is enforced before decoding', () => {
    const big = Buffer.alloc(MAX_INDIVIDUAL_FILE_SIZE + 1, 'a');
    const r = ingestChatFiles([file('big.txt', big)]);
    assert.equal(r.ok, false);
    assert.equal(r.files[0].status, 'TOO_LARGE');
  });

  test('file count and total size limits', () => {
    const many = Array.from({ length: MAX_CHAT_ATTACHMENT_FILES + 1 }, (_, i) => file(`f${i}.txt`, 'x'));
    assert.equal(ingestChatFiles(many).httpStatus, 413);
    const chunk = Buffer.alloc(900 * 1024, 'a');
    const r = ingestChatFiles([file('1.txt', chunk), file('2.txt', chunk), file('3.txt', chunk), file('4.txt', chunk)]);
    assert.equal(r.ok, false);
    assert.equal(r.code, 'attachment_total_too_large');
  });

  test('invalid base64 is rejected', () => {
    const r = ingestChatFiles([{ name: 'a.txt', contentBase64: '!!!not base64!!!' }]);
    assert.equal(r.ok, false);
  });

  test('secrets inside an accepted file are redacted by the existing redaction', () => {
    const fake = 'sk-' + 'abcdefghijklmnopqrstuvwxyz0123456789ABCD';
    const r = ingestChatFiles([file('cfg.txt', `token=${fake}`)]);
    assert.equal(r.ok, true);
    assert.ok(!r.context.includes(fake));
  });

  test('policy reports the same constants the server enforces and says images are unsupported', () => {
    const p = getChatAttachmentPolicy();
    assert.equal(p.maxFileBytes, MAX_INDIVIDUAL_FILE_SIZE);
    assert.equal(p.maxFiles, MAX_CHAT_ATTACHMENT_FILES);
    assert.equal(p.imagesSupported, false);
    assert.ok(p.allowedExtensions.includes('.ts') && !p.allowedExtensions.includes('.exe'));
  });
});

describe('client mirror: validateCandidate', () => {
  const policy: AttachmentPolicy = { ...getChatAttachmentPolicy(), authRequired: true, tokenState: 'configured', available: true };
  test('refuses images, oversize, unknown types, too many, and accepts a text file', () => {
    assert.ok(validateCandidate({ name: 'a.png', size: 10, type: 'image/png' }, policy, []));
    assert.ok(validateCandidate({ name: 'a.txt', size: policy.maxFileBytes + 1 }, policy, []));
    assert.ok(validateCandidate({ name: 'a.exe', size: 10 }, policy, []));
    assert.ok(validateCandidate({ name: 'a.txt', size: 10 }, policy, new Array(policy.maxFiles).fill({ size: 1 })));
    assert.equal(validateCandidate({ name: 'a.txt', size: 10, type: 'text/plain' }, policy, []), null);
    assert.equal(fileExtension('dir/App.TSX'), '.tsx');
  });
});

describe('wiring (source checks, not a browser run)', () => {
  const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  const server = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  test('"+" menu is wired to the existing hidden file input and the real policy endpoint', () => {
    assert.ok(app.includes('data-testid="attach-menu-button"'));
    assert.ok(app.includes("fileInputRef.current?.click()"));
    assert.ok(app.includes("/api/chat/attachment-policy"));
    assert.ok(app.includes('contentBase64'));
  });
  test('server authenticates before ingesting and keeps the legacy 503 contract', () => {
    const i = server.indexOf('ingestChatFiles(chatFiles)');
    assert.ok(i > 0 && server.lastIndexOf('requireWorkspaceApiAuth(req, res', i) > 0);
    assert.ok(server.includes("code: 'attachment_ingestion_unavailable'"));
  });
  test('file bytes are not stored in the session message', () => {
    assert.ok(app.includes("mimeType: f.mimeType, url: '' }"));
  });
});
