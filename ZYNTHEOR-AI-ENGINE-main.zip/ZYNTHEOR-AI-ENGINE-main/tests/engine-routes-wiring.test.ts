import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { ConnectorHub } from "../server/connectorHub.js";
import { handleRoute } from "../server/engineRoutes.js";

// The real entry point (npm start / dev) is server.ts. These routes must be served there.
test("server.ts (the real entry point) serves the engine routes the UI calls", () => {
  const src = readFileSync(new URL("../server.ts", import.meta.url), "utf8");
  for (const route of ["/api/engine/lessons", "/api/engine/route", "/api/engine/memory-insight", "/api/engine/connectors'"]) {
    assert.ok(src.includes(route), `server.ts is missing ${route}`);
  }
});

test("route decision: connector hint for an uninstalled connector is NOT_INSTALLED, never faked as available", async () => {
  const hub = new ConnectorHub();
  const r = await handleRoute({ message: "ดู pull request ใน github" }, hub);
  assert.equal(r.status, 200);
  const body = r.body as { connectors: Array<{ hint: string; availability: string }> };
  assert.deepEqual(body.connectors, [{ hint: "github", availability: "NOT_INSTALLED" }]);
});

test("route rejects unknown mode and unexpected fields", async () => {
  const hub = new ConnectorHub();
  assert.equal((await handleRoute({ message: "hi", mode: "turbo" }, hub)).status, 400);
  assert.equal((await handleRoute({ message: "hi", extra: 1 }, hub)).status, 400);
});

test("preferred depth: DEEP is honoured; FAST cannot downgrade a risky/approval-gated request", async () => {
  const { selectEngineMode } = await import("../server/modeSelector.js");
  assert.equal(selectEngineMode("สวัสดี", undefined, "DEEP").depth, "DEEP");
  const risky = selectEngineMode("ดู pull request ใน github", undefined, "FAST");
  assert.equal(risky.depth, "DEEP");
  assert.equal(risky.depthOverridden, true);
  assert.equal(selectEngineMode("สวัสดี", undefined, "FAST").depth, "FAST");
});

test("handleRoute validates depth and reports limitations honestly", async () => {
  const hub = new ConnectorHub();
  assert.equal((await handleRoute({ message: "hi", depth: "TURBO" }, hub)).status, 400);
  const ok = await handleRoute({ message: "hi", depth: "DEEP" }, hub);
  assert.equal(ok.status, 200);
  const body = ok.body as { decision: { depth: string }; limitations: string[] };
  assert.equal(body.decision.depth, "DEEP");
  assert.ok(body.limitations.length > 0);
});

test("ChatWorkspace sends the selected mode to /api/chat and the route request", () => {
  const src = readFileSync(new URL("../src/components/ChatWorkspace.tsx", import.meta.url), "utf8");
  assert.ok(src.includes("toChatMode(engineChoice)"));
  assert.ok(src.includes("/api/engine/route"));
});
