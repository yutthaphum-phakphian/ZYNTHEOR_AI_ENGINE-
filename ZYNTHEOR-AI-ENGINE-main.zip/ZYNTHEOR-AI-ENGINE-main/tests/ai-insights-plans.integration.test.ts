import test from 'node:test';
import assert from 'node:assert/strict';
import { deriveAssistantInsights, filterAndGroupPlans } from '../src/utils/newFeatureLogic.js';

const chat = [
  {
    id: 'm-1',
    sender: 'user' as const,
    content: 'ช่วยสร้าง API สำหรับระบบรายงานและตรวจสอบแผนงานให้ด้วย',
    timestamp: 1,
  },
  {
    id: 'm-2',
    sender: 'agent' as const,
    content: 'กำลังจัดโครงสร้างงานให้เป็นลำดับขั้นตอน',
    summary: 'กำหนดขอบเขต API และแผนทดสอบ',
    timestamp: 2,
  },
  {
    id: 'm-3',
    sender: 'user' as const,
    content: 'จากนั้นช่วยสร้างเอกสารสรุปด้วย',
    timestamp: 3,
  },
];

const plans = [
  {
    id: 'plan-api',
    title: 'สร้าง API ระบบรายงาน',
    description: 'วางแผน endpoint และการตรวจสอบแผนงาน',
    status: 'active',
    progress: 40,
    updatedAt: '2026-10-14T10:00:00.000Z',
    steps: [{ title: 'ออกแบบ endpoint', status: 'done' }],
  },
  {
    id: 'plan-docs',
    title: 'สร้างเอกสารสรุป',
    description: 'เอกสารประกอบการใช้งาน',
    status: 'draft',
    progress: 0,
    updatedAt: '2026-10-14T11:00:00.000Z',
    steps: [{ title: 'ร่างเอกสาร', status: 'pending' }],
  },
  {
    id: 'plan-unrelated',
    title: 'ปรับธีมสีหน้าเว็บ',
    description: 'งานออกแบบที่ไม่เกี่ยวกับคำขอปัจจุบัน',
    status: 'active',
    progress: 10,
    updatedAt: '2026-10-14T12:00:00.000Z',
    steps: [{ title: 'เลือกสี', status: 'pending' }],
  },
];

test('integration: AI Insights pending actions can drive Plans & Tasks search and grouping', () => {
  const insights = deriveAssistantInsights(chat);
  assert.deepEqual(insights.pending, [
    'ช่วยสร้าง API สำหรับระบบรายงานและตรวจสอบแผนงานให้ด้วย',
    'จากนั้นช่วยสร้างเอกสารสรุปด้วย',
  ]);

  // The UI uses the latest actionable phrase as a Plans search query.
  const latestAction = insights.pending.at(-1)!;
  const matchingPlans = filterAndGroupPlans(plans, 'เอกสารสรุป', 'all', 'status');
  assert.equal(matchingPlans.draft.length, 1);
  assert.equal(matchingPlans.draft[0].id, 'plan-docs');
  assert.match(latestAction, /เอกสาร/);
});

test('integration: insight-driven status filter never includes unrelated active plans', () => {
  const insights = deriveAssistantInsights(chat);
  assert.ok(insights.pending.length > 0);

  const activeGroups = filterAndGroupPlans(plans, 'API', 'active', 'status');
  assert.deepEqual(activeGroups.active.map((plan) => plan.id), ['plan-api']);
  assert.equal(activeGroups.active.some((plan) => plan.id === 'plan-unrelated'), false);
});

test('integration: empty insights produce an empty Plans result without throwing', () => {
  const insights = deriveAssistantInsights([
    { id: 'agent-only', sender: 'agent' as const, content: 'พร้อมช่วยเหลือครับ', timestamp: 10 },
  ]);
  assert.deepEqual(insights.pending, []);
  const result = filterAndGroupPlans(plans, '', 'completed', 'status');
  assert.deepEqual(result, {});
});
