import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, writeFile, readdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  SovereignAuditLog,
  SovereignClient,
  createSovereignClientFromEnv,
  loadSovereignAuth,
  validateContract,
  type FetchLike,
  type SovereignContract,
} from "../../../src/connectors/sovereign/index.js";

// ---- MOCK fixtures. Nothing here is a real Sovereign endpoint; paths are invented for tests only. ----
const MOCK_CONTRACT: SovereignContract = {
  contractVersion: "mock-0.0.1",
  source: "sdk",
  verifiedAt: "2026-01-01T00:00:00Z",
  baseUrl: "https://sovereign.invalid",
  operations: {
    ping: { method: "GET", path: "/mock/ping", responseRequired: ["ok"] },
    submit: { method: "POST", path: "/mock/submit", requestRequired: ["id"], responseRequired: ["accepted"] },
    submitIdem: { method: "POST", path: "/mock/submit-idem", idempotent: true, responseRequired: ["accepted"] },
  },
};
const TOKEN = "tok_" + "x".repeat(24);
const auth = () => loadSovereignAuth({ SOVEREIGN_API_TOKEN: TOKEN });
const reply = (status: number, body: unknown = {}) => ({ status, text: async () => JSON.stringify(body) });

function mockClient(handler: FetchLike, over: Partial<ConstructorParameters<typeof SovereignClient>[0]> = {}) {
  const calls: Array<{ url: string; method: string; headers: Record<string, string> }> = [];
  const fetchImpl: FetchLike = async (url, init) => {
    calls.push({ url, method: init.method, headers: init.headers });
    return handler(url, init);
  };
  const audit = new SovereignAuditLog();
  const client = new SovereignClient({
    contract: MOCK_CONTRACT, auth: auth(), audit, timeoutMs: 50, maxRetries: 2, backoffMs: 0,
    sleep: async () => {}, transport: { kind: "MOCK", fetch: fetchImpl }, ...over,
  });
  return { client, calls, audit };
}

test("no contract → UNAVAILABLE/NO_CONTRACT and the network is never touched", async () => {
  const audit = new SovereignAuditLog();
  let touched = false;
  const client = new SovereignClient({
    contract: null, auth: auth(), audit,
    transport: { kind: "REAL", fetch: async () => { touched = true; return reply(200); } },
  });
  const r = await client.call("ping");
  assert.equal(r.status, "UNAVAILABLE");
  assert.equal(r.reason, "NO_CONTRACT");
  assert.equal(r.origin, "REAL");
  assert.equal(r.attempts, 0);
  assert.equal(touched, false);
  assert.equal(r.data, undefined);
});

test("createSovereignClientFromEnv without contract path is UNAVAILABLE; with invalid file is CONTRACT_INVALID", async () => {
  const a = await (await createSovereignClientFromEnv({ SOVEREIGN_API_TOKEN: TOKEN })).call("ping");
  assert.equal(a.reason, "NO_CONTRACT");
  const dir = await mkdtemp(join(tmpdir(), "sov-"));
  const p = join(dir, "c.json");
  await writeFile(p, JSON.stringify({ baseUrl: "http://evil.example" }));
  const b = await (await createSovereignClientFromEnv({ SOVEREIGN_CONTRACT_PATH: p, SOVEREIGN_API_TOKEN: TOKEN })).call("ping");
  assert.equal(b.status, "UNAVAILABLE");
  assert.equal(b.reason, "CONTRACT_INVALID");
});

test("contract validation rejects unverified, insecure and unsafe contracts", () => {
  assert.equal(validateContract(MOCK_CONTRACT).valid, true);
  const bad = (patch: object) => validateContract({ ...MOCK_CONTRACT, ...patch }).valid;
  assert.equal(bad({ verifiedAt: undefined }), false, "unverified contract");
  assert.equal(bad({ baseUrl: "http://sovereign.example" }), false, "plain http to non-loopback");
  assert.equal(bad({ baseUrl: "https://user:pw@sovereign.example" }), false, "embedded credentials");
  assert.equal(bad({ baseUrl: "http://127.0.0.1:9" }), true, "loopback http allowed");
  assert.equal(bad({ operations: {} }), false);
  assert.equal(bad({ operations: { x: { method: "GET", path: "https://evil/x", responseRequired: [] } } }), false);
  assert.equal(bad({ operations: { x: { method: "GET", path: "/a/../b", responseRequired: [] } } }), false);
  assert.equal(bad({ operations: { x: { method: "DELETE", path: "/a", responseRequired: [] } } }), false);
});

test("missing credentials → UNAVAILABLE/NOT_CONFIGURED without calling out", async () => {
  const { client, calls } = mockClient(async () => reply(200, { ok: true }), { auth: null });
  const r = await client.call("ping");
  assert.deepEqual([r.status, r.reason, calls.length], ["UNAVAILABLE", "NOT_CONFIGURED", 0]);
  assert.equal(loadSovereignAuth({ SOVEREIGN_API_TOKEN: "short" }), null);
});

test("valid 2xx matching the contract → SUCCESS, labelled MOCK, never presented as real", async () => {
  const { client, calls } = mockClient(async () => reply(200, { ok: true }));
  const r = await client.call<{ ok: boolean }>("ping", { q: "1" });
  assert.equal(r.status, "SUCCESS");
  assert.equal(r.origin, "MOCK");
  assert.match(r.message, /^\[MOCK — not from Sovereign\]/);
  assert.deepEqual(r.data, { ok: true });
  assert.equal(calls[0].url, "https://sovereign.invalid/mock/ping?q=1");
  assert.equal(calls[0].headers.Authorization, `Bearer ${TOKEN}`);
  assert.ok(calls[0].headers["X-Correlation-Id"]);
});

test("2xx that violates the contract → FAILED, not SUCCESS; non-JSON → FAILED", async () => {
  const a = await mockClient(async () => reply(200, { unrelated: 1 })).client.call("ping");
  assert.deepEqual([a.status, a.reason, a.data], ["FAILED", "RESPONSE_CONTRACT_VIOLATION", undefined]);
  const b = await mockClient(async () => ({ status: 200, text: async () => "<html>" })).client.call("ping");
  assert.deepEqual([b.status, b.reason], ["FAILED", "INVALID_JSON"]);
});

test("401/403 → DENIED and never retried", async () => {
  for (const code of [401, 403]) {
    const { client, calls } = mockClient(async () => reply(code));
    const r = await client.call("ping");
    assert.equal(r.status, "DENIED");
    assert.equal(calls.length, 1);
  }
});

test("unknown operation and missing request fields → FAILED without calling out", async () => {
  const { client, calls } = mockClient(async () => reply(200, {}));
  assert.equal((await client.call("nope")).reason, "UNKNOWN_OPERATION");
  assert.equal((await client.call("submit", {})).reason, "REQUEST_INVALID");
  assert.equal(calls.length, 0);
});

test("transient 503 on idempotent GET is retried then succeeds; exhaustion → UNAVAILABLE", async () => {
  let n = 0;
  const ok = mockClient(async () => (++n < 3 ? reply(503) : reply(200, { ok: true })));
  const r = await ok.client.call("ping");
  assert.deepEqual([r.status, r.attempts], ["SUCCESS", 3]);

  const dead = mockClient(async () => reply(503));
  const d = await dead.client.call("ping");
  assert.deepEqual([d.status, d.reason, d.attempts, dead.calls.length], ["UNAVAILABLE", "UPSTREAM_UNAVAILABLE", 3, 3]);
});

test("non-idempotent POST is never retried; declared-idempotent POST is", async () => {
  const a = mockClient(async () => reply(503));
  assert.equal((await a.client.call("submit", { id: "1" })).attempts, 1);
  const b = mockClient(async () => reply(503));
  assert.equal((await b.client.call("submitIdem", {})).attempts, 3);
});

test("500 and other 4xx → FAILED (not retried); 504 → TIMEOUT", async () => {
  const a = mockClient(async () => reply(500));
  const r = await a.client.call("ping");
  assert.deepEqual([r.status, a.calls.length], ["FAILED", 1]);
  assert.equal((await mockClient(async () => reply(404)).client.call("ping")).status, "FAILED");
  assert.equal((await mockClient(async () => reply(504), { maxRetries: 0 }).client.call("ping")).status, "TIMEOUT");
});

test("no response before the deadline → TIMEOUT; network error → UNAVAILABLE/NETWORK", async () => {
  const hang = mockClient((_u, init) => new Promise((_res, rej) => init.signal.addEventListener("abort", () => rej(new Error("aborted")))), { maxRetries: 0, timeoutMs: 20 });
  assert.equal((await hang.client.call("ping")).status, "TIMEOUT");
  const down = mockClient(async () => { throw new Error("ECONNREFUSED"); }, { maxRetries: 0 });
  const r = await down.client.call("ping");
  assert.deepEqual([r.status, r.reason], ["UNAVAILABLE", "NETWORK"]);
});

test("audit: one hash-chained record per call, tamper-evident, no credentials stored", async () => {
  const dir = await mkdtemp(join(tmpdir(), "sov-audit-"));
  const file = join(dir, "audit.jsonl");
  const audit = new SovereignAuditLog(file);
  const client = new SovereignClient({
    contract: MOCK_CONTRACT, auth: auth(), audit, backoffMs: 0, sleep: async () => {},
    transport: { kind: "MOCK", fetch: async () => reply(200, { ok: true }) },
  });
  await client.call("ping");
  await client.call("nope");
  const recs = audit.list();
  assert.equal(recs.length, 2);
  assert.equal(audit.verifyChain(), true);
  assert.ok(recs.every((r) => r.origin === "MOCK"));
  const tampered = recs.map((r, i) => (i === 0 ? { ...r, status: "DENIED" as const } : r));
  assert.equal(audit.verifyChain(tampered), false);
  assert.equal(audit.verifyChain(recs.slice(1)), false, "removing the first record breaks the chain");
  const onDisk = await readFile(file, "utf8");
  assert.equal(onDisk.trim().split("\n").length, 2);
  assert.ok(!onDisk.includes(TOKEN));
});

test("isolation: connector imports nothing from the engine/core, and the engine does not import the connector", async () => {
  const dir = new URL("../../../src/connectors/sovereign/", import.meta.url);
  for (const f of (await readdir(dir)).filter((x) => x.endsWith(".ts"))) {
    const src = await readFile(new URL(f, dir), "utf8");
    const imports = [...src.matchAll(/from\s+"([^"]+)"/g)].map((m) => m[1]);
    for (const i of imports) assert.ok(i.startsWith("node:") || i.startsWith("./"), `${f} imports ${i}`);
    assert.doesNotMatch(src, /\b(HSM|Treasury|ForensicPipeline|SovereignKernel)\b\s*[({=]/);
  }
  const engine = await readdir(new URL("../../../server/", import.meta.url));
  for (const f of engine.filter((x) => x.endsWith(".ts"))) {
    assert.doesNotMatch(await readFile(new URL(`../../../server/${f}`, import.meta.url), "utf8"), /connectors\/sovereign/, `server/${f} must not depend on the connector`);
  }
});
