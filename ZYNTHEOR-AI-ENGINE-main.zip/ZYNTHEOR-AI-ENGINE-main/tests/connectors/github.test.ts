import test from "node:test";
import assert from "node:assert/strict";
import { ConnectorHub } from "../../server/connectorHub.js";
import {
  createGitHubAdapter,
  validateOwner,
  validateRepo,
  validateFilePath,
  validateIssueState,
  validatePerPage,
  validateRef,
} from "../../server/connectors/github.js";
import { declareDefaultConnectors } from "../../server/engineRoutes.js";

function mockJson(status: number, body: unknown): Response {
  const text = JSON.stringify(body);
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: "",
    headers: new Headers({ "content-type": "application/json" }),
    async text() { return text; },
    async json() { return body; },
  } as unknown as Response;
}

test("declareDefaultConnectors marks github AVAILABLE with read permission", async () => {
  const hub = new ConnectorHub();
  declareDefaultConnectors(hub);
  const list = await hub.list();
  const gh = list.find((c) => c.id === "github");
  assert.ok(gh);
  assert.equal(gh!.availability, "AVAILABLE");
  assert.ok(gh!.grantedPermissions.includes("read"));
});

// --- Strict Input Validation Unit Tests ---
test("validateOwner enforces strict username/org format", () => {
  assert.equal(validateOwner("octocat"), "octocat");
  assert.equal(validateOwner("google-ai-studio"), "google-ai-studio");
  assert.equal(validateOwner("owner.name"), "owner.name");

  assert.throws(() => validateOwner(""), /owner is required/);
  assert.throws(() => validateOwner("   "), /owner is required/);
  assert.throws(() => validateOwner("owner/with/slash"), /invalid owner/);
  assert.throws(() => validateOwner("../traversal"), /invalid owner/);
  assert.throws(() => validateOwner("a".repeat(45)), /invalid owner/);
});

test("validateRepo enforces strict repo name format", () => {
  assert.equal(validateRepo("Hello-World"), "Hello-World");
  assert.equal(validateRepo("zyntheor_engine"), "zyntheor_engine");
  assert.equal(validateRepo("app.v2"), "app.v2");

  assert.throws(() => validateRepo(""), /repo is required/);
  assert.throws(() => validateRepo(".."), /invalid repo/);
  assert.throws(() => validateRepo("."), /invalid repo/);
  assert.throws(() => validateRepo("repo/with/slash"), /invalid repo/);
  assert.throws(() => validateRepo("a".repeat(105)), /invalid repo/);
});

test("validateFilePath prevents directory traversal and empty paths", () => {
  assert.equal(validateFilePath("package.json"), "package.json");
  assert.equal(validateFilePath("src/server/agent.ts"), "src/server/agent.ts");
  assert.equal(validateFilePath("/leading/slash.txt"), "leading/slash.txt");

  assert.throws(() => validateFilePath(""), /path is required/);
  assert.throws(() => validateFilePath("../secret.key"), /path traversal is not allowed/);
  assert.throws(() => validateFilePath("src/../../etc/passwd"), /path traversal is not allowed/);
});

test("validateIssueState accepts only open, closed, all", () => {
  assert.equal(validateIssueState("open"), "open");
  assert.equal(validateIssueState("closed"), "closed");
  assert.equal(validateIssueState("all"), "all");
  assert.equal(validateIssueState(undefined), "open");

  assert.throws(() => validateIssueState("invalid_state"), /must be one of 'open', 'closed', 'all'/);
});

test("validatePerPage validates integer in range 1-30", () => {
  assert.equal(validatePerPage(10), 10);
  assert.equal(validatePerPage(1), 1);
  assert.equal(validatePerPage(30), 30);
  assert.equal(validatePerPage(undefined), 10);

  assert.throws(() => validatePerPage(0), /must be an integer between 1 and 30/);
  assert.throws(() => validatePerPage(50), /must be an integer between 1 and 30/);
  assert.throws(() => validatePerPage(-5), /must be an integer between 1 and 30/);
  assert.throws(() => validatePerPage("not_a_num"), /must be an integer between 1 and 30/);
});

// --- Action 1: get_repo ---
test("Action 1: get_repo returns structured metadata on SUCCESS", async () => {
  const hub = new ConnectorHub();
  hub.register(createGitHubAdapter({
    token: null,
    fetchImpl: async (url) => {
      assert.match(String(url), /\/repos\/octocat\/Hello-World$/);
      return mockJson(200, {
        full_name: "octocat/Hello-World",
        description: "demo",
        default_branch: "master",
        stargazers_count: 100,
        forks_count: 10,
        open_issues_count: 2,
        language: "C",
        private: false,
        html_url: "https://github.com/octocat/Hello-World",
      });
    },
  }));
  hub.grant("github", "read");
  const r = await hub.invoke(
    "github",
    "get_repo",
    { owner: "octocat", repo: "Hello-World" },
    { permission: "read" },
  );
  assert.equal(r.status, "SUCCESS");
  const data = r.data as { fullName: string; stars: number; defaultBranch: string };
  assert.equal(data.fullName, "octocat/Hello-World");
  assert.equal(data.stars, 100);
  assert.equal(data.defaultBranch, "master");
});

// --- Action 2: get_file ---
test("Action 2: get_file decodes base64 content and returns file metadata", async () => {
  const rawContent = '{"name":"test-project","version":"1.0.0"}';
  const base64Content = Buffer.from(rawContent, "utf8").toString("base64");

  const hub = new ConnectorHub();
  hub.register(createGitHubAdapter({
    token: null,
    fetchImpl: async (url) => {
      assert.match(String(url), /\/repos\/octocat\/Hello-World\/contents\/package\.json\?ref=main/);
      return mockJson(200, {
        type: "file",
        name: "package.json",
        path: "package.json",
        sha: "abc12345",
        size: rawContent.length,
        encoding: "base64",
        content: base64Content,
        html_url: "https://github.com/octocat/Hello-World/blob/main/package.json",
      });
    },
  }));
  hub.grant("github", "read");

  const r = await hub.invoke(
    "github",
    "get_file",
    { owner: "octocat", repo: "Hello-World", path: "package.json", ref: "main" },
    { permission: "read" },
  );
  assert.equal(r.status, "SUCCESS");
  const data = r.data as { path: string; content: string; sha: string; truncated: boolean };
  assert.equal(data.path, "package.json");
  assert.equal(data.content, rawContent);
  assert.equal(data.sha, "abc12345");
  assert.equal(data.truncated, false);
});

// --- Action 3: list_issues ---
test("Action 3: list_issues returns issues while filtering out pull requests", async () => {
  const hub = new ConnectorHub();
  hub.register(createGitHubAdapter({
    token: null,
    fetchImpl: async (url) => {
      assert.match(String(url), /\/repos\/octocat\/Hello-World\/issues\?state=open&per_page=10&pulls=false/);
      return mockJson(200, [
        {
          number: 1,
          title: "Bug in parser",
          state: "open",
          user: { login: "alice" },
          html_url: "https://github.com/octocat/Hello-World/issues/1",
          created_at: "2026-10-01T00:00:00Z",
        },
        {
          number: 2,
          title: "Fix bug in parser",
          state: "open",
          pull_request: { url: "https://api.github.com/repos/octocat/Hello-World/pulls/2" },
          html_url: "https://github.com/octocat/Hello-World/pull/2",
        },
      ]);
    },
  }));
  hub.grant("github", "read");

  const r = await hub.invoke(
    "github",
    "list_issues",
    { owner: "octocat", repo: "Hello-World" },
    { permission: "read" },
  );
  assert.equal(r.status, "SUCCESS");
  const data = r.data as { count: number; issues: Array<{ number: number; title: string }> };
  assert.equal(data.count, 1);
  assert.equal(data.issues[0].number, 1);
  assert.equal(data.issues[0].title, "Bug in parser");
});

// --- Unknown Action Rejection ---
test("unknown action is rejected cleanly with supported actions listed", async () => {
  const hub = new ConnectorHub();
  hub.register(createGitHubAdapter());
  hub.grant("github", "read");

  const r = await hub.invoke(
    "github",
    "delete_repo",
    { owner: "octocat", repo: "Hello-World" },
    { permission: "read" },
  );
  assert.equal(r.status, "FAILED");
  assert.match(r.message, /unknown action "delete_repo"/);
  assert.match(r.message, /get_repo, get_file, list_issues/);
});

// --- Error Handling & Permissions ---
test("API 404 error is reported as FAILED without throwing", async () => {
  const hub = new ConnectorHub();
  hub.register(createGitHubAdapter({
    fetchImpl: async () => mockJson(404, { message: "Not Found" }),
  }));
  hub.grant("github", "read");
  const r = await hub.invoke(
    "github",
    "get_repo",
    { owner: "nope", repo: "missing" },
    { permission: "read" },
  );
  assert.equal(r.status, "FAILED");
  assert.match(r.message, /Not Found|404/i);
});

test("permission enforced: DENIED when read permission is not granted", async () => {
  const hub = new ConnectorHub();
  hub.register(createGitHubAdapter());
  const r = await hub.invoke(
    "github",
    "get_repo",
    { owner: "octocat", repo: "Hello-World" },
    { permission: "read" },
  );
  assert.equal(r.status, "DENIED");
});
