import test from 'node:test';
import assert from 'node:assert/strict';
import { GitHubConnectorClient, GITHUB_METADATA } from '../../src/connectors/github/client.js';
import type { ConnectionStatus, GitHubRepoMetadata, GitHubIssue, GitHubFileContent } from '../../src/types/connectors.js';

test('GitHubConnectorClient conforms to standard engine connector contract', async () => {
  const client = new GitHubConnectorClient();

  assert.equal(client.connectorId, 'github');
  assert.equal(client.metadata.id, 'github');
  assert.equal(client.metadata.isReadOnly, true);
  assert.deepEqual(client.metadata.requiredScopes, ['read']);
  assert.deepEqual([...client.metadata.supportedActions], ['get_repo', 'get_file', 'list_issues', 'search']);
});

test('GitHubConnectorClient routes calls strictly through authenticated hub agent endpoint', async () => {
  const recordedCalls: Array<{ url: string; method: string; headers: Record<string, string>; body: any }> = [];

  const mockFetch: typeof fetch = async (input, init) => {
    const url = String(input);
    const method = init?.method || 'GET';
    const headers = (init?.headers || {}) as Record<string, string>;
    const body = init?.body ? JSON.parse(String(init.body)) : null;

    recordedCalls.push({ url, method, headers, body });

    if (url.endsWith('/api/engine/connectors/github')) {
      if (body?.action === 'get_repo') {
        return new Response(
          JSON.stringify({
            status: 'SUCCESS',
            connectorId: 'github',
            action: 'get_repo',
            data: {
              fullName: `${body.input.owner}/${body.input.repo}`,
              description: 'Mocked Repository',
              defaultBranch: 'main',
              stars: 120,
              forks: 45,
              openIssues: 3,
              language: 'TypeScript',
              private: false,
              htmlUrl: `https://github.com/${body.input.owner}/${body.input.repo}`,
              fetchedAt: new Date().toISOString(),
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }

      if (body?.action === 'list_issues') {
        return new Response(
          JSON.stringify({
            status: 'SUCCESS',
            connectorId: 'github',
            action: 'list_issues',
            data: {
              owner: body.input.owner,
              repo: body.input.repo,
              state: body.input.state,
              count: 1,
              issues: [
                {
                  number: 101,
                  title: 'First Mock Issue',
                  state: 'open',
                  user: 'octocat',
                  htmlUrl: 'https://github.com/octocat/Hello-World/issues/101',
                  createdAt: new Date().toISOString(),
                },
              ],
              fetchedAt: new Date().toISOString(),
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }

      if (body?.action === 'get_file') {
        return new Response(
          JSON.stringify({
            status: 'SUCCESS',
            connectorId: 'github',
            action: 'get_file',
            data: {
              owner: body.input.owner,
              repo: body.input.repo,
              path: body.input.path,
              ref: body.input.ref,
              size: 256,
              sha: 'abc1234567890',
              htmlUrl: `https://github.com/${body.input.owner}/${body.input.repo}/blob/main/${body.input.path}`,
              content: '# Hello from Mock GitHub File\nTest verified.',
              truncated: false,
              fetchedAt: new Date().toISOString(),
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }

      if (body?.action === 'search') {
        return new Response(
          JSON.stringify({
            status: 'SUCCESS',
            connectorId: 'github',
            action: 'search',
            data: {
              owner: body.input.owner,
              repo: body.input.repo,
              query: body.input.query,
              type: body.input.type || 'all',
              count: 2,
              issueCount: 1,
              fileCount: 1,
              issues: [
                {
                  number: 42,
                  title: 'Search issue result',
                  state: 'open',
                  isPullRequest: false,
                  user: 'octocat',
                  htmlUrl: 'https://github.com/octocat/Hello-World/issues/42',
                  createdAt: new Date().toISOString(),
                },
              ],
              files: [
                {
                  name: 'README.md',
                  path: 'README.md',
                  sha: 'sha123',
                  htmlUrl: 'https://github.com/octocat/Hello-World/blob/main/README.md',
                },
              ],
              fetchedAt: new Date().toISOString(),
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
    }

    if (url.endsWith('/api/engine/connectors')) {
      return new Response(
        JSON.stringify({
          connectors: [
            {
              id: 'github',
              label: 'GitHub',
              availability: 'AVAILABLE',
              declaredPermissions: ['read'],
              grantedPermissions: ['read'],
            },
          ],
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    return new Response(JSON.stringify({ error: 'not found' }), { status: 404 });
  };

  const client = new GitHubConnectorClient({
    baseUrl: 'https://hub.local',
    authToken: 'test-hub-bearer-token-32-chars-long',
    fetchImpl: mockFetch,
  });

  // 1. Check status
  const status = await client.checkStatus();
  assert.equal(status, 'CONNECTED');
  assert.equal(recordedCalls[0].url, 'https://hub.local/api/engine/connectors');
  assert.equal(recordedCalls[0].headers.Authorization, 'Bearer test-hub-bearer-token-32-chars-long');

  // 2. Fetch repo metadata
  const repoMeta = await client.getRepositoryMetadata('octocat', 'Hello-World');
  assert.equal(repoMeta.fullName, 'octocat/Hello-World');
  assert.equal(repoMeta.stars, 120);
  assert.equal(recordedCalls[1].url, 'https://hub.local/api/engine/connectors/github');
  assert.equal(recordedCalls[1].body.action, 'get_repo');
  assert.deepEqual(recordedCalls[1].body.input, { owner: 'octocat', repo: 'Hello-World' });

  // 3. List issues
  const issuesResult = await client.listIssues({ owner: 'octocat', repo: 'Hello-World', state: 'open' });
  assert.equal(issuesResult.count, 1);
  assert.equal(issuesResult.issues[0].number, 101);
  assert.equal(recordedCalls[2].body.action, 'list_issues');

  // 4. Get file content
  const fileResult = await client.getFileContent({ owner: 'octocat', repo: 'Hello-World', path: 'README.md' });
  assert.equal(fileResult.path, 'README.md');
  assert.match(fileResult.content, /Hello from Mock GitHub File/);
  assert.equal(recordedCalls[3].body.action, 'get_file');

  // 5. Get Readme shortcut
  const readmeResult = await client.getReadme('octocat', 'Hello-World');
  assert.equal(readmeResult.path, 'README.md');

  // 6. Search
  const searchResult = await client.search({ owner: 'octocat', repo: 'Hello-World', query: 'parser' });
  assert.equal(searchResult.count, 2);
  assert.equal(searchResult.issues[0].number, 42);
  assert.equal(searchResult.files[0].path, 'README.md');
});

test('GitHubConnectorClient strictly validates required inputs and throws descriptive errors', async () => {
  const client = new GitHubConnectorClient();

  await assert.rejects(
    () => client.getRepositoryMetadata('', 'repo'),
    /Owner and repo are required/
  );

  await assert.rejects(
    () => client.listIssues({ owner: 'owner', repo: '' }),
    /Owner and repo are required/
  );

  await assert.rejects(
    () => client.getFileContent({ owner: 'owner', repo: 'repo', path: '' }),
    /Owner, repo, and path are required/
  );

  await assert.rejects(
    () => client.search({ owner: '', repo: 'repo', query: 'test' }),
    /Owner, repo, and query are required/
  );
});
