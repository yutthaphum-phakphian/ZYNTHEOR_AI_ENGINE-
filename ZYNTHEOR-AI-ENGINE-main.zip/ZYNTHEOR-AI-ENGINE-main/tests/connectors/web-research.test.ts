import test from "node:test";
import assert from "node:assert/strict";
import { ConnectorHub } from "../../server/connectorHub.js";
import { createWebResearchAdapter, type WebResearchFetchResult } from "../../server/connectors/webResearch.js";
import { declareDefaultConnectors } from "../../server/engineRoutes.js";

/** Minimal mock Response-like object. */
function mockResponse(opts: {
  status?: number;
  headers?: Record<string, string>;
  body?: string | Uint8Array;
  statusText?: string;
}): Response {
  const status = opts.status ?? 200;
  const headers = new Headers(opts.headers ?? { "content-type": "text/html; charset=utf-8" });
  const bodyBytes = typeof opts.body === "string"
    ? new TextEncoder().encode(opts.body)
    : opts.body ?? new Uint8Array();
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: opts.statusText ?? "",
    headers,
    body: {
      getReader() {
        let done = false;
        return {
          async read() {
            if (done) return { done: true as const, value: undefined };
            done = true;
            return { done: false as const, value: bodyBytes };
          },
          cancel() { done = true; },
        };
      },
    },
    async arrayBuffer() {
      return bodyBytes.buffer.slice(bodyBytes.byteOffset, bodyBytes.byteOffset + bodyBytes.byteLength);
    },
    async text() {
      return new TextDecoder().decode(bodyBytes);
    },
  } as unknown as Response;
}

test("web_research adapter reports AVAILABLE and is registered by declareDefaultConnectors", async () => {
  const hub = new ConnectorHub();
  declareDefaultConnectors(hub);
  const list = await hub.list();
  const wr = list.find((c) => c.id === "web_research");
  assert.ok(wr, "web_research present");
  assert.equal(wr!.availability, "AVAILABLE");
  assert.ok(wr!.grantedPermissions.includes("read"));
  // Placeholders still honest
  assert.equal(list.find((c) => c.id === "file_store")?.availability, "NOT_INSTALLED");
});

test("fetch_page success returns structured evidence (no phantom data)", async () => {
  const html = "<html><head><title>Example Domain</title></head><body><h1>Hello</h1><p>Research text.</p></body></html>";
  const fetchImpl = async (url: string) => {
    assert.equal(url, "https://example.com/");
    return mockResponse({ body: html });
  };
  const hub = new ConnectorHub();
  hub.register(createWebResearchAdapter({ fetchImpl: fetchImpl as typeof fetch }));
  hub.grant("web_research", "read");

  const r = await hub.invoke(
    "web_research",
    "fetch_page",
    { url: "https://example.com/" },
    { permission: "read" },
  );
  assert.equal(r.status, "SUCCESS");
  const data = r.data as WebResearchFetchResult;
  assert.equal(data.status, 200);
  assert.equal(data.title, "Example Domain");
  assert.match(data.text, /Hello/);
  assert.match(data.text, /Research text/);
  assert.equal(data.url, "https://example.com/");
  assert.ok(data.fetchedAt);
  assert.equal(data.truncated, false);
});

test("blocks private / loopback / credential URLs", async () => {
  const hub = new ConnectorHub();
  hub.register(createWebResearchAdapter({
    fetchImpl: async () => { throw new Error("should not be called"); },
  }));
  hub.grant("web_research", "read");

  for (const url of [
    "http://127.0.0.1/",
    "http://localhost/secret",
    "http://192.168.1.1/",
    "http://10.0.0.5/x",
    "https://user:pass@example.com/",
    "file:///etc/passwd",
    "ftp://example.com/",
  ]) {
    const r = await hub.invoke("web_research", "fetch_page", { url }, { permission: "read" });
    assert.equal(r.status, "FAILED", `expected FAILED for ${url}`);
    assert.ok(r.reason === "ADAPTER_ERROR");
  }
});

test("search parses DuckDuckGo HTML and never fabricates hits", async () => {
  const html = `
    <a class="result__a" href="https://example.com/a">Alpha Result</a>
    <a class="result__snippet">Snippet for alpha</a>
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fb">Beta Result</a>
  `;
  const hub = new ConnectorHub();
  hub.register(createWebResearchAdapter({
    fetchImpl: async () => mockResponse({ body: html, headers: { "content-type": "text/html" } }),
  }));
  hub.grant("web_research", "read");
  const r = await hub.invoke("web_research", "search", { query: "test", maxResults: 5 }, { permission: "read" });
  assert.equal(r.status, "SUCCESS");
  const data = r.data as { results: Array<{ title: string; url: string }>; provider: string };
  assert.equal(data.provider, "duckduckgo_html");
  assert.ok(data.results.length >= 1);
  assert.equal(data.results[0].title, "Alpha Result");
  assert.equal(data.results[0].url, "https://example.com/a");
});

test("HTTP error from remote is FAILED, not SUCCESS", async () => {
  const hub = new ConnectorHub();
  hub.register(createWebResearchAdapter({
    fetchImpl: async () => mockResponse({ status: 404, statusText: "Not Found", body: "missing" }),
  }));
  hub.grant("web_research", "read");
  const r = await hub.invoke(
    "web_research",
    "fetch_page",
    { url: "https://example.com/missing" },
    { permission: "read" },
  );
  assert.equal(r.status, "FAILED");
  assert.match(r.message, /404/);
});

test("permission still enforced: no grant → DENIED", async () => {
  const hub = new ConnectorHub();
  hub.register(createWebResearchAdapter());
  // deliberately do not grant
  const r = await hub.invoke(
    "web_research",
    "fetch_page",
    { url: "https://example.com/" },
    { permission: "read" },
  );
  assert.equal(r.status, "DENIED");
  assert.equal(r.reason, "PERMISSION_NOT_GRANTED");
});

test("mode selector still surfaces web_research and resolve shows AVAILABLE after install", async () => {
  const { selectEngineMode, resolveConnectorHints } = await import("../../server/modeSelector.js");
  const d = selectEngineMode("ช่วยค้นหาข้อมูล research จากเว็บให้หน่อย");
  assert.ok(d.connectorHints.includes("web_research"));
  const hub = new ConnectorHub();
  declareDefaultConnectors(hub);
  const resolved = await resolveConnectorHints(hub, d.connectorHints);
  const wr = resolved.find((x) => x.hint === "web_research");
  assert.equal(wr?.availability, "AVAILABLE");
});
