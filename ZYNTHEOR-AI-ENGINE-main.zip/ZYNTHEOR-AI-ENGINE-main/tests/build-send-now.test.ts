import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (p: string) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const app = read('src/App.tsx');
const build = read('src/components/views/UnifiedBuildView.tsx');
const panel = read('src/components/WorkspacePanel.tsx');

test('Build panel can send the instruction directly, and still offers handoff to the chat box', () => {
  assert.match(build, /data-testid="build-send-now"/);
  assert.match(build, /onSendBuildPromptNow\(instruction\)/);
  assert.match(build, /onSendBuildPrompt\(instruction\)/);
  assert.match(panel, /onSendBuildPromptNow=\{onSendBuildPromptNow\}/);
});

test('direct send goes through the normal sendMessage path (consent and checks are not bypassed)', () => {
  assert.match(app, /onSendBuildPromptNow=\{\(prompt\) =>/);
  assert.match(app, /setPendingBuildSend\(prompt\)/);
  assert.match(app, /draft !== pendingBuildSend \|\| activeMode !== 'code'/);
  assert.match(app, /void sendMessage\(\);/);
  assert.match(app, /providerChoice !== 'local' && !providerConsent/, 'consent gate still present in sendMessage');
  assert.match(app, /if \(sending\) \{\s*setNotice\(/, 'does not interrupt an in-flight reply');
});

test('workspace tabs and build form are phone-friendly', () => {
  assert.match(panel, /role="tablist" className="flex min-w-0 flex-1 gap-1 overflow-x-auto whitespace-nowrap/);
  assert.match(panel, /safe-area-inset-top/);
  assert.match(build, /grid w-full grid-cols-3/);
  assert.match(build, /text-base sm:text-sm/, 'textarea is 16px on phones so browsers do not zoom on focus');
  assert.match(build, /window\.innerWidth < 1024 \? 'code-only' : 'split'/);
});
