import test, { describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { ENGINE_MODE_OPTIONS, UNSUPPORTED_MODES, toChatMode, toPreferredDepth, modeLabel } from '../src/utils/engineModes.js';

const read = (p: string) => readFileSync(new URL(p, import.meta.url), 'utf8');

describe('Chat mode sheet: modes map to real backend behavior', () => {
  test('every selectable mode maps to a mode the Core accepts', () => {
    const routes = read('../server/engineRoutes.ts');
    const allowed = new Set((routes.match(/ALLOWED_MODES = new Set\(\[([^\]]+)\]/)?.[1] ?? '').match(/"([a-z]+)"/g)?.map((m) => m.replace(/"/g, '')));
    assert.ok(allowed.size > 0, 'could not read ALLOWED_MODES');
    for (const o of ENGINE_MODE_OPTIONS) {
      assert.ok(allowed.has(toChatMode(o.id)), `${o.id} -> ${toChatMode(o.id)} is not accepted by /api/engine routes`);
    }
  });

  test('mapping is stable for each mode', () => {
    assert.equal(toChatMode('auto'), 'auto');
    assert.equal(toChatMode('planning'), 'plan');
    assert.equal(toChatMode('coding'), 'code');
    assert.equal(toChatMode('review'), 'review');
    assert.equal(toChatMode('custom'), 'custom');
    assert.equal(toChatMode('fast'), 'auto');
    assert.equal(toChatMode('deep'), 'auto');
    assert.equal(toPreferredDepth('fast'), 'FAST');
    assert.equal(toPreferredDepth('deep'), 'DEEP');
    assert.equal(toPreferredDepth('planning'), undefined);
  });

  test('unsupported modes are never selectable', () => {
    const selectable = new Set(ENGINE_MODE_OPTIONS.map((o) => o.id as string));
    for (const m of UNSUPPORTED_MODES) assert.ok(!selectable.has(m.id), `${m.id} must not be selectable`);
    assert.deepEqual(UNSUPPORTED_MODES.map((m) => m.id), ['analyze', 'research', 'debug', 'creative']);
  });

  test('labels exist for every mode', () => {
    for (const o of ENGINE_MODE_OPTIONS) assert.ok(modeLabel(o.id).length > 0);
  });
});

describe('Chat mode sheet: wiring (single conversation, no duplicate bars)', () => {
  const chat = read('../src/components/ChatWorkspace.tsx');
  test('the chip replaces the old Chat|Planning tab strip above the input', () => {
    assert.ok(chat.includes('<ChatModeSheet'));
    assert.ok(!chat.includes('aria-label="Chat or Planning mode"'), 'old two-tab strip must be gone');
  });
  test('the legacy selector keeps only Custom config and route info', () => {
    assert.ok(/<EngineModeSelector[\s\S]*?hideModeButtons[\s\S]*?\/>/.test(chat));
  });
  test('changing mode does not reset the conversation', () => {
    const sheet = read('../src/components/ChatModeSheet.tsx');
    assert.ok(!/setMessages|clearConversation|setAttachedFiles|onClear/.test(sheet), 'sheet must not touch history or attachments');
    assert.ok(sheet.includes('onChange(o.id)'));
  });
  test('the chosen mode is still what is sent to /api/chat', () => {
    assert.ok((chat.match(/mode: toChatMode\(engineChoice\)/g) ?? []).length >= 3);
  });
});
