import test from "node:test";
import assert from "node:assert/strict";
import { ConnectorHub, type ConnectorAdapter } from "../server/connectorHub.js";
import { selectEngineMode, resolveConnectorHints } from "../server/modeSelector.js";

// ---- Test adapters (clearly fake; they exist only inside this test file) ----
function adapter(over: Partial<ConnectorAdapter> = {}): ConnectorAdapter {
  return {
    id: "demo", label: "Demo", permissions: ["read", "write", "call_api"],
    checkAvailability: async () => ({ available: true }),
    invoke: async (action) => ({ echoed: action }),
    ...over,
  };
}

test("declared-but-not-installed connector is NOT_INSTALLED and every call is UNAVAILABLE", async () => {
  const hub = new ConnectorHub();
  hub.declare({ id: "github", label: "GitHub", permissions: ["read", "write"] });
  const [view] = await hub.list();
  assert.deepEqual([view.id, view.availability], ["github", "NOT_INSTALLED"]);
  const r = await hub.invoke("github", "list_repos", {}, { permission: "read" });
  assert.deepEqual([r.status, r.reason], ["UNAVAILABLE", "NOT_INSTALLED"]);
  assert.equal((await hub.invoke("ghost", "x", {}, { permission: "read" })).reason, "UNKNOWN_CONNECTOR");
});

test("permissions are per connector and per class: undeclared/ungranted → DENIED; write needs approval", async () => {
  const hub = new ConnectorHub();
  hub.register(adapter());
  assert.equal((await hub.invoke("demo", "a", {}, { permission: "mutate_system" })).reason, "PERMISSION_NOT_DECLARED");
  assert.equal((await hub.invoke("demo", "a", {}, { permission: "read" })).reason, "PERMISSION_NOT_GRANTED");
  assert.equal(hub.grant("demo", "mutate_system"), false, "cannot grant an undeclared permission");
  hub.grant("demo", "read"); hub.grant("demo", "write");
  assert.equal((await hub.invoke("demo", "a", {}, { permission: "read" })).status, "SUCCESS");
  const w = await hub.invoke("demo", "a", {}, { permission: "write" });
  assert.deepEqual([w.status, w.reason], ["DENIED", "APPROVAL_REQUIRED"]);
  assert.equal((await hub.invoke("demo", "a", {}, { permission: "write", approved: true })).status, "SUCCESS");
  hub.revoke("demo", "read");
  assert.equal((await hub.invoke("demo", "a", {}, { permission: "read" })).status, "DENIED");
});

test("unavailable adapter → UNAVAILABLE; adapter throwing → FAILED with redacted message; slow adapter → TIMEOUT", async () => {
  const hub = new ConnectorHub();
  hub.register(adapter({ id: "down", checkAvailability: async () => ({ available: false, reason: "service offline" }) }));
  hub.register(adapter({ id: "boom", invoke: async () => { throw new Error("failed with password=hunter2hunter2"); } }));
  hub.register(adapter({ id: "slow", invoke: (_a, _i, { signal }) => new Promise((_r, rej) => signal.addEventListener("abort", () => rej(new Error("x")))) }));
  for (const id of ["down", "boom", "slow"]) hub.grant(id, "read");
  assert.equal((await hub.invoke("down", "a", {}, { permission: "read" })).status, "UNAVAILABLE");
  const b = await hub.invoke("boom", "a", {}, { permission: "read" });
  assert.equal(b.status, "FAILED");
  assert.ok(!b.message.includes("hunter2hunter2"));
  assert.equal((await hub.invoke("slow", "a", {}, { permission: "read", timeoutMs: 20 })).status, "TIMEOUT");
  assert.equal(hub.auditLog().length, 3, "every call is audited");
});

test("list() reports AVAILABLE/UNAVAILABLE from a real availability check, not from registration", async () => {
  const hub = new ConnectorHub();
  hub.register(adapter({ id: "up" }));
  hub.register(adapter({ id: "down", checkAvailability: async () => { throw new Error("nope"); } }));
  const byId = Object.fromEntries((await hub.list()).map((c) => [c.id, c.availability]));
  assert.deepEqual(byId, { down: "UNAVAILABLE", up: "AVAILABLE" });
});

test("mode selector: short read-only question → FAST", () => {
  const d = selectEngineMode("สวัสดี วันนี้เป็นไงบ้าง");
  assert.equal(d.depth, "FAST");
  assert.equal(d.riskLevel, "LOW");
  assert.equal(d.requiresApproval, false);
});

test("mode selector: code change, build, plan, long or multi-step requests → DEEP with reasons", () => {
  assert.equal(selectEngineMode("แก้ไฟล์ server/agent.ts ให้หน่อย").depth, "DEEP");
  assert.equal(selectEngineMode("แก้ไฟล์ server/agent.ts ให้หน่อย").requiresApproval, true);
  assert.equal(selectEngineMode("run the build").depth, "DEEP");
  assert.equal(selectEngineMode("hello", "plan").depth, "DEEP");
  assert.equal(selectEngineMode("x".repeat(700)).depth, "DEEP");
  const multi = selectEngineMode("ช่วยวิเคราะห์ก่อน แล้วเปรียบเทียบสถาปัตยกรรมสองแบบ");
  assert.equal(multi.depth, "DEEP");
  assert.ok(multi.reasons.length > 0);
});

test("mode selector: unsupported requests are DEEP and flagged unsupported", () => {
  const d = selectEngineMode("deploy to kubernetes now");
  assert.deepEqual([d.depth, d.supported], ["DEEP", false]);
});

test("connector hints → DEEP, and resolve against the hub's real status", async () => {
  const d = selectEngineMode("ดู pull request ล่าสุดใน github ให้หน่อย");
  assert.equal(d.depth, "DEEP");
  assert.ok(d.connectorHints.includes("github"));
  const hub = new ConnectorHub();
  assert.deepEqual(await resolveConnectorHints(hub, d.connectorHints), [{ hint: "github", availability: "NOT_INSTALLED" }]);
  hub.register(adapter({ id: "github" }));
  assert.equal((await resolveConnectorHints(hub, ["github"]))[0].availability, "AVAILABLE");
});
