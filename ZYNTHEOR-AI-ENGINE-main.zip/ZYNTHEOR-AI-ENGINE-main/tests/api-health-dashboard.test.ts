import { test } from 'node:test';
import assert from 'node:assert/strict';

test('Routing Enforcement Flow contains all 4 sequential phases', () => {
  const phases = [
    { phase: 1, name: 'Initialization Phase' },
    { phase: 2, name: 'Enforcement Phase' },
    { phase: 3, name: 'Verification Phase' },
    { phase: 4, name: 'Governance & Compliance' },
  ];

  assert.equal(phases.length, 4);
  assert.equal(phases[0].phase, 1);
  assert.equal(phases[3].phase, 4);
});

test('Enforcement Phase guarantees fail-closed and prevents silent external leaks', () => {
  const fallbackPolicy = {
    allowSilentCloudFallback: false,
    failClosed: true,
    recordAuditLog: true,
  };

  assert.equal(fallbackPolicy.allowSilentCloudFallback, false, 'Must never allow silent cloud fallback');
  assert.equal(fallbackPolicy.failClosed, true, 'Must fail closed with explicit status');
  assert.equal(fallbackPolicy.recordAuditLog, true, 'Must record audit log on rejection');
});

test('Compliance phase covers ETDA Sections 9, 26, 28 and PDPA Enclave', () => {
  const complianceStandards = {
    etdaSection9: 'Electronic Signature & Verifiable Records',
    etdaSection26: 'State-of-the-Art Secure System Methods',
    etdaSection28: 'System Custodian Access & Audit Trails',
    pdpaEnclave: 'Zyrquen Enclave Personal Data Segregation',
  };

  assert.ok(complianceStandards.etdaSection9.includes('Records'));
  assert.ok(complianceStandards.etdaSection26.includes('Secure System'));
  assert.ok(complianceStandards.etdaSection28.includes('Audit Trails'));
  assert.ok(complianceStandards.pdpaEnclave.includes('Enclave'));
});
