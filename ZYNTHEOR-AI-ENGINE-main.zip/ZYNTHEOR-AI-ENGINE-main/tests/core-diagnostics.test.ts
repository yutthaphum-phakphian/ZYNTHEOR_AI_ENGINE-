import test, { describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { runCoreDiagnostics } from '../server/coreDiagnostics.js';

let server: http.Server;
let base = '';
let mode: 'ollama' | 'empty' | 'openai' | 'http500' | 'slow' = 'ollama';
const hits: string[] = [];

before(async () => {
  server = http.createServer((req, res) => {
    hits.push(`${req.method} ${req.url}`);
    const json = (code: number, body: unknown) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
    if (mode === 'http500') return json(500, { error: 'boom' });
    if (mode === 'slow') return; // never answers
    if (mode === 'openai') {
      if (req.url === '/v1/models') return json(200, { data: [{ id: 'local-gguf' }] });
      if (req.url === '/v1/chat/completions') return json(200, { choices: [{ message: { content: 'pong' } }] });
      return json(404, {});
    }
    if (req.url === '/api/tags') return json(200, { models: mode === 'empty' ? [] : [{ name: 'llama3.2:latest' }] });
    if (req.url === '/api/chat') return json(200, { message: { content: 'pong' } });
    return json(404, {});
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(() => new Promise<void>((r) => { server.closeAllConnections?.(); server.close(() => r()); }));

const stage = (r: Awaited<ReturnType<typeof runCoreDiagnostics>>, id: string) => r.stages.find((s) => s.id === id)!;

describe('Core Connection Diagnostics', () => {
  test('runtime unreachable -> FAIL with the real error code; later stages NOT_TESTED', async () => {
    // Grab a real free port and close it, so the OS refuses the connection (fetch itself blocks port 1).
    const probe = http.createServer();
    await new Promise<void>((r) => probe.listen(0, '127.0.0.1', r));
    const closedPort = (probe.address() as AddressInfo).port;
    await new Promise<void>((r) => probe.close(() => r()));
    const r = await runCoreDiagnostics({ endpoint: `http://127.0.0.1:${closedPort}`, timeoutMs: 800 });
    assert.equal(stage(r, 'core_api').status, 'PASS');
    assert.equal(stage(r, 'runtime_reachable').status, 'FAIL');
    assert.equal(stage(r, 'runtime_reachable').code, 'ECONNREFUSED');
    assert.equal(stage(r, 'model_present').status, 'NOT_TESTED');
    assert.equal(stage(r, 'inference').status, 'NOT_TESTED');
    assert.equal(r.firstFailure, 'runtime_reachable');
    assert.equal(r.overall, 'FAIL');
  });

  test('runtime answers with HTTP error -> code carries the HTTP status', async () => {
    mode = 'http500';
    const r = await runCoreDiagnostics({ endpoint: base });
    assert.equal(stage(r, 'runtime_reachable').status, 'FAIL');
    assert.equal(stage(r, 'runtime_reachable').code, 'HTTP_500');
  });

  test('runtime hangs -> TIMEOUT', async () => {
    mode = 'slow';
    const r = await runCoreDiagnostics({ endpoint: base, timeoutMs: 300 });
    assert.equal(stage(r, 'runtime_reachable').code, 'TIMEOUT');
  });

  test('runtime up but no models -> model_present FAIL NO_MODELS', async () => {
    mode = 'empty';
    const r = await runCoreDiagnostics({ endpoint: base });
    assert.equal(stage(r, 'runtime_reachable').status, 'PASS');
    assert.equal(stage(r, 'model_present').code, 'NO_MODELS');
  });

  test('configured model missing -> CONFIGURED_MODEL_MISSING', async () => {
    mode = 'ollama';
    const r = await runCoreDiagnostics({ endpoint: base, configuredModel: 'qwen2.5:7b' });
    assert.equal(stage(r, 'model_present').code, 'CONFIGURED_MODEL_MISSING');
  });

  test('inference is NOT_TESTED unless requested, and never runs the model by default', async () => {
    mode = 'ollama';
    hits.length = 0;
    const r = await runCoreDiagnostics({ endpoint: base });
    assert.equal(stage(r, 'inference').status, 'NOT_TESTED');
    assert.ok(!hits.some((h) => h.includes('/api/chat')));
    assert.equal(r.overall, 'PARTIAL');
  });

  test('infer requested without a model: Core does not pick one silently', async () => {
    mode = 'ollama';
    hits.length = 0;
    const r = await runCoreDiagnostics({ endpoint: base, infer: true });
    assert.equal(stage(r, 'inference').status, 'NOT_TESTED');
    assert.equal(stage(r, 'inference').code, 'NO_MODEL_SELECTED');
    assert.ok(!hits.some((h) => h.includes('/api/chat')));
  });

  test('real inference on an installed model -> PASS (Ollama)', async () => {
    mode = 'ollama';
    const r = await runCoreDiagnostics({ endpoint: base, infer: true, requestedModel: 'llama3.2:latest' });
    assert.equal(stage(r, 'inference').status, 'PASS');
    assert.equal(r.overall, 'PASS');
    assert.equal(r.runtimeKind, 'ollama');
  });

  test('real inference works through the OpenAI-compatible local server', async () => {
    mode = 'openai';
    const r = await runCoreDiagnostics({ endpoint: base, infer: true, requestedModel: 'local-gguf' });
    assert.equal(r.runtimeKind, 'openai-compatible');
    assert.equal(stage(r, 'inference').status, 'PASS');
  });

  test('requested model not installed -> FAIL MODEL_NOT_INSTALLED', async () => {
    mode = 'ollama';
    const r = await runCoreDiagnostics({ endpoint: base, infer: true, requestedModel: 'ghost' });
    assert.equal(stage(r, 'inference').code, 'MODEL_NOT_INSTALLED');
  });

  test('provider routing: disabled or non-local provider is reported, never silently switched', async () => {
    mode = 'ollama';
    const off = await runCoreDiagnostics({ endpoint: base, aiProvider: 'none' });
    assert.equal(stage(off, 'provider_routing').code, 'provider_disabled');
    const hosted = await runCoreDiagnostics({ endpoint: base, aiProvider: 'openai' });
    assert.equal(stage(hosted, 'provider_routing').code, 'provider_not_local');
    const local = await runCoreDiagnostics({ endpoint: base, aiProvider: 'local' });
    assert.equal(stage(local, 'provider_routing').status, 'PASS');
  });
});

import { readFileSync } from 'node:fs';
describe('Core diagnostics wiring (source checks)', () => {
  test('route is registered and takes no caller-supplied endpoint', () => {
    const src = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
    const start = src.indexOf("app.get('/api/diagnostics/core'");
    assert.ok(start > 0, 'route must exist');
    const block = src.slice(start, start + 900);
    assert.ok(!/req\.query\.endpoint/.test(block), 'must not accept a caller-supplied endpoint (SSRF)');
  });
  test('panel is mounted in App.tsx without adding a menu entry', () => {
    const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
    assert.ok(app.includes('<CoreDiagnosticsPanel'));
    const panel = readFileSync(new URL('../src/components/CoreDiagnosticsPanel.tsx', import.meta.url), 'utf8');
    assert.ok(panel.includes('data-testid="core-diagnostics-panel"'));
  });
});
