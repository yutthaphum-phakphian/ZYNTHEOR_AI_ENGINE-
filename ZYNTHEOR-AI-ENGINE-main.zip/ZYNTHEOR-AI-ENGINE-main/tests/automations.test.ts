import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { createApp } from "../server.js";

test("Automations API: CRUD and trigger workflow with real evidence and secret redaction", async (t) => {
  const app = await createApp({ skipVite: true });
  const server = http.createServer(app);

  await new Promise<void>((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve());
  });

  const address = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${address.port}`;

  t.after(() => {
    server.close();
  });

  // 1. Validation: reject automation without name or prompt
  const resBad = await fetch(`${baseUrl}/api/automations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: "", prompt: "" }),
  });
  assert.equal(resBad.status, 400);

  // 2. Create valid automation with webhook link and prompt
  const resCreate = await fetch(`${baseUrl}/api/automations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Auto Build & Verify",
      icon: "⚡",
      triggerType: "webhook",
      prompt: "ตรวจสอบความถูกต้องของสถาปัตยกรรมเว็บไซต์",
      mode: "fast",
      notifications: { push: true, emailOrWebhook: false },
    }),
  });
  assert.equal(resCreate.status, 201);
  const createData = (await resCreate.json()) as any;
  assert.equal(createData.status, "created");
  assert.ok(createData.automation.id);
  assert.equal(createData.automation.name, "Auto Build & Verify");
  assert.equal(createData.automation.enabled, true);
  const autoId = createData.automation.id;

  // 3. List automations and verify presence
  const resList = await fetch(`${baseUrl}/api/automations`);
  assert.equal(resList.status, 200);
  const listData = (await resList.json()) as any;
  assert.ok(Array.isArray(listData.automations));
  const found = listData.automations.find((a: any) => a.id === autoId);
  assert.ok(found, "Created automation must be present in GET /api/automations");

  // 4. Update automation via PATCH
  const resPatch = await fetch(`${baseUrl}/api/automations/${autoId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Auto Build & Verify Renamed",
    }),
  });
  assert.equal(resPatch.status, 200);
  const patchData = (await resPatch.json()) as any;
  assert.equal(patchData.automation.name, "Auto Build & Verify Renamed");

  // 5. Trigger automation via POST /api/automations/:id/trigger
  const resTrigger = await fetch(`${baseUrl}/api/automations/${autoId}/trigger`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ triggerSource: "webhook" }),
  });
  assert.equal(resTrigger.status, 200);
  const triggerData = (await resTrigger.json()) as any;
  assert.ok(triggerData.status === "SUCCESS" || triggerData.status === "FAILED");
  assert.ok(triggerData.log);
  assert.equal(triggerData.log.triggerSource, "webhook");
  assert.ok(typeof triggerData.log.durationMs === "number");
  assert.ok(triggerData.automation.lastRunAt);
  assert.equal(triggerData.automation.executionLogs.length, 1);

  // 6. Disable automation and ensure trigger is blocked
  await fetch(`${baseUrl}/api/automations/${autoId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ enabled: false }),
  });
  const resDisabledTrigger = await fetch(`${baseUrl}/api/automations/${autoId}/trigger`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
  });
  assert.equal(resDisabledTrigger.status, 400);

  // 7. Delete automation
  const resDelete = await fetch(`${baseUrl}/api/automations/${autoId}`, {
    method: "DELETE",
  });
  assert.equal(resDelete.status, 200);

  // Verify deletion
  const resNotFound = await fetch(`${baseUrl}/api/automations/${autoId}/trigger`, {
    method: "POST",
  });
  assert.equal(resNotFound.status, 404);
});
