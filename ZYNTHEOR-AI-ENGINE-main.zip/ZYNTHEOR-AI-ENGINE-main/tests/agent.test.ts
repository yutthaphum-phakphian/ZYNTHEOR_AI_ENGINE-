import test, { after } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  AgentError,
  approvePlan,
  createPlan,
  dependenciesSatisfied,
  executePlan,
  getPlan,
  getTool,
  listAuditEvents,
  listTools,
  recordPlanRejection,
  requestPlanApproval,
  revisePlan,
  type Plan,
  type PlanStep,
  verifyToolResult,
  validatePlannerOutput,
  type PlanDraft
} from "../server/agent.js";
import { saveAgentEvent } from "../server/store.js";

const previousStorePath = process.env.CHAT_STORE_PATH;
const tempDir = await mkdtemp(join(tmpdir(), "apphub-agent-core-test-"));
process.env.CHAT_STORE_PATH = join(tempDir, "ledger.jsonl");
after(async () => {
  if (previousStorePath === undefined) delete process.env.CHAT_STORE_PATH;
  else process.env.CHAT_STORE_PATH = previousStorePath;
  await rm(tempDir, { recursive: true, force: true });
});

const validStep = (id: string, dependsOn: string[] = []) => ({
  id,
  tool: "get_time",
  input: {},
  dependsOn,
  successCondition: "result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt"
});
const draft = (steps: unknown[] = [validStep("clock")]): PlanDraft => ({ goal: "Read current time", steps });

test("rejects unregistered tools and malformed or unauthorized plans", async () => {
  assert.deepEqual(listTools().map((tool) => tool.name), ["get_time", "check_local_runtime"]);
  assert.equal(listTools().find((tool) => tool.name === "get_time")?.availability, "AVAILABLE");
  const runtimeTool = getTool("check_local_runtime");
  assert.ok(runtimeTool);
  assert.equal(runtimeTool?.permission, "read:local-runtime");
  assert.equal(runtimeTool?.risk, "LOW");
  assert.equal(runtimeTool?.available, true);
  assert.equal(runtimeTool?.inputSchema.additionalProperties, false);
  assert.deepEqual(listTools()[0].inputSchema, {
    type: "object", properties: {}, required: [], additionalProperties: false
  });
  await assert.rejects(
    createPlan(draft([{ ...validStep("shell"), tool: "shell" }])),
    (error: unknown) => error instanceof AgentError && error.code === "tool_unavailable"
  );
  await assert.rejects(
    createPlan(draft([{ ...validStep("clock"), input: { command: "id" } }])),
    (error: unknown) => error instanceof AgentError && error.code === "invalid_plan"
  );
  await assert.rejects(
    createPlan({ goal: "", steps: [validStep("clock")] }),
    (error: unknown) => error instanceof AgentError && error.code === "invalid_plan"
  );
  await assert.rejects(
    createPlan(draft([{ ...validStep("clock"), successCondition: "success" }])),
    (error: unknown) => error instanceof AgentError && error.code === "invalid_plan"
  );
});

test("accepts a strictly shaped planner result and persists its source, risk, tools, and criteria", async () => {
  const valid = {
    goal: "Read the current time",
    riskLevel: "LOW",
    successCriteria: ["A valid timestamp is verified."],
    steps: [validStep("clock")]
  };
  const plan = await createPlan(validatePlannerOutput(valid), "ai");
  assert.equal(plan.source, "ai");
  assert.equal(plan.riskLevel, "LOW");
  assert.deepEqual(plan.requiredTools, ["get_time"]);
  assert.deepEqual(plan.successCriteria, ["A valid timestamp is verified."]);
  assert.match(plan.hash, /^[a-f0-9]{64}$/);

  for (const invalid of [
    { ...valid, extra: "not allowed" },
    { ...valid, riskLevel: "EXTREME" },
    { ...valid, successCriteria: [] }
  ]) {
    assert.throws(() => validatePlannerOutput(invalid), AgentError);
  }
  for (const invalid of [
    { ...valid, steps: [{ ...validStep("clock"), input: { command: "id" } }] },
    { ...valid, steps: [{ ...validStep("clock"), tool: "shell" }] }
  ]) {
    await assert.rejects(createPlan(validatePlannerOutput(invalid), "ai"), AgentError);
  }
});

test("validates dependencies and schedules prerequisite steps first", async () => {
  await assert.rejects(
    createPlan(draft([validStep("clock", ["missing"])])),
    (error: unknown) => error instanceof AgentError && error.code === "invalid_plan"
  );
  await assert.rejects(
    createPlan(draft([validStep("first", ["second"]), validStep("second", ["first"])])),
    (error: unknown) => error instanceof AgentError && error.code === "invalid_plan"
  );
  const plan = await createPlan(draft([validStep("second", ["first"]), validStep("first")]));
  assert.deepEqual(plan.steps.map((step) => step.id), ["first", "second"]);
});

test("approval requires the current plan hash, explicit submission, and one-time execution", async () => {
  const proposed = await createPlan(draft());
  assert.equal(proposed.status, "PROPOSED");
  await assert.rejects(
    approvePlan(proposed.id, proposed.hash),
    (error: unknown) => error instanceof AgentError && error.code === "plan_not_approvable"
  );
  const waiting = await requestPlanApproval(proposed.id);
  assert.equal(waiting.status, "WAITING_APPROVAL");
  await assert.rejects(
    approvePlan(proposed.id, "0".repeat(64)),
    (error: unknown) => error instanceof AgentError && error.code === "approval_mismatch"
  );
  const approved = await approvePlan(proposed.id, proposed.hash);
  assert.equal(approved.status, "APPROVED");
  await assert.rejects(
    executePlan(proposed.id, "not-the-approval"),
    (error: unknown) => error instanceof AgentError && error.code === "approval_mismatch"
  );
  const completed = await executePlan(proposed.id, approved.approval?.id);
  assert.equal(completed.status, "SUCCEEDED");
  assert.equal(completed.steps[0].status, "SUCCEEDED");
  assert.equal(completed.steps[0].verification?.status, "VERIFIED");
  assert.equal(completed.steps[0].result?.value.isoTimestamp, completed.steps[0].result?.observedAt);
  const events = await listAuditEvents();
  for (const type of ["plan_proposed", "approval_requested", "plan_approved", "plan_execution_started", "step_execution_finished", "plan_execution_finished"]) {
    assert.ok(events.some((event) => event.type === type), `Expected audit event: ${type}`);
  }
  await assert.rejects(
    executePlan(proposed.id, approved.approval?.id),
    (error: unknown) => error instanceof AgentError && error.code === "approval_replayed"
  );
});

test("parallel duplicate execution requests cannot reuse one approval", async () => {
  const plan = await createPlan(draft());
  await requestPlanApproval(plan.id);
  const approved = await approvePlan(plan.id, plan.hash);
  const results = await Promise.allSettled([
    executePlan(plan.id, approved.approval?.id),
    executePlan(plan.id, approved.approval?.id)
  ]);
  assert.equal(results.filter((result) => result.status === "fulfilled").length, 1);
  const rejected = results.find((result): result is PromiseRejectedResult => result.status === "rejected");
  assert.ok(rejected?.reason instanceof AgentError);
  assert.equal(rejected.reason.code, "approval_replayed");
});

test("revision invalidates the earlier approval and changes the plan hash", async () => {
  const plan = await createPlan(draft());
  await requestPlanApproval(plan.id);
  const approval = await approvePlan(plan.id, plan.hash);
  const revised = await revisePlan(plan.id, { goal: "Read current server time", steps: [validStep("clock")] });
  assert.equal(revised.status, "PROPOSED");
  assert.notEqual(revised.hash, plan.hash);
  await assert.rejects(
    executePlan(plan.id, approval.approval?.id),
    (error: unknown) => error instanceof AgentError && error.code === "approval_mismatch"
  );
  await assert.rejects(
    approvePlan(plan.id, plan.hash),
    (error: unknown) => error instanceof AgentError && error.code === "approval_mismatch"
  );
});

test("rejection is persisted and prevents execution", async () => {
  const plan = await createPlan(draft());
  await requestPlanApproval(plan.id);
  await recordPlanRejection(plan.id);
  assert.equal((await getPlan(plan.id)).status, "BLOCKED");
  await assert.rejects(
    executePlan(plan.id, "anything"),
    (error: unknown) => error instanceof AgentError
  );
  assert.ok((await listAuditEvents()).some((event) => event.type === "approval_rejected"));
});

test("evidence verifier does not call missing or invalid output successful", () => {
  assert.equal(verifyToolResult("get_time", null).status, "UNKNOWN");
  assert.equal(verifyToolResult("get_time", {
    observedAt: "not-a-time",
    value: { isoTimestamp: "not-a-time" }
  }).status, "FAILED");
  assert.equal(verifyToolResult("unregistered", {}).status, "UNKNOWN");
});

test("dependencies require successful status and separately verified evidence", () => {
  const first: PlanStep = {
    ...validStep("first"),
    status: "FAILED",
    verification: { status: "FAILED", checkedAt: new Date().toISOString(), evidence: "failed" }
  };
  const second: PlanStep = {
    ...validStep("second", ["first"]),
    status: "PENDING"
  };
  assert.equal(dependenciesSatisfied([first, second], second), false);
  first.status = "SUCCEEDED";
  first.verification = { status: "VERIFIED", checkedAt: new Date().toISOString(), evidence: "verified" };
  assert.equal(dependenciesSatisfied([first, second], second), true);
});

test("execution blocks a dependent step when its prerequisite tool is unavailable", async () => {
  const proposed = await createPlan(draft([validStep("first"), validStep("second", ["first"])]));
  await requestPlanApproval(proposed.id);
  const approved = await approvePlan(proposed.id, proposed.hash);
  const interruptedCatalog: Plan = structuredClone(approved);
  interruptedCatalog.steps[0].tool = "unavailable_tool";
  interruptedCatalog.requiredTools = ["unavailable_tool", "get_time"];
  interruptedCatalog.hash = createHash("sha256").update(JSON.stringify({
    id: interruptedCatalog.id,
    goal: interruptedCatalog.goal,
    revision: interruptedCatalog.revision,
    riskLevel: interruptedCatalog.riskLevel,
    requiredTools: interruptedCatalog.requiredTools,
    successCriteria: interruptedCatalog.successCriteria,
    source: interruptedCatalog.source,
    steps: interruptedCatalog.steps.map(({ id, tool, input, dependsOn, successCondition }) => ({
      id, tool, input, dependsOn, successCondition
    }))
  })).digest("hex");
  interruptedCatalog.approval!.planHash = interruptedCatalog.hash;
  await saveAgentEvent({
    id: "unavailable-tool-injected",
    type: "test",
    at: new Date().toISOString(),
    data: { plan: interruptedCatalog }
  });

  const result = await executePlan(proposed.id, interruptedCatalog.approval?.id);
  assert.equal(result.status, "BLOCKED");
  assert.equal(result.steps[0].status, "BLOCKED");
  assert.equal(result.steps[1].status, "BLOCKED");
  assert.equal(result.steps[1].error, undefined);
});

test("plan goal and persisted conversation content redact API keys and secrets", async () => {
  const secret = "not-a-real-placeholder";
  const plan = await createPlan({ ...draft(), goal: `OPENAI_API_KEY=${secret}` });
  assert.doesNotMatch(plan.goal, /not-a-real-placeholder/);
  const ledger = await readFile(process.env.CHAT_STORE_PATH!, "utf8");
  assert.doesNotMatch(ledger, /not-a-real-placeholder/);
  await saveAgentEvent({
    id: "secret-audit-event",
    type: "test",
    at: new Date().toISOString(),
    data: { Authorization: "Bearer fake-token-value", details: "client_secret=fake-secret-value" }
  });
  const redactedLedger = await readFile(process.env.CHAT_STORE_PATH!, "utf8");
  assert.doesNotMatch(redactedLedger, /fake-token-value|fake-secret-value/);
});

test("plan execution state and verified evidence survive a fresh Node process", async () => {
  const plan = await createPlan(draft());
  await requestPlanApproval(plan.id);
  const approved = await approvePlan(plan.id, plan.hash);
  await executePlan(plan.id, approved.approval?.id);
  const script = `import { getPlan } from "./server/agent.ts"; const plan = await getPlan(${JSON.stringify(plan.id)}); console.log(JSON.stringify({ id: plan.id, status: plan.status, hash: plan.hash }));`;
  const child = spawnSync(process.execPath, ["--import", "tsx", "--input-type=module", "-e", script], {
    cwd: process.cwd(),
    encoding: "utf8",
    env: { ...process.env, CHAT_STORE_PATH: process.env.CHAT_STORE_PATH }
  });
  assert.equal(child.status, 0, child.stderr);
  assert.deepEqual(JSON.parse(child.stdout), { id: plan.id, status: "SUCCEEDED", hash: plan.hash });
});

test("an interrupted execution recovers as UNKNOWN rather than success after restart", async () => {
  const plan = await createPlan(draft());
  await requestPlanApproval(plan.id);
  const approved = await approvePlan(plan.id, plan.hash);
  const interrupted: Plan = structuredClone(approved);
  interrupted.status = "RUNNING";
  interrupted.approval!.usedAt = new Date().toISOString();
  interrupted.steps[0].status = "RUNNING";
  await saveAgentEvent({
    id: "simulated-crash-boundary",
    type: "plan_execution_started",
    at: new Date().toISOString(),
    data: { plan: interrupted }
  });
  const script = `import { getPlan } from "./server/agent.ts"; const plan = await getPlan(${JSON.stringify(plan.id)}); console.log(JSON.stringify({ status: plan.status, step: plan.steps[0].status }));`;
  const child = spawnSync(process.execPath, ["--import", "tsx", "--input-type=module", "-e", script], {
    cwd: process.cwd(),
    encoding: "utf8",
    env: { ...process.env, CHAT_STORE_PATH: process.env.CHAT_STORE_PATH }
  });
  assert.equal(child.status, 0, child.stderr);
  assert.deepEqual(JSON.parse(child.stdout), { status: "UNKNOWN", step: "UNKNOWN" });
});

test("legacy v0.3 plan records migrate without retaining stale approvals", async () => {
  const current = await createPlan(draft());
  const legacy: Record<string, unknown> = structuredClone(current);
  delete legacy.riskLevel;
  delete legacy.requiredTools;
  delete legacy.successCriteria;
  delete legacy.source;
  legacy.status = "APPROVED";
  legacy.approval = { id: "old-approval", planHash: current.hash, approvedAt: new Date().toISOString() };
  legacy.hash = createHash("sha256").update(JSON.stringify({
    id: current.id,
    goal: current.goal,
    revision: current.revision,
    steps: current.steps.map(({ id, tool, input, dependsOn, successCondition }) => ({
      id, tool, input, dependsOn, successCondition
    }))
  })).digest("hex");
  await saveAgentEvent({
    id: "legacy-v03-plan",
    type: "plan_approved",
    at: new Date().toISOString(),
    data: { plan: legacy }
  });

  const migrated = await getPlan(current.id);
  assert.equal(migrated.source, "system");
  assert.equal(migrated.status, "PROPOSED");
  assert.equal(migrated.approval, undefined);
  assert.deepEqual(migrated.requiredTools, ["get_time"]);
});
