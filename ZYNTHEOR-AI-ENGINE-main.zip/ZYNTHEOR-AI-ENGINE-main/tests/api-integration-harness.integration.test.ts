import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import { createApp } from '../server.js';

test('API Integration Harness & Observability Suite', async (t) => {
  const tempDir = await mkdtemp(join(tmpdir(), 'zyrquen-api-integration-'));
  const originalChatStore = process.env.CHAT_STORE_PATH;
  process.env.CHAT_STORE_PATH = join(tempDir, 'conversations.jsonl');

  const app = await createApp({ skipVite: true });
  const server = createServer(app);

  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  t.after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    if (originalChatStore) {
      process.env.CHAT_STORE_PATH = originalChatStore;
    } else {
      delete process.env.CHAT_STORE_PATH;
    }
    await rm(tempDir, { recursive: true, force: true });
  });

  // 1. Health check & Observability Correlation Propagation
  await t.test('1. GET /api/health propagates correlation ID and leaks zero secrets', async () => {
    // 1a. Auto-generated correlation ID
    const res1 = await fetch(`${baseUrl}/api/health`);
    assert.equal(res1.status, 200);
    const corr1 = res1.headers.get('x-correlation-id');
    assert.ok(corr1 && corr1.startsWith('corr_'), 'Should generate correlation ID header');
    const body1 = (await res1.json()) as Record<string, unknown>;
    assert.equal(body1.status, 'available');
    assert.equal(body1.correlationId, corr1);
    assert.equal('hasKey' in body1, false);
    assert.equal('gemini' in body1, false);

    // 1b. Custom client correlation ID preserved
    const customCorr = 'custom-trace-req-9999';
    const res2 = await fetch(`${baseUrl}/api/health`, {
      headers: { 'X-Correlation-Id': customCorr },
    });
    assert.equal(res2.status, 200);
    assert.equal(res2.headers.get('x-correlation-id'), customCorr);
    const body2 = (await res2.json()) as Record<string, unknown>;
    assert.equal(body2.correlationId, customCorr);
  });

  // 2. Full Agent Plan Lifecycle with Cryptographic Verification and Correlation Tracing
  await t.test('2. Agent Plan lifecycle enforces cryptographic verification, correlation, and replay guards', async () => {
    const traceId = 'trace-plan-test-' + Date.now();

    // 2a. Create Plan
    const createRes = await fetch(`${baseUrl}/api/plans`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({
        goal: 'Read and verify server time with empirical evidence',
        riskLevel: 'LOW',
        successCriteria: ['Time retrieved with valid ISO timestamp format'],
        steps: [
          {
            id: 'time-step-1',
            tool: 'get_time',
            input: {},
            dependsOn: [],
            successCondition: 'result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt',
          },
        ],
      }),
    });

    assert.equal(createRes.status, 201);
    assert.equal(createRes.headers.get('x-correlation-id'), traceId);
    const createData = (await createRes.json()) as { plan: any; correlationId: string };
    const plan = createData.plan;
    assert.ok(plan && plan.id);
    assert.equal(plan.status, 'PROPOSED');
    assert.equal(plan.correlationId, traceId);
    assert.equal(createData.correlationId, traceId);
    assert.ok(plan.hash && plan.hash.length === 64, 'Plan hash must be SHA-256');

    // 2b. Attempt to execute without approval -> must be rejected with 403
    const prematureExecRes = await fetch(`${baseUrl}/api/plans/${plan.id}/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({ approvalId: 'unapproved_fake_id' }),
    });
    assert.equal(prematureExecRes.status, 403);
    const prematureBody = (await prematureExecRes.json()) as { error: string; code: string };
    assert.equal(prematureBody.code, 'approval_mismatch');

    // 2c. Request Approval -> transitions to WAITING_APPROVAL
    const reqApprRes = await fetch(`${baseUrl}/api/plans/${plan.id}/request-approval`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
    });
    assert.equal(reqApprRes.status, 200);
    const reqApprData = (await reqApprRes.json()) as { plan: any };
    assert.equal(reqApprData.plan.status, 'WAITING_APPROVAL');

    // 2d. Attempt approval with wrong planHash -> rejected with 400
    const badApproveRes = await fetch(`${baseUrl}/api/plans/${plan.id}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({ planHash: '0000000000000000000000000000000000000000000000000000000000000000' }),
    });
    assert.equal(badApproveRes.status, 400);

    // 2e. Approve with correct cryptographic hash -> transitions to APPROVED
    const approveRes = await fetch(`${baseUrl}/api/plans/${plan.id}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({ planHash: plan.hash }),
    });
    assert.equal(approveRes.status, 200);
    const approveData = (await approveRes.json()) as { plan: any };
    assert.equal(approveData.plan.status, 'APPROVED');
    assert.ok(approveData.plan.approval && approveData.plan.approval.id);
    const approvalId = approveData.plan.approval.id;

    // 2f. Execute Plan with verified approval
    const execRes = await fetch(`${baseUrl}/api/plans/${plan.id}/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({ approvalId }),
    });
    assert.equal(execRes.status, 200);
    const execData = (await execRes.json()) as { plan: any; correlationId: string };
    const executedPlan = execData.plan;
    assert.equal(executedPlan.status, 'SUCCEEDED');
    assert.equal(executedPlan.correlationId, traceId);
    assert.equal(executedPlan.steps.length, 1);
    const executedStep = executedPlan.steps[0];
    assert.equal(executedStep.status, 'SUCCEEDED');
    assert.equal(executedStep.verification.status, 'VERIFIED');
    assert.equal(executedStep.correlationId, traceId);
    assert.ok(typeof executedStep.durationMs === 'number' && executedStep.durationMs >= 0);

    // 2g. Replay attack prevention: Attempt to execute again with same approvalId -> must be rejected with 409
    const replayRes = await fetch(`${baseUrl}/api/plans/${plan.id}/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({ approvalId }),
    });
    assert.equal(replayRes.status, 409);
    const replayBody = (await replayRes.json()) as { code: string; error: string };
    assert.equal(replayBody.code, 'approval_replayed');

    // 2h. Verify against Audit Ledger
    const verifyLedgerRes = await fetch(`${baseUrl}/api/plans/${plan.id}/verify-ledger`);
    assert.equal(verifyLedgerRes.status, 200);
    const verifyData = (await verifyLedgerRes.json()) as { verification: any };
    assert.equal(verifyData.verification.verified, true);
    assert.equal(verifyData.verification.planHashMatches, true);
    assert.equal(verifyData.verification.status, 'SUCCEEDED');

    // 2i. Query Audit Events with correlation ID filter
    const auditRes = await fetch(`${baseUrl}/api/audit?correlationId=${traceId}`);
    assert.equal(auditRes.status, 200);
    const auditData = (await auditRes.json()) as { events: any[] };
    assert.ok(auditData.events.length >= 4, 'Must have recorded proposal, approval, execution start and finish');
    for (const ev of auditData.events) {
      assert.equal(ev.correlationId || ev.data?.correlationId, traceId);
    }

    // 2j. Audit ledger integrity verification
    const integrityRes = await fetch(`${baseUrl}/api/audit/verify-integrity`);
    assert.equal(integrityRes.status, 200);
    const integrityData = (await integrityRes.json()) as { report: any };
    assert.equal(integrityData.report.intact, true);
    assert.equal(integrityData.report.tamperedCount, 0);
  });

  // 3. Autonomous Task Execution API with State Machine & Observability
  await t.test('3. Autonomous Task Execution handles UNAVAILABLE, FAILED, and VERIFIED with correlation', async () => {
    const taskTraceId = 'trace-task-sandbox-' + Date.now();

    // 3a. Unsupported task type reports 503 UNAVAILABLE with state BLOCKED
    const unavailRes = await fetch(`${baseUrl}/api/tasks/autonomous-run`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': taskTraceId,
      },
      body: JSON.stringify({
        task: {
          id: 'task-unsupported-1',
          goal: 'Invoke an unallowlisted foreign provider tool',
          taskType: 'unknown_exotic_action',
        },
        muted: true,
      }),
    });
    assert.equal(unavailRes.status, 503);
    const unavailData = (await unavailRes.json()) as { status: string; result: any; correlationId: string };
    assert.equal(unavailData.status, 'UNAVAILABLE');
    assert.equal(unavailData.result.state, 'BLOCKED');
    assert.match(unavailData.result.error || '', /^\[UNAVAILABLE\]/);
    assert.equal(unavailData.correlationId, taskTraceId);

    // 3b. Safe sandbox task execution (syntax_check)
    const syntaxRes = await fetch(`${baseUrl}/api/tasks/autonomous-run`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': taskTraceId,
      },
      body: JSON.stringify({
        task: {
          id: 'task-syntax-check-1',
          goal: 'Perform syntax check on current repository',
          taskType: 'syntax_check',
        },
        muted: true,
      }),
    });
    assert.equal(syntaxRes.status, 200);
    const syntaxData = (await syntaxRes.json()) as { status: string; result: any };
    assert.equal(syntaxData.status, 'completed');
    assert.equal(syntaxData.result.state, 'COMPLETED');
    assert.ok(syntaxData.result.evidenceLedger.length > 0);
    const entry = syntaxData.result.evidenceLedger[0];
    assert.equal(entry.verificationStatus, 'VERIFIED');
    assert.equal(entry.exitCode, 0);
    assert.equal(entry.correlationId, taskTraceId);

    // 3c. Query Evidence Ledger with correlation filter
    const evidenceRes = await fetch(`${baseUrl}/api/evidence-ledger?correlationId=${taskTraceId}`);
    assert.equal(evidenceRes.status, 200);
    const evidenceData = (await evidenceRes.json()) as { records: any[] };
    assert.ok(evidenceData.records.length > 0);
    for (const rec of evidenceData.records) {
      assert.equal(rec.correlationId, taskTraceId);
    }
  });

  // 4. Secret Redaction Across Error Responses & Audit Ledger
  await t.test('4. Secret redaction strictly scrubs API keys, bearer tokens, and passwords', async () => {
    const secretTraceId = 'trace-secret-' + Date.now();
    const dummyKey = 'sk-proj-supersecretkey1234567890';
    const dummyBearer = 'Bearer ya29.a0AfH6SMDUMMYTOKEN1234567890';

    // Submit invalid plan with sensitive credentials embedded in goal
    const leakAttemptRes = await fetch(`${baseUrl}/api/plans`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': secretTraceId,
      },
      body: JSON.stringify({
        goal: `Perform migration with secret ${dummyKey} and auth ${dummyBearer}`,
        riskLevel: 'LOW',
        successCriteria: ['Completed without error'],
        steps: [
          {
            id: 'secret-step-1',
            tool: 'get_time',
            input: {},
            dependsOn: [],
            successCondition: 'result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt',
          },
        ],
      }),
    });

    assert.equal(leakAttemptRes.status, 201);
    const leakData = (await leakAttemptRes.json()) as { plan: any };
    const serializedPlan = JSON.stringify(leakData.plan);
    assert.equal(serializedPlan.includes(dummyKey), false, 'Raw OpenAI key must not be exposed');
    assert.equal(serializedPlan.includes('ya29.a0AfH6SMDUMMYTOKEN1234567890'), false, 'Raw Bearer token must not be exposed');
    assert.match(leakData.plan.goal, /\[REDACTED\]/);

    // Verify audit event also scrubs the secret
    const auditRes = await fetch(`${baseUrl}/api/audit?correlationId=${secretTraceId}`);
    const auditData = (await auditRes.json()) as { events: any[] };
    const serializedAudit = JSON.stringify(auditData);
    assert.equal(serializedAudit.includes(dummyKey), false, 'Audit ledger must not contain raw secret');
    assert.equal(serializedAudit.includes('ya29.a0AfH6SMDUMMYTOKEN1234567890'), false, 'Audit ledger must not contain raw token');
  });

  await t.test('6. /api/chat handles code explanation of verifyIntegrity with empirical proof, no approval needed', async () => {
    const chatTraceId = `trace-chat-explain-${Date.now()}`;
    const chatRes = await fetch(`${baseUrl}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': chatTraceId,
      },
      body: JSON.stringify({
        message: 'ให้อธิบายโค้ด server/agent.ts ฟังก์ชัน verifyIntegrity',
        mode: 'auto',
      }),
    });

    assert.equal(chatRes.status, 200);
    const chatData = (await chatRes.json()) as {
      status: string;
      reasoning: any;
      assistantMessage: { content: string; summary: string };
    };

    assert.equal(chatData.status, 'VERIFIED');
    assert.equal(chatData.reasoning.analysis.intentType, 'explain_code');
    assert.equal(chatData.reasoning.analysis.requiresApproval, false);

    const content = chatData.assistantMessage.content;
    assert.match(content, /server\/agent\.ts/);
    assert.match(content, /verifyIntegrity/);
    assert.match(content, /createHash/);
    assert.match(content, /node:crypto/);
    assert.match(content, /SHA-256/i);
    assert.match(content, /hexadecimal/i);
    assert.match(content, /64/);
    assert.match(content, /Project Codebase/);
    assert.match(content, /Sandbox Workspace/);
    assert.match(content, /ไม่ต้องขออนุมัติ|Approval Not Required/);
  });
});

