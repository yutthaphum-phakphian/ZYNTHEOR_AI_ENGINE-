import test from 'node:test';
import assert from 'node:assert/strict';
import { getPlans, createPlan } from '../features/copilot/plans/plans.js';

test('copilot plan store ships empty: no hard-coded sample plans that look like real work', () => {
  assert.deepEqual(getPlans(), []);
});

test('a plan appears only after it is created, and keeps what was created', () => {
  const p = createPlan({ title: 'real plan', description: 'made in test' });
  assert.equal(getPlans().length, 1);
  assert.equal(getPlans()[0].id, p.id);
  assert.equal(p.status, 'draft');
});
