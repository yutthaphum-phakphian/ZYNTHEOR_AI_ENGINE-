import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');

test('header person icon opens an account menu with honest sign-in status', () => {
  assert.match(app, /data-testid="account-menu-button"/);
  assert.match(app, /data-testid="account-menu"/);
  assert.match(app, /aria-expanded=\{userMenuOpen\}/);
  assert.match(app, /ยังไม่ได้เข้าสู่ระบบ/);
  assert.match(app, /ระบบสมาชิกยังไม่เปิดใช้งาน/);
});

test('sign-in is disabled because no membership system exists (no fake login)', () => {
  assert.match(app, /data-testid="account-menu-signin"[\s\S]{0,300}/);
  const block = app.slice(app.indexOf('data-testid="account-menu-signin"') - 400, app.indexOf('data-testid="account-menu-signin"') + 200);
  assert.match(block, /disabled/);
  assert.match(block, /aria-disabled="true"/);
});

test('status dot reflects real health state, not a hard-coded green', () => {
  const idx = app.indexOf('data-testid="account-menu-button"');
  const btn = app.slice(idx, idx + 1800);
  assert.match(btn, /healthState === 'ready'/);
  assert.doesNotMatch(btn, /bg-emerald-400"><\/span>/);
});

test('menu closes on outside press and Escape; profile block removed from sidebar footer', () => {
  assert.match(app, /event\.key === 'Escape'\) setUserMenuOpen\(false\)/);
  assert.match(app, /document\.addEventListener\('pointerdown', onPointerDown\)/);
  assert.ok(!app.includes('aria-label="ตั้งค่าโปรไฟล์"'), 'duplicate sidebar profile block should be gone');
});
