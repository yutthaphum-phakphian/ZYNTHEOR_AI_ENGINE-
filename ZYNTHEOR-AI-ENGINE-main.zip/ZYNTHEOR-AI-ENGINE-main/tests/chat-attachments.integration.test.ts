import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';

const tempDir = await mkdtemp(join(tmpdir(), 'zyntheor-attach-test-'));
const TOKEN = 'attach-test-token-0123456789-0123456789';
const saved = { w: process.env.WORKSPACE_FILES_DIR, m: process.env.MEMORY_STORE_DIR, c: process.env.CHAT_STORE_PATH, t: process.env.APPHUB_AUTH_TOKEN };
process.env.WORKSPACE_FILES_DIR = join(tempDir, 'workspace');
process.env.MEMORY_STORE_DIR = join(tempDir, 'memory');
process.env.CHAT_STORE_PATH = join(tempDir, 'audit.jsonl');
delete process.env.APPHUB_AUTH_TOKEN;

const { createApp } = await import('../server.js');
const app = await createApp({ skipVite: true });
const server = app.listen(0, '127.0.0.1');
await new Promise<void>((r) => server.once('listening', r));
const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

// Ollama-protocol stand-in: records what the server sends to the model. It proves routing/content, not model quality.
const seen: string[] = [];
let runtime: http.Server;
let runtimeUrl = '';
before(async () => {
  runtime = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      const json = (o: unknown) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
      if (req.url === '/api/tags') return json({ models: [{ name: 'stub:latest' }] });
      if (req.url === '/api/chat' || req.url === '/api/generate') { seen.push(body); return json({ message: { content: 'stub-reply' }, response: 'stub-reply', done: true }); }
      res.writeHead(404); res.end('{}');
    });
  });
  await new Promise<void>((r) => runtime.listen(0, '127.0.0.1', r));
  runtimeUrl = `http://127.0.0.1:${(runtime.address() as AddressInfo).port}`;
});
after(async () => {
  runtime.closeAllConnections?.();
  await new Promise<void>((r) => runtime.close(() => r()));
  server.closeAllConnections?.();
  await new Promise<void>((r) => server.close(() => r()));
  for (const [k, v] of [['WORKSPACE_FILES_DIR', saved.w], ['MEMORY_STORE_DIR', saved.m], ['CHAT_STORE_PATH', saved.c], ['APPHUB_AUTH_TOKEN', saved.t]] as const) {
    if (v === undefined) delete process.env[k]; else process.env[k] = v;
  }
  await rm(tempDir, { recursive: true, force: true });
});

const b64 = (s: string) => Buffer.from(s).toString('base64');
const post = (body: object, token?: string) => fetch(`${base}/api/chat`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  body: JSON.stringify({ mode: 'chat', provider: 'local', localEndpoint: runtimeUrl, ...body }),
});
const goodFiles = [{ name: 'notes.txt', mimeType: 'text/plain', contentBase64: b64('ATTACH-MARKER-42') }];

test('policy endpoint reports not_configured (and unavailable) when no auth token is set', async () => {
  const p = await (await fetch(`${base}/api/chat/attachment-policy`)).json() as any;
  assert.equal(p.tokenState, 'not_configured');
  assert.equal(p.available, false);
  assert.equal(p.imagesSupported, false);
});

test('files without a configured server token fail closed (503) and nothing reaches the model', async () => {
  seen.length = 0;
  const r = await post({ message: 'read it', files: goodFiles }, TOKEN);
  assert.equal(r.status, 503);
  assert.equal(seen.length, 0);
});

test('with a token configured: no/wrong token -> 401, nothing reaches the model', async () => {
  process.env.APPHUB_AUTH_TOKEN = TOKEN;
  seen.length = 0;
  assert.equal((await post({ message: 'read it', files: goodFiles })).status, 401);
  assert.equal((await post({ message: 'read it', files: goodFiles }, 'x'.repeat(40))).status, 401);
  assert.equal(seen.length, 0);
  const p = await (await fetch(`${base}/api/chat/attachment-policy`)).json() as any;
  assert.equal(p.available, true);
  assert.equal(JSON.stringify(p).includes(TOKEN), false, 'policy must never leak the token');
});

test('invalid files are rejected with per-file reasons and never reach the model', async () => {
  process.env.APPHUB_AUTH_TOKEN = TOKEN;
  seen.length = 0;
  const r = await post({ message: 'read it', files: [...goodFiles, { name: '.env', contentBase64: b64('K=1') }] }, TOKEN);
  assert.equal(r.status, 422);
  const d = await r.json() as any;
  assert.equal(d.code, 'attachment_rejected');
  assert.ok(d.files.some((f: any) => f.name === '.env' && f.status === 'BLOCKED'));
  assert.equal(seen.length, 0);
});

test('a valid file with a valid token reaches the local runtime prompt (stand-in runtime)', async () => {
  process.env.APPHUB_AUTH_TOKEN = TOKEN;
  seen.length = 0;
  const r = await post({ message: 'summarise the file', files: goodFiles }, TOKEN);
  assert.equal(r.status, 200);
  assert.ok(seen.some((b) => b.includes('ATTACH-MARKER-42')), 'attachment text must be in the model request');
});

test('legacy contract is intact: metadata-only attachments and images still return 503 attachment_ingestion_unavailable', async () => {
  const r = await post({ message: 'x', attachments: [{ id: 'a', name: 'a.txt', type: 'file', size: 1, mimeType: 'text/plain' }], images: [] });
  assert.equal(r.status, 503);
  assert.equal(((await r.json()) as any).code, 'attachment_ingestion_unavailable');
});
