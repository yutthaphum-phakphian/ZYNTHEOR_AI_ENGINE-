import test, { describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { detectModeFromText, detectModeWithEvidence, explainAutoChoice, restoreManualMode } from '../src/utils/detectMode.js';

describe('Auto mode: choice matches the message and carries its evidence', () => {
  const cases: Array<[string, string, string]> = [
    ['สรุปข่าวล่าสุดเกี่ยวกับ AI', 'web', 'ข่าวล่าสุด'],
    ['ช่วยหาไฟล์ config ในโฟลเดอร์นี้', 'files', 'หาไฟล์'],
    ['ช่วยแก้บั๊ก python ให้หน่อย', 'code', 'บั๊ก'],
    ['วิเคราะห์แนวโน้มยอดขาย', 'analysis', 'วิเคราะห์'],
    ['please run command ls', 'tools', 'run command'],
    ['see https://example.com/page', 'web', 'https://'],
  ];
  for (const [text, mode, matched] of cases) {
    test(`"${text}" -> ${mode}`, () => {
      const d = detectModeWithEvidence(text);
      assert.equal(d.mode, mode);
      assert.ok(d.matched && d.matched.includes(matched), `evidence should contain "${matched}", got ${d.matched}`);
    });
  }

  test('no match -> chat with matched=null and an honest "no keyword" explanation', () => {
    const d = detectModeWithEvidence('สวัสดีครับ');
    assert.equal(d.mode, 'chat');
    assert.equal(d.matched, null);
    assert.equal(d.candidates.length, 0);
    assert.match(explainAutoChoice(d, 'แชทหลัก'), /ไม่พบคำ/);
  });

  test('multi-category: fixed priority, and the explanation names the other matches', () => {
    const d = detectModeWithEvidence('ค้นเว็บแล้ววิเคราะห์แนวโน้ม');
    assert.equal(d.mode, 'web');
    assert.deepEqual(d.candidates.map((c) => c.mode), ['web', 'analysis']);
    const text = explainAutoChoice(d, 'ค้นหาเว็บ');
    assert.ok(text.includes('ค้นเว็บ') && text.includes('analysis') && text.includes('ลำดับความสำคัญ'));
  });

  test('explanation only quotes evidence that was found in the text', () => {
    const d = detectModeWithEvidence('ช่วยแก้บั๊ก python ให้หน่อย');
    assert.ok('ช่วยแก้บั๊ก python ให้หน่อย'.toLowerCase().includes(d.matched!));
  });

  test('detectModeFromText stays backward compatible with the evidence version', () => {
    for (const t of ['สวัสดีครับ', 'ค้นเว็บแล้ววิเคราะห์แนวโน้ม', 'ช่วยวิเคราะห์บั๊กในโค้ดนี้', '']) {
      assert.equal(detectModeFromText(t), detectModeWithEvidence(t).mode);
    }
    assert.equal(detectModeFromText(undefined as any), 'chat');
  });

  test('long evidence is truncated, never invented', () => {
    const d = detectModeWithEvidence('https://' + 'a'.repeat(200));
    assert.ok(d.matched!.length <= 41);
  });
});

describe('Manual mode selection is preserved', () => {
  const ids = ['auto', 'chat', 'web', 'files', 'tools', 'code', 'analysis'] as const;
  test('restoreManualMode accepts only known ids', () => {
    assert.equal(restoreManualMode('code', ids), 'code');
    assert.equal(restoreManualMode('auto', ids), 'auto');
    assert.equal(restoreManualMode('hacker', ids), null);
    assert.equal(restoreManualMode('', ids), null);
    assert.equal(restoreManualMode(null, ids), null);
    assert.equal(restoreManualMode(undefined, ids), null);
  });
  test('an id that is no longer available is not restored', () => {
    assert.equal(restoreManualMode('web', ids.filter((i) => i !== 'web')), null);
  });
});

describe('Auto mode wiring in App.tsx (source checks)', () => {
  const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
  const fn = app.slice(app.indexOf('function resolveRequestMode'), app.indexOf('function chooseMode'));
  test('manual mode returns before any detection runs', () => {
    assert.ok(fn.indexOf("activeMode !== 'auto'") > -1);
    assert.ok(fn.indexOf("activeMode !== 'auto'") < fn.indexOf('detectModeWithEvidence'));
  });
  test('the reason is shown to the user, including the fallback case', () => {
    assert.ok(fn.includes('explainAutoChoice(detection'));
    assert.ok(!/if \(detected !== 'chat'\)/.test(fn), 'must not hide the reason when nothing matched');
  });
  test('manual choice is persisted and restored without adding a menu entry', () => {
    assert.ok(app.includes("localStorage.setItem('zyntheor_active_mode'"));
    assert.ok(app.includes("restoreManualMode(localStorage.getItem('zyntheor_active_mode')"));
    assert.equal((app.match(/id: 'auto', label: 'อัตโนมัติ'/g) || []).length, 1, 'no duplicate Auto entry');
  });
  test('every request path goes through resolveRequestMode', () => {
    assert.equal((app.match(/mode: resolveRequestMode\(/g) || []).length, 3);
  });
});
