import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import { createApp } from '../server.js';

test('Phase 2: API Contract & Audit Acknowledgment Integration Suite', async (t) => {
  const tempDir = await mkdtemp(join(tmpdir(), 'zyrquen-phase2-contract-'));
  const originalChatStore = process.env.CHAT_STORE_PATH;
  process.env.CHAT_STORE_PATH = join(tempDir, 'conversations.jsonl');

  const app = await createApp({ skipVite: true });
  const server = createServer(app);

  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  t.after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    if (originalChatStore) {
      process.env.CHAT_STORE_PATH = originalChatStore;
    } else {
      delete process.env.CHAT_STORE_PATH;
    }
    await rm(tempDir, { recursive: true, force: true });
  });

  // --------------------------------------------------------------------------
  // Contract 1: กรณีสำเร็จ (Success Case) & Audit Acknowledgment Lifecycle
  // --------------------------------------------------------------------------
  await t.test('1. Contract Success: Plan lifecycle provides verifiable Audit Acknowledgment and retroactive tracing', async () => {
    const traceId = `trace-p2-success-${Date.now()}`;

    // 1a. Plan creation
    const createRes = await fetch(`${baseUrl}/api/plans`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({
        goal: 'Retrieve authoritative server time with verifiable audit evidence',
        riskLevel: 'LOW',
        successCriteria: ['Time retrieved with valid ISO timestamp format'],
        steps: [
          {
            id: 'phase2-step-time',
            tool: 'get_time',
            input: {},
            dependsOn: [],
            successCondition: 'result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt',
          },
        ],
      }),
    });

    assert.equal(createRes.status, 201, 'POST /api/plans should return HTTP 201 Created');
    const createData = (await createRes.json()) as { plan: any; correlationId: string; auditAck?: any };
    assert.equal(createData.correlationId, traceId);
    assert.ok(createData.plan && createData.plan.id);
    assert.equal(createData.plan.status, 'PROPOSED');

    // Audit Acknowledgment verification on creation
    const createAck = createData.auditAck || createData.plan.auditAck;
    assert.ok(createAck, 'Must return Audit Acknowledgment');
    assert.equal(createAck.acknowledged, true, 'Audit event must be acknowledged');
    assert.equal(createAck.status, 'RECORDED', 'Initial audit status must be RECORDED');
    assert.equal(createAck.runId, createData.plan.id, 'Audit runId must match plan id');
    assert.equal(createAck.correlationId, traceId, 'Audit correlationId must match traceId');
    assert.ok(createAck.ackId && createAck.ackId.startsWith('ack_'), 'Acknowledgment ID must be formatted');
    assert.ok(createAck.digest && createAck.digest.length === 64, 'Digest must be 64-char SHA-256');

    const planId = createData.plan.id;
    const planHash = createData.plan.hash;

    // 1b. Request approval
    const reqApprRes = await fetch(`${baseUrl}/api/plans/${planId}/request-approval`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
    });
    assert.equal(reqApprRes.status, 200, 'POST /api/plans/:id/request-approval should return HTTP 200');
    const reqApprData = (await reqApprRes.json()) as { plan: any; correlationId: string; auditAck?: any };
    assert.equal(reqApprData.plan.status, 'WAITING_APPROVAL');
    const reqApprAck = reqApprData.auditAck || reqApprData.plan.auditAck;
    assert.ok(reqApprAck && reqApprAck.acknowledged === true);
    assert.equal(reqApprAck.runId, planId);

    // 1c. Approve plan
    const apprRes = await fetch(`${baseUrl}/api/plans/${planId}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({ planHash }),
    });
    assert.equal(apprRes.status, 200, 'POST /api/plans/:id/approve should return HTTP 200');
    const apprData = (await apprRes.json()) as { plan: any; correlationId: string; auditAck?: any };
    assert.equal(apprData.plan.status, 'APPROVED');
    assert.ok(apprData.plan.approval && apprData.plan.approval.id);
    const approvalId = apprData.plan.approval.id;
    const apprAck = apprData.auditAck || apprData.plan.auditAck;
    assert.ok(apprAck && apprAck.acknowledged === true);

    // 1d. Execute plan
    const execRes = await fetch(`${baseUrl}/api/plans/${planId}/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({ approvalId }),
    });
    assert.equal(execRes.status, 200, 'POST /api/plans/:id/execute should return HTTP 200');
    const execData = (await execRes.json()) as { plan: any; correlationId: string; auditAck?: any };
    assert.equal(execData.plan.status, 'SUCCEEDED');
    const execAck = execData.auditAck || execData.plan.auditAck;
    assert.ok(execAck && execAck.acknowledged === true);
    assert.equal(execAck.status, 'SUCCESS', 'Executed plan audit ack status must be SUCCESS');
    assert.equal(execAck.runId, planId);

    // 1e. Direct Audit Event Ingestion & Acknowledgment API (POST /api/audit/events)
    const directAuditRes = await fetch(`${baseUrl}/api/audit/events`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({
        type: 'verification_milestone_recorded',
        runId: planId,
        stepId: 'phase2-step-time',
        status: 'SUCCESS',
        data: {
          verifiedBy: 'Zyrquen Integrity Engine',
          evidenceChecked: true,
        },
      }),
    });
    assert.equal(directAuditRes.status, 201, 'POST /api/audit/events should return HTTP 201');
    const directAuditData = (await directAuditRes.json()) as {
      status: string;
      acknowledged: boolean;
      acknowledgment: any;
      correlationId: string;
    };
    assert.equal(directAuditData.acknowledged, true);
    assert.equal(directAuditData.status, 'SUCCESS');
    assert.ok(directAuditData.acknowledgment.digest && directAuditData.acknowledgment.digest.length === 64);
    assert.equal(directAuditData.acknowledgment.runId, planId);
    assert.equal(directAuditData.acknowledgment.stepId, 'phase2-step-time');

    // 1f. Fetch specific audit event by ID (GET /api/audit/events/:id)
    const getEventRes = await fetch(`${baseUrl}/api/audit/events/${directAuditData.acknowledgment.eventId}`);
    assert.equal(getEventRes.status, 200, 'GET /api/audit/events/:id should return HTTP 200');
    const getEventData = (await getEventRes.json()) as { event: any; digest: string };
    assert.equal(getEventData.event.id, directAuditData.acknowledgment.eventId);
    assert.equal(getEventData.digest, directAuditData.acknowledgment.digest);

    // 1g. Retroactive Tracing: Filter audit events by Run ID and Step ID
    const runAuditRes = await fetch(`${baseUrl}/api/audit?runId=${planId}`);
    assert.equal(runAuditRes.status, 200);
    const runAuditData = (await runAuditRes.json()) as { events: any[] };
    assert.ok(runAuditData.events.length >= 5, 'Should return all events associated with this runId');
    for (const ev of runAuditData.events) {
      const eventRunId = ev.runId || ev.data?.runId || ev.data?.planId || ev.data?.plan?.id;
      assert.equal(eventRunId, planId, `Audit event ${ev.type} must link to runId ${planId}`);
    }

    // 1h. Ledger integrity verification
    const integrityRes = await fetch(`${baseUrl}/api/audit/verify-integrity`);
    assert.equal(integrityRes.status, 200);
    const integrityData = (await integrityRes.json()) as { report: any };
    assert.equal(integrityData.report.intact, true);
    assert.equal(integrityData.report.tamperedCount, 0);
  });

  // --------------------------------------------------------------------------
  // Contract 2: กรณีล้มเหลว (Failure / Execution Error Case)
  // --------------------------------------------------------------------------
  await t.test('2. Contract Failure: Execution failures report FAILED/BLOCKED accurately without false VERIFIED claims', async () => {
    const traceId = `trace-p2-failure-${Date.now()}`;

    // 2a. Create a plan
    const createRes = await fetch(`${baseUrl}/api/plans`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({
        goal: 'Plan to be rejected by human reviewer',
        riskLevel: 'LOW',
        successCriteria: ['Observe rejected plan handling'],
        steps: [
          {
            id: 'step-to-reject',
            tool: 'get_time',
            input: {},
            dependsOn: [],
            successCondition: 'result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt',
          },
        ],
      }),
    });

    assert.equal(createRes.status, 201);
    const createData = (await createRes.json()) as { plan: any };
    const planId = createData.plan.id;

    // 2b. Request approval
    await fetch(`${baseUrl}/api/plans/${planId}/request-approval`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
    });

    // 2c. Reject plan -> status transitions to BLOCKED
    const rejectRes = await fetch(`${baseUrl}/api/plans/${planId}/reject`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
    });
    assert.equal(rejectRes.status, 200, 'POST /api/plans/:id/reject should return HTTP 200');
    const rejectData = (await rejectRes.json()) as { plan: any; auditAck?: any };
    assert.equal(rejectData.plan.status, 'BLOCKED', 'Rejected plan status must be BLOCKED');
    assert.equal(rejectData.auditAck?.status, 'BLOCKED', 'Audit Ack status for rejected plan must be BLOCKED');

    // 2d. Attempt to execute rejected plan -> must be rejected with HTTP 403 / approval_required
    const execRejectedRes = await fetch(`${baseUrl}/api/plans/${planId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({ approvalId: 'any-approval-id' }),
    });
    assert.equal(execRejectedRes.status, 403, 'Execution of rejected plan must be rejected with 403');

    // 2e. Direct Audit Ingestion with FAILED status
    const failedEventRes = await fetch(`${baseUrl}/api/audit/events`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({
        type: 'step_execution_failed',
        runId: planId,
        stepId: 'step-to-reject',
        status: 'FAILED',
        data: {
          exitCode: 1,
          error: 'Simulated tool failure for audit verification',
        },
      }),
    });
    assert.equal(failedEventRes.status, 201);
    const failedEventData = (await failedEventRes.json()) as { status: string; acknowledgment: any };
    assert.equal(failedEventData.status, 'FAILED');
    assert.equal(failedEventData.acknowledgment.status, 'FAILED');
    assert.equal(failedEventData.acknowledgment.runId, planId);

    // 2f. Verify Audit Event captures BLOCKED and FAILED status in ledger
    const auditRes = await fetch(`${baseUrl}/api/audit?runId=${planId}&status=BLOCKED`);
    assert.equal(auditRes.status, 200);
    const auditData = (await auditRes.json()) as { events: any[] };
    assert.ok(auditData.events.length > 0, 'Audit ledger must contain recorded BLOCKED event');

    // 2g. Autonomous task with unsupported action: reports 503 UNAVAILABLE with state BLOCKED
    const autoFailRes = await fetch(`${baseUrl}/api/tasks/autonomous-run`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': traceId,
      },
      body: JSON.stringify({
        task: {
          id: 'task-fail-test',
          goal: 'Test failure state handling',
          taskType: 'unknown_unsupported_action',
        },
        muted: true,
      }),
    });

    assert.equal(autoFailRes.status, 503, 'Unsupported task must return HTTP 503 UNAVAILABLE');
    const autoFailData = (await autoFailRes.json()) as { status: string; result: any };
    assert.equal(autoFailData.status, 'UNAVAILABLE');
    assert.equal(autoFailData.result.state, 'BLOCKED');
  });

  // --------------------------------------------------------------------------
  // Contract 3: กรณีไม่มีสิทธิ์ (Permission Denied / Unauthorized / Boundary Case)
  // --------------------------------------------------------------------------
  await t.test('3. Contract Unauthorized: Premature execution and replay attacks return 403/409 with correlation', async () => {
    const traceId = `trace-p2-auth-${Date.now()}`;

    // 3a. Create plan
    const createRes = await fetch(`${baseUrl}/api/plans`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({
        goal: 'Test approval enforcement boundary',
        riskLevel: 'LOW',
        successCriteria: ['Enforce approval boundary'],
        steps: [
          {
            id: 'auth-step-1',
            tool: 'get_time',
            input: {},
            dependsOn: [],
            successCondition: 'result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt',
          },
        ],
      }),
    });
    const createData = (await createRes.json()) as { plan: any };
    const planId = createData.plan.id;

    // 3b. Premature execution without approval -> HTTP 403 Forbidden
    const unapprovedRes = await fetch(`${baseUrl}/api/plans/${planId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({ approvalId: 'unauthorized-token' }),
    });
    assert.equal(unapprovedRes.status, 403, 'Premature execution without approval must return 403');
    const unapprovedBody = (await unapprovedRes.json()) as { code: string; error: string; correlationId: string };
    assert.equal(unapprovedBody.code, 'approval_mismatch');
    assert.equal(unapprovedBody.correlationId, traceId);

    // 3c. Request approval and approve
    await fetch(`${baseUrl}/api/plans/${planId}/request-approval`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
    });
    const apprRes = await fetch(`${baseUrl}/api/plans/${planId}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({ planHash: createData.plan.hash }),
    });
    const apprData = (await apprRes.json()) as { plan: any };
    const approvalId = apprData.plan.approval.id;

    // 3d. Execute successfully once
    const execRes1 = await fetch(`${baseUrl}/api/plans/${planId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({ approvalId }),
    });
    assert.equal(execRes1.status, 200);

    // 3e. Replay attack: Execute again with the same approvalId -> HTTP 409 Conflict
    const replayRes = await fetch(`${baseUrl}/api/plans/${planId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({ approvalId }),
    });
    assert.equal(replayRes.status, 409, 'Replay execution must return HTTP 409 Conflict');
    const replayBody = (await replayRes.json()) as { code: string; error: string; correlationId: string };
    assert.equal(replayBody.code, 'approval_replayed');
    assert.equal(replayBody.correlationId, traceId);
  });

  // --------------------------------------------------------------------------
  // Contract 4: กรณีข้อมูลไม่ถูกต้อง (Invalid Input / Schema Mismatch Case)
  // --------------------------------------------------------------------------
  await t.test('4. Contract Bad Request: Malformed schemas return HTTP 400 with descriptive error code', async () => {
    const traceId = `trace-p2-invalid-${Date.now()}`;

    // 4a. POST /api/plans with empty goal -> 400
    const emptyGoalRes = await fetch(`${baseUrl}/api/plans`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({
        goal: '',
        steps: [],
      }),
    });
    assert.equal(emptyGoalRes.status, 400, 'Empty goal must return HTTP 400');
    const emptyGoalBody = (await emptyGoalRes.json()) as { code: string; error: string; correlationId: string };
    assert.equal(emptyGoalBody.code, 'invalid_plan');
    assert.equal(emptyGoalBody.correlationId, traceId);

    // 4b. POST /api/plans with unregistered extra fields -> 400
    const extraFieldRes = await fetch(`${baseUrl}/api/plans`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({
        goal: 'Valid goal statement',
        steps: [],
        maliciousInjectedField: 'hack',
      }),
    });
    assert.equal(extraFieldRes.status, 400, 'Unregistered extra fields must return HTTP 400');
    const extraFieldBody = (await extraFieldRes.json()) as { code: string; error: string };
    assert.equal(extraFieldBody.code, 'invalid_plan');

    // 4c. POST /api/audit/events with missing type -> 400
    const invalidAuditRes = await fetch(`${baseUrl}/api/audit/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
      body: JSON.stringify({
        runId: 'run-123',
        data: {},
      }),
    });
    assert.equal(invalidAuditRes.status, 400, 'Audit event without type must return HTTP 400');
    const invalidAuditBody = (await invalidAuditRes.json()) as { code: string; error: string; correlationId: string };
    assert.equal(invalidAuditBody.code, 'invalid_audit_event');
    assert.equal(invalidAuditBody.correlationId, traceId);

    // 4d. GET /api/audit/events/:id for non-existent event -> 404
    const notFoundEventRes = await fetch(`${baseUrl}/api/audit/events/non_existent_event_id_xyz`, {
      headers: { 'X-Correlation-Id': traceId },
    });
    assert.equal(notFoundEventRes.status, 404, 'Non-existent event ID must return HTTP 404');
    const notFoundBody = (await notFoundEventRes.json()) as { code: string; error: string; correlationId: string };
    assert.equal(notFoundBody.code, 'event_not_found');
    assert.equal(notFoundBody.correlationId, traceId);
  });

  // --------------------------------------------------------------------------
  // Contract 5: กรณี Audit บันทึกไม่สำเร็จ (Storage Failure / 503 Case)
  // --------------------------------------------------------------------------
  await t.test('5. Contract Storage Failure: Storage errors return HTTP 503 with acknowledged=false and preserve Zero Fake', async () => {
    const traceId = `trace-p2-storage-${Date.now()}`;

    // Set storage path to an illegal directory path that cannot be created/written
    const previousPath = process.env.CHAT_STORE_PATH;
    process.env.CHAT_STORE_PATH = '/dev/null/forbidden/cannot_write.jsonl';

    try {
      // 5a. POST /api/audit/events during storage outage -> HTTP 503 Service Unavailable
      const storageFailAuditRes = await fetch(`${baseUrl}/api/audit/events`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
        body: JSON.stringify({
          type: 'test_storage_failure_event',
          data: { test: true },
        }),
      });
      assert.equal(storageFailAuditRes.status, 503, 'Storage failure must return HTTP 503 Service Unavailable');
      const storageFailAuditBody = (await storageFailAuditRes.json()) as {
        code: string;
        acknowledged: boolean;
        status: string;
        correlationId: string;
      };
      assert.equal(storageFailAuditBody.code, 'storage_unavailable');
      assert.equal(storageFailAuditBody.acknowledged, false, 'Failed storage MUST report acknowledged=false (Zero Fake)');
      assert.equal(storageFailAuditBody.status, 'FAILED');
      assert.equal(storageFailAuditBody.correlationId, traceId);

      // 5b. POST /api/plans during storage outage -> HTTP 503
      const storageFailPlanRes = await fetch(`${baseUrl}/api/plans`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': traceId },
        body: JSON.stringify({
          goal: 'Attempt plan creation during storage outage',
          riskLevel: 'LOW',
          successCriteria: ['Should fail safely without false success'],
          steps: [],
        }),
      });
      assert.equal(storageFailPlanRes.status, 503, 'Plan creation during storage failure must return HTTP 503');
      const storageFailPlanBody = (await storageFailPlanRes.json()) as { code: string; correlationId: string };
      assert.equal(storageFailPlanBody.code, 'storage_unavailable');
      assert.equal(storageFailPlanBody.correlationId, traceId);
    } finally {
      process.env.CHAT_STORE_PATH = previousPath;
    }
  });
});
