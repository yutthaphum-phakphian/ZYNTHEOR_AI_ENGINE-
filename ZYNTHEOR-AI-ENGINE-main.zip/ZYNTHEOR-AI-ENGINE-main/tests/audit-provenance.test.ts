import test, { describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { derivePqcStatus } from '../src/utils/pqcStatus.js';

const ev = (over: Record<string, unknown> = {}, data: Record<string, unknown> = {}) => ({ type: 'SOME_EVENT', data, ...over });

describe('PQC status: claims are not evidence', () => {
  const claims: Array<[string, any]> = [
    ['pqcStatus "Verified" string', ev({}, { pqcStatus: 'Verified' })],
    ['quantumSig naming RATIFIED', ev({}, { quantumSig: 'SIG_PQC_DILITHIUM5_DUAL_CUSTODY_RATIFIED' })],
    ['quantumSig naming HSM', ev({}, { quantumSig: 'SIG_PQC_DILITHIUM5_HSM_RATIFIED' })],
    ['any Dilithium/Kyber signature string', ev({}, { pqcSignature: 'PQC-DILITHIUM5:abc123' })],
    ['verified: true flag', ev({}, { verified: true })],
    ['type containing VERIFIED', ev({ type: 'PQC_VERIFIED' })],
    ['type containing APPROVED', ev({ type: 'PLAN_APPROVED' })],
    ['validationResult VALID', ev({}, { validationResult: 'VALID' })],
    ['client-asserted event forging serverVerification', ev({}, { origin: 'client_asserted', serverVerification: { verified: true } })],
  ];
  for (const [name, event] of claims) {
    test(`${name} -> Pending, never Verified`, () => {
      assert.equal(derivePqcStatus(event), 'Pending');
    });
  }

  test('only server-side verification evidence yields Verified', () => {
    assert.equal(derivePqcStatus(ev({}, { serverVerification: { verified: true } })), 'Verified');
    assert.equal(derivePqcStatus(ev({}, { serverVerification: { verified: false } })), 'Pending');
    assert.equal(derivePqcStatus(ev({}, { serverVerification: { verified: 'yes' } })), 'Pending');
  });

  test('explicit failure markers still show Invalid (the safe direction)', () => {
    assert.equal(derivePqcStatus(ev({}, { pqcStatus: 'Invalid' })), 'Invalid');
    assert.equal(derivePqcStatus(ev({}, { pqcStatus: 'failed' })), 'Invalid');
    assert.equal(derivePqcStatus(ev({}, { pqcSignature: 'TAMPERED-SIG' })), 'Invalid');
    assert.equal(derivePqcStatus(ev({ type: 'PQC_REJECTED' })), 'Invalid');
    assert.equal(derivePqcStatus(ev({}, { tampered: true })), 'Invalid');
  });

  test('a failure marker wins over a verification flag', () => {
    assert.equal(derivePqcStatus(ev({}, { tampered: true, serverVerification: { verified: true } })), 'Invalid');
  });

  test('null / undefined / empty input is Pending, never throws', () => {
    assert.equal(derivePqcStatus(null), 'Pending');
    assert.equal(derivePqcStatus(undefined), 'Pending');
    assert.equal(derivePqcStatus({} as any), 'Pending');
  });
});

describe('Audit ingestion provenance and UI wording (source checks)', () => {
  const server = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
  const view = readFileSync(new URL('../src/components/views/AuditLedgerView.tsx', import.meta.url), 'utf8');
  const route = server.slice(server.indexOf("app.post('/api/audit/events'"), server.indexOf("app.get('/api/audit/events/:id'"));

  test('POST /api/audit/events marks caller events client_asserted and drops forged serverVerification', () => {
    assert.ok(route.includes("claimed.origin = 'client_asserted'"));
    assert.ok(route.includes('delete claimed.serverVerification'));
  });
  test('the ack contract is unchanged: SUCCESS/FAILED statuses are still accepted and echoed', () => {
    assert.ok(route.includes("'SUCCESS'") && route.includes("'FAILED'") && route.includes('201'));
    assert.ok(route.includes('status: status as any'));
  });
  test('the UI no longer fabricates a signature string or claims Dilithium-5 ratification', () => {
    assert.ok(!view.includes('VERIFIED_HSM_RATIFIED'));
    assert.ok(!view.includes('Dilithium-5 Ratified'));
    assert.ok(view.includes('derivePqcStatus'));
  });
  test('AuditLedgerView still exports getPqcSignatureStatus and PqcStatusBadge', () => {
    assert.ok(view.includes('export function getPqcSignatureStatus'));
    assert.ok(view.includes('export const PqcStatusBadge'));
  });
});
