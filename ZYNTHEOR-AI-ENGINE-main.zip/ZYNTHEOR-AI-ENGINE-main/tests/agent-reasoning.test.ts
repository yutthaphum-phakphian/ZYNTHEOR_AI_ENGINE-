import test from "node:test";
import assert from "node:assert/strict";
import {
  ZyntheorReasoningWorkflow,
  reasoningWorkflow,
  analyzeIntent,
  diagnoseFailure,
  generateThaiExplanation,
  type EvidenceItem,
  type ToolExecutionRecord,
} from "../server/reasoning.js";

test("ReasoningWorkflow: Intent analysis accurately classifies intent, risk, and approval requirements", () => {
  const codeIntent = analyzeIntent("ช่วยเขียนโค้ดและแก้ไขไฟล์ index.html ให้หน่อย", "code");
  assert.equal(codeIntent.intentType, "code_change");
  assert.equal(codeIntent.riskLevel, "HIGH");
  assert.equal(codeIntent.requiresApproval, true);
  assert.match(codeIntent.constraints[0], /อนุมัติ/);

  const reviewIntent = analyzeIntent("ช่วยตรวจโครงสร้างโปรเจกต์", "review");
  assert.equal(reviewIntent.intentType, "inspect");
  assert.equal(reviewIntent.riskLevel, "LOW");
  assert.equal(reviewIntent.requiresApproval, false);

  const syntaxIntent = analyzeIntent("ตรวจไวยากรณ์ syntax check ให้หน่อย");
  assert.equal(syntaxIntent.intentType, "syntax_check");
  assert.equal(syntaxIntent.riskLevel, "LOW");
  assert.equal(syntaxIntent.requiresApproval, false);
});

test("ReasoningWorkflow: Planning generates structured plan draft with criteria and steps", async () => {
  const workflow = new ZyntheorReasoningWorkflow();
  const analysis = workflow.analyzeIntent("วางแผนปรับปรุงระบบ", "plan");

  const evidence: EvidenceItem[] = [
    {
      id: "ev_1",
      category: "fact",
      statement: "ไฟล์ index.html มีอยู่จริง",
      source: "workspace:files",
      verified: true,
    },
  ];

  const planDraft = await workflow.planTask(analysis, evidence);
  const steps = planDraft.steps as Array<{ tool: string }>;
  const successCriteria = planDraft.successCriteria as string[];
  assert.equal(planDraft.goal, analysis.goal);
  assert.ok(steps.length > 0);
  assert.ok(successCriteria.length > 0);
  assert.equal(steps[0].tool, "get_time");
});

test("ReasoningWorkflow: Missing evidence triggers failure or unverified state instead of hallucinating VERIFIED", () => {
  const workflow = new ZyntheorReasoningWorkflow();
  const buildIntent = workflow.analyzeIntent("บิลด์โปรเจกต์ build bundle");

  // Scenario: index.html is missing
  const missingEvidence: EvidenceItem[] = [
    {
      id: "ev_no_html",
      category: "missing_info",
      statement: "ไม่พบไฟล์ index.html ใน Workspace",
      source: "workspace:index.html",
      verified: false,
    },
  ];

  const toolRecords: ToolExecutionRecord[] = [];

  // Verification must NOT hallucinate VERIFIED when required evidence is missing
  const verification = workflow.verifyExecution(toolRecords, missingEvidence);
  assert.notEqual(verification.status, "VERIFIED", "Cannot be VERIFIED when evidence is missing");
  assert.equal(verification.status, "NOT_VERIFIED");
  assert.equal(verification.missingInfo.length, 1);
  assert.equal(verification.hasHallucinationRisk, false);

  // Failure diagnosis must accurately identify the missing evidence
  const diagnosis = workflow.diagnoseFailure(buildIntent, toolRecords, missingEvidence);
  assert.equal(diagnosis.hasFailure, true);
  assert.match(diagnosis.rootCause || "", /index\.html/);
  assert.ok(diagnosis.recommendations.length > 0);
});

test("ReasoningWorkflow: Tool failure triggers failure diagnosis and actionable recommendations", () => {
  const workflow = new ZyntheorReasoningWorkflow();
  const syntaxIntent = workflow.analyzeIntent("รัน syntax_check ตรวจสอบไฟล์");

  const failedToolRecord: ToolExecutionRecord[] = [
    {
      tool: "syntax_check",
      status: "FAIL",
      command: ["node", "--check", "app.js"],
      exitCode: 1,
      stdout: "",
      stderr: "SyntaxError: Unexpected token '{' at line 42",
      durationMs: 45,
    },
  ];

  const evidence: EvidenceItem[] = [
    {
      id: "ev_syntax_fail",
      category: "fact",
      statement: "ผลรัน syntax_check ล้มเหลว",
      source: "sandbox:syntax_check",
      verified: false,
    },
  ];

  const verification = workflow.verifyExecution(failedToolRecord, evidence);
  assert.equal(verification.status, "FAIL", "Failed tool must produce FAIL status");

  const diagnosis = workflow.diagnoseFailure(syntaxIntent, failedToolRecord, evidence);
  assert.equal(diagnosis.hasFailure, true);
  assert.match(diagnosis.rootCause || "", /Syntax Error/i);
  assert.ok(diagnosis.recommendations.some((r) => r.includes("syntax error")));
});

test("ReasoningWorkflow: Blocked command or policy violation is diagnosed as BLOCKED with security notice", () => {
  const workflow = new ZyntheorReasoningWorkflow();
  const intent = workflow.analyzeIntent("เขียนไฟล์ทับระบบ");

  const blockedToolRecord: ToolExecutionRecord[] = [
    {
      tool: "write_file",
      status: "BLOCKED",
      command: ["write", "/etc/passwd"],
      exitCode: 126,
      stdout: "",
      stderr: "Permission denied by sandbox policy",
      durationMs: 5,
    },
  ];

  const diagnosis = workflow.diagnoseFailure(intent, blockedToolRecord, []);
  assert.equal(diagnosis.hasFailure, true);
  assert.match(diagnosis.rootCause || "", /บล็อก/);
  assert.ok(diagnosis.recommendations.some((r) => r.includes("อนุมัติ") || r.includes("สิทธิ์")));
});

test("ReasoningWorkflow: Permission check enforces approval boundary for high-risk operations", () => {
  const workflow = new ZyntheorReasoningWorkflow();

  const codeChangeAnalysis = workflow.analyzeIntent("แก้ไขไฟล์ server/agent.ts", "code");
  const permCode = workflow.checkPermissions(codeChangeAnalysis);
  assert.equal(permCode.allowed, false);
  assert.equal(permCode.requiresApproval, true);
  assert.equal(permCode.boundary, "APPROVAL_REQUIRED");

  const inspectAnalysis = workflow.analyzeIntent("ตรวจสอบโค้ด", "review");
  const permInspect = workflow.checkPermissions(inspectAnalysis);
  assert.equal(permInspect.allowed, true);
  assert.equal(permInspect.requiresApproval, false);
  assert.equal(permInspect.boundary, "ALLOWLISTED_SANDBOX");
});

test("ReasoningWorkflow: Explanation separates facts, hypotheses, and redacts secrets from speech", () => {
  const analysis = analyzeIntent("ตรวจสอบโปรเจกต์");
  const facts = ["พบไฟล์ index.html ใน Workspace", "ตรวจไวยากรณ์ผ่าน 0 errors"];
  const hypotheses = ["อาจเป็น Static Website"];
  const missingInfo = ["ไม่พบ app.json"];

  const explanation = generateThaiExplanation({
    status: "VERIFIED",
    analysis,
    facts,
    hypotheses,
    missingInfo,
    toolsExecuted: [],
  });

  // Verify structure
  assert.match(explanation.detailTh, /ข้อเท็จจริงที่ตรวจสอบแล้ว/);
  assert.match(explanation.detailTh, /สมมติฐานและสิ่งที่ยังขาด/);
  assert.match(explanation.summaryTh, /VERIFIED/);

  // Test secret redaction in spoken output
  const secretExplanation = generateThaiExplanation({
    status: "VERIFIED",
    analysis,
    facts: [
      "API Token: Bearer apphub-workspace-auth-token-key-32chars",
      "Found OpenAI key sk-1234567890abcdef123456",
    ],
    hypotheses: [],
    missingInfo: [],
    toolsExecuted: [],
  });

  assert.doesNotMatch(
    secretExplanation.spokenTextTh,
    /sk-1234567890abcdef123456/,
    "Spoken text must never leak OpenAI or secret keys"
  );
  assert.match(secretExplanation.spokenTextTh, /\[REDACTED\]|Bearer \[REDACTED\]/);
});

test("ReasoningWorkflow: explain_code intent is classified with LOW risk, no approval required, and inspects verifyIntegrity accurately", async () => {
  const workflow = new ZyntheorReasoningWorkflow();
  const prompt = "ให้อธิบายโค้ด server/agent.ts ฟังก์ชัน verifyIntegrity";

  // 1. Intent Analysis
  const analysis = workflow.analyzeIntent(prompt);
  assert.equal(analysis.intentType, "explain_code");
  assert.equal(analysis.riskLevel, "LOW");
  assert.equal(analysis.requiresApproval, false, "Code explanation must not require approval");

  // 2. Permission Check
  const perm = workflow.checkPermissions(analysis);
  assert.equal(perm.allowed, true);
  assert.equal(perm.requiresApproval, false);
  assert.equal(perm.boundary, "READ_ONLY");

  // 3. Full Orchestration & Evidence-Based Verification
  const result = await workflow.orchestrate({ prompt });
  assert.equal(result.status, "VERIFIED");
  assert.equal(result.analysis.requiresApproval, false);

  // 4. Verify Tool Execution Record
  const inspectTool = result.toolsExecuted.find((t) => t.tool === "inspect_code");
  assert.ok(inspectTool, "Must execute inspect_code tool");
  assert.equal(inspectTool.status, "VERIFIED");

  // 5. Verify Explanation Content
  const detail = result.explanation.detailTh;
  assert.match(detail, /server\/agent\.ts/);
  assert.match(detail, /verifyIntegrity/);
  assert.match(detail, /createHash/);
  assert.match(detail, /node:crypto/);
  assert.match(detail, /SHA-256/i);
  assert.match(detail, /hexadecimal/i);
  assert.match(detail, /64/);

  // 6. Verify Workspace Scope Distinction
  assert.match(detail, /Project Codebase/);
  assert.match(detail, /Sandbox Workspace/);

  // 7. Verify Approval Status Notice
  assert.match(detail, /ไม่ต้องขออนุมัติ|Approval Not Required/);
  assert.match(result.explanation.summaryTh, /ไม่ต้องขออนุมัติ/);
});

