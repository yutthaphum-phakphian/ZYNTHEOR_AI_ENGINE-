# features/copilot/plans

This directory contains the implementation and assets for the "plans" feature of the Copilot integration.

Structure:
- index.ts — entrypoint / exported API for the plans feature
- plans.json — example data / default plans
- README.md — this file

Purpose
- Provide a place to implement plan creation, retrieval, and management for Copilot features used by the app.
