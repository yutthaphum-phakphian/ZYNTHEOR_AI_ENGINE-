export type PlanStatus = "draft" | "active" | "completed" | "archived";

export type TaskPriority = "low" | "medium" | "high" | "critical";

export interface PlanSubTask {
  id: string;
  title: string;
  completed: boolean;
  status?: "pending" | "in_progress" | "done";
  assignedAgent?: string;
  completedAt?: string;
}

export interface PlanStep {
  id: string;
  title: string;
  description?: string;
  status: "pending" | "in_progress" | "done";
  dependsOn?: string[];
  subTasks?: PlanSubTask[];
}

export interface Plan {
  id: string;
  title: string;
  description?: string;
  status: PlanStatus;
  priority?: TaskPriority;
  progress: number;
  steps: PlanStep[];
  createdAt: string;
  updatedAt: string;
}

export interface CreatePlanInput {
  title: string;
  description?: string;
  steps?: PlanStep[];
}
