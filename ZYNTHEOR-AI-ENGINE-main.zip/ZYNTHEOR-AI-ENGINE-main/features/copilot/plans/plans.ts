import type { Plan, CreatePlanInput, PlanStep } from "./types";

const defaultSteps: PlanStep[] = [
  { id: "step-1", title: "Define objective", description: "Clarify the goal", status: "done" },
  { id: "step-2", title: "Research context", description: "Collect requirements", status: "in_progress" },
  { id: "step-3", title: "Implement", description: "Build the change", status: "pending" },
];

export const samplePlans: Plan[] = [];

export function getPlans(): Plan[] {
  return samplePlans;
}

export function getPlanById(id: string): Plan | undefined {
  return samplePlans.find((plan) => plan.id === id);
}

export function createPlan(input: CreatePlanInput): Plan {
  const now = new Date().toISOString();
  const steps = input.steps ?? [
    { id: `step-${Date.now()}`, title: "New task", status: "pending" },
  ];

  const plan: Plan = {
    id: `plan-${Date.now()}`,
    title: input.title,
    description: input.description,
    status: "draft",
    progress: 0,
    steps,
    createdAt: now,
    updatedAt: now,
  };
  samplePlans.unshift(plan);
  return plan;
}

export function updatePlanStepStatus(
  planId: string,
  stepId: string,
  status: "pending" | "in_progress" | "done"
): Plan | undefined {
  const plan = samplePlans.find((p) => p.id === planId);
  if (!plan) return undefined;
  const step = plan.steps.find((s) => s.id === stepId);
  if (!step) return undefined;
  step.status = status;

  // If step has subTasks, synchronize them with step status
  if (Array.isArray(step.subTasks)) {
    for (const st of step.subTasks) {
      if (status === 'done') {
        st.completed = true;
        st.status = 'done';
      } else if (status === 'pending') {
        st.completed = false;
        st.status = 'pending';
      }
    }
  }

  // Recalculate progress across subtasks if present, else steps
  const hasSubTasks = plan.steps.some(
    (s) => Array.isArray(s.subTasks) && s.subTasks.length > 0
  );

  if (hasSubTasks) {
    let total = 0;
    let done = 0;
    for (const s of plan.steps) {
      if (Array.isArray(s.subTasks) && s.subTasks.length > 0) {
        for (const st of s.subTasks) {
          total++;
          if (st.completed || st.status === 'done') done++;
        }
      } else {
        total++;
        if (s.status === 'done') done++;
      }
    }
    plan.progress = total > 0 ? Math.round((done / total) * 100) : 0;
  } else {
    const doneCount = plan.steps.filter((s) => s.status === "done").length;
    plan.progress = Math.round((doneCount / plan.steps.length) * 100);
  }

  if (plan.progress === 100) plan.status = "completed";
  else if (plan.progress > 0 && plan.status === "draft") plan.status = "active";
  plan.updatedAt = new Date().toISOString();
  return plan;
}

export function updatePlanSubTaskStatus(
  planId: string,
  stepId: string,
  subTaskId: string,
  completed?: boolean
): Plan | undefined {
  const plan = samplePlans.find((p) => p.id === planId);
  if (!plan) return undefined;
  const step = plan.steps.find((s) => s.id === stepId);
  if (!step) return undefined;

  if (!Array.isArray(step.subTasks)) {
    step.subTasks = [];
  }

  const subTask = step.subTasks.find((st) => st.id === subTaskId);
  if (!subTask) return undefined;

  const nextCompleted = completed !== undefined ? completed : !subTask.completed;
  subTask.completed = nextCompleted;
  subTask.status = nextCompleted ? 'done' : 'pending';
  subTask.completedAt = nextCompleted ? new Date().toISOString() : undefined;

  // Auto-sync parent step status
  const allDone = step.subTasks.every((st) => st.completed || st.status === 'done');
  const anyDone = step.subTasks.some((st) => st.completed || st.status === 'done');
  step.status = allDone ? 'done' : anyDone ? 'in_progress' : 'pending';

  // Recalculate plan total progress
  let total = 0;
  let done = 0;
  for (const s of plan.steps) {
    if (Array.isArray(s.subTasks) && s.subTasks.length > 0) {
      for (const st of s.subTasks) {
        total++;
        if (st.completed || st.status === 'done') done++;
      }
    } else {
      total++;
      if (s.status === 'done') done++;
    }
  }

  plan.progress = total > 0 ? Math.round((done / total) * 100) : 0;
  if (plan.progress === 100) plan.status = 'completed';
  else if (plan.progress > 0 && plan.status === 'draft') plan.status = 'active';

  plan.updatedAt = new Date().toISOString();
  return plan;
}

export function deletePlan(planId: string): boolean {
  const idx = samplePlans.findIndex((p) => p.id === planId);
  if (idx === -1) return false;
  samplePlans.splice(idx, 1);
  return true;
}

