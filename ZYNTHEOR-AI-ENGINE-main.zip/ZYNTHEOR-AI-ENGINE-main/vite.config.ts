import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    base: '/',
    resolve: {
      alias: {
        '@': path.resolve('.'),
      },
    },
    build: {
      chunkSizeWarningLimit: 600,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules')) {
              if (id.includes('/react/') || id.includes('/react-dom/') || id.includes('/scheduler/')) return 'vendor-react';
              if (id.includes('/framer-motion/')) return 'vendor-motion';
              if (id.includes('/lucide-react/')) return 'vendor-icons';
              if (id.includes('/jspdf/') || id.includes('/html2canvas/') || id.includes('/canvg/')) return 'vendor-pdf';
              if (id.includes('/jszip/')) return 'vendor-zip';
              if (id.includes('/three/')) return 'vendor-three';
              if (id.includes('/prismjs/')) return 'vendor-editor';
              if (id.includes('/recharts/') || id.includes('/d3-')) return 'vendor-charts';
              return 'vendor-libs';
            }
            if (id.includes('/src/components/views/')) return 'app-views';
            if (id.includes('/src/components/ZyntheorApiHealthDashboard')) return 'app-health-dashboard';
          },
        },
      },
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      allowedHosts: true as const,
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
