/**
 * ZYNTHEOR Auth & Cryptographic JWT Validator
 * Scope: Internal Workspace Token Checking
 */

export interface TokenClaims {
  sub: string;
  role: 'admin' | 'auditor' | 'operator';
  scope: string[];
  exp: number;
}

export function validateClaims(token: string): { valid: boolean; claims?: TokenClaims; error?: string } {
  if (!token || typeof token !== 'string') {
    return { valid: false, error: 'Empty or invalid token format' };
  }
  
  const parts = token.split('.');
  if (parts.length !== 3) {
    return { valid: false, error: 'Malformed JWT structure' };
  }

  try {
    const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf-8'));
    if (payload.exp && Date.now() / 1000 > payload.exp) {
      return { valid: false, error: 'Token has expired' };
    }
    return { valid: true, claims: payload };
  } catch (err: any) {
    return { valid: false, error: 'Failed to decode token payload: ' + err.message };
  }
}
