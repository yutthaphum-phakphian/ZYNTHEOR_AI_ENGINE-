# ZYNTHEOR AI ENGINE — Next Implementation Status

สถานะรวม: `PARTIAL` — เป็นการแก้เฉพาะ local provider timeout configuration; ยังไม่ได้ยืนยัน runtime inference ใน Codespaces

## เปลี่ยนในรอบนี้
- เพิ่ม `LOCAL_AI_TIMEOUT_MS` สำหรับ local provider โดยค่าเริ่มต้น 90,000 ms และจำกัดค่าให้อยู่ในช่วง 10,000–180,000 ms
- เมื่อ Ollama inference timeout จะคืน `provider_timeout` พร้อมข้อความระบุว่าไม่ได้ลอง Hosted fallback
- ไม่เพิ่มการ fallback ไปยัง cloud provider
- เพิ่มค่า non-secret `LOCAL_AI_TIMEOUT_MS=90000` ใน `.env.example`

## สิ่งที่ยังจำเป็นและยังไม่ถือว่าทำเสร็จ
1. ทดสอบ local inference จริงจาก Codespaces; หาก Core API/client มี timeout 30 วินาทีที่ชั้นนอก จะต้องปรับ timeout ให้สอดคล้องโดยไม่ทำให้คำขอค้างไม่จำกัดเวลา
2. แก้/ยืนยัน API route สำหรับ App Builder ให้สร้างไฟล์จริงใน workspace ที่ถูกจำกัด path, แสดง diff และตรวจผล build/test ก่อนรายงานสำเร็จ
3. ระบบสมาชิก: ต้องเลือก persistence จริง, password hashing, session/token rotation/revocation, rate limiting, CSRF/Origin controls ตาม auth strategy, server-side user/workspace authorization. GitHub OAuth ที่มีอยู่ไม่เท่ากับ email/password signup/login ที่ครบถ้วน
4. Workspace isolation และ path traversal tests ต้องผ่าน; client-supplied userId/workspaceId ห้ามถือเป็นสิทธิ์ที่เชื่อถือได้
5. Chat UI: Retry ต้องส่งคำขอจริงอย่างมีการควบคุม; Like/Dislike ควร persist ฝั่ง server ถ้าต้องการ feedback analytics; sticker actions ต้องแยกจากการสร้างข้อความ AI
6. Add and verify `package-lock.json` from the canonical repository environment; current archive has no lockfile, so reproducible `npm ci` is not yet established.
7. Run typecheck, complete test suite, production build and end-to-end tests in the real Codespace.

## Evidence from this local artifact only
- `server/provider.ts` contains bounded configurable local inference timeouts.
- Source checks below verify configuration and no cloud fallback addition; they do not prove live inference.
- Live Ollama inference: `NOT_TESTED`
- Full tests / typecheck / production build: `NOT_TESTED` (dependencies are not installed in this working environment)
