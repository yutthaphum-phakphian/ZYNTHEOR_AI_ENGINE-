# Provider Routing Remediation — Evidence Report

Status: `PARTIAL`

## Change made
- `.devcontainer/devcontainer.json`: changed the Codespaces container default from `AI_PROVIDER=none` to `AI_PROVIDER=local` so normal development defaults to the local provider.
- `.env.example`: set non-secret local defaults `AI_PROVIDER=local`, `LOCAL_AI_ENDPOINT=http://127.0.0.1:11434`, and `LOCAL_AI_MODEL=qwen2.5:1.5b`.
- `README.md`: clarified that `none` is for intentionally disabled/safety-test environments and local runtime failures must not trigger hosted fallback.

## Safety properties
- No API keys or credentials were added.
- No Hosted provider fallback was added.
- Test commands that explicitly set `AI_PROVIDER=none` were left unchanged to preserve test isolation.
- This configuration change does not install Ollama in Codespaces or prove the model can infer.

## Verification
- `devcontainer.json` JSON parse: PASS.
- `.env.example` checked for secret-like non-empty key values: PASS (all credential fields blank).
- ZIP integrity: PASS (`zipfile.testzip()` returned no corrupt member); 1,211 entries; 0 unsafe paths.
- SHA-256 of delivered ZIP: `d46d370253c26e48ff8159f5a40d302ed473bf82c49eb06e7f466fbf25adb551`.
- Typecheck / full tests / production build: NOT_TESTED in this environment because dependency installation was previously blocked by npm registry DNS (`EAI_AGAIN`).
- Live Ollama inference: NOT_TESTED; this environment cannot access the user's Codespaces runtime.

## Required user-side step
A running Codespace does not necessarily inherit a changed `containerEnv`. Rebuild/recreate the Codespace container or set `AI_PROVIDER=local` in the actual server process environment, restart the server, then run `/api/preflight?infer=1` or the project's documented inference diagnostic. Confirm the actual model response before marking inference PASS.
