import { IncomingMessage, ServerResponse } from 'http';
import { parse as parseUrl } from 'url';
import os from 'node:os';
import { listAuditEvents } from './agent.js';
import {
  inspectWorkspaceDirectory,
  readWorkspaceFileContent,
  loadLedger,
  recordLedgerEvent,
  verifyLedgerIntegrity,
  evaluateSafeMath,
  getSystemDiagnostics,
  probeLocalRuntime,
  performWebResearch,
  executeInference,
  listRegisteredProviders,
  scrubSensitiveData,
  LedgerEvent
} from './api.js';
import { listGgufModels, installAndVerifyGgufModel } from './ggufManager.js';
import { resolveLocalEndpoint } from './localEndpoint.js';

function sendJson(res: ServerResponse, statusCode: number, data: any) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-correlation-id');
  res.end(JSON.stringify(data));
}

function readBody(req: IncomingMessage): Promise<any> {
  if ((req as any).body !== undefined) {
    return Promise.resolve((req as any).body);
  }
  if ((req as any).readableEnded) {
    return Promise.resolve({});
  }
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      // 5MB safeguard
      if (body.length > 5 * 1024 * 1024) {
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch {
        resolve({ raw: body });
      }
    });
    req.on('error', () => resolve({}));
  });
}

/**
 * ZYNTHEOR CORE API MIDDLEWARE
 * 
 * Strict Zero-Fake Policy Enforcement:
 * 1. Default engine is strictly the Sovereign Local Runtime (Ollama / llama.cpp).
 * 2. Absolute ban on implicit fallback to external hosted LLMs.
 * 3. Explicitly verifies the 'localEndpoint' state and returns HTTP 503 with 'local_runtime_unavailable'
 *    whenever the local model registry is offline, connection is refused, or model weights are missing.
 * 4. External hosted providers are only accessible when explicitly chosen by the user with verified consent.
 */
const HANDLED_ROUTES: Record<string, string[]> = {
  '/api/health': ['GET'],
  '/api/workspace/inspect': ['GET'],
  '/api/workspace/file': ['GET'],
  '/api/ledger/events': ['GET'],
  '/api/ledger/verify': ['GET'],
  '/api/ledger/export': ['GET'],
  '/api/models/gguf': ['GET'],
  '/api/models/gguf/install': ['POST'],
  '/api/runtime/status': ['GET'],
  '/api/local-model/status': ['GET'],
  '/api/system/health': ['GET'],
  '/api/runtime/probe': ['POST'],
  '/api/web/search': ['POST'],
  '/api/tools/execute': ['POST'],
  '/api/code/analyze': ['POST'],
  '/api/providers': ['GET'],
  '/api/chat': ['POST'],
};

export function handleApiRequest(req: IncomingMessage, res: ServerResponse): boolean {
  const parsed = parseUrl(req.url || '', true);
  const pathname = parsed.pathname || '';

  if (!pathname.startsWith('/api')) {
    return false;
  }

  const allowedMethods = HANDLED_ROUTES[pathname];
  if (!allowedMethods || (req.method && !allowedMethods.includes(req.method) && req.method !== 'OPTIONS')) {
    return false;
  }

  // Handle CORS Preflight
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-correlation-id');
    res.end();
    return true;
  }

  (async () => {
    const startTime = Date.now();

    try {
      // 1. Health check & Sovereign Engine Telemetry
      if (pathname === '/api/health' && req.method === 'GET') {
        const diagnostics = getSystemDiagnostics();
        return sendJson(res, 200, {
          status: 'ONLINE',
          engine: 'ZYNTHEOR AI ENGINE v4.2.0',
          architecture: 'Sovereign Core Architecture (Independent Local AI Runtime)',
          zeroFakePolicy: {
            enforced: true,
            implicitHostedFallback: false,
            disallowSimulatedOutputs: true,
            statusCodeOnUnavailable: 503,
            errorCodeOnUnavailable: 'local_runtime_unavailable',
          },
          diagnostics
        });
      }

      // System Health: Uptime, Active background threads, and Critical errors
      if (pathname === '/api/system/health' && req.method === 'GET') {
        const threads = (process as any).availableParallelism ? (process as any).availableParallelism() : (os.cpus()?.length || 4);
        const uptimeSec = Math.floor(process.uptime());
        let allAuditEvents: any[] = [];
        try {
          allAuditEvents = await listAuditEvents();
        } catch {
          allAuditEvents = [];
        }

        const criticalErrors = (allAuditEvents || [])
          .filter((e: any) => {
            const type = String(e.type || '').toUpperCase();
            const dataStr = JSON.stringify(e.data || '').toUpperCase();
            return type.includes('ERROR') || type.includes('CRITICAL') || type.includes('FAIL') || dataStr.includes('FATAL') || dataStr.includes('CRITICAL_ERROR');
          })
          .slice(0, 10)
          .map((e: any) => ({
            id: e.id || e.hash || `err-${Date.now()}`,
            timestamp: e.timestamp,
            type: e.type,
            summary: e.data?.message || e.data?.error || e.type,
            data: e.data,
          }));

        return sendJson(res, 200, {
          status: 'ok',
          uptimeSeconds: uptimeSec,
          systemUptimeSeconds: Math.floor(os.uptime()),
          activeBackgroundThreads: threads,
          activeHandles: (process as any)._getActiveHandles ? (process as any)._getActiveHandles().length : threads,
          criticalErrorsCount: criticalErrors.length,
          recentCriticalErrors: criticalErrors,
          totalAuditEvents: (allAuditEvents || []).length,
          timestamp: new Date().toISOString(),
        });
      }

      // 2. Special Command: Inspect .data/workspace files & sizes
      if (pathname === '/api/workspace/inspect' && req.method === 'GET') {
        const inspection = inspectWorkspaceDirectory();
        const latency = Date.now() - startTime;
        recordLedgerEvent(
          'WORKSPACE_SCAN',
          'TOOL_EXECUTION',
          'TOOL_REGISTRY',
          'PASS',
          '.data/workspace',
          `Scanned ${inspection.totalFiles} workspace files (${inspection.totalSizeFormatted}) within boundary scope.`,
          { totalFiles: inspection.totalFiles, size: inspection.totalSizeBytes },
          latency
        );
        return sendJson(res, 200, inspection);
      }

      // 3. Read specific workspace file safely
      if (pathname === '/api/workspace/file' && req.method === 'GET') {
        const targetPath = (parsed.query.path as string) || '';
        const fileData = readWorkspaceFileContent(targetPath);
        const latency = Date.now() - startTime;
        recordLedgerEvent(
          'WORKSPACE_SCAN',
          'TOOL_EXECUTION',
          'SECURITY_BARRIER',
          fileData.success ? 'PASS' : 'BLOCKED',
          targetPath,
          fileData.success ? `Read workspace file: ${targetPath}` : `Blocked or missing file: ${fileData.error}`,
          { path: targetPath, success: fileData.success },
          latency
        );
        return sendJson(res, fileData.success ? 200 : 400, fileData);
      }

      // 4. Ledger: Get all events & Raw Cryptographic Evidence (/api/ledger/events)
      if (pathname === '/api/ledger/events' && req.method === 'GET') {
        const events = loadLedger();
        const verification = verifyLedgerIntegrity();
        return sendJson(res, 200, {
          status: 'available',
          total: events.length,
          verification,
          events,
          correlationId: (parsed.query.correlationId as string) || `corr_${Date.now()}`
        });
      }

      // 4.1 GGUF Models Management API (Download, Installation & SHA-256 Validation)
      if (pathname === '/api/models/gguf' && req.method === 'GET') {
        const models = listGgufModels();
        return sendJson(res, 200, {
          status: 'available',
          models,
        });
      }

      if (pathname === '/api/models/gguf/install' && req.method === 'POST') {
        const body = await readBody(req);
        const modelId = body?.modelId;
        if (!modelId) {
          return sendJson(res, 400, { error: 'modelId is required' });
        }
        try {
          const result = await installAndVerifyGgufModel(modelId);
          return sendJson(res, 200, result);
        } catch (err: any) {
          return sendJson(res, 400, { error: err.message || 'Failed to install GGUF model' });
        }
      }

      // 5. Ledger: Cryptographic Verification
      if (pathname === '/api/ledger/verify' && req.method === 'GET') {
        const verification = verifyLedgerIntegrity();
        return sendJson(res, 200, verification);
      }

      // 6. Ledger: Export Audit Report (JSON, CSV, or Markdown)
      if (pathname === '/api/ledger/export' && req.method === 'GET') {
        const format = (parsed.query.format as string) || 'markdown';
        const events = loadLedger();
        const verification = verifyLedgerIntegrity();

        const passCount = events.filter((e) => e.status === 'PASS').length;
        const blockedCount = events.filter((e) => e.status === 'BLOCKED').length;
        const failCount = events.filter((e) => e.status === 'FAIL').length;

        if (format === 'json') {
          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Content-Disposition', 'attachment; filename="zyntheor_audit_ledger.json"');
          return res.end(JSON.stringify({ verification, summary: { total: events.length, passCount, blockedCount, failCount }, events }, null, 2));
        }

        if (format === 'csv') {
          res.setHeader('Content-Type', 'text/csv');
          res.setHeader('Content-Disposition', 'attachment; filename="zyntheor_audit_ledger.csv"');
          let csv = 'Index,Timestamp,EventType,PipelineStage,Actor,Status,Target,LatencyMs,LedgerHash\n';
          for (const ev of events) {
            const cleanTarget = `"${(ev.target || '').replace(/"/g, '""')}"`;
            const cleanDetails = `"${(ev.details || '').replace(/"/g, '""')}"`;
            csv += `${ev.index},${ev.timestamp},${ev.eventType},${ev.pipelineStage},${ev.actor},${ev.status},${cleanTarget},${ev.latencyMs},${ev.ledgerHash}\n`;
          }
          return res.end(csv);
        }

        // Markdown Report
        res.setHeader('Content-Type', 'text/markdown');
        res.setHeader('Content-Disposition', 'attachment; filename="zyntheor_audit_report.md"');
        let md = `# ZYNTHEOR AI ENGINE - AUDIT & CRYPTOGRAPHIC EVIDENCE REPORT\n\n`;
        md += `Generated at: ${new Date().toISOString()}\n`;
        md += `Ledger Status: ${verification.isValid ? 'VERIFIED (Chain Untampered)' : 'FAILED (Tampering Detected)'}\n`;
        md += `Total Pipeline Events: ${events.length} | PASS: ${passCount} | BLOCKED: ${blockedCount} | FAIL: ${failCount}\n`;
        md += `Genesis Hash: \`${verification.genesisHash}\`\n`;
        md += `Terminal Ledger Hash: \`${verification.latestHash}\`\n\n`;
        md += `## Execution Pipeline Activity Summary\n\n`;
        md += `| # | Timestamp | Event Type | Stage | Actor | Status | Target | Latency | SHA-256 Seal |\n`;
        md += `|---|---|---|---|---|---|---|---|---|\n`;
        for (const ev of events) {
          const shortHash = ev.ledgerHash.slice(0, 10) + '...';
          md += `| ${ev.index} | ${ev.timestamp.split('T')[1]?.slice(0, 8)} | ${ev.eventType} | ${ev.pipelineStage} | ${ev.actor} | **${ev.status}** | ${ev.target} | ${ev.latencyMs}ms | \`${shortHash}\` |\n`;
        }
        md += `\n---\n*Report generated under ZYNTHEOR Zero-Fake Policy and Cryptographic Integrity Enforcement.*`;
        return res.end(md);
      }

      // 7. System Diagnostics & Real Local Model Status
      if ((pathname === '/api/runtime/status' || pathname === '/api/local-model/status') && req.method === 'GET') {
        const resolvedEndpoint = resolveLocalEndpoint(parsed.query.endpoint, parsed.query.localEndpoint);
        if (!resolvedEndpoint.ok) {
          return sendJson(res, 400, { status: 'BLOCKED', code: resolvedEndpoint.code, message: resolvedEndpoint.message });
        }
        const localEndpoint = resolvedEndpoint.endpoint;

        const diagnostics = getSystemDiagnostics();
        const localProbe = await probeLocalRuntime(localEndpoint);

        return sendJson(res, 200, {
          status: localProbe.connected ? 'ONLINE' : 'OFFLINE',
          connected: localProbe.connected,
          endpoint: localEndpoint,
          localEndpoint,
          models: localProbe.models,
          availableModels: localProbe.models,
          latencyMs: localProbe.latencyMs,
          message: localProbe.message,
          diagnostics,
          localProbe,
          zeroFakeEnforced: true,
          defaultProvider: 'LOCAL_OLLAMA'
        });
      }

      // 8. Probe custom runtime endpoint
      if (pathname === '/api/runtime/probe' && req.method === 'POST') {
        const body = await readBody(req);
        const resolvedEndpoint = resolveLocalEndpoint(body.localEndpoint, body.endpoint);
        if (!resolvedEndpoint.ok) {
          return sendJson(res, 400, { status: 'BLOCKED', code: resolvedEndpoint.code, message: resolvedEndpoint.message });
        }
        const endpoint = resolvedEndpoint.endpoint;
        const probe = await probeLocalRuntime(endpoint);
        return sendJson(res, 200, {
          ...probe,
          localEndpoint: endpoint
        });
      }

      // 9. Web Research with SSRF prevention
      if (pathname === '/api/web/search' && req.method === 'POST') {
        const body = await readBody(req);
        const query = body.query || '';
        const searchResult = await performWebResearch(query);
        const latency = Date.now() - startTime;

        recordLedgerEvent(
          'WEB_RESEARCH',
          'TOOL_EXECUTION',
          'TOOL_REGISTRY',
          searchResult.success ? 'PASS' : 'FAIL',
          'DuckDuckGo/Wikipedia Provider',
          searchResult.success ? `Found ${searchResult.results.length} public sources for query "${query}"` : `Web research failed: ${searchResult.error}`,
          { query, resultsCount: searchResult.results.length },
          latency
        );

        return sendJson(res, searchResult.success ? 200 : 400, searchResult);
      }

      // 10. Tools execution engine
      if (pathname === '/api/tools/execute' && req.method === 'POST') {
        const body = await readBody(req);
        const { tool, args } = body;

        if (tool === 'calculator') {
          const evalRes = evaluateSafeMath(args?.expression || '');
          const latency = Date.now() - startTime;
          recordLedgerEvent(
            'TOOL_INVOCATION',
            'TOOL_EXECUTION',
            'TOOL_REGISTRY',
            evalRes.success ? 'PASS' : 'FAIL',
            'calculator',
            evalRes.success ? `Evaluated ${args?.expression} = ${evalRes.result}` : `Calculator error: ${evalRes.error}`,
            { expression: args?.expression, result: evalRes.result },
            latency
          );
          return sendJson(res, evalRes.success ? 200 : 400, evalRes);
        }

        if (tool === 'system_diagnostics') {
          const diag = getSystemDiagnostics();
          const latency = Date.now() - startTime;
          recordLedgerEvent(
            'DIAGNOSTICS_CHECK',
            'TOOL_EXECUTION',
            'TOOL_REGISTRY',
            'PASS',
            'system_diagnostics',
            `Queried system telemetry: Memory RSS ${diag.memory.rssFormatted}, Load: ${diag.cpu.loadAvg[0].toFixed(2)}`,
            diag,
            latency
          );
          return sendJson(res, 200, { success: true, diagnostics: diag });
        }

        if (tool === 'inspect_workspace') {
          const inspect = inspectWorkspaceDirectory();
          return sendJson(res, 200, { success: true, workspace: inspect });
        }

        if (tool === 'file_search') {
          const inspect = inspectWorkspaceDirectory();
          const query = (args?.query || '').toLowerCase();
          const extFilter = (args?.extension || '').toLowerCase();
          const matches = inspect.files.filter((f) => {
            if (extFilter && !f.extension.toLowerCase().includes(extFilter)) return false;
            return f.name.toLowerCase().includes(query) || f.relativePath.toLowerCase().includes(query);
          });
          const latency = Date.now() - startTime;
          recordLedgerEvent(
            'WORKSPACE_SCAN',
            'TOOL_EXECUTION',
            'TOOL_REGISTRY',
            'PASS',
            'file_search',
            `Searched workspace for query '${query}'. Found ${matches.length} matches.`,
            { query, matchesCount: matches.length },
            latency
          );
          return sendJson(res, 200, { success: true, query, totalFound: matches.length, files: matches });
        }

        if (tool === 'code_runner') {
          const latency = Date.now() - startTime;
          recordLedgerEvent(
            'SECURITY_VALIDATION',
            'POLICY_VERIFICATION',
            'SECURITY_BARRIER',
            'BLOCKED',
            'code_runner',
            'Blocked unsandboxed code execution request to prevent container host compromise.',
            { command: args?.command || 'run_code' },
            latency
          );
          return sendJson(res, 403, {
            success: false,
            status: 'BLOCKED',
            reason: 'Zero-Fake Policy Violation: Code execution requires an isolated microVM sandbox. In this cloud container environment, unsandboxed execution is disabled for security.'
          });
        }

        if (tool === 'data_inspector') {
          try {
            const raw = args?.data || '';
            const parsedData = JSON.parse(raw);
            const isArray = Array.isArray(parsedData);
            const count = isArray ? parsedData.length : Object.keys(parsedData).length;
            const keys = isArray && parsedData[0] ? Object.keys(parsedData[0]) : Object.keys(parsedData);
            return sendJson(res, 200, {
              success: true,
              type: isArray ? 'ARRAY' : 'OBJECT',
              entriesCount: count,
              keys,
              sample: isArray ? parsedData.slice(0, 3) : parsedData
            });
          } catch (err: any) {
            return sendJson(res, 400, { success: false, error: 'Data parsing error: ' + err.message });
          }
        }

        return sendJson(res, 404, { success: false, error: `Tool '${tool}' not found in registry.` });
      }

      // 11. Code Assistant & Analysis
      if (pathname === '/api/code/analyze' && req.method === 'POST') {
        const body = await readBody(req);
        const { code, language } = body;
        const latency = Date.now() - startTime;

        const issues: string[] = [];
        if (/eval\s*\(/.test(code)) issues.push('High-risk function eval() detected.');
        if (/innerHTML\s*=/.test(code)) issues.push('Direct innerHTML assignment detected (Potential XSS risk).');
        if (/process\.exit/.test(code)) issues.push('process.exit() detected in server code.');
        if (/API_KEY\s*=\s*['"][a-zA-Z0-9_\-]{20,}['"]/.test(code)) issues.push('Hardcoded credential or API key found in source.');

        recordLedgerEvent(
          'CODE_ANALYSIS',
          'TOOL_EXECUTION',
          'TOOL_REGISTRY',
          issues.length > 0 ? 'FAIL' : 'PASS',
          language || 'typescript',
          `Analyzed code snippet (${code.length} chars). Detected ${issues.length} security/quality issues.`,
          { lines: code.split('\n').length, issuesCount: issues.length },
          latency
        );

        return sendJson(res, 200, {
          success: true,
          linesCount: code.split('\n').length,
          characterCount: code.length,
          issues,
          status: issues.length > 0 ? 'SECURITY_WARNING' : 'CLEAN',
          executionStatus: 'BLOCKED (Sandbox Required)'
        });
      }

      // 12. Inference Providers List
      if (pathname === '/api/providers' && req.method === 'GET') {
        const providers = listRegisteredProviders();
        return sendJson(res, 200, {
          defaultProvider: 'LOCAL_OLLAMA',
          providers
        });
      }

      // 13. Inference (Chat / Analysis) - Strict Local-First, Zero-Fake Policy
      if (pathname === '/api/chat' && req.method === 'POST') {
        const body = await readBody(req);
        const prompt = (
          body.prompt ||
          body.message ||
          (Array.isArray(body.messages) ? body.messages[body.messages.length - 1]?.content : '') ||
          ''
        ).trim();

        if (!prompt) {
          return sendJson(res, 400, {
            success: false,
            statusCode: 400,
            errorCode: 'empty_prompt',
            message: 'Prompt or message string is required.'
          });
        }

        const systemInstruction = body.systemInstruction || body.systemPrompt;
        const rawProvider = (body.provider || 'local').toUpperCase();
        if (rawProvider === 'GOOGLE_GEMINI' || rawProvider === 'GEMINI') {
          return sendJson(res, 400, {
            success: false,
            status: 'BLOCKED',
            code: 'provider_removed',
            message: 'Gemini support has been removed. No provider was called.',
            fallbackTriggered: false
          });
        }
        const isHosted =
          rawProvider === 'OPENAI' ||
          rawProvider === 'ANTHROPIC' ||
          rawProvider === 'HOSTED';

        // Resolve Local Endpoint target
        const resolvedLocalEndpoint = resolveLocalEndpoint(body.localEndpoint, body.endpoint);
        if (!resolvedLocalEndpoint.ok) {
          return sendJson(res, 400, { status: 'BLOCKED', code: resolvedLocalEndpoint.code, message: resolvedLocalEndpoint.message, fallbackTriggered: false });
        }
        const localEndpoint = resolvedLocalEndpoint.endpoint;

        const targetModel = (
          body.modelId ||
          body.model ||
          process.env.LOCAL_AI_MODEL ||
          process.env.LOCAL_MODEL_NAME ||
          'llama3.2'
        ).trim();

        // -------------------------------------------------------------
        // BRANCH A: HOSTED PROVIDER MODE (Explicit User Opt-In Only)
        // -------------------------------------------------------------
        if (isHosted) {
          const hasExplicitConsent = body.explicitUserConsent === true || body.userConfirmed === true;
          if (!hasExplicitConsent) {
            const latency = Date.now() - startTime;
            recordLedgerEvent(
              'SECURITY_VALIDATION',
              'POLICY_VERIFICATION',
              'SECURITY_BARRIER',
              'BLOCKED',
              rawProvider,
              'Blocked unconfirmed hosted provider execution. Explicit user consent is mandatory.',
              { provider: rawProvider },
              latency
            );
            return sendJson(res, 400, {
              success: false,
              statusCode: 400,
              code: 'hosted_consent_required',
              errorCode: 'hosted_consent_required',
              status: 'BLOCKED',
              error: 'Explicit user consent required for hosted providers',
              message: 'External hosted providers cannot be invoked without explicit user consent. Zyntheor defaults strictly to sovereign local execution.',
              fallbackTriggered: false
            });
          }

          // Execute only the chosen hosted provider. If it fails, report error directly. Never fallback!
          const inferenceResult = await executeInference(
            prompt,
            systemInstruction,
            rawProvider,
            targetModel,
            localEndpoint
          );
          const latency = Date.now() - startTime;

          const scrubbedDetails = scrubSensitiveData(
            inferenceResult.success
              ? `Hosted inference executed via ${inferenceResult.provider} (${inferenceResult.modelId}) in ${latency}ms [Status: PASS]`
              : `Hosted inference error on ${inferenceResult.provider}: ${inferenceResult.message || inferenceResult.errorCode} [Status: ${inferenceResult.status}]`
          );

          recordLedgerEvent(
            'INFERENCE_REQUEST',
            'CORE_INFERENCE',
            'AI_CORE',
            inferenceResult.status,
            `${inferenceResult.provider}:${inferenceResult.modelId}`,
            scrubbedDetails,
            { provider: inferenceResult.provider, status: inferenceResult.status },
            latency
          );

          return sendJson(res, inferenceResult.statusCode || (inferenceResult.success ? 200 : 502), inferenceResult);
        }

        // -------------------------------------------------------------
        // BRANCH B: SOVEREIGN LOCAL MODE (Default Brain)
        // Strict Zero-Fake Policy:
        // 1. Explicitly check 'localEndpoint' state first!
        // 2. Return HTTP 503 if local model registry is unavailable.
        // 3. ZERO implicit fallback to any hosted LLM.
        // -------------------------------------------------------------
        const localProbe = await probeLocalRuntime(localEndpoint);

        // Check 1: Is local runtime endpoint reachable with available models?
        if (!localProbe.connected || !localProbe.models || localProbe.models.length === 0) {
          const latency = Date.now() - startTime;
          const failureReason = localProbe.message || 'Connection refused or daemon offline';

          recordLedgerEvent(
            'INFERENCE_REQUEST',
            'CORE_INFERENCE',
            'AI_CORE',
            'UNAVAILABLE',
            `LOCAL_OLLAMA:${localEndpoint}`,
            `Local model registry unavailable at ${localEndpoint} (${failureReason}). Zero-Fake Policy enforced: automatic external fallback is blocked.`,
            { localEndpoint, connected: localProbe.connected, modelsCount: localProbe.models?.length || 0 },
            latency
          );

          const standard503Payload = {
            success: false,
            status: 'UNAVAILABLE',
            statusCode: 503,
            code: 'local_runtime_unavailable',
            errorCode: 'local_runtime_unavailable',
            error: 'Local AI runtime is unavailable',
            message: `Local model registry is unavailable at ${localEndpoint}. Start your local runtime daemon ('ollama serve' or llama-server) and pull model weights ('ollama pull ${targetModel}').`,
            details: `Local model registry is unavailable at ${localEndpoint} (${failureReason}). Per Zero-Fake Policy, external hosted fallback is strictly prohibited.`,
            localEndpoint,
            availableModels: localProbe.models || [],
            targetModel,
            fallbackTriggered: false,
            provider: 'LOCAL_OLLAMA',
            remediationSteps: [
              `1. Ensure your local AI runtime daemon is active: run 'ollama serve' or start llama.cpp server.`,
              `2. Verify that model weights are downloaded: run 'ollama pull ${targetModel}'.`,
              `3. Check network connectivity to the local endpoint URL: ${localEndpoint}.`,
              `4. Zero-Fake Invariant: System will NEVER fall back to a hosted LLM automatically.`
            ],
            assistantMessage: {
              id: `msg_err_${Date.now()}`,
              role: 'assistant',
              content: `[UNAVAILABLE] ไม่สามารถเชื่อมต่อ Local AI Runtime ที่ ${localEndpoint} ได้ (${failureReason})\n\nกรุณาเปิดการทำงานของ runtime ด้วยคำสั่ง 'ollama serve' หรือ llama-server และติดตั้งโมเดล '${targetModel}' ก่อนใช้งาน\n\n(ระบบปฏิบัติตาม Zero-Fake Policy อย่างเคร่งครัด: จะไม่มีการส่งคำขอไปยัง Hosted LLM โดยเด็ดขาด)`,
              createdAt: new Date().toISOString()
            }
          };

          return sendJson(res, 503, standard503Payload);
        }

        // Check 2: If a specific model was requested, verify it exists in local model registry
        const requestedModel = targetModel;
        const modelExists = localProbe.models.some(
          (m) => m.toLowerCase() === requestedModel.toLowerCase() ||
                 m.toLowerCase().startsWith(requestedModel.toLowerCase() + ':') ||
                 requestedModel.toLowerCase().startsWith(m.toLowerCase() + ':')
        );

        if (!modelExists && (body.modelId || body.model)) {
          const latency = Date.now() - startTime;
          recordLedgerEvent(
            'INFERENCE_REQUEST',
            'CORE_INFERENCE',
            'AI_CORE',
            'UNAVAILABLE',
            `LOCAL_OLLAMA:${requestedModel}`,
            `Model '${requestedModel}' not found in local registry at ${localEndpoint}. Available: [${localProbe.models.join(', ')}]. Zero-Fake Policy enforced.`,
            { localEndpoint, requestedModel, availableModels: localProbe.models },
            latency
          );

          return sendJson(res, 503, {
            success: false,
            status: 'UNAVAILABLE',
            statusCode: 503,
            code: 'local_runtime_unavailable',
            errorCode: 'local_runtime_unavailable',
            error: 'Model not found in local model registry',
            message: `Model '${requestedModel}' is not installed in local runtime at ${localEndpoint}. Available models: [${localProbe.models.join(', ')}]. Run 'ollama pull ${requestedModel}'.`,
            details: `Model '${requestedModel}' not found in local model registry at ${localEndpoint}. Zero-Fake Policy prohibits faking output or falling back to external hosted models.`,
            localEndpoint,
            availableModels: localProbe.models,
            requestedModel,
            fallbackTriggered: false,
            provider: 'LOCAL_OLLAMA',
            remediationSteps: [
              `Run 'ollama pull ${requestedModel}' in your terminal.`,
              `Or switch to an installed model: ${localProbe.models.join(', ')}`
            ],
            assistantMessage: {
              id: `msg_err_${Date.now()}`,
              role: 'assistant',
              content: `[UNAVAILABLE] ไม่พบโมเดล '${requestedModel}' ใน Local Runtime (${localEndpoint})\n\nโมเดลที่มีในเครื่อง: [${localProbe.models.join(', ')}]\nกรุณารัน 'ollama pull ${requestedModel}' ก่อนใช้งาน`,
              createdAt: new Date().toISOString()
            }
          });
        }

        // Check 3: Execute genuine local model inference
        const activeModel = modelExists ? requestedModel : localProbe.models[0];
        const inferenceResult = await executeInference(
          prompt,
          systemInstruction,
          'LOCAL_OLLAMA',
          activeModel,
          localEndpoint,
          undefined,
          typeof body.timeoutMs === 'number' ? body.timeoutMs : undefined
        );
        const latency = Date.now() - startTime;

        const scrubbedDetails = scrubSensitiveData(
          inferenceResult.success
            ? `Inference executed via ${inferenceResult.provider} (${inferenceResult.modelId}) in ${latency}ms [Status: PASS]`
            : `Inference error on ${inferenceResult.provider}: ${inferenceResult.message || inferenceResult.errorCode} [Status: ${inferenceResult.status}]`
        );

        recordLedgerEvent(
          'INFERENCE_REQUEST',
          'CORE_INFERENCE',
          'AI_CORE',
          inferenceResult.status,
          `${inferenceResult.provider}:${inferenceResult.modelId}`,
          scrubbedDetails,
          {
            provider: inferenceResult.provider,
            modelId: inferenceResult.modelId,
            promptLength: prompt.length,
            status: inferenceResult.status,
            errorCode: inferenceResult.errorCode,
            localEndpoint
          },
          latency
        );

        // If local inference failed (e.g. timeout or internal error):
        // Enforce ZERO automatic fallback to hosted LLMs; return the local result directly.
        if (!inferenceResult.success) {
          return sendJson(res, inferenceResult.statusCode || 503, {
            ...inferenceResult,
            code: inferenceResult.errorCode || 'local_runtime_unavailable',
            localEndpoint,
            fallbackTriggered: false,
            assistantMessage: {
              id: `msg_err_${Date.now()}`,
              role: 'assistant',
              content: `[UNAVAILABLE] การประมวลผลบน Local Runtime ล้มเหลว: ${inferenceResult.message || 'Timeout / Inference error'}\n\n(ไม่มีการ fallback ไปยัง Hosted LLM ตาม Zero-Fake Policy)`,
              createdAt: new Date().toISOString()
            }
          });
        }

        // Return successful 200 response with genuine local output
        return sendJson(res, 200, {
          ...inferenceResult,
          localEndpoint,
          fallbackTriggered: false,
          assistantMessage: {
            id: `msg_${Date.now()}`,
            role: 'assistant',
            content: inferenceResult.response,
            status: 'AVAILABLE',
            createdAt: new Date().toISOString()
          }
        });
      }

      sendJson(res, 404, { error: `Endpoint ${pathname} not found.` });
    } catch (err: any) {
      console.error('API Error:', err);
      sendJson(res, 500, { error: 'Internal Server Error: ' + err.message });
    }
  })();

  return true;
}
