/**
 * Custom Engine Mode Configuration Schema & Deterministic Validator
 * Enforces user-defined policies: analysis depth, allowed connectors,
 * mandatory approval, and file modification restrictions.
 * Rejects invalid configurations with exact error descriptions.
 */

export type CustomDepth = "AUTO" | "FAST" | "DEEP";
export type CustomStrictness = "permissive" | "standard" | "strict";

export const KNOWN_CONNECTORS = ["github", "web_research", "file_store", "external_api"] as const;
export type KnownConnector = typeof KNOWN_CONNECTORS[number];

export interface CustomEngineConfig {
  depth?: CustomDepth;
  allowedConnectors?: string[];
  requiresApproval?: boolean;
  allowFileModifications?: boolean;
  maxSteps?: number;
  strictness?: CustomStrictness;
}

export const DEFAULT_CUSTOM_CONFIG: Required<CustomEngineConfig> = {
  depth: "AUTO",
  allowedConnectors: ["github", "web_research", "file_store", "external_api"],
  requiresApproval: false,
  allowFileModifications: true,
  maxSteps: 10,
  strictness: "standard",
};

const ALLOWED_KEYS = new Set([
  "depth",
  "allowedConnectors",
  "requiresApproval",
  "allowFileModifications",
  "maxSteps",
  "strictness",
]);

export interface ValidationResult {
  ok: boolean;
  code?: "invalid_custom_config";
  errors?: string[];
  config?: Required<CustomEngineConfig>;
}

/**
 * Validates a custom engine configuration object.
 * Rejects any unexpected keys, wrong types, or out-of-bound values.
 */
export function validateCustomConfig(input: unknown): ValidationResult {
  if (typeof input !== "object" || input === null || Array.isArray(input)) {
    return {
      ok: false,
      code: "invalid_custom_config",
      errors: ["Custom config must be a JSON object"],
    };
  }

  const record = input as Record<string, unknown>;
  const errors: string[] = [];

  // Check for unknown keys
  for (const key of Object.keys(record)) {
    if (!ALLOWED_KEYS.has(key)) {
      errors.push(`Unrecognized property: '${key}'`);
    }
  }

  // Validate depth
  let depth: CustomDepth = DEFAULT_CUSTOM_CONFIG.depth;
  if ("depth" in record && record.depth !== undefined) {
    if (record.depth === "AUTO" || record.depth === "FAST" || record.depth === "DEEP") {
      depth = record.depth;
    } else {
      errors.push(`Invalid 'depth': expected 'AUTO', 'FAST', or 'DEEP', got '${String(record.depth)}'`);
    }
  }

  // Validate allowedConnectors
  let allowedConnectors: string[] = [...DEFAULT_CUSTOM_CONFIG.allowedConnectors];
  if ("allowedConnectors" in record && record.allowedConnectors !== undefined) {
    if (!Array.isArray(record.allowedConnectors)) {
      errors.push("'allowedConnectors' must be an array of strings");
    } else {
      const validSet = new Set<string>();
      for (const item of record.allowedConnectors) {
        if (typeof item !== "string") {
          errors.push(`Connector element must be string, got '${typeof item}'`);
        } else if (!KNOWN_CONNECTORS.includes(item as KnownConnector)) {
          errors.push(`Unknown connector '${item}'. Allowed connectors: ${KNOWN_CONNECTORS.join(", ")}`);
        } else {
          validSet.add(item);
        }
      }
      allowedConnectors = Array.from(validSet);
    }
  }

  // Validate requiresApproval
  let requiresApproval: boolean = DEFAULT_CUSTOM_CONFIG.requiresApproval;
  if ("requiresApproval" in record && record.requiresApproval !== undefined) {
    if (typeof record.requiresApproval === "boolean") {
      requiresApproval = record.requiresApproval;
    } else {
      errors.push(`'requiresApproval' must be boolean, got '${typeof record.requiresApproval}'`);
    }
  }

  // Validate allowFileModifications
  let allowFileModifications: boolean = DEFAULT_CUSTOM_CONFIG.allowFileModifications;
  if ("allowFileModifications" in record && record.allowFileModifications !== undefined) {
    if (typeof record.allowFileModifications === "boolean") {
      allowFileModifications = record.allowFileModifications;
    } else {
      errors.push(`'allowFileModifications' must be boolean, got '${typeof record.allowFileModifications}'`);
    }
  }

  // Validate maxSteps
  let maxSteps: number = DEFAULT_CUSTOM_CONFIG.maxSteps;
  if ("maxSteps" in record && record.maxSteps !== undefined) {
    if (
      typeof record.maxSteps === "number" &&
      Number.isInteger(record.maxSteps) &&
      record.maxSteps >= 1 &&
      record.maxSteps <= 20
    ) {
      maxSteps = record.maxSteps;
    } else {
      errors.push(`'maxSteps' must be an integer between 1 and 20, got '${String(record.maxSteps)}'`);
    }
  }

  // Validate strictness
  let strictness: CustomStrictness = DEFAULT_CUSTOM_CONFIG.strictness;
  if ("strictness" in record && record.strictness !== undefined) {
    if (record.strictness === "permissive" || record.strictness === "standard" || record.strictness === "strict") {
      strictness = record.strictness;
    } else {
      errors.push(`'strictness' must be 'permissive', 'standard', or 'strict', got '${String(record.strictness)}'`);
    }
  }

  if (errors.length > 0) {
    return {
      ok: false,
      code: "invalid_custom_config",
      errors,
    };
  }

  return {
    ok: true,
    config: {
      depth,
      allowedConnectors,
      requiresApproval,
      allowFileModifications,
      maxSteps,
      strictness,
    },
  };
}
