import { createHash, randomUUID } from "node:crypto";
import { loadAgentEvents, redactSecrets, containsSensitiveData, saveAgentEvent, loadEvidenceRecords, type AgentEvent, type AuditAcknowledgment } from "./store.js";
import { connectorHub } from "./connectorHub.js";

export type PlanStatus =
  | "PROPOSED"
  | "WAITING_APPROVAL"
  | "APPROVED"
  | "RUNNING"
  | "SUCCEEDED"
  | "FAILED"
  | "BLOCKED"
  | "UNKNOWN";

export type StepStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "BLOCKED" | "UNKNOWN";
export type VerificationStatus = "VERIFIED" | "FAILED" | "UNKNOWN";
export type RiskLevel = "LOW" | "MEDIUM" | "HIGH";
export type PlanSource = "ai" | "system";

export type PlanStep = {
  id: string;
  tool: string;
  input: Record<string, unknown>;
  dependsOn: string[];
  successCondition: string;
  status: StepStatus;
  startedAt?: string;
  finishedAt?: string;
  durationMs?: number;
  correlationId?: string;
  error?: string;
  result?: ToolResult;
  verification?: Verification;
};
const grantedPermissions = new Set(["read:clock", "read:local-runtime"]);

export type Plan = {
  id: string;
  correlationId?: string;
  goal: string;
  riskLevel: RiskLevel;
  requiredTools: string[];
  successCriteria: string[];
  source: PlanSource;
  createdAt: string;
  updatedAt: string;
  revision: number;
  status: PlanStatus;
  hash: string;
  steps: PlanStep[];
  approval?: { id: string; planHash: string; approvedAt: string; usedAt?: string; expiresAt?: string; contextHash?: string };
  auditAck?: AuditAcknowledgment;
  honestReport?: HonestReport;
};

export type HonestReport = {
  goal: string;
  finalStatus: PlanStatus;
  actionsPerformed: Array<{
    stepId: string;
    tool: string;
    status: StepStatus;
    verified: boolean;
    evidence?: string;
    durationMs?: number;
  }>;
  verifiedEvidence: string[];
  actionsNotPerformed: Array<{
    stepId: string;
    tool: string;
    reason: string;
  }>;
  blockersOrMissingPermissions: string[];
  isPartial: boolean;
  summary: string;
};

export type ToolResult = {
  observedAt: string;
  value: Record<string, unknown>;
};
export type Verification = { status: VerificationStatus; checkedAt: string; evidence: string };
export type ToolInputSchema = {
  type: "object";
  properties: Record<string, {
    type: string;
    required?: string[];
    properties?: Record<string, unknown>;
    additionalProperties?: boolean;
    items?: unknown;
    enum?: unknown[];
    format?: string;
  }>;
  required: string[];
  additionalProperties: boolean;
};
export type PlanDraft = {
  goal: unknown;
  steps: unknown;
  riskLevel?: unknown;
  successCriteria?: unknown;
  correlationId?: unknown;
};
export type AgentErrorCode =
  | "invalid_plan"
  | "plan_not_found"
  | "plan_not_approvable"
  | "approval_required"
  | "approval_mismatch"
  | "approval_replayed"
  | "approval_expired"
  | "dependency_not_satisfied"
  | "tool_unavailable"
  | "storage_unavailable";

export class AgentError extends Error {
  constructor(public readonly code: AgentErrorCode, message: string, public readonly statusCode: number) {
    super(message);
  }
}

export type ToolAdapter = {
  name: string;
  description: string;
  permission: string;
  risk: RiskLevel;
  available: boolean;
  configured?: boolean;
  reachable?: boolean;
  availabilityReason?: string;
  inputSchema: ToolInputSchema;
  outputSchema: {
    type: "object";
    properties: Record<string, unknown>;
    required: string[];
    additionalProperties: false;
  };
  successCondition: string;
  execute: (input: Record<string, unknown>) => Promise<ToolResult>;
  verify: (result: unknown) => Verification;
};

const tools: Record<string, ToolAdapter> = {
  get_time: {
    name: "get_time",
    description: "Read the current server time. This tool has no side effects.",
    permission: "read:clock",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: { type: "object", properties: {}, required: [], additionalProperties: false },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["isoTimestamp"],
          additionalProperties: false,
          properties: { isoTimestamp: { type: "string", format: "date-time" } }
        }
      }
    },
    successCondition: "result.value.isoTimestamp is a valid ISO timestamp equal to result.observedAt",
    async execute(input) {
      if (Object.keys(input).length !== 0) throw new AgentError("invalid_plan", "get_time accepts no input fields.", 400);
      const observedAt = new Date().toISOString();
      return { observedAt, value: { isoTimestamp: observedAt } };
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Tool result is missing or not an object." };
      }
      const candidate = result as Partial<ToolResult>;
      const timestamp = candidate.value?.isoTimestamp;
      const observedAt = candidate.observedAt;
      if (typeof timestamp !== "string" || typeof observedAt !== "string") {
        return { status: "UNKNOWN", checkedAt, evidence: "Tool result does not contain timestamp evidence." };
      }
      const parsedTimestamp = Date.parse(timestamp);
      const parsedObservedAt = Date.parse(observedAt);
      if (
        !Number.isFinite(parsedTimestamp) ||
        !Number.isFinite(parsedObservedAt) ||
        new Date(parsedTimestamp).toISOString() !== timestamp ||
        timestamp !== observedAt
      ) {
        return { status: "FAILED", checkedAt, evidence: "Returned timestamp evidence failed validation." };
      }
      return { status: "VERIFIED", checkedAt, evidence: `Validated ISO timestamp observed at ${observedAt}.` };
    }
  },
  check_local_runtime: {
    name: "check_local_runtime",
    description: "Check the local Ollama runtime without sending prompts or contacting hosted providers.",
    permission: "read:local-runtime",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: undefined,
    inputSchema: { type: "object", properties: {}, required: [], additionalProperties: false },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["status", "endpoint", "elapsedMs", "models"],
          additionalProperties: false,
          properties: {
            status: { type: "string", enum: ["CONNECTED", "UNAVAILABLE"] },
            endpoint: { type: "string" },
            elapsedMs: { type: "number" },
            models: { type: "array", items: { type: "string" } },
          },
        },
      },
    },
    successCondition: "result.value.status is CONNECTED or UNAVAILABLE and reflects a real bounded local HTTP probe",
    async execute(input) {
      if (Object.keys(input).length !== 0) throw new AgentError("invalid_plan", "check_local_runtime accepts no input fields.", 400);
      const endpoint = "http://127.0.0.1:11434/api/tags";
      const observedAt = new Date().toISOString();
      const started = Date.now();
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 2500);
      try {
        const response = await fetch(endpoint, { signal: controller.signal, headers: { accept: "application/json" } });
        if (!response.ok) {
          return { observedAt, value: { status: "UNAVAILABLE", endpoint, elapsedMs: Date.now() - started, models: [] } };
        }
        const body: unknown = await response.json();
        const models = body && typeof body === "object" && Array.isArray((body as { models?: unknown }).models)
          ? (body as { models: unknown[] }).models.filter((item): item is { name: string } => Boolean(item && typeof item === "object" && typeof (item as { name?: unknown }).name === "string")).map((item) => item.name).slice(0, 100)
          : [];
        return { observedAt, value: { status: "CONNECTED", endpoint, elapsedMs: Date.now() - started, models } };
      } catch {
        return { observedAt, value: { status: "UNAVAILABLE", endpoint, elapsedMs: Date.now() - started, models: [] } };
      } finally {
        clearTimeout(timer);
      }
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") return { status: "UNKNOWN", checkedAt, evidence: "Local runtime probe returned no structured evidence." };
      const value = (result as ToolResult).value;
      if (!value || !["CONNECTED", "UNAVAILABLE"].includes(String(value.status)) || value.endpoint !== "http://127.0.0.1:11434/api/tags" || typeof value.elapsedMs !== "number" || !Array.isArray(value.models)) {
        return { status: "FAILED", checkedAt, evidence: "Local runtime probe evidence failed schema validation." };
      }
      return { status: "VERIFIED", checkedAt, evidence: `Local-only probe returned ${value.status} in ${value.elapsedMs}ms; no hosted provider was contacted.` };
    }
  }
};

export function registerTool(tool: ToolAdapter): void {
  tools[tool.name] = tool;
}

export function unregisterTool(name: string): boolean {
  if (name === "get_time" || name === "check_local_runtime") return false;
  return delete tools[name];
}

export function grantPermission(permission: string): void {
  grantedPermissions.add(permission);
}

export function revokePermission(permission: string): boolean {
  if (permission === "read:clock" || permission === "read:local-runtime") return false;
  return grantedPermissions.delete(permission);
}

export function getTool(name: string): ToolAdapter | undefined {
  return tools[name];
}

export function listTools() {
  return Object.values(tools).map(({ name, description, permission, risk, available, configured, reachable, availabilityReason, inputSchema, outputSchema, successCondition }) => ({
    name,
    description,
    permission,
    risk,
    availability: available ? "AVAILABLE" : "UNAVAILABLE",
    availabilityReason: available ? undefined : availabilityReason ?? "Tool adapter is not implemented.",
    execution: available ? "IMPLEMENTED" : "UNAVAILABLE",
    configured: configured ?? available,
    reachable: reachable ?? available,
    evidence: { outputSchema, successCondition },
    inputSchema,
    outputSchema,
    successCondition
  }));
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function validateToolInput(tool: ToolAdapter, input: unknown): input is Record<string, unknown> {
  return validateSchema(tool.inputSchema, input);
}

function validateSchema(schema: unknown, value: unknown): value is Record<string, unknown> {
  if (!isPlainObject(schema) || typeof schema.type !== "string") return false;
  if (Array.isArray(schema.enum) && !schema.enum.some((entry) => entry === value)) return false;
  if (schema.type === "object") {
    if (!isPlainObject(value)) return false;
    const properties = schema.properties;
    if (!isPlainObject(properties) || !Array.isArray(schema.required)) return false;
    if (!schema.required.every((key) => typeof key === "string" && Object.hasOwn(value, key))) return false;
    if (schema.additionalProperties === false && Object.keys(value).some((key) => !Object.hasOwn(properties, key))) {
      return false;
    }
    return Object.entries(value).every(([key, child]) =>
      Object.hasOwn(properties, key) && validateSchema(properties[key], child)
    );
  }
  if (schema.type === "array") {
    return Array.isArray(value) && schema.items !== undefined &&
      value.every((entry) => validateSchema(schema.items, entry));
  }
  if (schema.type === "string") return typeof value === "string";
  if (schema.type === "number") return typeof value === "number" && Number.isFinite(value);
  if (schema.type === "integer") return typeof value === "number" && Number.isSafeInteger(value);
  if (schema.type === "boolean") return typeof value === "boolean";
  return false;
}

/**
 * Compute SHA-256 integrity hash of a string payload.
 *
 * Characteristics:
 * - Accepts a payload string as input.
 * - Generates hash using the SHA-256 algorithm.
 * - Converts the result to a hexadecimal string.
 * - Returns a 64-character hash string for standard byte-encoded inputs.
 *
 * Limitations:
 * - Computes a hash only; does not automatically verify file validity without an authoritative reference hash.
 * - SHA-256 alone does not prove the content originated from a trusted sender (requires digital signatures / PKI).
 */
export function verifyIntegrity(payload: string): string {
  if (typeof payload !== "string") {
    throw new TypeError("Payload must be a string");
  }
  return createHash("sha256").update(payload, "utf8").digest("hex");
}

export type PlanGraphNode = { id: string; dependsOn: string[] };
export type PlanGraphAnalysis = { orderedIds: string[]; levels: string[][]; maxParallelism: number };

/** Validate a plan DAG and return dependency levels. This is analysis only; execution remains governed by executePlan. */
export function analyzePlanGraph(nodes: PlanGraphNode[]): PlanGraphAnalysis {
  if (!Array.isArray(nodes) || nodes.length === 0) throw new AgentError("invalid_plan", "Plan graph must contain steps.", 400);
  const ids = new Set<string>();
  for (const node of nodes) {
    if (!node || typeof node.id !== "string" || !node.id || ids.has(node.id) || !Array.isArray(node.dependsOn)) {
      throw new AgentError("invalid_plan", "Plan graph contains invalid or duplicate step identifiers.", 400);
    }
    ids.add(node.id);
  }
  for (const node of nodes) {
    if (new Set(node.dependsOn).size !== node.dependsOn.length || node.dependsOn.includes(node.id)) {
      throw new AgentError("invalid_plan", `Step ${node.id} has duplicate or self dependencies.`, 400);
    }
    if (node.dependsOn.some((dependency) => !ids.has(dependency))) {
      throw new AgentError("invalid_plan", `Step ${node.id} depends on an unknown step.`, 400);
    }
  }
  const completed = new Set<string>();
  const levels: string[][] = [];
  while (completed.size < nodes.length) {
    const ready = nodes.filter((node) => !completed.has(node.id) && node.dependsOn.every((dependency) => completed.has(dependency)));
    if (!ready.length) throw new AgentError("invalid_plan", "Plan dependencies contain a cycle.", 400);
    const level = ready.map((node) => node.id);
    levels.push(level);
    level.forEach((id) => completed.add(id));
  }
  return { orderedIds: levels.flat(), levels, maxParallelism: Math.max(0, ...levels.map((level) => level.length)) };
}

export function computePlanHash(plan: Pick<Plan, "id" | "goal" | "revision" | "steps" | "riskLevel" | "requiredTools" | "successCriteria" | "source">): string {
  const content = {
    id: plan.id,
    goal: plan.goal,
    revision: plan.revision,
    riskLevel: plan.riskLevel,
    requiredTools: plan.requiredTools,
    successCriteria: plan.successCriteria,
    source: plan.source,
    steps: plan.steps.map(({ id, tool, input, dependsOn, successCondition }) => ({
      id, tool, input, dependsOn, successCondition
    }))
  };
  return createHash("sha256").update(JSON.stringify(content)).digest("hex");
}

function parseDraft(draft: PlanDraft, id: string, revision: number, createdAt: string, source: PlanSource, correlationId?: string): Plan {
  if (!isPlainObject(draft)) throw new AgentError("invalid_plan", "Plan draft must be an object.", 400);
  if (Object.keys(draft).some((key) => !["goal", "steps", "riskLevel", "successCriteria", "correlationId"].includes(key))) {
    throw new AgentError("invalid_plan", "Plan draft contains fields outside the registered schema.", 400);
  }
  if (typeof draft.goal !== "string" || draft.goal.trim().length < 1 || draft.goal.trim().length > 1000) {
    throw new AgentError("invalid_plan", "Plan goal must be 1 to 1000 characters.", 400);
  }
  if (!Array.isArray(draft.steps) || draft.steps.length < 1 || draft.steps.length > 20) {
    throw new AgentError("invalid_plan", "Plan must contain 1 to 20 steps.", 400);
  }
  const requestedRisk = draft.riskLevel ?? "LOW";
  if (requestedRisk !== "LOW" && requestedRisk !== "MEDIUM" && requestedRisk !== "HIGH") {
    throw new AgentError("invalid_plan", "Plan riskLevel must be LOW, MEDIUM, or HIGH.", 400);
  }
  const successCriteria = draft.successCriteria ?? [];
  if (
    !Array.isArray(successCriteria) ||
    (draft.successCriteria !== undefined && successCriteria.length < 1) ||
    successCriteria.length > 20 ||
    successCriteria.some((criterion) => typeof criterion !== "string" || criterion.trim().length < 1 || criterion.trim().length > 500)
  ) {
    throw new AgentError("invalid_plan", "Plan must provide 1 to 20 valid success criteria.", 400);
  }
  const ids = new Set<string>();
  const steps: PlanStep[] = [];
  for (const value of draft.steps) {
    if (!isPlainObject(value)) throw new AgentError("invalid_plan", "Each step must be an object.", 400);
    if (Object.keys(value).some((key) => !["id", "tool", "input", "dependsOn", "successCondition"].includes(key))) {
      throw new AgentError("invalid_plan", "Step contains fields outside the registered plan schema.", 400);
    }
    const { id: stepId, tool, input, dependsOn, successCondition } = value;
    if (typeof stepId !== "string" || !/^[a-zA-Z0-9_-]{1,50}$/.test(stepId) || ids.has(stepId)) {
      throw new AgentError("invalid_plan", "Step IDs must be unique and contain only letters, numbers, _ or -.", 400);
    }
    if (typeof tool !== "string" || !tools[tool] || !tools[tool].available || !grantedPermissions.has(tools[tool].permission)) {
      throw new AgentError("tool_unavailable", "Requested tool is not registered or permitted.", 403);
    }
    if (!validateToolInput(tools[tool], input)) {
      throw new AgentError("invalid_plan", `Invalid input for tool ${tool}.`, 400);
    }
    if (!Array.isArray(dependsOn) || !dependsOn.every((dependency) => typeof dependency === "string")) {
      throw new AgentError("invalid_plan", "Each step must provide a dependency list.", 400);
    }
    if (new Set(dependsOn).size !== dependsOn.length || dependsOn.includes(stepId)) {
      throw new AgentError("invalid_plan", "Dependencies must be unique and cannot include the same step.", 400);
    }
    if (typeof successCondition !== "string" || successCondition !== tools[tool].successCondition) {
      throw new AgentError("invalid_plan", `Step ${stepId} must use the registered success condition for ${tool}.`, 400);
    }
    ids.add(stepId);
    steps.push({
      id: stepId,
      tool,
      input: isPlainObject(input) ? { ...input } : {},
      dependsOn: [...dependsOn],
      successCondition: successCondition.trim(),
      status: "PENDING"
    });
  }
  const graph = analyzePlanGraph(steps.map(({ id, dependsOn }) => ({ id, dependsOn })));
  const orderedSteps = graph.orderedIds.map((stepId) => steps.find((step) => step.id === stepId)!);
  const riskOrder: RiskLevel[] = ["LOW", "MEDIUM", "HIGH"];
  const riskLevel = orderedSteps.reduce<RiskLevel>((highest, step) => {
    const toolRisk = tools[step.tool].risk;
    return riskOrder.indexOf(toolRisk) > riskOrder.indexOf(highest) ? toolRisk : highest;
  }, requestedRisk);
  const resolvedCorrelationId = correlationId || (typeof (draft as any).correlationId === "string" ? (draft as any).correlationId : undefined);
  const plan: Plan = {
    id,
    correlationId: resolvedCorrelationId,
    goal: redactSecrets(draft.goal.trim()),
    riskLevel,
    requiredTools: [...new Set(orderedSteps.map(({ tool }) => tool))],
    successCriteria: successCriteria.length
      ? successCriteria.map((criterion) => redactSecrets((criterion as string).trim()))
      : orderedSteps.map(({ successCondition }) => redactSecrets(successCondition)),
    source,
    createdAt,
    updatedAt: createdAt,
    revision,
    status: "PROPOSED",
    hash: "",
    steps: orderedSteps
  };
  plan.hash = computePlanHash(plan);
  return plan;
}

async function latestState(): Promise<{ plans: Map<string, Plan>; events: AgentEvent[] }> {
  const events = await loadAgentEvents();
  const plans = new Map<string, Plan>();
  for (const event of events) {
    if ("plan" in event.data) {
      const rawPlan = event.data.plan;
      if (!isPlainObject(rawPlan)) throw new Error("Persisted plan record is malformed.");
      if (
        typeof rawPlan.id !== "string" ||
        typeof rawPlan.goal !== "string" ||
        !Number.isInteger(rawPlan.revision) ||
        typeof rawPlan.createdAt !== "string" ||
        typeof rawPlan.updatedAt !== "string" ||
        !Array.isArray(rawPlan.steps) ||
        typeof rawPlan.hash !== "string" ||
        typeof rawPlan.status !== "string" ||
        !["PROPOSED", "WAITING_APPROVAL", "APPROVED", "RUNNING", "SUCCEEDED", "FAILED", "BLOCKED", "UNKNOWN"].includes(rawPlan.status)
      ) {
        throw new Error("Persisted plan record is malformed.");
      }
      const plan = structuredClone(rawPlan) as unknown as Plan;
      let migrated = false;
      if (!plan.riskLevel || !plan.requiredTools || !plan.successCriteria || !plan.source) {
        plan.riskLevel = "LOW";
        plan.requiredTools = [...new Set(plan.steps.map((step) => step.tool))];
        plan.successCriteria = plan.steps.map((step) => step.successCondition);
        plan.source = "system";
        plan.approval = undefined;
        if (plan.status === "APPROVED" || plan.status === "WAITING_APPROVAL") plan.status = "PROPOSED";
        plan.hash = computePlanHash(plan);
        migrated = true;
      }
      if (
        (plan.riskLevel !== "LOW" && plan.riskLevel !== "MEDIUM" && plan.riskLevel !== "HIGH") ||
        !["ai", "system"].includes(plan.source) ||
        !Array.isArray(plan.requiredTools) ||
        !plan.requiredTools.every((tool) => typeof tool === "string") ||
        !Array.isArray(plan.successCriteria) ||
        !plan.successCriteria.every((criterion) => typeof criterion === "string") ||
        !plan.steps.every((step) =>
          isPlainObject(step) &&
          typeof step.id === "string" &&
          typeof step.tool === "string" &&
          isPlainObject(step.input) &&
          Array.isArray(step.dependsOn) &&
          step.dependsOn.every((dependency) => typeof dependency === "string") &&
          typeof step.successCondition === "string" &&
          ["PENDING", "RUNNING", "SUCCEEDED", "FAILED", "BLOCKED", "UNKNOWN"].includes(String(step.status))
        ) ||
        plan.hash !== computePlanHash(plan)
      ) {
        throw new Error("Persisted plan hash or steps are invalid.");
      }
      if (plan.approval && plan.approval.planHash !== plan.hash) {
        plan.approval = undefined;
        if (plan.status === "APPROVED") plan.status = "PROPOSED";
        migrated = true;
      }
      if (plan.status === "APPROVED" && !plan.approval) {
        plan.status = "PROPOSED";
        migrated = true;
      }
      if (migrated) plan.updatedAt = new Date().toISOString();
      if (migrated) await persistPlan("plan_schema_migrated", plan);
      plans.set(plan.id, plan);
    }
  }
  for (const [id, plan] of plans) {
    if (!activeExecutions.has(id) && (plan.status === "RUNNING" || plan.steps.some((step) => step.status === "RUNNING"))) {
      plan.status = "UNKNOWN";
      plan.updatedAt = new Date().toISOString();
      plan.steps = plan.steps.map((step) =>
        step.status === "RUNNING" ? { ...step, status: "UNKNOWN" } : step
      );
      await persistPlan("execution_recovered_as_unknown", plan);
      plans.set(id, plan);
    }
  }
  return { plans, events };
}

async function persistPlan(eventType: string, plan: Plan, extra: Record<string, unknown> = {}): Promise<AuditAcknowledgment> {
  const correlationId = (extra.correlationId as string) || plan.correlationId;
  const stepId = (extra.stepId as string) || undefined;
  const status =
    plan.status === "FAILED" ? "FAILED" :
    plan.status === "BLOCKED" ? "BLOCKED" :
    eventType.includes("finished") && plan.status === "SUCCEEDED" ? "SUCCESS" : "RECORDED";

  const ack = await saveAgentEvent({
    id: randomUUID(),
    type: eventType,
    at: new Date().toISOString(),
    correlationId,
    runId: plan.id,
    stepId,
    status,
    data: { plan: structuredClone(plan), correlationId, runId: plan.id, stepId, ...extra }
  });
  plan.auditAck = ack;
  return ack;
}

export async function audit(type: string, data: Record<string, unknown>, correlationId?: string): Promise<AuditAcknowledgment> {
  const corr = correlationId || (data.correlationId as string) || undefined;
  const runId = (data.runId as string) || (data.planId as string) || (data.taskId as string) || undefined;
  const stepId = (data.stepId as string) || undefined;
  const status = (data.status as any) || "RECORDED";
  return await saveAgentEvent({
    id: randomUUID(),
    type,
    at: new Date().toISOString(),
    correlationId: corr,
    runId,
    stepId,
    status,
    data: { ...data, correlationId: corr, runId, stepId }
  });
}

let operationQueue: Promise<void> = Promise.resolve();
const activeExecutions = new Set<string>();
async function exclusive<T>(operation: () => Promise<T>): Promise<T> {
  const previous = operationQueue;
  let release!: () => void;
  operationQueue = new Promise<void>((resolve) => { release = resolve; });
  await previous;
  try {
    return await operation();
  } finally {
    release();
  }
}

export function dependenciesSatisfied(steps: PlanStep[], step: PlanStep): boolean {
  return step.dependsOn.every((dependencyId) => {
    const dependency = steps.find((candidate) => candidate.id === dependencyId);
    return dependency?.status === "SUCCEEDED" && dependency.verification?.status === "VERIFIED";
  });
}

export async function createPlan(draft: PlanDraft, source: PlanSource = "system", correlationId?: string): Promise<Plan> {
  return exclusive(async () => {
    try {
      const { plans } = await latestState();
      const now = new Date().toISOString();
      const plan = parseDraft(draft, randomUUID(), 1, now, source, correlationId);
      if (plans.has(plan.id)) throw new AgentError("invalid_plan", "Generated plan ID already exists.", 409);
      await persistPlan("plan_proposed", plan);
      return plan;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError("storage_unavailable", "Could not persist the proposed plan.", 503);
    }
  });
}

export async function revisePlan(id: string, draft: PlanDraft): Promise<Plan> {
  return exclusive(async () => {
    try {
      const { plans } = await latestState();
      const previous = plans.get(id);
      if (!previous) throw new AgentError("plan_not_found", "Plan was not found.", 404);
      if (["RUNNING", "SUCCEEDED", "FAILED"].includes(previous.status)) {
        throw new AgentError("plan_not_approvable", "A running or finished plan cannot be revised.", 409);
      }
      const plan = parseDraft(draft, id, previous.revision + 1, previous.createdAt, previous.source);
      plan.updatedAt = new Date().toISOString();
      plan.status = "PROPOSED";
      await persistPlan("plan_revised", plan, { invalidatedApprovalId: previous.approval?.id ?? null });
      return plan;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError("storage_unavailable", "Could not persist the revised plan.", 503);
    }
  });
}

export async function requestPlanApproval(id: string): Promise<Plan> {
  return exclusive(async () => {
    try {
      const { plans } = await latestState();
      const plan = plans.get(id);
      if (!plan) throw new AgentError("plan_not_found", "Plan was not found.", 404);
      if (plan.status !== "PROPOSED") {
        throw new AgentError("plan_not_approvable", "Only a proposed plan can be submitted for approval.", 409);
      }
      plan.status = "WAITING_APPROVAL";
      plan.updatedAt = new Date().toISOString();
      await persistPlan("approval_requested", plan);
      return plan;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError("storage_unavailable", "Could not persist approval request.", 503);
    }
  });
}

export async function approvePlan(
  id: string,
  expectedHash: unknown,
  options?: { expiresAt?: string; ttlMs?: number; contextHash?: string }
): Promise<Plan> {
  return exclusive(async () => {
    try {
      const { plans } = await latestState();
      const plan = plans.get(id);
      if (!plan) throw new AgentError("plan_not_found", "Plan was not found.", 404);
      const currentHash = computePlanHash(plan);
      if (typeof expectedHash !== "string" || expectedHash !== currentHash || expectedHash !== plan.hash) {
        throw new AgentError("approval_mismatch", "Approval does not match the current plan hash.", 400);
      }
      if (plan.status !== "WAITING_APPROVAL") {
        throw new AgentError("plan_not_approvable", "Plan is not waiting for approval.", 409);
      }
      plan.status = "APPROVED";
      plan.updatedAt = new Date().toISOString();
      const expiresAt = options?.expiresAt || (options?.ttlMs ? new Date(Date.now() + options.ttlMs).toISOString() : undefined);
      plan.approval = {
        id: randomUUID(),
        planHash: currentHash,
        approvedAt: plan.updatedAt,
        expiresAt,
        contextHash: options?.contextHash,
      };
      await persistPlan("plan_approved", plan);
      return plan;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError("storage_unavailable", "Could not persist plan approval.", 503);
    }
  });
}

export interface PlanOverlapValidation {
  planId: string;
  hasOverlap: boolean;
  hasFileLock: boolean;
  warningCount: number;
  warnings: string[];
  overlappingPlans: Array<{
    id: string;
    goal: string;
    status: PlanStatus;
    overlappingTools: string[];
    overlappingFiles: string[];
  }>;
  lockedFiles: string[];
}

export async function validatePlanExecutionOverlaps(id: string): Promise<PlanOverlapValidation> {
  const { plans } = await latestState();
  const target = plans.get(id);
  if (!target) {
    throw new AgentError("plan_not_found", "Plan was not found.", 404);
  }

  const warnings: string[] = [];
  const lockedFiles: string[] = [];
  const overlappingPlans: PlanOverlapValidation["overlappingPlans"] = [];

  // Extract tools and files referenced in target plan
  const targetTools = new Set(target.steps.map((s) => s.tool));
  const targetFiles = new Set<string>();
  for (const s of target.steps) {
    if (s.input && typeof s.input === "object") {
      for (const k of ["path", "filename", "file", "targetFile", "name"]) {
        const val = (s.input as Record<string, unknown>)[k];
        if (typeof val === "string" && val.trim()) {
          targetFiles.add(val.trim().toLowerCase());
        }
      }
    }
  }

  // 1. Check against active/unfinished plans
  for (const [otherId, otherPlan] of plans) {
    if (otherId === id) continue;
    const isUnfinished =
      otherPlan.status === "RUNNING" ||
      otherPlan.status === "WAITING_APPROVAL" ||
      otherPlan.status === "APPROVED" ||
      otherPlan.steps.some((s) => s.status === "RUNNING");

    if (!isUnfinished) continue;

    const otherTools = new Set(otherPlan.steps.map((s) => s.tool));
    const otherFiles = new Set<string>();
    for (const s of otherPlan.steps) {
      if (s.input && typeof s.input === "object") {
        for (const k of ["path", "filename", "file", "targetFile", "name"]) {
          const val = (s.input as Record<string, unknown>)[k];
          if (typeof val === "string" && val.trim()) {
            otherFiles.add(val.trim().toLowerCase());
          }
        }
      }
    }

    const commonTools = Array.from(targetTools).filter((t) => otherTools.has(t));
    const commonFiles = Array.from(targetFiles).filter((f) => otherFiles.has(f));

    if (otherPlan.status === "RUNNING") {
      warnings.push(
        `แผนงาน #${otherId.slice(0, 8)} ("${otherPlan.goal}") กำลังดำเนินการอยู่ (RUNNING)` +
          (commonFiles.length > 0 ? ` และมีการใช้งานไฟล์ร่วมกัน: ${commonFiles.join(", ")}` : "") +
          (commonTools.length > 0 ? ` โดยใช้เครื่องมือ: ${commonTools.join(", ")}` : "")
      );
      overlappingPlans.push({
        id: otherId,
        goal: otherPlan.goal,
        status: otherPlan.status,
        overlappingTools: commonTools,
        overlappingFiles: commonFiles,
      });
    } else if (commonFiles.length > 0) {
      warnings.push(
        `ตรวจพบไฟล์ที่ซ้ำซ้อน [${commonFiles.join(", ")}] กับแผนงาน #${otherId.slice(0, 8)} ("${otherPlan.goal}") ซึ่งยังไม่เสร็จสิ้น (สถานะ: ${otherPlan.status})`
      );
      overlappingPlans.push({
        id: otherId,
        goal: otherPlan.goal,
        status: otherPlan.status,
        overlappingTools: commonTools,
        overlappingFiles: commonFiles,
      });
    } else if (otherPlan.status === "APPROVED" && commonTools.length > 0) {
      warnings.push(
        `แผนงาน #${otherId.slice(0, 8)} ได้รับการอนุมัติแล้วและกำลังรอรัน โดยใช้เครื่องมือ [${commonTools.join(", ")}] ซ้ำกับแผนนี้`
      );
      overlappingPlans.push({
        id: otherId,
        goal: otherPlan.goal,
        status: otherPlan.status,
        overlappingTools: commonTools,
        overlappingFiles: commonFiles,
      });
    }
  }

  // 2. Check pending file proposals / active locks in workspace
  try {
    const { listProposals } = await import("./files.js");
    const proposals = await listProposals();
    const pendingProposals = proposals.filter((p: any) =>
      p.status === "PROPOSED" || p.status === "WAITING_APPROVAL" || p.status === "APPROVED"
    );

    for (const prop of pendingProposals) {
      const propFileName = (prop.name || "").toLowerCase().trim();
      if (targetFiles.has(propFileName)) {
        lockedFiles.push(prop.name);
        warnings.push(
          `ไฟล์ "${prop.name}" กำลังมีคำขอแก้ไข (Proposal #${prop.id.slice(0, 8)}) ค้างอยู่ (${prop.status}) ซึ่งอาจเกิดความขัดแย้งในการบันทึก`
        );
      }
    }
  } catch {}

  const hasOverlap = overlappingPlans.length > 0;
  const hasFileLock = lockedFiles.length > 0;

  return {
    planId: id,
    hasOverlap,
    hasFileLock,
    warningCount: warnings.length,
    warnings,
    overlappingPlans,
    lockedFiles,
  };
}

export async function executePlan(id: string, approvalId: unknown, correlationId?: string): Promise<Plan> {
  return exclusive(async () => {
    let plan: Plan;
    try {
      const { plans } = await latestState();
      const current = plans.get(id);
      if (!current) throw new AgentError("plan_not_found", "Plan was not found.", 404);
      if (activeExecutions.has(id) || current.status === "RUNNING") {
        throw new AgentError("invalid_plan", `Plan "${id}" is already running concurrently.`, 409);
      }
      const approval = current.approval;
      if (typeof approvalId === "string" && approval?.id === approvalId && approval.usedAt) {
        throw new AgentError("approval_replayed", "Approval has already been used.", 409);
      }
      if (approval?.usedAt) {
        throw new AgentError("approval_replayed", "Approval has already been used.", 409);
      }
      if (!approval || typeof approvalId !== "string" || approvalId !== approval.id || approval.planHash !== current.hash) {
        throw new AgentError("approval_mismatch", "Approval does not match this plan revision.", 403);
      }
      if (current.status !== "APPROVED") {
        throw new AgentError("approval_required", "Plan must be explicitly approved before execution.", 403);
      }
      if (approval.expiresAt && Date.now() > Date.parse(approval.expiresAt)) {
        throw new AgentError("approval_expired", `Approval expired at ${approval.expiresAt}.`, 403);
      }
      if (current.hash !== computePlanHash(current)) {
        throw new AgentError("approval_mismatch", "Plan changed after approval; approval is invalid.", 409);
      }

      plan = structuredClone(current);
      if (correlationId && !plan.correlationId) {
        plan.correlationId = correlationId;
      }
      plan.status = "RUNNING";
      plan.updatedAt = new Date().toISOString();
      if (plan.approval) plan.approval.usedAt = plan.updatedAt;
      activeExecutions.add(id);
      await persistPlan("plan_execution_started", plan);
    } catch (error) {
      activeExecutions.delete(id);
      if (error instanceof AgentError) throw error;
      throw new AgentError("storage_unavailable", "Could not start plan execution.", 503);
    }

    try {
      for (const step of plan.steps) {
        if (!dependenciesSatisfied(plan.steps, step)) {
          step.status = "BLOCKED";
          await persistPlan("step_blocked", plan, { stepId: step.id, reason: "dependency_not_satisfied" });
          continue;
        }
        const tool = tools[step.tool];
        if (!tool || !tool.available || !grantedPermissions.has(tool.permission)) {
          step.status = "BLOCKED";
          await persistPlan("step_blocked", plan, { stepId: step.id, reason: "tool_unavailable" });
          continue;
        }
        if (tool.configured === false) {
          step.status = "BLOCKED";
          await persistPlan("step_blocked", plan, { stepId: step.id, reason: "tool_not_configured" });
          continue;
        }
        if (tool.reachable === false) {
          step.status = "BLOCKED";
          await persistPlan("step_blocked", plan, { stepId: step.id, reason: "tool_unreachable" });
          continue;
        }
        if (!validateToolInput(tool, step.input)) {
          step.status = "BLOCKED";
          await persistPlan("step_blocked", plan, { stepId: step.id, reason: "invalid_tool_input" });
          continue;
        }
        step.status = "RUNNING";
        step.startedAt = new Date().toISOString();
        step.correlationId = plan.correlationId;
        await persistPlan("step_execution_started", plan, { stepId: step.id, input: step.input, correlationId: plan.correlationId });
        let result: ToolResult;
        try {
          result = await tool.execute(step.input);
        } catch (error) {
          step.status = "UNKNOWN";
          step.finishedAt = new Date().toISOString();
          step.durationMs = Math.max(0, new Date(step.finishedAt).getTime() - new Date(step.startedAt).getTime());
          step.error = redactSecrets(error instanceof Error
            ? `Tool call outcome is unknown: ${error.message}`
            : "Tool call outcome is unknown.");
          step.verification = {
            status: "UNKNOWN",
            checkedAt: step.finishedAt,
            evidence: "Tool call did not return a verifiable result."
          };
          await persistPlan("step_execution_finished", plan, {
            stepId: step.id,
            input: step.input,
            error: step.error,
            durationMs: step.durationMs,
            correlationId: plan.correlationId,
            status: step.status,
            verification: step.verification
          });
          continue;
        }
        step.result = result;
        try {
          step.verification = tool.verify(result);
          step.status = step.verification.status === "VERIFIED"
            ? "SUCCEEDED"
            : step.verification.status === "FAILED" ? "FAILED" : "UNKNOWN";
        } catch (error) {
          step.status = "UNKNOWN";
          step.error = redactSecrets(error instanceof Error ? error.message : "Evidence verification failed.");
          step.verification = {
            status: "UNKNOWN",
            checkedAt: new Date().toISOString(),
            evidence: "Evidence verifier failed; result cannot be confirmed."
          };
        }
        step.finishedAt = new Date().toISOString();
        step.durationMs = Math.max(0, new Date(step.finishedAt).getTime() - new Date(step.startedAt).getTime());
        await persistPlan("step_execution_finished", plan, {
          stepId: step.id,
          input: step.input,
          output: result,
          status: step.status,
          durationMs: step.durationMs,
          correlationId: plan.correlationId,
          verification: step.verification,
          error: step.error
        });
      }

      plan.status = plan.steps.every((step) => step.status === "SUCCEEDED" && step.verification?.status === "VERIFIED")
        ? "SUCCEEDED"
        : plan.steps.some((step) => step.status === "FAILED") ? "FAILED"
        : plan.steps.some((step) => step.status === "UNKNOWN") ? "UNKNOWN"
        : plan.steps.some((step) => step.status === "BLOCKED") ? "BLOCKED"
        : "UNKNOWN";
      plan.updatedAt = new Date().toISOString();

      const executedSteps = plan.steps.filter((s) => s.status === "SUCCEEDED" || s.status === "FAILED" || s.status === "UNKNOWN");
      const unexecutedSteps = plan.steps.filter((s) => s.status === "PENDING" || s.status === "BLOCKED");
      const isPartial = executedSteps.length > 0 && unexecutedSteps.length > 0;

      const honestReport: HonestReport = {
        goal: plan.goal,
        finalStatus: plan.status,
        actionsPerformed: executedSteps.map((s) => ({
          stepId: s.id,
          tool: s.tool,
          status: s.status,
          verified: s.verification?.status === "VERIFIED",
          evidence: s.verification?.evidence,
          durationMs: s.durationMs,
        })),
        verifiedEvidence: plan.steps
          .filter((s) => s.verification?.status === "VERIFIED")
          .map((s) => s.verification!.evidence),
        actionsNotPerformed: unexecutedSteps.map((s) => ({
          stepId: s.id,
          tool: s.tool,
          reason: s.status === "BLOCKED" ? "Step blocked, dependency not satisfied, or tool unavailable" : "Step not executed",
        })),
        blockersOrMissingPermissions: plan.steps
          .filter((s) => s.status === "BLOCKED")
          .map((s) => `Step "${s.id}" (${s.tool}) blocked`),
        isPartial,
        summary: `Plan execution ${plan.status}. Completed ${executedSteps.length}/${plan.steps.length} steps.${isPartial ? " (Partial execution)" : ""}`
      };
      plan.honestReport = honestReport;

      try {
        await persistPlan("plan_execution_finished", plan);
      } catch {
        plan.status = "UNKNOWN";
        throw new AgentError("storage_unavailable", "Execution finished but its final evidence could not be persisted; status is unknown.", 503);
      }
      return plan;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError(
        "storage_unavailable",
        "Execution was interrupted before final evidence was persisted; status must be recovered as UNKNOWN.",
        503
      );
    } finally {
      activeExecutions.delete(id);
    }
  });
}

export async function getPlan(id: string): Promise<Plan> {
  try {
    const { plans } = await latestState();
    const plan = plans.get(id);
    if (!plan) throw new AgentError("plan_not_found", "Plan was not found.", 404);
    return plan;
  } catch (error) {
    if (error instanceof AgentError) throw error;
    throw new AgentError("storage_unavailable", "Could not load plans.", 503);
  }
}

export async function listPlans(): Promise<Plan[]> {
  try {
    return [...(await latestState()).plans.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch {
    throw new AgentError("storage_unavailable", "Could not load plans.", 503);
  }
}

export async function listAuditEvents(): Promise<AgentEvent[]> {
  try {
    return await loadAgentEvents();
  } catch {
    throw new AgentError("storage_unavailable", "Could not load audit events.", 503);
  }
}

export function verifyToolResult(toolName: string, result: unknown): Verification {
  const tool = tools[toolName];
  if (!tool) return { status: "UNKNOWN", checkedAt: new Date().toISOString(), evidence: "No verifier is registered for this tool." };
  return tool.verify(result);
}

export function createTimePlanDraft(goal: string): PlanDraft {
  return {
    goal,
    riskLevel: "LOW",
    successCriteria: ["Read and verify the current server time."],
    steps: [{
      id: "read-current-time",
      tool: "get_time",
      input: {},
      dependsOn: [],
      successCondition: tools.get_time.successCondition
    }]
  };
}

export function validatePlannerOutput(value: unknown): PlanDraft {
  if (!isPlainObject(value) || Object.keys(value).sort().join(",") !== "goal,riskLevel,steps,successCriteria") {
    throw new AgentError("invalid_plan", "Planner output must contain exactly goal, riskLevel, successCriteria, and steps.", 422);
  }
  if (
    typeof value.goal !== "string" ||
    value.goal.trim().length < 1 ||
    value.goal.trim().length > 1000 ||
    (value.riskLevel !== "LOW" && value.riskLevel !== "MEDIUM" && value.riskLevel !== "HIGH") ||
    !Array.isArray(value.successCriteria) ||
    value.successCriteria.length < 1 ||
    value.successCriteria.length > 20 ||
    value.successCriteria.some((criterion) =>
      typeof criterion !== "string" || criterion.trim().length < 1 || criterion.trim().length > 500
    ) ||
    !Array.isArray(value.steps) ||
    value.steps.length > 20
  ) {
    throw new AgentError("invalid_plan", "Planner output does not satisfy the plan schema.", 422);
  }
  for (const step of value.steps) {
    if (!isPlainObject(step) || Object.keys(step).sort().join(",") !== "dependsOn,id,input,successCondition,tool") {
      throw new AgentError("invalid_plan", "Planner steps must contain exactly id, tool, input, dependsOn, and successCondition.", 422);
    }
  }
  return value as PlanDraft;
}

export async function recordPlanRejection(id: string): Promise<Plan> {
  return exclusive(async () => {
    try {
      const plan = await getPlan(id);
      if (plan.status !== "WAITING_APPROVAL") {
        throw new AgentError("plan_not_approvable", "Only a plan waiting for approval can be rejected.", 409);
      }

      plan.status = "BLOCKED";
      plan.updatedAt = new Date().toISOString();
      const ack = await persistPlan("plan_rejected", plan);
      await audit("approval_rejected", { planId: id, planHash: plan.hash });
      plan.auditAck = ack;
      return plan;
    } catch (error) {
      if (error instanceof AgentError) throw error;
      throw new AgentError("storage_unavailable", "Could not persist plan rejection.", 503);
    }
  });
}

export type LedgerMismatchType =
  | "TAMPERED_PLAN_HASH"
  | "APPROVAL_HASH_MISMATCH"
  | "UNAUTHORIZED_APPROVAL"
  | "REPLAYED_APPROVAL"
  | "EXPIRED_APPROVAL_USED"
  | "INVALID_EVIDENCE_STATUS"
  | "MISSING_EVIDENCE"
  | "MISSING_AUDIT_RECORDS"
  | "UNVERIFIED_STEP_SUCCESS"
  | "OUT_OF_SEQUENCE_EVENT"
  | "SECRET_EXPOSURE_IN_LEDGER"
  | "MALFORMED_LEDGER_RECORD";

export type LedgerIntegrityIssue = {
  issueId: string;
  type: LedgerMismatchType;
  severity: "CRITICAL" | "HIGH" | "MEDIUM";
  planId?: string;
  stepId?: string;
  eventId?: string;
  expected?: string;
  actual?: string;
  message: string;
  recordedAt?: string;
};

export type PlanIntegrityReport = {
  planId: string;
  goal: string;
  status: PlanStatus;
  recordedHash: string;
  recalculatedHash: string;
  hashValid: boolean;
  approvalValid: boolean;
  evidenceConsistent: boolean;
  totalEvents: number;
  matchedEvidenceCount: number;
  issues: LedgerIntegrityIssue[];
};

export type LedgerIntegrityVerificationReport = {
  valid: boolean;
  intact?: boolean;
  tamperedCount?: number;
  status: "VERIFIED" | "FAIL" | "TAMPERED" | "UNKNOWN";
  totalEventsChecked: number;
  totalPlansChecked: number;
  totalEvidenceRecordsChecked: number;
  plans: PlanIntegrityReport[];
  mismatches: LedgerIntegrityIssue[];
  summary: string;
  verifiedAt: string;
};

export function safeComputePlanHash(raw: any): string {
  if (!raw || typeof raw !== "object") return "INVALID_PLAN_PAYLOAD";
  try {
    const steps = Array.isArray(raw.steps) ? raw.steps : [];
    const content = {
      id: raw.id ?? "",
      goal: raw.goal ?? "",
      revision: typeof raw.revision === "number" ? raw.revision : 1,
      riskLevel: raw.riskLevel ?? "LOW",
      requiredTools: Array.isArray(raw.requiredTools) ? raw.requiredTools : [],
      successCriteria: Array.isArray(raw.successCriteria) ? raw.successCriteria : [],
      source: raw.source ?? "system",
      steps: steps.map((s: any) => ({
        id: s?.id ?? "",
        tool: s?.tool ?? "",
        input: s?.input && typeof s.input === "object" ? s.input : {},
        dependsOn: Array.isArray(s?.dependsOn) ? s.dependsOn : [],
        successCondition: s?.successCondition ?? "",
      })),
    };
    return createHash("sha256").update(JSON.stringify(content)).digest("hex");
  } catch {
    return "HASH_COMPUTATION_FAILED";
  }
}

/**
 * Verifies the integrity of the Cryptographic Audit Ledger by re-calculating plan hashes,
 * verifying approval cryptographic signatures, confirming correspondence with recorded evidence,
 * checking chronological sequencing, and flagging any mismatches.
 */
export async function verifyAuditLedgerIntegrity(targetPlanId?: string): Promise<LedgerIntegrityVerificationReport> {
  let events: AgentEvent[] = [];
  try {
    events = await loadAgentEvents();
  } catch (err: any) {
    return {
      valid: false,
      status: "FAIL",
      totalEventsChecked: 0,
      totalPlansChecked: 0,
      totalEvidenceRecordsChecked: 0,
      plans: [],
      mismatches: [
        {
          issueId: `issue_store_read_err`,
          type: "MALFORMED_LEDGER_RECORD",
          severity: "CRITICAL",
          message: `Could not read ledger events from storage: ${err.message}`,
        },
      ],
      summary: `❌ Failed to read ledger: ${err.message}`,
      verifiedAt: new Date().toISOString(),
    };
  }

  let evidenceRecords = await loadEvidenceRecords().catch(() => []);
  const mismatches: LedgerIntegrityIssue[] = [];

  // 1. Secret Scanning across the relevant audit ledger events
  for (const event of events) {
    if (targetPlanId) {
      const data = (event.data || {}) as Record<string, unknown>;
      const rawPlan = data.plan as Plan | undefined;
      const pid = rawPlan?.id || (data.planId as string | undefined) || (data.id as string | undefined);
      if (pid !== targetPlanId) continue;
    }
    const rawJson = JSON.stringify(event);
    if (containsSensitiveData(rawJson)) {
      mismatches.push({
        issueId: `issue_secret_${event.id || Math.random().toString(36).slice(2, 8)}`,
        type: "SECRET_EXPOSURE_IN_LEDGER",
        severity: "CRITICAL",
        eventId: event.id,
        message: `Unredacted secret pattern detected in audit ledger event ${event.id} (type: ${event.type})`,
        recordedAt: event.at,
      });
    }
  }

  // 2. Group events by plan
  const planEventsMap = new Map<string, AgentEvent[]>();
  const planLatestStateMap = new Map<string, Plan>();

  for (const event of events) {
    const data = (event.data || {}) as Record<string, unknown>;
    const rawPlan = data.plan as Plan | undefined;
    const planId = rawPlan?.id || (data.planId as string | undefined) || (data.id as string | undefined);
    if (planId) {
      if (!planEventsMap.has(planId)) {
        planEventsMap.set(planId, []);
      }
      planEventsMap.get(planId)!.push(event);
    }
    if (rawPlan && rawPlan.id) {
      planLatestStateMap.set(rawPlan.id, rawPlan);
    }
  }

  const planIdsToInspect = targetPlanId
    ? [targetPlanId]
    : Array.from(new Set([...planEventsMap.keys(), ...planLatestStateMap.keys()]));

  const plansReports: PlanIntegrityReport[] = [];
  const usedApprovalIds = new Map<string, { planId: string; revision: number }>();

  for (const planId of planIdsToInspect) {
    const planEvents = planEventsMap.get(planId) || [];
    const latestPlan = planLatestStateMap.get(planId);
    const planIssues: LedgerIntegrityIssue[] = [];

    if (!latestPlan) {
      const issue: LedgerIntegrityIssue = {
        issueId: `issue_missing_plan_${planId}`,
        type: planEvents.length > 0 ? "MISSING_EVIDENCE" : "MISSING_AUDIT_RECORDS",
        severity: "CRITICAL",
        planId,
        message: planEvents.length > 0
          ? `Audit events reference planId "${planId}" but no complete plan state is recorded in the ledger.`
          : `Plan "${planId}" has no state or audit events recorded in the ledger. Integrity cannot be established.`,
      };
      planIssues.push(issue);
      mismatches.push(issue);
      continue;
    }

    if (planEvents.length === 0) {
      const issue: LedgerIntegrityIssue = {
        issueId: `issue_missing_events_${planId}`,
        type: "MISSING_AUDIT_RECORDS",
        severity: "CRITICAL",
        planId,
        message: `Plan "${planId}" has no audit events recorded in the ledger. Integrity cannot be established.`,
      };
      planIssues.push(issue);
      mismatches.push(issue);
    }

    // Check plan hash for EVERY recorded version of this plan across events
    let allHashesValidForPlan = true;
    for (const evt of planEvents) {
      const data = (evt.data || {}) as Record<string, unknown>;
      const p = data.plan as any;
      if (p && p.id === planId && typeof p.hash === "string") {
        const calculated = safeComputePlanHash(p);
        if (calculated !== p.hash) {
          allHashesValidForPlan = false;
          const issue: LedgerIntegrityIssue = {
            issueId: `issue_tampered_hash_${evt.id || planId}`,
            type: "TAMPERED_PLAN_HASH",
            severity: "CRITICAL",
            planId,
            eventId: evt.id,
            expected: calculated,
            actual: p.hash,
            message: `Plan hash mismatch in event "${evt.type}": recorded hash "${p.hash}" does not match recalculated hash "${calculated}". The plan payload has been tampered with!`,
            recordedAt: evt.at,
          };
          planIssues.push(issue);
          mismatches.push(issue);
        }
      }
    }

    // Latest plan hash recalculation
    const latestRecalculatedHash = safeComputePlanHash(latestPlan);
    const latestHashValid = latestPlan.hash === latestRecalculatedHash;
    if (!latestHashValid && allHashesValidForPlan) {
      const issue: LedgerIntegrityIssue = {
        issueId: `issue_tampered_hash_latest_${planId}`,
        type: "TAMPERED_PLAN_HASH",
        severity: "CRITICAL",
        planId,
        expected: latestRecalculatedHash,
        actual: latestPlan.hash,
        message: `Current plan hash "${latestPlan.hash}" does not match recalculated hash "${latestRecalculatedHash}".`,
      };
      planIssues.push(issue);
      mismatches.push(issue);
    }

    // Check approval integrity
    let approvalValid = true;
    if (latestPlan.approval) {
      if (latestPlan.approval.planHash !== latestPlan.hash || latestPlan.approval.planHash !== latestRecalculatedHash) {
        approvalValid = false;
        const issue: LedgerIntegrityIssue = {
          issueId: `issue_approval_hash_${planId}`,
          type: "APPROVAL_HASH_MISMATCH",
          severity: "CRITICAL",
          planId,
          expected: latestRecalculatedHash,
          actual: latestPlan.approval.planHash,
          message: `Approval planHash "${latestPlan.approval.planHash}" does not match current plan hash "${latestRecalculatedHash}".`,
        };
        planIssues.push(issue);
        mismatches.push(issue);
      }

      // Replay check across different plans or revisions
      const prevUsage = usedApprovalIds.get(latestPlan.approval.id);
      if (prevUsage && (prevUsage.planId !== planId || prevUsage.revision !== latestPlan.revision)) {
        approvalValid = false;
        const issue: LedgerIntegrityIssue = {
          issueId: `issue_replay_${latestPlan.approval.id}`,
          type: "REPLAYED_APPROVAL",
          severity: "CRITICAL",
          planId,
          message: `Approval ticket ID "${latestPlan.approval.id}" was replayed across different plans/revisions (previously used in plan ${prevUsage.planId} rev ${prevUsage.revision}).`,
        };
        planIssues.push(issue);
        mismatches.push(issue);
      } else {
        usedApprovalIds.set(latestPlan.approval.id, { planId, revision: latestPlan.revision });
      }

      // Check whether approval was used after expiration
      if (latestPlan.approval.expiresAt && latestPlan.approval.usedAt) {
        if (Date.parse(latestPlan.approval.usedAt) > Date.parse(latestPlan.approval.expiresAt)) {
          approvalValid = false;
          const issue: LedgerIntegrityIssue = {
            issueId: `issue_expired_approval_${planId}`,
            type: "EXPIRED_APPROVAL_USED",
            severity: "CRITICAL",
            planId,
            message: `Plan "${planId}" executed using an approval that expired at ${latestPlan.approval.expiresAt} (used at ${latestPlan.approval.usedAt}).`,
          };
          planIssues.push(issue);
          mismatches.push(issue);
        }
      }

      // Check whether a plan_approved event exists
      const hasApprovedEvent = planEvents.some((e) => e.type === "plan_approved");
      if (!hasApprovedEvent && latestPlan.status !== "PROPOSED") {
        approvalValid = false;
        const issue: LedgerIntegrityIssue = {
          issueId: `issue_unauth_approval_${planId}`,
          type: "UNAUTHORIZED_APPROVAL",
          severity: "HIGH",
          planId,
          message: `Plan "${planId}" claims approval ticket "${latestPlan.approval.id}" but no "plan_approved" event was found in the audit trail.`,
        };
        planIssues.push(issue);
        mismatches.push(issue);
      }
    } else if (
      ["APPROVED", "RUNNING", "SUCCEEDED"].includes(latestPlan.status) &&
      (latestPlan.riskLevel === "MEDIUM" || latestPlan.riskLevel === "HIGH")
    ) {
      approvalValid = false;
      const issue: LedgerIntegrityIssue = {
        issueId: `issue_missing_approval_${planId}`,
        type: "UNAUTHORIZED_APPROVAL",
        severity: "CRITICAL",
        planId,
        message: `High/Medium risk plan "${planId}" is in status "${latestPlan.status}" without required cryptographic approval.`,
      };
      planIssues.push(issue);
      mismatches.push(issue);
    }

    // Step verification & evidence checks
    let evidenceConsistent = true;
    const planEvidenceRecords = evidenceRecords.filter(
      (ev) => ev.taskId === planId || ev.id.includes(planId) || (latestPlan.steps || []).some((s) => s.id === ev.taskId)
    );

    for (const step of latestPlan.steps || []) {
      if (step.status === "SUCCEEDED" && step.verification?.status !== "VERIFIED") {
        evidenceConsistent = false;
        const issue: LedgerIntegrityIssue = {
          issueId: `issue_unverified_step_${step.id}`,
          type: "UNVERIFIED_STEP_SUCCESS",
          severity: "CRITICAL",
          planId,
          stepId: step.id,
          message: `Step "${step.id}" is marked SUCCEEDED but its verification status is "${step.verification?.status || "NONE"}". Only empirically VERIFIED steps may succeed.`,
        };
        planIssues.push(issue);
        mismatches.push(issue);
      }
    }

    // Evidence records validation: if verificationStatus is VERIFIED, exitCode MUST be 0
    for (const rec of planEvidenceRecords) {
      if (rec.verificationStatus === "VERIFIED" && rec.exitCode !== 0) {
        evidenceConsistent = false;
        const issue: LedgerIntegrityIssue = {
          issueId: `issue_bad_evidence_status_${rec.id}`,
          type: "INVALID_EVIDENCE_STATUS",
          severity: "CRITICAL",
          planId,
          expected: "exitCode 0 for VERIFIED status",
          actual: `exitCode ${rec.exitCode}`,
          message: `Evidence record "${rec.id}" claims status VERIFIED despite non-zero exit code ${rec.exitCode}.`,
          recordedAt: rec.timestamps?.finishedAt,
        };
        planIssues.push(issue);
        mismatches.push(issue);
      }
    }

    // If plan status is SUCCEEDED, all steps must be SUCCEEDED and VERIFIED
    if (latestPlan.status === "SUCCEEDED") {
      const allSucceeded = (latestPlan.steps || []).every(
        (s) => s.status === "SUCCEEDED" && s.verification?.status === "VERIFIED"
      );
      if (!allSucceeded) {
        evidenceConsistent = false;
        const issue: LedgerIntegrityIssue = {
          issueId: `issue_succeeded_without_evidence_${planId}`,
          type: "MISSING_EVIDENCE",
          severity: "CRITICAL",
          planId,
          message: `Plan "${planId}" is marked SUCCEEDED, but not all steps have status SUCCEEDED and verification status VERIFIED.`,
        };
        planIssues.push(issue);
        mismatches.push(issue);
      }
    }

    // Event sequence ordering check
    for (let i = 1; i < planEvents.length; i++) {
      const prev = planEvents[i - 1];
      const curr = planEvents[i];
      if (prev.at && curr.at && new Date(curr.at).getTime() < new Date(prev.at).getTime()) {
        const issue: LedgerIntegrityIssue = {
          issueId: `issue_out_of_seq_${curr.id || i}`,
          type: "OUT_OF_SEQUENCE_EVENT",
          severity: "HIGH",
          planId,
          eventId: curr.id,
          message: `Ledger event sequence anomaly: event "${curr.type}" (${curr.at}) occurred earlier than preceding event "${prev.type}" (${prev.at}).`,
          recordedAt: curr.at,
        };
        planIssues.push(issue);
        mismatches.push(issue);
      }
    }

    plansReports.push({
      planId,
      goal: latestPlan.goal || "",
      status: latestPlan.status,
      recordedHash: latestPlan.hash || "",
      recalculatedHash: latestRecalculatedHash,
      hashValid: latestHashValid && allHashesValidForPlan,
      approvalValid,
      evidenceConsistent,
      totalEvents: planEvents.length,
      matchedEvidenceCount: planEvidenceRecords.length,
      issues: planIssues,
    });
  }

  const hasCriticalOrHighIssues = mismatches.some((m) => m.severity === "CRITICAL" || m.severity === "HIGH");
  const hasTampering = mismatches.some(
    (m) =>
      m.type === "TAMPERED_PLAN_HASH" ||
      m.type === "APPROVAL_HASH_MISMATCH" ||
      m.type === "INVALID_EVIDENCE_STATUS" ||
      m.type === "REPLAYED_APPROVAL" ||
      m.type === "EXPIRED_APPROVAL_USED"
  );
  const hasMissingRecords = mismatches.some((m) => m.type === "MISSING_AUDIT_RECORDS");

  const status: "VERIFIED" | "FAIL" | "TAMPERED" | "UNKNOWN" = hasMissingRecords
    ? "UNKNOWN"
    : hasTampering
    ? "TAMPERED"
    : hasCriticalOrHighIssues
    ? "FAIL"
    : "VERIFIED";
  const valid = status === "VERIFIED";

  const summary = valid
    ? `✅ Cryptographic Audit Ledger verified intact: ${plansReports.length} plans re-hashed, ${events.length} audit events, and ${evidenceRecords.length} evidence proofs verified without mismatch.`
    : `❌ Cryptographic Audit Ledger integrity check failed (${status}): Detected ${mismatches.length} mismatch(es) across ${plansReports.length} plans.`;

  const tamperedCount = mismatches.filter(
    (m) =>
      m.type === "TAMPERED_PLAN_HASH" ||
      m.type === "APPROVAL_HASH_MISMATCH" ||
      m.type === "INVALID_EVIDENCE_STATUS" ||
      m.type === "REPLAYED_APPROVAL"
  ).length;

  return {
    valid,
    intact: valid,
    tamperedCount,
    status,
    totalEventsChecked: events.length,
    totalPlansChecked: plansReports.length,
    totalEvidenceRecordsChecked: evidenceRecords.length,
    plans: plansReports,
    mismatches,
    summary,
    verifiedAt: new Date().toISOString(),
  };
}

export type PlanLedgerVerificationResult = {
  planId: string;
  valid: boolean;
  verified?: boolean;
  status: PlanStatus;
  hash: string;
  computedHash: string;
  hashMatches: boolean;
  planHashMatches?: boolean;
  ledgerEventsCount: number;
  approvalVerified: boolean;
  approvalId?: string;
  stepsVerification: {
    id: string;
    tool: string;
    status: StepStatus;
    verified: boolean;
    verificationStatus?: string;
  }[];
  evidenceRecordsCount: number;
  isLedgerConsistent: boolean;
  summary: string;
  checkedAt: string;
  issues?: LedgerIntegrityIssue[];
};

export async function verifyPlanAgainstLedger(id: string): Promise<PlanLedgerVerificationResult> {
  const integrityReport = await verifyAuditLedgerIntegrity(id);
  const planReport = integrityReport.plans.find((p) => p.planId === id);

  let plan: Plan | undefined;
  try {
    plan = await getPlan(id);
  } catch {
    // If getPlan fails because of hash tampering in storage, use data from planReport
  }

  const computedHash = planReport ? planReport.recalculatedHash : plan ? computePlanHash(plan) : "";
  const recordedHash = planReport ? planReport.recordedHash : plan?.hash || "";
  const hashMatches = !!planReport ? planReport.hashValid : recordedHash === computedHash;

  const stepsVerification = (plan?.steps || []).map((step) => ({
    id: step.id,
    tool: step.tool,
    status: step.status,
    verified: step.verification?.status === "VERIFIED",
    verificationStatus: step.verification?.status,
  }));

  const planIssues = planReport?.issues || [];
  const hasCriticalOrHigh = planIssues.some((i) => i.severity === "CRITICAL" || i.severity === "HIGH");
  const valid = !hasCriticalOrHigh && hashMatches;

  const summary = valid
    ? `แผนงานผ่านการตรวจสอบความถูกต้องเทียบกับ Ledger เรียบร้อย (Hash: ${recordedHash.slice(0, 8)}..., Events: ${planReport?.totalEvents ?? 0}, Evidence: ${planReport?.matchedEvidenceCount ?? 0})`
    : `พบข้อขัดแย้งในการตรวจสอบเทียบกับ Ledger: ${planIssues.map((i) => i.message).join("; ") || "Hash หรือหลักฐานไม่ตรงกัน"}`;

  return {
    planId: id,
    valid,
    verified: valid,
    status: planReport?.status || plan?.status || "UNKNOWN",
    hash: recordedHash,
    computedHash,
    hashMatches,
    planHashMatches: hashMatches,
    ledgerEventsCount: planReport?.totalEvents ?? 0,
    approvalVerified: planReport?.approvalValid ?? false,
    approvalId: plan?.approval?.id,
    stepsVerification,
    evidenceRecordsCount: planReport?.matchedEvidenceCount ?? 0,
    isLedgerConsistent: (planReport?.issues.length ?? 0) === 0,
    summary,
    checkedAt: new Date().toISOString(),
    issues: planReport?.issues,
  };
}


// ---------------------------------------------------------------------------
// Bridge: ConnectorHub → Agent ToolAdapter (web_research.fetch_page)
// ---------------------------------------------------------------------------

/**
 * Register a read-only `web_fetch` tool that calls the web_research connector.
 * Safe to call multiple times (idempotent overwrite via registerTool).
 * Requires declareDefaultConnectors() (or equivalent) to have run first so
 * the connector is installed and `read` is granted.
 */
export function registerWebFetchTool(): void {
  registerTool({
    name: "web_fetch",
    description:
      "Fetch a public web page (http/https) and return title + text excerpt. Read-only; private/loopback hosts are blocked.",
    permission: "read:web",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        url: { type: "string", format: "uri" },
      },
      required: ["url"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["url", "status", "text"],
          additionalProperties: true,
          properties: {
            url: { type: "string" },
            finalUrl: { type: "string" },
            status: { type: "number" },
            title: { type: "string" },
            text: { type: "string" },
            bytes: { type: "number" },
            truncated: { type: "boolean" },
          },
        },
      },
    },
    successCondition: "result.value.status is 2xx and result.value.text is a non-empty string",
    async execute(input) {
      const r = await connectorHub.invoke(
        "web_research",
        "fetch_page",
        { url: input.url },
        { permission: "read", timeoutMs: 10_000 },
      );
      if (r.status !== "SUCCESS" || !r.data || typeof r.data !== "object") {
        throw new AgentError(
          "tool_unavailable",
          r.message || `web_research failed with status ${r.status}`,
          502,
        );
      }
      const data = r.data as Record<string, unknown>;
      const observedAt =
        typeof data.fetchedAt === "string" ? data.fetchedAt : new Date().toISOString();
      return {
        observedAt,
        value: {
          url: data.url,
          finalUrl: data.finalUrl,
          status: data.status,
          title: data.title,
          text: data.text,
          bytes: data.bytes,
          truncated: data.truncated,
        },
      };
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Tool result is missing or not an object." };
      }
      const candidate = result as { observedAt?: string; value?: Record<string, unknown> };
      const value = candidate.value;
      if (!value || typeof value !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Tool result has no value payload." };
      }
      const status = value.status;
      const text = value.text;
      if (typeof status !== "number" || status < 200 || status >= 300) {
        return {
          status: "FAILED",
          checkedAt,
          evidence: `HTTP status is not successful (${String(status)}).`,
        };
      }
      if (typeof text !== "string" || text.length === 0) {
        return { status: "FAILED", checkedAt, evidence: "Page text is empty." };
      }
      return {
        status: "VERIFIED",
        checkedAt,
        evidence: `Fetched ${String(value.url ?? "")} (${text.length} chars, status ${status}).`,
      };
    },
  });
  // Permission required by the tool; grant it so plans can use web_fetch after registration.
  grantPermission("read:web");
}

/**
 * Register read-only `web_search` tool (DuckDuckGo HTML via web_research connector).
 */
export function registerWebSearchTool(): void {
  registerTool({
    name: "web_search",
    description:
      "Search the public web (DuckDuckGo HTML). Returns titles, URLs, and snippets. Read-only; does not fabricate results.",
    permission: "read:web",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" },
        maxResults: { type: "number" },
      },
      required: ["query"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["query", "provider", "results"],
          additionalProperties: true,
          properties: {
            query: { type: "string" },
            provider: { type: "string" },
            results: { type: "array" },
            note: { type: "string" },
          },
        },
      },
    },
    successCondition: "result.value.results is an array (may be empty) and provider is present",
    async execute(input) {
      const r = await connectorHub.invoke(
        "web_research",
        "search",
        { query: input.query, maxResults: input.maxResults },
        { permission: "read", timeoutMs: 12_000 },
      );
      if (r.status !== "SUCCESS" || !r.data || typeof r.data !== "object") {
        throw new AgentError(
          "tool_unavailable",
          r.message || `web_search failed with status ${r.status}`,
          502,
        );
      }
      const data = r.data as Record<string, unknown>;
      const observedAt =
        typeof data.fetchedAt === "string" ? data.fetchedAt : new Date().toISOString();
      return {
        observedAt,
        value: {
          query: data.query,
          provider: data.provider,
          results: data.results,
          note: data.note,
        },
      };
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Tool result is missing or not an object." };
      }
      const value = (result as { value?: Record<string, unknown> }).value;
      if (!value || typeof value !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Tool result has no value payload." };
      }
      if (!Array.isArray(value.results)) {
        return { status: "FAILED", checkedAt, evidence: "results is not an array." };
      }
      if (typeof value.provider !== "string") {
        return { status: "FAILED", checkedAt, evidence: "provider missing." };
      }
      return {
        status: "VERIFIED",
        checkedAt,
        evidence: `Search "${String(value.query ?? "")}" via ${value.provider}: ${value.results.length} hit(s).`,
      };
    },
  });
  grantPermission("read:web");
}

/**
 * Register read-only GitHub tools: github_get_repo, github_list_issues, github_get_file, github_get_readme.
 */
export function registerGitHubTools(): void {
  const baseVerify = (label: string) => (result: unknown) => {
    const checkedAt = new Date().toISOString();
    if (!result || typeof result !== "object") {
      return { status: "UNKNOWN" as const, checkedAt, evidence: "Tool result is missing or not an object." };
    }
    const value = (result as { value?: Record<string, unknown> }).value;
    if (!value || typeof value !== "object") {
      return { status: "UNKNOWN" as const, checkedAt, evidence: "Tool result has no value payload." };
    }
    if (typeof value.fetchedAt !== "string") {
      return { status: "FAILED" as const, checkedAt, evidence: "fetchedAt missing." };
    }
    return {
      status: "VERIFIED" as const,
      checkedAt,
      evidence: `${label} ok at ${value.fetchedAt}.`,
    };
  };

  const invokeGh = async (action: string, input: Record<string, unknown>) => {
    const r = await connectorHub.invoke("github", action, input, {
      permission: "read",
      timeoutMs: 12_000,
    });
    if (r.status !== "SUCCESS" || !r.data || typeof r.data !== "object") {
      throw new AgentError(
        "tool_unavailable",
        r.message || `github.${action} failed with status ${r.status}`,
        502,
      );
    }
    const data = r.data as Record<string, unknown>;
    const observedAt =
      typeof data.fetchedAt === "string" ? data.fetchedAt : new Date().toISOString();
    return { observedAt, value: data };
  };

  registerTool({
    name: "github_get_repo",
    description: "Get public GitHub repository metadata (stars, description, default branch, etc.).",
    permission: "read:github",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: { owner: { type: "string" }, repo: { type: "string" } },
      required: ["owner", "repo"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: { type: "object", additionalProperties: true, properties: {}, required: [] },
      },
    },
    successCondition: "result.value.fullName is a non-empty string",
    async execute(input) {
      return invokeGh("get_repo", input);
    },
    verify: baseVerify("github_get_repo"),
  });

  registerTool({
    name: "github_list_issues",
    description: "List issues on a public GitHub repository (excludes pull requests).",
    permission: "read:github",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string" },
        repo: { type: "string" },
        state: { type: "string" },
        perPage: { type: "number" },
      },
      required: ["owner", "repo"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: { type: "object", additionalProperties: true, properties: {}, required: [] },
      },
    },
    successCondition: "result.value.issues is an array",
    async execute(input) {
      return invokeGh("list_issues", input);
    },
    verify: baseVerify("github_list_issues"),
  });

  registerTool({
    name: "github_get_file",
    description: "Read a file from a public GitHub repository via the Contents API.",
    permission: "read:github",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string" },
        repo: { type: "string" },
        path: { type: "string" },
        ref: { type: "string" },
      },
      required: ["owner", "repo", "path"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: { type: "object", additionalProperties: true, properties: {}, required: [] },
      },
    },
    successCondition: "result.value.content is a string",
    async execute(input) {
      return invokeGh("get_file", input);
    },
    verify: baseVerify("github_get_file"),
  });

  registerTool({
    name: "github_get_readme",
    description: "Fetch the README of a public GitHub repository.",
    permission: "read:github",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string" },
        repo: { type: "string" },
        ref: { type: "string" },
      },
      required: ["owner", "repo"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: { type: "object", additionalProperties: true, properties: {}, required: [] },
      },
    },
    successCondition: "result.value.content is a string",
    async execute(input) {
      return invokeGh("get_readme", input);
    },
    verify: baseVerify("github_get_readme"),
  });

  grantPermission("read:github");
}

/**
 * Register read and write tools for the safe workspace sandbox:
 * - workspace_list_files (read:workspace, LOW risk)
 * - workspace_read_file (read:workspace, LOW risk)
 * - workspace_syntax_check (read:workspace, LOW risk)
 * - workspace_write_file (write:workspace, HIGH risk, requires approval)
 */
export function registerWorkspaceTools(): void {
  // 1. workspace_list_files
  registerTool({
    name: "workspace_list_files",
    description: "List all files present in the safe sandbox workspace. Read-only.",
    permission: "read:workspace",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {},
      required: [],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["files", "count"],
          additionalProperties: true,
          properties: {
            files: { type: "array" },
            count: { type: "number" },
          },
        },
      },
    },
    successCondition: "result.value.files is an array",
    async execute() {
      const { listWorkspaceFiles } = await import("./files.js");
      const files = await listWorkspaceFiles();
      const observedAt = new Date().toISOString();
      return {
        observedAt,
        value: {
          files: files.map((f) => ({
            name: f.name,
            size: f.size,
            hash: f.hash,
            updatedAt: f.updatedAt,
          })),
          count: files.length,
        },
      };
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Tool result missing." };
      }
      const val = (result as { value?: Record<string, unknown> }).value;
      if (!val || !Array.isArray(val.files)) {
        return { status: "FAILED", checkedAt, evidence: "files is not an array." };
      }
      return {
        status: "VERIFIED",
        checkedAt,
        evidence: `Listed ${val.files.length} file(s) in workspace.`,
      };
    },
  });

  // 2. workspace_read_file
  registerTool({
    name: "workspace_read_file",
    description: "Read a file from the safe sandbox workspace. Read-only.",
    permission: "read:workspace",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
      },
      required: ["path"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["path", "content", "hash"],
          additionalProperties: true,
          properties: {
            path: { type: "string" },
            content: { type: "string" },
            hash: { type: "string" },
            size: { type: "number" },
          },
        },
      },
    },
    successCondition: "result.value.content is a string and result.value.hash is a 64-char hex string",
    async execute(input) {
      const filePath = String(input.path || "").trim();
      if (!filePath) {
        throw new AgentError("invalid_plan", "path is required", 400);
      }
      const { readWorkspaceFile } = await import("./files.js");
      const record = await readWorkspaceFile(filePath);
      if (!record) {
        throw new AgentError("tool_unavailable", `File not found in workspace: ${filePath}`, 404);
      }
      const observedAt = new Date().toISOString();
      return {
        observedAt,
        value: {
          path: record.name,
          content: record.content,
          hash: record.hash,
          size: record.size,
        },
      };
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Result missing." };
      }
      const val = (result as { value?: Record<string, unknown> }).value;
      if (!val || typeof val.content !== "string" || typeof val.hash !== "string") {
        return { status: "FAILED", checkedAt, evidence: "Content or hash missing." };
      }
      return {
        status: "VERIFIED",
        checkedAt,
        evidence: `Read workspace file ${String(val.path)} (${val.content.length} chars, hash ${val.hash.slice(0, 16)}...).`,
      };
    },
  });

  // 3. workspace_syntax_check
  registerTool({
    name: "workspace_syntax_check",
    description: "Check JavaScript or TypeScript syntax for a workspace file. Read-only.",
    permission: "read:workspace",
    risk: "LOW",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
      },
      required: ["path"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["path", "valid"],
          additionalProperties: true,
          properties: {
            path: { type: "string" },
            valid: { type: "boolean" },
            error: { type: "string" },
          },
        },
      },
    },
    successCondition: "result.value.valid is a boolean",
    async execute(input) {
      const filePath = String(input.path || "").trim();
      const { checkJavaScriptSyntax } = await import("./files.js");
      const res = await checkJavaScriptSyntax(filePath, false);
      const observedAt = new Date().toISOString();
      return {
        observedAt,
        value: {
          path: filePath,
          valid: res.valid,
          error: res.error,
        },
      };
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Result missing." };
      }
      const val = (result as { value?: Record<string, unknown> }).value;
      if (!val || typeof val.valid !== "boolean") {
        return { status: "FAILED", checkedAt, evidence: "Validation boolean missing." };
      }
      return {
        status: val.valid ? "VERIFIED" : "FAILED",
        checkedAt,
        evidence: val.valid ? `Syntax valid for ${String(val.path)}.` : `Syntax error: ${String(val.error)}.`,
      };
    },
  });

  // 4. workspace_write_file (HIGH risk, write:workspace permission, approval-governed)
  registerTool({
    name: "workspace_write_file",
    description: "Write or update a file in the sandbox workspace. HIGH risk, requires approval.",
    permission: "write:workspace",
    risk: "HIGH",
    available: true,
    configured: true,
    reachable: true,
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        content: { type: "string" },
      },
      required: ["path", "content"],
      additionalProperties: false,
    },
    outputSchema: {
      type: "object",
      required: ["observedAt", "value"],
      additionalProperties: false,
      properties: {
        observedAt: { type: "string", format: "date-time" },
        value: {
          type: "object",
          required: ["path", "size", "hash"],
          additionalProperties: true,
          properties: {
            path: { type: "string" },
            size: { type: "number" },
            hash: { type: "string" },
          },
        },
      },
    },
    successCondition: "result.value.hash is a 64-char hex string matching written content",
    async execute(input) {
      const filePath = String(input.path || "").trim();
      const content = String(input.content ?? "");
      const { writeWorkspaceFile } = await import("./files.js");
      const record = await writeWorkspaceFile(filePath, content, "code");
      const observedAt = new Date().toISOString();
      return {
        observedAt,
        value: {
          path: record.name,
          size: record.size,
          hash: record.hash,
        },
      };
    },
    verify(result) {
      const checkedAt = new Date().toISOString();
      if (!result || typeof result !== "object") {
        return { status: "UNKNOWN", checkedAt, evidence: "Result missing." };
      }
      const val = (result as { value?: Record<string, unknown> }).value;
      if (!val || typeof val.hash !== "string") {
        return { status: "FAILED", checkedAt, evidence: "Hash missing from write result." };
      }
      return {
        status: "VERIFIED",
        checkedAt,
        evidence: `Wrote file ${String(val.path)} with verified hash ${val.hash.slice(0, 16)}...`,
      };
    },
  });

  grantPermission("read:workspace");
}

