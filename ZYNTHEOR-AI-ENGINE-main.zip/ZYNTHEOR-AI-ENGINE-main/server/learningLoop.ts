/**
 * Learning loop — verified lessons.
 *
 * A lesson is something the engine may reuse on later tasks ("npm run build needs index.html in the root").
 * Rules, so "remembered" never silently becomes "believed":
 *  - A lesson can only be recorded together with evidence references (e.g. evidence-ledger ids).
 *  - It starts as CANDIDATE and is NEVER returned for use.
 *  - It becomes VALIDATED only after being confirmed by evidence from >= 2 distinct runs.
 *  - If contradicting observations reach the number of confirmations it becomes REJECTED.
 *  - Lessons can be retired (STALE) when the facts they depend on change.
 *  - Text is secret-redacted before persistence. Nothing here modifies code or configuration.
 * Storage: append-only JSONL events (LESSONS_PATH, default .data/lessons.jsonl); state is rebuilt by replay.
 */
import { appendFile, mkdir, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { dirname } from "node:path";
import { redactSecrets } from "./store.js";

export type LessonStatus = "CANDIDATE" | "VALIDATED" | "REJECTED" | "STALE";

export interface Lesson {
  id: string;
  taskType: string;
  lesson: string;
  status: LessonStatus;
  confirmedByRuns: string[];
  contradictedByRuns: string[];
  evidenceRefs: string[];
  createdAt: string;
  updatedAt: string;
  retiredReason?: string;
}

export const VALIDATION_THRESHOLD = 2;

type LessonEvent =
  | { type: "observe"; at: string; id: string; taskType: string; lesson: string; runId: string; held: boolean; evidenceRefs: string[] }
  | { type: "retire"; at: string; id: string; reason: string };

const file = () => process.env.LESSONS_PATH || ".data/lessons.jsonl";
const norm = (t: string) => t.toLowerCase().replace(/\s+/g, " ").trim();
export const lessonId = (taskType: string, lesson: string) =>
  "les_" + createHash("sha256").update(`${taskType}\n${norm(lesson)}`).digest("hex").slice(0, 16);

let chain: Promise<unknown> = Promise.resolve();
const serialized = <T>(fn: () => Promise<T>): Promise<T> => {
  const next = chain.then(fn, fn);
  chain = next.catch(() => undefined);
  return next;
};

async function readEvents(): Promise<LessonEvent[]> {
  let raw: string;
  try { raw = await readFile(file(), "utf8"); } catch { return []; }
  const events: LessonEvent[] = [];
  for (const line of raw.split("\n")) {
    if (!line.trim()) continue;
    try { events.push(JSON.parse(line) as LessonEvent); } catch { /* skip a corrupt line rather than invent state */ }
  }
  return events;
}

function rebuild(events: LessonEvent[]): Map<string, Lesson> {
  const map = new Map<string, Lesson>();
  for (const e of events) {
    if (e.type === "observe") {
      const l = map.get(e.id) ?? {
        id: e.id, taskType: e.taskType, lesson: e.lesson, status: "CANDIDATE" as LessonStatus,
        confirmedByRuns: [], contradictedByRuns: [], evidenceRefs: [], createdAt: e.at, updatedAt: e.at,
      };
      const bucket = e.held ? l.confirmedByRuns : l.contradictedByRuns;
      if (!bucket.includes(e.runId)) bucket.push(e.runId);
      for (const r of e.evidenceRefs) if (!l.evidenceRefs.includes(r)) l.evidenceRefs.push(r);
      l.updatedAt = e.at;
      if (l.status !== "STALE") {
        if (l.contradictedByRuns.length > 0 && l.contradictedByRuns.length >= l.confirmedByRuns.length) l.status = "REJECTED";
        else if (l.confirmedByRuns.length >= VALIDATION_THRESHOLD) l.status = "VALIDATED";
        else l.status = "CANDIDATE";
      }
      map.set(e.id, l);
    } else {
      const l = map.get(e.id);
      if (l) { l.status = "STALE"; l.retiredReason = e.reason; l.updatedAt = e.at; }
    }
  }
  return map;
}

async function append(event: LessonEvent): Promise<void> {
  await mkdir(dirname(file()), { recursive: true });
  await appendFile(file(), JSON.stringify(event) + "\n", "utf8");
}

export class LessonRecordError extends Error {}

/** Record that a run observed a lesson to hold (held=true) or to be contradicted (held=false). */
export function observeLesson(input: {
  taskType: string; lesson: string; runId: string; held: boolean; evidenceRefs: string[];
}): Promise<Lesson> {
  return serialized(async () => {
    const lesson = redactSecrets(input.lesson).trim();
    if (!input.taskType.trim() || !lesson || lesson.length > 500) throw new LessonRecordError("taskType and a lesson of 1-500 chars are required");
    if (!input.runId.trim()) throw new LessonRecordError("runId is required");
    const refs = input.evidenceRefs.map((r) => redactSecrets(r).trim()).filter(Boolean);
    if (refs.length === 0) throw new LessonRecordError("evidenceRefs are required: a lesson without evidence is not recorded");
    const id = lessonId(input.taskType, lesson);
    await append({ type: "observe", at: new Date().toISOString(), id, taskType: input.taskType, lesson, runId: input.runId, held: input.held, evidenceRefs: refs });
    return rebuild(await readEvents()).get(id)!;
  });
}

export function retireLesson(id: string, reason: string): Promise<Lesson | undefined> {
  return serialized(async () => {
    if (!(await readEvents().then(rebuild)).has(id)) return undefined;
    await append({ type: "retire", at: new Date().toISOString(), id, reason: redactSecrets(reason).slice(0, 300) });
    return rebuild(await readEvents()).get(id);
  });
}

export async function listLessons(filter: { status?: LessonStatus; taskType?: string } = {}): Promise<Lesson[]> {
  return [...rebuild(await readEvents()).values()]
    .filter((l) => (!filter.status || l.status === filter.status) && (!filter.taskType || l.taskType === filter.taskType))
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

/** The ONLY function the engine should use to apply lessons: validated ones, most-confirmed first. */
export async function retrieveUsableLessons(taskType: string, limit = 5): Promise<Lesson[]> {
  const all = await listLessons({ status: "VALIDATED", taskType });
  return all.sort((a, b) => b.confirmedByRuns.length - a.confirmedByRuns.length).slice(0, Math.max(0, limit));
}
