/**
 * Connector Hub — engine-side registry for external tools/services (GitHub, file stores, web research, APIs...).
 *
 * Honesty rules:
 *  - A connector that is declared but not installed is reported NOT_INSTALLED and every call returns UNAVAILABLE.
 *  - Nothing is simulated: SUCCESS only when a registered adapter actually returned.
 *  - Permissions are per connector and per class of action; write/mutate actions also need explicit approval.
 * The hub is generic: it knows no specific connector (and imports none).
 */
import { redactSecrets } from "./store.js";

export type ConnectorPermission = "read" | "write" | "call_api" | "mutate_system";
export type ConnectorAvailability = "NOT_INSTALLED" | "UNAVAILABLE" | "AVAILABLE";
export type HubStatus = "SUCCESS" | "FAILED" | "TIMEOUT" | "DENIED" | "UNAVAILABLE";
export type HubReason =
  | "NOT_INSTALLED" | "UNKNOWN_CONNECTOR" | "PERMISSION_NOT_GRANTED" | "PERMISSION_NOT_DECLARED"
  | "APPROVAL_REQUIRED" | "NOT_AVAILABLE" | "DEADLINE_EXCEEDED" | "ADAPTER_ERROR";

export interface ConnectorAdapter {
  id: string;
  label: string;
  /** Permission classes this connector can ever use. */
  permissions: ConnectorPermission[];
  checkAvailability(): Promise<{ available: boolean; reason?: string }>;
  invoke(action: string, input: Record<string, unknown>, ctx: { signal: AbortSignal }): Promise<unknown>;
}

export interface ConnectorStatusView {
  id: string;
  label: string;
  availability: ConnectorAvailability;
  declaredPermissions: ConnectorPermission[];
  grantedPermissions: ConnectorPermission[];
  note?: string;
}

export interface HubResult {
  status: HubStatus;
  connectorId: string;
  action: string;
  permission: ConnectorPermission;
  durationMs: number;
  reason?: HubReason;
  message: string;
  data?: unknown;
}

export interface HubAuditEntry {
  at: string; connectorId: string; action: string; permission: ConnectorPermission;
  status: HubStatus; reason?: HubReason; durationMs: number;
}

const NEEDS_APPROVAL: ReadonlySet<ConnectorPermission> = new Set(["write", "mutate_system"]);

type Declared = { id: string; label: string; permissions: ConnectorPermission[] };

export class ConnectorHub {
  private adapters = new Map<string, ConnectorAdapter>();
  private declared = new Map<string, Declared>();
  private grants = new Map<string, Set<ConnectorPermission>>();
  private audit: HubAuditEntry[] = [];

  /** Make a connector visible as "planned" without pretending it works. */
  declare(entry: Declared): void {
    if (!this.adapters.has(entry.id)) this.declared.set(entry.id, entry);
  }

  register(adapter: ConnectorAdapter): void {
    this.adapters.set(adapter.id, adapter);
    this.declared.delete(adapter.id);
  }

  unregister(id: string): boolean {
    this.grants.delete(id);
    return this.adapters.delete(id) || this.declared.delete(id);
  }

  grant(id: string, permission: ConnectorPermission): boolean {
    const known = this.adapters.get(id)?.permissions ?? this.declared.get(id)?.permissions;
    if (!known || !known.includes(permission)) return false;
    if (!this.grants.has(id)) this.grants.set(id, new Set());
    this.grants.get(id)!.add(permission);
    return true;
  }

  revoke(id: string, permission: ConnectorPermission): boolean {
    return this.grants.get(id)?.delete(permission) ?? false;
  }

  async list(): Promise<ConnectorStatusView[]> {
    const out: ConnectorStatusView[] = [];
    for (const d of this.declared.values()) {
      out.push({ id: d.id, label: d.label, availability: "NOT_INSTALLED", declaredPermissions: d.permissions, grantedPermissions: [...(this.grants.get(d.id) ?? [])], note: "declared only; no adapter installed" });
    }
    for (const a of this.adapters.values()) {
      let availability: ConnectorAvailability = "UNAVAILABLE";
      let note: string | undefined;
      try {
        const c = await a.checkAvailability();
        availability = c.available ? "AVAILABLE" : "UNAVAILABLE";
        note = c.reason ? redactSecrets(c.reason) : undefined;
      } catch (e) {
        note = redactSecrets(e instanceof Error ? e.message : "availability check failed");
      }
      out.push({ id: a.id, label: a.label, availability, declaredPermissions: a.permissions, grantedPermissions: [...(this.grants.get(a.id) ?? [])], note });
    }
    return out.sort((x, y) => x.id.localeCompare(y.id));
  }

  async invoke(
    id: string, action: string, input: Record<string, unknown>,
    opts: { permission: ConnectorPermission; approved?: boolean; timeoutMs?: number },
  ): Promise<HubResult> {
    const started = Date.now();
    const { permission } = opts;
    const done = (status: HubStatus, message: string, extra: { reason?: HubReason; data?: unknown } = {}): HubResult => {
      const durationMs = Date.now() - started;
      this.audit.push({ at: new Date().toISOString(), connectorId: id, action, permission, status, reason: extra.reason, durationMs });
      return { status, connectorId: id, action, permission, durationMs, message, ...extra };
    };

    const adapter = this.adapters.get(id);
    if (!adapter) {
      return this.declared.has(id)
        ? done("UNAVAILABLE", `Connector "${id}" is declared but not installed.`, { reason: "NOT_INSTALLED" })
        : done("UNAVAILABLE", `Connector "${id}" is not registered.`, { reason: "UNKNOWN_CONNECTOR" });
    }
    if (!adapter.permissions.includes(permission)) return done("DENIED", `Connector "${id}" does not declare "${permission}".`, { reason: "PERMISSION_NOT_DECLARED" });
    if (!this.grants.get(id)?.has(permission)) return done("DENIED", `Permission "${permission}" is not granted for "${id}".`, { reason: "PERMISSION_NOT_GRANTED" });
    if (NEEDS_APPROVAL.has(permission) && opts.approved !== true) return done("DENIED", `"${permission}" actions need explicit approval.`, { reason: "APPROVAL_REQUIRED" });

    try {
      const avail = await adapter.checkAvailability();
      if (!avail.available) return done("UNAVAILABLE", `Connector "${id}" is not available${avail.reason ? `: ${redactSecrets(avail.reason)}` : "."}`, { reason: "NOT_AVAILABLE" });
    } catch {
      return done("UNAVAILABLE", `Connector "${id}" availability check failed.`, { reason: "NOT_AVAILABLE" });
    }

    const controller = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, opts.timeoutMs ?? 10_000);
    try {
      const aborted = new Promise<never>((_, rej) => controller.signal.addEventListener("abort", () => rej(new Error("aborted"))));
      const data = await Promise.race([adapter.invoke(action, input, { signal: controller.signal }), aborted]);
      return done("SUCCESS", "Connector call completed.", { data });
    } catch (e) {
      return timedOut
        ? done("TIMEOUT", "Connector did not respond before the deadline.", { reason: "DEADLINE_EXCEEDED" })
        : done("FAILED", `Connector error: ${redactSecrets(e instanceof Error ? e.message : "unknown")}`, { reason: "ADAPTER_ERROR" });
    } finally {
      clearTimeout(timer);
    }
  }

  auditLog(): readonly HubAuditEntry[] { return this.audit; }
}

export const connectorHub = new ConnectorHub();
