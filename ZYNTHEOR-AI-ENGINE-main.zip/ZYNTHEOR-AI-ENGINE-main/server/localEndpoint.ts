/**
 * Caller-supplied local-runtime endpoints.
 *
 * A request may name the local runtime it wants to talk to (`endpoint` / `localEndpoint`). Without a check, any caller
 * could make the Core fetch an arbitrary URL (SSRF) or send a prompt to a server of their choosing. A requested endpoint
 * is therefore accepted only when it is a loopback address or the same host:port the operator configured in
 * LOCAL_AI_ENDPOINT / LOCAL_MODEL_URL. Anything else is rejected, never silently replaced.
 */
const DEFAULT_ENDPOINT = 'http://127.0.0.1:11434';

/** Flat on purpose: the project does not enable strictNullChecks, so a discriminated union would not narrow. */
export interface LocalEndpointResult {
  ok: boolean;
  /** The endpoint to use; empty when `ok` is false. */
  endpoint: string;
  /** Empty when `ok` is true. */
  code: '' | 'local_endpoint_not_allowed';
  message: string;
}

const accepted = (endpoint: string): LocalEndpointResult => ({ ok: true, endpoint, code: '', message: '' });

function configuredEndpoint(): string {
  return (process.env.LOCAL_AI_ENDPOINT || process.env.LOCAL_MODEL_URL || DEFAULT_ENDPOINT).trim().replace(/\/+$/, '');
}

function parse(value: string): URL | null {
  try {
    const url = new URL(value);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
    if (url.username || url.password) return null;
    return url;
  } catch {
    return null;
  }
}

function isLoopbackHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  return h === 'localhost' || h === '::1' || /^127(?:\.\d{1,3}){3}$/.test(h);
}

/** `requested` is whatever the caller sent (string, or anything else which is treated as "not provided"). */
export function resolveLocalEndpoint(...requested: unknown[]): LocalEndpointResult {
  const configured = configuredEndpoint();
  const asked = requested.find((v) => typeof v === 'string' && v.trim() !== '') as string | undefined;
  if (asked === undefined) return accepted(configured);

  const endpoint = asked.trim().replace(/\/+$/, '');
  const url = parse(endpoint);
  const reject = (): LocalEndpointResult => ({
    ok: false,
    endpoint: '',
    code: 'local_endpoint_not_allowed',
    message: 'The requested local runtime endpoint is not allowed. Use a loopback address, or set LOCAL_AI_ENDPOINT on the server.',
  });
  if (!url) return reject();
  if (isLoopbackHost(url.hostname)) return accepted(endpoint);
  const cfg = parse(configured);
  if (cfg && cfg.host.toLowerCase() === url.host.toLowerCase() && cfg.protocol === url.protocol) return accepted(endpoint);
  return reject();
}
