/**
 * Preflight Check: is the message path ready to carry a chat message to a local model?
 *
 * Every check carries a `basis` so nothing observed is mixed up with something merely assumed:
 *  - observed:    a real request/response or process fact seen by this run (HTTP status, error code, latency).
 *  - invariant:   the shipped decision logic was executed on fixed probe inputs (no network, no model).
 *  - not_tested:  nothing was exercised. Never reported as PASS.
 *
 * `READY` requires every blocking check to PASS, including a real inference. Without `infer`, the best result is
 * `PARTIAL`: the runtime and model are present, but nothing proves the model can answer.
 * Local only: this module contacts nothing except the configured local runtime (through runCoreDiagnostics).
 */
import { runCoreDiagnostics, type CoreDiagnosticsOptions, type StageStatus } from './coreDiagnostics.js';
import { routeReasoning } from './modeRouting.js';
import { derivePqcStatus } from '../src/utils/pqcStatus.js';

export type PreflightBasis = 'observed' | 'invariant' | 'not_tested';

export interface PreflightCheck {
  id: string;
  label: string;
  status: StageStatus;
  basis: PreflightBasis;
  /** Blocking checks decide `overall`; non-blocking ones are reported for honesty only. */
  blocking: boolean;
  code: string | null;
  evidence: string;
  latencyMs: number | null;
}

export interface PreflightReport {
  generatedAt: string;
  endpoint: string;
  runtimeKind: 'ollama' | 'openai-compatible' | null;
  models: string[];
  overall: 'READY' | 'PARTIAL' | 'NOT_READY';
  firstFailure: string | null;
  /** Ids of checks that were not exercised in this run. */
  notTested: string[];
  checks: PreflightCheck[];
}

/** A hand-picked mode must keep its meaning: the same wording must not reason in `chat` but must in `auto`. */
export function checkModeEnforcement(): PreflightCheck {
  const probe = 'ช่วยแก้บั๊กหน่อย';
  const auto = routeReasoning('auto', probe).use;
  const chat = routeReasoning('chat', probe).use;
  const code = routeReasoning('code', 'สวัสดี').use;
  const ok = auto === true && chat === false && code === true;
  return {
    id: 'mode_enforcement', label: 'Mode enforcement (server routing logic)',
    status: ok ? 'PASS' : 'FAIL', basis: 'invariant', blocking: true,
    code: ok ? null : 'MODE_ROUTING_DRIFT',
    evidence: `routeReasoning on fixed probes: auto+keyword=${auto} (expect true), chat+keyword=${chat} (expect false), code+plain=${code} (expect true). Logic only; not an HTTP request.`,
    latencyMs: null,
  };
}

/** A client that asserts it was verified must not be able to produce a Verified status. */
export function checkAuditEvidencePolicy(): PreflightCheck {
  const forged = {
    type: 'AUDIT_EVENT',
    pqcStatus: 'Verified',
    data: { verified: true, pqcStatus: 'Verified', origin: 'client_asserted', serverVerification: { verified: true } },
  };
  const claimOnly = { type: 'AUDIT_EVENT', data: { pqcStatus: 'Verified', verified: true, signature: 'SIG_VERIFIED' } };
  const a = derivePqcStatus(forged);
  const b = derivePqcStatus(claimOnly);
  const ok = a !== 'Verified' && b !== 'Verified';
  return {
    id: 'audit_evidence_policy', label: 'Audit: client claims are not evidence',
    status: ok ? 'PASS' : 'FAIL', basis: 'invariant', blocking: true,
    code: ok ? null : 'CLIENT_CLAIM_ACCEPTED',
    evidence: `derivePqcStatus on a client-asserted event=${a}, on a claim-only event=${b} (neither may be Verified). Logic only; not an HTTP request.`,
    latencyMs: null,
  };
}

/** Informational: states plainly that no server component produces PQC verification evidence. */
export function pqcVerificationSource(): PreflightCheck {
  return {
    id: 'pqc_server_verification', label: 'PQC server-side verification source',
    status: 'NOT_TESTED', basis: 'not_tested', blocking: false, code: 'NO_EVIDENCE_PRODUCER',
    evidence: 'No server component produces serverVerification evidence, so no audit event can show PQC "Verified".',
    latencyMs: null,
  };
}

export async function runPreflight(options: CoreDiagnosticsOptions): Promise<PreflightReport> {
  const diag = await runCoreDiagnostics(options);
  const checks: PreflightCheck[] = diag.stages.map((s) => ({
    id: s.id, label: s.label, status: s.status,
    // The Core API stage only proves this handler ran; it is an observed fact. Others come from real probes.
    basis: s.status === 'NOT_TESTED' ? 'not_tested' : s.id === 'provider_routing' ? 'invariant' : 'observed',
    blocking: true, code: s.code, evidence: s.evidence, latencyMs: s.latencyMs,
  }));
  checks.push(checkModeEnforcement(), checkAuditEvidencePolicy(), pqcVerificationSource());

  const blocking = checks.filter((c) => c.blocking);
  const failed = blocking.find((c) => c.status === 'FAIL');
  const allPass = blocking.every((c) => c.status === 'PASS');
  return {
    generatedAt: new Date().toISOString(),
    endpoint: diag.endpoint,
    runtimeKind: diag.runtimeKind,
    models: diag.models,
    overall: failed ? 'NOT_READY' : allPass ? 'READY' : 'PARTIAL',
    firstFailure: failed ? failed.id : null,
    notTested: checks.filter((c) => c.status === 'NOT_TESTED').map((c) => c.id),
    checks,
  };
}
