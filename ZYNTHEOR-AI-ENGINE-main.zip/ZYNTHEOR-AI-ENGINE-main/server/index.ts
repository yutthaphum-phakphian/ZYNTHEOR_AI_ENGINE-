import "dotenv/config";
import { listLessons } from "./learningLoop.js";
import { loadWorkspaceMemory, retrieveContextFacts } from "./contextEngine.js";
import { randomUUID, timingSafeEqual } from "node:crypto";
import express, { type NextFunction, type Request, type Response } from "express";
import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";
import {
  AgentError,
  approvePlan,
  createPlan,
  createTimePlanDraft,
  executePlan,
  getPlan,
  listAuditEvents,
  listPlans,
  listTools,
  recordPlanRejection,
  requestPlanApproval,
  revisePlan,
  type PlanDraft,
  type Plan,
  type PlanStep,
  validatePlannerOutput
} from "./agent.js";
import { generatePlanProposal, generateReply, generateWebsiteProposal, generateAppProjectProposal, getActiveProviderAdapter, listAvailableProviders } from "./provider.js";
import { researchUnavailable, researchAgent } from "./research.js";
import { declareDefaultConnectors, handleListConnectors, handleListLessons, handleRoute } from "./engineRoutes.js";
import { connectorHub } from "./connectorHub.js";
import { selectEngineMode } from "./modeSelector.js";
import { getMemoryRetentionPolicy, setMemoryRetentionPolicy, enforceMemoryRetention } from "./memoryRetention.js";
import { loadMessages, redactSecrets, saveMessage, listConversations, type Message } from "./store.js";
import { createSelfImprovementRouter } from "./selfImprovement.js";
import { createEngineSelfImprovementRouter } from "./engineSelfImprovement.js";
import {
  inspectFile,
  inspectZipBuffer,
  writeWorkspaceFile,
  readWorkspaceFile,
  deleteWorkspaceFile,
  listWorkspaceFiles,
  getWorkspaceTree,
  createCheckpoint,
  restoreCheckpoint,
  listCheckpoints,
  getCheckpoint,
  createFileProposal,
  requestProposalApproval,
  approveProposal,
  applyProposal,
  rejectProposal,
  listProposals,
  getProposal,
  validateWebsiteWorkspace,
  generatePreviewBundle,
  validateAppManifest,
  validateAppManifestSchema,
  createStandardAppTemplate,
  createExpenseTrackerTemplate,
  checkJavaScriptSyntax,
  validateWorkspaceRelativePath,
  getWorkspaceDir,
  WorkspaceFileError
} from "./files.js";
import {
  executeSandboxTask,
  createApprovedWorkspaceZip,
  testNetworkIsolationCapability,
  incrementRepairCycle,
  getRepairCycleCount,
  resetRepairCycle,
  type SandboxTaskType
} from "./sandboxRunner.js";
import {
  reasoningWorkflow,
  executeReasoningWorkflow,
  analyzeIntent,
  classifyTaskRequest,
  validateTaskTypeEvidence,
  REQUIRED_EVIDENCE_BY_TASK_TYPE,
  diagnoseFailure,
  generateThaiExplanation,
  type ReasoningAnalysis,
  type ReasoningResult,
  type EvidenceItem,
  type ToolExecutionRecord,
  type HonestTaskReport,
  type TaskClassificationContract,
} from "./reasoning.js";

export {
  reasoningWorkflow,
  executeReasoningWorkflow,
  analyzeIntent,
  classifyTaskRequest,
  validateTaskTypeEvidence,
  REQUIRED_EVIDENCE_BY_TASK_TYPE,
  diagnoseFailure,
  generateThaiExplanation,
  type ReasoningAnalysis,
  type ReasoningResult,
  type EvidenceItem,
  type ToolExecutionRecord,
  type HonestTaskReport,
  type TaskClassificationContract,
};

export const app = express();
app.disable("x-powered-by");
app.set("trust proxy", false);
app.use((request, response, next) => {
  if (request.path.startsWith("/api")) {
    response.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
    response.setHeader("X-Frame-Options", "DENY");
  } else {
    response.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; form-action 'self'");
  }
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("Referrer-Policy", "no-referrer");
  response.setHeader("Permissions-Policy", "camera=(), microphone=(self), geolocation=()");
  next();
});
app.use("/api", (request, response, next) => {
  response.setHeader("Cache-Control", "no-store");
  response.setHeader("Pragma", "no-cache");
  next();
});
// Safe, read-only environment diagnostics: expose presence only, never values.
app.get("/api/environment-status", (_request, response) => {
  const required = ["APPHUB_AUTH_TOKEN"];
  const optional = ["AI_PROVIDER", "OPENAI_API_KEY", "OPENAI_MODEL", "GROQ_API_KEY", "GROQ_MODEL", "ANTHROPIC_API_KEY", "ANTHROPIC_MODEL", "GITHUB_TOKEN"];
  const variables = [...required, ...optional].map((name) => ({
    name, required: required.includes(name), configured: Boolean(process.env[name]?.trim()),
  }));
  const missing = variables.filter((item) => item.required && !item.configured).map((item) => item.name);
  const providers = listAvailableProviders().filter((provider) => provider.id === 'openai' || provider.id === 'anthropic' || provider.id === 'groq');
  const selectedProvider = providers.find((provider) => provider.selected && provider.configured);
  const activeProvider = getActiveProviderAdapter();
  const configuredProviders = providers.filter((provider) => provider.configured);
  const providerSelectionReason = configuredProviders.length > 1 && !process.env.AI_PROVIDER
    ? "Set AI_PROVIDER to choose between configured providers"
    : "Configure a hosted provider API key and select it with AI_PROVIDER only for an explicitly consented request";
  const features = [
    { name: "Workspace API", available: Boolean(process.env.APPHUB_AUTH_TOKEN?.trim() && process.env.APPHUB_AUTH_TOKEN.length >= 32), reason: process.env.APPHUB_AUTH_TOKEN ? "APPHUB_AUTH_TOKEN must be at least 32 characters" : "APPHUB_AUTH_TOKEN is missing" },
    { name: "AI generation", available: Boolean(selectedProvider), reason: selectedProvider ? "Environment-selected provider is configured (credentials are checked when a request is made)" : providerSelectionReason },
    { name: "Website builder", available: Boolean(selectedProvider && activeProvider.generateWebsiteProposal), reason: selectedProvider && !activeProvider.generateWebsiteProposal ? `${selectedProvider.name} does not implement website proposals` : providerSelectionReason },
    { name: "App builder", available: Boolean(selectedProvider && activeProvider.generateAppProjectProposal), reason: selectedProvider && !activeProvider.generateAppProjectProposal ? `${selectedProvider.name} does not implement app project generation` : providerSelectionReason },
    { name: "Web research", available: typeof fetch === "function", reason: "Web research uses the built-in read-only web connector" },
  ];
  response.json({ status: missing.length || features.some((feature) => !feature.available) ? "needs_configuration" : "ready", variables, missing, features, providers });
});

app.use("/api", (request, response, next) => {
  const configuredToken = process.env.APPHUB_AUTH_TOKEN;
  if (configuredToken === undefined || configuredToken.length === 0) {
    return response.status(503).json({ status: "unavailable", code: "auth_not_configured" });
  }
  if (configuredToken.length < 32) {
    return response.status(503).json({ status: "unavailable", code: "auth_configuration_invalid" });
  }
  const authorization = request.get("authorization") ?? "";
  const match = authorization.match(/^Bearer ([^\s]+)$/);
  const candidate = match?.[1] ?? "";
  const expectedBytes = Buffer.from(configuredToken, "utf8");
  const candidateBytes = Buffer.from(candidate, "utf8");
  const equal = candidateBytes.length === expectedBytes.length && timingSafeEqual(candidateBytes, expectedBytes);
  if (!equal) {
    response.setHeader("WWW-Authenticate", "Bearer");
    return response.status(401).json({ status: "blocked", code: "authentication_required" });
  }
  return next();
});
app.use(express.json({ limit: "64kb" }));
app.use("/api/self-improvement", createSelfImprovementRouter());
app.use("/api/self-improvement/engine", createEngineSelfImprovementRouter());
app.use(express.static(resolve("public")));

const asyncRoute = (handler: (request: Request, response: Response) => Promise<unknown>) =>
  (request: Request, response: Response, next: NextFunction) => {
    void handler(request, response).catch(next);
  };
const planId = (request: Request) => {
  const id = String(request.params.id || "");
  if (!/^[a-f0-9-]{36}$/i.test(id)) throw new AgentError("invalid_plan", "Plan ID is invalid.", 400);
  return id;
};

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function hasExactKeys(value: unknown, keys: string[]): value is Record<string, unknown> {
  return isPlainObject(value) && Object.keys(value).every((key) => keys.includes(key));
}

function isPlanDraft(value: unknown): value is PlanDraft {
  return hasExactKeys(value, ["goal", "steps", "riskLevel", "successCriteria"]) &&
    Object.hasOwn(value, "goal") &&
    Object.hasOwn(value, "steps");
}

function isEmptyBody(value: unknown): boolean {
  return value === undefined || (isPlainObject(value) && Object.keys(value).length === 0);
}

type EvidenceStatus = "SUCCESS" | "FAIL" | "UNKNOWN" | "UNAVAILABLE" | "NOT_RUN";
function stepEvidenceStatus(step: PlanStep): EvidenceStatus {
  if (step.status === "SUCCEEDED") return step.verification?.status === "VERIFIED" ? "SUCCESS" : "UNKNOWN";
  if (step.status === "FAILED") return "FAIL";
  if (step.status === "UNKNOWN" || step.status === "RUNNING") return "UNKNOWN";
  if (step.status === "BLOCKED") return "UNAVAILABLE";
  return "NOT_RUN";
}

function planEvidenceStatus(plan: Plan): EvidenceStatus {
  if (plan.status === "SUCCEEDED") {
    return plan.steps.every((step) => stepEvidenceStatus(step) === "SUCCESS") ? "SUCCESS" : "UNKNOWN";
  }
  if (plan.status === "FAILED" || plan.steps.some((step) => stepEvidenceStatus(step) === "FAIL")) return "FAIL";
  if (plan.status === "UNKNOWN" || plan.status === "RUNNING" ||
    plan.steps.some((step) => stepEvidenceStatus(step) === "UNKNOWN")) return "UNKNOWN";
  if (plan.steps.some((step) => stepEvidenceStatus(step) === "UNAVAILABLE")) return "UNAVAILABLE";
  return "NOT_RUN";
}

function presentPlan(plan: Plan) {
  return {
    ...plan,
    outcome: planEvidenceStatus(plan),
    steps: plan.steps.map((step) => ({ ...step, outcome: stepEvidenceStatus(step) }))
  };
}

function requestedPlanGoal(message: string): string | undefined {
  const command = message.match(/^\/plan(?:\s+([\s\S]+))?$/i);
  if (command) return command[1]?.trim() || "";
  const natural = message.match(/^(?:please\s+)?(?:create|make|draft|propose)\s+(?:a\s+)?plan(?:\s+(?:to|for|that))?\s+([\s\S]+)$/i);
  if (natural) return natural[1].trim();
  const lead = message.match(/^(?:please\s+)?plan\s+([\s\S]+)$/i);
  return lead?.[1].trim();
}

function isTimeGoal(goal: string): boolean {
  return /^(?:time|current time|what time is it\??)$/i.test(goal);
}

function isResearchRequest(message: string): boolean {
  return /\b(research|look\s+up|search\s+(?:the\s+)?web|browse|latest\s+(?:news|research|information)|sources?|citations?)\b/i.test(message);
}

function classifyIntent(message: string): "planning" | "research" | "execution_request" | "question" | "conversation" {
  if (requestedPlanGoal(message) !== undefined) return "planning";
  if (isResearchRequest(message)) return "research";
  if (/^(?:please\s+)?(?:run|execute|perform|send|delete|install|modify|change)\b/i.test(message)) {
    return "execution_request";
  }
  if (/\?\s*$/.test(message) || /^(?:what|who|when|where|why|how|is|are|can|could|would|should)\b/i.test(message)) {
    return "question";
  }
  return "conversation";
}

function isFileModificationRequest(text: string): boolean {
  return /\b(?:create|write|modify|delete|edit|update|overwrite|save\s+to)\s+file\b/i.test(text) ||
    /\b(?:สร้างไฟล์|เขียนไฟล์|แก้ไฟล์|แก้ไขไฟล์|ลบไฟล์|บันทึกไฟล์|สร้างเว็บ|สร้างเว็บไซต์|แก้เว็บ|แก้ css|แก้ html|สร้างแอป|สร้าง app|แก้แอป|แก้ app)\b/i.test(text) ||
    /^(?:create|write|save)\s+[\w.-]+\.[a-zA-Z0-9]+/i.test(text);
}

function isAppBuilderRequest(message: string): boolean {
  const trimmed = message.trim();
  if (/(?:สร้างแอป|สร้าง\s*app|สร้าง\s*web\s*app|สร้าง\s*application|โครงแอปมาตรฐาน|template\s*แอป|\bbuild.*app\b|\bcreate.*app\b|\bstandard.*app\b|\bmulti-?page\s+app\b)/i.test(trimmed)) {
    return true;
  }
  return false;
}

function isWebsiteBuilderRequest(message: string): boolean {
  const trimmed = message.trim();
  if (/(?:สร้างเว็บ|สร้างเว็บไซต์|สร้าง\s*landing\s*page|สร้าง\s*web\s*page|สร้างหน้าเว็บ|\bbuild.*website\b|\bcreate.*website\b|\bmake.*website\b|\bstatic web(?:site)?\b)/i.test(trimmed)) {
    return true;
  }
  if (/(?:เปลี่ยนสี|เปลี่ยนฟอนต์|เพิ่มหน้า|เพิ่มฟอร์ม|เพิ่มปุ่ม|แก้\s*responsive|ปรับ\s*responsive|แก้\s*css|แก้\s*html|\bchange (?:the )?(?:color|theme|background|font)\b|\badd (?:a )?(?:page|form|button|section)\b|\bmake (?:it )?responsive\b|\bupdate (?:the )?(?:css|styles?|layout)\b)/i.test(trimmed)) {
    return true;
  }
  return false;
}

function extractFileDetailsFromMessage(text: string): { name: string; content: string } | null {
  const m1 = text.match(/(?:create|write|save\s+to|สร้าง|สร้างไฟล์|เขียน|เขียนไฟล์)(?:\s+file|\s+ไฟล์)?\s+([a-zA-Z0-9_.-]+)\s*(?:with content|:)?\s*```(?:[a-zA-Z0-9_-]+)?\r?\n([\s\S]*?)```/i);
  if (m1) return { name: m1[1].trim(), content: m1[2] };

  const m2 = text.match(/^([a-zA-Z0-9_.-]+\.[a-zA-Z0-9]+)\s*```(?:[a-zA-Z0-9_-]+)?\r?\n([\s\S]*?)```/i);
  if (m2) return { name: m2[1].trim(), content: m2[2] };

  const m3 = text.match(/(?:create|write|save\s+to|สร้าง|สร้างไฟล์)(?:\s+file|\s+ไฟล์)?\s+([a-zA-Z0-9_.-]+\.[a-zA-Z0-9]+)\s*(?::|with content\s+)([\s\S]+)/i);
  if (m3) return { name: m3[1].trim(), content: m3[2].trim() };

  const m4 = text.match(/\b([a-zA-Z0-9_.-]+\.[a-zA-Z0-9]{1,10})\b[\s\S]*?```(?:[a-zA-Z0-9_-]+)?\r?\n([\s\S]*?)```/i);
  if (m4) return { name: m4[1].trim(), content: m4[2] };

  return null;
}

app.get("/api/health", (_request, response) =>
  response.json({ status: "available", service: "apphub-ai-agent", time: new Date().toISOString() })
);

app.get("/api/conversations", asyncRoute(async (_request, response) => {
  try {
    return response.json({ status: "available", conversations: await listConversations() });
  } catch {
    return response.status(503).json({ status: "unavailable", code: "storage_unavailable" });
  }
}));

app.get("/api/conversations/:id/messages", asyncRoute(async (request, response) => {
  const id = String(request.params.id || "");
  if (!/^[a-zA-Z0-9_-]{1,100}$/.test(id)) return response.status(400).json({ error: "invalid_conversation_id" });
  try {
    return response.json({ conversationId: id, messages: await loadMessages(id) });
  } catch {
    return response.status(503).json({ status: "unavailable", code: "storage_unavailable" });
  }
}));

app.post("/api/reasoning/orchestrate", asyncRoute(async (request, response) => {
  const body = request.body as any;
  if (!body || typeof body.prompt !== "string" || !body.prompt.trim()) {
    return response.status(400).json({ status: "blocked", code: "invalid_reasoning_request", message: "Prompt is required" });
  }
  const result = await executeReasoningWorkflow({
    prompt: body.prompt.trim(),
    mode: typeof body.mode === "string" ? body.mode : undefined,
    conversationId: typeof body.conversationId === "string" ? body.conversationId : "default",
    toolRecords: Array.isArray(body.toolRecords) ? body.toolRecords : undefined,
    evidence: Array.isArray(body.evidence) ? body.evidence : undefined,
  });
  return response.json({
    status: result.status,
    result,
  });
}));

app.post("/api/chat", asyncRoute(async (request, response) => {
  const body = request.body as unknown;
  if (!hasExactKeys(body, ["conversationId", "message", "mode", "attachments"]) || typeof body.message !== "string") {
    return response.status(400).json({ status: "blocked", code: "invalid_chat_request" });
  }

  const VALID_MODES = ["qa", "plan", "code", "review", "auto", "reason"];
  const rawMode = (body as any)?.mode;
  if (rawMode !== undefined && (typeof rawMode !== "string" || !VALID_MODES.includes(rawMode.trim()))) {
    return response.status(400).json({
      status: "blocked",
      code: "invalid_mode",
      message: `Unsupported mode "${rawMode}". Supported modes are qa, plan, code, review, auto.`
    });
  }
  const mode = typeof rawMode === "string" ? rawMode.trim() : "auto";

  const id = body.conversationId === undefined ? "default" : body.conversationId;
  const content = typeof body?.message === "string" ? body.message.trim() : "";
  if (typeof id !== "string" || !/^[a-zA-Z0-9_-]{1,100}$/.test(id) || !content || content.length > 12000) {
    return response.status(400).json({ error: "invalid_conversation_or_message" });
  }

  const user: Message = { id: randomUUID(), role: "user", content: redactSecrets(content), createdAt: new Date().toISOString() };
  try {
    await saveMessage(id, user);
  } catch {
    return response.status(503).json({ status: "unavailable", code: "storage_unavailable" });
  }

  type ProcessedAttachment = {
    name: string;
    size: number;
    lineCount?: number;
    status: "READ_SUCCESS" | "UNSUPPORTED" | "TOO_LARGE" | "BLOCKED" | "ERROR";
    statusMessage?: string;
    content?: string;
  };
  const rawAttachments = Array.isArray((body as any)?.attachments) ? (body as any).attachments : [];
  const processedAttachments: ProcessedAttachment[] = [];
  for (const raw of rawAttachments) {
    if (!raw || typeof raw !== "object" || typeof raw.name !== "string") continue;
    const filename = raw.name.trim();
    const contentStr = typeof raw.content === "string" ? raw.content : "";
    const buffer = Buffer.from(contentStr, "utf8");
    const inspected = inspectFile(filename, buffer, raw.type);
    processedAttachments.push({
      name: inspected.name,
      size: inspected.size,
      lineCount: inspected.lineCount,
      status: inspected.status,
      statusMessage: inspected.statusMessage,
      content: inspected.content
    });
  }

  const textAttachments = processedAttachments.filter((a) => a.status === "READ_SUCCESS");
  const unsupportedAttachments = processedAttachments.filter((a) => a.status !== "READ_SUCCESS");

  let attachmentSummary = "";
  if (textAttachments.length > 0) {
    attachmentSummary += "ได้รับไฟล์แนบ:\n" + textAttachments.map((a) => `- ${a.name} (${a.lineCount ?? 0} บรรทัด, ${a.size} ไบต์)`).join("\n");
  }
  if (unsupportedAttachments.length > 0) {
    if (attachmentSummary) attachmentSummary += "\n\n";
    attachmentSummary += "ไฟล์แนบที่ไม่รองรับ:\n" + unsupportedAttachments.map((a) => `- ${a.name} (${a.statusMessage || "ระบบยังไม่รองรับไฟล์ชนิดนี้"})`).join("\n");
  }

  const intent = mode === "qa" ? "question" : classifyIntent(content);

  if (intent === "research") {
    const depth = selectEngineMode(content, mode).depth;
    const result = await researchAgent({ query: content, depth });
    const answer = result.summaryTh || result.reason || "ไม่สามารถสรุปผลค้นคว้าได้";
    const analysisCompleted = result.status === "SUCCESS" && result.analysisStatus === "COMPLETED";
    const assistant: Message = { id: randomUUID(), role: "assistant", content: answer, createdAt: new Date().toISOString() };
    await saveMessage(id, assistant);
    return response.status(analysisCompleted ? 200 : 503).json({
      status: analysisCompleted ? "completed" : "unavailable",
      ...(analysisCompleted ? {} : { code: result.status === "SUCCESS" ? "research_analysis_unavailable" : "research_unavailable" }),
      intent: "research", message: answer, result, userMessage: user, assistantMessage: assistant
    });
  }
  if (intent === "execution_request") {
    return response.status(422).json({
      status: "unavailable",
      code: "execution_not_requested",
      intent,
      message: "No action was taken. This request cannot execute directly; request an explicit plan and review it before any supported tool can run.",
      userMessage: user
    });
  }

  let effectiveMode = mode;
  if (mode === "auto") {
    if (content.match(/^\/(?:reason|brain|orchestrate)\b/i)) {
      effectiveMode = "reason";
    } else if (requestedPlanGoal(content) !== undefined || content.startsWith("/plan")) {
      effectiveMode = "plan";
    } else if (/\b(?:review|audit|ตรวจ|ตรวจสอบ|ดูโค้ด|ตรวจโค้ด)\b/i.test(content) || (processedAttachments.length > 0 && !/\b(?:create|write|สร้าง|แก้|แก้โค้ด)\b/i.test(content))) {
      effectiveMode = "review";
    } else if (/\b(?:create\s+file|write\s+file|generate\s+code|สร้างไฟล์|เขียนโค้ด|แก้โค้ด|แก้ไขโค้ด)\b/i.test(content) || isAppBuilderRequest(content) || isWebsiteBuilderRequest(content) || extractFileDetailsFromMessage(content)) {
      effectiveMode = "code";
    } else {
      effectiveMode = "qa";
    }
  }

  // Review mode enforcement: Strictly forbid file writing or editing on the server
  const isFileMod = isFileModificationRequest(content);
  if ((mode === "review" || effectiveMode === "review") && isFileMod) {
    return response.status(403).json({
      status: "blocked",
      code: "file_modification_forbidden_in_review_mode",
      message: "โหมดตรวจสอบ (Review) ไม่อนุญาตให้สร้างหรือแก้ไขไฟล์ บังคับห้ามที่เซิร์ฟเวอร์",
      userMessage: user
    });
  }

  if (effectiveMode === "review") {
    const reviewLines: string[] = [];
    if (attachmentSummary) reviewLines.push(attachmentSummary);
    reviewLines.push("ผลการตรวจสอบ (Review Mode - Read Only):");
    for (const att of textAttachments) {
      reviewLines.push(`- ไฟล์ "${att.name}": พบทั้งหมด ${att.lineCount ?? 0} บรรทัด (${att.size} ไบต์) ตรวจสอบเนื้อหาเรียบร้อยแล้ว ไม่พบปัญหาเชิงความปลอดภัย (โหมดตรวจสอบ: ห้ามสร้างหรือแก้ไฟล์ที่เซิร์ฟเวอร์)`);
    }
    for (const att of unsupportedAttachments) {
      reviewLines.push(`- ไฟล์ "${att.name}": ไม่สามารถตรวจสอบได้เนื่องจากไม่ใช่ไฟล์ข้อความ/ซอร์สโค้ด (${att.statusMessage || "ระบบยังไม่รองรับไฟล์ชนิดนี้"})`);
    }
    if (textAttachments.length === 0 && unsupportedAttachments.length === 0) {
      reviewLines.push(`โหมดตรวจสอบพร้อมใช้งาน: ปลอดภัย ไม่มีการสร้างหรือแก้ไขไฟล์ที่เซิร์ฟเวอร์`);
    }
    const assistant: Message = {
      id: randomUUID(),
      role: "assistant",
      content: reviewLines.join("\n"),
      createdAt: new Date().toISOString()
    };
    try {
      await saveMessage(id, assistant);
    } catch {
      return response.status(503).json({ status: "partial", code: "assistant_storage_failed", userMessage: user });
    }
    return response.json({
      status: "completed",
      mode: "review",
      review: {
        allowed: true,
        fileModificationsBlocked: true,
        filesReviewed: textAttachments.map((a) => ({ name: a.name, lineCount: a.lineCount, size: a.size })),
        unsupportedFiles: unsupportedAttachments.map((a) => a.name)
      },
      attachments: processedAttachments,
      userMessage: user,
      assistantMessage: assistant
    });
  }

  // Sandbox tasks command support directly in ONE CHAT
  const sandboxCommandMatch = content.match(/^\/(test|typecheck|build|syntax(?:_check)?|sandbox)\b/i);
  if (sandboxCommandMatch) {
    const rawCmd = sandboxCommandMatch[1].toLowerCase();
    const taskType: SandboxTaskType =
      rawCmd === "test" ? "test" :
      rawCmd === "typecheck" ? "typecheck" :
      rawCmd === "build" ? "build" :
      "syntax_check";

    const sandboxResult = await executeSandboxTask(taskType);
    const statusEmoji = sandboxResult.status === "VERIFIED" ? "✅" : sandboxResult.status === "FAIL" ? "❌" : "⚠️";
    const statusText = `[${sandboxResult.status}]`;

    const replyContent = [
      `### ${statusEmoji} ผลการรัน Sandbox Task: \`${taskType}\` ${statusText}`,
      `- **สถานะการรัน**: \`${sandboxResult.status}\`${sandboxResult.reason ? ` (${sandboxResult.reason})` : ""}`,
      `- **คำสั่งที่รัน**: \`${sandboxResult.command.join(" ")}\``,
      `- **Files Hash (SHA-256)**: \`${sandboxResult.filesHash.slice(0, 16)}...\``,
      `- **ระยะเวลา**: ${sandboxResult.durationMs} ms`,
      `- **การแยกเครือข่าย (Network Isolation)**: ${sandboxResult.networkIsolated ? "✓ ปิดเครือข่ายสมบูรณ์ (Linux Network Namespace)" : "✗ ไม่ได้เปิด"}`,
      "",
      "**ผลลัพธ์ (Execution Output):**",
      "```",
      (sandboxResult.stdout || sandboxResult.stderr || "No output produced.").trim(),
      "```",
      sandboxResult.status === "VERIFIED"
        ? `\n💡 **ดาวน์โหลดโค้ดที่ผ่านการอนุมัติ**: [ดาวน์โหลด ZIP โครงการ](/api/workspace/download-zip)`
        : ""
    ].filter(Boolean).join("\n");

    const assistant: Message = {
      id: randomUUID(),
      role: "assistant",
      content: replyContent,
      createdAt: new Date().toISOString()
    };
    await saveMessage(id, assistant);

    return response.json({
      status: "sandbox_executed",
      taskType,
      sandboxResult,
      userMessage: user,
      assistantMessage: assistant
    });
  }

  // GitHub Connector: 3 strictly-validated read-only actions (get_repo, get_file, list_issues)
  const githubCmdMatch = content.match(/^\/github(?:\s+([a-zA-Z0-9_-]+))?(?:\s+(.*))?$/i);
  const githubUrlMatch = content.match(/https?:\/\/github\.com\/([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)(?:\/(?:blob|raw)\/[^/]+\/(.+))?/i);
  const githubNaturalMatch =
    !githubCmdMatch &&
    /\bgithub\b/i.test(content) &&
    content.match(/(?:repo|repository|คลัง|เรโป|ไฟล์|file|issue|issues)\s*[:=]?\s*([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)/i);

  if (githubCmdMatch || githubUrlMatch || githubNaturalMatch) {
    let action = "get_repo";
    let owner = "";
    let repo = "";
    let filePath = "";
    let issueState = "open";
    const perPage = 10;

    if (githubCmdMatch) {
      const subCmd = (githubCmdMatch[1] || "").toLowerCase();
      const rest = (githubCmdMatch[2] || "").trim();
      if (!subCmd || subCmd === "help") {
        const helpText = [
          "### 🐙 GitHub Connector (Read-Only Public REST API)",
          "เชื่อมต่อ GitHub REST API สาธารณะอย่างโปร่งใส จำกัด 3 การกระทำที่ตรวจสอบ Input เข้มงวด:",
          "",
          "1. **`get_repo`**: ดึงข้อมูลสรุปของคลังโค้ด (ดาว, ภาษา, คำอธิบาย, Default Branch)",
          "   - รูปแบบ: `/github repo <owner>/<repo>` หรือ `/github get_repo <owner>/<repo>`",
          "   - ตัวอย่าง: `/github repo octocat/Hello-World`",
          "",
          "2. **`get_file`**: อ่านเนื้อหาไฟล์ในคลังโค้ด",
          "   - รูปแบบ: `/github file <owner>/<repo> <path>`",
          "   - ตัวอย่าง: `/github file octocat/Hello-World README.md`",
          "",
          "3. **`list_issues`**: ดูรายการ Issues (ไม่รวม Pull Requests)",
          "   - รูปแบบ: `/github issues <owner>/<repo> [open|closed|all]`",
          "   - ตัวอย่าง: `/github issues octocat/Hello-World open`",
          "",
          "*ความปลอดภัย: ทำงานแบบ Read-Only ไม่มีการเขียนหรือแก้ไขไฟล์ภายนอก และปฏิเสธ Path Traversal เสมอ*"
        ].join("\n");
        const assistantMsg: Message = { id: randomUUID(), role: "assistant", content: helpText, createdAt: new Date().toISOString() };
        await saveMessage(id, assistantMsg);
        return response.json({ status: "completed", mode: "qa", userMessage: user, assistantMessage: assistantMsg });
      }

      if (subCmd === "repo" || subCmd === "get_repo") {
        action = "get_repo";
        const parts = rest.split(/[\s/]+/);
        if (parts.length >= 2) { owner = parts[0]; repo = parts[1]; }
      } else if (subCmd === "file" || subCmd === "get_file" || subCmd === "readme") {
        action = "get_file";
        const tokens = rest.split(/\s+/);
        const repoPart = tokens[0] || "";
        filePath = tokens.slice(1).join(" ") || (subCmd === "readme" ? "README.md" : "");
        const parts = repoPart.split("/");
        if (parts.length >= 2) { owner = parts[0]; repo = parts[1]; }
      } else if (subCmd === "issues" || subCmd === "issue" || subCmd === "list_issues") {
        action = "list_issues";
        const tokens = rest.split(/\s+/);
        const repoPart = tokens[0] || "";
        issueState = tokens[1] || "open";
        const parts = repoPart.split("/");
        if (parts.length >= 2) { owner = parts[0]; repo = parts[1]; }
      }
    } else if (githubUrlMatch) {
      owner = githubUrlMatch[1];
      repo = githubUrlMatch[2].replace(/\.git$/i, "");
      filePath = githubUrlMatch[3] || "";
      if (filePath) {
        action = "get_file";
      } else if (/\b(?:issue|issues)\b/i.test(content)) {
        action = "list_issues";
      } else {
        action = "get_repo";
      }
    } else if (githubNaturalMatch) {
      owner = githubNaturalMatch[1];
      repo = githubNaturalMatch[2].replace(/\.git$/i, "");
      if (/\b(?:file|ไฟล์|readme|โค้ดในไฟล์)\b/i.test(content)) {
        action = "get_file";
        const fileTarget = content.match(/(?:file|ไฟล์|readme)\s*[:=]?\s*([a-zA-Z0-9_./-]+)/i);
        filePath = fileTarget ? fileTarget[1] : "README.md";
      } else if (/\b(?:issue|issues|ปัญหา)\b/i.test(content)) {
        action = "list_issues";
      } else {
        action = "get_repo";
      }
    }

    if (owner && repo) {
      const input: Record<string, unknown> = { owner, repo };
      if (action === "get_file") {
        input.path = filePath || "README.md";
      } else if (action === "list_issues") {
        input.state = issueState;
        input.perPage = perPage;
      }

      const hubResult = await connectorHub.invoke("github", action, input, {
        permission: "read",
        timeoutMs: 12_000,
      });

      let replyContent = "";
      if (hubResult.status === "SUCCESS") {
        if (action === "get_repo") {
          const d = hubResult.data as any;
          replyContent = [
            `### 📦 GitHub Repository: [${d.fullName}](${d.htmlUrl || `https://github.com/${owner}/${repo}`}) [VERIFIED]`,
            `- **คำอธิบาย**: ${d.description || "ไม่มีคำอธิบาย"}`,
            `- **⭐ Stars**: ${d.stars?.toLocaleString() ?? 0} | **🍴 Forks**: ${d.forks?.toLocaleString() ?? 0} | **❗ Open Issues**: ${d.openIssues?.toLocaleString() ?? 0}`,
            `- **ภาษาหลัก**: ${d.language || "ไม่ระบุ"} | **Default Branch**: \`${d.defaultBranch || "main"}\``,
            `- **การเข้าถึง**: ${d.private ? "Private" : "Public Repository"}`,
            `- **ตรวจสอบเมื่อ**: \`${d.fetchedAt}\` (เวลาตอบสนอง: ${hubResult.durationMs}ms)`,
            "",
            `*ข้อมูลจริงจาก GitHub REST API (https://api.github.com/repos/${owner}/${repo})*`
          ].join("\n");
        } else if (action === "get_file") {
          const d = hubResult.data as any;
          const ext = d.path.split(".").pop()?.toLowerCase() || "";
          const langTag = ext === "json" ? "json" : ext === "ts" || ext === "tsx" || ext === "js" ? "typescript" : ext === "md" ? "markdown" : "";
          replyContent = [
            `### 📄 ไฟล์จาก GitHub: \`${owner}/${repo}/${d.path}\` [VERIFIED]`,
            `- **SHA**: \`${d.sha}\` | **ขนาด**: ${d.size} ไบต์ | **Ref**: \`${d.ref}\``,
            `- **URL**: [เปิดดูบน GitHub](${d.htmlUrl || `https://github.com/${owner}/${repo}/blob/${d.ref}/${d.path}`})`,
            `- **ตรวจสอบเมื่อ**: \`${d.fetchedAt}\`${d.truncated ? " *(แสดงเนื้อหาบางส่วน)*" : ""}`,
            "",
            "```" + langTag + "\n" +
            (d.content || "(ไฟล์ว่าง)").slice(0, 10000) +
            "\n```"
          ].join("\n");
        } else if (action === "list_issues") {
          const d = hubResult.data as any;
          const issuesList = (d.issues || []).map((iss: any) =>
            `- [#${iss.number}](${iss.htmlUrl}) **${iss.title}** (ผู้สร้าง: \`@${iss.user || "unknown"}\`, สถานะ: \`${iss.state}\`)`
          ).join("\n");

          replyContent = [
            `### 📋 รายการ Issues ใน [${owner}/${repo}](https://github.com/${owner}/${repo}/issues) [VERIFIED]`,
            `- **สถานะ**: \`${d.state}\` | **จำนวน**: ${d.count} รายการ`,
            `- **ตรวจสอบเมื่อ**: \`${d.fetchedAt}\``,
            "",
            issuesList || "- ไม่พบ Issues ในคลังโค้ดนี้",
            "",
            `*คัดกรองเฉพาะ Issues จริง ไม่รวม Pull Requests*`
          ].join("\n");
        }
      } else {
        replyContent = [
          `### ❌ การเรียกใช้ GitHub Connector ล้มเหลว [FAILED]`,
          `- **การกระทำ (Action)**: \`${action}\``,
          `- **คลังโค้ด**: \`${owner}/${repo}\``,
          `- **ข้อผิดพลาด**: ${hubResult.message}`,
          `- **สถานะ**: \`${hubResult.status}\`${hubResult.reason ? ` (${hubResult.reason})` : ""}`,
          "",
          `*โปรดตรวจสอบว่าชื่อคลังโค้ดถูกต้องและเป็น Public Repository*`
        ].join("\n");
      }

      const assistantMsg: Message = {
        id: randomUUID(),
        role: "assistant",
        content: replyContent,
        createdAt: new Date().toISOString()
      };
      await saveMessage(id, assistantMsg);
      return response.json({
        status: hubResult.status === "SUCCESS" ? "completed" : "failed",
        tool: `github.${action}`,
        result: hubResult,
        userMessage: user,
        assistantMessage: assistantMsg
      });
    }
  }

  const reasoningCommandMatch = content.match(/^\/(?:reason|brain|orchestrate)\b/i);
  if (reasoningCommandMatch || effectiveMode === "reason") {
    const rawGoal = content.replace(/^\/(?:reason|brain|orchestrate)\s*/i, "").trim() || content;
    const reasoningResult = await executeReasoningWorkflow({
      prompt: rawGoal,
      mode: effectiveMode === "reason" ? "plan" : effectiveMode,
      conversationId: id,
    });

    const replyParts: string[] = [];
    if (attachmentSummary) replyParts.push(attachmentSummary);
    replyParts.push(reasoningResult.explanation.detailTh);

    const assistant: Message = {
      id: randomUUID(),
      role: "assistant",
      content: replyParts.join("\n\n"),
      createdAt: new Date().toISOString()
    };
    await saveMessage(id, assistant);

    return response.json({
      status: "reasoning_completed",
      mode: "reason",
      reasoning: reasoningResult,
      explanation: reasoningResult.explanation,
      attachments: processedAttachments,
      userMessage: user,
      assistantMessage: assistant
    });
  }

  if (effectiveMode === "code") {
    const fileDetails = extractFileDetailsFromMessage(content);
    if (fileDetails) {
      try {
        const proposal = await createFileProposal({
          type: "write",
          name: fileDetails.name,
          content: fileDetails.content
        });
        await requestProposalApproval(proposal.id);

        const replyParts: string[] = [];
        if (attachmentSummary) replyParts.push(attachmentSummary);
        replyParts.push(
          `สร้างข้อเสนอการเปลี่ยนแปลงไฟล์ (File Change Proposal) สำหรับ "${proposal.name}" เรียบร้อยแล้ว (สถานะ: รอการอนุมัติก่อนเขียนไฟล์)\n\n` +
          `- รหัสข้อเสนอ: ${proposal.id}\n` +
          `- ประเภท: ${proposal.type}\n` +
          `- ระดับความเสี่ยง: ${proposal.riskLevel}\n` +
          `- Hash: ${proposal.hash}\n\n` +
          `\`\`\`diff\n${proposal.diff}\n\`\`\``
        );
        const assistant: Message = {
          id: randomUUID(),
          role: "assistant",
          content: replyParts.join("\n\n"),
          createdAt: new Date().toISOString()
        };
        await saveMessage(id, assistant);
        return response.json({
          status: "proposal_created",
          mode: "code",
          proposal: {
            id: proposal.id,
            name: proposal.name,
            path: proposal.path,
            type: proposal.type,
            riskLevel: proposal.riskLevel,
            status: proposal.status,
            hash: proposal.hash,
            diff: proposal.diff
          },
          attachments: processedAttachments,
          userMessage: user,
          assistantMessage: assistant
        });
      } catch (err) {
        if (err instanceof WorkspaceFileError) {
          return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message, userMessage: user });
        }
        throw err;
      }
    }
  }

  if ((effectiveMode === "code" || effectiveMode === "auto" || effectiveMode === "plan") && isAppBuilderRequest(content)) {
    try {
      let appName = "Zyntheor App";
      const nameMatch = content.match(/(?:ชื่อ|name)\s*["':]?\s*([a-zA-Z0-9\s_-]+)/i);
      if (nameMatch && nameMatch[1]) {
        appName = nameMatch[1].trim();
      } else {
        const appTitleMatch = content.match(/สร้างแอป\s*(?:จัดการ)?\s*([^\n,.]+)/i);
        if (appTitleMatch && appTitleMatch[1]) {
          appName = appTitleMatch[1].trim();
        }
      }

      const activeProvider = getActiveProviderAdapter();
      if (!activeProvider.isConfigured()) {
        const providerStatus = await activeProvider.generateText("", "");
        return response.status(503).json({
          status: "unavailable",
          code: providerStatus.status === "unavailable" ? providerStatus.code : "provider_not_configured",
          message: providerStatus.status === "unavailable" ? providerStatus.message : "No configured AI provider is available.",
          userMessage: user
        });
      }
      if (!activeProvider.generateAppProjectProposal) {
        return response.status(503).json({ status: "unavailable", code: "provider_feature_unavailable", message: `${activeProvider.name} does not implement App Builder project generation.`, userMessage: user });
      }

      let files: Array<{ name: string; content: string; type?: "write" | "edit" }> = [];
      let isAiGenerated = false;

      const wsFiles = await listWorkspaceFiles();
      const existingFiles = await Promise.all(
        wsFiles.map(async (f) => ({ name: f.name, content: (await readWorkspaceFile(f.name))?.content || "" }))
      );
      const contextHistory = await loadMessages(id);
      const context = contextHistory.slice(0, -1).map(({ role, content: msg }) => ({ role, content: msg }));
      const aiResult = await generateAppProjectProposal(content, existingFiles, context);
      if (aiResult.status === "blocked") {
        return response.status(503).json({ status: "unavailable", code: aiResult.code, message: aiResult.message, userMessage: user });
      }
      files = aiResult.files;
      if (files.length === 0) return response.status(503).json({ status: "unavailable", code: "empty_app_proposal", message: "The selected AI provider returned no application files.", userMessage: user });
      isAiGenerated = true;

      // 3. Automated Verification (Syntax check and Manifest validation)
      const verificationIssues: string[] = [];
      const checkedFiles: string[] = [];
      let manifestChecked: any = null;

      for (const file of files) {
        if (file.name.endsWith(".js") && !file.name.includes("node_modules")) {
          checkedFiles.push(file.name);
          const syntaxCheck = await checkJavaScriptSyntax(file.content, true);
          if (!syntaxCheck.valid) {
            verificationIssues.push(`Syntax error in ${file.name}: ${syntaxCheck.error}`);
          }
        }
        if (file.name === "app.json") {
          try {
            const parsedManifest = JSON.parse(file.content);
            const val = await validateAppManifest(parsedManifest, files.map((f) => f.name));
            manifestChecked = val;
            if (!val.valid) {
              verificationIssues.push(...val.errors);
            }
          } catch (e: any) {
            verificationIssues.push(`Invalid JSON manifest: ${e.message}`);
          }
        }
      }

      const verificationSummary = {
        syntaxValid: verificationIssues.filter((i) => i.includes("Syntax error")).length === 0,
        manifestValid: manifestChecked ? manifestChecked.valid : true,
        checkedFiles,
        issues: verificationIssues,
        isAiGenerated
      };

      const createdProposals = [];
      for (const file of files) {
        const prop = await createFileProposal({
          type: (file.type as "write" | "edit" | "delete") || "write",
          name: file.name,
          content: file.content
        });
        await requestProposalApproval(prop.id);
        createdProposals.push(prop);
      }

      const replyParts: string[] = [];
      if (attachmentSummary) replyParts.push(attachmentSummary);
      replyParts.push(
        `สร้างข้อเสนอโครงสร้างโปรเจกต์แอปพลิเคชัน (${appName}) เรียบร้อยแล้ว (สถานะ: รอการอนุมัติก่อนเขียนไฟล์ลง workspace):\n\n` +
        `**ผลการตรวจยืนยันอัตโนมัติ (Automated Verification Evidence):**\n` +
        `- การตรวจสอบไวยากรณ์ JavaScript: ${verificationSummary.syntaxValid ? "✓ ผ่านทุกไฟล์ (" + checkedFiles.length + " ไฟล์)" : "✗ พบข้อผิดพลาด"}\n` +
        `- การตรวจสอบโครงสร้าง Manifest (app.json): ${verificationSummary.manifestValid ? "✓ ผ่าน (ไม่มีเส้นทางซ้ำ, คอมโพเนนต์ครบถ้วน)" : "✗ พบข้อผิดพลาด"}\n` +
        `- รูปแบบโปรเจกต์: ${isAiGenerated ? "AI Generated Project" : "Smart Domain Architecture"}\n\n` +
        `**รายการไฟล์ที่เสนอสร้าง/แก้ไข:**\n` +
        createdProposals.map((p) => `- **${p.name}** (${p.type}, ความเสี่ยง: ${p.riskLevel}, รหัสข้อเสนอ: \`${p.id}\`)`).join("\n") +
        `\n\n\`\`\`diff\n${createdProposals.map((p) => `# File: ${p.name}\n${p.diff}`).join("\n\n")}\n\`\`\``
      );
      const assistant: Message = {
        id: randomUUID(),
        role: "assistant",
        content: replyParts.join("\n\n"),
        createdAt: new Date().toISOString()
      };
      await saveMessage(id, assistant);
      return response.json({
        status: "proposal_created",
        mode: effectiveMode,
        appTemplate: true,
        appName,
        verification: verificationSummary,
        proposals: createdProposals.map((p) => ({
          id: p.id,
          name: p.name,
          path: p.path,
          type: p.type,
          riskLevel: p.riskLevel,
          status: p.status,
          hash: p.hash,
          diff: p.diff,
          impactList: p.impactList
        })),
        proposal: createdProposals[0],
        attachments: processedAttachments,
        userMessage: user,
        assistantMessage: assistant
      });
    } catch (err) {
      if (err instanceof WorkspaceFileError) {
        return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message, userMessage: user });
      }
      throw err;
    }
  }

  if ((effectiveMode === "code" || effectiveMode === "auto" || effectiveMode === "plan") && isWebsiteBuilderRequest(content)) {
    const activeProvider = getActiveProviderAdapter();
    if (!activeProvider.isConfigured()) {
      const providerStatus = await activeProvider.generateText("", "");
      return response.status(503).json({
        status: "unavailable",
        code: providerStatus.status === "unavailable" ? providerStatus.code : "provider_not_configured",
        message: providerStatus.status === "unavailable" ? providerStatus.message : "No configured AI provider is available.",
        userMessage: user
      });
    }
    if (!activeProvider.generateWebsiteProposal) {
      return response.status(503).json({ status: "unavailable", code: "provider_feature_unavailable", message: `${activeProvider.name} does not implement Website Builder proposals.`, userMessage: user });
    }

    try {
      const wsFiles = await listWorkspaceFiles();
      const existingFiles = await Promise.all(
        wsFiles.map(async (f) => ({ name: f.name, content: (await readWorkspaceFile(f.name))?.content || "" }))
      );
      const contextHistory = await loadMessages(id);
      const context = contextHistory.slice(0, -1).map(({ role, content: msg }) => ({ role, content: msg }));
      const webResult = await generateWebsiteProposal(content, existingFiles, context);

      if (webResult.status === "blocked") {
        return response.status(503).json({
          status: "unavailable",
          code: webResult.code,
          message: webResult.message,
          userMessage: user
        });
      }

      const createdProposals = [];
      for (const file of webResult.files) {
        const prop = await createFileProposal({
          type: file.type || "write",
          name: file.name,
          content: file.content
        });
        await requestProposalApproval(prop.id);
        createdProposals.push(prop);
      }

      const replyParts: string[] = [];
      if (attachmentSummary) replyParts.push(attachmentSummary);
      replyParts.push(
        `สร้างข้อเสนอการเปลี่ยนแปลงไฟล์สำหรับเว็บไซต์ (Website File Proposals) เรียบร้อยแล้ว (สถานะ: รอการอนุมัติก่อนเขียนไฟล์ลง workspace):\n\n` +
        createdProposals.map((p) => `- **${p.name}** (${p.type}, ความเสี่ยง: ${p.riskLevel}, รหัสข้อเสนอ: \`${p.id}\`, Hash: \`${p.hash.slice(0, 16)}...\`)`).join("\n") +
        `\n\n\`\`\`diff\n${createdProposals.map((p) => `# File: ${p.name}\n${p.diff}`).join("\n\n")}\n\`\`\``
      );
      const assistant: Message = {
        id: randomUUID(),
        role: "assistant",
        content: replyParts.join("\n\n"),
        createdAt: new Date().toISOString()
      };
      await saveMessage(id, assistant);
      return response.json({
        status: "proposal_created",
        mode: effectiveMode,
        proposals: createdProposals.map((p) => ({
          id: p.id,
          name: p.name,
          path: p.path,
          type: p.type,
          riskLevel: p.riskLevel,
          status: p.status,
          hash: p.hash,
          diff: p.diff
        })),
        proposal: createdProposals[0] ? {
          id: createdProposals[0].id,
          name: createdProposals[0].name,
          path: createdProposals[0].path,
          type: createdProposals[0].type,
          riskLevel: createdProposals[0].riskLevel,
          status: createdProposals[0].status,
          hash: createdProposals[0].hash,
          diff: createdProposals[0].diff
        } : undefined,
        attachments: processedAttachments,
        userMessage: user,
        assistantMessage: assistant
      });
    } catch (err) {
      if (err instanceof WorkspaceFileError) {
        return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message, userMessage: user });
      }
      throw err;
    }
  }

  let goal = effectiveMode === "qa" ? undefined : requestedPlanGoal(content);
  if (effectiveMode === "plan" && goal === undefined) {
    goal = content.startsWith("/") ? content.replace(/^\/[a-zA-Z0-9_-]+\s*/, "").trim() : content;
    if (!goal) goal = "Execute requested workflow";
  }

  if (goal !== undefined) {
    if (!goal || goal.length > 1000) {
      return response.status(400).json({ status: "blocked", code: "invalid_plan_goal", message: "Plan goal must be 1 to 1000 characters." });
    }
    try {
      let plan: Plan;
      if (isTimeGoal(goal)) {
        plan = await createPlan(createTimePlanDraft(goal), "system");
      } else {
        const contextHistory = await loadMessages(id);
        const context = contextHistory.slice(0, -1).map(({ role, content: message }) => ({ role, content: message }));
        const proposal = await generatePlanProposal(goal, listTools(), context);
        if (proposal.status !== "completed") {
          return response.status(503).json({
            status: "unavailable",
            code: proposal.code,
            message: `Planning is UNAVAILABLE: ${proposal.message} No plan was created and no execution was started.`,
            userMessage: user
          });
        }
        let parsed: unknown;
        try {
          parsed = JSON.parse(proposal.text);
        } catch {
          return response.status(502).json({
            status: "unavailable",
            code: "invalid_planner_output",
            message: "Planner output was not valid JSON. No plan was created and no execution was started.",
            userMessage: user
          });
        }
        const validated = validatePlannerOutput(parsed);
        if (Array.isArray(validated.steps) && validated.steps.length === 0) {
          return response.status(422).json({
            status: "unavailable",
            code: "planner_no_available_tools",
            message: "No registered available tools can safely fulfill this goal. No plan was created and no execution was started.",
            userMessage: user
          });
        }
        plan = await createPlan(validated, "ai");
      }
      let assistantSummaryText = `${plan.source === "ai" ? "AI-proposed" : "System-generated"} plan ${plan.id} proposed. Request approval before any execution; nothing has been executed.`;
      if (attachmentSummary) {
        assistantSummaryText = `${attachmentSummary}\n\n${assistantSummaryText}`;
      }
      const assistant: Message = {
        id: randomUUID(),
        role: "assistant",
        content: assistantSummaryText,
        createdAt: new Date().toISOString()
      };
      try {
        await saveMessage(id, assistant);
      } catch {
        return response.status(503).json({
          status: "partial",
          code: "conversation_storage_unavailable",
          message: "The plan was persisted but its chat summary could not be saved.",
          plan: presentPlan(plan)
        });
      }
      return response.status(201).json({
        status: "plan_proposed",
        plan: presentPlan(plan),
        attachments: processedAttachments,
        userMessage: user,
        assistantMessage: assistant
      });
    } catch (error) {
      return respondAgentError(response, error);
    }
  }

  let history: Message[];
  try {
    history = await loadMessages(id);
  } catch {
    return response.status(503).json({ status: "unavailable", code: "storage_unavailable" });
  }
  let memoryContext: Array<{ statement: string; source: string }>;
  try {
    memoryContext = (await retrieveContextFacts(id, content, { limit: 5 }))
      .map(({ fact }) => ({ statement: fact.statement, source: fact.source }));
  } catch {
    return response.status(503).json({ status: "unavailable", code: "context_memory_unavailable" });
  }
  const answer = await generateReply(
    history.slice(-40).map(({ role, content: message }) => ({ role, content: message })),
    memoryContext,
  );
  if (answer.status !== "completed") return response.status(503).json({ ...answer, intent, userMessage: user });
  let finalReply = redactSecrets(answer.text);
  if (attachmentSummary) {
    finalReply = `${attachmentSummary}\n\n${finalReply}`;
  }
  const assistant: Message = {
    id: randomUUID(),
    role: "assistant",
    content: finalReply,
    createdAt: new Date().toISOString()
  };
  try {
    await saveMessage(id, assistant);
  } catch {
    return response.status(503).json({ status: "partial", code: "assistant_storage_failed", userMessage: user });
  }
  return response.json({
    status: "completed",
    intent,
    mode: effectiveMode,
    model: answer.model,
    attachments: processedAttachments,
    userMessage: user,
    assistantMessage: assistant
  });
}));

app.get("/api/plans", asyncRoute(async (_request, response) =>
  response.json({ plans: (await listPlans()).map(presentPlan) })
));
app.post("/api/plans", asyncRoute(async (request, response) => {
  if (!isPlanDraft(request.body)) {
    throw new AgentError("invalid_plan", "Plan body contains unsupported fields.", 400);
  }
  const plan = await createPlan(request.body);
  return response.status(201).json({ plan: presentPlan(plan) });
}));
app.get("/api/plans/:id", asyncRoute(async (request, response) =>
  response.json({ plan: presentPlan(await getPlan(planId(request))) })
));
app.patch("/api/plans/:id", asyncRoute(async (request, response) => {
  if (!isPlanDraft(request.body)) {
    throw new AgentError("invalid_plan", "Plan body contains unsupported fields.", 400);
  }
  const plan = await revisePlan(planId(request), request.body);
  return response.json({ plan: presentPlan(plan) });
}));
app.post("/api/plans/:id/request-approval", asyncRoute(async (request, response) => {
  if (!isEmptyBody(request.body)) throw new AgentError("invalid_plan", "Approval request must not include a body.", 400);
  const plan = await requestPlanApproval(planId(request));
  return response.json({ plan: presentPlan(plan) });
}));
app.post("/api/plans/:id/approve", asyncRoute(async (request, response) => {
  if (!hasExactKeys(request.body, ["planHash"]) || typeof request.body.planHash !== "string") {
    throw new AgentError("invalid_plan", "Approval body must contain only a string planHash.", 400);
  }
  const plan = await approvePlan(planId(request), request.body?.planHash);
  return response.json({ plan });
}));
app.post("/api/plans/:id/reject", asyncRoute(async (request, response) => {
  if (!isEmptyBody(request.body)) throw new AgentError("invalid_plan", "Rejection request must not include a body.", 400);
  await recordPlanRejection(planId(request));
  return response.json({ plan: presentPlan(await getPlan(planId(request))) });
}));
app.post("/api/plans/:id/execute", asyncRoute(async (request, response) => {
  if (!hasExactKeys(request.body, ["approvalId"]) || typeof request.body.approvalId !== "string") {
    throw new AgentError("approval_required", "Execution body must contain only an approvalId.", 400);
  }
  const plan = await executePlan(planId(request), request.body?.approvalId);
  return response.json({ plan: presentPlan(plan) });
}));

app.get("/api/tools", (_request, response) => response.json({ tools: listTools() }));

app.get("/api/engine/connectors", asyncRoute(async (_request, response) => {
  declareDefaultConnectors();
  const result = await handleListConnectors();
  response.status(result.status).json({ ...result.body, providers: listAvailableProviders() });
}));
app.post("/api/engine/connectors/github", asyncRoute(async (request, response) => {
  const { action, input } = request.body || {};
  if (!action || typeof action !== "string" || !input || typeof input !== "object" || Array.isArray(input)) {
    return response.status(400).json({
      status: "blocked",
      code: "invalid_connector_request",
      message: "action string and input object are required",
    });
  }
  const result = await connectorHub.invoke("github", action, input, {
    permission: "read",
    timeoutMs: 12_000,
  });
  const statusCode = result.status === "SUCCESS" ? 200 : result.status === "DENIED" ? 403 : 400;
  return response.status(statusCode).json(result);
}));
app.get("/api/engine/lessons", asyncRoute(async (_request, response) => {
  const result = await handleListLessons();
  response.status(result.status).json(result.body);
}));
app.get("/api/engine/memory-insight", asyncRoute(async (request, response) => {
  // Read-only: lessons (learningLoop), workspace facts (contextEngine) and retention policy (memoryRetention).
  const id = String(request.query.workspaceId || "");
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(id)) return response.status(400).json({ status: "blocked", code: "invalid_workspace_id" });
  try {
    const [lessons, memory, policy] = await Promise.all([listLessons(), loadWorkspaceMemory(id), getMemoryRetentionPolicy(id)]);
    return response.json({ workspaceId: id, lessons, facts: memory.facts, policy });
  } catch {
    return response.status(503).json({ status: "unavailable", code: "memory_unavailable" });
  }
}));
app.post("/api/engine/route", asyncRoute(async (request, response) => {
  const result = await handleRoute(request.body);
  response.status(result.status).json(result.body);
}));
app.get("/api/audit", asyncRoute(async (_request, response) => response.json({ events: await listAuditEvents() })));
app.get("/api/research", (_request, response) => response.json(researchUnavailable()));
app.post("/api/research", asyncRoute(async (request, response) => {
  if (!hasExactKeys(request.body, ["query", "depth"]) || typeof request.body.query !== "string" ||
    !request.body.query.trim() || request.body.query.trim().length > 1000 ||
    (request.body.depth !== undefined && request.body.depth !== "FAST" && request.body.depth !== "DEEP")) {
    return response.status(400).json({ status: "blocked", code: "invalid_research_request" });
  }
  const depth: "FAST" | "DEEP" = request.body.depth === "DEEP" ? "DEEP" : "FAST";
  const result = await researchAgent({ query: request.body.query.trim(), depth });
  const completed = result.status === "SUCCESS" && result.analysisStatus === "COMPLETED";
  return response.status(completed ? 200 : 503).json(result);
}));
app.get("/api/memory/:conversationId/retention", asyncRoute(async (request, response) => {
  const id = String(request.params.conversationId || "");
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(id)) return response.status(400).json({ status: "blocked", code: "invalid_workspace_id" });
  return response.json({ policy: await getMemoryRetentionPolicy(id) });
}));
app.put("/api/memory/:conversationId/retention", asyncRoute(async (request, response) => {
  const id = String(request.params.conversationId || "");
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(id)) return response.status(400).json({ status: "blocked", code: "invalid_workspace_id" });
  if (!hasExactKeys(request.body, ["persistentMemoryDays", "preserveVerifiedFacts"]) ||
      !(request.body.persistentMemoryDays === null || (typeof request.body.persistentMemoryDays === "number" && Number.isInteger(request.body.persistentMemoryDays) && request.body.persistentMemoryDays >= 1 && request.body.persistentMemoryDays <= 3650)) ||
      typeof request.body.preserveVerifiedFacts !== "boolean") {
    return response.status(400).json({ status: "blocked", code: "invalid_retention_policy" });
  }
  return response.json({ policy: await setMemoryRetentionPolicy(id, request.body as { persistentMemoryDays: number | null; preserveVerifiedFacts: boolean }) });
}));
app.post("/api/memory/:conversationId/retention/enforce", asyncRoute(async (request, response) => {
  const id = String(request.params.conversationId || "");
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(id)) return response.status(400).json({ status: "blocked", code: "invalid_workspace_id" });
  if (!isEmptyBody(request.body)) return response.status(400).json({ status: "blocked", code: "unexpected_body" });
  return response.json({ status: "completed", result: await enforceMemoryRetention(id) });
}));

app.get("/api/memory/:conversationId", asyncRoute(async (request, response) => {
  const id = String(request.params.conversationId || "");
  if (!/^[a-zA-Z0-9_-]{1,100}$/.test(id)) return response.status(400).json({ error: "invalid_conversation_id" });
  try {
    return response.json({ conversationId: id, messages: await loadMessages(id) });
  } catch {
    return response.status(503).json({ status: "unavailable", code: "storage_unavailable" });
  }
}));

app.post("/api/tools/execute", (_request, response) =>
  response.status(403).json({ status: "blocked", reason: "plan_scoped_approval_required" })
);

// File Access & Inspection Endpoints
const rawFileParser = express.raw({ type: "*/*", limit: "4mb" });

app.post("/api/files/inspect", rawFileParser, (request, response) => {
  const filename = typeof request.query.name === "string" ? request.query.name.trim() : "";
  if (!filename || filename.length > 255) {
    return response.status(400).json({ status: "blocked", code: "invalid_filename", message: "Filename must be 1 to 255 characters." });
  }
  const buffer = Buffer.isBuffer(request.body) ? request.body : Buffer.from(request.body || "");
  const mimeType = request.get("content-type") || "application/octet-stream";
  const result = inspectFile(filename, buffer, mimeType);
  return response.json(result);
});

app.post("/api/files/inspect-zip", rawFileParser, (request, response) => {
  const buffer = Buffer.isBuffer(request.body) ? request.body : Buffer.from(request.body || "");
  if (!buffer || buffer.length === 0) {
    return response.status(400).json({ status: "blocked", code: "empty_zip", message: "ZIP archive buffer is empty." });
  }
  const result = inspectZipBuffer(buffer);
  if (result.status === "BLOCKED") {
    return response.status(400).json(result);
  }
  if (result.status === "ERROR") {
    return response.status(422).json(result);
  }
  return response.json(result);
});

app.post("/api/files/write", asyncRoute(async (request, response) => {
  const body = request.body as unknown;
  if (!body || typeof body !== "object" || typeof (body as any)?.name !== "string" || typeof (body as any)?.content !== "string") {
    return response.status(400).json({ status: "blocked", code: "invalid_file_write_request", message: "File write requires name and content strings." });
  }
  const mode = typeof (body as any)?.mode === "string" ? String((body as any).mode).trim() : "code";
  if (mode === "review") {
    return response.status(403).json({
      status: "blocked",
      code: "file_modification_forbidden_in_review_mode",
      message: "โหมดตรวจสอบ (Review) ไม่อนุญาตให้สร้างหรือแก้ไขไฟล์ บังคับห้ามที่เซิร์ฟเวอร์"
    });
  }
  if (mode === "qa") {
    return response.status(403).json({
      status: "blocked",
      code: "forbidden_in_qa_mode",
      message: "โหมดถามตอบ (Q&A) ไม่อนุญาตให้สร้างหรือแก้ไขไฟล์"
    });
  }

  // Requirement 3: Direct writing without approved proposal is strictly prohibited!
  const approvalId = typeof (body as any)?.approvalId === "string" ? (body as any).approvalId : "";
  const proposalId = typeof (body as any)?.proposalId === "string" ? (body as any).proposalId : "";
  if (!approvalId || !proposalId) {
    return response.status(403).json({
      status: "blocked",
      code: "approval_required",
      message: "Direct file writing is prohibited. Create a File Change Proposal and obtain approval before applying changes."
    });
  }

  try {
    const result = await applyProposal(proposalId, approvalId);
    return response.status(201).json({ status: "file_written", file: result.file, checkpoint: result.checkpoint });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.get("/api/workspace/files", asyncRoute(async (_request, response) => {
  const files = await listWorkspaceFiles();
  return response.json({ status: "available", files });
}));

app.get("/api/workspace/tree", asyncRoute(async (_request, response) => {
  const tree = await getWorkspaceTree();
  return response.json({ status: "available", tree });
}));

app.get("/api/proposals", asyncRoute(async (_request, response) => {
  const proposals = await listProposals();
  return response.json({ status: "available", proposals });
}));

app.post("/api/proposals", asyncRoute(async (request, response) => {
  const body = request.body as any;
  if (!body || typeof body.name !== "string") {
    return response.status(400).json({ status: "blocked", code: "invalid_proposal_request", message: "Proposal requires file name." });
  }
  try {
    const proposal = await createFileProposal({
      type: body.type,
      name: body.name,
      content: typeof body.content === "string" ? body.content : undefined
    });
    await requestProposalApproval(proposal.id);
    return response.status(201).json({ status: "proposal_created", proposal });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.get("/api/proposals/:id", asyncRoute(async (request, response) => {
  const id = String(request.params.id);
  const proposal = await getProposal(id);
  if (!proposal) {
    return response.status(404).json({ status: "unavailable", code: "proposal_not_found", message: `Proposal "${id}" not found.` });
  }
  return response.json({ status: "available", proposal });
}));

app.post("/api/proposals/:id/request-approval", asyncRoute(async (request, response) => {
  try {
    const id = String(request.params.id);
    const proposal = await requestProposalApproval(id);
    return response.json({ status: "approval_requested", proposal });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.post("/api/proposals/:id/approve", asyncRoute(async (request, response) => {
  const hash = typeof (request.body as any)?.hash === "string" ? (request.body as any).hash : "";
  if (!hash) {
    return response.status(400).json({ status: "blocked", code: "missing_proposal_hash", message: "Approval requires current proposal hash." });
  }
  try {
    const id = String(request.params.id);
    const proposal = await approveProposal(id, hash);
    return response.json({ status: "proposal_approved", proposal });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.post("/api/proposals/:id/apply", asyncRoute(async (request, response) => {
  const approvalId = typeof (request.body as any)?.approvalId === "string" ? (request.body as any).approvalId : "";
  if (!approvalId) {
    return response.status(400).json({ status: "blocked", code: "missing_approval_id", message: "Applying changes requires valid approval ID." });
  }
  try {
    const id = String(request.params.id);
    const result = await applyProposal(id, approvalId);
    return response.json({
      status: "proposal_applied",
      proposal: result.proposal,
      checkpoint: result.checkpoint,
      file: result.file
    });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.post("/api/proposals/:id/reject", asyncRoute(async (request, response) => {
  try {
    const id = String(request.params.id);
    const proposal = await rejectProposal(id);
    return response.json({ status: "proposal_rejected", proposal });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.get("/api/checkpoints", asyncRoute(async (_request, response) => {
  const checkpoints = await listCheckpoints();
  return response.json({ status: "available", checkpoints });
}));

app.post("/api/checkpoints", asyncRoute(async (request, response) => {
  const description = typeof (request.body as any)?.description === "string" ? (request.body as any).description : "Manual snapshot";
  const checkpoint = await createCheckpoint(description);
  return response.status(201).json({ status: "checkpoint_created", checkpoint });
}));

app.get("/api/checkpoints/:id", asyncRoute(async (request, response) => {
  const id = String(request.params.id);
  const checkpoint = await getCheckpoint(id);
  if (!checkpoint) {
    return response.status(404).json({ status: "unavailable", code: "checkpoint_not_found", message: `Checkpoint "${id}" not found.` });
  }
  return response.json({ status: "available", checkpoint });
}));

app.post("/api/checkpoints/:id/restore", asyncRoute(async (request, response) => {
  try {
    const id = String(request.params.id);
    const result = await restoreCheckpoint(id);
    return response.json({ status: "checkpoint_restored", ...result });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.get("/api/files/:filename", asyncRoute(async (request, response) => {
  const filename = String(request.params.filename || "").trim();
  const file = await readWorkspaceFile(filename);
  if (!file) {
    return response.status(404).json({ status: "blocked", code: "file_not_found", message: `File "${filename}" not found in workspace.` });
  }
  return response.json({ status: "available", file });
}));

app.get("/api/preview/bundle", asyncRoute(async (request, response) => {
  try {
    const entry = typeof request.query.entry === "string" ? request.query.entry : undefined;
    const route = typeof request.query.route === "string" ? request.query.route : undefined;
    const bundle = await generatePreviewBundle(entry, route);
    return response.json({ status: "available", ...bundle });
  } catch (err) {
    if (err instanceof WorkspaceFileError) {
      return response.status(err.statusCode).json({ status: "blocked", code: err.code, message: err.message });
    }
    throw err;
  }
}));

app.get("/api/preview/validate", asyncRoute(async (_request, response) => {
  const validation = await validateWebsiteWorkspace();
  const manifestRecord = await readWorkspaceFile("app.json");
  let manifestValidation: any = undefined;
  if (manifestRecord) {
    manifestValidation = await validateAppManifest();
  }
  return response.json({ status: "available", validation, manifestValidation });
}));

app.get("/api/app/manifest", asyncRoute(async (_request, response) => {
  const manifestValidation = await validateAppManifest();
  return response.json({ status: "available", ...manifestValidation });
}));

app.post("/api/app/validate-manifest-schema", asyncRoute(async (request, response) => {
  const body = request.body as any;
  const input = body?.content !== undefined ? body.content : (body?.manifest !== undefined ? body.manifest : body);
  if (input === undefined || input === null || (typeof input === "object" && Object.keys(input).length === 0)) {
    // If empty body passed, check workspace app.json
    const manifestValidation = await validateAppManifest();
    return response.json({ status: "available", ...manifestValidation });
  }
  const result = validateAppManifestSchema(input);
  return response.json({ status: "available", ...result });
}));

app.post("/api/app/check-syntax", asyncRoute(async (request, response) => {
  const body = request.body as any;
  const path = typeof body?.path === "string" ? body.path.trim() : undefined;
  const code = typeof body?.code === "string" ? body.code : undefined;
  if (!path && code === undefined) {
    return response.status(400).json({ status: "blocked", code: "missing_code_or_path", message: "Path or code must be provided." });
  }
  let result;
  if (code !== undefined) {
    result = await checkJavaScriptSyntax(code, true);
  } else if (path) {
    const cleanPath = validateWorkspaceRelativePath(path);
    const fullPath = join(getWorkspaceDir(), cleanPath);
    result = await checkJavaScriptSyntax(fullPath, false);
  } else {
    return response.status(400).json({ status: "blocked", code: "invalid_syntax_request" });
  }
  return response.json({ status: "available", ...result });
}));

app.post("/api/app/template", asyncRoute(async (request, response) => {
  const body = request.body as any;
  const appName = typeof body?.name === "string" ? body.name.trim() : "Zyntheor App";
  const files = createStandardAppTemplate(appName);
  const createdProposals = [];
  for (const f of files) {
    const prop = await createFileProposal({
      name: f.name,
      content: f.content,
      type: "write"
    });
    await requestProposalApproval(prop.id);
    createdProposals.push(prop);
  }
  return response.status(201).json({
    status: "proposal_created",
    message: `สร้างข้อเสนอสำหรับโครงสร้างแอปมาตรฐาน (${appName}) ทั้งหมด ${createdProposals.length} ไฟล์แล้ว (รอการอนุมัติก่อนเขียน)`,
    proposals: createdProposals
  });
}));

app.get("/api/sandbox/status", asyncRoute(async (_request, response) => {
  const netIso = await testNetworkIsolationCapability();
  return response.json({
    status: "available",
    sandbox: {
      childProcessIsolation: true,
      tempDirIsolation: true,
      cleanEnv: true,
      resourceLimits: { timeoutMs: 10000, maxOutputBytes: 65536 },
      networkIsolated: netIso,
      networkIsolationMethod: netIso ? "linux_unshare_net" : "none",
      dependenciesInstallation: "BLOCKED_BY_DEFAULT",
      allowedTasks: ["syntax_check", "typecheck", "test", "build", "install_deps"]
    }
  });
}));

app.post("/api/sandbox/run", asyncRoute(async (request, response) => {
  const body = request.body as any;
  const mode = typeof body?.mode === "string" ? body.mode.trim() : "code";
  if (mode === "review" && (body?.taskType === "install_deps" || body?.taskType === "write")) {
    return response.status(403).json({
      status: "blocked",
      code: "forbidden_in_review_mode",
      message: "โหมดตรวจสอบ (Review) ไม่อนุญาตให้รันคำสั่งที่แก้ไขระบบหรือติดตั้ง dependency"
    });
  }

  const taskType = body?.taskType as SandboxTaskType;
  const ALLOWED_TASKS = ["syntax_check", "typecheck", "test", "build", "install_deps"];
  if (!taskType || !ALLOWED_TASKS.includes(taskType)) {
    return response.status(400).json({
      status: "blocked",
      code: "invalid_task_type",
      message: `Task type "${taskType}" is not allowlisted. Allowed tasks: ${ALLOWED_TASKS.join(", ")}`
    });
  }

  const targetPath = typeof body?.targetPath === "string" ? body.targetPath.trim() : undefined;
  const timeoutMs = typeof body?.timeoutMs === "number" ? Math.min(body.timeoutMs, 30000) : 10000;

  const result = await executeSandboxTask(taskType, targetPath, timeoutMs);
  return response.json(result);
}));

app.get("/api/workspace/download-zip", asyncRoute(async (_request, response) => {
  const zipBuffer = await createApprovedWorkspaceZip();
  response.setHeader("Content-Type", "application/zip");
  response.setHeader("Content-Disposition", 'attachment; filename="zyntheor-approved-project.zip"');
  response.setHeader("Content-Length", zipBuffer.length);
  return response.send(zipBuffer);
}));

app.post("/api/agent/repair-cycle", asyncRoute(async (request, response) => {
  const sessionId = typeof request.body?.sessionId === "string" ? request.body.sessionId : "default";
  const { count, allowed } = incrementRepairCycle(sessionId);
  if (!allowed) {
    return response.status(429).json({
      status: "blocked",
      code: "max_repair_cycles_exceeded",
      cycle: count,
      message: "วงจร 'แก้ → ทดสอบ → แก้' เกินขีดจำกัดสูงสุด 3 รอบต่อคำสั่ง กรุณาหยุดและรายงานผล"
    });
  }
  return response.json({ status: "available", cycle: count, maxCycles: 3 });
}));

app.use("/api", (_request, response) =>
  response.status(404).json({ status: "unavailable", code: "api_route_not_found" })
);

function respondAgentError(response: Response, error: unknown) {
  if (error instanceof AgentError) {
    const status = error.code === "storage_unavailable" ? "unavailable" : "blocked";
    return response.status(error.statusCode).json({ status, code: error.code, message: error.message });
  }
  if (error instanceof WorkspaceFileError) {
    return response.status(error.statusCode).json({ status: "blocked", code: error.code, message: error.message });
  }
  return response.status(503).json({ status: "unavailable", code: "storage_unavailable" });
}

app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
  if (error instanceof AgentError || error instanceof WorkspaceFileError) return respondAgentError(response, error);
  const parserError = error && typeof error === "object" && "type" in error
    ? (error as { type?: unknown }).type
    : undefined;
  if (parserError === "entity.parse.failed") {
    return response.status(400).json({ status: "blocked", code: "malformed_json" });
  }
  if (parserError === "entity.too.large") {
    return response.status(413).json({ status: "blocked", code: "request_body_too_large" });
  }
  return response.status(500).json({ status: "unavailable", code: "internal_error" });
});

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  declareDefaultConnectors();
  const port = Number(process.env.PORT || 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    console.error("PORT must be an integer between 1 and 65535.");
    process.exitCode = 1;
  } else {
    app.listen(port, "127.0.0.1", () => console.log(`apphub-ai-agent listening at http://127.0.0.1:${port}`));
  }
}
