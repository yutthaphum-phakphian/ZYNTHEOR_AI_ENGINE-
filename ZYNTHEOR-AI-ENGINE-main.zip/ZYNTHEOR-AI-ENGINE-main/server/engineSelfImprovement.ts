import { spawn } from "node:child_process";
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
import { access, cp, lstat, mkdir, open, readFile, readdir, readlink, rename, rm, writeFile } from "node:fs/promises";
import { createServer as createNetServer } from "node:net";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express, { type NextFunction, type Request, type Response } from "express";
import { generateUnifiedDiff, isBlockedFilename, validateWorkspaceRelativePath } from "./files.js";
import { getActiveProviderAdapter, type AIProviderAdapter } from "./provider.js";
import { redactSecrets, saveAgentEvent } from "./store.js";

const ENGINE_ROOT = path.resolve(fileURLToPath(new URL("../", import.meta.url)));
const CHECKS = [
  { name: "typecheck", args: ["run", "typecheck"], timeoutMs: 120_000 },
  { name: "build", args: ["run", "build"], timeoutMs: 180_000 },
  { name: "test:unit", args: ["run", "test:unit"], timeoutMs: 240_000 },
  { name: "test:integration", args: ["run", "test:integration"], timeoutMs: 180_000 },
] as const;
const MAX_FILES = 1500;
const MAX_SOURCE_BYTES = 100 * 1024 * 1024;
const MAX_CONTEXT_BYTES = 48 * 1024;
const MAX_PATCH_FILES = 8;
const MAX_PATCH_BYTES = 64 * 1024;
const MAX_OUTPUT_BYTES = 48 * 1024;
const MAX_PROPOSAL_AGE_MS = 30 * 60 * 1000;
const PATCHABLE_EXTENSIONS = new Set([".ts", ".tsx"]);
const BLOCKED_PARTS = /^(?:tests?|specs?|node_modules|git|sovereign|kernel|core|hsm|treasury|forensic)/i;
const BLOCKED_MANIFESTS = new Set([
  "package.json", "package-lock.json", "npm-shrinkwrap.json",
  "bun.lock", "bun.lockb", "pnpm-lock.yaml", "yarn.lock",
  "deno.json", "deno.jsonc", "tsconfig.json",
  "cargo.toml", "cargo.lock", "go.mod", "go.sum",
  "composer.json", "composer.lock", "gemfile", "gemfile.lock",
  "pyproject.toml", "poetry.lock", "requirements.txt", "pipfile", "pipfile.lock",
]);

type CheckEvidence = {
  name: string;
  status: "VERIFIED" | "FAIL" | "NOT_VERIFIED";
  command: string[];
  exitCode: number;
  durationMs: number;
  stdout: string;
  stderr: string;
  networkIsolated: boolean;
  sandboxIsolationEvidenceHash: string;
  truncated: boolean;
  outputHash: string;
  sourceHash?: string;
  workspaceUnchanged?: boolean;
  testCount?: number;
  passCount?: number;
  failCount?: number;
};

type EnginePatchFile = {
  name: string;
  content: string;
  reason: string;
  diff: string;
  originalHash: string;
  proposedHash: string;
};

type EnginePatchProposal = {
  id: string;
  hash: string;
  status: "WAITING_APPROVAL" | "APPROVED" | "APPLIED" | "ROLLED_BACK" | "ROLLBACK_FAILED" | "PARTIAL_ROLLBACK" | "APPLY_FAILED" | "PARTIAL_APPLY" | "STALE";
  createdAt: string;
  sourceBaselineHash: string;
  unmodifiedSourceHash: string;
  sourceAppliedHash?: string;
  analysis: string;
  provider: string;
  aiGenerated: boolean;
  approvalIdentity?: string;
  sandboxIsolation: SandboxIsolationEvidence;
  checkpointEvidenceHash?: string;
  baseline: CheckEvidence[];
  candidate: CheckEvidence[];
  files: EnginePatchFile[];
  approvalId?: string;
  approvedAt?: string;
  approvalUsedAt?: string;
};

function isProtectedEnginePart(part: string): boolean {
  return BLOCKED_PARTS.test(part.replace(/[^a-z0-9]/gi, ""));
}

function sha256(content: string | Buffer): string {
  return createHash("sha256").update(content).digest("hex");
}

async function hashSourceTree(root: string, excludedFiles: ReadonlySet<string> = new Set()): Promise<string> {
  const hash = createHash("sha256");
  const ignoredDirectories = new Set(["node_modules", "dist", "coverage", ".data", ".codesight", ".vite", "build"]);
  async function walk(directory: string, prefix = ""): Promise<void> {
    const entries = await readdir(directory, { withFileTypes: true });
    entries.sort((left, right) => left.name.localeCompare(right.name));
    for (const entry of entries) {
      if (entry.isSymbolicLink()) throw new Error(`Engine source snapshot contains a symbolic link: ${prefix}${entry.name}`);
      const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) {
        if (!ignoredDirectories.has(entry.name)) await walk(path.join(directory, entry.name), relative);
      } else if (
        entry.isFile() &&
        entry.name !== ".env" &&
        !(entry.name.startsWith(".env.") && entry.name !== ".env.example") &&
        entry.name !== ".npmrc"
      ) {
        if (!excludedFiles.has(relative)) {
          hash.update(relative).update("\0").update(await readFile(path.join(directory, entry.name))).update("\0");
        }
      }
    }
  }
  await walk(root);
  return hash.digest("hex");
}

async function assertNoSymlinkPath(target: string, sourceRoot = ENGINE_ROOT): Promise<void> {
  const relative = path.relative(sourceRoot, target);
  if (!relative || relative.startsWith("..") || path.isAbsolute(relative)) {
    throw new Error("Engine path is outside the source root.");
  }
  let current = sourceRoot;
  for (const segment of relative.split(path.sep)) {
    current = path.join(current, segment);
    let stats;
    try {
      stats = await lstat(current);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
      throw error;
    }
    if (stats.isSymbolicLink()) throw new Error(`Engine path contains a symbolic link: ${path.relative(sourceRoot, current)}`);
  }
}

async function acquireApplyLock(sourceRoot: string): Promise<() => Promise<void>> {
  const dataRoot = path.join(sourceRoot, ".data");
  await assertNoSymlinkPath(dataRoot, sourceRoot);
  await mkdir(dataRoot, { recursive: true });
  await assertNoSymlinkPath(dataRoot, sourceRoot);
  const lockPath = path.join(dataRoot, "engine-patch-apply.lock");
  const lock = await open(lockPath, "wx", 0o600);
  return async () => {
    await lock.close();
    await rm(lockPath);
  };
}

type SandboxIsolationEvidence = {
  verified: boolean;
  networkIsolated: boolean;
  sourceWorkspaceHidden: boolean;
  sourceWriteBlocked: boolean;
  privilegeSeparated: boolean;
  sandboxUid: number | null;
  probeExitCode: number;
  evidenceHash: string;
  error?: string;
};

function getSandboxRuntime(): { nodePath: string; runtimeRoot: string; npmCliPath: string; uid: number } {
  const runtimeRoot = path.resolve(path.dirname(process.execPath), "..");
  const nodePath = "/runtime/node/bin/node";
  const npmCliPath = "/runtime/node/lib/node_modules/npm/bin/npm-cli.js";
  const hostUid = typeof process.getuid === "function" ? process.getuid() : 1000;
  const uid = hostUid === 65534 ? 65533 : 65534;
  return {
    nodePath,
    runtimeRoot,
    npmCliPath,
    uid,
  };
}

function resolveBubblewrapExecution(rawArgs: string[]): { command: string; args: string[] } {
  const hasUnshareAll = rawArgs.includes("--unshare-all");
  if (!hasUnshareAll) {
    return { command: "/usr/bin/bwrap", args: rawArgs };
  }
  return {
    command: "/usr/bin/bwrap",
    args: rawArgs,
  };
}

async function verifySandboxIsolation(sourceRoot: string): Promise<SandboxIsolationEvidence> {
  const runtime = getSandboxRuntime();
  const result: Omit<SandboxIsolationEvidence, "evidenceHash"> = {
    verified: false,
    networkIsolated: false,
    sourceWorkspaceHidden: false,
    sourceWriteBlocked: false,
    privilegeSeparated: false,
    sandboxUid: null,
    probeExitCode: 127,
  };
  let listener: ReturnType<typeof createNetServer> | undefined;
  try {
    await access("/usr/bin/bwrap");
    await access(runtime.runtimeRoot);
    await access(path.join(runtime.runtimeRoot, "lib/node_modules/npm/bin/npm-cli.js"));
    listener = createNetServer();
    await new Promise<void>((resolve, reject) => {
      listener!.once("error", reject);
      listener!.listen(0, "127.0.0.1", resolve);
    });
    const address = listener.address();
    if (!address || typeof address === "string") throw new Error("Sandbox isolation probe could not bind a host loopback port.");
    const sourceRoots = [...new Set([ENGINE_ROOT, sourceRoot])];
    const hiddenPaths = sourceRoots;
    const writePaths = sourceRoots.map((root) => path.join(root, `.sandbox-write-probe-${randomUUID()}`));
    const script = [
      "const fs=require('node:fs'),net=require('node:net');",
      "const hiddenPaths=JSON.parse(process.argv[1]),writePaths=JSON.parse(process.argv[2]),port=Number(process.argv[3]);",
      "const sourceWorkspaceHidden=hiddenPaths.every((item)=>!fs.existsSync(item));",
      "const sourceWriteBlocked=writePaths.every((item)=>{try{fs.writeFileSync(item,'probe',{flag:'wx'});fs.unlinkSync(item);return false}catch{return true}});",
      "const socket=net.connect({host:'127.0.0.1',port});",
      "const finish=(networkIsolated)=>{socket.destroy();console.log(JSON.stringify({sourceWorkspaceHidden,sourceWriteBlocked,networkIsolated,sandboxUid:process.getuid()}));};",
      "socket.setTimeout(1000,()=>finish(true));",
      "socket.once('connect',()=>finish(false));",
      "socket.once('error',()=>finish(true));",
    ].join("");
    const args = [
      "--unshare-all",
      "--die-with-parent",
      "--tmpfs", "/",
      "--ro-bind", "/usr", "/usr",
      "--symlink", "usr/bin", "/bin",
      "--dir", "/runtime",
      "--ro-bind", runtime.runtimeRoot, "/runtime/node",
      "--ro-bind", "/lib", "/lib",
      "--ro-bind", "/lib64", "/lib64",
      "--proc", "/proc",
      "--dev", "/dev",
      "--tmpfs", "/tmp",
      "--dir", "/home",
      "--dir", "/workspaces",
      "--uid", String(runtime.uid),
      "--gid", String(runtime.uid),
      "--clearenv",
      "--setenv", "PATH", "/runtime/node/bin:/usr/bin:/bin",
      "--setenv", "HOME", "/tmp",
      "--",
      runtime.nodePath,
      "-e",
      script,
      JSON.stringify(hiddenPaths),
      JSON.stringify(writePaths),
      String(address.port),
    ];

    const output = await new Promise<{ code: number; stdout: string; stderr: string }>((resolve, reject) => {
      const execution = resolveBubblewrapExecution(args);
      const child = spawn(execution.command, execution.args, { env: { PATH: "/usr/local/bin:/usr/bin:/bin" }, stdio: ["ignore", "pipe", "pipe"] });
      let stdout = "";
      let stderr = "";
      const timer = setTimeout(() => child.kill("SIGKILL"), 5000);
      child.stdout?.on("data", (chunk: Buffer) => { stdout += chunk.toString("utf8"); });
      child.stderr?.on("data", (chunk: Buffer) => { stderr += chunk.toString("utf8"); });
      child.once("error", (error) => {
        clearTimeout(timer);
        reject(error);
      });
      child.once("close", (code) => {
        clearTimeout(timer);
        resolve({ code: code ?? 1, stdout, stderr });
      });
    });
    result.probeExitCode = output.code;
    if (output.code !== 0) throw new Error(`Bubblewrap isolation probe failed: ${redactSecrets(output.stderr).trim() || `exit ${output.code}`}`);
    const measured = JSON.parse(output.stdout.trim()) as {
      sourceWorkspaceHidden?: boolean;
      sourceWriteBlocked?: boolean;
      networkIsolated?: boolean;
      sandboxUid?: number;
    };
    result.sourceWorkspaceHidden = measured.sourceWorkspaceHidden === true;
    result.sourceWriteBlocked = measured.sourceWriteBlocked === true;
    result.networkIsolated = measured.networkIsolated === true;
    result.sandboxUid = typeof measured.sandboxUid === "number" ? measured.sandboxUid : null;
    result.privilegeSeparated = result.sandboxUid === runtime.uid &&
      (typeof process.getuid !== "function" || result.sandboxUid !== process.getuid());
    result.verified = result.networkIsolated &&
      result.sourceWorkspaceHidden &&
      result.sourceWriteBlocked &&
      result.privilegeSeparated;
    if (!result.verified) throw new Error("Bubblewrap isolation probe did not verify every required boundary.");
  } catch (error) {
    result.error = redactSecrets(error instanceof Error ? error.message : String(error));
  } finally {
    if (listener) await new Promise<void>((resolve) => listener!.close(() => resolve()));
  }
  return {
    ...result,
    evidenceHash: sha256(JSON.stringify(result)),
  };
}

function parseTestCounts(output: string): { testCount: number; passCount: number; failCount: number } | null {
  const values = [...output.matchAll(/(?:ℹ\s*|#\s*)(tests|pass|fail)\s+(\d+)/g)];
  const counts = new Map(values.map((match) => [match[1], Number(match[2])]));
  const testCount = counts.get("tests");
  const passCount = counts.get("pass");
  const failCount = counts.get("fail");
  if (testCount === undefined || passCount === undefined || failCount === undefined || testCount <= 0) return null;
  return { testCount, passCount, failCount };
}

function boundedAppend(current: string, chunk: Buffer): { value: string; truncated: boolean } {
  const remaining = Math.max(0, MAX_OUTPUT_BYTES - Buffer.byteLength(current, "utf8"));
  if (chunk.length <= remaining) return { value: current + chunk.toString("utf8"), truncated: false };
  return {
    value: current + chunk.toString("utf8", 0, remaining),
    truncated: true,
  };
}

async function runInBubblewrap(
  workspace: string,
  dependencies: string,
  name: string,
  args: readonly string[],
  timeoutMs: number,
  isolation: SandboxIsolationEvidence,
): Promise<CheckEvidence> {
  if (!isolation.verified) throw new Error("Sandbox isolation has not been verified.");
  const runtime = getSandboxRuntime();
  await access("/usr/bin/bwrap");
  await access(dependencies);
  await mkdir(path.join(dependencies, ".vite-temp"), { recursive: true });
  await mkdir(path.join(workspace, "node_modules"), { recursive: true });
  for (const outputDirectory of ["dist", ".data", "coverage", ".vite"]) {
    await mkdir(path.join(workspace, outputDirectory), { recursive: true });
  }

  const bindArgs = [
    "--unshare-all",
    "--die-with-parent",
    "--tmpfs", "/",
    "--ro-bind", "/usr", "/usr",
    "--symlink", "usr/bin", "/bin",
    "--dir", "/runtime",
    "--ro-bind", runtime.runtimeRoot, "/runtime/node",
    "--ro-bind", "/lib", "/lib",
    "--ro-bind", "/lib64", "/lib64",
    "--dev", "/dev",
    "--proc", "/proc",
    "--tmpfs", "/tmp",
    "--chmod", "1777", "/tmp",
    "--tmpfs", "/home",
    "--dir", "/workspaces",
    "--dir", "/tmp/workspace",
    "--ro-bind", workspace, "/tmp/workspace",
    "--ro-bind", dependencies, "/tmp/workspace/node_modules",
    "--tmpfs", "/tmp/workspace/node_modules/.vite-temp",
    "--chmod", "0777", "/tmp/workspace/node_modules/.vite-temp",
    "--tmpfs", "/tmp/workspace/dist",
    "--chmod", "0777", "/tmp/workspace/dist",
    "--tmpfs", "/tmp/workspace/.data",
    "--chmod", "0777", "/tmp/workspace/.data",
    "--tmpfs", "/tmp/workspace/coverage",
    "--chmod", "0777", "/tmp/workspace/coverage",
    "--tmpfs", "/tmp/workspace/.vite",
    "--chmod", "0777", "/tmp/workspace/.vite",
    "--dir", "/tmp/test-workspace",
    "--tmpfs", "/tmp/test-workspace",
    "--chmod", "0777", "/tmp/test-workspace",
    "--uid", String(runtime.uid),
    "--gid", String(runtime.uid),
    "--clearenv",
    "--setenv", "PATH", "/runtime/node/bin:/tmp/workspace/node_modules/.bin:/usr/bin:/bin",
    "--setenv", "HOME", "/tmp",
    "--setenv", "TMPDIR", "/tmp",
    "--setenv", "XDG_CONFIG_HOME", "/tmp/.config",
    "--setenv", "NODE_ENV", "test",
    "--setenv", "CI", "true",
    "--setenv", "AI_PROVIDER", "none",
    "--setenv", "OPENAI_API_KEY", "",
    "--setenv", "ANTHROPIC_API_KEY", "",
    "--setenv", "WORKSPACE_FILES_DIR", "/tmp/test-workspace",
    "--setenv", "CHAT_STORE_PATH", "/tmp/test-workspace/audit.jsonl",
    "--setenv", "NPM_CONFIG_GLOBALCONFIG", "/dev/null",
    "--setenv", "NPM_CONFIG_USERCONFIG", "/tmp/npm-user-config",
    "--setenv", "NPM_CONFIG_UPDATE_NOTIFIER", "false",
    "--setenv", "NPM_CONFIG_AUDIT", "false",
    "--setenv", "NPM_CONFIG_CACHE", "/tmp/npm-cache",
    "--setenv", "GIT_CONFIG_GLOBAL", "/dev/null",
    "--setenv", "GIT_CONFIG_SYSTEM", "/dev/null",
  ];
  const sandboxMarker = "__ZYNTHEOR_SANDBOX_STARTED__";
  const launcher = [
    "const{spawnSync}=require('node:child_process');",
    `process.stdout.write('${sandboxMarker}');`,
    "const result=spawnSync(process.execPath,[process.argv[1],...process.argv.slice(2)],{stdio:'inherit',env:process.env});",
    "if(result.error){console.error(result.error.message);process.exit(127)}",
    "process.exit(result.status===null?1:result.status);",
  ].join("");
  const commandArgs = [
    ...bindArgs,
    "--chdir", "/tmp/workspace",
    runtime.nodePath, "-e", launcher, runtime.npmCliPath, ...args,
  ];
  const startedAt = Date.now();

  return await new Promise<CheckEvidence>((resolve) => {
    let stdout = "";
    let stderr = "";
    let truncated = false;
    let timedOut = false;
    const execution = resolveBubblewrapExecution(commandArgs);
    const child = spawn(execution.command, execution.args, {
      env: { PATH: process.env.PATH || "/usr/local/bin:/usr/bin:/bin" },
      stdio: ["ignore", "pipe", "pipe"],
    });
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, timeoutMs);

    child.stdout?.on("data", (chunk: Buffer) => {
      const result = boundedAppend(stdout, chunk);
      stdout = result.value;
      truncated ||= result.truncated;
    });
    child.stderr?.on("data", (chunk: Buffer) => {
      const result = boundedAppend(stderr, chunk);
      stderr = result.value;
      truncated ||= result.truncated;
    });
    child.on("error", (error) => {
      clearTimeout(timer);
      const visibleStdout = redactSecrets(stdout);
      const visibleStderr = redactSecrets(`${stderr}\nSandbox process error: ${error.message}`);
      resolve({
        name,
        status: "NOT_VERIFIED",
        command: ["bwrap", runtime.nodePath, runtime.npmCliPath, ...args],
        exitCode: 127,
        durationMs: Date.now() - startedAt,
        stdout: visibleStdout,
        stderr: visibleStderr,
        networkIsolated: false,
        sandboxIsolationEvidenceHash: isolation.evidenceHash,
        truncated,
        outputHash: sha256(`${visibleStdout}\0${visibleStderr}`),
      });
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      const sandboxStarted = stdout.startsWith(sandboxMarker);
      const commandStdout = sandboxStarted ? stdout.slice(sandboxMarker.length) : stdout;
      const exitCode = timedOut ? 124 : (code ?? 1);
      const testCounts = name.startsWith("test:") ? parseTestCounts(`${commandStdout}\n${stderr}`) : undefined;
      const status = !sandboxStarted
        ? "NOT_VERIFIED"
        : exitCode !== 0
        ? "FAIL"
        : name.startsWith("test:") && (!testCounts || testCounts.failCount !== 0)
          ? "NOT_VERIFIED"
          : "VERIFIED";
      const visibleStdout = redactSecrets(commandStdout);
      const visibleStderr = redactSecrets(timedOut ? `${stderr}\nTimed out after ${timeoutMs}ms.` : stderr);
      resolve({
        name,
        status,
        command: ["bwrap", runtime.nodePath, runtime.npmCliPath, ...args],
        exitCode,
        durationMs: Date.now() - startedAt,
        stdout: visibleStdout,
        stderr: visibleStderr,
        networkIsolated: sandboxStarted,
        sandboxIsolationEvidenceHash: isolation.evidenceHash,
        truncated,
        outputHash: sha256(`${visibleStdout}\0${visibleStderr}`),
        ...(testCounts || {}),
      });
    });
  });
}

async function copyEngineSource(destination: string, sourceRoot = ENGINE_ROOT): Promise<void> {
  let fileCount = 0;
  let totalBytes = 0;
  await mkdir(destination, { recursive: true });

  async function copyDirectory(sourceDir: string, relativeDir = ""): Promise<void> {
    const entries = await readdir(sourceDir, { withFileTypes: true });
    for (const entry of entries) {
      const relativePath = relativeDir ? `${relativeDir}/${entry.name}` : entry.name;
      const parts = relativePath.split("/");
      if (
        parts.some((part) => part === "node_modules" || part === ".git" || part === ".data" || part === ".codesight" || part === "dist") ||
        entry.name === ".env" || (entry.name.startsWith(".env.") && entry.name !== ".env.example") ||
        entry.name === ".npmrc"
      ) continue;
      if (entry.isSymbolicLink()) {
        throw new Error(`Engine source snapshot contains a symbolic link: ${relativePath}`);
      }
      const sourcePath = path.join(sourceDir, entry.name);
      const targetPath = path.join(destination, relativePath);
      if (entry.isDirectory()) {
        await mkdir(targetPath, { recursive: true });
        await copyDirectory(sourcePath, relativePath);
      } else if (entry.isFile()) {
        fileCount++;
        if (fileCount > MAX_FILES) throw new Error("Engine source snapshot exceeded the file-count limit.");
        const sourceStats = await lstat(sourcePath);
        totalBytes += sourceStats.size;
        if (totalBytes > MAX_SOURCE_BYTES) throw new Error("Engine source snapshot exceeded the size limit.");
        await mkdir(path.dirname(targetPath), { recursive: true });
        await writeFile(targetPath, await readFile(sourcePath), { mode: sourceStats.mode & 0o777 });
      }
    }
  }

  await copyDirectory(sourceRoot);
}

async function copyDependencies(destination: string, sourceRoot = ENGINE_ROOT): Promise<void> {
  const source = path.join(sourceRoot, "node_modules");
  let entriesChecked = 0;

  async function validateLinks(directory: string): Promise<void> {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const absolute = path.join(directory, entry.name);
      entriesChecked++;
      if (entriesChecked > 100_000) throw new Error("Dependency tree exceeded the symlink-validation limit.");
      if (entry.isSymbolicLink()) {
        const link = await readlink(absolute);
        const resolved = path.resolve(path.dirname(absolute), link);
        if (!resolved.startsWith(`${source}${path.sep}`)) {
          throw new Error(`Dependency tree contains an external symbolic link: ${path.relative(source, absolute)}`);
        }
      } else if (entry.isDirectory()) {
        await validateLinks(absolute);
      }
    }
  }

  await validateLinks(source);
  await cp(source, destination, { recursive: true, verbatimSymlinks: true });
}

async function runSuite(
  workspace: string,
  dependencies: string,
  isolation: SandboxIsolationEvidence,
): Promise<CheckEvidence[]> {
  const sourceHash = await hashSourceTree(workspace);
  const evidence: CheckEvidence[] = [];
  for (const check of CHECKS) {
    evidence.push(await runInBubblewrap(workspace, dependencies, check.name, check.args, check.timeoutMs, isolation));
  }
  const workspaceUnchanged = sourceHash === await hashSourceTree(workspace);
  return evidence.map((result) => ({
    ...result,
    status: result.status === "VERIFIED" && !workspaceUnchanged ? "NOT_VERIFIED" : result.status,
    sourceHash,
    workspaceUnchanged,
  }));
}

function suitePassed(evidence: CheckEvidence[]): boolean {
  return evidence.length === CHECKS.length &&
    evidence.every((result) => result.status === "VERIFIED" && result.networkIsolated);
}

function isAllowedEnginePatch(name: string): boolean {
  let cleanName: string;
  try {
    cleanName = validateWorkspaceRelativePath(name);
  } catch {
    return false;
  }
  const parts = cleanName.split("/");
  const filename = parts.at(-1)?.toLowerCase() || "";
  const extension = path.extname(filename);
  return cleanName === name &&
    !parts.some(isProtectedEnginePart) &&
    !name.includes("\\") &&
    !BLOCKED_MANIFESTS.has(filename) &&
    !filename.endsWith(".lock") &&
    !/\.(?:test|spec)\.tsx?$/i.test(filename) &&
    PATCHABLE_EXTENSIONS.has(extension) &&
    !isBlockedFilename(filename);
}

function parsePatchOutput(text: string): { analysis: string; patches: Array<{ name: string; content: string; reason: string }> } | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, ""));
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
  const result = parsed as Record<string, unknown>;
  if (
    Object.keys(result).some((key) => key !== "analysis" && key !== "patches") ||
    typeof result.analysis !== "string" || !result.analysis.trim() || result.analysis.length > 4000 ||
    !Array.isArray(result.patches) || result.patches.length === 0 || result.patches.length > MAX_PATCH_FILES
  ) return null;

  const patches: Array<{ name: string; content: string; reason: string }> = [];
  const names = new Set<string>();
  for (const value of result.patches) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const patch = value as Record<string, unknown>;
    if (
      Object.keys(patch).some((key) => !["name", "content", "reason"].includes(key)) ||
      typeof patch.name !== "string" ||
      typeof patch.content !== "string" ||
      typeof patch.reason !== "string" || !patch.reason.trim() || patch.reason.length > 1000 ||
      Buffer.byteLength(patch.content, "utf8") > MAX_PATCH_BYTES ||
      !isAllowedEnginePatch(patch.name) ||
      names.has(patch.name)
    ) return null;
    names.add(patch.name);
    patches.push({ name: patch.name, content: patch.content, reason: patch.reason.trim() });
  }
  return { analysis: result.analysis.trim(), patches };
}

async function readEngineFiles(sourceRoot = ENGINE_ROOT): Promise<Array<{ name: string; content: string }>> {
  const files: Array<{ name: string; content: string }> = [];
  async function walk(directory: string, prefix = ""): Promise<void> {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      if (entry.isSymbolicLink()) continue;
      const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      const parts = relative.split("/");
      if (
        parts.some((part) => part === "node_modules" || part === ".git" || part === ".data" || part === ".codesight" || part === "dist") ||
        entry.name === ".env" || (entry.name.startsWith(".env.") && entry.name !== ".env.example") ||
        entry.name === ".npmrc"
      ) continue;
      const absolute = path.join(directory, entry.name);
      if (entry.isDirectory()) await walk(absolute, relative);
      else if (entry.isFile() && PATCHABLE_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) {
        files.push({ name: relative, content: await readFile(absolute, "utf8") });
      }
    }
  }
  await walk(sourceRoot);
  return files;
}

function selectSourceContext(
  files: Array<{ name: string; content: string }>,
  priorityText = "",
): { text: string; files: string[] } {
  let remaining = MAX_CONTEXT_BYTES;
  const result: string[] = [];
  const selectedFiles: string[] = [];
  const eligible = files.filter((file) => isAllowedEnginePatch(file.name));
  eligible.sort((left, right) => Number(priorityText.includes(right.name)) - Number(priorityText.includes(left.name)));
  for (const file of eligible) {
    const section = `--- ${file.name} ---\n${redactSecrets(file.content)}`;
    const size = Buffer.byteLength(section, "utf8");
    if (size > remaining) continue;
    result.push(section);
    selectedFiles.push(file.name);
    remaining -= size;
  }
  return { text: result.join("\n\n"), files: selectedFiles };
}

type EngineSelfImprovementContext = {
  sourceRoot: string;
  provider?: Pick<AIProviderAdapter, "isConfigured" | "generateText">;
  proposals: Map<string, EnginePatchProposal>;
  activeRun: boolean;
  activeApply: Set<string>;
};

async function runEngineImprovement(
  request: Request,
  response: Response,
  context: EngineSelfImprovementContext,
): Promise<void> {
  if (context.activeRun) {
    response.status(409).json({ status: "blocked", code: "engine_improvement_already_running" });
    return;
  }
  const body = request.body;
  if (
    !body || typeof body !== "object" || Array.isArray(body) ||
    Object.keys(body).some((key) => key !== "allowExternalCodeSharing") ||
    body.allowExternalCodeSharing !== undefined && typeof body.allowExternalCodeSharing !== "boolean"
  ) {
    response.status(400).json({ status: "blocked", code: "invalid_engine_improvement_request" });
    return;
  }

  context.activeRun = true;
  const provider = context.provider ?? getActiveProviderAdapter();
  if (!provider.isConfigured()) {
    const providerMessage = "No configured AI provider is available; baseline execution was not started.";
    const baseline = CHECKS.map((check) => ({
      name: check.name,
      status: "FAIL" as const,
      command: ["npm", ...check.args],
      exitCode: 1,
      durationMs: 0,
      stdout: "",
      stderr: providerMessage,
      networkIsolated: false,
      sandboxIsolationEvidenceHash: sha256(providerMessage),
      truncated: false,
      outputHash: sha256(`${check.name}:${providerMessage}`),
      workspaceUnchanged: true,
    }));
    context.activeRun = false;
    response.status(503).json({
      status: "unavailable",
      code: "provider_not_configured",
      message: providerMessage,
      baseline,
    });
    return;
  }
  const isolation = await verifySandboxIsolation(context.sourceRoot);
  if (!isolation.verified) {
    context.activeRun = false;
    response.status(503).json({
      status: "unavailable",
      code: "engine_sandbox_isolation_unverified",
      message: "No engine source was copied or executed because sandbox network, filesystem, and privilege isolation could not all be verified.",
      networkIsolated: isolation.networkIsolated,
      sandboxIsolation: isolation,
    });
    return;
  }

  const runId = randomUUID();
  const tempRoot = path.join("/tmp", `zyntheor-engine-improvement-${runId}`);
  const baselineDir = path.join(tempRoot, "baseline");
  const candidateDir = path.join(tempRoot, "candidate");
  const baselineDependencies = path.join(tempRoot, "baseline-dependencies");
  const candidateDependencies = path.join(tempRoot, "candidate-dependencies");
  try {
    const sourceBaselineHash = await hashSourceTree(context.sourceRoot);
    await copyEngineSource(baselineDir, context.sourceRoot);
    await copyEngineSource(candidateDir, context.sourceRoot);
    await copyDependencies(baselineDependencies, context.sourceRoot);
    if (
      sourceBaselineHash !== await hashSourceTree(context.sourceRoot) ||
      sourceBaselineHash !== await hashSourceTree(baselineDir) ||
      sourceBaselineHash !== await hashSourceTree(candidateDir)
    ) {
      response.status(409).json({ status: "blocked", code: "engine_source_changed_during_snapshot", sandboxIsolation: isolation });
      return;
    }
    const baseline = await runSuite(baselineDir, baselineDependencies, isolation);
    if (suitePassed(baseline)) {
      response.json({
        status: "no_failure_detected",
        sourceBaselineHash,
        baseline,
        networkIsolated: isolation.networkIsolated,
        sandboxIsolation: isolation,
        message: "Typecheck, build, unit tests, and integration tests passed in an isolated source copy; no patch was generated.",
      });
      return;
    }
    if (baseline.some((result) =>
      result.status === "NOT_VERIFIED" ||
      !result.networkIsolated ||
      result.workspaceUnchanged !== true
    )) {
      response.status(503).json({
        status: "unavailable",
        code: "engine_baseline_checks_not_verified",
        baseline,
        networkIsolated: isolation.networkIsolated,
        sandboxIsolation: isolation,
        message: "Patch generation stopped because every baseline check did not produce verified isolation and unchanged-source evidence.",
      });
      return;
    }

    const failureSummary = baseline.map((result) => ({
      name: result.name,
      status: result.status,
      exitCode: result.exitCode,
      stdout: result.stdout,
      stderr: result.stderr,
    }));
    if (body.allowExternalCodeSharing !== true) {
      response.json({
        status: "analysis_only",
        sourceBaselineHash,
        baseline,
        networkIsolated: isolation.networkIsolated,
        sandboxIsolation: isolation,
        patchStatus: "not_generated",
        reason: "Engine source is not sent to an external provider without explicit allowExternalCodeSharing consent.",
      });
      return;
    }

    const sourceFiles = await readEngineFiles(candidateDir);
    const sourceContext = selectSourceContext(sourceFiles, JSON.stringify(failureSummary));
    const providerResult = await provider.generateText(
      [
        "You are reviewing ZYNTHEOR AI ENGINE source following a real isolated check failure.",
        "Analyze the failure evidence and propose a minimal patch only to existing TypeScript source files.",
        "Do not edit tests, dependency manifests, lockfiles, Sovereign components, Core, or Kernel.",
        "Return JSON only: {\"analysis\":\"...\",\"patches\":[{\"name\":\"server/module.ts\",\"content\":\"complete replacement file\",\"reason\":\"...\"}]}",
        "The evidence is not proof of a root cause. Be explicit about uncertainty. Do not claim tests passed.",
      ].join("\n"),
      JSON.stringify({
        failureEvidence: failureSummary,
        availableSourceFiles: sourceContext.files,
        sourceContext: sourceContext.text,
      }),
    );
    if (providerResult.status !== "completed") {
      const code = (providerResult.code === "local_runtime_unavailable" && !process.env.AI_PROVIDER)
        ? "provider_not_configured"
        : providerResult.code;
      response.status(503).json({
        status: "unavailable",
        code,
        message: providerResult.message,
        baseline,
      });
      return;
    }
    if (sourceBaselineHash !== await hashSourceTree(context.sourceRoot)) {
      response.status(409).json({ status: "blocked", code: "engine_source_changed_during_analysis", sandboxIsolation: isolation });
      return;
    }
    const generated = parsePatchOutput(providerResult.text);
    if (!generated) {
      response.status(422).json({ status: "blocked", code: "invalid_engine_patch_output", baseline });
      return;
    }
    const sourceByName = new Map(sourceFiles.map((file) => [file.name, file.content]));
    if (generated.patches.some((patch) => !sourceByName.has(patch.name))) {
      response.status(422).json({ status: "blocked", code: "engine_patch_must_update_existing_source", baseline });
      return;
    }
    if (generated.patches.some((patch) => !sourceContext.files.includes(patch.name))) {
      response.status(422).json({ status: "blocked", code: "engine_patch_source_not_provided_to_provider", baseline });
      return;
    }

    const patchTargetNames = new Set(generated.patches.map((patch) => patch.name));
    const unmodifiedSourceHash = await hashSourceTree(context.sourceRoot, patchTargetNames);
    const candidateFiles: EnginePatchFile[] = [];
    for (const patch of generated.patches) {
      const original = sourceByName.get(patch.name);
      if (original === undefined) {
        response.status(422).json({ status: "blocked", code: "engine_patch_must_update_existing_source", baseline });
        return;
      }
      const candidatePath = path.join(candidateDir, patch.name);
      const parent = path.dirname(candidatePath);
      await mkdir(parent, { recursive: true });
      await writeFile(candidatePath, patch.content, "utf8");
      candidateFiles.push({
        ...patch,
        diff: generateUnifiedDiff(original, patch.content, patch.name),
        originalHash: sha256(original),
        proposedHash: sha256(patch.content),
      });
    }
    if (unmodifiedSourceHash !== await hashSourceTree(candidateDir, patchTargetNames)) {
      response.status(409).json({ status: "blocked", code: "engine_source_snapshot_mismatch", sandboxIsolation: isolation });
      return;
    }
    await copyDependencies(candidateDependencies);
    const candidate = await runSuite(candidateDir, candidateDependencies, isolation);
    if (!suitePassed(candidate)) {
      response.json({
        status: "patch_test_failed",
        analysis: generated.analysis,
        provider: providerResult.model,
        baseline,
        candidate,
        diffs: candidateFiles.map(({ name, diff, reason }) => ({ name, diff, reason })),
        proposals: [],
        networkIsolated: isolation.networkIsolated,
        sandboxIsolation: isolation,
      });
      return;
    }
    if (sourceBaselineHash !== await hashSourceTree(context.sourceRoot)) {
      response.status(409).json({ status: "blocked", code: "engine_source_changed_during_candidate_tests", sandboxIsolation: isolation });
      return;
    }

    const id = `engine-patch-${runId}`;
    const createdAt = new Date().toISOString();
    const hash = sha256(JSON.stringify({
      id,
      createdAt,
      sourceBaselineHash,
      unmodifiedSourceHash,
      aiGenerated: !context.provider,
      analysis: generated.analysis,
      provider: providerResult.model,
      sandboxIsolation: isolation,
      files: candidateFiles.map(({ name, content, reason, diff, originalHash, proposedHash }) => ({
        name, content, reason, diff, originalHash, proposedHash,
      })),
      baseline,
      candidate,
    }));
    const proposal: EnginePatchProposal = {
      id,
      hash,
      status: "WAITING_APPROVAL",
      createdAt,
      sourceBaselineHash,
      unmodifiedSourceHash,
      analysis: generated.analysis,
      provider: providerResult.model,
      aiGenerated: !context.provider,
      sandboxIsolation: isolation,
      baseline,
      candidate,
      files: candidateFiles,
    };
    context.proposals.set(id, proposal);
    const audit = await saveAgentEvent({
      id: randomUUID(),
      type: "ENGINE_PATCH_PROPOSED",
      at: createdAt,
      data: {
        proposalId: id,
        proposalHash: hash,
        sourceBaselineHash,
        unmodifiedSourceHash,
        provider: providerResult.model,
        aiGenerated: proposal.aiGenerated,
        sandboxIsolation: proposal.sandboxIsolation,
        baseline,
        candidate,
        files: candidateFiles.map(({ name, originalHash, proposedHash }) => ({ name, originalHash, proposedHash })),
        networkIsolated: isolation.networkIsolated,
        approvalRequired: true,
      },
    });
    response.json({
      status: "patch_verified_waiting_approval",
      proposal: {
        id,
        hash,
        status: proposal.status,
        createdAt,
        sourceBaselineHash,
        unmodifiedSourceHash,
        analysis: proposal.analysis,
        provider: proposal.provider,
        aiGenerated: proposal.aiGenerated,
        sandboxIsolation: proposal.sandboxIsolation,
        files: candidateFiles.map(({ name, reason, diff, originalHash, proposedHash }) => ({
          name, reason, diff, originalHash, proposedHash,
        })),
        baseline,
        candidate,
      },
      audit,
      networkIsolated: isolation.networkIsolated,
      sandboxIsolation: isolation,
      applyWith: {
        approval: "POST /api/self-improvement/engine/proposals/:id/approve",
        apply: "POST /api/self-improvement/engine/proposals/:id/apply",
      },
      note: "The patch changed only an isolated temporary source copy; engine source remains unchanged pending explicit approval and Apply.",
    });
  } finally {
    context.activeRun = false;
    await rm(tempRoot, { recursive: true, force: true });
  }
}

async function approveEnginePatch(
  request: Request,
  response: Response,
  context: EngineSelfImprovementContext,
): Promise<void> {
  const proposalId = typeof request.params.id === "string" ? request.params.id : "";
  const proposal = context.proposals.get(proposalId);
  if (!proposal) {
    response.status(404).json({ status: "unavailable", code: "engine_patch_proposal_not_found" });
    return;
  }
  if (proposal.status !== "WAITING_APPROVAL" || Date.now() - Date.parse(proposal.createdAt) > MAX_PROPOSAL_AGE_MS) {
    response.status(409).json({ status: "blocked", code: "engine_patch_not_approvable" });
    return;
  }
  if (
    !request.body || typeof request.body !== "object" ||
    Object.keys(request.body).some((key) => key !== "hash" && key !== "sourceBaselineHash") ||
    request.body.hash !== proposal.hash ||
    request.body.sourceBaselineHash !== proposal.sourceBaselineHash
  ) {
    response.status(409).json({ status: "blocked", code: "engine_patch_approval_hash_mismatch" });
    return;
  }
  if (proposal.sourceBaselineHash !== await hashSourceTree(context.sourceRoot)) {
    proposal.status = "STALE";
    response.status(409).json({ status: "blocked", code: "engine_source_changed_since_proposal" });
    return;
  }
  const approverIdentity = process.env.ENGINE_PATCH_APPROVER_ID?.trim();
  if (!approverIdentity) {
    response.status(503).json({ status: "unavailable", code: "engine_patch_approver_identity_unconfigured" });
    return;
  }
  const approvalId = randomUUID();
  const approvedAt = new Date().toISOString();
  proposal.status = "APPROVED";
  proposal.approvalId = approvalId;
  proposal.approvedAt = approvedAt;
  proposal.approvalIdentity = approverIdentity;
  try {
    await saveAgentEvent({
      id: randomUUID(),
      type: "ENGINE_PATCH_APPROVED",
      at: approvedAt,
      data: {
        proposalId: proposal.id,
        proposalHash: proposal.hash,
        sourceBaselineHash: proposal.sourceBaselineHash,
        approvalId,
        approvalIdentity: approverIdentity,
        approvalStatus: "APPROVED",
      },
    });
  } catch (error) {
    proposal.status = "WAITING_APPROVAL";
    delete proposal.approvalId;
    delete proposal.approvedAt;
    delete proposal.approvalIdentity;
    throw error;
  }
  response.json({
    status: "approved",
    proposalId: proposal.id,
    approvalId,
    hash: proposal.hash,
    sourceBaselineHash: proposal.sourceBaselineHash,
    approvalIdentity: proposal.approvalIdentity,
  });
}

async function applyEnginePatch(
  request: Request,
  response: Response,
  context: EngineSelfImprovementContext,
): Promise<void> {
  const proposalId = typeof request.params.id === "string" ? request.params.id : "";
  const proposal = context.proposals.get(proposalId);
  if (!proposal) {
    response.status(404).json({ status: "unavailable", code: "engine_patch_proposal_not_found" });
    return;
  }
  if (
    proposal.status !== "APPROVED" ||
    !proposal.approvalId ||
    proposal.approvalUsedAt ||
    Date.now() - Date.parse(proposal.createdAt) > MAX_PROPOSAL_AGE_MS
  ) {
    response.status(403).json({ status: "blocked", code: "engine_patch_approval_required" });
    return;
  }
  if (
    !request.body || typeof request.body !== "object" ||
    Object.keys(request.body).some((key) => key !== "approvalId" && key !== "hash" && key !== "sourceBaselineHash") ||
    request.body.approvalId !== proposal.approvalId ||
    request.body.hash !== proposal.hash ||
    request.body.sourceBaselineHash !== proposal.sourceBaselineHash
  ) {
    response.status(403).json({ status: "blocked", code: "engine_patch_approval_mismatch" });
    return;
  }
  if (context.activeApply.has(proposal.id)) {
    response.status(409).json({ status: "blocked", code: "engine_patch_apply_in_progress" });
    return;
  }
  context.activeApply.add(proposal.id);
  let releaseApplyLock: (() => Promise<void>) | undefined;
  try {
    releaseApplyLock = await acquireApplyLock(context.sourceRoot);
  } catch (error) {
    context.activeApply.delete(proposal.id);
    const code = (error as NodeJS.ErrnoException).code;
    response.status(code === "EEXIST" ? 409 : 503).json({
      status: "blocked",
      code: code === "EEXIST" ? "engine_patch_apply_lock_held" : "engine_patch_apply_lock_unavailable",
    });
    return;
  }
  proposal.approvalUsedAt = new Date().toISOString();

  const currentContents = new Map<string, Buffer>();
  const applied: string[] = [];
  const checkpointRoot = path.join(context.sourceRoot, ".data", "engine-patch-checkpoints", proposal.id);
  try {
    if (
      proposal.sourceBaselineHash !== await hashSourceTree(context.sourceRoot) ||
      proposal.unmodifiedSourceHash !== await hashSourceTree(
        context.sourceRoot,
        new Set(proposal.files.map((file) => file.name)),
      )
    ) {
      proposal.status = "STALE";
      response.status(409).json({ status: "blocked", code: "engine_source_changed_since_approval" });
      return;
    }
    for (const file of proposal.files) {
      if (!isAllowedEnginePatch(file.name)) {
        response.status(403).json({ status: "blocked", code: "engine_patch_path_protected" });
        return;
      }
      const target = path.resolve(context.sourceRoot, file.name);
      if (!target.startsWith(`${context.sourceRoot}${path.sep}`)) {
        response.status(403).json({ status: "blocked", code: "engine_patch_path_escape" });
        return;
      }
      await assertNoSymlinkPath(target, context.sourceRoot);
      const current = await readFile(target);
      if (sha256(current) !== file.originalHash) {
        response.status(409).json({ status: "blocked", code: "engine_source_changed_since_proposal", file: file.name });
        return;
      }
      currentContents.set(file.name, current);
    }

    await assertNoSymlinkPath(checkpointRoot, context.sourceRoot);
    await mkdir(checkpointRoot, { recursive: true });
    await assertNoSymlinkPath(checkpointRoot, context.sourceRoot);
    for (const [name, content] of currentContents) {
      const checkpoint = path.join(checkpointRoot, name);
      await assertNoSymlinkPath(checkpoint, context.sourceRoot);
      await mkdir(path.dirname(checkpoint), { recursive: true });
      await writeFile(checkpoint, content);
    }
    const checkpointEvidence = {
      proposalId: proposal.id,
      proposalHash: proposal.hash,
      approvedAt: proposal.approvedAt,
      approvalIdentity: proposal.approvalIdentity,
      approvalStatus: "APPROVED",
      approvalUsedAt: proposal.approvalUsedAt,
      sourceBaselineHash: proposal.sourceBaselineHash,
      unmodifiedSourceHash: proposal.unmodifiedSourceHash,
      checkpointCreatedAt: new Date().toISOString(),
      patchStatus: "APPLY_REQUESTED",
      baseline: proposal.baseline,
      candidate: proposal.candidate,
      sandboxIsolation: proposal.sandboxIsolation,
    };
    const checkpointEvidenceText = JSON.stringify(checkpointEvidence, null, 2);
    await writeFile(path.join(checkpointRoot, "evidence.json"), checkpointEvidenceText);
    const audit = await saveAgentEvent({
      id: randomUUID(),
      type: "ENGINE_PATCH_APPLY_REQUESTED",
      at: new Date().toISOString(),
      data: {
        proposalId: proposal.id,
        proposalHash: proposal.hash,
        sourceBaselineHash: proposal.sourceBaselineHash,
        unmodifiedSourceHash: proposal.unmodifiedSourceHash,
        approvalId: proposal.approvalId,
        approvalIdentity: proposal.approvalIdentity,
        checkpoint: path.relative(context.sourceRoot, checkpointRoot),
      },
    });

    if (
      proposal.sourceBaselineHash !== await hashSourceTree(context.sourceRoot) ||
      proposal.unmodifiedSourceHash !== await hashSourceTree(
        context.sourceRoot,
        new Set(proposal.files.map((file) => file.name)),
      )
    ) {
      proposal.status = "STALE";
      response.status(409).json({ status: "blocked", code: "engine_source_changed_before_apply" });
      return;
    }
    for (const file of proposal.files) {
      const target = path.resolve(context.sourceRoot, file.name);
      const parent = path.dirname(target);
      const tempFile = path.join(parent, `.${path.basename(target)}.${randomUUID()}.tmp`);
      const oldStats = await lstat(target);
      if (!oldStats.isFile() || oldStats.isSymbolicLink()) throw new Error(`Patch target is not a regular file: ${file.name}`);
      await assertNoSymlinkPath(target, context.sourceRoot);
      if (sha256(await readFile(target)) !== file.originalHash) {
        throw new Error(`Patch target changed immediately before replacement: ${file.name}`);
      }
      try {
        await writeFile(tempFile, file.content, { mode: oldStats.mode & 0o777, flag: "wx" });
        const untouchedPaths = new Set(proposal.files.map((entry) => entry.name));
        untouchedPaths.add(path.relative(context.sourceRoot, tempFile).split(path.sep).join("/"));
        if (
          proposal.unmodifiedSourceHash !== await hashSourceTree(
            context.sourceRoot,
            untouchedPaths,
          ) ||
          sha256(await readFile(target)) !== file.originalHash
        ) {
          throw new Error(`Engine source changed immediately before patch replacement: ${file.name}`);
        }
        await assertNoSymlinkPath(target, context.sourceRoot);
        await rename(tempFile, target);
      } catch (error) {
        await rm(tempFile, { force: true });
        throw error;
      }
      applied.push(file.name);
    }

    const sourceAppliedHash = await hashSourceTree(context.sourceRoot);
    const expectedCandidateHash = proposal.candidate[0]?.sourceHash;
    if (!expectedCandidateHash || sourceAppliedHash !== expectedCandidateHash) {
      throw new Error("Applied source tree does not match the tested candidate hash.");
    }
    const appliedEvidenceText = JSON.stringify({
      ...checkpointEvidence,
      patchStatus: "APPLIED",
      sourceAppliedHash,
      appliedAt: new Date().toISOString(),
    }, null, 2);
    await writeFile(path.join(checkpointRoot, "evidence.json"), appliedEvidenceText);
    proposal.checkpointEvidenceHash = sha256(appliedEvidenceText);
    proposal.status = "APPLIED";
    proposal.sourceAppliedHash = sourceAppliedHash;
    try {
      await saveAgentEvent({
        id: randomUUID(),
        type: "ENGINE_PATCH_APPLIED",
        at: new Date().toISOString(),
        data: {
          proposalId: proposal.id,
          proposalHash: proposal.hash,
          sourceBaselineHash: proposal.sourceBaselineHash,
          sourceAppliedHash,
          approvalIdentity: proposal.approvalIdentity,
          approvalStatus: "CONSUMED",
          files: applied.map((name) => ({
            name,
            oldHash: proposal.files.find((file) => file.name === name)?.originalHash,
            newHash: proposal.files.find((file) => file.name === name)?.proposedHash,
          })),
          checkpoint: path.relative(context.sourceRoot, checkpointRoot),
        },
      });
    } catch (error) {
      response.status(503).json({
        status: "applied_audit_unavailable",
        code: "engine_patch_applied_but_final_audit_failed",
        message: error instanceof Error ? error.message : String(error),
        files: applied,
        checkpoint: path.relative(context.sourceRoot, checkpointRoot),
        requestAuditId: audit.eventId,
      });
      return;
    }
    response.json({
      status: "applied",
      proposalHash: proposal.hash,
      sourceBaselineHash: proposal.sourceBaselineHash,
      sourceAppliedHash,
      files: applied,
      checkpoint: path.relative(context.sourceRoot, checkpointRoot),
    });
  } catch (error) {
    const rollbackErrors: string[] = [];
    for (const name of applied.reverse()) {
      try {
        const target = path.resolve(context.sourceRoot, name);
        await assertNoSymlinkPath(target, context.sourceRoot);
        const original = currentContents.get(name);
        if (!original) throw new Error(`Original content is missing for rollback: ${name}`);
        const tempFile = path.join(path.dirname(target), `.${path.basename(target)}.${randomUUID()}.rollback`);
        await writeFile(tempFile, original, { flag: "wx" });
        await rename(tempFile, target);
      } catch (rollbackError) {
        rollbackErrors.push(rollbackError instanceof Error ? rollbackError.message : String(rollbackError));
      }
    }
    proposal.status = rollbackErrors.length > 0 ? "PARTIAL_APPLY" : "APPLY_FAILED";
    response.status(500).json({
      status: rollbackErrors.length > 0 ? "partial_apply" : "apply_failed_rolled_back",
      code: "engine_patch_apply_failed",
      message: error instanceof Error ? error.message : String(error),
      rollbackErrors,
      checkpoint: path.relative(context.sourceRoot, checkpointRoot),
    });
  } finally {
    context.activeApply.delete(proposal.id);
    await releaseApplyLock();
  }
}

async function rollbackEnginePatch(
  request: Request,
  response: Response,
  context: EngineSelfImprovementContext,
): Promise<void> {
  const proposalId = typeof request.params.id === "string" ? request.params.id : "";
  const proposal = context.proposals.get(proposalId);
  if (!proposal) {
    response.status(404).json({ status: "unavailable", code: "engine_patch_proposal_not_found" });
    return;
  }
  if (
    (proposal.status !== "APPLIED" && proposal.status !== "ROLLBACK_FAILED") ||
    !proposal.sourceAppliedHash ||
    !proposal.checkpointEvidenceHash
  ) {
    response.status(409).json({ status: "blocked", code: "engine_patch_not_rollbackable" });
    return;
  }
  if (
    !request.body || typeof request.body !== "object" ||
    Object.keys(request.body).some((key) => key !== "hash" && key !== "sourceAppliedHash") ||
    request.body.hash !== proposal.hash ||
    request.body.sourceAppliedHash !== proposal.sourceAppliedHash
  ) {
    response.status(409).json({ status: "blocked", code: "engine_patch_rollback_hash_mismatch" });
    return;
  }
  if (proposal.sourceAppliedHash !== await hashSourceTree(context.sourceRoot)) {
    response.status(409).json({ status: "blocked", code: "engine_source_changed_since_apply" });
    return;
  }
  if (context.activeApply.has(proposal.id)) {
    response.status(409).json({ status: "blocked", code: "engine_patch_rollback_in_progress" });
    return;
  }
  context.activeApply.add(proposal.id);

  const approverIdentity = process.env.ENGINE_PATCH_APPROVER_ID?.trim();
  if (!approverIdentity) {
    context.activeApply.delete(proposal.id);
    response.status(503).json({ status: "unavailable", code: "engine_patch_approver_identity_unconfigured" });
    return;
  }
  let releaseApplyLock: (() => Promise<void>) | undefined;
  try {
    releaseApplyLock = await acquireApplyLock(context.sourceRoot);
  } catch (error) {
    context.activeApply.delete(proposal.id);
    const code = (error as NodeJS.ErrnoException).code;
    response.status(code === "EEXIST" ? 409 : 503).json({
      status: "blocked",
      code: code === "EEXIST" ? "engine_patch_apply_lock_held" : "engine_patch_apply_lock_unavailable",
    });
    return;
  }
  const checkpointRoot = path.join(context.sourceRoot, ".data", "engine-patch-checkpoints", proposal.id);
  const evidencePath = path.join(checkpointRoot, "evidence.json");
  const restored: string[] = [];
  const appliedFiles = new Map(proposal.files.map((file) => [file.name, file]));
  try {
    await assertNoSymlinkPath(checkpointRoot, context.sourceRoot);
    await assertNoSymlinkPath(evidencePath, context.sourceRoot);
    const checkpointEvidence = await readFile(evidencePath);
    if (sha256(checkpointEvidence) !== proposal.checkpointEvidenceHash) {
      response.status(409).json({ status: "blocked", code: "engine_patch_checkpoint_evidence_changed" });
      return;
    }
    const evidence = JSON.parse(checkpointEvidence.toString("utf8")) as {
      proposalId?: string;
      proposalHash?: string;
      sourceBaselineHash?: string;
      unmodifiedSourceHash?: string;
      patchStatus?: string;
      sourceAppliedHash?: string;
      candidate?: CheckEvidence[];
    };
    if (
      evidence.proposalId !== proposal.id ||
      evidence.proposalHash !== proposal.hash ||
      evidence.sourceBaselineHash !== proposal.sourceBaselineHash ||
      evidence.unmodifiedSourceHash !== proposal.unmodifiedSourceHash ||
      evidence.patchStatus !== "APPLIED" ||
      evidence.sourceAppliedHash !== proposal.sourceAppliedHash ||
      evidence.candidate?.[0]?.sourceHash !== proposal.sourceAppliedHash
    ) {
      response.status(409).json({ status: "blocked", code: "engine_patch_checkpoint_evidence_invalid" });
      return;
    }
    const restoreFiles: Array<{ name: string; original: Buffer; mode: number }> = [];
    for (const file of proposal.files) {
      if (!isAllowedEnginePatch(file.name)) {
        response.status(403).json({ status: "blocked", code: "engine_patch_path_protected" });
        return;
      }
      const checkpoint = path.join(checkpointRoot, file.name);
      const target = path.resolve(context.sourceRoot, file.name);
      await assertNoSymlinkPath(checkpoint, context.sourceRoot);
      await assertNoSymlinkPath(target, context.sourceRoot);
      const original = await readFile(checkpoint);
      const targetStats = await lstat(target);
      if (
        sha256(original) !== file.originalHash ||
        !targetStats.isFile() ||
        targetStats.isSymbolicLink() ||
        sha256(await readFile(target)) !== file.proposedHash
      ) {
        response.status(409).json({ status: "blocked", code: "engine_patch_rollback_file_hash_mismatch", file: file.name });
        return;
      }
      restoreFiles.push({ name: file.name, original, mode: targetStats.mode & 0o777 });
    }

    await saveAgentEvent({
      id: randomUUID(),
      type: "ENGINE_PATCH_ROLLBACK_REQUESTED",
      at: new Date().toISOString(),
      data: {
        proposalId: proposal.id,
        proposalHash: proposal.hash,
        sourceAppliedHash: proposal.sourceAppliedHash,
        sourceBaselineHash: proposal.sourceBaselineHash,
        approvalIdentity: approverIdentity,
        approvalStatus: "ROLLBACK_APPROVED",
      },
    });
    if (
      proposal.sourceAppliedHash !== await hashSourceTree(context.sourceRoot) ||
      proposal.unmodifiedSourceHash !== await hashSourceTree(
        context.sourceRoot,
        new Set(proposal.files.map((file) => file.name)),
      )
    ) {
      response.status(409).json({ status: "blocked", code: "engine_source_changed_before_rollback" });
      return;
    }
    for (const file of restoreFiles) {
      const target = path.resolve(context.sourceRoot, file.name);
      await assertNoSymlinkPath(target, context.sourceRoot);
      if (sha256(await readFile(target)) !== appliedFiles.get(file.name)?.proposedHash) {
        throw new Error(`Engine patch target changed immediately before rollback: ${file.name}`);
      }
      const tempFile = path.join(path.dirname(target), `.${path.basename(target)}.${randomUUID()}.rollback`);
      await writeFile(tempFile, file.original, { mode: file.mode, flag: "wx" });
      const untouchedPaths = new Set(proposal.files.map((entry) => entry.name));
      untouchedPaths.add(path.relative(context.sourceRoot, tempFile).split(path.sep).join("/"));
      if (
        proposal.unmodifiedSourceHash !== await hashSourceTree(
          context.sourceRoot,
          untouchedPaths,
        ) ||
        sha256(await readFile(target)) !== appliedFiles.get(file.name)?.proposedHash
      ) {
        await rm(tempFile, { force: true });
        throw new Error(`Engine source changed immediately before rollback: ${file.name}`);
      }
      await assertNoSymlinkPath(target, context.sourceRoot);
      await rename(tempFile, target);
      restored.push(file.name);
    }
    const sourceRollbackHash = await hashSourceTree(context.sourceRoot);
    if (sourceRollbackHash !== proposal.sourceBaselineHash) {
      throw new Error("Rolled-back source does not match the approved baseline hash.");
    }
    proposal.status = "ROLLED_BACK";
    await saveAgentEvent({
      id: randomUUID(),
      type: "ENGINE_PATCH_ROLLED_BACK",
      at: new Date().toISOString(),
      data: {
        proposalId: proposal.id,
        proposalHash: proposal.hash,
        sourceAppliedHash: proposal.sourceAppliedHash,
        sourceRollbackHash,
        approvalIdentity: approverIdentity,
        files: restoreFiles.map(({ name }) => ({
          name,
          restoredHash: appliedFiles.get(name)?.originalHash,
        })),
      },
    });
    response.json({
      status: "rolled_back",
      proposalId: proposal.id,
      sourceRollbackHash,
      files: restoreFiles.map(({ name }) => name),
    });
  } catch (error) {
    const recoveryErrors: string[] = [];
    for (const name of restored.reverse()) {
      try {
        const file = appliedFiles.get(name);
        if (!file) throw new Error(`Applied patch content is unavailable for recovery: ${name}`);
        const target = path.resolve(context.sourceRoot, name);
        await assertNoSymlinkPath(target, context.sourceRoot);
        const tempFile = path.join(path.dirname(target), `.${path.basename(target)}.${randomUUID()}.recover`);
        await writeFile(tempFile, file.content, { flag: "wx" });
        await rename(tempFile, target);
      } catch (recoveryError) {
        recoveryErrors.push(recoveryError instanceof Error ? recoveryError.message : String(recoveryError));
      }
      if (recoveryErrors.length === 0) {
        const recoveredHash = await hashSourceTree(context.sourceRoot);
        if (recoveredHash !== proposal.sourceAppliedHash) {
          recoveryErrors.push("Recovered source does not match the tested applied hash.");
        }
      }
    }
    proposal.status = recoveryErrors.length > 0 ? "PARTIAL_ROLLBACK" : "ROLLBACK_FAILED";
    response.status(500).json({
      status: recoveryErrors.length > 0 ? "partial_rollback" : "rollback_failed_patch_restored",
      code: "engine_patch_rollback_failed",
      message: error instanceof Error ? error.message : String(error),
      recoveryErrors,
    });
  } finally {
    context.activeApply.delete(proposal.id);
    await releaseApplyLock();
  }
}

export type EngineSelfImprovementRouterOptions = {
  sourceRoot?: string;
  provider?: Pick<AIProviderAdapter, "isConfigured" | "generateText">;
};

function matchesSecret(request: Request, expected: string, headerName: string): boolean {
  const header = request.get(headerName);
  const candidateValue = headerName.toLowerCase() === "authorization"
    ? header?.match(/^Bearer\s+([^\s]+)$/i)?.[1]
    : header;
  if (!candidateValue) return false;
  const candidate = Buffer.from(candidateValue, "utf8");
  const expectedBytes = Buffer.from(expected, "utf8");
  return candidate.length === expectedBytes.length && timingSafeEqual(candidate, expectedBytes);
}

function requireConfiguredBearer(
  request: Request,
  response: Response,
  tokenName: "APPHUB_AUTH_TOKEN" | "ENGINE_PATCH_APPROVAL_TOKEN",
): boolean {
  const expected = process.env[tokenName];
  if (!expected || expected.trim().length < 32) {
    response.status(503).json({ status: "unavailable", code: `${tokenName.toLowerCase()}_not_configured` });
    return false;
  }
  if (!matchesSecret(request, expected, "authorization")) {
    response.setHeader("WWW-Authenticate", "Bearer");
    response.status(401).json({ status: "blocked", code: "authentication_required" });
    return false;
  }
  return true;
}

export function createEngineSelfImprovementRouter(options: EngineSelfImprovementRouterOptions = {}): express.Router {
  const router = express.Router();
  const context: EngineSelfImprovementContext = {
    sourceRoot: path.resolve(options.sourceRoot ?? ENGINE_ROOT),
    provider: options.provider,
    proposals: new Map(),
    activeRun: false,
    activeApply: new Set(),
  };
  router.use((request: Request, response: Response, next: NextFunction) => {
    if (requireConfiguredBearer(request, response, "APPHUB_AUTH_TOKEN")) next();
  });
  router.post("/run", (request: Request, response: Response, next: NextFunction) => {
    void runEngineImprovement(request, response, context).catch(next);
  });
  router.post("/proposals/:id/approve", (request: Request, response: Response, next: NextFunction) => {
    const apiToken = process.env.APPHUB_AUTH_TOKEN;
    const approvalToken = process.env.ENGINE_PATCH_APPROVAL_TOKEN;
    const identity = process.env.ENGINE_PATCH_APPROVER_ID?.trim();
    if (
      !approvalToken || approvalToken.trim().length < 32 ||
      approvalToken === apiToken ||
      !identity || identity.length > 128
    ) {
      response.status(503).json({ status: "unavailable", code: "engine_patch_approver_not_configured" });
      return;
    }
    if (!matchesSecret(request, approvalToken, "x-engine-patch-approval-token")) {
      response.status(401).json({ status: "blocked", code: "engine_patch_approver_authentication_required" });
      return;
    }
    void approveEnginePatch(request, response, context).catch(next);
  });
  router.post("/proposals/:id/apply", (request: Request, response: Response, next: NextFunction) => {
    void applyEnginePatch(request, response, context).catch(next);
  });
  router.post("/proposals/:id/rollback", (request: Request, response: Response, next: NextFunction) => {
    const approvalToken = process.env.ENGINE_PATCH_APPROVAL_TOKEN;
    if (
      !approvalToken ||
      approvalToken.trim().length < 32 ||
      approvalToken === process.env.APPHUB_AUTH_TOKEN ||
      !matchesSecret(request, approvalToken, "x-engine-patch-approval-token")
    ) {
      response.status(401).json({ status: "blocked", code: "engine_patch_approver_authentication_required" });
      return;
    }
    void rollbackEnginePatch(request, response, context).catch(next);
  });
  return router;
}

export const engineSelfImprovementInternals = {
  assertNoSymlinkPath,
  isAllowedEnginePatch,
  parsePatchOutput,
  parseTestCounts,
  verifySandboxIsolation,
};
