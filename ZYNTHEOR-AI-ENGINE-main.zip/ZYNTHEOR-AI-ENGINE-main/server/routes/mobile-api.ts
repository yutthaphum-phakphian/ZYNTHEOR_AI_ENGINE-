import { Router } from 'express'
import crypto from 'node:crypto'

/**
 * P11 Mobile API - Local-only bridge
 * No external provider, sandboxed builds only
 */
const router = Router()

// P11: Device registration (local only)
router.post('/device/register', (req, res) => {
  const { deviceId, platform } = req.body
  if (!deviceId) return res.status(400).json({ error: 'deviceId required' })
  
  const digest = crypto.createHash('sha256')
    .update(`MOBILE|${deviceId}|${platform}|${Date.now()}`)
    .digest('hex')
  
  res.json({
    deviceId,
    platform: platform || 'web',
    registered: true,
    digest,
    sandbox: 'isolated',
    mode: 'local-only'
  })
})

// P11: Offline queue sync (for mobile offline-first)
router.post('/sync/queue', (req, res) => {
  const { actions } = req.body
  if (!Array.isArray(actions)) return res.status(400).json({ error: 'actions array required' })
  
  const h_in = crypto.createHash('sha256').update(JSON.stringify(actions)).digest('hex')
  // Zero-fake: if local core unavailable, return UNAVAILABLE not fake success
  const coreAvailable = process.env.MODEL_MANIFEST_DIGEST !== 'dev-mode-no-manifest'
  
  if (!coreAvailable) {
    return res.status(503).json({
      status: 'UNAVAILABLE',
      h_in,
      reason: 'Local model not loaded: dev-mode-no-manifest',
      queued: actions.length
    })
  }
  
  res.json({
    status: 'QUEUED',
    h_in,
    processed: actions.length,
    evidence: `P11-MOBILE|${h_in}`
  })
})

// P11: One-Chat Workspace state
router.get('/workspace/one-chat', (req, res) => {
  res.json({
    workspace: 'one-chat',
    modes: ['Auto','Fast','Deep Reasoning','Coding','Review','Custom'],
    components: ['Assistant','CodeStudio','Plans','AuditLedger','Settings'],
    sandbox: true,
    localOnly: true
  })
})

export default router
