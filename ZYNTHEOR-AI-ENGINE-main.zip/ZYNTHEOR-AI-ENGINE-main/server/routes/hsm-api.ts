import { Router } from 'express'
import { generateEd25519Keypair, signWithEd25519, verifyEd25519, createTimestampToken, getHSMStatus } from '../engine/hsm-kms.js'
import crypto from 'node:crypto'

const router = Router()

// P13: Generate keypair in HSM
router.post('/hsm/keygen', (req, res) => {
  const { keyId } = req.body
  if (!keyId) return res.status(400).json({ error: 'keyId required' })
  const result = generateEd25519Keypair(keyId)
  res.json({ ...result, status: 'generated', hsm: 'local' })
})

// P13: Sign payload (evidence)
router.post('/sign', (req, res) => {
  const { keyId, payload } = req.body
  if (!keyId || !payload) return res.status(400).json({ error: 'keyId + payload required' })
  try {
    const { signature } = signWithEd25519(keyId, payload)
    const digest = crypto.createHash('sha256').update(payload).digest('hex')
    const tsa = createTimestampToken(digest)
    res.json({ keyId, digest, signature, tsa, algorithm: 'Ed25519' })
  } catch (e: any) {
    res.status(403).json({ status: 'BLOCKED', reason: e.message })
  }
})

// P13: Verify
router.post('/verify', (req, res) => {
  const { keyId, payload, signature } = req.body
  const valid = verifyEd25519(keyId, payload, signature)
  res.json({ valid, keyId, verified: valid })
})

router.get('/status', (req, res) => {
  res.json(getHSMStatus())
})

export default router
