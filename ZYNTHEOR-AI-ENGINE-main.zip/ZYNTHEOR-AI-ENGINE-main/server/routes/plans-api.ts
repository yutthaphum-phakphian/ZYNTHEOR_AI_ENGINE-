import { Router } from 'express'
import crypto from 'node:crypto'

const router = Router()

type PlanStatus = 'draft'|'approved'|'running'|'blocked'|'done'
type Plan = { id: string, title: string, steps: string[], status: PlanStatus, digest: string, correlationId: string }

const plans = new Map<string, Plan>()

// P12: Create task plan (with digest)
router.post('/create', (req, res) => {
  const { title, steps } = req.body
  if (!title || !Array.isArray(steps)) return res.status(400).json({ error: 'title + steps[] required' })
  
  const id = crypto.randomUUID()
  const correlationId = crypto.randomUUID()
  const digest = crypto.createHash('sha256').update(JSON.stringify({ title, steps })).digest('hex')
  
  const plan: Plan = { id, title, steps, status: 'draft', digest, correlationId }
  plans.set(id, plan)
  
  res.json({ plan, evidence: `P12-PLAN|${digest}|${correlationId}` })
})

// P12: Approval Gate - must approve before execution
router.post('/:id/approve', (req, res) => {
  const plan = plans.get(req.params.id)
  if (!plan) return res.status(404).json({ error: 'plan not found' })
  if (plan.status !== 'draft') return res.status(400).json({ error: `cannot approve from ${plan.status}` })
  
  plan.status = 'approved'
  res.json({ plan, approved: true, gate: 'human-approval' })
})

// P12: Run plan (blocked if not approved - Zero-Fake)
router.post('/:id/run', (req, res) => {
  const plan = plans.get(req.params.id)
  if (!plan) return res.status(404).json({ error: 'plan not found' })
  if (plan.status !== 'approved') {
    return res.status(403).json({ 
      status: 'BLOCKED', 
      reason: 'Plan must be approved before run',
      current: plan.status 
    })
  }
  plan.status = 'running'
  // Simulate done
  setTimeout(()=>{ plan.status = 'done' }, 1000)
  res.json({ plan, started: true })
})

router.get('/', (req, res) => {
  res.json({ plans: Array.from(plans.values()), count: plans.size })
})

export default router
