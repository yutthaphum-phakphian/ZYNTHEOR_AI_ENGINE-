/**
 * ZYNTHEOR EXTERNAL HOSTED PROVIDERS — REMOVED
 * 
 * Strict Zero Fake & Sovereignty Policy:
 * External AI providers (OpenAI, Anthropic, Groq, Gemini) have been removed.
 * No outbound network requests are made to external AI providers.
 */

import { ChatMessage, HostedProviderConfig, ZeroFakeAttestation } from '../types.js';

export async function executeHostedInference(
  _messages: ChatMessage[],
  hostedConfig: HostedProviderConfig,
  _systemPrompt?: string
): Promise<{
  content: string;
  model: string;
  tokensUsed?: { prompt?: number; completion?: number; total?: number };
  executionTimeMs: number;
  zeroFakeAttestation: ZeroFakeAttestation;
}> {
  const error: any = new Error(
    `External hosted provider '${hostedConfig?.providerName || 'unknown'}' has been removed.`
  );
  error.code = 'external_provider_removed';
  throw error;
}
