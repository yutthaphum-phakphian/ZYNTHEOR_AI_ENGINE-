/**
 * ZYNTHEOR SOVEREIGN LOCAL RUNTIME ADAPTER
 * Zero-Fake Invariant:
 * 1. Directly interfaces ONLY with locally configured runtimes (Ollama, llama.cpp, Local server).
 * 2. Absolutely NO calls to @google/genai, OpenAI, Anthropic, or external hosted LLMs.
 * 3. Never mocks or synthesizes responses.
 * 4. Fails fast with structured error if runtime is offline, timed out, or model missing.
 */

import { ChatMessage, LocalRuntimeConfig, RuntimeStatus, ZeroFakeAttestation } from '../types.js';

export class LocalRuntimeError extends Error {
  public code: 'local_runtime_unavailable';
  public details: string;
  public status: number;

  constructor(message: string, details: string, status = 503) {
    super(message);
    this.name = 'LocalRuntimeError';
    this.code = 'local_runtime_unavailable';
    this.details = details;
    this.status = status;
  }
}

/**
 * Normalizes URL without trailing slash
 */
export function normalizeEndpoint(url: string): string {
  return url.trim().replace(/\/+$/, '');
}

/**
 * Checks actual health of local runtime endpoint
 */
export async function checkLocalRuntimeHealth(config: LocalRuntimeConfig): Promise<RuntimeStatus> {
  const baseEndpoint = normalizeEndpoint(config.endpoint);
  const startTime = Date.now();
  const availableModels: string[] = [];

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    let isHealthy = false;
    let versionInfo: string | undefined = undefined;

    if (config.runtimeType === 'ollama') {
      // Ollama provides /api/tags for model registry and /api/version
      try {
        const res = await fetch(`${baseEndpoint}/api/tags`, {
          signal: controller.signal,
          headers: { 'Accept': 'application/json' },
        });

        if (res.ok) {
          const data = (await res.json()) as { models?: Array<{ name: string; model?: string }> };
          if (data && Array.isArray(data.models)) {
            data.models.forEach((m) => {
              if (m.name) availableModels.push(m.name);
            });
          }
          isHealthy = true;
        }
      } catch (err: any) {
        // Continue to check if /api/version works
      }

      if (!isHealthy) {
        // Fallback probe for Ollama /api/version
        try {
          const verRes = await fetch(`${baseEndpoint}/api/version`, { signal: controller.signal });
          if (verRes.ok) {
            const verData = (await verRes.json()) as { version?: string };
            versionInfo = verData.version;
            isHealthy = true;
          }
        } catch {
          // Both failed
        }
      }
    } else {
      // llama.cpp / openai-compatible (e.g. /v1/models or /health)
      try {
        const res = await fetch(`${baseEndpoint}/v1/models`, {
          signal: controller.signal,
          headers: { 'Accept': 'application/json' },
        });
        if (res.ok) {
          const data = (await res.json()) as { data?: Array<{ id: string }> };
          if (data && Array.isArray(data.data)) {
            data.data.forEach((m) => {
              if (m.id) availableModels.push(m.id);
            });
          }
          isHealthy = true;
        }
      } catch {
        // Try /health
      }

      if (!isHealthy) {
        try {
          const healthRes = await fetch(`${baseEndpoint}/health`, { signal: controller.signal });
          if (healthRes.ok) {
            isHealthy = true;
          }
        } catch {
          // Both failed
        }
      }
    }

    clearTimeout(timeoutId);
    const latency = Date.now() - startTime;

    if (!isHealthy) {
      return {
        status: 'offline',
        endpoint: baseEndpoint,
        model: config.model,
        runtimeType: config.runtimeType,
        availableModels: [],
        latencyMs: latency,
        error: `Could not reach ${config.runtimeType} server at ${baseEndpoint}. Connection refused or invalid response.`,
        lastChecked: Date.now(),
        isZeroFakeVerified: false,
      };
    }

    // Verify configured model availability if models were returned
    let modelWarning: string | undefined = undefined;
    if (availableModels.length > 0) {
      const match = availableModels.some((m) =>
        m.toLowerCase() === config.model.toLowerCase() ||
        m.toLowerCase().startsWith(config.model.toLowerCase() + ':')
      );
      if (!match) {
        modelWarning = `Model '${config.model}' was not found in available models: [${availableModels.join(', ')}]. Run 'ollama pull ${config.model}'.`;
      }
    }

    return {
      status: 'online',
      endpoint: baseEndpoint,
      model: config.model,
      runtimeType: config.runtimeType,
      availableModels,
      latencyMs: latency,
      error: modelWarning,
      lastChecked: Date.now(),
      isZeroFakeVerified: true,
      versionInfo,
    };
  } catch (err: any) {
    const latency = Date.now() - startTime;
    return {
      status: 'offline',
      endpoint: baseEndpoint,
      model: config.model,
      runtimeType: config.runtimeType,
      availableModels: [],
      latencyMs: latency,
      error: err.name === 'AbortError'
        ? `Connection to local runtime at ${baseEndpoint} timed out.`
        : `Failed to connect to local runtime: ${err.message || String(err)}`,
      lastChecked: Date.now(),
      isZeroFakeVerified: false,
    };
  }
}

/**
 * Execute chat inference against the sovereign Local Runtime.
 * Strictly guarantees ZERO calls to external LLMs.
 */
export async function executeLocalInference(
  messages: ChatMessage[],
  config: LocalRuntimeConfig,
  systemPrompt?: string
): Promise<{
  content: string;
  model: string;
  tokensUsed?: { prompt?: number; completion?: number; total?: number };
  executionTimeMs: number;
  zeroFakeAttestation: ZeroFakeAttestation;
}> {
  const baseEndpoint = normalizeEndpoint(config.endpoint);
  const startTime = Date.now();
  const timeoutMs = config.timeoutMs || 30000;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    if (config.runtimeType === 'ollama') {
      // Ollama native /api/chat payload
      const formattedMessages = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      if (systemPrompt && !formattedMessages.some((m) => m.role === 'system')) {
        formattedMessages.unshift({ role: 'system', content: systemPrompt });
      }

      const res = await fetch(`${baseEndpoint}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          model: config.model,
          messages: formattedMessages,
          stream: false,
          options: {
            temperature: config.temperature ?? 0.7,
            top_p: config.topP ?? 0.9,
            num_predict: config.maxTokens ?? 2048,
          },
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        const errorText = await res.text().catch(() => '');
        if (res.status === 404) {
          throw new LocalRuntimeError(
            `Model '${config.model}' not found on local Ollama server`,
            `The Ollama server returned 404. Run 'ollama pull ${config.model}' in your terminal to download the model weights. Server response: ${errorText}`,
            503
          );
        }
        throw new LocalRuntimeError(
          `Local Ollama server returned HTTP ${res.status}`,
          `Error from local runtime: ${errorText || res.statusText}`,
          503
        );
      }

      const data = (await res.json()) as {
        message?: { content?: string };
        prompt_eval_count?: number;
        eval_count?: number;
      };

      if (!data?.message?.content) {
        throw new LocalRuntimeError(
          'Local runtime returned an empty response',
          'The Ollama response payload did not contain message content.',
          503
        );
      }

      const executionTimeMs = Date.now() - startTime;

      return {
        content: data.message.content,
        model: config.model,
        tokensUsed: {
          prompt: data.prompt_eval_count,
          completion: data.eval_count,
          total: (data.prompt_eval_count || 0) + (data.eval_count || 0),
        },
        executionTimeMs,
        zeroFakeAttestation: {
          disposition: 'genuine_local_inference',
          fallbackTriggered: false,
          runtimeHost: baseEndpoint,
          verifiedTimestamp: Date.now(),
        },
      };
    } else {
      // llama.cpp / openai-compatible endpoint (/v1/chat/completions)
      const formattedMessages = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      if (systemPrompt && !formattedMessages.some((m) => m.role === 'system')) {
        formattedMessages.unshift({ role: 'system', content: systemPrompt });
      }

      const res = await fetch(`${baseEndpoint}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          model: config.model,
          messages: formattedMessages,
          temperature: config.temperature ?? 0.7,
          top_p: config.topP ?? 0.9,
          max_tokens: config.maxTokens ?? 2048,
          stream: false,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        const errorText = await res.text().catch(() => '');
        throw new LocalRuntimeError(
          `Local llama.cpp/server returned HTTP ${res.status}`,
          `Endpoint ${baseEndpoint}/v1/chat/completions returned ${res.status}: ${errorText}`,
          503
        );
      }

      const data = (await res.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
        usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number };
      };

      const choice = data?.choices?.[0];
      if (!choice?.message?.content) {
        throw new LocalRuntimeError(
          'Local runtime returned empty choice',
          'The local server response did not contain message choices.',
          503
        );
      }

      const executionTimeMs = Date.now() - startTime;

      return {
        content: choice.message.content,
        model: config.model,
        tokensUsed: data.usage ? {
          prompt: data.usage.prompt_tokens,
          completion: data.usage.completion_tokens,
          total: data.usage.total_tokens,
        } : undefined,
        executionTimeMs,
        zeroFakeAttestation: {
          disposition: 'genuine_local_inference',
          fallbackTriggered: false,
          runtimeHost: baseEndpoint,
          verifiedTimestamp: Date.now(),
        },
      };
    }
  } catch (err: any) {
    clearTimeout(timeoutId);

    if (err instanceof LocalRuntimeError) {
      throw err;
    }

    if (err.name === 'AbortError') {
      throw new LocalRuntimeError(
        `Local runtime timed out after ${timeoutMs}ms`,
        `The local AI runtime at ${baseEndpoint} took too long to generate a response. Increase timeout or verify that the local model is not running out of GPU memory.`,
        503
      );
    }

    const code = err.code || err.cause?.code || '';
    const message = err.message || String(err);

    let details = `Failed to connect to local runtime at ${baseEndpoint}. `;
    if (code === 'ECONNREFUSED' || message.includes('ECONNREFUSED')) {
      details += `Connection refused. Please start your local runtime server (e.g., run 'ollama serve' or start llama.cpp server).`;
    } else if (code === 'ENOTFOUND' || message.includes('ENOTFOUND')) {
      details += `Host not found. Verify the local endpoint URL.`;
    } else {
      details += `Original error: ${message}`;
    }

    throw new LocalRuntimeError(
      'Local AI runtime is unavailable',
      details,
      503
    );
  }
}
