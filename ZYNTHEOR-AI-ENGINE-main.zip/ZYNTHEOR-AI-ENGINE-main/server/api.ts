import fs from 'fs';
import path from 'path';
import os from 'os';
import crypto from 'crypto';
import http from 'http';
import { execSync } from 'child_process';

// Base directories
const DATA_DIR = path.resolve(process.cwd(), '.data');
const WORKSPACE_DIR = path.resolve(DATA_DIR, 'workspace');
const LEDGER_FILE = path.resolve(DATA_DIR, 'ledger.json');
const SESSIONS_FILE = path.resolve(DATA_DIR, 'sessions.json');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(WORKSPACE_DIR)) {
  fs.mkdirSync(WORKSPACE_DIR, { recursive: true });
}

// -------------------------------------------------------------
// Cryptographic Evidence Ledger Types & Utilities
// -------------------------------------------------------------
export interface LedgerEvent {
  id: string;
  index: number;
  timestamp: string;
  eventType: 'INFERENCE_REQUEST' | 'WORKSPACE_SCAN' | 'WEB_RESEARCH' | 'TOOL_INVOCATION' | 'SECURITY_VALIDATION' | 'AUDIT_EXPORT' | 'DIAGNOSTICS_CHECK' | 'CODE_ANALYSIS';
  pipelineStage: 'INPUT_SANITIZATION' | 'POLICY_VERIFICATION' | 'CORE_INFERENCE' | 'TOOL_EXECUTION' | 'OUTPUT_VERIFICATION' | 'LEDGER_COMMIT';
  actor: 'USER' | 'AI_CORE' | 'TOOL_REGISTRY' | 'SECURITY_BARRIER' | 'AUDIT_SUBSYSTEM';
  status: 'PASS' | 'FAIL' | 'BLOCKED' | 'NOT_TESTED' | 'UNAVAILABLE';
  target: string;
  details: string;
  latencyMs: number;
  payloadHash: string;
  previousHash: string;
  ledgerHash: string;
}

export function computeSha256(content: string): string {
  return crypto.createHash('sha256').update(content, 'utf8').digest('hex');
}

export function loadLedger(): LedgerEvent[] {
  try {
    if (fs.existsSync(LEDGER_FILE)) {
      const data = fs.readFileSync(LEDGER_FILE, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading ledger file:', err);
  }

  // Genesis block initialization
  const genesisPayload = JSON.stringify({ system: 'ZYNTHEOR AI ENGINE', epoch: 'GENESIS', timestamp: new Date().toISOString() });
  const payloadHash = computeSha256(genesisPayload);
  const genesisHash = computeSha256(`0-${new Date().toISOString()}-SECURITY_VALIDATION-AUDIT_SUBSYSTEM-PASS-${payloadHash}-0000000000000000000000000000000000000000000000000000000000000000`);
  
  const genesisEvent: LedgerEvent = {
    id: crypto.randomUUID(),
    index: 0,
    timestamp: new Date().toISOString(),
    eventType: 'SECURITY_VALIDATION',
    pipelineStage: 'LEDGER_COMMIT',
    actor: 'AUDIT_SUBSYSTEM',
    status: 'PASS',
    target: 'GENESIS_BLOCK',
    details: 'Cryptographic Evidence Ledger genesis block initialized with SHA-256 seal.',
    latencyMs: 1,
    payloadHash,
    previousHash: '0000000000000000000000000000000000000000000000000000000000000000',
    ledgerHash: genesisHash
  };

  const initialList = [genesisEvent];
  try {
    fs.writeFileSync(LEDGER_FILE, JSON.stringify(initialList, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to write genesis ledger:', err);
  }
  return initialList;
}

export function recordLedgerEvent(
  eventType: LedgerEvent['eventType'],
  pipelineStage: LedgerEvent['pipelineStage'],
  actor: LedgerEvent['actor'],
  status: LedgerEvent['status'],
  target: string,
  details: string,
  rawPayload: any,
  latencyMs: number = 0
): LedgerEvent {
  const ledger = loadLedger();
  const lastEvent = ledger[ledger.length - 1];
  const previousHash = lastEvent ? lastEvent.ledgerHash : '0000000000000000000000000000000000000000000000000000000000000000';
  const index = ledger.length;
  const timestamp = new Date().toISOString();
  
  const payloadStr = typeof rawPayload === 'string' ? rawPayload : JSON.stringify(rawPayload || {});
  const payloadHash = computeSha256(payloadStr);

  const hashString = `${index}-${timestamp}-${eventType}-${actor}-${status}-${payloadHash}-${previousHash}`;
  const ledgerHash = computeSha256(hashString);

  const newEvent: LedgerEvent = {
    id: crypto.randomUUID(),
    index,
    timestamp,
    eventType,
    pipelineStage,
    actor,
    status,
    target,
    details,
    latencyMs,
    payloadHash,
    previousHash,
    ledgerHash
  };

  ledger.push(newEvent);

  try {
    fs.writeFileSync(LEDGER_FILE, JSON.stringify(ledger, null, 2), 'utf8');
  } catch (err) {
    console.error('Error saving ledger event:', err);
  }

  return newEvent;
}

export function verifyLedgerIntegrity(): {
  isValid: boolean;
  totalEvents: number;
  brokenIndex?: number;
  message: string;
  genesisHash: string;
  latestHash: string;
} {
  const ledger = loadLedger();
  if (ledger.length === 0) {
    return {
      isValid: false,
      totalEvents: 0,
      message: 'Ledger is empty. No genesis block detected.',
      genesisHash: '',
      latestHash: ''
    };
  }

  for (let i = 0; i < ledger.length; i++) {
    const item = ledger[i];
    
    // Check previous hash link
    if (i > 0) {
      if (item.previousHash !== ledger[i - 1].ledgerHash) {
        return {
          isValid: false,
          totalEvents: ledger.length,
          brokenIndex: i,
          message: `Cryptographic link broken at event #${i}. Previous hash does not match block #${i - 1}.`,
          genesisHash: ledger[0].ledgerHash,
          latestHash: ledger[ledger.length - 1].ledgerHash
        };
      }
    }

    // Verify hash calculation
    const hashString = `${item.index}-${item.timestamp}-${item.eventType}-${item.actor}-${item.status}-${item.payloadHash}-${item.previousHash}`;
    const calculatedHash = computeSha256(hashString);
    if (calculatedHash !== item.ledgerHash) {
      return {
        isValid: false,
        totalEvents: ledger.length,
        brokenIndex: i,
        message: `Tampering detected at event #${i}. Hashed digest differs from recorded seal.`,
        genesisHash: ledger[0].ledgerHash,
        latestHash: ledger[ledger.length - 1].ledgerHash
      };
    }
  }

  return {
    isValid: true,
    totalEvents: ledger.length,
    message: `All ${ledger.length} ledger events cryptographically verified. SHA-256 chain is immutable and untampered.`,
    genesisHash: ledger[0].ledgerHash,
    latestHash: ledger[ledger.length - 1].ledgerHash
  };
}

// -------------------------------------------------------------
// Workspace Inspector Utilities (.data/workspace)
// -------------------------------------------------------------
export interface WorkspaceFileMetadata {
  name: string;
  relativePath: string;
  absolutePath: string;
  sizeBytes: number;
  sizeFormatted: string;
  extension: string;
  lines: number;
  modifiedAt: string;
  isReadable: boolean;
  category: 'code' | 'config' | 'document' | 'data' | 'other';
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function getCategory(ext: string): WorkspaceFileMetadata['category'] {
  const e = ext.toLowerCase();
  if (['.ts', '.tsx', '.js', '.jsx', '.py', '.sh', '.go', '.rs'].includes(e)) return 'code';
  if (['.json', '.yaml', '.yml', '.toml', '.env', '.ini'].includes(e)) return 'config';
  if (['.md', '.txt', '.doc', '.pdf', '.rst'].includes(e)) return 'document';
  if (['.csv', '.tsv', '.sql', '.db'].includes(e)) return 'data';
  return 'other';
}

export function inspectWorkspaceDirectory(): {
  totalFiles: number;
  totalSizeBytes: number;
  totalSizeFormatted: string;
  allowedScope: string;
  environment: string;
  scannedAt: string;
  files: WorkspaceFileMetadata[];
  boundaryEnforced: boolean;
} {
  const files: WorkspaceFileMetadata[] = [];
  let totalSizeBytes = 0;

  function walkDir(currentDir: string) {
    if (!fs.existsSync(currentDir)) return;
    const items = fs.readdirSync(currentDir);
    for (const item of items) {
      const fullPath = path.join(currentDir, item);
      
      // Strict path traversal prevention: must remain inside WORKSPACE_DIR
      const relative = path.relative(WORKSPACE_DIR, fullPath);
      if (relative.startsWith('..') || path.isAbsolute(relative)) {
        continue; // Block any traversal attempts
      }

      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        walkDir(fullPath);
      } else if (stat.isFile()) {
        const ext = path.extname(item);
        let lines = 0;
        let isReadable = true;

        try {
          const content = fs.readFileSync(fullPath, 'utf8');
          lines = content.split('\n').length;
        } catch {
          isReadable = false;
        }

        totalSizeBytes += stat.size;
        files.push({
          name: item,
          relativePath: relative,
          absolutePath: `[Container Sandbox] /app/.data/workspace/${relative}`,
          sizeBytes: stat.size,
          sizeFormatted: formatBytes(stat.size),
          extension: ext || 'none',
          lines,
          modifiedAt: stat.mtime.toISOString(),
          isReadable,
          category: getCategory(ext)
        });
      }
    }
  }

  walkDir(WORKSPACE_DIR);

  return {
    totalFiles: files.length,
    totalSizeBytes,
    totalSizeFormatted: formatBytes(totalSizeBytes),
    allowedScope: '.data/workspace/*',
    environment: 'Cloud Container Environment (Isolated)',
    scannedAt: new Date().toISOString(),
    files: files.sort((a, b) => a.relativePath.localeCompare(b.relativePath)),
    boundaryEnforced: true
  };
}

export function readWorkspaceFileContent(filePath: string): {
  success: boolean;
  content?: string;
  error?: string;
  metadata?: Partial<WorkspaceFileMetadata>;
} {
  // Path traversal check
  const target = path.resolve(WORKSPACE_DIR, filePath);
  const relative = path.relative(WORKSPACE_DIR, target);
  if (relative.startsWith('..') || path.isAbsolute(relative)) {
    return {
      success: false,
      error: 'Security Barrier Violation: Attempted out-of-bounds path traversal beyond .data/workspace'
    };
  }

  if (!fs.existsSync(target)) {
    return { success: false, error: 'File not found in workspace' };
  }

  const stat = fs.statSync(target);
  if (!stat.isFile()) {
    return { success: false, error: 'Target path is not a regular file' };
  }

  if (stat.size > 2 * 1024 * 1024) {
    return { success: false, error: 'File size exceeds maximum safe preview limit (2MB)' };
  }

  const content = fs.readFileSync(target, 'utf8');
  return {
    success: true,
    content,
    metadata: {
      name: path.basename(target),
      relativePath: relative,
      sizeBytes: stat.size,
      sizeFormatted: formatBytes(stat.size),
      modifiedAt: stat.mtime.toISOString()
    }
  };
}

// -------------------------------------------------------------
// Safe Math Calculator (Zero eval)
// -------------------------------------------------------------
export function evaluateSafeMath(expression: string): { success: boolean; result?: number; steps?: string[]; error?: string } {
  const sanitized = expression.trim();
  // Allow only digits, basic operators, parenthesis, decimal points, spaces
  if (!/^[0-9+\-*/%^().\s]+$/.test(sanitized)) {
    return { success: false, error: 'Invalid characters in mathematical expression. Only digits and operators (+, -, *, /, %, ^) are permitted.' };
  }

  try {
    // Safe tokenization and parser
    const safeExpr = sanitized.replace(/\^/g, '**');
    // Using Function without scope access to globals
    const fn = new Function(`"use strict"; return (${safeExpr});`);
    const val = fn();
    if (typeof val !== 'number' || isNaN(val) || !isFinite(val)) {
      return { success: false, error: 'Expression did not resolve to a finite numeric value.' };
    }
    return {
      success: true,
      result: val,
      steps: [
        `Expression sanitized: ${sanitized}`,
        `Operator normalization verified`,
        `Calculated result: ${val}`
      ]
    };
  } catch (err: any) {
    return { success: false, error: 'Arithmetic evaluation error: ' + err.message };
  }
}

// -------------------------------------------------------------
// System Diagnostics & Hardware Probing
// -------------------------------------------------------------
export function getSystemDiagnostics() {
  const mem = process.memoryUsage();
  const cpus = os.cpus();
  const isCodespaces = process.env.CODESPACES === 'true';
  const isCloudRun = Boolean(process.env.K_SERVICE);
  const containerEnvironment = isCodespaces || isCloudRun || fs.existsSync('/.dockerenv');
  const containerScope = isCodespaces
    ? 'GitHub Codespaces'
    : isCloudRun
      ? 'Google Cloud Run'
      : containerEnvironment
        ? 'Container (provider not identified)'
        : 'Host process (container not detected)';

  let gpuDetected = false;
  let gpuDevice: string | null = null;
  let gpuModel: string | null = null;
  let vramBytes = 0;
  let vramFormatted = 'UNAVAILABLE';
  let gpuStatus = 'No GPU device nodes or accelerators detected (CPU inference mode).';

  // 1. Probe using nvidia-smi if available on host
  try {
    const smiOutput = execSync(
      'nvidia-smi --query-gpu=gpu_name,memory.total,driver_version --format=csv,noheader,nounits',
      { timeout: 1500, stdio: ['ignore', 'pipe', 'ignore'], encoding: 'utf8' }
    ).trim();

    if (smiOutput) {
      const parts = smiOutput.split('\n')[0].split(',').map((s) => s.trim());
      if (parts[0]) {
        gpuDetected = true;
        gpuModel = parts[0];
        gpuDevice = parts[0];
        const totalMb = parseInt(parts[1], 10);
        if (!isNaN(totalMb) && totalMb > 0) {
          vramBytes = totalMb * 1024 * 1024;
          vramFormatted = formatBytes(vramBytes);
        }
        const driverVer = parts[2] ? ` (Driver ${parts[2]})` : '';
        gpuStatus = `NVIDIA GPU: ${gpuModel} [VRAM: ${vramFormatted}]${driverVer}`;
      }
    }
  } catch {
    // nvidia-smi not available or no nvidia card
  }

  // 2. Probe /dev nodes if nvidia-smi was not executed
  if (!gpuDetected) {
    try {
      if (fs.existsSync('/dev')) {
        const devFiles = fs.readdirSync('/dev');
        const nvidiaNode = devFiles.find((d) => /^nvidia(?:\d+|ctl|uvm)$/.test(d));
        if (nvidiaNode) {
          gpuDetected = true;
          gpuDevice = `/dev/${nvidiaNode}`;
          gpuStatus = `NVIDIA device node detected at /dev/${nvidiaNode}; GPU communications node active.`;
        } else if (devFiles.includes('kfd')) {
          gpuDetected = true;
          gpuDevice = '/dev/kfd';
          gpuStatus = 'AMD ROCm compute device node detected at /dev/kfd.';
        } else if (fs.existsSync('/dev/dri') && fs.readdirSync('/dev/dri').length > 0) {
          gpuDetected = true;
          gpuDevice = '/dev/dri';
          gpuStatus = 'Direct Rendering Infrastructure (DRI) graphics accelerator node detected.';
        }
      }
    } catch {
      // Ignore /dev reading error in sandboxed environment
    }
  }

  return {
    platform: os.platform(),
    osType: os.type(),
    arch: os.arch(),
    nodeVersion: process.version,
    uptimeSeconds: Math.floor(process.uptime()),
    systemUptimeSeconds: Math.floor(os.uptime()),
    containerEnvironment,
    containerScope,
    hostNotice: `Measurements come from Node process/os APIs inside ${containerScope}; they do not describe the user's separate computer.`,
    resourceSource: 'Node os.cpus(), os.totalmem(), os.freemem() and process.memoryUsage() in the app process',
    memory: {
      rssBytes: mem.rss,
      rssFormatted: formatBytes(mem.rss),
      heapTotalBytes: mem.heapTotal,
      heapTotalFormatted: formatBytes(mem.heapTotal),
      heapUsedBytes: mem.heapUsed,
      heapUsedFormatted: formatBytes(mem.heapUsed),
      systemTotalBytes: os.totalmem(),
      systemTotalFormatted: formatBytes(os.totalmem()),
      systemFreeBytes: os.freemem(),
      systemFreeFormatted: formatBytes(os.freemem())
    },
    cpu: {
      count: cpus.length,
      model: cpus[0]?.model || 'Container Virtual CPU',
      speedMHz: cpus[0]?.speed || 0,
      loadAvg: os.loadavg()
    },
    gpu: {
      detected: gpuDetected,
      device: gpuDevice,
      model: gpuModel,
      vramBytes,
      vramFormatted,
      status: gpuStatus
    }
  };
}

// -------------------------------------------------------------
// Local Model Probing (e.g. Ollama or local API)
// -------------------------------------------------------------
export async function probeLocalRuntime(endpoint: string = 'http://127.0.0.1:11434'): Promise<{
  connected: boolean;
  endpoint: string;
  models: string[];
  latencyMs: number;
  message: string;
}> {
  const startTime = Date.now();
  const cleanEndpoint = endpoint.replace(/\/+$/, '');
  
  // 1. Try Ollama /api/tags
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1500);

    const res = await fetch(`${cleanEndpoint}/api/tags`, {
      method: 'GET',
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    const latencyMs = Date.now() - startTime;
    if (res.ok) {
      const data = await res.json();
      const models = (data.models || []).map((m: any) => m.name || m.model || String(m));
      return {
        connected: true,
        endpoint: cleanEndpoint,
        models,
        latencyMs,
        message: `Local Runtime (Ollama) online. Detected ${models.length} model(s): [${models.join(', ')}].`
      };
    }
  } catch {
    // Try llama.cpp / OpenAI-compatible endpoint next
  }

  // 2. Try llama.cpp / OpenAI-compatible /v1/models
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1500);

    const res = await fetch(`${cleanEndpoint}/v1/models`, {
      method: 'GET',
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    const latencyMs = Date.now() - startTime;
    if (res.ok) {
      const data = await res.json();
      const models = (data.data || []).map((m: any) => m.id || String(m));
      return {
        connected: true,
        endpoint: cleanEndpoint,
        models,
        latencyMs,
        message: `Local Runtime (llama.cpp/OpenAI-compatible) online. Detected ${models.length} model(s): [${models.join(', ')}].`
      };
    }
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    return {
      connected: false,
      endpoint: cleanEndpoint,
      models: [],
      latencyMs,
      message: `Local Runtime not detected at ${cleanEndpoint} (${err.name === 'AbortError' ? 'Connection timed out' : 'Connection refused / Daemon offline'}).`
    };
  }

  const latencyMs = Date.now() - startTime;
  return {
    connected: false,
    endpoint: cleanEndpoint,
    models: [],
    latencyMs,
    message: `Local Runtime at ${cleanEndpoint} returned non-200 response.`
  };
}

// -------------------------------------------------------------
// Web Research with Real Search & SSRF Guard
// -------------------------------------------------------------
function isPrivateIpOrHost(hostname: string): boolean {
  if (['localhost', '127.0.0.1', '0.0.0.0', '::1', 'metadata.google.internal', '169.254.169.254'].includes(hostname.toLowerCase())) {
    return true;
  }
  // Check private RFC1918 ranges
  if (/^10\./.test(hostname) || /^192\.168\./.test(hostname) || /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(hostname)) {
    return true;
  }
  return false;
}

export async function performWebResearch(query: string): Promise<{
  success: boolean;
  query: string;
  provider: string;
  timestamp: string;
  results: Array<{ title: string; snippet: string; url: string; timestamp: string }>;
  error?: string;
}> {
  const sanitizedQuery = query.trim();
  if (!sanitizedQuery) {
    return { success: false, query, provider: 'none', timestamp: new Date().toISOString(), results: [], error: 'Search query is empty.' };
  }

  // SSRF checks on potential URL queries
  if (sanitizedQuery.startsWith('http://') || sanitizedQuery.startsWith('https://')) {
    try {
      const parsedUrl = new URL(sanitizedQuery);
      if (isPrivateIpOrHost(parsedUrl.hostname)) {
        return {
          success: false,
          query,
          provider: 'SSRF_SHIELD',
          timestamp: new Date().toISOString(),
          results: [],
          error: 'Security Barrier Blocked: Target domain is a private RFC1918 or loopback address.'
        };
      }
    } catch {
      // Not a pure URL, proceed with text search
    }
  }

  // Real Web Search via Wikipedia API + DuckDuckGo Instant API
  const results: Array<{ title: string; snippet: string; url: string; timestamp: string }> = [];
  const searchTimestamp = new Date().toISOString();

  try {
    // 1. Query DuckDuckGo Instant Answer API
    const ddgUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(sanitizedQuery)}&format=json&no_html=1&skip_disambig=1`;
    const ddgRes = await fetch(ddgUrl);
    if (ddgRes.ok) {
      const data = await ddgRes.json();
      if (data.AbstractText) {
        results.push({
          title: data.Heading || sanitizedQuery,
          snippet: data.AbstractText,
          url: data.AbstractURL || 'https://duckduckgo.com/?q=' + encodeURIComponent(sanitizedQuery),
          timestamp: searchTimestamp
        });
      }
      if (data.RelatedTopics && Array.isArray(data.RelatedTopics)) {
        for (const topic of data.RelatedTopics.slice(0, 3)) {
          if (topic.Text && topic.FirstURL) {
            results.push({
              title: topic.Text.split(' - ')[0] || sanitizedQuery,
              snippet: topic.Text,
              url: topic.FirstURL,
              timestamp: searchTimestamp
            });
          }
        }
      }
    }

    // 2. Query Wikipedia API for deep public knowledge
    const wikiUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(sanitizedQuery)}&utf8=&format=json&origin=*`;
    const wikiRes = await fetch(wikiUrl);
    if (wikiRes.ok) {
      const wikiData = await wikiRes.json();
      const searchItems = wikiData.query?.search || [];
      for (const item of searchItems.slice(0, 3)) {
        const cleanSnippet = item.snippet.replace(/<[^>]*>/g, '');
        results.push({
          title: item.title,
          snippet: cleanSnippet,
          url: `https://en.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/\s+/g, '_'))}`,
          timestamp: searchTimestamp
        });
      }
    }

    if (results.length === 0) {
      return {
        success: true,
        query: sanitizedQuery,
        provider: 'DuckDuckGo + Wikipedia Public Knowledge Base',
        timestamp: searchTimestamp,
        results: [],
        error: 'No verified search results found for the query in public knowledge providers.'
      };
    }

    return {
      success: true,
      query: sanitizedQuery,
      provider: 'DuckDuckGo + Wikipedia Public Knowledge Base',
      timestamp: searchTimestamp,
      results
    };
  } catch (err: any) {
    return {
      success: false,
      query: sanitizedQuery,
      provider: 'DuckDuckGo + Wikipedia',
      timestamp: searchTimestamp,
      results: [],
      error: 'Web research provider error: ' + err.message
    };
  }
}

// -------------------------------------------------------------
// Secret Scrubbing Utility for Security & Audit Ledger
// -------------------------------------------------------------
export function scrubSensitiveData(text: string): string {
  if (!text || typeof text !== 'string') return text;
  return text
    .replace(/(?:AIzaSy[A-Za-z0-9_-]{33})/g, 'AIzaSy[REDACTED_KEY]')
    .replace(/(?:Bearer\s+)[A-Za-z0-9._-]{20,}/gi, 'Bearer [REDACTED_TOKEN]')
    .replace(/(?:api[_-]?key["']?\s*[:=]\s*["'])[A-Za-z0-9_\-]{16,}(["'])/gi, '$1[REDACTED_KEY]$2');
}

// -------------------------------------------------------------
// ZYNTHEOR Provider Adapter Architecture (Independent Local-First Core)
// -------------------------------------------------------------
export interface InferenceParams {
  prompt: string;
  systemInstruction?: string;
  modelId?: string;
  endpoint?: string;
  temperature?: number;
  timeoutMs?: number;
  signal?: AbortSignal;
}

export interface InferenceResult {
  success: boolean;
  statusCode: number;
  errorCode?: 'local_runtime_unavailable' | 'model_not_found' | 'provider_missing_key' | 'runtime_timeout' | 'inference_error' | 'request_cancelled';
  provider: string;
  modelId: string;
  endpoint: string;
  response: string;
  latencyMs: number;
  tokensEstimate: number;
  status: 'PASS' | 'FAIL' | 'UNAVAILABLE' | 'BLOCKED' | 'NOT_TESTED';
  message?: string;
}

export interface InferenceProviderAdapter {
  id: string;
  name: string;
  isLocal: boolean;
  defaultEndpoint: string;
  probe(endpoint?: string): Promise<{ available: boolean; models: string[]; latencyMs: number; error?: string }>;
  execute(params: InferenceParams): Promise<InferenceResult>;
}

// Provider Registry Map
const providerRegistry = new Map<string, InferenceProviderAdapter>();

export function registerProviderAdapter(adapter: InferenceProviderAdapter) {
  providerRegistry.set(adapter.id.toUpperCase(), adapter);
}

export function getProviderAdapter(providerId: string): InferenceProviderAdapter | undefined {
  return providerRegistry.get(providerId.toUpperCase());
}

export function listRegisteredProviders() {
  return Array.from(providerRegistry.values()).map(a => ({
    id: a.id,
    name: a.name,
    isLocal: a.isLocal,
    defaultEndpoint: a.defaultEndpoint
  }));
}

// -------------------------------------------------------------
// Provider Adapter 1: LOCAL_OLLAMA & llama.cpp (Primary Sovereign Brain)
// -------------------------------------------------------------
const localOllamaAdapter: InferenceProviderAdapter = {
  id: 'LOCAL_OLLAMA',
  name: 'Local Sovereign AI Runtime (Ollama / llama.cpp)',
  isLocal: true,
  defaultEndpoint: 'http://127.0.0.1:11434',

  async probe(endpoint = 'http://127.0.0.1:11434') {
    const probe = await probeLocalRuntime(endpoint);
    return {
      available: probe.connected,
      models: probe.models,
      latencyMs: probe.latencyMs,
      error: probe.connected ? undefined : probe.message
    };
  },

  async execute(params: InferenceParams): Promise<InferenceResult> {
    const startTime = Date.now();
    const endpoint = (params.endpoint || process.env.LOCAL_AI_ENDPOINT || 'http://127.0.0.1:11434').replace(/\/+$/, '');

    // 1. Probe runtime availability first (Never fake, never fallback)
    const probe = await this.probe(endpoint);
    if (!probe.available || !probe.models || probe.models.length === 0) {
      const latencyMs = Date.now() - startTime;
      return {
        success: false,
        statusCode: 503,
        errorCode: 'local_runtime_unavailable',
        provider: 'LOCAL_OLLAMA',
        modelId: params.modelId || 'unassigned',
        endpoint,
        response: '',
        latencyMs,
        tokensEstimate: 0,
        status: 'UNAVAILABLE',
        message: `Local Runtime is unavailable at ${endpoint} (${probe.error || 'runtime offline or 0 models'}). Start your local runtime daemon ('ollama serve' or llama-server) and pull model weights. Per ZYNTHEOR Zero-Fake Policy, automatic cloud fallback is strictly disabled.`
      };
    }

    // 2. Check model existence if models detected
    const targetModel = params.modelId || (probe.models.length > 0 ? probe.models[0] : null);
    if (!targetModel) {
      const latencyMs = Date.now() - startTime;
      return {
        success: false,
        statusCode: 503,
        errorCode: 'local_runtime_unavailable',
        provider: 'LOCAL_OLLAMA',
        modelId: 'none',
        endpoint,
        response: '',
        latencyMs,
        tokensEstimate: 0,
        status: 'UNAVAILABLE',
        message: `No models found in Local Runtime at ${endpoint}. Run 'ollama pull <model>' to install a local model.`
      };
    }

    // Check if specified model is present in tags
    if (params.modelId && !probe.models.some(m =>
      m.toLowerCase() === params.modelId!.toLowerCase() ||
      m.toLowerCase().startsWith(params.modelId!.toLowerCase() + ':') ||
      params.modelId!.toLowerCase().startsWith(m.toLowerCase() + ':')
    )) {
      const latencyMs = Date.now() - startTime;
      return {
        success: false,
        statusCode: 503,
        errorCode: 'local_runtime_unavailable',
        provider: 'LOCAL_OLLAMA',
        modelId: params.modelId,
        endpoint,
        response: '',
        latencyMs,
        tokensEstimate: 0,
        status: 'UNAVAILABLE',
        message: `Model '${params.modelId}' is not installed in Local Runtime at ${endpoint}. Available: [${probe.models.join(', ')}]. Zero-Fake Policy prohibits faking output or falling back to external hosted models.`
      };
    }

    // 3. Execute actual local model inference
    let timeoutId: ReturnType<typeof setTimeout> | undefined;
    let timeoutMs = 90000;
    try {
      if (params.signal?.aborted) {
        return {
          success: false,
          statusCode: 503,
          errorCode: 'request_cancelled',
          provider: 'LOCAL_OLLAMA',
          modelId: targetModel,
          endpoint,
          response: '',
          latencyMs: Date.now() - startTime,
          tokensEstimate: 0,
          status: 'UNAVAILABLE',
          message: 'Local inference request was cancelled by the client.',
        };
      }
      // Keep the Core API timeout aligned with the Local Provider timeout.
      // Bound request overrides so a client cannot disable timeout protection.
      const configuredTimeout = Number(process.env.LOCAL_AI_TIMEOUT_MS || 90000);
      const defaultTimeout = Number.isFinite(configuredTimeout)
        ? Math.max(10000, Math.min(Math.floor(configuredTimeout), 180000))
        : 90000;
      const requestedTimeout = typeof params.timeoutMs === 'number' && Number.isFinite(params.timeoutMs)
        ? Math.floor(params.timeoutMs)
        : defaultTimeout;
      timeoutMs = Math.max(10000, Math.min(requestedTimeout, 180000));
      const controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      const effectiveSignal = params.signal ? AbortSignal.any([params.signal, controller.signal]) : controller.signal;

      // Strategy A: Try Ollama /api/chat
      let textOutput = '';
      let executionSuccess = false;

      try {
        const chatRes = await fetch(`${endpoint}/api/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({
            model: targetModel,
            messages: [
              ...(params.systemInstruction ? [{ role: 'system', content: params.systemInstruction }] : []),
              { role: 'user', content: params.prompt }
            ],
            stream: false
          }),
          signal: effectiveSignal
        });

        if (chatRes.ok) {
          const chatData = await chatRes.json();
          const content = chatData?.message?.content || chatData?.response;
          if (typeof content === 'string' && content.trim()) {
            textOutput = content;
            executionSuccess = true;
          }
        }
      } catch (err: any) {
        if (params.signal?.aborted || err?.name === 'AbortError') throw err;
      }

      // Strategy B: Try OpenAI-compatible /v1/chat/completions (llama.cpp server)
      if (!executionSuccess) {
        try {
          const v1Res = await fetch(`${endpoint}/v1/chat/completions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({
              model: targetModel,
              messages: [
                ...(params.systemInstruction ? [{ role: 'system', content: params.systemInstruction }] : []),
                { role: 'user', content: params.prompt }
              ],
              stream: false
            }),
            signal: effectiveSignal
          });

          if (v1Res.ok) {
            const v1Data = await v1Res.json();
            const content = v1Data?.choices?.[0]?.message?.content;
            if (typeof content === 'string' && content.trim()) {
              textOutput = content;
              executionSuccess = true;
            }
          }
        } catch (err: any) {
          if (params.signal?.aborted || err?.name === 'AbortError') throw err;
        }
      }

      // Strategy C: Try Ollama legacy /api/generate
      if (!executionSuccess) {
        try {
          const genRes = await fetch(`${endpoint}/api/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({
              model: targetModel,
              prompt: params.prompt,
              system: params.systemInstruction,
              stream: false
            }),
            signal: effectiveSignal
          });

          if (genRes.ok) {
            const genData = await genRes.json();
            const content = genData?.response;
            if (typeof content === 'string' && content.trim()) {
              textOutput = content;
              executionSuccess = true;
            }
          }
        } catch (err: any) {
          if (params.signal?.aborted || err?.name === 'AbortError') throw err;
        }
      }

      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;

      if (!executionSuccess) {
        return {
          success: false,
          statusCode: 503,
          errorCode: 'local_runtime_unavailable',
          provider: 'LOCAL_OLLAMA',
          modelId: targetModel,
          endpoint,
          response: '',
          latencyMs,
          tokensEstimate: 0,
          status: 'FAIL',
          message: `Local Runtime at ${endpoint} returned error or unparseable response. Zero-Fake Policy strictly disallows automatic fallback to hosted LLMs.`
        };
      }

      return {
        success: true,
        statusCode: 200,
        provider: 'LOCAL_OLLAMA',
        modelId: targetModel,
        endpoint,
        response: textOutput,
        latencyMs,
        tokensEstimate: Math.round((params.prompt.length + textOutput.length) / 4),
        status: 'PASS'
      };
    } catch (err: any) {
      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;
      const isTimeout = err?.name === 'AbortError' && !params.signal?.aborted;
      return {
        success: false,
        statusCode: 503,
        errorCode: params.signal?.aborted ? 'request_cancelled' : 'local_runtime_unavailable',
        provider: 'LOCAL_OLLAMA',
        modelId: targetModel,
        endpoint,
        response: '',
        latencyMs,
        tokensEstimate: 0,
        status: params.signal?.aborted ? 'UNAVAILABLE' : 'FAIL',
        message: params.signal?.aborted
          ? 'Local inference request was cancelled by the client.'
          : isTimeout
            ? `Local runtime inference timed out after ${timeoutMs}ms at ${endpoint}. Zero-Fake Policy strictly disallows automatic fallback to hosted LLMs.`
            : `Inference failed on Local Runtime at ${endpoint}: ${err.message || 'connection failed'}. Zero-Fake Policy strictly disallows automatic fallback to hosted LLMs.`
      };
    }
  }
};

// Register default providers and aliases
registerProviderAdapter(localOllamaAdapter);
providerRegistry.set('LOCAL', localOllamaAdapter);
providerRegistry.set('LOCAL_RUNTIME', localOllamaAdapter);
providerRegistry.set('OLLAMA', localOllamaAdapter);
providerRegistry.set('LLAMACPP', localOllamaAdapter);

// -------------------------------------------------------------
// Core Inference Dispatcher (Strict Selection - ZERO Automatic Fallback)
// -------------------------------------------------------------
export async function executeInference(
  prompt: string,
  systemInstruction?: string,
  providerId: string = 'LOCAL',
  modelId?: string,
  endpoint?: string,
  signal?: AbortSignal,
  timeoutMs?: number
): Promise<InferenceResult> {
  const chosenProviderId = (providerId || 'LOCAL').toUpperCase();
  const adapter = getProviderAdapter(chosenProviderId);

  // If selected provider is not registered:
  if (!adapter) {
    return {
      success: false,
      statusCode: 400,
      provider: chosenProviderId,
      modelId: modelId || 'unassigned',
      endpoint: endpoint || 'none',
      response: '',
      latencyMs: 0,
      tokensEstimate: 0,
      status: 'NOT_TESTED',
      message: `Provider '${chosenProviderId}' is not registered in ZYNTHEOR Core. Registered providers: [${listRegisteredProviders().map(p => p.id).join(', ')}]`
    };
  }

  // Execute ONLY the chosen provider. Strict Zero-Fake Policy:
  // If the chosen provider fails or is offline, return its error immediately!
  // NEVER switch to another provider automatically!
  return await adapter.execute({
    prompt,
    systemInstruction,
    modelId,
    endpoint,
    signal,
    timeoutMs
  });
}

