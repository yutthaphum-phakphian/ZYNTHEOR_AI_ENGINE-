import { mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import { loadWorkspaceMemory, saveWorkspaceMemory, type ContextFact } from "./contextEngine.js";
import { saveAgentEvent } from "./store.js";

export interface MemoryRetentionPolicy {
  workspaceId: string;
  persistentMemoryDays: number | null;
  preserveVerifiedFacts: boolean;
  updatedAt: string;
}

const policyDir = () => process.env.MEMORY_RETENTION_DIR || join(process.cwd(), ".data", "memory-retention");
function safeWorkspaceId(value: string): string {
  if (typeof value !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(value)) throw new Error("invalid_workspace_id");
  return value;
}
function policyPath(id: string) { return join(policyDir(), `${safeWorkspaceId(id)}.json`); }
function validateDays(value: unknown): value is number | null {
  return value === null || (typeof value === "number" && Number.isInteger(value) && value >= 1 && value <= 3650);
}

export async function getMemoryRetentionPolicy(workspaceId: string): Promise<MemoryRetentionPolicy> {
  const id = safeWorkspaceId(workspaceId);
  try {
    const parsed: unknown = JSON.parse(await readFile(policyPath(id), "utf8"));
    if (!parsed || typeof parsed !== "object") throw new Error("malformed_retention_policy");
    const p = parsed as Record<string, unknown>;
    if (p.workspaceId !== id || !validateDays(p.persistentMemoryDays) || typeof p.preserveVerifiedFacts !== "boolean" || typeof p.updatedAt !== "string" || !Number.isFinite(Date.parse(p.updatedAt))) throw new Error("malformed_retention_policy");
    return p as unknown as MemoryRetentionPolicy;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return { workspaceId: id, persistentMemoryDays: null, preserveVerifiedFacts: true, updatedAt: new Date(0).toISOString() };
    throw error;
  }
}

export async function setMemoryRetentionPolicy(workspaceId: string, input: { persistentMemoryDays: number | null; preserveVerifiedFacts: boolean }): Promise<MemoryRetentionPolicy> {
  const id = safeWorkspaceId(workspaceId);
  if (!validateDays(input?.persistentMemoryDays) || typeof input?.preserveVerifiedFacts !== "boolean") throw new Error("invalid_retention_policy");
  const policy: MemoryRetentionPolicy = { workspaceId: id, ...input, updatedAt: new Date().toISOString() };
  const dir = policyDir();
  await mkdir(dir, { recursive: true });
  const target = policyPath(id);
  const temp = `${target}.${randomUUID()}.tmp`;
  try {
    await writeFile(temp, JSON.stringify(policy, null, 2), { encoding: "utf8", flag: "wx" });
    await rename(temp, target);
  } catch (error) {
    await unlink(temp).catch(() => undefined);
    throw error;
  }
  await saveAgentEvent({ id: `memory_retention_${randomUUID()}`, type: "memory_retention_policy_updated", at: policy.updatedAt, data: { workspaceId: id, persistentMemoryDays: policy.persistentMemoryDays, preserveVerifiedFacts: policy.preserveVerifiedFacts } });
  return policy;
}

/** Explicit, auditable retention sweep. A null day limit disables age-based deletion. */
export async function enforceMemoryRetention(workspaceId: string, now = Date.now()): Promise<{ examined: number; deleted: number; preservedVerified: number; policy: MemoryRetentionPolicy }> {
  const id = safeWorkspaceId(workspaceId);
  const policy = await getMemoryRetentionPolicy(id);
  const memory = await loadWorkspaceMemory(id);
  if (policy.persistentMemoryDays === null) return { examined: memory.facts.length, deleted: 0, preservedVerified: 0, policy };
  const cutoff = now - policy.persistentMemoryDays * 24 * 60 * 60 * 1000;
  const kept: ContextFact[] = [];
  const deletedIds: string[] = [];
  let preservedVerified = 0;
  for (const fact of memory.facts) {
    const timestamp = Date.parse(fact.updatedAt);
    const expired = Number.isFinite(timestamp) && timestamp < cutoff;
    if (expired && policy.preserveVerifiedFacts && fact.verified) {
      preservedVerified++;
      kept.push(fact);
    } else if (expired) deletedIds.push(fact.id);
    else kept.push(fact);
  }
  if (deletedIds.length) {
    await saveWorkspaceMemory(id, { ...memory, facts: kept, updatedAt: new Date(now).toISOString() });
    await saveAgentEvent({ id: `memory_retention_sweep_${randomUUID()}`, type: "memory_retention_sweep_completed", at: new Date(now).toISOString(), data: { workspaceId: id, examined: memory.facts.length, deleted: deletedIds.length, deletedFactIds: deletedIds, preservedVerified } });
  }
  return { examined: memory.facts.length, deleted: deletedIds.length, preservedVerified, policy };
}
