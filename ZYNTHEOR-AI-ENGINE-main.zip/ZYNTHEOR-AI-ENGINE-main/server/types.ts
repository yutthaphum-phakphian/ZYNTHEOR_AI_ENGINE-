/**
 * ZYNTHEOR AI ENGINE - Type Definitions
 * Sovereign Local AI Runtime Architecture
 */

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
  timestamp?: number;
}

export type LocalRuntimeType = 'ollama' | 'llamacpp' | 'openai-compatible';

export interface LocalRuntimeConfig {
  endpoint: string;
  model: string;
  runtimeType: LocalRuntimeType;
  timeoutMs: number;
  temperature?: number;
  topP?: number;
  maxTokens?: number;
}

export interface RuntimeStatus {
  status: 'online' | 'offline';
  endpoint: string;
  model: string;
  runtimeType: LocalRuntimeType;
  availableModels: string[];
  latencyMs?: number;
  error?: string;
  lastChecked: number;
  isZeroFakeVerified: boolean;
  versionInfo?: string;
}

export interface HostedProviderConfig {
  providerName: 'openai' | 'anthropic' | 'groq';
  apiKey: string;
  modelName: string;
  explicitUserConsent: boolean;
}

export interface ChatRequest {
  messages: ChatMessage[];
  provider?: 'local' | 'hosted';
  model?: string;
  systemPrompt?: string;
  temperature?: number;
  hostedConfig?: HostedProviderConfig;
}

export interface ZeroFakeAttestation {
  disposition: 'genuine_local_inference' | 'explicit_hosted_inference';
  fallbackTriggered: false;
  runtimeHost: string;
  verifiedTimestamp: number;
}

export interface ChatResponse {
  content: string;
  model: string;
  provider: 'local' | 'hosted';
  runtimeEndpoint: string;
  tokensUsed?: {
    prompt?: number;
    completion?: number;
    total?: number;
  };
  executionTimeMs: number;
  zeroFakeAttestation: ZeroFakeAttestation;
}

export interface ErrorResponse503 {
  error: string;
  code: 'local_runtime_unavailable';
  details: string;
  runtimeConfig: {
    provider: 'local';
    endpoint: string;
    model: string;
    runtimeType: string;
  };
  fallbackTriggered: false;
  remediationSteps: string[];
}
