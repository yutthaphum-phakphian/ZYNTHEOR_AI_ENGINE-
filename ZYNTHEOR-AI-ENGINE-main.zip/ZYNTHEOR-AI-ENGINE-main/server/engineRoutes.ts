/**
 * Request-handling logic for the read-only engine endpoints (kept out of server/index.ts so it is unit-testable):
 *   GET  /api/engine/connectors  -> real connector status from the hub
 *   POST /api/engine/route       -> { message, mode? } -> FAST/DEEP decision + connector availability
 * Neither endpoint executes anything or calls a connector.
 */
import { connectorHub, type ConnectorHub } from "./connectorHub.js";
import { listLessons } from "./learningLoop.js";
import { resolveConnectorHints, selectEngineMode } from "./modeSelector.js";
import { createWebResearchAdapter } from "./connectors/webResearch.js";
import { createGitHubAdapter } from "./connectors/github.js";
import { registerWebFetchTool, registerWebSearchTool, registerGitHubTools } from "./agent.js";
import { validateCustomConfig, DEFAULT_CUSTOM_CONFIG, type CustomEngineConfig } from "./customConfig.js";

const ALLOWED_MODES = new Set(["qa", "plan", "code", "review", "auto", "custom"]);

/**
 * Install real adapters where available; keep the rest as honest
 * declared-but-not-installed placeholders. Idempotent for practical purposes
 * (register overwrites; declare is a no-op once an adapter exists).
 */
export function declareDefaultConnectors(hub: ConnectorHub = connectorHub): void {
  // Real adapters
  hub.register(createWebResearchAdapter());
  hub.grant("web_research", "read");

  hub.register(createGitHubAdapter());
  hub.grant("github", "read");

  // Expose as agent tools so plans can call them.
  registerWebFetchTool();
  registerWebSearchTool();
  registerGitHubTools();

  // Still placeholders until real adapters land.
  hub.declare({ id: "file_store", label: "File storage", permissions: ["read", "write"] });
  hub.declare({ id: "external_api", label: "External API", permissions: ["call_api"] });
}

export async function handleListConnectors(hub: ConnectorHub = connectorHub) {
  return { status: 200, body: { connectors: await hub.list() } };
}

export async function handleValidateCustomConfig(body: unknown) {
  const result = validateCustomConfig(body);
  if (!result.ok) {
    return { status: 400, body: { status: "blocked", code: result.code, errors: result.errors } };
  }
  return { status: 200, body: { status: "valid", config: result.config } };
}

export async function handleRoute(body: unknown, hub: ConnectorHub = connectorHub) {
  const bad = (code: string, extra?: Record<string, unknown>) => ({
    status: 400,
    body: { status: "blocked", code, ...(extra || {}) },
  });
  if (typeof body !== "object" || body === null || Array.isArray(body)) return bad("invalid_route_request");
  const { message, mode, depth, customConfig, ...rest } = body as Record<string, unknown>;
  if (Object.keys(rest).length > 0) return bad("invalid_route_request");
  if (typeof message !== "string" || !message.trim() || message.length > 8000) return bad("invalid_route_request");
  if (mode !== undefined && (typeof mode !== "string" || !ALLOWED_MODES.has(mode))) return bad("invalid_mode");

  if (depth !== undefined && depth !== "FAST" && depth !== "DEEP") return bad("invalid_depth");

  let validatedCustomConfig: CustomEngineConfig | undefined = undefined;
  if (customConfig !== undefined) {
    const valResult = validateCustomConfig(customConfig);
    if (!valResult.ok) {
      return bad("invalid_custom_config", { errors: valResult.errors });
    }
    validatedCustomConfig = valResult.config;
  } else if (mode === "custom") {
    validatedCustomConfig = DEFAULT_CUSTOM_CONFIG;
  }

  const decision = selectEngineMode(
    message,
    mode === "auto" ? undefined : (mode as string | undefined),
    depth as "FAST" | "DEEP" | undefined,
    validatedCustomConfig
  );
  const connectors = await resolveConnectorHints(hub, decision.connectorHints);
  const limitations = [
    `depth ${decision.depth}: ${decision.depth === "DEEP" ? "deep reasoning pipeline active with multi-query research, hypothesis verification, and contradiction checks" : "fast reasoning pipeline active with direct single-pass verification"}`,
    mode === "custom"
      ? `custom mode active: enforcing user-defined policy (depth=${validatedCustomConfig?.depth || 'AUTO'}, approval=${validatedCustomConfig?.requiresApproval ?? false}, allowWrites=${validatedCustomConfig?.allowFileModifications ?? true})`
      : "mode code/plan/review are applied by local engine",
  ];
  return { status: 200, body: { decision, connectors, limitations } };
}

/** Read-only view of what the engine has learned, with status so unvalidated lessons are never mistaken for knowledge. */
export async function handleListLessons() {
  return { status: 200, body: { lessons: await listLessons() } };
}

