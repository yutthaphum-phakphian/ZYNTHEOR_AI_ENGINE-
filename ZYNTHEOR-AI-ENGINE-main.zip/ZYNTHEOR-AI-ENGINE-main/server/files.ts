import { extname, basename, normalize, join, resolve, sep, dirname } from "node:path";
import { mkdir, writeFile, readFile, readdir, unlink, stat, lstat, realpath, rm, rename } from "node:fs/promises";
import { createHash, randomUUID } from "node:crypto";
import { inflateRawSync } from "node:zlib";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { tmpdir } from "node:os";
import { redactSecrets } from "./store.js";

const execFileAsync = promisify(execFile);

export type ReadFileStatus = "READ_SUCCESS" | "UNSUPPORTED" | "TOO_LARGE" | "BLOCKED" | "ERROR";

export type InspectedFile = {
  name: string;
  size: number;
  mimeType: string;
  extension: string;
  status: ReadFileStatus;
  statusMessage?: string;
  content?: string;
  isTruncated?: boolean;
  lineCount?: number;
  schemaValidation?: ManifestSchemaValidationResult;
};

export type ZipEntryItem = {
  path: string;
  name: string;
  size: number;
  uncompressedSize: number;
  isDirectory: boolean;
  status: ReadFileStatus;
  statusMessage?: string;
  content?: string;
};

export type ZipInspectionResult = {
  status: "INSPECTED" | "BLOCKED" | "ERROR";
  reason?: string;
  totalEntries: number;
  entries: ZipEntryItem[];
};

// Security limits
export const MAX_INDIVIDUAL_FILE_SIZE = 1 * 1024 * 1024; // 1 MB limit per file
export const MAX_TEXT_PREVIEW_SIZE = 100 * 1024; // 100 KB max text returned to AI context / view
export const MAX_ZIP_TOTAL_UNCOMPRESSED = 10 * 1024 * 1024; // 10 MB total uncompressed (ZIP bomb guard)
export const MAX_ZIP_ENTRIES = 500; // max entries inside a ZIP archive
export const MAX_COMPRESSION_RATIO = 100; // uncompressed to compressed ratio guard

const SUPPORTED_TEXT_EXTENSIONS = new Set([
  // Source Code
  ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs",
  ".py", ".rb", ".go", ".rs", ".java", ".c", ".cpp", ".h", ".hpp", ".cs", ".php",
  ".sh", ".bash", ".zsh",
  // Web & Config & Data
  ".html", ".htm", ".css", ".scss", ".sass", ".less",
  ".json", ".jsonc", ".jsonl", ".yaml", ".yml", ".toml", ".xml", ".svg",
  ".md", ".markdown", ".txt", ".rst", ".log", ".env.example", ".gitignore",
  ".dockerfile", ".editorconfig", ".npmrc"
]);

const BLOCKED_EXTENSIONS = new Set([
  // Executable binaries & scripts to prevent any execution
  ".exe", ".bat", ".cmd", ".com", ".vbs", ".msi", ".dll", ".so", ".dylib",
  ".bin", ".app", ".dmg", ".iso"
]);

// Sensitive filename patterns that must be blocked
const BLOCKED_FILENAME_PATTERNS = [
  /^\.env(?!\.example$)/i, // .env, .env.local, .env.production etc. (allow .env.example)
  /^id_rsa/i,
  /^id_ed25519/i,
  /\.pem$/i,
  /\.key$/i,
  /\.pfx$/i,
  /\.p12$/i,
  /credentials\.json$/i,
  /service-account.*\.json$/i
];

export function isBlockedFilename(filename: string): boolean {
  const base = basename(filename);
  for (const pattern of BLOCKED_FILENAME_PATTERNS) {
    if (pattern.test(base)) return true;
  }
  return false;
}

export function detectFileExtension(filename: string): string {
  const ext = extname(filename).toLowerCase();
  if (ext) return ext;
  const base = basename(filename).toLowerCase();
  if (base.startsWith(".")) return base;
  return "";
}

export function isTextExtension(extension: string): boolean {
  return SUPPORTED_TEXT_EXTENSIONS.has(extension);
}

export function listSupportedTextExtensions(): string[] {
  return Array.from(SUPPORTED_TEXT_EXTENSIONS);
}

export function isExecutableExtension(extension: string): boolean {
  return BLOCKED_EXTENSIONS.has(extension);
}

/**
 * Inspects a single file buffer or string safely.
 */
export function inspectFile(
  filename: string,
  buffer: Buffer,
  declaredMimeType?: string
): InspectedFile {
  const cleanName = basename(filename);
  const size = buffer.length;
  const ext = detectFileExtension(cleanName);
  const mimeType = declaredMimeType || (isTextExtension(ext) ? "text/plain" : "application/octet-stream");

  // Check 1: Sensitive file pattern
  if (isBlockedFilename(cleanName)) {
    return {
      name: cleanName,
      size,
      mimeType,
      extension: ext,
      status: "BLOCKED",
      statusMessage: "File contains sensitive configuration or credentials pattern and is blocked from inspection."
    };
  }

  // Check 2: Executable extension
  if (isExecutableExtension(ext)) {
    return {
      name: cleanName,
      size,
      mimeType,
      extension: ext,
      status: "BLOCKED",
      statusMessage: "Executable binary or script files are strictly blocked for security."
    };
  }

  // Check 3: Max file size
  if (size > MAX_INDIVIDUAL_FILE_SIZE) {
    return {
      name: cleanName,
      size,
      mimeType,
      extension: ext,
      status: "TOO_LARGE",
      statusMessage: `File exceeds maximum allowed size of 1 MB (${(size / 1024).toFixed(1)} KB).`
    };
  }

  // Check 4: Text content check
  if (!isTextExtension(ext) && !isLikelyPlainText(buffer)) {
    return {
      name: cleanName,
      size,
      mimeType,
      extension: ext,
      status: "UNSUPPORTED",
      statusMessage: `Binary or unsupported file format (${ext || "unknown"}). Only UTF-8 text and source code can be inspected.`
    };
  }

  // Check 5: Read and decode UTF-8 safely
  try {
    const rawContent = buffer.toString("utf8");
    // Check for null bytes which indicate binary file masquerading as text
    if (rawContent.includes("\0")) {
      return {
        name: cleanName,
        size,
        mimeType,
        extension: ext,
        status: "UNSUPPORTED",
        statusMessage: "File contains binary null bytes and cannot be displayed as source text."
      };
    }

    // Secret redaction to ensure no accidental secrets leak
    const redacted = redactSecrets(rawContent);
    const lines = redacted.split("\n");
    const isTruncated = redacted.length > MAX_TEXT_PREVIEW_SIZE;
    const finalContent = isTruncated ? redacted.slice(0, MAX_TEXT_PREVIEW_SIZE) + "\n\n/* [Content truncated due to size limit] */" : redacted;

    let schemaValidation: ManifestSchemaValidationResult | undefined;
    if (cleanName.toLowerCase() === "app.json") {
      schemaValidation = validateAppManifestSchema(rawContent);
    }

    return {
      name: cleanName,
      size,
      mimeType,
      extension: ext,
      status: "READ_SUCCESS",
      content: finalContent,
      isTruncated,
      lineCount: lines.length,
      schemaValidation
    };
  } catch (error) {
    return {
      name: cleanName,
      size,
      mimeType,
      extension: ext,
      status: "ERROR",
      statusMessage: error instanceof Error ? error.message : "Failed to read file content."
    };
  }
}

function isLikelyPlainText(buf: Buffer): boolean {
  if (buf.length === 0) return true;
  const sample = buf.subarray(0, Math.min(buf.length, 512));
  for (let i = 0; i < sample.length; i++) {
    const byte = sample[i];
    if (byte === 0) return false; // null byte
  }
  return true;
}

/**
 * Safe ZIP Parser:
 * - Reads ZIP Central Directory / Local Headers without executing anything
 * - Guard against ZIP bomb: max entries, max uncompressed size, compression ratio check
 * - Guard against Path Traversal: reject '../', absolute paths, backslashes
 */
export function inspectZipBuffer(zipBuffer: Buffer): ZipInspectionResult {
  if (zipBuffer.length < 22) {
    return { status: "ERROR", reason: "Invalid ZIP file: too short", totalEntries: 0, entries: [] };
  }

  // 1. Locate End of Central Directory Record (EOCD)
  // EOCD signature is 0x06054b50
  let eocdOffset = -1;
  const maxSearch = Math.min(zipBuffer.length, 65535 + 22);
  for (let i = zipBuffer.length - 22; i >= zipBuffer.length - maxSearch; i--) {
    if (zipBuffer.readUInt32LE(i) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }

  if (eocdOffset === -1) {
    return { status: "ERROR", reason: "Could not find ZIP End of Central Directory record", totalEntries: 0, entries: [] };
  }

  const totalEntries = zipBuffer.readUInt16LE(eocdOffset + 10);
  const cdSize = zipBuffer.readUInt32LE(eocdOffset + 12);
  const cdOffset = zipBuffer.readUInt32LE(eocdOffset + 16);

  if (totalEntries > MAX_ZIP_ENTRIES) {
    return {
      status: "BLOCKED",
      reason: `ZIP contains ${totalEntries} entries, exceeding maximum limit of ${MAX_ZIP_ENTRIES}.`,
      totalEntries,
      entries: []
    };
  }

  if (cdOffset + cdSize > zipBuffer.length) {
    return { status: "ERROR", reason: "Corrupted ZIP: Central Directory bounds exceed buffer", totalEntries, entries: [] };
  }

  let currentOffset = cdOffset;
  let totalCalculatedUncompressed = 0;
  const entries: ZipEntryItem[] = [];

  for (let idx = 0; idx < totalEntries; idx++) {
    if (currentOffset + 46 > zipBuffer.length) {
      break;
    }
    const signature = zipBuffer.readUInt32LE(currentOffset);
    if (signature !== 0x02014b50) {
      break; // central directory header signature
    }

    const compressionMethod = zipBuffer.readUInt16LE(currentOffset + 10);
    const compressedSize = zipBuffer.readUInt32LE(currentOffset + 20);
    const uncompressedSize = zipBuffer.readUInt32LE(currentOffset + 24);
    const fileNameLength = zipBuffer.readUInt16LE(currentOffset + 28);
    const extraFieldLength = zipBuffer.readUInt16LE(currentOffset + 30);
    const fileCommentLength = zipBuffer.readUInt16LE(currentOffset + 32);
    const localHeaderOffset = zipBuffer.readUInt32LE(currentOffset + 42);

    const nameStart = currentOffset + 46;
    const rawPath = zipBuffer.toString("utf8", nameStart, nameStart + fileNameLength);

    currentOffset = nameStart + fileNameLength + extraFieldLength + fileCommentLength;

    // Security check: Path traversal prevention
    const normalized = normalize(rawPath.replace(/\\/g, "/"));
    if (
      normalized.startsWith("/") ||
      normalized.startsWith("../") ||
      normalized.includes("/../") ||
      rawPath.includes("..")
    ) {
      return {
        status: "BLOCKED",
        reason: `ZIP contains path traversal attempt in entry: "${rawPath}". Entire archive blocked for safety.`,
        totalEntries,
        entries: []
      };
    }

    const isDirectory = rawPath.endsWith("/") || rawPath.endsWith("\\");
    totalCalculatedUncompressed += uncompressedSize;

    // ZIP bomb compression ratio check
    if (!isDirectory && compressedSize > 0) {
      const ratio = uncompressedSize / compressedSize;
      if (ratio > MAX_COMPRESSION_RATIO && uncompressedSize > 1024 * 1024) {
        return {
          status: "BLOCKED",
          reason: `ZIP bomb detected: entry "${rawPath}" compression ratio (${ratio.toFixed(0)}:1) exceeds safe limit.`,
          totalEntries,
          entries: []
        };
      }
    }

    if (totalCalculatedUncompressed > MAX_ZIP_TOTAL_UNCOMPRESSED) {
      return {
        status: "BLOCKED",
        reason: `ZIP uncompressed size exceeds safe limit of 10 MB (detected ${Math.round(totalCalculatedUncompressed / 1024 / 1024)} MB).`,
        totalEntries,
        entries: []
      };
    }

    const ext = detectFileExtension(normalized);
    let status: ReadFileStatus = "READ_SUCCESS";
    let statusMessage: string | undefined;
    let content: string | undefined;

    if (isDirectory) {
      status = "READ_SUCCESS";
    } else if (isBlockedFilename(normalized)) {
      status = "BLOCKED";
      statusMessage = "Sensitive file configuration or credential pattern blocked.";
    } else if (isExecutableExtension(ext)) {
      status = "BLOCKED";
      statusMessage = "Executable binary or script blocked for security.";
    } else if (uncompressedSize > MAX_INDIVIDUAL_FILE_SIZE) {
      status = "TOO_LARGE";
      statusMessage = `File exceeds 1 MB limit (${(uncompressedSize / 1024).toFixed(1)} KB).`;
    } else if (!isTextExtension(ext)) {
      status = "UNSUPPORTED";
      statusMessage = `Binary or non-text file extension (${ext || "unknown"}).`;
    } else {
      // Decompress safely
      try {
        const decompressed = extractLocalZipEntry(zipBuffer, localHeaderOffset, compressionMethod, compressedSize, uncompressedSize);
        if (decompressed) {
          if (!isLikelyPlainText(decompressed)) {
            status = "UNSUPPORTED";
            statusMessage = "Binary content detected in file.";
          } else {
            const raw = decompressed.toString("utf8");
            if (raw.includes("\0")) {
              status = "UNSUPPORTED";
              statusMessage = "File contains null bytes.";
            } else {
              const redacted = redactSecrets(raw);
              content = redacted.length > MAX_TEXT_PREVIEW_SIZE
                ? redacted.slice(0, MAX_TEXT_PREVIEW_SIZE) + "\n\n/* [Content truncated due to size limit] */"
                : redacted;
              status = "READ_SUCCESS";
            }
          }
        } else {
          status = "ERROR";
          statusMessage = "Could not decompress file entry.";
        }
      } catch (err) {
        status = "ERROR";
        statusMessage = err instanceof Error ? err.message : "Decompression error.";
      }
    }

    entries.push({
      path: normalized,
      name: basename(normalized) || normalized,
      size: compressedSize,
      uncompressedSize,
      isDirectory,
      status,
      statusMessage,
      content
    });
  }

  return {
    status: "INSPECTED",
    totalEntries: entries.length,
    entries
  };
}

function extractLocalZipEntry(
  zipBuffer: Buffer,
  localHeaderOffset: number,
  compressionMethod: number,
  compressedSize: number,
  uncompressedSize: number
): Buffer | null {
  if (localHeaderOffset + 30 > zipBuffer.length) return null;
  const sig = zipBuffer.readUInt32LE(localHeaderOffset);
  if (sig !== 0x04034b50) return null;

  const fnLen = zipBuffer.readUInt16LE(localHeaderOffset + 26);
  const extraLen = zipBuffer.readUInt16LE(localHeaderOffset + 28);
  const dataStart = localHeaderOffset + 30 + fnLen + extraLen;

  if (dataStart + compressedSize > zipBuffer.length) return null;
  const data = zipBuffer.subarray(dataStart, dataStart + compressedSize);

  if (compressionMethod === 0) {
    // Stored (no compression)
    return Buffer.from(data);
  } else if (compressionMethod === 8) {
    // Deflated (standard ZIP deflate uses raw deflate without zlib wrapper)
    const inflated = inflateRawSync(data, { maxOutputLength: uncompressedSize + 1024 });
    return inflated;
  }
  return null;
}

export type WorkspaceFileRecord = {
  name: string;
  path: string;
  size: number;
  lineCount: number;
  content: string;
  updatedAt: string;
  hash: string;
};

export class WorkspaceFileError extends Error {
  constructor(public readonly code: string, message: string, public readonly statusCode: number) {
    super(message);
  }
}

export const MAX_WORKSPACE_FILES = Number(process.env.MAX_WORKSPACE_FILES) || 100;
export const MAX_WORKSPACE_TOTAL_SIZE = Number(process.env.MAX_WORKSPACE_TOTAL_SIZE) || 5 * 1024 * 1024; // 5 MB

export function getWorkspaceDir(): string {
  return process.env.WORKSPACE_FILES_DIR || join(process.cwd(), ".data", "workspace");
}

async function resolveWorkspacePath(pathname: string): Promise<string> {
  let currentPath = resolve(pathname);
  const suffix: string[] = [];
  while (true) {
    try {
      return resolve(await realpath(currentPath), ...suffix.reverse());
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      const parent = dirname(currentPath);
      if (parent === currentPath) throw error;
      suffix.push(currentPath.slice(parent.length + 1));
      currentPath = parent;
    }
  }
}

export async function assertWorkspaceRootIsolated(): Promise<void> {
  const projectRoot = await realpath(process.cwd());
  const workspaceRoot = await resolveWorkspacePath(getWorkspaceDir());
  const defaultWorkspaceRoot = resolve(projectRoot, ".data", "workspace");
  const overlapsProject = (root: string, candidate: string) =>
    root === candidate || root.startsWith(candidate + sep) || candidate.startsWith(root + sep);
  if (
    workspaceRoot !== defaultWorkspaceRoot &&
    overlapsProject(workspaceRoot, projectRoot)
  ) {
    throw new WorkspaceFileError(
      "workspace_root_protected",
      "Workspace file operations cannot read or modify the engine source tree.",
      403
    );
  }
}

export function validateWorkspaceRelativePath(relativePath: string): string {
  if (!relativePath || typeof relativePath !== "string") {
    throw new WorkspaceFileError("invalid_path", "Filename or path must be a non-empty string.", 400);
  }
  const trimmed = relativePath.trim();
  if (!trimmed || trimmed.length > 255) {
    throw new WorkspaceFileError("invalid_filename", "Filename must be between 1 and 255 characters.", 400);
  }
  if (/[\0\x00-\x1f\x7f]/.test(trimmed)) {
    throw new WorkspaceFileError("invalid_path", "Path contains invalid control characters or null bytes.", 400);
  }
  if (trimmed.includes("\\")) {
    throw new WorkspaceFileError("path_traversal_blocked", "Backslashes are not allowed in workspace paths.", 403);
  }
  if (
    trimmed.includes("..") ||
    trimmed.startsWith("/") ||
    trimmed.startsWith("\\") ||
    /^[a-zA-Z]:/.test(trimmed)
  ) {
    throw new WorkspaceFileError(
      "path_traversal_blocked",
      `Path traversal outside workspace root is blocked for "${trimmed}".`,
      403
    );
  }
  const baseDir = resolve(getWorkspaceDir());
  const resolvedTarget = resolve(baseDir, trimmed);
  if (!resolvedTarget.startsWith(baseDir + sep) && resolvedTarget !== baseDir) {
    throw new WorkspaceFileError(
      "path_traversal_blocked",
      `Path traversal outside workspace root is blocked: "${trimmed}".`,
      403
    );
  }
  return trimmed;
}

export async function assertSafeWorkspacePath(targetPath: string): Promise<void> {
  await assertWorkspaceRootIsolated();
  const baseDir = resolve(getWorkspaceDir());
  const resolvedTarget = resolve(targetPath);
  if (resolvedTarget !== baseDir && !resolvedTarget.startsWith(baseDir + sep)) {
    throw new WorkspaceFileError("path_traversal_blocked", "Workspace path resolves outside the workspace root.", 403);
  }
  let realBaseDir = baseDir;
  try {
    realBaseDir = await realpath(baseDir);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  const components = resolvedTarget.slice(baseDir.length).split(sep).filter(Boolean);
  let currentPath = baseDir;
  for (const component of ["", ...components]) {
    if (component) currentPath = join(currentPath, component);
    let entry;
    try {
      entry = await lstat(currentPath);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
      throw error;
    }
    if (!entry.isSymbolicLink()) continue;
    let real: string;
    try {
      real = await realpath(currentPath);
    } catch {
      throw new WorkspaceFileError(
        "symlink_resolution_failed",
        `Symbolic link target cannot be resolved safely: "${currentPath}".`,
        403
      );
    }
    if (real !== realBaseDir && !real.startsWith(realBaseDir + sep)) {
      throw new WorkspaceFileError(
        "symlink_escape_blocked",
        `Symbolic link target escapes project workspace: "${currentPath}".`,
        403
      );
    }
    currentPath = real;
  }
}

export type WorkspaceFileChangeListener = (filename: string, action: "write" | "delete") => void | Promise<void>;
const workspaceFileChangeListeners: WorkspaceFileChangeListener[] = [];

export function onWorkspaceFileChanged(listener: WorkspaceFileChangeListener): () => void {
  workspaceFileChangeListeners.push(listener);
  return () => {
    const idx = workspaceFileChangeListeners.indexOf(listener);
    if (idx !== -1) workspaceFileChangeListeners.splice(idx, 1);
  };
}

export function notifyWorkspaceFileChanged(filename: string, action: "write" | "delete") {
  for (const listener of workspaceFileChangeListeners) {
    try {
      const res = listener(filename, action);
      if (res && typeof (res as Promise<void>).catch === "function") {
        (res as Promise<void>).catch(() => {});
      }
    } catch {}
  }
}

export async function writeWorkspaceFile(
  filename: string,
  content: string,
  mode = "code"
): Promise<WorkspaceFileRecord> {
  if (mode === "review") {
    throw new WorkspaceFileError(
      "file_modification_forbidden_in_review_mode",
      "File modification is strictly forbidden in review mode.",
      403
    );
  }
  if (mode === "qa") {
    throw new WorkspaceFileError(
      "forbidden_in_qa_mode",
      "File creation/modification is forbidden in Q&A mode.",
      403
    );
  }

  const cleanName = validateWorkspaceRelativePath(filename);
  await assertWorkspaceRootIsolated();
  const baseFileName = basename(cleanName);
  if (isBlockedFilename(baseFileName)) {
    throw new WorkspaceFileError("blocked_filename", `Sensitive file "${cleanName}" cannot be created or modified.`, 400);
  }
  const ext = detectFileExtension(baseFileName);
  if (isExecutableExtension(ext)) {
    throw new WorkspaceFileError("blocked_executable", `Executable extension "${ext}" is blocked for security.`, 400);
  }

  const dir = getWorkspaceDir();
  await mkdir(dir, { recursive: true });
  const targetPath = join(dir, cleanName);
  await assertSafeWorkspacePath(targetPath);

  const buffer = Buffer.from(content, "utf8");
  if (buffer.length > MAX_INDIVIDUAL_FILE_SIZE) {
    throw new WorkspaceFileError("file_too_large", `File size exceeds 1 MB limit (${(buffer.length / 1024).toFixed(1)} KB).`, 400);
  }

  // Quotas check: file count and total size
  const existingFiles = await listWorkspaceFiles();
  const fileAlreadyExists = existingFiles.some((f) => f.name === cleanName);
  if (!fileAlreadyExists && existingFiles.length >= MAX_WORKSPACE_FILES) {
    throw new WorkspaceFileError(
      "file_count_limit_exceeded",
      `Workspace file count limit exceeded (maximum ${MAX_WORKSPACE_FILES} files).`,
      400
    );
  }
  const currentTotalSize = existingFiles.reduce((acc, f) => acc + (f.name === cleanName ? 0 : f.size), 0);
  if (currentTotalSize + buffer.length > MAX_WORKSPACE_TOTAL_SIZE) {
    throw new WorkspaceFileError(
      "workspace_quota_exceeded",
      `Workspace total storage quota exceeded (${((currentTotalSize + buffer.length) / (1024 * 1024)).toFixed(2)} MB / ${(MAX_WORKSPACE_TOTAL_SIZE / (1024 * 1024)).toFixed(2)} MB limit).`,
      400
    );
  }

  const parentDir = dirname(targetPath);
  if (parentDir !== dir) {
    await mkdir(parentDir, { recursive: true });
  }

  await writeFile(targetPath, buffer);
  const inspected = inspectFile(baseFileName, buffer);

  notifyWorkspaceFileChanged(cleanName, "write");

  return {
    name: cleanName,
    path: targetPath,
    size: buffer.length,
    lineCount: inspected.lineCount ?? content.split("\n").length,
    content: inspected.content ?? content,
    updatedAt: new Date().toISOString(),
    hash: createHash("sha256").update(buffer).digest("hex")
  };
}

export async function deleteWorkspaceFile(filename: string): Promise<boolean> {
  const cleanName = validateWorkspaceRelativePath(filename);
  await assertWorkspaceRootIsolated();
  const dir = getWorkspaceDir();
  const targetPath = join(dir, cleanName);
  await assertSafeWorkspacePath(targetPath);
  try {
    await unlink(targetPath);
    notifyWorkspaceFileChanged(cleanName, "delete");
    return true;
  } catch (err: any) {
    if (err?.code === "ENOENT") return false;
    throw err;
  }
}

export async function readWorkspaceFile(filename: string): Promise<WorkspaceFileRecord | null> {
  let cleanName: string;
  try {
    cleanName = validateWorkspaceRelativePath(filename);
  } catch {
    return null;
  }
  const dir = getWorkspaceDir();
  const targetPath = join(dir, cleanName);
  try {
    await assertWorkspaceRootIsolated();
    await assertSafeWorkspacePath(targetPath);
    const buffer = await readFile(targetPath);
    const inspected = inspectFile(basename(cleanName), buffer);
    return {
      name: cleanName,
      path: targetPath,
      size: buffer.length,
      lineCount: inspected.lineCount ?? 0,
      content: inspected.content ?? buffer.toString("utf8"),
      updatedAt: new Date().toISOString(),
      hash: createHash("sha256").update(buffer).digest("hex")
    };
  } catch {
    return null;
  }
}

export async function listWorkspaceFiles(): Promise<WorkspaceFileRecord[]> {
  await assertWorkspaceRootIsolated();
  const dir = getWorkspaceDir();
  try {
    await mkdir(dir, { recursive: true });
  } catch {
    // Ignore
  }
  const results: WorkspaceFileRecord[] = [];

  async function walk(currentDir: string, relativePrefix = "") {
    let entries;
    try {
      entries = await readdir(currentDir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const relPath = relativePrefix ? `${relativePrefix}/${entry.name}` : entry.name;
      const fullPath = join(currentDir, entry.name);
      await assertSafeWorkspacePath(fullPath);

      if (entry.isDirectory()) {
        await walk(fullPath, relPath);
      } else if (entry.isFile()) {
        try {
          const buffer = await readFile(fullPath);
          const inspected = inspectFile(entry.name, buffer);
          const stats = await stat(fullPath);
          results.push({
            name: relPath,
            path: fullPath,
            size: buffer.length,
            lineCount: inspected.lineCount ?? buffer.toString("utf8").split("\n").length,
            content: inspected.content ?? buffer.toString("utf8"),
            updatedAt: stats.mtime.toISOString(),
            hash: createHash("sha256").update(buffer).digest("hex")
          });
        } catch {
          // Skip unreadable files
        }
      }
    }
  }

  await walk(dir);
  return results.sort((a, b) => a.name.localeCompare(b.name));
}

export type WorkspaceTreeNode = {
  name: string;
  path: string;
  type: "file" | "directory";
  size?: number;
  lineCount?: number;
  updatedAt?: string;
  children?: WorkspaceTreeNode[];
};

export async function getWorkspaceTree(): Promise<WorkspaceTreeNode[]> {
  const files = await listWorkspaceFiles();
  const rootNodes: WorkspaceTreeNode[] = [];

  for (const file of files) {
    const parts = file.name.split("/");
    let currentLevel = rootNodes;
    let accumulatedPath = "";

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      accumulatedPath = accumulatedPath ? `${accumulatedPath}/${part}` : part;
      const isFile = i === parts.length - 1;

      let existing = currentLevel.find((n) => n.name === part);
      if (!existing) {
        existing = {
          name: part,
          path: accumulatedPath,
          type: isFile ? "file" : "directory",
          ...(isFile
            ? { size: file.size, lineCount: file.lineCount, updatedAt: file.updatedAt }
            : { children: [] })
        };
        currentLevel.push(existing);
      }
      if (!isFile) {
        if (!existing.children) existing.children = [];
        currentLevel = existing.children;
      }
    }
  }
  return rootNodes;
}

export function generateUnifiedDiff(oldContent: string, newContent: string, filename: string): string {
  const oldLines = oldContent === "" ? [] : oldContent.split(/\r?\n/);
  const newLines = newContent === "" ? [] : newContent.split(/\r?\n/);

  const header = [
    `--- a/${filename}`,
    `+++ b/${filename}`,
    `@@ -${oldLines.length === 0 ? 0 : 1},${oldLines.length} +${newLines.length === 0 ? 0 : 1},${newLines.length} @@`
  ];

  if (oldLines.length === 0) {
    return [...header, ...newLines.map((l) => `+${l}`)].join("\n");
  }
  if (newLines.length === 0) {
    return [...header, ...oldLines.map((l) => `-${l}`)].join("\n");
  }

  const diffLines: string[] = [];
  let i = 0;
  let j = 0;
  while (i < oldLines.length || j < newLines.length) {
    if (i < oldLines.length && j < newLines.length && oldLines[i] === newLines[j]) {
      diffLines.push(` ${oldLines[i]}`);
      i++;
      j++;
    } else {
      if (i < oldLines.length && (j >= newLines.length || !newLines.slice(j).includes(oldLines[i]))) {
        diffLines.push(`-${oldLines[i]}`);
        i++;
      } else if (j < newLines.length) {
        diffLines.push(`+${newLines[j]}`);
        j++;
      }
    }
  }
  return [...header, ...diffLines].join("\n");
}

export type CheckpointFileEntry = {
  name: string;
  content: string;
  size: number;
};

export type CheckpointRecord = {
  id: string;
  createdAt: string;
  description: string;
  proposalId?: string;
  files: CheckpointFileEntry[];
};

const inMemoryCheckpoints: Map<string, CheckpointRecord> = new Map();

export async function createCheckpoint(description: string, proposalId?: string): Promise<CheckpointRecord> {
  const currentFiles = await listWorkspaceFiles();
  const snapshotFiles: CheckpointFileEntry[] = currentFiles.map((f) => ({
    name: f.name,
    content: f.content,
    size: f.size
  }));

  const checkpoint: CheckpointRecord = {
    id: `cp-${Date.now()}-${randomUUID().slice(0, 8)}`,
    createdAt: new Date().toISOString(),
    description,
    proposalId,
    files: snapshotFiles
  };
  inMemoryCheckpoints.set(checkpoint.id, checkpoint);
  return checkpoint;
}

export async function listCheckpoints(): Promise<CheckpointRecord[]> {
  return Array.from(inMemoryCheckpoints.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getCheckpoint(id: string): Promise<CheckpointRecord | null> {
  return inMemoryCheckpoints.get(id) || null;
}

export async function restoreCheckpoint(id: string): Promise<{ restoredCount: number; checkpoint: CheckpointRecord }> {
  const checkpoint = inMemoryCheckpoints.get(id);
  if (!checkpoint) {
    throw new WorkspaceFileError("checkpoint_not_found", `Checkpoint "${id}" not found.`, 404);
  }

  // Clear current files in workspace
  const currentFiles = await listWorkspaceFiles();
  for (const f of currentFiles) {
    await deleteWorkspaceFile(f.name);
  }

  // Restore snapshot files
  for (const entry of checkpoint.files) {
    await writeWorkspaceFile(entry.name, entry.content, "code");
  }

  return {
    restoredCount: checkpoint.files.length,
    checkpoint
  };
}

export type FileProposalType = "write" | "edit" | "delete";
export type FileProposalStatus = "PROPOSED" | "WAITING_APPROVAL" | "APPROVED" | "APPLIED" | "REJECTED";

export type FileProposal = {
  id: string;
  type: FileProposalType;
  name: string;
  path: string;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  status: FileProposalStatus;
  content?: string;
  previousContent?: string;
  diff: string;
  hash: string;
  baselineHash: string | null;
  createdAt: string;
  updatedAt: string;
  approval?: {
    id: string;
    proposalHash: string;
    approvedAt: string;
    usedAt?: string;
  };
  checkpointId?: string;
  impactList?: string[];
};

const inMemoryProposals: Map<string, FileProposal> = new Map();
const activeProposalApplies = new Set<string>();
let proposalStoreLoad: Promise<void> | null = null;
let proposalStoreWriteQueue: Promise<void> = Promise.resolve();

function proposalStorePath(): string {
  return process.env.FILE_PROPOSALS_STORE_PATH || ".data/file-proposals.json";
}

async function ensureProposalsLoaded(): Promise<void> {
  if (!proposalStoreLoad) {
    proposalStoreLoad = (async () => {
      let raw: string;
      try {
        raw = await readFile(proposalStorePath(), "utf8");
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
        throw error;
      }
      let parsed: unknown;
      try {
        parsed = JSON.parse(raw);
      } catch {
        // Fail closed: never silently discard proposal/approval state on corruption.
        throw new Error("File proposal store is corrupt; refusing to start proposal operations.");
      }
      if (!Array.isArray(parsed)) throw new Error("File proposal store has an invalid shape; refusing to start proposal operations.");
      const seenIds = new Set<string>();
      for (const row of parsed) {
        if (!row || typeof row !== "object" || Array.isArray(row)) throw new Error("File proposal store contains an invalid record.");
        const p = row as Partial<FileProposal>;
        if (typeof p.id !== "string" || !p.id.trim() || seenIds.has(p.id) ||
            typeof p.name !== "string" || !p.name.trim() || typeof p.hash !== "string" || !/^[a-f0-9]{64}$/i.test(p.hash) ||
            typeof p.status !== "string" || typeof p.createdAt !== "string" || Number.isNaN(Date.parse(p.createdAt)) ||
            typeof p.updatedAt !== "string" || Number.isNaN(Date.parse(p.updatedAt)) ||
            !["write", "edit", "delete"].includes(String(p.type)) ||
            !["PROPOSED", "WAITING_APPROVAL", "APPROVED", "APPLIED", "REJECTED"].includes(String(p.status)) ||
            !["LOW", "MEDIUM", "HIGH"].includes(String(p.riskLevel)) ||
            typeof p.path !== "string" || !p.path.trim() || typeof p.diff !== "string" ||
            (p.baselineHash !== null && (typeof p.baselineHash !== "string" || !/^[a-f0-9]{64}$/i.test(p.baselineHash))) ||
            (p.content !== undefined && typeof p.content !== "string") ||
            (p.previousContent !== undefined && typeof p.previousContent !== "string") ||
            (p.approval !== undefined && (!p.approval || typeof p.approval.id !== "string" || !p.approval.id.trim() ||
              typeof p.approval.proposalHash !== "string" || !/^[a-f0-9]{64}$/i.test(p.approval.proposalHash) ||
              p.approval.proposalHash !== p.hash ||
              typeof p.approval.approvedAt !== "string" || Number.isNaN(Date.parse(p.approval.approvedAt)) ||
              (p.approval.usedAt !== undefined && (typeof p.approval.usedAt !== "string" || Number.isNaN(Date.parse(p.approval.usedAt))))) ) ||
            (["APPROVED", "APPLIED"].includes(String(p.status)) && !p.approval) ||
            (p.checkpointId !== undefined && typeof p.checkpointId !== "string") ||
            (p.impactList !== undefined && (!Array.isArray(p.impactList) || p.impactList.some((item) => typeof item !== "string"))) ||
            computeProposalHash(p.id, p.name, p.type, p.content, p.diff, p.baselineHash) !== p.hash) {
          throw new Error("File proposal store contains an invalid or duplicate record; refusing to load it.");
        }
        seenIds.add(p.id);
        inMemoryProposals.set(p.id, p as FileProposal);
      }
    })();
  }
  await proposalStoreLoad;
}

async function persistProposals(): Promise<void> {
  const previous = proposalStoreWriteQueue;
  let release!: () => void;
  proposalStoreWriteQueue = new Promise<void>((resolve) => { release = resolve; });
  await previous;
  let temp: string | undefined;
  try {
    const target = proposalStorePath();
    const snapshot = JSON.stringify(Array.from(inMemoryProposals.values()), null, 2) + "\n";
    await mkdir(dirname(target), { recursive: true });
    temp = `${target}.${process.pid}.${randomUUID()}.tmp`;
    await writeFile(temp, snapshot, { encoding: "utf8", mode: 0o600 });
    await rename(temp, target);
    temp = undefined;
  } finally {
    if (temp) {
      try { await unlink(temp); } catch { /* best-effort cleanup; original write error is authoritative */ }
    }
    release();
  }
}

function computeProposalHash(
  id: string,
  name: string,
  type: string,
  content: string | undefined,
  diff: string,
  baselineHash: string | null
): string {
  return createHash("sha256")
    .update(JSON.stringify({ id, name, type, content: content ?? "", diff, baselineHash }))
    .digest("hex");
}

function isBlockedProposalPath(name: string): boolean {
  const parts = name.split("/");
  const filename = parts.at(-1)?.toLowerCase() ?? "";
  const protectedManifest = new Set([
    "package.json",
    "package-lock.json",
    "npm-shrinkwrap.json",
    "bun.lock",
    "pnpm-lock.yaml",
    "yarn.lock",
    "tsconfig.json",
  ]);
  return protectedManifest.has(filename) ||
    /^tsconfig\..+\.json$/i.test(filename) ||
    parts.some((part) => /^(?:tests?|__tests__|node_modules|\.git)$/i.test(part)) ||
    /(?:^|\/)(?:sovereign|kernel|core|hsm|treasury|forensic)(?:\/|$)/i.test(name) ||
    /(?:^|\/)(?:sovereign|kernel|core|hsm|treasury|forensic)[^/]*\.[^/]+$/i.test(name) ||
    /(?:Sovereign|Kernel|Core|HSM|Treasury|Forensic)/.test(name);
}

export async function computeProposalImpactList(targetFileName: string): Promise<string[]> {
  try {
    const manifestFile = await readWorkspaceFile("app.json");
    if (!manifestFile) return [];
    const manifest = JSON.parse(manifestFile.content) as AppManifest;
    if (!manifest || !Array.isArray(manifest.routes) || !Array.isArray(manifest.components)) return [];

    const normalizedTarget = targetFileName.replace(/^\.\//, "").replace(/\\/g, "/");
    const matchedComponent = manifest.components.find((c) =>
      c.file.replace(/^\.\//, "").replace(/\\/g, "/") === normalizedTarget ||
      c.name.toLowerCase() === basename(targetFileName, extname(targetFileName)).toLowerCase()
    );

    if (!matchedComponent) return [];

    const impactedRoutes: string[] = [];
    for (const route of manifest.routes) {
      const usesInManifest = Array.isArray(route.components) && route.components.includes(matchedComponent.name);
      let usesInSource = false;
      if (!usesInManifest && route.pageFile) {
        const page = await readWorkspaceFile(route.pageFile);
        if (page && page.content.includes(matchedComponent.name)) {
          usesInSource = true;
        }
      }
      if (usesInManifest || usesInSource) {
        impactedRoutes.push(`${route.name} (${route.path})`);
      }
    }
    return impactedRoutes;
  } catch {
    return [];
  }
}

export async function createFileProposal(input: {
  type?: FileProposalType;
  name: string;
  content?: string;
}): Promise<FileProposal> {
  await ensureProposalsLoaded();
  const cleanName = validateWorkspaceRelativePath(input.name);
  await assertWorkspaceRootIsolated();
  const baseName = basename(cleanName);
  if (isBlockedFilename(baseName)) {
    throw new WorkspaceFileError("blocked_filename", `Sensitive file "${cleanName}" cannot be proposed.`, 400);
  }
  const ext = detectFileExtension(baseName);
  if (isExecutableExtension(ext)) {
    throw new WorkspaceFileError("blocked_executable", `Executable extension "${ext}" is blocked for security.`, 400);
  }
  if (isBlockedProposalPath(cleanName)) {
    throw new WorkspaceFileError("protected_path", `Workspace path "${cleanName}" is protected from proposals.`, 403);
  }
  await assertSafeWorkspacePath(join(getWorkspaceDir(), cleanName));

  const existingFile = await readWorkspaceFile(cleanName);
  const previousContent = existingFile ? existingFile.content : "";
  const content = input.content ?? "";

  let type: FileProposalType = input.type || (existingFile ? "edit" : "write");
  if (type === "delete" && !existingFile) {
    throw new WorkspaceFileError("file_not_found", `Cannot propose deletion for non-existent file "${cleanName}".`, 404);
  }

  let riskLevel: "LOW" | "MEDIUM" | "HIGH" = "LOW";
  if (type === "delete") {
    riskLevel = "HIGH";
  } else if (type === "edit") {
    riskLevel = "MEDIUM";
  } else {
    // New file write
    const lineCount = content.split("\n").length;
    riskLevel = lineCount > 300 ? "MEDIUM" : "LOW";
  }

  const diff = generateUnifiedDiff(previousContent, type === "delete" ? "" : content, cleanName);
  const id = `prop-${Date.now()}-${randomUUID().slice(0, 8)}`;
  const baselineHash = existingFile?.hash ?? null;
  const hash = computeProposalHash(id, cleanName, type, content, diff, baselineHash);
  const impactList = await computeProposalImpactList(cleanName);

  const proposal: FileProposal = {
    id,
    type,
    name: cleanName,
    path: join(getWorkspaceDir(), cleanName),
    riskLevel,
    status: "PROPOSED",
    content: type === "delete" ? undefined : content,
    previousContent: existingFile ? previousContent : undefined,
    diff,
    hash,
    baselineHash,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    impactList: impactList.length > 0 ? impactList : undefined
  };

  inMemoryProposals.set(id, proposal);
  await persistProposals();
  return proposal;
}

export async function requestProposalApproval(id: string): Promise<FileProposal> {
  await ensureProposalsLoaded();
  const proposal = inMemoryProposals.get(id);
  if (!proposal) {
    throw new WorkspaceFileError("proposal_not_found", `Proposal "${id}" not found.`, 404);
  }
  if (proposal.status !== "PROPOSED") {
    throw new WorkspaceFileError("invalid_proposal_state", `Proposal is already in state "${proposal.status}".`, 400);
  }
  proposal.status = "WAITING_APPROVAL";
  proposal.updatedAt = new Date().toISOString();
  await persistProposals();
  return proposal;
}

export async function approveProposal(id: string, proposalHash: string): Promise<FileProposal> {
  await ensureProposalsLoaded();
  const proposal = inMemoryProposals.get(id);
  if (!proposal) {
    throw new WorkspaceFileError("proposal_not_found", `Proposal "${id}" not found.`, 404);
  }
  if (proposal.status !== "WAITING_APPROVAL") {
    throw new WorkspaceFileError("proposal_not_approvable", `Proposal in state "${proposal.status}" cannot be approved.`, 400);
  }
  if (proposal.hash !== proposalHash) {
    throw new WorkspaceFileError("approval_mismatch", "Proposal hash mismatch. Content may have changed.", 400);
  }

  const approvalId = `appr-${randomUUID()}`;
  proposal.status = "APPROVED";
  proposal.approval = {
    id: approvalId,
    proposalHash,
    approvedAt: new Date().toISOString()
  };
  proposal.updatedAt = new Date().toISOString();
  await persistProposals();
  return proposal;
}

export async function applyProposal(id: string, approvalId: string): Promise<{
  proposal: FileProposal;
  checkpoint: CheckpointRecord;
  file?: WorkspaceFileRecord;
}> {
  await ensureProposalsLoaded();
  const proposal = inMemoryProposals.get(id);
  if (!proposal) {
    throw new WorkspaceFileError("proposal_not_found", `Proposal "${id}" not found.`, 404);
  }
  if (proposal.approval?.usedAt || proposal.status === "APPLIED") {
    throw new WorkspaceFileError("approval_replayed", "Approval has already been used and cannot be replayed.", 409);
  }
  if (proposal.status !== "APPROVED" || !proposal.approval) {
    throw new WorkspaceFileError("approval_required", `Proposal must be approved before it can be applied.`, 403);
  }
  if (proposal.approval.id !== approvalId) {
    throw new WorkspaceFileError("approval_mismatch", "Approval ID does not match.", 400);
  }
  if (proposal.approval.proposalHash !== proposal.hash) {
    throw new WorkspaceFileError("approval_mismatch", "The approved proposal hash no longer matches its content.", 409);
  }

  if (activeProposalApplies.has(id)) {
    throw new WorkspaceFileError("proposal_apply_in_progress", "This proposal is already being applied.", 409);
  }
  activeProposalApplies.add(id);
  try {
    const currentFile = await readWorkspaceFile(proposal.name);
    if ((currentFile?.hash ?? null) !== proposal.baselineHash) {
      throw new WorkspaceFileError("stale_proposal", "Workspace source changed after the proposal was created; create and review a new proposal.", 409);
    }
    const checkpoint = await createCheckpoint(`Pre-change snapshot before applying proposal ${proposal.id} (${proposal.type} ${proposal.name})`, proposal.id);
    const currentBeforeWrite = await readWorkspaceFile(proposal.name);
    if ((currentBeforeWrite?.hash ?? null) !== proposal.baselineHash) {
      throw new WorkspaceFileError("stale_proposal", "Workspace source changed before the proposal could be applied; create and review a new proposal.", 409);
    }

    let fileRecord: WorkspaceFileRecord | undefined;
    if (proposal.type === "delete") {
      await deleteWorkspaceFile(proposal.name);
    } else {
      fileRecord = await writeWorkspaceFile(proposal.name, proposal.content || "", "code");
    }

    proposal.approval.usedAt = new Date().toISOString();
    proposal.status = "APPLIED";
    proposal.checkpointId = checkpoint.id;
    proposal.updatedAt = new Date().toISOString();
    await persistProposals();
    return { proposal, checkpoint, file: fileRecord };
  } finally {
    activeProposalApplies.delete(id);
  }
}

export async function rejectProposal(id: string): Promise<FileProposal> {
  await ensureProposalsLoaded();
  const proposal = inMemoryProposals.get(id);
  if (!proposal) {
    throw new WorkspaceFileError("proposal_not_found", `Proposal "${id}" not found.`, 404);
  }
  proposal.status = "REJECTED";
  proposal.updatedAt = new Date().toISOString();
  await persistProposals();
  return proposal;
}

export async function listProposals(): Promise<FileProposal[]> {
  await ensureProposalsLoaded();
  return Array.from(inMemoryProposals.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getProposal(id: string): Promise<FileProposal | null> {
  await ensureProposalsLoaded();
  return inMemoryProposals.get(id) || null;
}

export type WebsiteValidationResult = {
  valid: boolean;
  hasHtml: boolean;
  entryFile?: string;
  files: string[];
  totalSize: number;
  structureErrors: string[];
  missingAssetReferences: string[];
  warnings: string[];
  visualStatus: "NOT VERIFIED";
  responsiveStatus: "NOT VERIFIED";
  deployableStatus: "NOT VERIFIED";
};

export async function validateWebsiteWorkspace(): Promise<WebsiteValidationResult> {
  const files = await listWorkspaceFiles();
  const fileNames = files.map((f) => f.name);
  const totalSize = files.reduce((acc, f) => acc + f.size, 0);

  const htmlFiles = fileNames.filter((name) => /\.html?$/i.test(name));
  const entryFile = htmlFiles.find((name) => /^index\.html?$/i.test(name)) || htmlFiles[0];

  const structureErrors: string[] = [];
  const missingAssetReferences: string[] = [];
  const warnings: string[] = [];

  if (htmlFiles.length === 0) {
    return {
      valid: false,
      hasHtml: false,
      files: fileNames,
      totalSize,
      structureErrors: ["No HTML files found in workspace."],
      missingAssetReferences: [],
      warnings: [],
      visualStatus: "NOT VERIFIED",
      responsiveStatus: "NOT VERIFIED",
      deployableStatus: "NOT VERIFIED"
    };
  }

  for (const htmlName of htmlFiles) {
    const file = await readWorkspaceFile(htmlName);
    if (!file) continue;
    const content = file.content;

    const hasDoctypeOrHtml = /<!DOCTYPE\s+html/i.test(content) || /<html/i.test(content);
    const hasBody = /<body/i.test(content);
    if (!hasDoctypeOrHtml) {
      structureErrors.push(`${htmlName}: Missing <!DOCTYPE html> or <html> element`);
    }
    if (!hasBody) {
      warnings.push(`${htmlName}: Missing <body> element`);
    }

    const linkMatches = content.matchAll(/<link\s+[^>]*?href=["']([^"']+)["']/gi);
    for (const match of linkMatches) {
      const ref = match[1].trim();
      if (!ref.startsWith("http://") && !ref.startsWith("https://") && !ref.startsWith("//") && !ref.startsWith("data:") && !ref.startsWith("#")) {
        const cleanRef = ref.replace(/^\.\//, "").split("?")[0].split("#")[0];
        if (!fileNames.includes(cleanRef)) {
          missingAssetReferences.push(`${htmlName} references missing stylesheet or file: "${ref}"`);
        }
      }
    }

    const srcMatches = content.matchAll(/<(?:script|img)\s+[^>]*?src=["']([^"']+)["']/gi);
    for (const match of srcMatches) {
      const ref = match[1].trim();
      if (!ref.startsWith("http://") && !ref.startsWith("https://") && !ref.startsWith("//") && !ref.startsWith("data:")) {
        const cleanRef = ref.replace(/^\.\//, "").split("?")[0].split("#")[0];
        if (!fileNames.includes(cleanRef)) {
          missingAssetReferences.push(`${htmlName} references missing asset: "${ref}"`);
        }
      }
    }
  }

  const valid = structureErrors.length === 0 && missingAssetReferences.length === 0;

  return {
    valid,
    hasHtml: true,
    entryFile,
    files: fileNames,
    totalSize,
    structureErrors,
    missingAssetReferences,
    warnings,
    visualStatus: "NOT VERIFIED",
    responsiveStatus: "NOT VERIFIED",
    deployableStatus: "NOT VERIFIED"
  };
}

export const PREVIEW_CSP_META = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; form-action 'none';">`;

export const PREVIEW_ERROR_SCRIPT = `<script>
(function() {
  function report(type, message, source, lineno, colno) {
    try {
      window.parent.postMessage({
        type: 'zyntheor-preview-error',
        errorType: type,
        message: String(message),
        source: source,
        lineno: lineno,
        colno: colno
      }, '*');
    } catch(e) {}
  }
  window.onerror = function(msg, src, line, col, err) {
    report('window.onerror', msg, src, line, col);
    return false;
  };
  var origErr = console.error;
  console.error = function() {
    var args = Array.prototype.slice.call(arguments);
    report('console.error', args.map(function(a) { return typeof a === 'object' ? JSON.stringify(a) : String(a); }).join(' '));
    if (origErr) origErr.apply(console, args);
  };
})();
</script>`;

export type AppManifestRoute = {
  path: string;
  name: string;
  pageFile: string;
  components?: string[];
};

export type AppManifestComponent = {
  name: string;
  file: string;
};

export type AppManifest = {
  name: string;
  version: string;
  entry: string;
  routes: AppManifestRoute[];
  components: AppManifestComponent[];
};

export async function checkJavaScriptSyntax(targetPathOrCode: string, isCodeString = false): Promise<{ valid: boolean; error?: string }> {
  let targetPath = targetPathOrCode;
  let tempFilePath: string | null = null;
  if (isCodeString) {
    const tempName = `syntax-check-${randomUUID()}.js`;
    tempFilePath = join(tmpdir(), tempName);
    await writeFile(tempFilePath, targetPathOrCode, "utf8");
    targetPath = tempFilePath;
  }
  try {
    await execFileAsync("node", ["--check", targetPath], { timeout: 2000 });
    return { valid: true };
  } catch (err: any) {
    const message = err.stderr || err.message || "JavaScript syntax error";
    return { valid: false, error: message.trim() };
  } finally {
    if (tempFilePath) {
      await unlink(tempFilePath).catch(() => {});
    }
  }
}

export type ManifestSchemaValidationResult = {
  valid: boolean;
  errors: string[];
  warnings: string[];
  manifest?: AppManifest;
};

/**
 * Schema validation for app.json in the file inspection and build verification modules.
 * Enforces that app.json conforms to the required manifest structure before build:
 * - Valid JSON parsing
 * - Root is a valid JSON object
 * - Required string 'name' (non-empty)
 * - Required string 'version' (non-empty)
 * - Required string 'entry' (non-empty, safe workspace-relative path)
 * - Required array 'routes' (objects with path, name, pageFile, optional components)
 * - Required array 'components' (objects with name, file)
 * - Safe workspace paths (no traversal or absolute paths)
 */
export function validateAppManifestSchema(input: string | unknown): ManifestSchemaValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  let parsed: any;
  if (typeof input === "string") {
    if (!input.trim()) {
      return {
        valid: false,
        errors: ["app.json manifest content is empty."],
        warnings: []
      };
    }
    try {
      parsed = JSON.parse(input);
    } catch (err: any) {
      return {
        valid: false,
        errors: [`app.json contains invalid JSON syntax: ${err?.message || "parse error"}`],
        warnings: []
      };
    }
  } else {
    parsed = input;
  }

  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return {
      valid: false,
      errors: ["app.json root must be a valid JSON object."],
      warnings: []
    };
  }

  // 1. Validate 'name'
  if (typeof parsed.name !== "string" || !parsed.name.trim()) {
    errors.push("Missing or invalid required manifest field 'name' (must be a non-empty string).");
  }

  // 2. Validate 'version'
  if (typeof parsed.version !== "string" || !parsed.version.trim()) {
    errors.push("Missing or invalid required manifest field 'version' (must be a non-empty string).");
  } else if (!/^\d+\.\d+\.\d+/.test(parsed.version.trim())) {
    warnings.push(`Manifest 'version' ("${parsed.version}") is recommended to follow semver (e.g. "1.0.0").`);
  }

  // 3. Validate 'entry'
  if (typeof parsed.entry !== "string" || !parsed.entry.trim()) {
    errors.push("Missing or invalid required manifest field 'entry' (must be a non-empty string, e.g. 'index.html').");
  } else {
    const cleanEntry = parsed.entry.trim();
    if (cleanEntry.startsWith("/") || cleanEntry.startsWith("\\") || cleanEntry.includes("..") || /^[a-zA-Z]:[\\/]/.test(cleanEntry)) {
      errors.push(`Manifest 'entry' ("${cleanEntry}") must be a safe workspace-relative file path without directory traversal.`);
    }
  }

  // 4. Validate 'routes'
  if (!Array.isArray(parsed.routes)) {
    errors.push("Missing or invalid required manifest field 'routes' (must be an array).");
  } else {
    if (parsed.routes.length === 0) {
      warnings.push("Manifest 'routes' array is empty. At least one route is recommended.");
    }
    parsed.routes.forEach((route: any, idx: number) => {
      const prefix = `Route[${idx}]`;
      if (typeof route !== "object" || route === null || Array.isArray(route)) {
        errors.push(`${prefix} must be an object.`);
        return;
      }
      if (typeof route.path !== "string" || !route.path.trim()) {
        errors.push(`${prefix} requires a non-empty string for 'path' (e.g. '/').`);
      } else {
        const cleanPath = route.path.trim();
        if (!cleanPath.startsWith("/")) {
          errors.push(`${prefix} 'path' ("${cleanPath}") must start with '/'.`);
        }
      }

      if (typeof route.name !== "string" || !route.name.trim()) {
        errors.push(`${prefix} requires a non-empty string for 'name'.`);
      }

      if (typeof route.pageFile !== "string" || !route.pageFile.trim()) {
        errors.push(`${prefix} requires a non-empty string for 'pageFile'.`);
      } else {
        const cleanFile = route.pageFile.trim();
        if (cleanFile.startsWith("/") || cleanFile.startsWith("\\") || cleanFile.includes("..") || /^[a-zA-Z]:[\\/]/.test(cleanFile)) {
          errors.push(`${prefix} 'pageFile' ("${cleanFile}") must be a safe workspace-relative path without directory traversal.`);
        }
      }

      if (route.components !== undefined) {
        if (!Array.isArray(route.components)) {
          errors.push(`${prefix} 'components' must be an array of component names when specified.`);
        } else {
          for (let cIdx = 0; cIdx < route.components.length; cIdx++) {
            if (typeof route.components[cIdx] !== "string" || !route.components[cIdx].trim()) {
              errors.push(`${prefix} components[${cIdx}] must be a non-empty string.`);
            }
          }
        }
      }
    });
  }

  // 5. Validate 'components'
  if (!Array.isArray(parsed.components)) {
    errors.push("Missing or invalid required manifest field 'components' (must be an array).");
  } else {
    parsed.components.forEach((comp: any, idx: number) => {
      const prefix = `Component[${idx}]`;
      if (typeof comp !== "object" || comp === null || Array.isArray(comp)) {
        errors.push(`${prefix} must be an object.`);
        return;
      }
      if (typeof comp.name !== "string" || !comp.name.trim()) {
        errors.push(`${prefix} requires a non-empty string for 'name'.`);
      }

      if (typeof comp.file !== "string" || !comp.file.trim()) {
        errors.push(`${prefix} requires a non-empty string for 'file'.`);
      } else {
        const cleanFile = comp.file.trim();
        if (cleanFile.startsWith("/") || cleanFile.startsWith("\\") || cleanFile.includes("..") || /^[a-zA-Z]:[\\/]/.test(cleanFile)) {
          errors.push(`${prefix} 'file' ("${cleanFile}") must be a safe workspace-relative path without directory traversal.`);
        }
      }
    });
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    manifest: errors.length === 0 ? (parsed as AppManifest) : undefined
  };
}

export const validateAppJsonSchema = validateAppManifestSchema;

export async function validateAppManifest(manifestOverride?: AppManifest, additionalFiles: string[] = []): Promise<{
  valid: boolean;
  hasManifest: boolean;
  errors: string[];
  warnings: string[];
  duplicateRoutes: string[];
  missingFiles: string[];
  unusedComponents: string[];
  manifest?: AppManifest;
  schemaValid?: boolean;
}> {
  let manifest = manifestOverride;
  let schemaErrors: string[] = [];
  let schemaWarnings: string[] = [];
  let isSchemaValid = false;

  if (!manifest) {
    const manifestRecord = await readWorkspaceFile("app.json");
    if (!manifestRecord) {
      return {
        valid: false,
        hasManifest: false,
        errors: ["app.json not found in workspace."],
        warnings: [],
        duplicateRoutes: [],
        missingFiles: [],
        unusedComponents: [],
        schemaValid: false
      };
    }
    const schemaCheck = validateAppManifestSchema(manifestRecord.content);
    schemaErrors = schemaCheck.errors;
    schemaWarnings = schemaCheck.warnings;
    isSchemaValid = schemaCheck.valid;
    if (!schemaCheck.valid && !schemaCheck.manifest) {
      return {
        valid: false,
        hasManifest: true,
        errors: schemaCheck.errors,
        warnings: schemaCheck.warnings,
        duplicateRoutes: [],
        missingFiles: [],
        unusedComponents: [],
        schemaValid: false
      };
    }
    manifest = (schemaCheck.manifest || {}) as AppManifest;
  } else {
    const schemaCheck = validateAppManifestSchema(manifest);
    schemaErrors = schemaCheck.errors;
    schemaWarnings = schemaCheck.warnings;
    isSchemaValid = schemaCheck.valid;
    manifest = (schemaCheck.manifest || manifest) as AppManifest;
  }

  const errors: string[] = [...schemaErrors];
  const warnings: string[] = [...schemaWarnings];
  const duplicateRoutes: string[] = [];
  const missingFiles: string[] = [];
  const unusedComponents: string[] = [];

  const wsFiles = await listWorkspaceFiles();
  const fileNames = Array.from(new Set([...wsFiles.map((f) => f.name.replace(/\\/g, "/")), ...additionalFiles.map((f) => f.replace(/\\/g, "/"))]));

  // Check entry file if entry is a valid string
  if (typeof manifest.entry === "string" && manifest.entry.trim()) {
    const cleanEntry = manifest.entry.replace(/^\.\//, "").replace(/\\/g, "/");
    if (!fileNames.includes(cleanEntry)) {
      missingFiles.push(cleanEntry);
      errors.push(`Manifest entry references missing file: "${manifest.entry}".`);
    }
  }

  // 1. Validate routes
  const seenPaths = new Set<string>();
  if (Array.isArray(manifest.routes)) {
    for (const route of manifest.routes) {
      if (!route || typeof route !== "object") continue;
      if (!route.path || !route.name || !route.pageFile) {
        if (!errors.some((e) => e.includes("missing path, name, or pageFile") || e.includes("Route["))) {
          errors.push("Route is missing path, name, or pageFile.");
        }
        continue;
      }
      if (seenPaths.has(route.path)) {
        duplicateRoutes.push(route.path);
        errors.push(`Duplicate route path found: "${route.path}".`);
      } else {
        seenPaths.add(route.path);
      }

      const cleanPage = route.pageFile.replace(/^\.\//, "").replace(/\\/g, "/");
      if (!fileNames.includes(cleanPage)) {
        missingFiles.push(cleanPage);
        errors.push(`Route "${route.path}" references missing page file: "${route.pageFile}".`);
      }
    }
  } else if (!errors.some((e) => e.includes("routes"))) {
    errors.push("Manifest routes must be an array.");
  }

  // 2. Validate components
  const declaredCompNames = new Set<string>();
  if (Array.isArray(manifest.components)) {
    for (const comp of manifest.components) {
      if (!comp || typeof comp !== "object") continue;
      if (!comp.name || !comp.file) {
        if (!errors.some((e) => e.includes("missing name or file") || e.includes("Component["))) {
          errors.push("Component is missing name or file.");
        }
        continue;
      }
      declaredCompNames.add(comp.name);
      const cleanComp = comp.file.replace(/^\.\//, "").replace(/\\/g, "/");
      if (!fileNames.includes(cleanComp)) {
        missingFiles.push(cleanComp);
        errors.push(`Component "${comp.name}" references missing file: "${comp.file}".`);
      }
    }
  } else if (!errors.some((e) => e.includes("components"))) {
    errors.push("Manifest components must be an array.");
  }

  // 3. Check component references in routes vs declared components
  const usedCompNames = new Set<string>();
  if (Array.isArray(manifest.routes)) {
    for (const route of manifest.routes) {
      if (route && Array.isArray(route.components)) {
        for (const compName of route.components) {
          if (!declaredCompNames.has(compName)) {
            errors.push(`Route "${route.path}" references undeclared component: "${compName}".`);
          } else {
            usedCompNames.add(compName);
          }
        }
      }
    }
  }

  // 4. Report unused components
  if (Array.isArray(manifest.components)) {
    for (const comp of manifest.components) {
      if (comp && comp.name && !usedCompNames.has(comp.name)) {
        unusedComponents.push(comp.name);
        warnings.push(`Component "${comp.name}" is declared but never referenced by any route.`);
      }
    }
  }

  return {
    valid: errors.length === 0,
    hasManifest: true,
    errors,
    warnings,
    duplicateRoutes,
    missingFiles,
    unusedComponents,
    manifest,
    schemaValid: isSchemaValid && schemaErrors.length === 0
  };
}

export function createStandardAppTemplate(appName = "Zyntheor App"): Array<{ name: string; content: string }> {
  const safeName = appName.trim() || "Zyntheor App";
  return [
    {
      name: "app.json",
      content: JSON.stringify(
        {
          name: safeName,
          version: "1.0.0",
          entry: "index.html",
          routes: [
            { path: "/", name: "Home", pageFile: "src/pages/home.js", components: ["Header", "Footer"] },
            { path: "/about", name: "About", pageFile: "src/pages/about.js", components: ["Header", "Footer"] }
          ],
          components: [
            { name: "Header", file: "src/components/header.js" },
            { name: "Footer", file: "src/components/footer.js" }
          ]
        },
        null,
        2
      )
    },
    {
      name: "index.html",
      content: `<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${safeName}</title>
  <link rel="stylesheet" href="src/styles.css">
</head>
<body>
  <div id="app"></div>
  <script src="src/app.js"></script>
</body>
</html>`
    },
    {
      name: "src/components/header.js",
      content: `function Header(props) {
  var title = escapeHtml((props && props.title) || "${safeName}");
  return '<header class="app-header">' +
    '<div class="brand"><strong>' + title + '</strong></div>' +
    '<nav class="app-nav">' +
      '<a href="#/">หน้าแรก</a>' +
      '<a href="#/about">เกี่ยวกับเรา</a>' +
    '</nav>' +
  '</header>';
}`
    },
    {
      name: "src/components/footer.js",
      content: `function Footer() {
  return '<footer class="app-footer">' +
    '<p>&copy; ' + new Date().getFullYear() + ' ${safeName}. Built with audited safe components.</p>' +
  '</footer>';
}`
    },
    {
      name: "src/pages/home.js",
      content: `function HomePage() {
  var count = State.get("counter", 0);
  return '<div class="page page-home">' +
    Header({ title: "${safeName}" }) +
    '<main class="page-content">' +
      '<h1>ยินดีต้อนรับสู่แอปพลิเคชัน</h1>' +
      '<p>แอปพลิเคชันแบบหลายหน้าพร้อมคอมโพเนนต์ที่ใช้ซ้ำได้</p>' +
      '<div class="card">' +
        '<p>ตัวนับสถานะในหน่วยความจำ: <strong>' + count + '</strong></p>' +
        '<button type="button" class="btn" onclick="State.set(\\'counter\\', ' + (count + 1) + '); renderCurrentRoute();">เพิ่มจำนวน (+1)</button>' +
      '</div>' +
    '</main>' +
    Footer() +
  '</div>';
}`
    },
    {
      name: "src/pages/about.js",
      content: `function AboutPage() {
  return '<div class="page page-about">' +
    Header({ title: "เกี่ยวกับเรา" }) +
    '<main class="page-content">' +
      '<h1>เกี่ยวกับ ${safeName}</h1>' +
      '<p>ระบบโครงสร้างแอปมาตรฐานแบบ Single Page Hash Router สำหรับ Sandbox Preview</p>' +
    '</main>' +
    Footer() +
  '</div>';
}`
    },
    {
      name: "src/app.js",
      content: `// Zyntheor In-Memory State & Hash Router
var State = (function() {
  var memory = {};
  return {
    get: function(key, defaultValue) {
      return memory[key] !== undefined ? memory[key] : defaultValue;
    },
    set: function(key, value) {
      memory[key] = value;
      return value;
    }
  };
})();

function escapeHtml(str) {
  return String(str || "").replace(/[&<>"']/g, function(m) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m];
  });
}

function renderCurrentRoute() {
  var hash = window.location.hash || "#/";
  var path = hash.replace(/^#/, "") || "/";
  var appEl = document.getElementById("app");
  if (!appEl) return;

  if (path === "/about") {
    appEl.innerHTML = typeof AboutPage === "function" ? AboutPage() : "<h1>About Page Not Found</h1>";
  } else {
    appEl.innerHTML = typeof HomePage === "function" ? HomePage() : "<h1>Home Page Not Found</h1>";
  }
}

window.addEventListener("hashchange", renderCurrentRoute);
window.addEventListener("DOMContentLoaded", renderCurrentRoute);
renderCurrentRoute();`
    },
    {
      name: "src/styles.css",
      content: `* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: #090b10;
  color: #f1f5f9;
  line-height: 1.5;
}
.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  background: #11141e;
  border-bottom: 1px solid rgba(148, 163, 184, 0.15);
}
.app-nav a {
  color: #94a3b8;
  text-decoration: none;
  margin-left: 16px;
  font-weight: 500;
}
.app-nav a:hover { color: #38bdf8; }
.page-content {
  max-width: 800px;
  margin: 40px auto;
  padding: 0 20px;
}
.card {
  background: #151a28;
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 12px;
  padding: 24px;
  margin-top: 24px;
}
.btn {
  background: #0284c7;
  color: white;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
}
.btn:hover { background: #0369a1; }
.app-footer {
  text-align: center;
  padding: 24px;
  color: #64748b;
  font-size: 0.85rem;
  border-top: 1px solid rgba(148, 163, 184, 0.1);
  margin-top: 60px;
}`
    }
  ];
}

export function createExpenseTrackerTemplate(appName = "แอปจัดการรายรับรายจ่าย"): Array<{ name: string; content: string }> {
  const safeName = appName.trim() || "แอปจัดการรายรับรายจ่าย";
  return [
    {
      name: "app.json",
      content: JSON.stringify(
        {
          name: safeName,
          version: "1.0.0",
          entry: "index.html",
          routes: [
            { path: "/", name: "Dashboard", pageFile: "src/pages/dashboard.js", components: ["Header", "SummaryCard", "TransactionList", "Footer"] },
            { path: "/add", name: "AddTransaction", pageFile: "src/pages/add_transaction.js", components: ["Header", "TransactionForm", "Footer"] },
            { path: "/history", name: "History", pageFile: "src/pages/history.js", components: ["Header", "TransactionList", "Footer"] }
          ],
          components: [
            { name: "Header", file: "src/components/header.js" },
            { name: "SummaryCard", file: "src/components/summary_card.js" },
            { name: "TransactionForm", file: "src/components/transaction_form.js" },
            { name: "TransactionList", file: "src/components/transaction_list.js" },
            { name: "Footer", file: "src/components/footer.js" }
          ]
        },
        null,
        2
      )
    },
    {
      name: "index.html",
      content: `<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${safeName}</title>
  <link rel="stylesheet" href="src/styles.css">
</head>
<body>
  <div id="app"></div>
  <script src="src/app.js"></script>
</body>
</html>`
    },
    {
      name: "src/components/header.js",
      content: `function Header(props) {
  var title = escapeHtml((props && props.title) || "${safeName}");
  return '<header class="app-header">' +
    '<div class="brand"><strong>' + title + '</strong></div>' +
    '<nav class="app-nav">' +
      '<a href="#/">ภาพรวม</a>' +
      '<a href="#/add">+ บันทึกรายการ</a>' +
      '<a href="#/history">ประวัติการเงิน</a>' +
    '</nav>' +
  '</header>';
}`
    },
    {
      name: "src/components/summary_card.js",
      content: `function SummaryCard() {
  var txs = State.get("transactions", []);
  var income = 0;
  var expense = 0;
  for (var i = 0; i < txs.length; i++) {
    var amt = Number(txs[i].amount) || 0;
    if (txs[i].type === "income") {
      income += amt;
    } else {
      expense += amt;
    }
  }
  var balance = income - expense;
  return '<div class="summary-grid">' +
    '<div class="summary-card balance">' +
      '<span class="label">ยอดเงินคงเหลือ</span>' +
      '<h2 class="amount ' + (balance >= 0 ? 'pos' : 'neg') + '">' + balance.toLocaleString() + ' บาท</h2>' +
    '</div>' +
    '<div class="summary-card inc">' +
      '<span class="label">รายรับทั้งหมด</span>' +
      '<h3 class="amount pos">+' + income.toLocaleString() + ' บาท</h3>' +
    '</div>' +
    '<div class="summary-card exp">' +
      '<span class="label">รายจ่ายทั้งหมด</span>' +
      '<h3 class="amount neg">-' + expense.toLocaleString() + ' บาท</h3>' +
    '</div>' +
  '</div>';
}`
    },
    {
      name: "src/components/transaction_form.js",
      content: `function TransactionForm() {
  return '<form class="card tx-form" onsubmit="handleTransactionSubmit(event)">' +
    '<h2>บันทึกรายการใหม่</h2>' +
    '<div class="form-group">' +
      '<label>ประเภทรายการ</label>' +
      '<select id="txType" class="form-control">' +
        '<option value="expense">รายจ่าย</option>' +
        '<option value="income">รายรับ</option>' +
      '</select>' +
    '</div>' +
    '<div class="form-group">' +
      '<label>ชื่อรายการ</label>' +
      '<input type="text" id="txTitle" class="form-control" placeholder="เช่น ค่าอาหาร, เงินเดือน" required>' +
    '</div>' +
    '<div class="form-group">' +
      '<label>จำนวนเงิน (บาท)</label>' +
      '<input type="number" id="txAmount" class="form-control" placeholder="0.00" min="1" step="any" required>' +
    '</div>' +
    '<div class="form-group">' +
      '<label>หมวดหมู่</label>' +
      '<input type="text" id="txCategory" class="form-control" placeholder="เช่น อาหาร, คมนาคม, ทั่วไป">' +
    '</div>' +
    '<button type="submit" class="btn btn-primary">บันทึกรายการ</button>' +
  '</form>';
}`
    },
    {
      name: "src/components/transaction_list.js",
      content: `function TransactionList(props) {
  var txs = State.get("transactions", []);
  var max = (props && props.limit) ? props.limit : txs.length;
  var display = txs.slice(0, max);
  if (display.length === 0) {
    return '<div class="card empty"><p>ยังไม่มีรายการบันทึก</p></div>';
  }
  var html = '<div class="card tx-list"><h2>' + escapeHtml((props && props.title) || "รายการล่าสุด") + '</h2><ul class="list">';
  for (var i = 0; i < display.length; i++) {
    var t = display[i];
    var isInc = t.type === "income";
    html += '<li class="tx-item ' + (isInc ? 'inc' : 'exp') + '">' +
      '<div class="tx-info">' +
        '<strong>' + escapeHtml(t.title) + '</strong>' +
        '<small>' + escapeHtml(t.category || "ทั่วไป") + ' &bull; ' + escapeHtml(t.date || "") + '</small>' +
      '</div>' +
      '<div class="tx-amount ' + (isInc ? 'pos' : 'neg') + '">' +
        (isInc ? '+' : '-') + (Number(t.amount) || 0).toLocaleString() + ' บาท' +
      '</div>' +
    '</li>';
  }
  html += '</ul></div>';
  return html;
}`
    },
    {
      name: "src/components/footer.js",
      content: `function Footer() {
  return '<footer class="app-footer">' +
    '<p>&copy; ' + new Date().getFullYear() + ' ${safeName}. ตรวจสอบสถาปัตยกรรมปลอดภัย ป้องกันการแทรกสคริปต์.</p>' +
  '</footer>';
}`
    },
    {
      name: "src/pages/dashboard.js",
      content: `function DashboardPage() {
  return '<div class="page page-dashboard">' +
    Header({ title: "${safeName}" }) +
    '<main class="page-content">' +
      SummaryCard() +
      '<div class="actions-bar">' +
        '<a href="#/add" class="btn btn-primary">+ บันทึกรายการใหม่</a>' +
        '<a href="#/history" class="btn btn-secondary">ดูประวัติทั้งหมด</a>' +
      '</div>' +
      TransactionList({ limit: 5, title: "รายการล่าสุด 5 รายการ" }) +
    '</main>' +
    Footer() +
  '</div>';
}`
    },
    {
      name: "src/pages/add_transaction.js",
      content: `function AddTransactionPage() {
  return '<div class="page page-add">' +
    Header({ title: "${safeName}" }) +
    '<main class="page-content">' +
      TransactionForm() +
    '</main>' +
    Footer() +
  '</div>';
}`
    },
    {
      name: "src/pages/history.js",
      content: `function HistoryPage() {
  return '<div class="page page-history">' +
    Header({ title: "${safeName}" }) +
    '<main class="page-content">' +
      TransactionList({ title: "ประวัติรายรับ-รายจ่ายทั้งหมด" }) +
    '</main>' +
    Footer() +
  '</div>';
}`
    },
    {
      name: "src/app.js",
      content: `// Zyntheor In-Memory State & Hash Router for Expense Tracker
var State = (function() {
  var memory = {
    transactions: [
      { id: "tx-1", title: "เงินเดือนประจำเดือน", amount: 35000, type: "income", category: "เงินเดือน", date: "2026-10-01" },
      { id: "tx-2", title: "ค่าเช่าห้องพัก", amount: 6500, type: "expense", category: "ที่อยู่อาศัย", date: "2026-10-02" },
      { id: "tx-3", title: "อาหารและเครื่องดื่ม", amount: 450, type: "expense", category: "อาหาร", date: "2026-10-03" }
    ]
  };
  return {
    get: function(key, defaultValue) {
      return memory[key] !== undefined ? memory[key] : defaultValue;
    },
    set: function(key, value) {
      memory[key] = value;
      return value;
    }
  };
})();

function escapeHtml(str) {
  return String(str || "").replace(/[&<>"']/g, function(m) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m];
  });
}

function handleTransactionSubmit(e) {
  if (e && e.preventDefault) e.preventDefault();
  var typeEl = document.getElementById("txType");
  var titleEl = document.getElementById("txTitle");
  var amountEl = document.getElementById("txAmount");
  var catEl = document.getElementById("txCategory");
  if (!titleEl || !amountEl) return;

  var type = typeEl ? typeEl.value : "expense";
  var title = titleEl.value.trim();
  var amount = parseFloat(amountEl.value) || 0;
  var category = catEl ? catEl.value.trim() : "ทั่วไป";

  if (!title || amount <= 0) return;

  var current = State.get("transactions", []);
  var newTx = {
    id: "tx-" + Date.now(),
    title: title,
    amount: amount,
    type: type,
    category: category || "ทั่วไป",
    date: new Date().toISOString().slice(0, 10)
  };
  State.set("transactions", [newTx].concat(current));
  window.location.hash = "#/";
}

function renderCurrentRoute() {
  var hash = window.location.hash || "#/";
  var path = hash.replace(/^#/, "") || "/";
  var appEl = document.getElementById("app");
  if (!appEl) return;

  if (path === "/add") {
    appEl.innerHTML = typeof AddTransactionPage === "function" ? AddTransactionPage() : "<h1>Page Not Found</h1>";
  } else if (path === "/history") {
    appEl.innerHTML = typeof HistoryPage === "function" ? HistoryPage() : "<h1>Page Not Found</h1>";
  } else {
    appEl.innerHTML = typeof DashboardPage === "function" ? DashboardPage() : (typeof HomePage === "function" ? HomePage() : "<h1>Dashboard Not Found</h1>");
  }
}

window.addEventListener("hashchange", renderCurrentRoute);
window.addEventListener("DOMContentLoaded", renderCurrentRoute);
renderCurrentRoute();`
    },
    {
      name: "src/styles.css",
      content: `* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: #0b0f19;
  color: #f1f5f9;
  line-height: 1.5;
}
.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  background: #111827;
  border-bottom: 1px solid rgba(148, 163, 184, 0.15);
}
.app-nav a {
  color: #94a3b8;
  text-decoration: none;
  margin-left: 16px;
  font-weight: 500;
}
.app-nav a:hover { color: #38bdf8; }
.page-content {
  max-width: 860px;
  margin: 32px auto;
  padding: 0 20px;
}
.summary-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}
.summary-card {
  background: #1e293b;
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 12px;
  padding: 20px;
}
.summary-card .label { font-size: 0.85rem; color: #94a3b8; }
.summary-card h2, .summary-card h3 { margin: 8px 0 0 0; }
.amount.pos { color: #34d399; }
.amount.neg { color: #f87171; }
.actions-bar {
  display: flex;
  gap: 12px;
  margin-bottom: 24px;
}
.btn {
  display: inline-block;
  padding: 10px 18px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  text-decoration: none;
  border: none;
}
.btn-primary { background: #0284c7; color: white; }
.btn-primary:hover { background: #0369a1; }
.btn-secondary { background: #334155; color: white; }
.btn-secondary:hover { background: #475569; }
.card {
  background: #1e293b;
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 12px;
  padding: 24px;
}
.tx-list h2 { margin-top: 0; font-size: 1.25rem; }
.list { list-style: none; padding: 0; margin: 0; }
.tx-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid rgba(148, 163, 184, 0.1);
}
.tx-item:last-child { border-bottom: none; }
.tx-info strong { display: block; }
.tx-info small { color: #94a3b8; }
.tx-form h2 { margin-top: 0; }
.form-group { margin-bottom: 16px; }
.form-group label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 0.9rem; }
.form-control {
  width: 100%;
  padding: 10px 12px;
  background: #0f172a;
  border: 1px solid #334155;
  border-radius: 6px;
  color: white;
  font-size: 1rem;
}
.form-control:focus { outline: none; border-color: #38bdf8; }
.app-footer {
  text-align: center;
  padding: 24px;
  color: #64748b;
  font-size: 0.85rem;
  border-top: 1px solid rgba(148, 163, 184, 0.1);
  margin-top: 60px;
}`
    }
  ];
}

export function createSmartAppProject(instruction: string, appName?: string): Array<{ name: string; content: string }> {
  const isExpense = /(?:รายรับ.*รายจ่าย|expense|finance|การเงิน|บันทึกรายรับ|เงินเดือน|บัญชี)/i.test(instruction);
  if (isExpense) {
    return createExpenseTrackerTemplate(appName || "แอปจัดการรายรับรายจ่าย");
  }
  return createStandardAppTemplate(appName || "Zyntheor App");
}

export async function generatePreviewBundle(requestedEntry?: string, requestedRoute?: string): Promise<{
  html: string;
  validation: WebsiteValidationResult;
  manifestValidation?: any;
}> {
  const validation = await validateWebsiteWorkspace();
  const manifestRecord = await readWorkspaceFile("app.json");
  let manifestValidation: any = undefined;

  let html = "";
  if (manifestRecord) {
    manifestValidation = await validateAppManifest();
    const manifest = manifestValidation.manifest as AppManifest;

    const entryName = requestedEntry && validation.files.includes(requestedEntry)
      ? requestedEntry
      : (manifest?.entry || "index.html");

    const entryFile = await readWorkspaceFile(entryName);
    html = entryFile ? entryFile.content : `<!DOCTYPE html><html><head></head><body><div id="app"></div></body></html>`;

    // Inlined styles
    const cssFiles = validation.files.filter((f) => /\.css$/i.test(f));
    let inlinedStyles = "";
    for (const cssName of cssFiles) {
      const cssFile = await readWorkspaceFile(cssName);
      if (cssFile) {
        const safeCss = cssFile.content.replace(/<\/style/gi, "<\\/style");
        inlinedStyles += `\n<style data-source="${cssName}">\n${safeCss}\n</style>`;
      }
    }

    // Inlined JS scripts in order: components -> pages -> app.js
    let inlinedScripts = "";
    if (manifest && Array.isArray(manifest.components)) {
      for (const comp of manifest.components) {
        const cleanPath = comp.file.replace(/^\.\//, "");
        const compFile = await readWorkspaceFile(cleanPath);
        if (compFile) {
          const safe = compFile.content.replace(/<\/script/gi, "<\\/script");
          inlinedScripts += `\n<!-- Component: ${comp.name} -->\n<script data-source="${cleanPath}">\n${safe}\n</script>`;
        }
      }
    }

    if (manifest && Array.isArray(manifest.routes)) {
      for (const route of manifest.routes) {
        const cleanPath = route.pageFile.replace(/^\.\//, "");
        const pageFile = await readWorkspaceFile(cleanPath);
        if (pageFile) {
          const safe = pageFile.content.replace(/<\/script/gi, "<\\/script");
          inlinedScripts += `\n<!-- Page: ${route.name} (${route.path}) -->\n<script data-source="${cleanPath}">\n${safe}\n</script>`;
        }
      }
    }

    // Finally router & app entry
    const appEntry = await readWorkspaceFile("src/app.js");
    if (appEntry) {
      const safe = appEntry.content.replace(/<\/script/gi, "<\\/script");
      inlinedScripts += `\n<!-- App Router & State -->\n<script data-source="src/app.js">\n${safe}\n</script>`;
    }

    if (requestedRoute) {
      const targetHash = requestedRoute.startsWith("#") ? requestedRoute : `#${requestedRoute}`;
      inlinedScripts += `\n<script>try { window.location.hash = ${JSON.stringify(targetHash)}; } catch(e){}</script>`;
    }

    const headInject = `${PREVIEW_CSP_META}\n${PREVIEW_ERROR_SCRIPT}\n${inlinedStyles}`;
    if (/<head(?:\s[^>]*)?>/i.test(html)) {
      html = html.replace(/<head(\s[^>]*)?>/i, (m) => `${m}\n${headInject}`);
    } else if (/<html(?:\s[^>]*)?>/i.test(html)) {
      html = html.replace(/<html(\s[^>]*)?>/i, (m) => `${m}\n<head>\n${headInject}\n</head>`);
    } else {
      html = `<!DOCTYPE html>\n<html>\n<head>\n${headInject}\n</head>\n<body>\n${html}\n</body>\n</html>`;
    }

    if (/<\/body>/i.test(html)) {
      html = html.replace(/<\/body>/i, () => `${inlinedScripts}\n</body>`);
    } else {
      html += inlinedScripts;
    }
  } else {
    // Static Website bundle fallback
    if (!validation.hasHtml || !validation.entryFile) {
      throw new WorkspaceFileError("no_html_entry", "No HTML file found in workspace for preview.", 404);
    }

    const entryName = requestedEntry && validation.files.includes(requestedEntry)
      ? requestedEntry
      : validation.entryFile;

    const entryFile = await readWorkspaceFile(entryName);
    if (!entryFile) {
      throw new WorkspaceFileError("file_not_found", `Entry file "${entryName}" not found.`, 404);
    }

    html = entryFile.content;

    const cssFiles = validation.files.filter((f) => /\.css$/i.test(f));
    let inlinedStyles = "";
    for (const cssName of cssFiles) {
      const cssFile = await readWorkspaceFile(cssName);
      if (cssFile) {
        const safeCss = cssFile.content.replace(/<\/style/gi, "<\\/style");
        inlinedStyles += `\n<style data-source="${cssName}">\n${safeCss}\n</style>`;
      }
    }

    const jsFiles = validation.files.filter((f) => /\.(?:js|mjs)$/i.test(f));
    let inlinedScripts = "";
    for (const jsName of jsFiles) {
      const jsFile = await readWorkspaceFile(jsName);
      if (jsFile) {
        const safeJs = jsFile.content.replace(/<\/script/gi, "<\\/script");
        inlinedScripts += `\n<script data-source="${jsName}">\n${safeJs}\n</script>`;
      }
    }

    const headInject = `${PREVIEW_CSP_META}\n${PREVIEW_ERROR_SCRIPT}\n${inlinedStyles}`;
    if (/<head(?:\s[^>]*)?>/i.test(html)) {
      html = html.replace(/<head(\s[^>]*)?>/i, (m) => `${m}\n${headInject}`);
    } else if (/<html(?:\s[^>]*)?>/i.test(html)) {
      html = html.replace(/<html(\s[^>]*)?>/i, (m) => `${m}\n<head>\n${headInject}\n</head>`);
    } else {
      html = `<!DOCTYPE html>\n<html>\n<head>\n${headInject}\n</head>\n<body>\n${html}\n</body>\n</html>`;
    }

    if (/<\/body>/i.test(html)) {
      html = html.replace(/<\/body>/i, () => `${inlinedScripts}\n</body>`);
    } else {
      html += inlinedScripts;
    }
  }

  // Check bundle for forbidden external URLs
  const hasExternalUrls = /\b(?:https?:)?\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/i.test(html.replace(/http:\/\/www\.w3\.org/g, ""));
  if (hasExternalUrls) {
    validation.warnings.push("Bundle contains external URLs; network calls are strictly blocked in sandbox.");
  }

  return {
    html,
    validation,
    manifestValidation
  };
}

export type FileSearchMatch = {
  lineNumber: number;
  lineText: string;
};

export type FileSearchResultItem = {
  name: string;
  path: string;
  size: number;
  lineCount: number;
  matches: FileSearchMatch[];
  matchedByName: boolean;
};

export type FileSearchResult = {
  status: "SUCCESS" | "EMPTY" | "ERROR";
  query: string;
  scope: string;
  totalFilesSearched: number;
  totalMatches: number;
  results: FileSearchResultItem[];
  containerNotice: string;
  reason?: string;
};

export async function searchWorkspaceFiles(
  query: string,
  options: {
    includeProjectCode?: boolean;
    maxResults?: number;
    maxMatchesPerFile?: number;
  } = {}
): Promise<FileSearchResult> {
  const q = (query || "").trim().toLowerCase();
  const containerNotice = "⚠️ หมายเหตุ: การค้นหาไฟล์นี้ดำเนินการภายในสภาพแวดล้อม Cloud Container Sandbox ของ ZYNTHEOR ไม่ใช่ไฟล์ทั้งหมดบนฮาร์ดไดรฟ์เครื่องของผู้ใช้";

  if (!q) {
    return {
      status: "EMPTY",
      query: "",
      scope: "Container Sandbox Workspace",
      totalFilesSearched: 0,
      totalMatches: 0,
      results: [],
      containerNotice,
      reason: "Query is empty.",
    };
  }

  // Reject malicious traversal query attempts in path
  if (q.includes("../") || q.includes("..\\") || q.startsWith("/etc") || q.startsWith("/proc") || q.startsWith("/sys")) {
    return {
      status: "ERROR",
      query,
      scope: "Container Sandbox Workspace",
      totalFilesSearched: 0,
      totalMatches: 0,
      results: [],
      containerNotice,
      reason: "Path traversal or system directory query blocked for security.",
    };
  }

  const maxResults = options.maxResults || 25;
  const maxMatchesPerFile = options.maxMatchesPerFile || 6;
  const results: FileSearchResultItem[] = [];
  let totalFilesSearched = 0;
  let totalMatches = 0;

  try {
    // 1. Search in primary workspace
    const workspaceFiles = await listWorkspaceFiles();
    for (const f of workspaceFiles) {
      totalFilesSearched++;
      if (isBlockedFilename(f.name)) continue;

      const nameLower = f.name.toLowerCase();
      const matchedByName = nameLower.includes(q);
      const content = f.content || "";
      const lines = content.split("\n");
      const matches: FileSearchMatch[] = [];

      for (let idx = 0; idx < lines.length; idx++) {
        const line = lines[idx];
        if (line.toLowerCase().includes(q)) {
          matches.push({
            lineNumber: idx + 1,
            lineText: redactSecrets(line.trim()).slice(0, 160),
          });
          if (matches.length >= maxMatchesPerFile) break;
        }
      }

      if (matchedByName || matches.length > 0) {
        totalMatches += matches.length;
        results.push({
          name: f.name,
          path: f.path,
          size: f.size,
          lineCount: f.lineCount,
          matches,
          matchedByName,
        });
        if (results.length >= maxResults) break;
      }
    }

    // 2. Also search project source files if requested or if workspace has fewer results
    const allowProjectSearch = options.includeProjectCode !== false;
    if (allowProjectSearch && results.length < maxResults) {
      const projectDirs = ["src", "server", "features", "docs"];
      const allowedRootFiles = ["package.json", "index.html", "metadata.json", "tsconfig.json", "vite.config.ts"];

      for (const rootFile of allowedRootFiles) {
        if (results.some((r) => r.name === rootFile)) continue;
        try {
          const filePath = join(process.cwd(), rootFile);
          const buf = await readFile(filePath);
          totalFilesSearched++;
          const content = buf.toString("utf8");
          const lines = content.split("\n");
          const matchedByName = rootFile.toLowerCase().includes(q);
          const matches: FileSearchMatch[] = [];

          for (let idx = 0; idx < lines.length; idx++) {
            const line = lines[idx];
            if (line.toLowerCase().includes(q)) {
              matches.push({
                lineNumber: idx + 1,
                lineText: redactSecrets(line.trim()).slice(0, 160),
              });
              if (matches.length >= maxMatchesPerFile) break;
            }
          }

          if (matchedByName || matches.length > 0) {
            totalMatches += matches.length;
            results.push({
              name: rootFile,
              path: filePath,
              size: buf.length,
              lineCount: lines.length,
              matches,
              matchedByName,
            });
            if (results.length >= maxResults) break;
          }
        } catch { /* skip */ }
      }

      for (const pDir of projectDirs) {
        if (results.length >= maxResults) break;
        const fullDirPath = join(process.cwd(), pDir);

        async function walkProject(currDir: string, relPrefix: string) {
          if (results.length >= maxResults) return;
          let entries;
          try {
            entries = await readdir(currDir, { withFileTypes: true });
          } catch {
            return;
          }

          for (const entry of entries) {
            if (results.length >= maxResults) return;
            const relPath = `${relPrefix}/${entry.name}`;
            const entryPath = join(currDir, entry.name);

            if (entry.isDirectory()) {
              if (["node_modules", ".git", "dist", ".data", "coverage"].includes(entry.name)) continue;
              await walkProject(entryPath, relPath);
            } else if (entry.isFile()) {
              if (isBlockedFilename(entry.name)) continue;
              const ext = detectFileExtension(entry.name);
              if (!isTextExtension(ext)) continue;

              try {
                const statInfo = await stat(entryPath);
                if (statInfo.size > MAX_INDIVIDUAL_FILE_SIZE) continue;

                totalFilesSearched++;
                const buf = await readFile(entryPath);
                const content = buf.toString("utf8");
                const lines = content.split("\n");
                const matchedByName = relPath.toLowerCase().includes(q);
                const matches: FileSearchMatch[] = [];

                for (let idx = 0; idx < lines.length; idx++) {
                  const line = lines[idx];
                  if (line.toLowerCase().includes(q)) {
                    matches.push({
                      lineNumber: idx + 1,
                      lineText: redactSecrets(line.trim()).slice(0, 160),
                    });
                    if (matches.length >= maxMatchesPerFile) break;
                  }
                }

                if (matchedByName || matches.length > 0) {
                  totalMatches += matches.length;
                  results.push({
                    name: relPath,
                    path: entryPath,
                    size: statInfo.size,
                    lineCount: lines.length,
                    matches,
                    matchedByName,
                  });
                }
              } catch { /* ignore read failures */ }
            }
          }
        }

        try {
          await walkProject(fullDirPath, pDir);
        } catch { /* ignore */ }
      }
    }

    return {
      status: results.length > 0 ? "SUCCESS" : "EMPTY",
      query,
      scope: "Container Sandbox Workspace & Project Source",
      totalFilesSearched,
      totalMatches,
      results,
      containerNotice,
    };
  } catch (err: any) {
    return {
      status: "ERROR",
      query,
      scope: "Container Sandbox Workspace",
      totalFilesSearched,
      totalMatches,
      results: [],
      containerNotice,
      reason: err?.message || "File search error",
    };
  }
}
