import { mkdir, open, readFile } from "node:fs/promises";
import { dirname } from "node:path";
import { createHash, randomUUID } from "node:crypto";

export type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
};

export type AgentEvent = {
  id: string;
  type: string;
  at: string;
  correlationId?: string;
  runId?: string;
  stepId?: string;
  status?: "RECEIVED" | "RECORDED" | "SUCCESS" | "FAILED" | "BLOCKED" | "REJECTED" | "UNAVAILABLE" | "UNKNOWN";
  data: Record<string, unknown>;
};

export type AuditAcknowledgment = {
  ackId: string;
  eventId: string;
  runId?: string;
  stepId?: string;
  correlationId?: string;
  type: string;
  recordedAt: string;
  status: "RECEIVED" | "RECORDED" | "SUCCESS" | "FAILED" | "BLOCKED" | "REJECTED" | "UNAVAILABLE" | "UNKNOWN";
  digest: string;
  acknowledged: boolean;
};

export function computeEventDigest(event: Pick<AgentEvent, "id" | "type" | "at"> & { runId?: string; stepId?: string; correlationId?: string; data?: Record<string, unknown> }): string {
  const payload = JSON.stringify({
    id: event.id,
    type: event.type,
    at: event.at,
    runId: event.runId || null,
    stepId: event.stepId || null,
    correlationId: event.correlationId || null,
    data: event.data || {}
  });
  return createHash("sha256").update(payload, "utf8").digest("hex");
}

type LedgerEntry =
  | { conversationId: string; message: Message }
  | { type: "agent_event"; event: AgentEvent };

const file = () => process.env.CHAT_STORE_PATH || ".data/conversations.jsonl";

export function redactSecrets(value: string): string {
  return value
    .replace(/\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})\b/gi, "[REDACTED]")
    .replace(/\b(([A-Z0-9_]*?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|secret))\s*[:=]\s*)[^\s,;]+/gi, "$1[REDACTED]")
    .replace(/\bBearer\s+[A-Za-z0-9._~+/-]+=*/gi, "Bearer [REDACTED]");
}

export function containsSensitiveData(value: unknown): boolean {
  if (value === null || value === undefined) return false;
  const str = typeof value === "string" ? value : JSON.stringify(value);
  const secretPattern =
    /(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|passwd|secret|private[_-]?key)\s*[:=]\s*[^\s,;"]+|Bearer\s+[A-Za-z0-9._~+/-]{16,})/i;
  return secretPattern.test(str);
}

function sanitizeAuditValue(value: unknown, key = ""): unknown {
  if (/(?:api[_-]?key|authorization|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|secret)/i.test(key)) {
    return "[REDACTED]";
  }
  if (typeof value === "string") return redactSecrets(value);
  if (Array.isArray(value)) return value.map((entry) => sanitizeAuditValue(entry));
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([childKey, child]) =>
      [childKey, sanitizeAuditValue(child, childKey)]
    ));
  }
  return value;
}

let ledgerQueue: Promise<void> = Promise.resolve();
async function withLedgerLock<T>(operation: () => Promise<T>): Promise<T> {
  const previous = ledgerQueue;
  let release!: () => void;
  ledgerQueue = new Promise<void>((resolve) => { release = resolve; });
  await previous;
  try {
    return await operation();
  } finally {
    release();
  }
}

async function readLedger(): Promise<LedgerEntry[]> {
  return withLedgerLock(async () => {
    let contents: string;
    try {
      contents = await readFile(file(), "utf8");
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
      throw error;
    }

    const entries: LedgerEntry[] = [];
    for (const [index, line] of contents.split("\n").entries()) {
      if (!line.trim()) continue;
      let value: unknown;
      try {
        value = JSON.parse(line);
      } catch {
        throw new Error(`Invalid JSONL ledger entry at line ${index + 1}`);
      }
      if (!value || typeof value !== "object") {
        throw new Error(`Invalid JSONL ledger entry at line ${index + 1}`);
      }
      const row = value as Record<string, unknown>;
      const event = row.event && typeof row.event === "object" ? row.event as Record<string, unknown> : undefined;
      const message = row.message && typeof row.message === "object" ? row.message as Record<string, unknown> : undefined;
      if (
        row.type === "agent_event" &&
        event &&
        typeof event.id === "string" &&
        typeof event.type === "string" &&
        typeof event.at === "string" &&
        event.data !== null &&
        typeof event.data === "object" &&
        !Array.isArray(event.data)
      ) {
        entries.push(row as unknown as LedgerEntry);
      } else if (
        typeof row.conversationId === "string" &&
        message &&
        typeof message.id === "string" &&
        ["user", "assistant"].includes(String(message.role)) &&
        typeof message.content === "string" &&
        typeof message.createdAt === "string"
      ) {
        entries.push(row as unknown as LedgerEntry);
      } else {
        throw new Error(`Unknown JSONL ledger entry at line ${index + 1}`);
      }
    }
    return entries;
  });
}

async function append(entry: LedgerEntry): Promise<void> {
  await withLedgerLock(async () => {
    const target = file();
    await mkdir(dirname(target), { recursive: true });
    const handle = await open(target, "a");
    try {
      await handle.writeFile(`${JSON.stringify(entry)}\n`, "utf8");
      await handle.sync();
    } finally {
      await handle.close();
    }
  });
}

export async function saveMessage(conversationId: string, message: Message): Promise<void> {
  await append({ conversationId, message: { ...message, content: redactSecrets(message.content) } });
}

export async function loadMessages(conversationId: string): Promise<Message[]> {
  return (await readLedger())
    .filter((entry): entry is Extract<LedgerEntry, { conversationId: string }> => "conversationId" in entry)
    .filter((entry) => entry.conversationId === conversationId)
    .map((entry) => entry.message)
    .filter((message) =>
      message &&
      ["user", "assistant"].includes(message.role) &&
      typeof message.content === "string" &&
      typeof message.createdAt === "string"
    );
}

export async function saveAgentEvent(event: AgentEvent): Promise<AuditAcknowledgment> {
  const sanitized = sanitizeAuditValue(event) as AgentEvent;
  const digest = computeEventDigest(sanitized);
  await append({ type: "agent_event", event: sanitized });
  const rawStatus = sanitized.status || "RECORDED";
  const status: AuditAcknowledgment["status"] =
    rawStatus === "SUCCESS" ? "SUCCESS" :
    rawStatus === "FAILED" ? "FAILED" :
    rawStatus === "BLOCKED" ? "BLOCKED" :
    rawStatus === "RECEIVED" ? "RECEIVED" :
    rawStatus === "REJECTED" ? "REJECTED" :
    rawStatus === "UNAVAILABLE" ? "UNAVAILABLE" :
    rawStatus === "UNKNOWN" ? "UNKNOWN" : "RECORDED";
  return {
    ackId: `ack_${randomUUID()}`,
    eventId: sanitized.id,
    runId: sanitized.runId,
    stepId: sanitized.stepId,
    correlationId: sanitized.correlationId,
    type: sanitized.type,
    recordedAt: sanitized.at,
    status,
    digest,
    acknowledged: true,
  };
}

export async function getAgentEventById(id: string): Promise<AgentEvent | undefined> {
  const events = await loadAgentEvents();
  return events.find((e) => e.id === id);
}

export async function loadAgentEvents(): Promise<AgentEvent[]> {
  return (await readLedger())
    .filter((entry): entry is Extract<LedgerEntry, { type: "agent_event" }> => "type" in entry)
    .map((entry) => entry.event);
}

export type ConversationSummary = {
  id: string;
  title: string;
  preview: string;
  messageCount: number;
  lastMessageAt: string;
};

export async function listConversations(): Promise<ConversationSummary[]> {
  const entries = (await readLedger())
    .filter((entry): entry is Extract<LedgerEntry, { conversationId: string }> => "conversationId" in entry);

  const map = new Map<string, { title: string; preview: string; messageCount: number; lastMessageAt: string }>();

  for (const entry of entries) {
    const existing = map.get(entry.conversationId);
    const content = (entry.message?.content || "").trim();
    if (!existing) {
      const cleanTitle = content.split("\n")[0].slice(0, 60) || `Session ${entry.conversationId.slice(0, 8)}`;
      map.set(entry.conversationId, {
        title: cleanTitle,
        preview: content.slice(0, 120),
        messageCount: 1,
        lastMessageAt: entry.message?.createdAt || new Date().toISOString()
      });
    } else {
      existing.messageCount++;
      if (entry.message?.createdAt && entry.message.createdAt > existing.lastMessageAt) {
        existing.lastMessageAt = entry.message.createdAt;
      }
      if (entry.message?.role === "user" && existing.messageCount <= 2 && content) {
        existing.title = content.split("\n")[0].slice(0, 60);
      }
      if (content) {
        existing.preview = content.slice(0, 120);
      }
    }
  }


  return Array.from(map.entries())
    .map(([id, data]) => ({ id, ...data }))
    .sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt));
}

export type EvidenceLedgerRecord = {
  id: string;
  taskId: string;
  correlationId?: string;
  command: string | string[];
  taskType: string;
  exitCode: number;
  outputSummary: string;
  changedFiles: string[];
  timestamps: {
    startedAt: string;
    finishedAt: string;
    durationMs: number;
  };
  verificationStatus: "VERIFIED" | "FAILED" | "UNKNOWN";
  verifiedAt?: string;
  details?: Record<string, unknown>;
};

export async function saveEvidenceRecord(record: EvidenceLedgerRecord): Promise<void> {
  // Ensure all values are scrubbed of secrets before saving
  const sanitizedRecord: EvidenceLedgerRecord = {
    ...record,
    outputSummary: redactSecrets(record.outputSummary || ""),
    command: Array.isArray(record.command)
      ? record.command.map((c) => redactSecrets(c))
      : redactSecrets(record.command || ""),
    details: record.details ? (sanitizeAuditValue(record.details) as Record<string, unknown>) : undefined,
  };

  await saveAgentEvent({
    id: record.id || `ev_rec_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    type: "evidence_ledger_entry",
    at: record.timestamps?.finishedAt || new Date().toISOString(),
    correlationId: record.correlationId,
    data: sanitizedRecord as unknown as Record<string, unknown>,
  });
}

export async function loadEvidenceRecords(): Promise<EvidenceLedgerRecord[]> {
  const events = await loadAgentEvents();
  return events
    .filter((e) => e.type === "evidence_ledger_entry")
    .map((e) => e.data as unknown as EvidenceLedgerRecord);
}

