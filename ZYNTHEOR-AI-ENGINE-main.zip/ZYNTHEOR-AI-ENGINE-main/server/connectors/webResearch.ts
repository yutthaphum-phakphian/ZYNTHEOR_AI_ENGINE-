/**
 * Web Research connector — real network adapter (read-only).
 *
 * Honesty rules (same as ConnectorHub):
 *  - SUCCESS only when a real HTTP response was obtained and processed.
 *  - search uses DuckDuckGo HTML (no API key). If parsing yields zero results
 *    we still return SUCCESS with an empty list + note — never fabricate hits.
 *  - Safety: http(s) only, block private/link-local ranges, size + timeout
 *    limits, no credential leakage.
 */
import type { ConnectorAdapter } from "../connectorHub.js";
import { redactSecrets } from "../store.js";

const DEFAULT_TIMEOUT_MS = 8_000;
const MAX_BYTES = 512 * 1024; // 512 KB
const MAX_REDIRECTS = 3;
const USER_AGENT = "Zyntheor-WebResearch/1.0 (+https://zyntheor.local; read-only research)";

/** IPv4 private / link-local / loopback ranges we refuse to contact. */
const BLOCKED_IPV4 = [
  /^127\./,
  /^10\./,
  /^192\.168\./,
  /^172\.(1[6-9]|2\d|3[0-1])\./,
  /^169\.254\./,
  /^0\./,
  /^100\.(6[4-9]|[7-9]\d|1[0-2]\d)\./, // CGNAT
];

export function isBlockedHostname(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/\.$/, "").replace(/^\[|\]$/g, "");
  if (
    h === "localhost" ||
    h.endsWith(".localhost") ||
    h.endsWith(".local") ||
    h.endsWith(".internal") ||
    h === "metadata.google.internal" ||
    h === "instance-data"
  ) {
    return true;
  }

  // IPv6 loopback, link-local, ULA, IPv4-mapped loopback
  if (
    h === "::1" ||
    h === "::" ||
    h.startsWith("fe80:") ||
    h.startsWith("fc00:") ||
    h.startsWith("fd00:") ||
    h.startsWith("::ffff:127.") ||
    h.startsWith("::ffff:10.") ||
    h.startsWith("::ffff:192.168.")
  ) {
    return true;
  }

  // IPv4 dotted-decimal
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) {
    return BLOCKED_IPV4.some((re) => re.test(h));
  }

  // Hexadecimal (0x7f000001) or Decimal Dword (2130706433) IPv4 representation bypass protection
  if (/^0x[0-9a-f]+$/i.test(h) || /^\d{8,11}$/.test(h)) {
    return true;
  }

  return false;
}

export function assertSafeUrl(raw: unknown): URL {
  if (typeof raw !== "string" || !raw.trim()) {
    throw new Error("url is required and must be a non-empty string");
  }
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    throw new Error("url is not a valid absolute URL");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("only http and https URLs are allowed");
  }
  if (url.username || url.password) {
    throw new Error("URLs containing credentials are not allowed");
  }
  if (isBlockedHostname(url.hostname)) {
    throw new Error("requests to private, loopback, or link-local hosts are blocked");
  }
  // Block internal ports (e.g., local applet dev server on 3000, internal databases)
  const port = url.port ? parseInt(url.port, 10) : (url.protocol === "https:" ? 443 : 80);
  const BLOCKED_INTERNAL_PORTS = new Set([3000, 22, 23, 25, 3306, 5432, 6379, 27017, 9200, 11211]);
  if (BLOCKED_INTERNAL_PORTS.has(port)) {
    throw new Error(`requests to internal port ${port} are blocked`);
  }
  return url;
}

/**
 * Sanitizes untrusted external web text to defend against indirect prompt injections.
 * Neutralizes jailbreak patterns, system prompt overrides, and tags untrusted content.
 */
export function sanitizeExternalWebText(rawText: string): { cleanText: string; hasPromptInjectionMarkers: boolean } {
  if (!rawText) return { cleanText: "", hasPromptInjectionMarkers: false };

  const PROMPT_INJECTION_PATTERNS = [
    /\bignore\s+(?:all\s+)?previous\s+instructions\b/gi,
    /\bdisregard\s+(?:all\s+)?prior\s+instructions\b/gi,
    /\byou\s+are\s+now\s+(?:in\s+)?(?:developer\s+mode|dan|unrestricted)\b/gi,
    /\b<\|im_start\|>/gi,
    /\b<\|im_end\|>/gi,
    /\[(?:system|override|jailbreak)\]/gi,
    /\bbypass\s+safety\s+(?:filters|rules|guidelines)\b/gi,
    /\bdo\s+not\s+follow\s+the\s+system\s+prompt\b/gi,
  ];

  let detected = false;
  let sanitized = rawText;

  for (const pattern of PROMPT_INJECTION_PATTERNS) {
    if (pattern.test(sanitized)) {
      detected = true;
      sanitized = sanitized.replace(pattern, (match) => `[UNTRUSTED_CONTENT_SHIELDED: ${match}]`);
    }
  }

  return {
    cleanText: sanitized,
    hasPromptInjectionMarkers: detected,
  };
}

/** Strip tags roughly and collapse whitespace — good enough for research snippets. */
export function htmlToText(html: string): string {
  let t = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
  return t.slice(0, 32_000);
}

function extractTitle(html: string): string | undefined {
  const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  if (!m) return undefined;
  return m[1].replace(/\s+/g, " ").trim().slice(0, 300) || undefined;
}

export type WebResearchFetchResult = {
  url: string;
  finalUrl: string;
  status: number;
  contentType: string | null;
  title?: string;
  text: string;
  bytes: number;
  truncated: boolean;
  fetchedAt: string;
};

export type WebResearchSearchHit = {
  title: string;
  url: string;
  snippet: string;
};

export type WebResearchSearchResult = {
  query: string;
  provider: string;
  results: WebResearchSearchHit[];
  note?: string;
  fetchedAt: string;
};

export interface WebResearchOptions {
  /** Injected fetch for tests. Defaults to global fetch. */
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

/**
 * Create a real web_research ConnectorAdapter.
 * Register it with the hub; grant "read" before invoking.
 */
export function createWebResearchAdapter(opts: WebResearchOptions = {}): ConnectorAdapter {
  const fetchImpl = opts.fetchImpl ?? fetch;
  const timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;

  return {
    id: "web_research",
    label: "Web research",
    permissions: ["read"],

    async checkAvailability() {
      if (typeof fetchImpl !== "function") {
        return { available: false, reason: "no fetch implementation" };
      }
      return { available: true };
    },

    async invoke(action: string, input: Record<string, unknown>, ctx: { signal: AbortSignal }) {
      if (action === "fetch_page") {
        return fetchPage(fetchImpl, input, ctx.signal, timeoutMs);
      }
      if (action === "search") {
        return searchDuckDuckGo(fetchImpl, input, ctx.signal, timeoutMs);
      }
      throw new Error(`unknown action "${action}"; supported: fetch_page, search`);
    },
  };
}

async function fetchPage(
  fetchImpl: typeof fetch,
  input: Record<string, unknown>,
  parentSignal: AbortSignal,
  timeoutMs: number,
): Promise<WebResearchFetchResult> {
  const url = assertSafeUrl(input.url);
  const maxBytes = typeof input.maxBytes === "number" && input.maxBytes > 0
    ? Math.min(input.maxBytes, MAX_BYTES)
    : MAX_BYTES;

  const controller = new AbortController();
  const onParentAbort = () => controller.abort();
  parentSignal.addEventListener("abort", onParentAbort);
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let current = url;
  let redirects = 0;
  let res: Response;

  try {
    while (true) {
      res = await fetchImpl(current.toString(), {
        method: "GET",
        redirect: "manual",
        headers: {
          "User-Agent": USER_AGENT,
          Accept: "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5",
          "Accept-Language": "en,th;q=0.8",
        },
        signal: controller.signal,
      });

      if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
        redirects += 1;
        if (redirects > MAX_REDIRECTS) {
          throw new Error(`too many redirects (>${MAX_REDIRECTS})`);
        }
        const next = new URL(res.headers.get("location")!, current);
        assertSafeUrl(next.toString());
        current = next;
        continue;
      }
      break;
    }

    if (!res.ok) {
      throw new Error(`HTTP ${res.status} ${res.statusText || ""}`.trim());
    }

    const contentType = res.headers.get("content-type");
    const reader = res.body?.getReader();
    if (!reader) {
      const buf = Buffer.from(await res.arrayBuffer());
      const truncated = buf.length > maxBytes;
      const slice = truncated ? buf.subarray(0, maxBytes) : buf;
      return finalize(current, url, res.status, contentType, slice, truncated);
    }

    const chunks: Uint8Array[] = [];
    let total = 0;
    let truncated = false;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      if (total + value.length > maxBytes) {
        chunks.push(value.subarray(0, maxBytes - total));
        total = maxBytes;
        truncated = true;
        try { reader.cancel(); } catch { /* ignore */ }
        break;
      }
      chunks.push(value);
      total += value.length;
    }
    const buf = Buffer.concat(chunks.map((c) => Buffer.from(c)));
    return finalize(current, url, res.status, contentType, buf, truncated);
  } catch (e) {
    if (controller.signal.aborted) {
      throw new Error("request aborted or timed out");
    }
    const msg = e instanceof Error ? e.message : "fetch failed";
    throw new Error(redactSecrets(msg));
  } finally {
    clearTimeout(timer);
    parentSignal.removeEventListener("abort", onParentAbort);
  }
}

function finalize(
  finalUrl: URL,
  original: URL,
  status: number,
  contentType: string | null,
  buf: Buffer,
  truncated: boolean,
): WebResearchFetchResult {
  const isHtml = !contentType || /text\/html|application\/xhtml/i.test(contentType);
  const isText = isHtml || /text\/plain|json|xml|javascript|csv/i.test(contentType ?? "");
  let text: string;
  let title: string | undefined;
  if (isText) {
    const raw = buf.toString("utf8");
    if (isHtml) {
      title = extractTitle(raw);
      text = htmlToText(raw);
    } else {
      text = raw.slice(0, 32_000);
    }
  } else {
    text = `[binary or non-text content: ${contentType ?? "unknown"}, ${buf.length} bytes]`;
  }
  const sanitized = sanitizeExternalWebText(text);
  return {
    url: original.toString(),
    finalUrl: finalUrl.toString(),
    status,
    contentType,
    title,
    text: sanitized.cleanText,
    bytes: buf.length,
    truncated,
    fetchedAt: new Date().toISOString(),
  };
}

/**
 * DuckDuckGo HTML search (no API key).
 * Parses result links from the lightweight HTML endpoint.
 * Returns empty results + note when nothing parseable — never invents hits.
 */
async function searchDuckDuckGo(
  fetchImpl: typeof fetch,
  input: Record<string, unknown>,
  parentSignal: AbortSignal,
  timeoutMs: number,
): Promise<WebResearchSearchResult> {
  const query = typeof input.query === "string" ? input.query.trim() : "";
  if (!query || query.length > 300) {
    throw new Error("query is required (1–300 characters)");
  }
  const maxResults = typeof input.maxResults === "number" && input.maxResults > 0
    ? Math.min(Math.floor(input.maxResults), 10)
    : 5;

  const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const controller = new AbortController();
  const onParentAbort = () => controller.abort();
  parentSignal.addEventListener("abort", onParentAbort);
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetchImpl(searchUrl, {
      method: "GET",
      headers: {
        "User-Agent": USER_AGENT,
        Accept: "text/html",
        "Accept-Language": "en,th;q=0.8",
      },
      signal: controller.signal,
      redirect: "follow",
    });
    if (!res.ok) {
      throw new Error(`search provider HTTP ${res.status}`);
    }
    const html = (await res.text()).slice(0, MAX_BYTES);
    const results = parseDuckDuckGoHtml(html, maxResults);
    return {
      query,
      provider: "duckduckgo_html",
      results,
      note: results.length === 0
        ? "Provider returned no parseable results (layout may have changed or query had no hits)."
        : undefined,
      fetchedAt: new Date().toISOString(),
    };
  } catch (e) {
    if (controller.signal.aborted) {
      throw new Error("search request aborted or timed out");
    }
    throw new Error(redactSecrets(e instanceof Error ? e.message : "search failed"));
  } finally {
    clearTimeout(timer);
    parentSignal.removeEventListener("abort", onParentAbort);
  }
}

/** Extract organic result blocks from DuckDuckGo HTML. */
export function parseDuckDuckGoHtml(html: string, maxResults: number): WebResearchSearchHit[] {
  const results: WebResearchSearchHit[] = [];
  // Result links look like: <a rel="nofollow" class="result__a" href="...">Title</a>
  // Snippet: <a class="result__snippet" ...> or <td class="result__snippet">
  const linkRe = /<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m: RegExpExecArray | null;
  while ((m = linkRe.exec(html)) !== null && results.length < maxResults) {
    let href = m[1];
    // DDG sometimes wraps redirects: //duckduckgo.com/l/?uddg=<encoded>
    try {
      if (href.includes("uddg=")) {
        const u = new URL(href.startsWith("http") ? href : `https:${href}`);
        const real = u.searchParams.get("uddg");
        if (real) href = decodeURIComponent(real);
      }
    } catch { /* keep original */ }
    if (!/^https?:\/\//i.test(href)) continue;
    const title = htmlToText(m[2]).slice(0, 200);
    if (!title) continue;
    // Try to find a nearby snippet
    const after = html.slice(m.index, m.index + 1200);
    const snipMatch = after.match(/class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|td|div)>/i);
    const snippet = snipMatch ? htmlToText(snipMatch[1]).slice(0, 300) : "";
    results.push({ title, url: href, snippet });
  }
  return results;
}

/** Convenience singleton for the process (tests should create their own). */
export const webResearchAdapter = createWebResearchAdapter();
