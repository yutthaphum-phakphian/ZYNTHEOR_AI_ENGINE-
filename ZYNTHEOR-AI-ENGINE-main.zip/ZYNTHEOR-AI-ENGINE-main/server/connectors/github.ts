/**
 * GitHub connector — read-only public REST API adapter on ConnectorHub.
 *
 * Implements exactly 3 strictly validated actions using the public GitHub REST API:
 *  1. get_repo    — Read public repository metadata (owner, repo)
 *  2. get_file    — Read file content via Contents API (owner, repo, path, [ref])
 *  3. list_issues — List repository issues excluding pull requests (owner, repo, [state], [perPage])
 *
 * Honesty & Safety rules:
 *  - Real GitHub REST API (https://api.github.com) calls only.
 *  - Read-only: no write or mutate actions are ever allowed or implemented.
 *  - Strict input validation before any network request (rejects traversal, invalid characters, injections).
 *  - Optional GITHUB_TOKEN used when configured for higher rate limits and authenticated requests.
 *  - Secret tokens are redacted from all error messages and responses.
 */
import type { ConnectorAdapter } from "../connectorHub.js";
import { redactSecrets } from "../store.js";

const API = "https://api.github.com";
const USER_AGENT = "Zyntheor-GitHubConnector/1.0";
const DEFAULT_TIMEOUT_MS = 10_000;

export const GITHUB_ACTIONS = ["get_repo", "get_file", "list_issues", "search"] as const;
export type GitHubAction = typeof GITHUB_ACTIONS[number];

export type GitHubOptions = {
  fetchImpl?: typeof fetch;
  token?: string | null;
  timeoutMs?: number;
};

// Strict input validation rules
const OWNER_REGEX = /^[a-zA-Z0-9](?:[a-zA-Z0-9._-]{0,37}[a-zA-Z0-9])?$/;
const REPO_REGEX = /^[a-zA-Z0-9_.-]{1,100}$/;
const REF_REGEX = /^[a-zA-Z0-9_./-]{1,100}$/;
const ALLOWED_ISSUE_STATES = new Set(["open", "closed", "all"]);

export function validateOwner(raw: unknown): string {
  if (typeof raw !== "string" || !raw.trim()) {
    throw new Error("owner is required and must be a non-empty string");
  }
  const owner = raw.trim();
  if (owner.length > 39 || !OWNER_REGEX.test(owner) || owner.includes("..") || owner.includes("/")) {
    throw new Error(`invalid owner "${owner}": must be 1-39 alphanumeric characters, dots, underscores, or hyphens`);
  }
  return owner;
}

export function validateRepo(raw: unknown): string {
  if (typeof raw !== "string" || !raw.trim()) {
    throw new Error("repo is required and must be a non-empty string");
  }
  const repo = raw.trim();
  if (repo === "." || repo === ".." || repo.length > 100 || !REPO_REGEX.test(repo) || repo.includes("/")) {
    throw new Error(`invalid repo "${repo}": must be 1-100 alphanumeric characters, dots, underscores, or hyphens`);
  }
  return repo;
}

export function validateFilePath(raw: unknown): string {
  if (typeof raw !== "string" || !raw.trim()) {
    throw new Error("path is required and must be a non-empty string");
  }
  const path = raw.trim().replace(/^\/+/, "");
  if (!path) {
    throw new Error("path cannot be empty");
  }
  if (path.length > 500) {
    throw new Error("path must not exceed 500 characters");
  }
  if (path.includes("\0")) {
    throw new Error("path must not contain null characters");
  }
  // Prevent path traversal
  const segments = path.split("/");
  for (const seg of segments) {
    if (seg === ".." || seg === ".") {
      throw new Error(`invalid path "${path}": path traversal is not allowed`);
    }
  }
  return path;
}

export function validateRef(raw: unknown): string {
  if (raw === undefined || raw === null || raw === "") return "HEAD";
  if (typeof raw !== "string") throw new Error("ref must be a string");
  const ref = raw.trim();
  if (!ref) return "HEAD";
  if (ref.length > 100 || !REF_REGEX.test(ref) || ref.includes("..")) {
    throw new Error(`invalid ref "${ref}": must be 1-100 alphanumeric characters, dots, slashes, or hyphens`);
  }
  return ref;
}

export function validateIssueState(raw: unknown): "open" | "closed" | "all" {
  if (raw === undefined || raw === null || raw === "") return "open";
  if (typeof raw !== "string") throw new Error("state must be a string ('open', 'closed', 'all')");
  const s = raw.trim().toLowerCase();
  if (!ALLOWED_ISSUE_STATES.has(s)) {
    throw new Error(`invalid state "${s}": must be one of 'open', 'closed', 'all'`);
  }
  return s as "open" | "closed" | "all";
}

export function validatePerPage(raw: unknown): number {
  if (raw === undefined || raw === null || raw === "") return 10;
  const n = typeof raw === "number" ? raw : parseInt(String(raw), 10);
  if (isNaN(n) || !Number.isInteger(n) || n < 1 || n > 30) {
    throw new Error(`invalid perPage "${raw}": must be an integer between 1 and 30`);
  }
  return n;
}

export function validateSearchQuery(raw: unknown): string {
  if (typeof raw !== "string" || !raw.trim()) {
    throw new Error("query is required and must be a non-empty string");
  }
  const q = raw.trim();
  if (q.length > 200) {
    throw new Error("query must not exceed 200 characters");
  }
  return q;
}

export function validateSearchType(raw: unknown): "issues" | "files" | "all" {
  if (raw === undefined || raw === null || raw === "") return "all";
  if (typeof raw !== "string") throw new Error("type must be a string ('issues', 'files', 'all')");
  const s = raw.trim().toLowerCase();
  if (s !== "issues" && s !== "files" && s !== "all") {
    throw new Error(`invalid search type "${s}": must be one of 'issues', 'files', 'all'`);
  }
  return s as "issues" | "files" | "all";
}

function tokenFromEnv(): string | null {
  const t = process.env.GITHUB_TOKEN?.trim();
  return t && t.length >= 8 ? t : null;
}

function headers(token: string | null): Record<string, string> {
  const h: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "User-Agent": USER_AGENT,
    "X-GitHub-Api-Version": "2022-11-28",
  };
  if (token) h.Authorization = `Bearer ${token}`;
  return h;
}

export function createGitHubAdapter(opts: GitHubOptions = {}): ConnectorAdapter {
  const fetchImpl = opts.fetchImpl ?? fetch;
  const token = opts.token !== undefined ? opts.token : tokenFromEnv();
  const timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;

  return {
    id: "github",
    label: "GitHub",
    permissions: ["read"],

    async checkAvailability() {
      if (typeof fetchImpl !== "function") {
        return { available: false, reason: "no fetch implementation" };
      }
      return {
        available: true,
        reason: token ? "token configured" : "public access only (no GITHUB_TOKEN)",
      };
    },

    async invoke(action: string, input: Record<string, unknown>, ctx: { signal: AbortSignal }) {
      if (typeof input !== "object" || input === null || Array.isArray(input)) {
        throw new Error("input must be an object");
      }
      switch (action) {
        case "get_repo":
          return getRepo(fetchImpl, token, input, ctx.signal, timeoutMs);
        case "get_file":
          return getFile(fetchImpl, token, input, ctx.signal, timeoutMs);
        case "list_issues":
          return listIssues(fetchImpl, token, input, ctx.signal, timeoutMs);
        case "search":
          return searchInRepo(fetchImpl, token, input, ctx.signal, timeoutMs);
        case "get_readme":
          // Backwards compatibility alias for get_file README.md
          return getFile(fetchImpl, token, { ...input, path: "README.md" }, ctx.signal, timeoutMs);
        default:
          throw new Error(
            `unknown action "${action}"; supported read-only actions are: ${GITHUB_ACTIONS.join(", ")}`,
          );
      }
    },
  };
}

async function apiGet(
  fetchImpl: typeof fetch,
  token: string | null,
  path: string,
  parentSignal: AbortSignal,
  timeoutMs: number,
): Promise<{ status: number; json: unknown; text: string }> {
  const controller = new AbortController();
  const onAbort = () => controller.abort();
  parentSignal.addEventListener("abort", onAbort);
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetchImpl(`${API}${path}`, {
      method: "GET",
      headers: headers(token),
      signal: controller.signal,
    });
    const text = await res.text();
    let json: unknown = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* non-json */ }
    if (!res.ok) {
      const msg =
        json && typeof json === "object" && json !== null && "message" in json
          ? String((json as { message: unknown }).message)
          : `HTTP ${res.status}`;
      throw new Error(redactSecrets(msg));
    }
    return { status: res.status, json, text };
  } catch (e) {
    if (controller.signal.aborted) throw new Error("request aborted or timed out");
    throw e instanceof Error ? e : new Error(String(e));
  } finally {
    clearTimeout(timer);
    parentSignal.removeEventListener("abort", onAbort);
  }
}

/** Action 1: get_repo — Read public repository metadata */
async function getRepo(
  fetchImpl: typeof fetch,
  token: string | null,
  input: Record<string, unknown>,
  signal: AbortSignal,
  timeoutMs: number,
) {
  const owner = validateOwner(input.owner);
  const repo = validateRepo(input.repo);
  const { json } = await apiGet(fetchImpl, token, `/repos/${owner}/${repo}`, signal, timeoutMs);
  const r = json as Record<string, unknown>;
  return {
    fullName: r.full_name,
    description: r.description ?? null,
    defaultBranch: r.default_branch,
    stars: r.stargazers_count,
    forks: r.forks_count,
    openIssues: r.open_issues_count,
    language: r.language ?? null,
    private: r.private,
    htmlUrl: r.html_url,
    fetchedAt: new Date().toISOString(),
  };
}

/** Action 2: get_file — Read file content via Contents API */
async function getFile(
  fetchImpl: typeof fetch,
  token: string | null,
  input: Record<string, unknown>,
  signal: AbortSignal,
  timeoutMs: number,
) {
  const owner = validateOwner(input.owner);
  const repo = validateRepo(input.repo);
  const path = validateFilePath(input.path);
  const ref = validateRef(input.ref);

  const encodedPath = path.split("/").map(encodeURIComponent).join("/");
  const apiPath = `/repos/${owner}/${repo}/contents/${encodedPath}?ref=${encodeURIComponent(ref)}`;
  const { json } = await apiGet(fetchImpl, token, apiPath, signal, timeoutMs);
  const r = json as Record<string, unknown>;
  if (r.type !== "file" || typeof r.content !== "string") {
    throw new Error(`path "${path}" is not a file or content is missing`);
  }
  const encoding = r.encoding === "base64" ? "base64" : "utf8";
  const content =
    encoding === "base64"
      ? Buffer.from(r.content.replace(/\n/g, ""), "base64").toString("utf8")
      : String(r.content);

  const max = 200_000;
  const truncated = content.length > max;
  return {
    owner,
    repo,
    path,
    ref,
    size: r.size,
    sha: r.sha,
    htmlUrl: r.html_url,
    content: truncated ? content.slice(0, max) : content,
    truncated,
    fetchedAt: new Date().toISOString(),
  };
}

/** Action 3: list_issues — List issues on public repository */
async function listIssues(
  fetchImpl: typeof fetch,
  token: string | null,
  input: Record<string, unknown>,
  signal: AbortSignal,
  timeoutMs: number,
) {
  const owner = validateOwner(input.owner);
  const repo = validateRepo(input.repo);
  const state = validateIssueState(input.state);
  const perPage = validatePerPage(input.perPage);

  const path = `/repos/${owner}/${repo}/issues?state=${state}&per_page=${perPage}&pulls=false`;
  const { json } = await apiGet(fetchImpl, token, path, signal, timeoutMs);
  const items = Array.isArray(json) ? json : [];
  // Filter out pull requests which GitHub includes in issues endpoint
  const issues = items
    .filter((i) => i && typeof i === "object" && !("pull_request" in (i as object)))
    .map((i) => {
      const x = i as Record<string, unknown>;
      return {
        number: x.number,
        title: x.title,
        state: x.state,
        user: (x.user as { login?: string } | null)?.login ?? null,
        htmlUrl: x.html_url,
        createdAt: x.created_at,
      };
    });
  return {
    owner,
    repo,
    state,
    count: issues.length,
    issues,
    fetchedAt: new Date().toISOString(),
  };
}

/** Action 4: search — Search issues and/or files in public repository */
async function searchInRepo(
  fetchImpl: typeof fetch,
  token: string | null,
  input: Record<string, unknown>,
  signal: AbortSignal,
  timeoutMs: number,
) {
  const owner = validateOwner(input.owner);
  const repo = validateRepo(input.repo);
  const query = validateSearchQuery(input.query);
  const type = validateSearchType(input.type);
  const perPage = validatePerPage(input.perPage ?? 10);

  let issues: Array<{
    number: number;
    title: string;
    state: string;
    isPullRequest: boolean;
    user: string | null;
    htmlUrl: string;
    createdAt: string;
    comments?: number;
  }> = [];

  let files: Array<{
    name: string;
    path: string;
    sha?: string;
    htmlUrl: string;
  }> = [];

  // 1. Search Issues & PRs
  if (type === "issues" || type === "all") {
    try {
      const q = encodeURIComponent(`${query} repo:${owner}/${repo}`);
      const { json } = await apiGet(fetchImpl, token, `/search/issues?q=${q}&per_page=${perPage}`, signal, timeoutMs);
      const items = json && typeof json === "object" && Array.isArray((json as any).items) ? (json as any).items : [];
      issues = items.map((item: any) => ({
        number: item.number,
        title: item.title,
        state: item.state,
        isPullRequest: Boolean(item.pull_request),
        user: item.user?.login ?? null,
        htmlUrl: item.html_url,
        createdAt: item.created_at,
        comments: item.comments,
      }));
    } catch {
      // If search endpoint fails or hits public rate limit, fall back to list_issues filtering
      try {
        const issuesRes = await listIssues(fetchImpl, token, { owner, repo, state: "all", perPage: 30 }, signal, timeoutMs);
        const lowerQ = query.toLowerCase();
        issues = issuesRes.issues
          .filter((i) => typeof i.title === "string" && i.title.toLowerCase().includes(lowerQ))
          .map((i) => ({
            number: typeof i.number === "number" ? i.number : Number(i.number) || 0,
            title: typeof i.title === "string" ? i.title : String(i.title || ""),
            state: typeof i.state === "string" ? i.state : "open",
            isPullRequest: false,
            user: typeof i.user === "string" ? i.user : (i.user ? String(i.user) : "anonymous"),
            htmlUrl: typeof i.htmlUrl === "string" ? i.htmlUrl : "",
            createdAt: typeof i.createdAt === "string" ? i.createdAt : new Date().toISOString(),
          }));
      } catch {
        issues = [];
      }
    }
  }

  // 2. Search Code/Files
  if (type === "files" || type === "all") {
    try {
      const q = encodeURIComponent(`${query} repo:${owner}/${repo}`);
      const { json } = await apiGet(fetchImpl, token, `/search/code?q=${q}&per_page=${perPage}`, signal, timeoutMs);
      const items = json && typeof json === "object" && Array.isArray((json as any).items) ? (json as any).items : [];
      files = items.map((item: any) => ({
        name: item.name,
        path: item.path,
        sha: item.sha,
        htmlUrl: item.html_url,
      }));
    } catch {
      // If code search fails (e.g. GitHub requires auth for code search API or rate-limited),
      // we inspect the repo tree or README/common files
      try {
        const lowerQ = query.toLowerCase();
        const treePath = `/repos/${owner}/${repo}/git/trees/HEAD?recursive=1`;
        const { json } = await apiGet(fetchImpl, token, treePath, signal, timeoutMs);
        const tree = json && typeof json === "object" && Array.isArray((json as any).tree) ? (json as any).tree : [];
        files = tree
          .filter((f: any) => f.type === "blob" && typeof f.path === "string" && f.path.toLowerCase().includes(lowerQ))
          .slice(0, perPage)
          .map((f: any) => ({
            name: f.path.split("/").pop() || f.path,
            path: f.path,
            sha: f.sha,
            htmlUrl: `https://github.com/${owner}/${repo}/blob/HEAD/${f.path}`,
          }));
      } catch {
        files = [];
      }
    }
  }

  return {
    owner,
    repo,
    query,
    type,
    count: issues.length + files.length,
    issueCount: issues.length,
    fileCount: files.length,
    issues,
    files,
    fetchedAt: new Date().toISOString(),
  };
}

export const githubAdapter = createGitHubAdapter();
