import { mkdtemp, rm, cp, writeFile, readFile, readdir, mkdir } from "node:fs/promises";
import { join, resolve, dirname } from "node:path";
import { tmpdir } from "node:os";
import { spawn } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import {
  getWorkspaceDir,
  listWorkspaceFiles,
  validateWorkspaceRelativePath,
  isBlockedFilename,
  validateWebsiteWorkspace,
  validateAppManifest,
  WorkspaceFileError,
} from "./files.js";
import { saveAgentEvent, redactSecrets } from "./store.js";
type JSZipType = typeof import("jszip");
async function loadJSZip(): Promise<JSZipType> {
  const mod = await import("jszip");
  // JSZip is CommonJS-shaped in some TS configurations and default-exported in others.
  return (("default" in mod ? mod.default : mod) as unknown) as JSZipType;
}

export type SandboxTaskType = "syntax_check" | "typecheck" | "test" | "build" | "install_deps";

export type SandboxExecutionResult = {
  status: "VERIFIED" | "FAIL" | "BLOCKED" | "NOT_VERIFIED";
  taskType: SandboxTaskType;
  command: string[];
  exitCode: number;
  durationMs: number;
  filesHash: string;
  stdout: string;
  stderr: string;
  networkIsolated: boolean;
  reason?: string;
  truncated: boolean;
};

export type SandboxPatchFile = { name: string; content: string };

export const MAX_OUTPUT_BYTES = 64 * 1024; // 64 KB max stdout/stderr
export const DEFAULT_TIMEOUT_MS = 10000; // 10 seconds timeout
export const MAX_REPAIR_CYCLES = 3; // Maximum 3 repair cycles per command

// Clean environment builder (strictly removes all secrets, keys, and tokens)
export function createStrippedEnv(extra: Record<string, string> = {}): NodeJS.ProcessEnv {
  const cleanEnv: NodeJS.ProcessEnv = {
    PATH: process.env.PATH || "/usr/local/bin:/usr/bin:/bin",
    NODE_ENV: "production",
    LANG: "en_US.UTF-8",
    ...extra,
  };

  // Explicitly remove any secrets or tokens that might exist
  for (const key of Object.keys(process.env)) {
    if (
      /(key|secret|token|auth|pass|cred|api_key|apphub|jwt|gemini|openai)/i.test(key)
    ) {
      delete cleanEnv[key];
    }
  }

  return cleanEnv;
}

// Compute aggregate SHA-256 hash of workspace files being tested
export async function computeWorkspaceFilesHash(): Promise<string> {
  const files = await listWorkspaceFiles();
  const hasher = createHash("sha256");
  for (const f of files) {
    hasher.update(`${f.name}:${f.content || ""}\n`);
  }
  return hasher.digest("hex");
}

// Test whether unshare -n (network namespace) works in the current environment
let cachedNetworkIsolationSupported: boolean | null = null;
export async function testNetworkIsolationCapability(): Promise<boolean> {
  if (cachedNetworkIsolationSupported !== null) return cachedNetworkIsolationSupported;
  try {
    const proc = spawn("unshare", ["-n", "true"], { stdio: "ignore" });
    const success = await new Promise<boolean>((res) => {
      proc.on("exit", (code) => res(code === 0));
      proc.on("error", () => res(false));
    });
    cachedNetworkIsolationSupported = success;
    return success;
  } catch {
    cachedNetworkIsolationSupported = false;
    return false;
  }
}

/**
 * Execute command inside an isolated temporary directory with stripped environment.
 */
async function runCommandInSandbox(
  cmd: string,
  args: string[],
  cwd: string,
  timeoutMs = DEFAULT_TIMEOUT_MS,
  enableNetworkIsolation = true
): Promise<{ exitCode: number; stdout: string; stderr: string; truncated: boolean; networkIsolated: boolean }> {
  const isNetIsoAvailable = enableNetworkIsolation ? await testNetworkIsolationCapability() : false;
  let finalCmd = cmd;
  let finalArgs = args;

  if (isNetIsoAvailable) {
    finalCmd = "unshare";
    finalArgs = ["-n", cmd, ...args];
  }

  const cleanEnv = createStrippedEnv({ HOME: cwd });

  return new Promise((resolvePromise) => {
    let stdoutBuffer = "";
    let stderrBuffer = "";
    let truncated = false;
    let timedOut = false;

    const child = spawn(finalCmd, finalArgs, {
      cwd,
      env: cleanEnv,
      stdio: ["ignore", "pipe", "pipe"],
    });

    const timer = setTimeout(() => {
      timedOut = true;
      try {
        child.kill("SIGKILL");
      } catch {
        // Ignore
      }
    }, timeoutMs);

    child.stdout?.on("data", (chunk: Buffer) => {
      if (stdoutBuffer.length + chunk.length > MAX_OUTPUT_BYTES) {
        stdoutBuffer += chunk.toString("utf8", 0, MAX_OUTPUT_BYTES - stdoutBuffer.length);
        truncated = true;
      } else {
        stdoutBuffer += chunk.toString("utf8");
      }
    });

    child.stderr?.on("data", (chunk: Buffer) => {
      if (stderrBuffer.length + chunk.length > MAX_OUTPUT_BYTES) {
        stderrBuffer += chunk.toString("utf8", 0, MAX_OUTPUT_BYTES - stderrBuffer.length);
        truncated = true;
      } else {
        stderrBuffer += chunk.toString("utf8");
      }
    });

    child.on("error", (err) => {
      clearTimeout(timer);
      resolvePromise({
        exitCode: 1,
        stdout: redactSecrets(stdoutBuffer),
        stderr: redactSecrets(stderrBuffer + `\nProcess error: ${err.message}`),
        truncated,
        networkIsolated: isNetIsoAvailable,
      });
    });

    child.on("close", (code) => {
      clearTimeout(timer);
      const exitCode = timedOut ? 124 : (code ?? 1);
      if (timedOut) {
        stderrBuffer += `\nCommand timed out after ${timeoutMs}ms.`;
      }
      resolvePromise({
        exitCode,
        stdout: redactSecrets(stdoutBuffer),
        stderr: redactSecrets(stderrBuffer),
        truncated,
        networkIsolated: isNetIsoAvailable,
      });
    });
  });
}

/**
 * Execute an allowlisted sandbox task.
 */
export async function executeSandboxTask(
  taskType: SandboxTaskType,
  targetPath?: string,
  timeoutMs = DEFAULT_TIMEOUT_MS,
  patchFiles: SandboxPatchFile[] = []
): Promise<SandboxExecutionResult> {
  const startTime = Date.now();
  if (!Array.isArray(patchFiles) || patchFiles.length > 5) {
    return {
      status: "BLOCKED",
      taskType,
      command: [String(taskType)],
      exitCode: 1,
      durationMs: 0,
      filesHash: await computeWorkspaceFilesHash(),
      stdout: "",
      stderr: "Sandbox patch must contain at most five files.",
      networkIsolated: true,
      reason: "Invalid patch overlay.",
      truncated: false,
    };
  }

  const patchNames = new Set<string>();
  for (const patch of patchFiles) {
    if (!patch || typeof patch.name !== "string" || typeof patch.content !== "string") {
      return {
        status: "BLOCKED",
        taskType,
        command: [String(taskType)],
        exitCode: 1,
        durationMs: 0,
        filesHash: await computeWorkspaceFilesHash(),
        stdout: "",
        stderr: "Sandbox patch entries require a filename and string content.",
        networkIsolated: true,
        reason: "Invalid patch overlay.",
        truncated: false,
      };
    }
    try {
      const cleanName = validateWorkspaceRelativePath(patch.name);
      if (cleanName !== patch.name || patchNames.has(cleanName) || isBlockedFilename(cleanName)) {
        throw new Error("Patch path is invalid, duplicated, or blocked.");
      }
      patchNames.add(cleanName);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      return {
        status: "BLOCKED",
        taskType,
        command: [String(taskType)],
        exitCode: 1,
        durationMs: 0,
        filesHash: await computeWorkspaceFilesHash(),
        stdout: "",
        stderr: redactSecrets(reason),
        networkIsolated: true,
        reason: "Invalid patch overlay path.",
        truncated: false,
      };
    }
  }
  if (patchFiles.length > 0 && taskType !== "test" && taskType !== "syntax_check") {
    return {
      status: "BLOCKED",
      taskType,
      command: [String(taskType)],
      exitCode: 1,
      durationMs: 0,
      filesHash: await computeWorkspaceFilesHash(),
      stdout: "",
      stderr: "Patch overlays are only supported for isolated test and syntax-check tasks.",
      networkIsolated: true,
      reason: "This task cannot verify overlay contents in isolation.",
      truncated: false,
    };
  }

  const workspaceFiles = await listWorkspaceFiles();
  const patchByName = new Map(patchFiles.map((patch) => [patch.name, patch.content]));
  const filesHash = createHash("sha256")
    .update(workspaceFiles
      .map((file) => [file.name, patchByName.get(file.name) ?? file.content ?? ""] as const)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([name, content]) => `${name}:${content}\n`)
      .join(""))
    .update([...patchByName.entries()]
      .filter(([name]) => !workspaceFiles.some((file) => file.name === name))
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([name, content]) => `${name}:${content}\n`)
      .join(""))
    .digest("hex");

  const ALLOWED_TASKS = ["syntax_check", "typecheck", "test", "build", "install_deps"];
  if (!ALLOWED_TASKS.includes(taskType)) {
    return {
      status: "BLOCKED",
      taskType,
      command: [String(taskType)],
      exitCode: 1,
      durationMs: 0,
      filesHash,
      stdout: "",
      stderr: `Task "${taskType}" is not allowlisted. Permitted tasks: ${ALLOWED_TASKS.join(", ")}`,
      networkIsolated: true,
      reason: `Task type "${taskType}" outside template allowlist.`,
      truncated: false,
    };
  }

  // 1. Dependency installation: BLOCKED by default for security
  if (taskType === "install_deps") {
    const result: SandboxExecutionResult = {
      status: "BLOCKED",
      taskType,
      command: ["npm", "install"],
      exitCode: 1,
      durationMs: 0,
      filesHash,
      stdout: "",
      stderr: "Dependency installation is BLOCKED by default. External dependencies pose high supply-chain security risks.",
      networkIsolated: true,
      reason: "Dependency installation requires explicit high-risk privilege authorization with fixed pinned packages and --ignore-scripts.",
      truncated: false,
    };

    await saveAgentEvent({
      id: randomUUID(),
      type: "SANDBOX_TASK_BLOCKED",
      at: new Date().toISOString(),
      data: { hash: filesHash, actor: "system", taskType, reason: result.reason },
    });

    return result;
  }

  // 2. Build task for static web / app projects: Server-side bundle & manifest validation
  if (taskType === "build") {
    const validation = await validateWebsiteWorkspace();
    const manifestCheck = await validateAppManifest();
    const durationMs = Date.now() - startTime;

    // An app project requires a valid app.json manifest.
    // A static website project requires valid HTML entry & asset references (app.json is optional).
    const isAppProject = manifestCheck.hasManifest;
    const isPassing = isAppProject
      ? (validation.valid && manifestCheck.valid)
      : (validation.valid && validation.hasHtml);

    const stdoutLines = [
      `[Zyntheor Builder] Validating project workspace structure...`,
      `Project architecture: ${isAppProject ? "Single Page Application (SPA / App Builder)" : "Static Website Project (HTML/CSS/JS)"}`,
      `Files found (${validation.files.length}): ${validation.files.join(", ")}`,
      `HTML entry: ${validation.hasHtml ? "Valid" : "Missing"}`,
      `Manifest (app.json): ${isAppProject ? (manifestCheck.valid ? "Valid" : "Issues detected") : "Optional (Static Web Project - Not Required)"}`,
    ];
    if (isAppProject && manifestCheck.errors.length > 0) {
      stdoutLines.push(`Manifest errors: ${manifestCheck.errors.join("; ")}`);
    }
    if (validation.structureErrors.length > 0) {
      stdoutLines.push(`Structure errors: ${validation.structureErrors.join("; ")}`);
    }
    if (validation.missingAssetReferences.length > 0) {
      stdoutLines.push(`Missing references: ${validation.missingAssetReferences.join("; ")}`);
    }

    const result: SandboxExecutionResult = {
      status: isPassing ? "VERIFIED" : "FAIL",
      taskType,
      command: ["builder", "validate-bundle"],
      exitCode: isPassing ? 0 : 1,
      durationMs,
      filesHash,
      stdout: stdoutLines.join("\n"),
      stderr: isAppProject ? manifestCheck.errors.join("\n") : validation.structureErrors.join("\n"),
      networkIsolated: true,
      truncated: false,
    };

    await saveAgentEvent({
      id: randomUUID(),
      type: "SANDBOX_TASK_EXECUTED",
      at: new Date().toISOString(),
      data: {
        hash: filesHash,
        actor: "system",
        taskType,
        status: result.status,
        exitCode: result.exitCode,
        durationMs,
      },
    });

    return result;
  }

  // 3. For syntax_check, typecheck, test:
  // Validate targetPath if provided to strictly prevent path traversal
  if (targetPath && targetPath !== ".") {
    try {
      validateWorkspaceRelativePath(targetPath);
    } catch (e: any) {
      return {
        status: "BLOCKED",
        taskType,
        command: [taskType, targetPath],
        exitCode: 1,
        durationMs: Date.now() - startTime,
        filesHash,
        stdout: "",
        stderr: `Path traversal violation: target path "${targetPath}" is outside project workspace.`,
        networkIsolated: true,
        reason: "Path escapes workspace boundary.",
        truncated: false,
      };
    }
  }

  // Create isolated temporary directory
  const tempSandboxDir = await mkdtemp(join(tmpdir(), "zyntheor-sandbox-"));

  try {
    // Copy approved workspace files into temp sandbox directory
    for (const f of workspaceFiles) {
      if (isBlockedFilename(f.name)) continue; // Never copy secrets or blocked files
      const destPath = join(tempSandboxDir, f.name);
      await mkdir(dirname(destPath), { recursive: true });
      await writeFile(destPath, f.content || "", "utf8");
    }
    for (const patch of patchFiles) {
      const destPath = join(tempSandboxDir, patch.name);
      await mkdir(dirname(destPath), { recursive: true });
      await writeFile(destPath, patch.content, "utf8");
    }

    if (taskType === "syntax_check") {
      const jsFiles = workspaceFiles.filter((f) => /\.(m?js|cjs)$/i.test(f.name));
      const filesToCheck = (targetPath && targetPath !== ".") ? [targetPath] : jsFiles.map((f) => f.name);

      if (filesToCheck.length === 0) {
        const durationMs = Date.now() - startTime;
        return {
          status: "VERIFIED",
          taskType,
          command: ["node", "--check"],
          exitCode: 0,
          durationMs,
          filesHash,
          stdout: `[Zyntheor Syntax Check] No JavaScript files found in workspace to check. Workspace contains ${workspaceFiles.length} file(s).`,
          stderr: "",
          networkIsolated: true,
          truncated: false,
        };
      }

      let allPass = true;
      let finalExitCode = 0;
      const fileReport: string[] = [];
      let combinedStderr = "";
      let netIso = false;
      let isTrunc = false;

      for (const file of filesToCheck) {
        const { exitCode, stdout: _out, stderr, truncated, networkIsolated } = await runCommandInSandbox(
          "node",
          ["--check", join(tempSandboxDir, file)],
          tempSandboxDir,
          timeoutMs,
          true
        );
        netIso = networkIsolated;
        if (truncated) isTrunc = true;
        if (exitCode !== 0) {
          allPass = false;
          finalExitCode = exitCode;
          fileReport.push(`  ✗ ${file}: Syntax error (exit code ${exitCode})`);
          combinedStderr += `Syntax check failed for ${file}:\n${stderr}\n`;
        } else {
          fileReport.push(`  ✓ ${file}: Syntax valid`);
        }
      }

      const durationMs = Date.now() - startTime;
      const status = allPass ? "VERIFIED" : "FAIL";
      const combinedStdout = [
        `[Zyntheor Syntax Check] Verified ${filesToCheck.length} JavaScript file(s): ${filesToCheck.join(", ")}`,
        ...fileReport,
        allPass
          ? `Summary: All ${filesToCheck.length} file(s) checked. Syntax valid with 0 errors across all checked files.`
          : `Summary: Syntax check failed with ${finalExitCode !== 0 ? `exit code ${finalExitCode}` : "errors"}.`,
      ].join("\n");

      const result: SandboxExecutionResult = {
        status,
        taskType,
        command: ["node", "--check", ...filesToCheck],
        exitCode: finalExitCode,
        durationMs,
        filesHash,
        stdout: combinedStdout,
        stderr: combinedStderr,
        networkIsolated: netIso,
        truncated: isTrunc,
      };

      await saveAgentEvent({
        id: randomUUID(),
        type: "SANDBOX_TASK_EXECUTED",
        at: new Date().toISOString(),
        data: {
          hash: filesHash,
          actor: "system",
          taskType,
          command: result.command.join(" "),
          status,
          exitCode: result.exitCode,
          durationMs,
          networkIsolated: result.networkIsolated,
        },
      });

      return result;
    }

    let cmd = "node";
    let args: string[] = [];

    if (taskType === "typecheck") {
      // Create minimal safe tsconfig in temp dir
      await writeFile(
        join(tempSandboxDir, "tsconfig.json"),
        JSON.stringify({
          compilerOptions: {
            target: "ES2022",
            module: "ESNext",
            moduleResolution: "bundler",
            noEmit: true,
            skipLibCheck: true,
          },
          include: ["**/*.ts", "**/*.js"],
        })
      );
      cmd = "npx";
      args = ["tsc", "--noEmit", "--project", tempSandboxDir];
    } else if (taskType === "test") {
      cmd = "node";
      args = ["--test"];
    }

    const { exitCode, stdout, stderr, truncated, networkIsolated } = await runCommandInSandbox(
      cmd,
      args,
      tempSandboxDir,
      timeoutMs,
      true
    );

    const durationMs = Date.now() - startTime;
    const status = exitCode === 0 ? "VERIFIED" : "FAIL";

    const result: SandboxExecutionResult = {
      status,
      taskType,
      command: [cmd, ...args],
      exitCode,
      durationMs,
      filesHash,
      stdout,
      stderr,
      networkIsolated,
      truncated,
    };

    // Store in existing tamper-resistant audit ledger
    await saveAgentEvent({
      id: randomUUID(),
      type: "SANDBOX_TASK_EXECUTED",
      at: new Date().toISOString(),
      data: {
        hash: filesHash,
        actor: "system",
        taskType,
        command: result.command.join(" "),
        status,
        exitCode,
        durationMs,
        networkIsolated,
      },
    });

    return result;
  } finally {
    // Clean up temporary sandbox directory completely
    await rm(tempSandboxDir, { recursive: true, force: true }).catch(() => {});
  }
}

/**
 * Generate a ZIP archive containing ONLY approved workspace files.
 * Strictly excludes any secrets, .env, .pem, or files outside workspace.
 */
export async function createApprovedWorkspaceZip(): Promise<Buffer> {
  const files = await listWorkspaceFiles();
  const JSZip = await loadJSZip();
  const zip = new JSZip();

  for (const file of files) {
    if (isBlockedFilename(file.name)) continue;
    zip.file(file.name, file.content || "");
  }

  return zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
}

// Memory tracker for repair cycles per request
const repairCycleTracker = new Map<string, number>();

export function getRepairCycleCount(sessionId: string): number {
  return repairCycleTracker.get(sessionId) || 0;
}

export function incrementRepairCycle(sessionId: string): { count: number; allowed: boolean } {
  const current = getRepairCycleCount(sessionId);
  const next = current + 1;
  repairCycleTracker.set(sessionId, next);
  return { count: next, allowed: next <= MAX_REPAIR_CYCLES };
}

export function resetRepairCycle(sessionId: string): void {
  repairCycleTracker.delete(sessionId);
}
