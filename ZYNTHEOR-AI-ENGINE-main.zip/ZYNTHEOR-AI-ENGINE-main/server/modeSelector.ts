/**
 * Engine mode selection: decides FAST vs DEEP reasoning depth and which connector kinds a task may need.
 * Deterministic (no model call), so it is testable and its reasons can be shown to the user.
 * Reuses classifyTaskRequest() for task type/risk instead of re-implementing intent detection.
 */
import { classifyTaskRequest, type SupportedTaskType } from "./reasoning.js";
import type { ConnectorHub, ConnectorStatusView } from "./connectorHub.js";
import type { CustomEngineConfig } from "./customConfig.js";

export type EngineDepth = "FAST" | "DEEP";

export interface ModeDecision {
  depth: EngineDepth;
  taskType: SupportedTaskType;
  supported: boolean;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  requiresApproval: boolean;
  connectorHints: string[];
  reasons: string[];
  /** true when the user's preferred depth was not honoured (FAST asked, but risk/approval forced DEEP). */
  depthOverridden?: boolean;
}

const MULTI_STEP = /(หลายขั้นตอน|ทีละขั้น|step[- ]by[- ]step|ก่อน.{0,40}แล้ว|แล้วจึง|วิเคราะห์.{0,30}เปรียบเทียบ|compare|trade-?off|architecture|สถาปัตยกรรม)/i;
const CONNECTOR_HINTS: Array<[string, RegExp]> = [
  ["github", /(github|git\s|pull request|\bpr\b|repo(sitory)?|คอมมิต|พุช)/i],
  ["web_research", /(ค้นเว็บ|ค้นหาข้อมูล|research|search the web|อ้างอิงแหล่ง|ข่าวล่าสุด)/i],
  ["file_store", /(drive|dropbox|s3|ที่เก็บไฟล์|cloud storage)/i],
  ["external_api", /(\bapi\b|webhook|endpoint|เรียก api)/i],
];

export function selectEngineMode(
  prompt: string,
  requestedMode?: string,
  preferredDepth?: EngineDepth,
  customConfig?: CustomEngineConfig
): ModeDecision {
  const text = (prompt ?? "").trim();
  const cls = classifyTaskRequest(text, requestedMode === "custom" ? undefined : requestedMode);
  const reasons: string[] = [];
  let connectorHints = CONNECTOR_HINTS.filter(([, re]) => re.test(text)).map(([k]) => k);

  const isCustom = requestedMode === "custom" || customConfig !== undefined;
  let effectivePreferredDepth = preferredDepth;

  if (isCustom && customConfig) {
    reasons.push("Custom mode active");
    if (customConfig.depth && customConfig.depth !== "AUTO" && !preferredDepth) {
      effectivePreferredDepth = customConfig.depth;
    }
    if (customConfig.requiresApproval) {
      cls.requiresApproval = true;
      reasons.push("Custom config: mandatory approval enforced");
    }
    if (customConfig.allowFileModifications === false) {
      if (cls.taskType === "code_change" || cls.taskType === "file_modification") {
        cls.supported = false;
        reasons.push("Custom config: file modifications disabled (read-only enforced)");
      }
    }
    if (customConfig.allowedConnectors) {
      const allowed = new Set(customConfig.allowedConnectors);
      const filtered: string[] = [];
      for (const hint of connectorHints) {
        if (allowed.has(hint)) {
          filtered.push(hint);
        } else {
          reasons.push(`Custom config: connector '${hint}' blocked by allowedConnectors policy`);
          if (customConfig.strictness === "strict") {
            cls.supported = false;
            reasons.push(`Custom config strictness: required connector '${hint}' is blocked`);
          }
        }
      }
      connectorHints = filtered;
    }
  }

  const deepByTask: SupportedTaskType[] = ["code_change", "file_modification", "build", "test", "syntax_check", "plan", "inspect"];
  const deepByMode = requestedMode === "plan" || requestedMode === "code" || requestedMode === "review";

  let depth: EngineDepth = "FAST";
  if (!cls.supported) { depth = "DEEP"; reasons.push("unsupported/high-risk request needs careful handling"); }
  if (cls.riskLevel !== "LOW") { depth = "DEEP"; reasons.push(`risk ${cls.riskLevel}`); }
  if (cls.requiresApproval) { depth = "DEEP"; reasons.push("requires approval"); }
  if (deepByTask.includes(cls.taskType)) { depth = "DEEP"; reasons.push(`task type ${cls.taskType}`); }
  if (deepByMode) { depth = "DEEP"; reasons.push(`requested mode ${requestedMode}`); }
  if (text.length > 600) { depth = "DEEP"; reasons.push("long request"); }
  if (MULTI_STEP.test(text)) { depth = "DEEP"; reasons.push("multi-step / analytical wording"); }
  if (connectorHints.length > 0 && depth === "FAST") { depth = "DEEP"; reasons.push("external connector involved"); }
  let depthOverridden = false;
  if (effectivePreferredDepth === "DEEP" && depth === "FAST") { depth = "DEEP"; reasons.push("DEEP requested by user"); }
  if (effectivePreferredDepth === "FAST" && depth === "DEEP") { depthOverridden = true; reasons.push("FAST requested but kept DEEP: risk, approval, task type or wording requires it"); }
  if (depth === "FAST") reasons.push("short, low-risk, read-only request");

  return {
    depth, taskType: cls.taskType, supported: cls.supported, riskLevel: cls.riskLevel,
    requiresApproval: cls.requiresApproval, connectorHints, reasons: [...new Set(reasons)], depthOverridden,
  };
}

/** Maps hints to real connector status. A hint with no matching connector is reported NOT_INSTALLED. */
export async function resolveConnectorHints(hub: ConnectorHub, hints: string[]): Promise<Array<{ hint: string; availability: ConnectorStatusView["availability"] }>> {
  const list = await hub.list();
  return hints.map((hint) => ({ hint, availability: list.find((c) => c.id === hint)?.availability ?? "NOT_INSTALLED" }));
}
