/**
 * Autonomous Task Execution & Evidence Ledger Engine
 *
 * Implements a strict, audited state machine for multi-step AI tasks:
 * - State Machine: PLANNED -> WAITING_APPROVAL -> RUNNING -> VERIFYING -> COMPLETED / FAILED / BLOCKED
 * - Evidence Ledger: Records actual command, exit code, output summary, changed files, timestamps, verification status
 * - Recovery Loop: Bounded retries (MAX_TASK_RETRIES = 3), safety check for idempotency, avoids infinite loops
 * - Approval Enforcement: Any high-risk or file-changing task requires cryptographic approval (SHA-256 hash match)
 * - Evidence-Based Verification: Only transitions to COMPLETED when empirical evidence satisfies criteria
 * - Secret Redaction: Ensures zero secret leakage in ledger, summaries, and speech notifications
 */

import { createHash, randomUUID } from "node:crypto";
import { redactSecrets, saveAgentEvent, type AgentEvent } from "./store.js";
import { executeSandboxTask, type SandboxTaskType, type SandboxExecutionResult } from "./sandboxRunner.js";
import { listWorkspaceFiles } from "./files.js";

export type TaskState =
  | "PLANNED"
  | "WAITING_APPROVAL"
  | "RUNNING"
  | "VERIFYING"
  | "COMPLETED"
  | "FAILED"
  | "BLOCKED";

export const VALID_TRANSITIONS: Record<TaskState, TaskState[]> = {
  PLANNED: ["RUNNING", "WAITING_APPROVAL", "BLOCKED"],
  WAITING_APPROVAL: ["RUNNING", "BLOCKED", "FAILED"],
  RUNNING: ["VERIFYING", "WAITING_APPROVAL", "FAILED", "BLOCKED"],
  VERIFYING: ["COMPLETED", "FAILED", "RUNNING"],
  FAILED: ["RUNNING"],
  COMPLETED: [],
  BLOCKED: [],
};

export const MAX_TASK_RETRIES = 3;

export interface TaskStep {
  id: string;
  title: string;
  tool: string;
  input?: Record<string, unknown>;
  requiresApproval: boolean;
  status: "PENDING" | "RUNNING" | "VERIFIED" | "FAILED" | "BLOCKED" | "SKIPPED";
  exitCode?: number;
  outputSummary?: string;
  error?: string;
  verificationEvidence?: string;
}

export interface EvidenceLedgerEntry {
  id: string;
  taskId: string;
  stepId: string;
  taskType: string;
  command: string[];
  exitCode: number;
  outputSummary: string; // Strictly redacted
  changedFiles: string[];
  timestamp: string;
  durationMs: number;
  verificationStatus: "VERIFIED" | "FAILED" | "UNVERIFIED";
  verificationEvidence: string;
}

export interface TaskApproval {
  id: string;
  taskHash: string;
  approvedAt: string;
  usedAt?: string;
  expiresAt?: string;
}

export interface AutonomousTask {
  id: string;
  goal: string;
  state: TaskState;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  steps: TaskStep[];
  currentStepIndex: number;
  retryCount: number;
  maxRetries: number;
  hash: string;
  approval?: TaskApproval;
  evidence: EvidenceLedgerEntry[];
  createdAt: string;
  updatedAt: string;
  finishedAt?: string;
  voiceNotification?: {
    spokenTextTh: string;
    status: TaskState;
    timestamp: string;
  };
  honestReport?: HonestTaskReport;
}

export interface HonestTaskReport {
  goal: string;
  finalStatus: TaskState;
  actionsPerformed: Array<{
    stepId: string;
    tool: string;
    command: string[];
    exitCode?: number;
    verificationStatus: "VERIFIED" | "FAILED" | "UNVERIFIED";
    evidence: string;
  }>;
  verifiedEvidence: string[];
  actionsNotPerformed: Array<{
    stepId: string;
    tool: string;
    reason: string;
  }>;
  blockersOrMissingPermissions: string[];
  isPartial: boolean;
  summary: string;
}

export interface RecoveryPlan {
  allowed: boolean;
  reason: string;
  retryCount: number;
  maxRetries: number;
  suggestedAction?: string;
}

// Global in-memory task registry
const taskStore = new Map<string, AutonomousTask>();
const globalEvidenceLedger: EvidenceLedgerEntry[] = [];

/**
 * Compute SHA-256 hash for a task definition ensuring cryptographic integrity
 */
export function computeTaskHash(goal: string, steps: TaskStep[], riskLevel: string): string {
  const payload = JSON.stringify({
    goal: goal.trim(),
    riskLevel,
    steps: steps.map((s) => ({
      id: s.id,
      title: s.title,
      tool: s.tool,
      input: s.input ?? {},
      requiresApproval: s.requiresApproval,
    })),
  });
  return createHash("sha256").update(payload).digest("hex");
}

/**
 * Validate and perform a state transition on an AutonomousTask
 */
export function transitionTaskState(
  task: AutonomousTask,
  nextState: TaskState,
  reason?: string
): AutonomousTask {
  // Prevent duplicate terminal transitions
  if (task.state === nextState && ["COMPLETED", "FAILED", "BLOCKED"].includes(task.state)) {
    throw new Error(
      `Duplicate terminal transition forbidden: Task '${task.id}' is already in terminal state '${task.state}'.`
    );
  }

  // Prevent duplicate concurrent execution
  if (task.state === "RUNNING" && nextState === "RUNNING") {
    throw new Error(
      `Duplicate execution blocked: Task '${task.id}' is already RUNNING.`
    );
  }

  const allowed = VALID_TRANSITIONS[task.state];
  if (!allowed || !allowed.includes(nextState)) {
    throw new Error(
      `Invalid state transition: Cannot change task state from '${task.state}' to '${nextState}'. Allowed transitions: [${(allowed || []).join(", ")}]`
    );
  }

  // Verification Gate: Cannot transition to COMPLETED without empirical evidence
  if (nextState === "COMPLETED") {
    if (task.evidence.length === 0) {
      throw new Error(
        "Verification Gate: Cannot transition task to COMPLETED without empirical verification evidence in the Evidence Ledger."
      );
    }
    const hasUnverified = task.evidence.some((e) => e.verificationStatus !== "VERIFIED");
    if (hasUnverified) {
      throw new Error(
        "Verification Gate: Cannot transition task to COMPLETED while evidence ledger contains unverified or failed items."
      );
    }
  }

  // Approval Gate: High-risk or unapproved tasks cannot transition to RUNNING without valid approval
  if (nextState === "RUNNING") {
    const currentStep = task.steps[task.currentStepIndex];
    if (currentStep && currentStep.requiresApproval) {
      if (!task.approval || !task.approval.id || task.approval.taskHash !== task.hash) {
        throw new Error(
          "Approval Gate: High-risk task requires cryptographic approval matching task hash before entering RUNNING state."
        );
      }
      if (task.approval.usedAt) {
        throw new Error(
          "Approval Gate: Approval has already been used (replayed approval rejected)."
        );
      }
      if (task.approval.expiresAt && Date.now() > Date.parse(task.approval.expiresAt)) {
        throw new Error(
          `Approval Gate: Approval expired at ${task.approval.expiresAt}.`
        );
      }
      task.approval.usedAt = new Date().toISOString();
    }
  }

  const previousState = task.state;
  task.state = nextState;
  task.updatedAt = new Date().toISOString();

  // Voice notification generator for significant events
  let voiceText = "";
  if (nextState === "WAITING_APPROVAL") {
    voiceText = "มีงานที่รอการอนุมัติแบบยืนยันความปลอดภัยจากคุณก่อนเริ่มดำเนินการครับ";
  } else if (nextState === "BLOCKED") {
    voiceText = "การทำงานถูกระงับเนื่องจากนโยบายความปลอดภัยครับ";
  } else if (nextState === "COMPLETED") {
    voiceText = `การทำงานเสร็จสมบูรณ์ ตรวจสอบหลักฐานจริงผ่านแล้ว ${task.evidence.length} รายการครับ`;
  } else if (nextState === "FAILED") {
    voiceText = "การทำงานพบข้อผิดพลาด กรุณาตรวจสอบบันทึกหลักฐานครับ";
  }

  if (voiceText) {
    task.voiceNotification = {
      spokenTextTh: redactSecrets(voiceText),
      status: nextState,
      timestamp: task.updatedAt,
    };
  }

  // Persist audit event
  saveAgentEvent({
    id: randomUUID(),
    type: "task_state_transition",
    at: task.updatedAt,
    runId: task.id,
    stepId: task.steps[task.currentStepIndex]?.id,
    status: nextState === "FAILED" ? "FAILED" : nextState === "BLOCKED" ? "BLOCKED" : "RECORDED",
    data: {
      taskId: task.id,
      runId: task.id,
      stepId: task.steps[task.currentStepIndex]?.id,
      previousState,
      nextState,
      reason: reason ? redactSecrets(reason) : undefined,
      evidenceCount: task.evidence.length,
      timestamp: task.updatedAt,
    },
  }).catch((error) => {
    console.error("Failed to persist task state transition event.", error);
  });

  return task;
}

/**
 * Create a new Autonomous Task in PLANNED state
 */
export function createAutonomousTask(params: {
  goal: string;
  steps: Array<{
    id?: string;
    title: string;
    tool: string;
    input?: Record<string, unknown>;
    requiresApproval?: boolean;
  }>;
  riskLevel?: "LOW" | "MEDIUM" | "HIGH";
}): AutonomousTask {
  const id = `task_${Date.now()}_${randomUUID().slice(0, 8)}`;
  const riskLevel = params.riskLevel || "LOW";

  const SAFE_ALLOWLIST = new Set(["get_time", "syntax_check", "typecheck", "test", "build", "inspect"]);

  const steps: TaskStep[] = params.steps.map((s, idx) => {
    const isUnsafeTool = !SAFE_ALLOWLIST.has(s.tool);
    const requiresApproval = s.requiresApproval === true || isUnsafeTool || riskLevel === "HIGH";
    return {
      id: s.id || `step_${idx + 1}`,
      title: s.title,
      tool: s.tool,
      input: s.input,
      requiresApproval,
      status: "PENDING",
    };
  });

  const hash = computeTaskHash(params.goal, steps, riskLevel);

  const task: AutonomousTask = {
    id,
    goal: params.goal,
    state: "PLANNED",
    riskLevel,
    steps,
    currentStepIndex: 0,
    retryCount: 0,
    maxRetries: MAX_TASK_RETRIES,
    hash,
    evidence: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  taskStore.set(id, task);

  saveAgentEvent({
    id: randomUUID(),
    type: "task_planned",
    at: task.createdAt,
    data: {
      taskId: id,
      goal: redactSecrets(params.goal),
      hash,
      stepCount: steps.length,
      riskLevel,
    },
  }).catch((error) => {
    console.error("Failed to persist task planning event.", error);
  });

  return task;
}

/**
 * Approve a task requiring approval by matching task hash
 */
export function approveTask(
  taskId: string,
  expectedHash: string,
  options?: { expiresAt?: string; ttlMs?: number }
): AutonomousTask {
  const task = taskStore.get(taskId);
  if (!task) {
    throw new Error(`Task '${taskId}' not found.`);
  }

  if (task.hash !== expectedHash) {
    throw new Error(
      `Task approval failed: Hash mismatch. Expected '${expectedHash}', but task has '${task.hash}'.`
    );
  }

  const approvedAt = new Date().toISOString();
  const expiresAt = options?.expiresAt || (options?.ttlMs ? new Date(Date.now() + options.ttlMs).toISOString() : undefined);

  task.approval = {
    id: `appr_${Date.now()}_${randomUUID().slice(0, 8)}`,
    taskHash: task.hash,
    approvedAt,
    expiresAt,
  };

  saveAgentEvent({
    id: randomUUID(),
    type: "task_approved",
    at: task.approval.approvedAt,
    data: {
      taskId: task.id,
      approvalId: task.approval.id,
      hash: task.hash,
    },
  }).catch((error) => {
    console.error("Failed to persist task approval event.", error);
  });

  return task;
}

/**
 * Evaluate if a failed task step is safe for recovery loop retry
 */
export function evaluateRecovery(
  task: AutonomousTask,
  failedStep: TaskStep
): RecoveryPlan {
  if (task.retryCount >= task.maxRetries) {
    return {
      allowed: false,
      reason: `จำนวนการลองซ้ำเกินขีดจำกัดสูงสุด (${task.maxRetries} รอบ) เพื่อป้องกันการวนลูปไม่สิ้นสุด`,
      retryCount: task.retryCount,
      maxRetries: task.maxRetries,
    };
  }

  const SAFE_RETRY_TOOLS = new Set(["get_time", "syntax_check", "typecheck", "test", "build", "inspect"]);
  if (!SAFE_RETRY_TOOLS.has(failedStep.tool)) {
    return {
      allowed: false,
      reason: `เครื่องมือ '${failedStep.tool}' ไม่ใช่การดำเนินการแบบ Idempotent การลองซ้ำโดยอัตโนมัติอาจทำให้ระบบเสียหายได้`,
      retryCount: task.retryCount,
      maxRetries: task.maxRetries,
    };
  }

  return {
    allowed: true,
    reason: `คำสั่ง '${failedStep.tool}' ปลอดภัยสำหรับการลองซ้ำ (รอบที่ ${task.retryCount + 1}/${task.maxRetries})`,
    retryCount: task.retryCount + 1,
    maxRetries: task.maxRetries,
    suggestedAction: "วิเคราะห์สาเหตุข้อผิดพลาดและรันการตรวจสอบซ้ำใน Sandbox",
  };
}

export function buildTaskHonestReport(task: AutonomousTask): HonestTaskReport {
  const executedSteps = task.steps.filter((s) => s.status === "VERIFIED" || s.status === "FAILED");
  const unexecutedSteps = task.steps.filter((s) => s.status === "PENDING" || s.status === "BLOCKED" || s.status === "SKIPPED");
  const isPartial = executedSteps.length > 0 && unexecutedSteps.length > 0;

  return {
    goal: task.goal,
    finalStatus: task.state,
    actionsPerformed: task.evidence.map((e) => ({
      stepId: e.stepId,
      tool: e.taskType,
      command: e.command,
      exitCode: e.exitCode,
      verificationStatus: e.verificationStatus,
      evidence: e.verificationEvidence,
    })),
    verifiedEvidence: task.evidence
      .filter((e) => e.verificationStatus === "VERIFIED")
      .map((e) => e.verificationEvidence),
    actionsNotPerformed: unexecutedSteps.map((s) => ({
      stepId: s.id,
      tool: s.tool,
      reason: s.status === "BLOCKED" ? "Step blocked by policy or unallowlisted tool" : "Step not reached due to prior failure or prerequisite",
    })),
    blockersOrMissingPermissions: task.steps
      .filter((s) => s.status === "BLOCKED")
      .map((s) => `Step "${s.id}" (${s.tool}) blocked`),
    isPartial,
    summary: `Autonomous task ${task.state}. Executed ${executedSteps.length}/${task.steps.length} steps.${isPartial ? " (Partial execution)" : ""}`
  };
}

const activeTaskExecutions = new Set<string>();

/**
 * Execute a task step-by-step through the Task State Machine with Evidence Ledger
 */
export async function executeAutonomousTask(taskId: string): Promise<AutonomousTask> {
  const task = taskStore.get(taskId);
  if (!task) {
    throw new Error(`Task '${taskId}' not found.`);
  }

  if (activeTaskExecutions.has(taskId) || task.state === "RUNNING") {
    throw new Error(`Duplicate execution blocked: Task '${taskId}' is already running concurrently.`);
  }

  if (["COMPLETED", "FAILED", "BLOCKED"].includes(task.state)) {
    throw new Error(`Task '${taskId}' is already in terminal state '${task.state}'. Duplicate execution is forbidden.`);
  }

  activeTaskExecutions.add(taskId);

  try {
    // Check initial state
    const firstStep = task.steps[task.currentStepIndex];
    if (firstStep && firstStep.requiresApproval && !task.approval) {
      transitionTaskState(task, "WAITING_APPROVAL", "Step requires approval before execution");
      task.honestReport = buildTaskHonestReport(task);
      return task;
    }

    // Transition from PLANNED or WAITING_APPROVAL to RUNNING
    transitionTaskState(task, "RUNNING", "Beginning task execution");

    while (task.currentStepIndex < task.steps.length) {
      const step = task.steps[task.currentStepIndex];

      // Check approval requirement for this step
      if (step.requiresApproval && (!task.approval || task.approval.taskHash !== task.hash)) {
        transitionTaskState(task, "WAITING_APPROVAL", `Step '${step.id}' requires approval`);
        task.honestReport = buildTaskHonestReport(task);
        return task;
      }

      step.status = "RUNNING";
      const startTime = Date.now();

      try {
        let exitCode = 0;
        let stdout = "";
        let stderr = "";
        let command: string[] = [step.tool];
        let verificationStatus: EvidenceLedgerEntry["verificationStatus"] = "UNVERIFIED";
        let verificationEvidence = "";

        if (
          step.tool === "syntax_check" ||
          step.tool === "typecheck" ||
          step.tool === "test" ||
          step.tool === "build"
        ) {
          const sandboxRes: SandboxExecutionResult = await executeSandboxTask(step.tool as SandboxTaskType);
          exitCode = sandboxRes.exitCode;
          stdout = sandboxRes.stdout;
          stderr = sandboxRes.stderr;
          command = sandboxRes.command;
          verificationStatus = sandboxRes.status === "VERIFIED" ? "VERIFIED" : "FAILED";
          verificationEvidence = `Sandbox ${step.tool} returned exit code ${exitCode}`;
        } else if (step.tool === "get_time") {
          exitCode = 0;
          const now = new Date().toISOString();
          stdout = JSON.stringify({ observedAt: now, isoTimestamp: now });
          verificationStatus = "VERIFIED";
          verificationEvidence = `Timestamp observed and verified: ${now}`;
        } else if (step.tool === "inspect") {
          const wsFiles = await listWorkspaceFiles();
          exitCode = 0;
          stdout = JSON.stringify(wsFiles.map((f) => ({ name: f.name, size: f.size, lineCount: f.lineCount })));
          command = ["inspect", "workspace"];
          verificationStatus = "VERIFIED";
          verificationEvidence = `Workspace inspected: ${wsFiles.length} files found`;
        } else {
          // Unallowlisted tool executed without authorization
          step.status = "BLOCKED";
          transitionTaskState(task, "BLOCKED", `Unallowlisted tool execution attempt: ${step.tool}`);
          task.honestReport = buildTaskHonestReport(task);
          return task;
        }

        const durationMs = Date.now() - startTime;
        const outputSummary = redactSecrets((stdout || stderr || "Execution completed").slice(0, 300).trim());

        // Record Evidence Ledger Entry
        const entry: EvidenceLedgerEntry = {
          id: `ev_${Date.now()}_${randomUUID().slice(0, 6)}`,
          taskId: task.id,
          stepId: step.id,
          taskType: step.tool,
          command,
          exitCode,
          outputSummary,
          changedFiles: [],
          timestamp: new Date().toISOString(),
          durationMs,
          verificationStatus,
          verificationEvidence,
        };

        task.evidence.push(entry);
        globalEvidenceLedger.push(entry);

        saveAgentEvent({
          id: randomUUID(),
          type: "evidence_recorded",
          at: new Date().toISOString(),
          runId: task.id,
          stepId: step.id,
          status: entry.verificationStatus === "VERIFIED" ? "SUCCESS" : "FAILED",
          data: {
            taskId: task.id,
            evidenceId: entry.id,
            taskType: entry.taskType,
            exitCode: entry.exitCode,
            verificationStatus: entry.verificationStatus,
            durationMs: entry.durationMs,
          },
        }).catch(() => {});

        if (exitCode !== 0 || verificationStatus === "FAILED") {
          step.status = "FAILED";
          step.exitCode = exitCode;
          step.error = stderr || "Step failed";

          // Persist failure event in audit ledger before invoking recovery
          await saveAgentEvent({
            id: randomUUID(),
            type: "task_step_failed",
            at: new Date().toISOString(),
            runId: task.id,
            stepId: step.id,
            status: "FAILED",
            data: {
              taskId: task.id,
              stepId: step.id,
              tool: step.tool,
              exitCode,
              retryCount: task.retryCount,
              maxRetries: task.maxRetries,
              error: redactSecrets(step.error),
            },
          }).catch(() => {});

          // Evaluate Recovery Loop
          const recovery = evaluateRecovery(task, step);
          if (recovery.allowed) {
            task.retryCount = recovery.retryCount;
            // Loop will retry this step safely
            continue;
          } else {
            transitionTaskState(task, "FAILED", recovery.reason);
            task.honestReport = buildTaskHonestReport(task);
            return task;
          }
        } else {
          step.status = "VERIFIED";
          step.exitCode = exitCode;
          step.verificationEvidence = verificationEvidence;
          task.currentStepIndex += 1;
        }
      } catch (err: any) {
        step.status = "FAILED";
        step.error = err.message || "Execution exception";
        transitionTaskState(task, "FAILED", step.error);
        task.honestReport = buildTaskHonestReport(task);
        return task;
      }
    }

    // All steps finished -> Transition to VERIFYING then COMPLETED
    transitionTaskState(task, "VERIFYING", "Verifying all evidence records");
    transitionTaskState(task, "COMPLETED", "All task steps verified with empirical evidence");
    task.finishedAt = new Date().toISOString();
    task.honestReport = buildTaskHonestReport(task);

    return task;
  } finally {
    activeTaskExecutions.delete(taskId);
  }
}

export function getTaskById(taskId: string): AutonomousTask | undefined {
  return taskStore.get(taskId);
}

export function listTasks(): AutonomousTask[] {
  return Array.from(taskStore.values());
}

export function getTaskEvidence(taskId: string): EvidenceLedgerEntry[] {
  const task = taskStore.get(taskId);
  return task ? task.evidence : [];
}

export function getGlobalEvidenceLedger(): EvidenceLedgerEntry[] {
  return globalEvidenceLedger;
}
