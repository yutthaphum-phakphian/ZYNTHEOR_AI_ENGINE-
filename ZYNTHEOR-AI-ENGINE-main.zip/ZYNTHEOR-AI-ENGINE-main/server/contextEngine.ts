import { mkdir, readFile, writeFile, rename, unlink, readdir, stat } from "node:fs/promises";
import { join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { saveAgentEvent } from "./store.js";
import { redactSecrets } from "./store.js";
import { getWorkspaceDir } from "./files.js";

export type ContextFactType = "FACT" | "ASSUMPTION" | "UNKNOWN" | "STALE";

export interface ContextFact {
  id: string;
  workspaceId: string;
  type: ContextFactType;
  statement: string;
  source: string;
  relevantFiles: string[];
  confidence: number;
  confidenceTag?: "HIGH" | "MEDIUM" | "LOW";
  evidence?: string;
  provenanceKind?: "VERIFIED_FACT" | "USER_CLAIM" | "ASSUMPTION" | "UNKNOWN";
  verified: boolean;
  stale: boolean;
  invalidatedAt?: string;
  invalidationReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface WorkspaceMemoryState {
  workspaceId: string;
  facts: ContextFact[];
  updatedAt: string;
  metadata?: Record<string, unknown>;
}

export interface CreateContextFactInput {
  type: ContextFactType;
  statement: string;
  source?: string;
  relevantFiles?: string[];
  confidence?: number;
  verified?: boolean;
}

export interface UpdateContextFactInput {
  type?: ContextFactType;
  statement?: string;
  source?: string;
  relevantFiles?: string[];
  confidence?: number;
  verified?: boolean;
  stale?: boolean;
}

// Memory file location helper
function getMemoryDir(): string {
  return process.env.MEMORY_STORE_DIR || join(process.cwd(), ".data", "memory");
}

function sanitizeWorkspaceId(workspaceId: string): string {
  if (!workspaceId || typeof workspaceId !== "string") return "default";
  const sanitized = workspaceId.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 80);
  return sanitized || "default";
}

function getMemoryFilePath(workspaceId: string): string {
  const safeId = sanitizeWorkspaceId(workspaceId);
  return join(getMemoryDir(), `${safeId}.json`);
}

function isValidMemoryState(value: unknown, workspaceId: string): value is WorkspaceMemoryState {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const state = value as Record<string, unknown>;
  if (state.workspaceId !== workspaceId || !Array.isArray(state.facts) || typeof state.updatedAt !== "string" || !Number.isFinite(Date.parse(state.updatedAt))) return false;
  return state.facts.every((candidate) => {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) return false;
    const fact = candidate as Record<string, unknown>;
    return fact.workspaceId === workspaceId && typeof fact.id === "string" &&
      ["FACT", "ASSUMPTION", "UNKNOWN", "STALE"].includes(String(fact.type)) &&
      typeof fact.statement === "string" && typeof fact.source === "string" &&
      Array.isArray(fact.relevantFiles) && fact.relevantFiles.every((item) => typeof item === "string") &&
      typeof fact.confidence === "number" && Number.isFinite(fact.confidence) && fact.confidence >= 0 && fact.confidence <= 1 &&
      (fact.confidenceTag === undefined || ["HIGH", "MEDIUM", "LOW"].includes(String(fact.confidenceTag))) &&
      (fact.evidence === undefined || typeof fact.evidence === "string") &&
      (fact.provenanceKind === undefined || ["VERIFIED_FACT", "USER_CLAIM", "ASSUMPTION", "UNKNOWN"].includes(String(fact.provenanceKind))) &&
      typeof fact.verified === "boolean" && typeof fact.stale === "boolean" &&
      typeof fact.createdAt === "string" && Number.isFinite(Date.parse(fact.createdAt)) &&
      typeof fact.updatedAt === "string" && Number.isFinite(Date.parse(fact.updatedAt));
  });
}

async function recordMemoryAudit(type: string, workspaceId: string, data: Record<string, unknown>): Promise<void> {
  // Audit failure must not be hidden: callers need to know the mutation lacks an audit acknowledgment.
  await saveAgentEvent({
    id: `memory_${randomUUID()}`,
    type,
    at: new Date().toISOString(),
    data: { workspaceId, ...data },
  });
}

// In-memory mutex to ensure atomic persistence per workspace
const memoryQueues = new Map<string, Promise<void>>();
async function withWorkspaceLock<T>(workspaceId: string, operation: () => Promise<T>): Promise<T> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const previous = memoryQueues.get(safeId) || Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>((res) => {
    release = res;
  });
  memoryQueues.set(safeId, current);
  await previous;
  try {
    return await operation();
  } finally {
    release();
    if (memoryQueues.get(safeId) === current) {
      memoryQueues.delete(safeId);
    }
  }
}

/**
 * Loads the memory state for a specific workspace.
 * Workspaces are strictly isolated: data is never mixed across sessions or workspaces.
 */
export async function loadWorkspaceMemory(workspaceId: string): Promise<WorkspaceMemoryState> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  return withWorkspaceLock(safeId, async () => {
    const filePath = getMemoryFilePath(safeId);
    try {
      const content = await readFile(filePath, "utf8");
      const parsed: unknown = JSON.parse(content);
      if (!isValidMemoryState(parsed, safeId)) {
        throw new Error(`Persistent memory for workspace "${safeId}" is malformed; refusing to silently reset it.`);
      }
      return parsed;
    } catch (err: any) {
      if (err.code === "ENOENT") {
        return {
          workspaceId: safeId,
          facts: [],
          updatedAt: new Date().toISOString(),
        };
      }
      throw err;
    }
  });
}

/**
 * Saves the memory state for a specific workspace with atomic write and secret redaction.
 */
export async function saveWorkspaceMemory(
  workspaceId: string,
  memory: WorkspaceMemoryState
): Promise<void> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  await withWorkspaceLock(safeId, async () => {
    const dir = getMemoryDir();
    await mkdir(dir, { recursive: true });

    // Scrub all facts to ensure compliance with secret redaction rules
    const scrubbedFacts: ContextFact[] = (memory.facts || []).map((fact) => ({
      ...fact,
      workspaceId: safeId,
      statement: redactSecrets(fact.statement || ""),
      source: redactSecrets(fact.source || "manual"),
      evidence: redactSecrets(fact.evidence || fact.source || "source unavailable"),
      confidenceTag: fact.confidenceTag || (fact.confidence >= 0.8 ? "HIGH" : fact.confidence >= 0.45 ? "MEDIUM" : "LOW"),
      provenanceKind: fact.verified ? "VERIFIED_FACT" : fact.type === "ASSUMPTION" ? "ASSUMPTION" : fact.type === "UNKNOWN" ? "UNKNOWN" : "USER_CLAIM",
      invalidationReason: fact.invalidationReason ? redactSecrets(fact.invalidationReason) : undefined,
    }));

    const sanitizedState: WorkspaceMemoryState = {
      workspaceId: safeId,
      facts: scrubbedFacts,
      updatedAt: new Date().toISOString(),
      metadata: memory.metadata,
    };

    if (!isValidMemoryState(sanitizedState, safeId)) {
      throw new Error(`Refusing to persist invalid memory state for workspace "${safeId}".`);
    }
    const filePath = getMemoryFilePath(safeId);
    const tempPath = `${filePath}.${randomUUID()}.tmp`;
    try {
      await writeFile(tempPath, JSON.stringify(sanitizedState, null, 2), { encoding: "utf8", flag: "wx" });
      await rename(tempPath, filePath);
    } catch (error) {
      await unlink(tempPath).catch(() => undefined);
      throw error;
    }
  });
}

/**
 * Adds a new context fact for a workspace.
 * Applies secret redaction automatically.
 */
export async function addContextFact(
  workspaceId: string,
  input: CreateContextFactInput
): Promise<ContextFact> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const memory = await loadWorkspaceMemory(safeId);

  // Validate type
  if (!input || !["FACT", "ASSUMPTION", "UNKNOWN", "STALE"].includes(input.type)) {
    throw new Error("Context fact type is invalid.");
  }
  const type: ContextFactType = input.type;

  // Clean and sanitize input with secret redaction
  const statement = redactSecrets((input.statement || "").trim());
  if (!statement) {
    throw new Error("Context fact statement cannot be empty.");
  }

  const source = redactSecrets((input.source || "user:manual").trim());
  const relevantFiles = Array.isArray(input.relevantFiles)
    ? input.relevantFiles.map((f) => f.trim()).filter(Boolean)
    : [];

  const now = new Date().toISOString();
  const rawConfidence = typeof input.confidence === "number" && Number.isFinite(input.confidence)
    ? input.confidence
    : (type === "FACT" ? 0.5 : type === "ASSUMPTION" ? 0.3 : 0);
  const confidence = Math.max(0, Math.min(1, rawConfidence));
  const fact: ContextFact = {
    id: `fact_${Date.now()}_${randomUUID().slice(0, 8)}`,
    workspaceId: safeId,
    type,
    statement,
    source,
    relevantFiles,
    confidence,
    confidenceTag: confidence >= 0.8 ? "HIGH" : confidence >= 0.45 ? "MEDIUM" : "LOW",
    evidence: source,
    provenanceKind: input.verified === true && type === "FACT" ? "VERIFIED_FACT" : type === "ASSUMPTION" ? "ASSUMPTION" : type === "UNKNOWN" ? "UNKNOWN" : "USER_CLAIM",
    // A fact label alone is not evidence. Only an explicit trusted caller may mark it verified.
    verified: input.verified === true && type === "FACT",
    stale: false,
    createdAt: now,
    updatedAt: now,
  };

  memory.facts.push(fact);
  memory.updatedAt = now;
  await saveWorkspaceMemory(safeId, memory);
  await recordMemoryAudit("memory_fact_created", safeId, { factId: fact.id, type: fact.type, verified: fact.verified, provenanceKind: fact.provenanceKind, evidence: fact.evidence, confidence: fact.confidence, confidenceTag: fact.confidenceTag });
  return fact;
}

/**
 * Updates an existing context fact.
 */
export async function updateContextFact(
  workspaceId: string,
  factId: string,
  updates: UpdateContextFactInput
): Promise<ContextFact> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const memory = await loadWorkspaceMemory(safeId);

  const index = memory.facts.findIndex((f) => f.id === factId);
  if (index === -1) {
    throw new Error(`Context fact "${factId}" not found in workspace "${safeId}".`);
  }

  const existing = memory.facts[index];
  const now = new Date().toISOString();

  const updated: ContextFact = {
    ...existing,
    type: updates.type && ["FACT", "ASSUMPTION", "UNKNOWN", "STALE"].includes(updates.type) ? updates.type : existing.type,
    statement: updates.statement !== undefined ? redactSecrets(updates.statement.trim()) : existing.statement,
    source: updates.source !== undefined ? redactSecrets(updates.source.trim()) : existing.source,
    relevantFiles: Array.isArray(updates.relevantFiles)
      ? updates.relevantFiles.map((f) => f.trim()).filter(Boolean)
      : existing.relevantFiles,
    confidence: typeof updates.confidence === "number" ? Math.max(0, Math.min(1, updates.confidence)) : existing.confidence,
    confidenceTag: (typeof updates.confidence === "number" ? updates.confidence : existing.confidence) >= 0.8 ? "HIGH" : (typeof updates.confidence === "number" ? updates.confidence : existing.confidence) >= 0.45 ? "MEDIUM" : "LOW",
    evidence: updates.source !== undefined ? redactSecrets(updates.source.trim()) : (existing.evidence || existing.source),
    provenanceKind: (updates.type ?? existing.type) === "ASSUMPTION" ? "ASSUMPTION" : (updates.type ?? existing.type) === "UNKNOWN" ? "UNKNOWN" : ((updates.type ?? existing.type) === "FACT" && (updates.verified ?? existing.verified)) ? "VERIFIED_FACT" : "USER_CLAIM",
    verified: (updates.type ?? existing.type) !== "FACT" ? false :
      updates.verified !== undefined ? Boolean(updates.verified) : existing.verified,
    stale: updates.stale !== undefined ? Boolean(updates.stale) : existing.stale,
    updatedAt: now,
  };

  // If marked non-stale, clear invalidation reason
  if (updates.stale === false) {
    updated.invalidatedAt = undefined;
    updated.invalidationReason = undefined;
  }

  memory.facts[index] = updated;
  memory.updatedAt = now;
  await saveWorkspaceMemory(safeId, memory);
  await recordMemoryAudit("memory_fact_updated", safeId, { factId: updated.id, type: updated.type, verified: updated.verified, stale: updated.stale, provenanceKind: updated.provenanceKind, evidence: updated.evidence, confidence: updated.confidence, confidenceTag: updated.confidenceTag });
  return updated;
}

/**
 * Deletes a context fact by ID.
 */
export async function deleteContextFact(
  workspaceId: string,
  factId: string
): Promise<boolean> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const memory = await loadWorkspaceMemory(safeId);

  const initialLength = memory.facts.length;
  const removedFact = memory.facts.find((f) => f.id === factId);
  memory.facts = memory.facts.filter((f) => f.id !== factId);

  if (memory.facts.length === initialLength) {
    return false;
  }

  memory.updatedAt = new Date().toISOString();
  await saveWorkspaceMemory(safeId, memory);
  await recordMemoryAudit("memory_fact_deleted", safeId, { factId, provenanceKind: removedFact?.provenanceKind || "UNKNOWN", evidence: removedFact?.evidence || removedFact?.source || "source unavailable", confidence: removedFact?.confidence ?? 0, confidenceTag: removedFact?.confidenceTag || "LOW", mutation: "delete" });
  return true;
}

/**
 * Lists facts for a workspace with optional filters.
 */
export async function listContextFacts(
  workspaceId: string,
  options?: { type?: ContextFactType; stale?: boolean; search?: string }
): Promise<ContextFact[]> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const memory = await loadWorkspaceMemory(safeId);
  const storedFacts: ContextFact[] = Array.isArray(memory.facts) ? memory.facts : [];
  let facts: ContextFact[] = [...storedFacts];

  if (options?.type) {
    facts = facts.filter((f) => f.type === options.type);
  }
  if (options?.stale !== undefined) {
    facts = facts.filter((f) => f.stale === options.stale);
  }
  if (options?.search) {
    const q = options.search.toLowerCase();
    facts = facts.filter((fact: ContextFact) => {
      const relevantFiles: string[] = Array.isArray(fact.relevantFiles) ? fact.relevantFiles : [];
      return fact.statement.toLowerCase().includes(q) ||
        fact.source.toLowerCase().includes(q) ||
        relevantFiles.some((file: string) => file.toLowerCase().includes(q));
    });
  }

  return facts;
}

/**
 * Retrieves evidence-bearing memory for a query. Stale facts are excluded by default;
 * relevance is deterministic keyword overlap, not an unsupported semantic-search claim.
 */
export function rankContextFacts(
  facts: ContextFact[],
  query: string,
  options?: { includeStale?: boolean; includeUnverified?: boolean; limit?: number }
): Array<{ fact: ContextFact; score: number; reason: string }> {
  const terms = [...new Set(((query.toLowerCase().match(/[\p{L}\p{N}_-]+/gu) as string[] | null) || []).filter((term: string) => term.length > 1))];
  if (!terms.length) return [];
  const limit = Math.max(1, Math.min(100, Math.floor(options?.limit ?? 10)));
  return facts
    .filter((fact) => options?.includeStale === true || !fact.stale)
    .filter((fact) => options?.includeUnverified === true || fact.verified)
    .map((fact) => {
      const haystack = `${fact.statement} ${fact.source} ${fact.relevantFiles.join(" ")}`.toLowerCase();
      const matched = terms.filter((term) => haystack.includes(term));
      const score = matched.length / terms.length;
      return { fact, score, reason: matched.length ? `Keyword overlap: ${matched.join(", ")}` : "No query terms matched" };
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score || b.fact.updatedAt.localeCompare(a.fact.updatedAt))
    .slice(0, limit);
}

export async function retrieveContextFacts(
  workspaceId: string,
  query: string,
  options?: { includeStale?: boolean; includeUnverified?: boolean; limit?: number }
): Promise<Array<{ fact: ContextFact; score: number; reason: string }>> {
  return rankContextFacts(await listContextFacts(workspaceId), query, options);
}

/**
 * Clears all context facts for a workspace.
 */
export async function clearWorkspaceMemory(workspaceId: string): Promise<void> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const memory: WorkspaceMemoryState = {
    workspaceId: safeId,
    facts: [],
    updatedAt: new Date().toISOString(),
  };
  await saveWorkspaceMemory(safeId, memory);
}

/**
 * Background Utility: Invalidate context facts when relevant files in the workspace are modified.
 * When files are written, edited, or deleted, any facts referencing them are flagged as stale.
 */
export async function invalidateContextFactsForFiles(
  workspaceId: string,
  modifiedFileNames: string[],
  customReason?: string
): Promise<{
  invalidatedCount: number;
  affectedFacts: ContextFact[];
}> {
  if (!modifiedFileNames || modifiedFileNames.length === 0) {
    return { invalidatedCount: 0, affectedFacts: [] };
  }

  const safeId = sanitizeWorkspaceId(workspaceId);
  const memory = await loadWorkspaceMemory(safeId);
  const normalizedModified = modifiedFileNames.map((f) => f.replace(/^\.\//, "").toLowerCase());

  const affectedFacts: ContextFact[] = [];
  const now = new Date().toISOString();

  for (let i = 0; i < memory.facts.length; i++) {
    const fact = memory.facts[i];
    // Check if any relevant file matches modified files
    const matchedFile = fact.relevantFiles.find((rf) =>
      normalizedModified.includes(rf.replace(/^\.\//, "").toLowerCase())
    );

    if (matchedFile && !fact.stale) {
      const updatedFact: ContextFact = {
        ...fact,
        stale: true,
        verified: false,
        invalidatedAt: now,
        invalidationReason: customReason || `ไฟล์ "${matchedFile}" ถูกแก้ไขใน Workspace ข้อมูลอาจไม่เป็นปัจจุบัน`,
        updatedAt: now,
      };
      memory.facts[i] = updatedFact;
      affectedFacts.push(updatedFact);
    }
  }

  if (affectedFacts.length > 0) {
    memory.updatedAt = now;
    await saveWorkspaceMemory(safeId, memory);
  }

  return {
    invalidatedCount: affectedFacts.length,
    affectedFacts,
  };
}

/**
 * Background Utility: Checks file freshness for all relevant files across facts in a workspace.
 * If a relevant file's modification time on disk is newer than the fact's updatedAt timestamp,
 * or if a relevant file no longer exists, marks the fact as stale.
 */
export async function checkWorkspaceFreshness(
  workspaceId: string,
  customWorkspaceDir?: string
): Promise<{
  checkedCount: number;
  invalidatedCount: number;
  affectedFacts: ContextFact[];
}> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const memory = await loadWorkspaceMemory(safeId);
  const wsDir = customWorkspaceDir || getWorkspaceDir();
  const now = new Date().toISOString();
  const affectedFacts: ContextFact[] = [];

  for (let i = 0; i < memory.facts.length; i++) {
    const fact = memory.facts[i];
    if (fact.stale) continue;
    if (!fact.relevantFiles || fact.relevantFiles.length === 0) continue;

    const factTime = new Date(fact.updatedAt).getTime();
    let becameStale = false;
    let staleReason = "";

    for (const relFile of fact.relevantFiles) {
      const filePath = resolve(wsDir, relFile);
      try {
        const fileStat = await stat(filePath);
        if (fileStat.mtimeMs > factTime + 1000) {
          becameStale = true;
          staleReason = `ตรวจพบการเปลี่ยนแปลงใน "${relFile}" (${new Date(fileStat.mtimeMs).toLocaleTimeString()})`;
          break;
        }
      } catch (err: any) {
        if (err.code === "ENOENT") {
          becameStale = true;
          staleReason = `ไม่พบไฟล์ "${relFile}" ใน Workspace (ไฟล์อาจถูกลบหรือย้าย)`;
          break;
        }
      }
    }

    if (becameStale) {
      const updatedFact: ContextFact = {
        ...fact,
        stale: true,
        verified: false,
        invalidatedAt: now,
        invalidationReason: staleReason,
        updatedAt: now,
      };
      memory.facts[i] = updatedFact;
      affectedFacts.push(updatedFact);
    }
  }

  if (affectedFacts.length > 0) {
    memory.updatedAt = now;
    await saveWorkspaceMemory(safeId, memory);
  }

  return {
    checkedCount: memory.facts.length,
    invalidatedCount: affectedFacts.length,
    affectedFacts,
  };
}

/**
 * Returns all active workspaces that have persistent memory entries.
 */
export async function listWorkspacesWithMemory(): Promise<string[]> {
  const dir = getMemoryDir();
  try {
    const files = await readdir(dir);
    return files
      .filter((f) => f.endsWith(".json"))
      .map((f) => f.slice(0, -5));
  } catch {
    return ["default"];
  }
}

/**
 * Context Engine singleton interface for AI Brain Core integration
 */
export class ProjectContextEngine {
  constructor(private readonly defaultWorkspaceId = "default") {}

  async getContextForReasoning(workspaceId = this.defaultWorkspaceId): Promise<{
    facts: ContextFact[];
    assumptions: ContextFact[];
    unknowns: ContextFact[];
    staleFactsCount: number;
  }> {
    const all = await listContextFacts(workspaceId);
    return {
      facts: all.filter((f) => f.type === "FACT" && !f.stale),
      assumptions: all.filter((f) => f.type === "ASSUMPTION" && !f.stale),
      unknowns: all.filter((f) => f.type === "UNKNOWN"),
      staleFactsCount: all.filter((f) => f.stale).length,
    };
  }

  async recordObservedFact(
    workspaceId: string,
    statement: string,
    source: string,
    relevantFiles: string[] = []
  ): Promise<ContextFact> {
    return addContextFact(workspaceId, {
      type: "FACT",
      statement,
      source,
      relevantFiles,
      verified: true,
    });
  }

  async recordAssumption(
    workspaceId: string,
    statement: string,
    source = "ai_inference",
    relevantFiles: string[] = []
  ): Promise<ContextFact> {
    return addContextFact(workspaceId, {
      type: "ASSUMPTION",
      statement,
      source,
      relevantFiles,
      verified: false,
    });
  }

  async recordUnknown(
    workspaceId: string,
    statement: string,
    source = "gap_analysis",
    relevantFiles: string[] = []
  ): Promise<ContextFact> {
    return addContextFact(workspaceId, {
      type: "UNKNOWN",
      statement,
      source,
      relevantFiles,
      verified: false,
    });
  }

  async onFilesModified(workspaceId: string, fileNames: string[]) {
    return invalidateContextFactsForFiles(workspaceId, fileNames);
  }
}

export const projectContextEngine = new ProjectContextEngine();
