/**
 * P13 - HSM/KMS + TSA + Ed25519 Tamper-Proof
 * Local-only, no external provider
 * Simulates HSM with local keystore + Ed25519 sign/verify
 */
import crypto from 'node:crypto'

// Simulated HSM Keystore (in production: real HSM)
const keystore = new Map<string, { publicKey: string, privateKey: string }>()

export function generateEd25519Keypair(keyId: string) {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519', {
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
  })
  keystore.set(keyId, { publicKey, privateKey })
  return { keyId, publicKey }
}

export function signWithEd25519(keyId: string, payload: string): { signature: string, keyId: string } {
  const keys = keystore.get(keyId)
  if (!keys) throw new Error(`Key ${keyId} not found in HSM - BLOCKED`)
  
  const signature = crypto.sign(null, Buffer.from(payload), keys.privateKey).toString('base64')
  return { signature, keyId }
}

export function verifyEd25519(keyId: string, payload: string, signature: string): boolean {
  const keys = keystore.get(keyId)
  if (!keys) return false
  try {
    return crypto.verify(null, Buffer.from(payload), keys.publicKey, Buffer.from(signature, 'base64'))
  } catch { return false }
}

// TSA - Trusted Timestamp Authority (local simulation)
export function createTimestampToken(digest: string) {
  const timestamp = new Date().toISOString()
  const tsaPayload = `TSA|${digest}|${timestamp}`
  const token = crypto.createHash('sha256').update(tsaPayload).digest('hex')
  return { digest, timestamp, token, authority: 'ZYNTH-LOCAL-TSA' }
}

export function getHSMStatus() {
  return {
    provider: 'local-hsm-sim',
    keys: Array.from(keystore.keys()),
    algorithm: 'Ed25519',
    tsa: 'enabled',
    mode: 'local-only'
  }
}
