/**
 * P14 - Evaluation Bench + Thai Voice Commands + Auto-tagging
 * Local-only
 */

export type Tag = 'Bug'|'Idea'|'Arch'|'Code'|'Review'|'Question'

// Thai voice commands mapping
export const thaiVoiceCommands: Record<string, string> = {
  'สรุปเซสชัน': 'summarize_session',
  'เปิดแผนงาน': 'open_plans',
  'ตรวจสอบโค้ด': 'review_code',
  'สร้างเอกสาร': 'create_doc',
  'อนุมัติ': 'approve',
  'ตรวจสอบความปลอดภัย': 'security_check',
  'เปิดบันทึกตรวจสอบ': 'open_audit',
  'สลับโหมด': 'switch_mode'
}

// Auto-tagging - bilingual detection
export function autoTag(text: string): Tag[] {
  const tags: Set<Tag> = new Set()
  const lower = text.toLowerCase()
  
  if (/bug|บั๊ก|ข้อผิดพลาด|error|พัง|แก้/.test(lower)) tags.add('Bug')
  if (/idea|ไอเดีย|แผน|ข้อเสนอ|ควร|น่าจะ/.test(lower)) tags.add('Idea')
  if (/arch|สถาปัตยกรรม|โครงสร้าง|design|system/.test(lower)) tags.add('Arch')
  if (/code|โค้ด|ฟังก์ชัน|function|class/.test(lower)) tags.add('Code')
  if (/review|ตรวจสอบ|ตรวจ|เช็ค/.test(lower)) tags.add('Review')
  if (/\?|\?|ทำไม|อย่างไร|ไหม|หรือไม่/.test(lower)) tags.add('Question')
  
  return Array.from(tags)
}

// Eval bench - app build benchmark
export type BenchResult = { task: string, passed: boolean, durationMs: number, evidence: string }

export function runAppBuildBench(tasks: string[]): BenchResult[] {
  const crypto = require('node:crypto') as typeof import('node:crypto')
  return tasks.map(task => {
    const start = Date.now()
    // Simulate check - Zero-fake: if task contains "external" -> BLOCKED
    const isBlocked = /external|google|openai/.test(task.toLowerCase())
    const passed = !isBlocked
    const digest = crypto.createHash('sha256').update(task).digest('hex').slice(0,12)
    return {
      task,
      passed,
      durationMs: Date.now() - start,
      evidence: `P14-BENCH|${digest}|${passed ? 'PASS' : 'BLOCKED'}`
    }
  })
}
