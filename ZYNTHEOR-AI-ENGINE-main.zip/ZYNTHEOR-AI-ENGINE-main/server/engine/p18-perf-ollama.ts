/**
 * P18 - Performance - Ollama Local Core Optimization
 * Local-only, no external inference
 */
export const p18PerfConfig = {
  ollama: {
    endpoint: 'http://127.0.0.1:11434',
    model: 'llama3.2:3b',
    options: {
      num_parallel: 1,
      num_ctx: 4096,
      temperature: 0.2,
      keep_alive: '5m'
    }
  },
  cache: {
    modelDigest: true,
    tokenizer: true,
    systemPrompt: true,
    ttlMs: 5*60*1000
  },
  ledger: {
    batchWriteMs: 100,
    maxBatchSize: 50,
    hashAlgorithm: 'sha256'
  }
}

export function getP18OptimizationReport() {
  const mem = process.memoryUsage()
  return {
    phase: 'P18',
    group: 'P17-P18 Eval + Performance',
    ollama: p18PerfConfig.ollama,
    memory: {
      heapMb: Math.round(mem.heapUsed/1024/1024),
      rssMb: Math.round(mem.rss/1024/1024)
    },
    suggestions: [
      'Use OLLAMA_NUM_PARALLEL=1 for stability on low RAM',
      'Cache MODEL_MANIFEST_DIGEST in memory - avoid fs read per request',
      'Batch ledger writes - reduce I/O',
      'Enable keep_alive 5m to avoid cold start'
    ],
    localOnly: true
  }
}
