/**
 * P16 - HSM/KMS + TSA + Ed25519 Final Verification
 * Closes P14-P16 group: HSM/KMS + TSA timestamp + Ed25519 sign
 * Local-only, Zero-Fake
 */
import crypto from 'node:crypto'
import { generateEd25519Keypair, signWithEd25519, verifyEd25519, createTimestampToken } from './hsm-kms.js'

export type P16Evidence = {
  phase: 'P16'
  group: 'P14-P16 HSM/KMS + TSA + Ed25519'
  keyId: string
  digest: string
  signature: string
  tsa: { digest: string, timestamp: string, token: string, authority: string }
  verified: boolean
  chain: string[]
}

export function runP16Closure(payload: string, keyId = 'zyntheor-p16-final'): P16Evidence {
  // 1. Generate keypair in simulated HSM if not exists
  let keys: any
  try {
    keys = generateEd25519Keypair(keyId)
  } catch {
    // key already exists
  }

  // 2. Digest
  const digest = crypto.createHash('sha256').update(payload).digest('hex')
  
  // 3. Sign with Ed25519
  const { signature } = signWithEd25519(keyId, payload)
  
  // 4. TSA token
  const tsa = createTimestampToken(digest)
  
  // 5. Verify
  const verified = verifyEd25519(keyId, payload, signature)
  
  // 6. Evidence chain
  const chain = [
    `P16|KEYGEN|${keyId}`,
    `P16|DIGEST|${digest.slice(0,16)}`,
    `P16|SIGN|${signature.slice(0,16)}...`,
    `P16|TSA|${tsa.token.slice(0,16)}`,
    `P16|VERIFY|${verified ? 'PASS' : 'FAIL'}`
  ]

  if (!verified) throw new Error('P16 verification FAILED - BLOCKED (Zero-Fake)')

  return {
    phase: 'P16',
    group: 'P14-P16 HSM/KMS + TSA + Ed25519',
    keyId,
    digest,
    signature,
    tsa,
    verified,
    chain
  }
}

// For audit/trail_p16.log
export function createP16AuditLog(payload: string) {
  const evidence = runP16Closure(payload)
  const logLine = `${new Date().toISOString()} | P16 | ${evidence.digest} | ${evidence.tsa.token} | ${evidence.signature.slice(0,32)} | VERIFIED`
  return { logLine, evidence }
}
