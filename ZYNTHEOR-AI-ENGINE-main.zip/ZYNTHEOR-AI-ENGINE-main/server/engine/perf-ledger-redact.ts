/**
 * P15 - Performance + Audit Ledger Explorer + Secret Redaction
 * Local-only
 */
import crypto from 'node:crypto'

// Secret redaction - filter API keys, tokens from logs/UI
const SECRET_PATTERNS = [
  /GEMINI_API_KEY\s*=\s*.+/gi,
  /OPENAI_API_KEY\s*=\s*.+/gi,
  /ANTHROPIC_API_KEY\s*=\s*.+/gi,
  /Bearer\s+[A-Za-z0-9\-\._~\+\/]+=* /gi,
  /sk-[A-Za-z0-9]{20,}/g,
  /xoxb-[0-9]+-[0-9]+-[A-Za-z0-9]+/g
]

export function redactSecrets(text: string): { redacted: string, found: number } {
  let redacted = text
  let found = 0
  for (const pattern of SECRET_PATTERNS) {
    const matches = redacted.match(pattern)
    if (matches) found += matches.length
    redacted = redacted.replace(pattern, '[REDACTED]')
  }
  return { redacted, found }
}

// Audit Ledger Explorer
export type LedgerEntry = { id: string, timestamp: string, action: string, digest: string, correlationId: string, prevHash: string }

export function verifyLedgerChain(entries: LedgerEntry[]): { valid: boolean, brokenAt?: number } {
  for (let i = 1; i < entries.length; i++) {
    const expectedPrev = crypto.createHash('sha256').update(JSON.stringify(entries[i-1])).digest('hex')
    if (entries[i].prevHash !== expectedPrev) {
      return { valid: false, brokenAt: i }
    }
  }
  return { valid: true }
}

// Performance - Ollama optimization hints
export function getPerformanceHints() {
  const mem = process.memoryUsage()
  return {
    memory: {
      heapUsedMb: Math.round(mem.heapUsed / 1024 / 1024),
      rssMb: Math.round(mem.rss / 1024 / 1024)
    },
    suggestions: [
      mem.heapUsed > 500*1024*1024 ? 'Consider --max-old-space-size=1024' : 'Memory OK',
      'Ollama: OLLAMA_NUM_PARALLEL=1 for stability',
      'Local Core: cache model digest in memory',
      'Ledger: batch writes every 100ms'
    ],
    localOnly: true
  }
}
