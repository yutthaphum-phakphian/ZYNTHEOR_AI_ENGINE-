/**
 * URL Metadata Scraping Utility
 *
 * Scrapes basic Open Graph and meta tags (title, description, og:image, favicon)
 * with strict SSRF protection, bounded size/timeouts, and in-memory caching.
 */

import { assertSafeUrl } from "./connectors/webResearch.js";
import { redactSecrets } from "./store.js";

export interface ScrapedUrlMetadata {
  url: string;
  domain: string;
  title: string | null;
  description: string | null;
  image: string | null;
  favicon: string | null;
  status: "SUCCESS" | "FALLBACK" | "BLOCKED";
  error?: string;
  fetchedAt: string;
}

const metadataCache = new Map<string, { data: ScrapedUrlMetadata; expiresAt: number }>();
const CACHE_TTL_MS = 60 * 60 * 1000; // 1 hour

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x2F;/g, "/")
    .replace(/&nbsp;/g, " ")
    .trim();
}

function extractMetaTag(html: string, property: string): string | null {
  // Support both property="..." and name="..."
  const patterns = [
    new RegExp(`<meta\\s+[^>]*property=["'](?:og:|twitter:)?${property}["'][^>]*content=["']([^"']*)["']`, "i"),
    new RegExp(`<meta\\s+[^>]*content=["']([^"']*)["'][^>]*property=["'](?:og:|twitter:)?${property}["']`, "i"),
    new RegExp(`<meta\\s+[^>]*name=["'](?:og:|twitter:)?${property}["'][^>]*content=["']([^"']*)["']`, "i"),
    new RegExp(`<meta\\s+[^>]*content=["']([^"']*)["'][^>]*name=["'](?:og:|twitter:)?${property}["']`, "i"),
  ];

  for (const regex of patterns) {
    const match = html.match(regex);
    if (match && match[1]) {
      return decodeHtmlEntities(match[1]);
    }
  }
  return null;
}

export function parseHtmlMetadata(html: string, baseUrl: URL): {
  title: string | null;
  description: string | null;
  image: string | null;
  favicon: string | null;
} {
  // 1. Title
  let title = extractMetaTag(html, "title");
  if (!title) {
    const titleMatch = html.match(/<title[^>]*>([^<]*)<\/title>/i);
    if (titleMatch && titleMatch[1]) {
      title = decodeHtmlEntities(titleMatch[1]);
    }
  }

  // 2. Description
  const description = extractMetaTag(html, "description");

  // 3. Image
  let rawImage = extractMetaTag(html, "image");
  let image: string | null = null;
  if (rawImage) {
    try {
      image = new URL(rawImage, baseUrl.origin).href;
    } catch {
      image = null;
    }
  }

  // 4. Favicon
  let favicon: string | null = null;
  const iconMatch = html.match(/<link\s+[^>]*rel=["'](?:shortcut )?icon["'][^>]*href=["']([^"']*)["']/i) ||
                    html.match(/<link\s+[^>]*href=["']([^"']*)["'][^>]*rel=["'](?:shortcut )?icon["']/i);
  if (iconMatch && iconMatch[1]) {
    try {
      favicon = new URL(iconMatch[1], baseUrl.origin).href;
    } catch {
      favicon = `${baseUrl.origin}/favicon.ico`;
    }
  } else {
    favicon = `${baseUrl.origin}/favicon.ico`;
  }

  return { title, description, image, favicon };
}

export async function scrapeUrlMetadata(rawUrl: string): Promise<ScrapedUrlMetadata> {
  const cached = metadataCache.get(rawUrl);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.data;
  }

  let safeUrl: URL;
  try {
    safeUrl = assertSafeUrl(rawUrl);
  } catch (err: any) {
    return {
      url: rawUrl,
      domain: "blocked-url",
      title: null,
      description: null,
      image: null,
      favicon: null,
      status: "BLOCKED",
      error: redactSecrets(err.message || "URL safety check failed"),
      fetchedAt: new Date().toISOString(),
    };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000);

  try {
    const response = await fetch(safeUrl.href, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Zyntheor-Engine/1.0 (+https://zyntheor.local; Link Preview Scraper)",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const fallback: ScrapedUrlMetadata = {
        url: safeUrl.href,
        domain: safeUrl.hostname,
        title: safeUrl.hostname,
        description: null,
        image: null,
        favicon: `${safeUrl.origin}/favicon.ico`,
        status: "FALLBACK",
        error: `HTTP ${response.status}`,
        fetchedAt: new Date().toISOString(),
      };
      metadataCache.set(rawUrl, { data: fallback, expiresAt: Date.now() + CACHE_TTL_MS });
      return fallback;
    }

    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("text/html") && !contentType.includes("application/xhtml")) {
      const nonHtml: ScrapedUrlMetadata = {
        url: safeUrl.href,
        domain: safeUrl.hostname,
        title: safeUrl.pathname.split("/").pop() || safeUrl.hostname,
        description: `Direct resource (${contentType || "binary"})`,
        image: contentType.startsWith("image/") ? safeUrl.href : null,
        favicon: `${safeUrl.origin}/favicon.ico`,
        status: "SUCCESS",
        fetchedAt: new Date().toISOString(),
      };
      metadataCache.set(rawUrl, { data: nonHtml, expiresAt: Date.now() + CACHE_TTL_MS });
      return nonHtml;
    }

    // Limit buffer read to 512KB
    const rawHtml = await response.text();
    const truncatedHtml = rawHtml.slice(0, 512 * 1024);

    const parsed = parseHtmlMetadata(truncatedHtml, safeUrl);

    const result: ScrapedUrlMetadata = {
      url: safeUrl.href,
      domain: safeUrl.hostname,
      title: parsed.title || safeUrl.hostname,
      description: parsed.description ? redactSecrets(parsed.description).slice(0, 300) : null,
      image: parsed.image,
      favicon: parsed.favicon,
      status: "SUCCESS",
      fetchedAt: new Date().toISOString(),
    };

    metadataCache.set(rawUrl, { data: result, expiresAt: Date.now() + CACHE_TTL_MS });
    return result;
  } catch (err: any) {
    clearTimeout(timeoutId);
    const fallback: ScrapedUrlMetadata = {
      url: safeUrl.href,
      domain: safeUrl.hostname,
      title: safeUrl.hostname,
      description: null,
      image: null,
      favicon: `${safeUrl.origin}/favicon.ico`,
      status: "FALLBACK",
      error: redactSecrets(err.message || "Scraping failed"),
      fetchedAt: new Date().toISOString(),
    };
    metadataCache.set(rawUrl, { data: fallback, expiresAt: Date.now() + 10 * 60 * 1000 });
    return fallback;
  }
}
