import express, { type NextFunction, type Request, type Response } from "express";
import { randomUUID } from "node:crypto";
import {
  createFileProposal,
  listWorkspaceFiles,
  requestProposalApproval,
  validateWorkspaceRelativePath,
  isBlockedFilename,
} from "./files.js";
import { getActiveProviderAdapter } from "./provider.js";
import {
  executeSandboxTask,
  testNetworkIsolationCapability,
  type SandboxExecutionResult,
  type SandboxPatchFile,
} from "./sandboxRunner.js";
import { redactSecrets, saveAgentEvent } from "./store.js";

type PatchProposal = SandboxPatchFile & { reason: string };
type GeneratedPatch = { analysis: string; patches: PatchProposal[] };

const MAX_PATCH_FILES = 5;
const MAX_PATCH_BYTES = 64 * 1024;
const MAX_CONTEXT_BYTES = 32 * 1024;
const PATCHABLE_EXTENSIONS = new Set([".cjs", ".css", ".html", ".js", ".json", ".mjs", ".ts", ".tsx"]);
const BLOCKED_PATCH_FILENAMES = new Set([
  "package.json",
  "package-lock.json",
  "npm-shrinkwrap.json",
  "bun.lock",
  "pnpm-lock.yaml",
  "yarn.lock",
  "tsconfig.json",
]);

function failureAnalysis(result: SandboxExecutionResult): string {
  const evidence = `${result.stdout}\n${result.stderr}`;
  const assertion = evidence.match(/AssertionError(?:\s*\[[^\]]+\])?:[^\n]*/);
  if (assertion) return `The sandbox reported a failing assertion: ${assertion[0].trim()}`;
  const syntax = evidence.match(/Syntax error in ([^:\n]+)|SyntaxError:[^\n]*/);
  if (syntax) return `The sandbox reported a JavaScript syntax failure: ${syntax[0].trim()}`;
  return `The ${result.taskType} sandbox command exited with code ${result.exitCode}. The captured output is evidence of failure, but does not identify a verified root cause.`;
}

function hasTestEvidence(result: SandboxExecutionResult): boolean {
  const output = `${result.stdout}\n${result.stderr}`;
  const counts = [...output.matchAll(/(?:# tests|ℹ tests)\s+(\d+)/g)]
    .map((match) => Number(match[1]));
  return counts.some((count) => Number.isInteger(count) && count > 0);
}

function parseGeneratedPatch(text: string): GeneratedPatch | null {
  const json = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  let value: unknown;
  try {
    value = JSON.parse(json);
  } catch {
    return null;
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const candidate = value as Record<string, unknown>;
  if (
    Object.keys(candidate).some((key) => key !== "analysis" && key !== "patches") ||
    typeof candidate.analysis !== "string" ||
    !candidate.analysis.trim() ||
    candidate.analysis.length > 4000 ||
    !Array.isArray(candidate.patches) ||
    candidate.patches.length === 0 ||
    candidate.patches.length > MAX_PATCH_FILES
  ) {
    return null;
  }
  const patches: PatchProposal[] = [];
  const names = new Set<string>();
  for (const value of candidate.patches) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const patch = value as Record<string, unknown>;
    if (
      Object.keys(patch).some((key) => !["name", "content", "reason"].includes(key)) ||
      typeof patch.name !== "string" ||
      typeof patch.content !== "string" ||
      typeof patch.reason !== "string" ||
      !patch.reason.trim() ||
      patch.reason.length > 1000 ||
      Buffer.byteLength(patch.content, "utf8") > MAX_PATCH_BYTES
    ) {
      return null;
    }
    let safeName: string;
    try {
      safeName = validateWorkspaceRelativePath(patch.name);
    } catch {
      return null;
    }
    const parts = safeName.split("/");
    const filename = parts.at(-1)?.toLowerCase() || "";
    const extension = safeName.slice(safeName.lastIndexOf(".")).toLowerCase();
    if (
      safeName !== patch.name ||
      names.has(safeName) ||
      BLOCKED_PATCH_FILENAMES.has(filename) ||
      parts.some((part) => /^(?:tests?|__tests__|node_modules|\.git)$/i.test(part)) ||
      /(?:sovereign|kernel|core)/i.test(safeName) ||
      !PATCHABLE_EXTENSIONS.has(extension) ||
      isBlockedFilename(filename)
    ) {
      return null;
    }
    names.add(safeName);
    patches.push({ name: safeName, content: patch.content, reason: patch.reason.trim() });
  }
  return { analysis: candidate.analysis.trim(), patches };
}

function sourceContext(
  files: Array<{ name: string; content: string }>,
  targetPath?: string
): string {
  const selected = targetPath
    ? files.filter((file) => file.name === targetPath)
    : files.filter((file) => /\.(?:cjs|css|html|js|json|mjs|ts|tsx)$/i.test(file.name));
  let remaining = MAX_CONTEXT_BYTES;
  const sections: string[] = [];
  for (const file of selected) {
    if (isBlockedFilename(file.name)) continue;
    const content = redactSecrets(file.content);
    const section = `--- ${file.name} ---\n${content}`;
    const bytes = Buffer.byteLength(section, "utf8");
    if (bytes > remaining) break;
    sections.push(section);
    remaining -= bytes;
  }
  return sections.join("\n\n");
}

function publicExecution(result: SandboxExecutionResult) {
  return {
    status: result.status,
    taskType: result.taskType,
    command: result.command,
    exitCode: result.exitCode,
    durationMs: result.durationMs,
    filesHash: result.filesHash,
    stdout: result.stdout,
    stderr: result.stderr,
    networkIsolated: result.networkIsolated,
    truncated: result.truncated,
  };
}

async function runImprovement(request: Request, response: Response): Promise<void> {
  const body = request.body;
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    response.status(400).json({ status: "blocked", code: "invalid_request" });
    return;
  }
  const allowedKeys = ["taskType", "targetPath", "allowExternalCodeSharing"];
  if (Object.keys(body).some((key) => !allowedKeys.includes(key))) {
    response.status(400).json({ status: "blocked", code: "unexpected_request_field" });
    return;
  }
  if (body.taskType !== "test" && body.taskType !== "syntax_check") {
    response.status(400).json({
      status: "blocked",
      code: "unsupported_task_type",
      message: "Self-improvement currently supports only sandbox test and JavaScript syntax-check tasks.",
    });
    return;
  }
  const taskType = body.taskType as "test" | "syntax_check";
  const targetPath = body.targetPath;
  if (targetPath !== undefined && typeof targetPath !== "string") {
    response.status(400).json({ status: "blocked", code: "invalid_target_path" });
    return;
  }
  if (taskType === "test" && targetPath !== undefined) {
    response.status(400).json({ status: "blocked", code: "target_path_not_supported_for_test" });
    return;
  }
  if (taskType === "syntax_check" && !targetPath) {
    response.status(400).json({ status: "blocked", code: "target_path_required" });
    return;
  }
  if (taskType === "syntax_check" && !/\.(?:cjs|js|mjs)$/i.test(targetPath || "")) {
    response.status(400).json({ status: "blocked", code: "javascript_target_required" });
    return;
  }
  if (typeof targetPath === "string") {
    try {
      validateWorkspaceRelativePath(targetPath);
    } catch {
      response.status(400).json({ status: "blocked", code: "invalid_target_path" });
      return;
    }
  }
  const workspaceFiles = await listWorkspaceFiles();
  if (taskType === "syntax_check" && !workspaceFiles.some((file) => file.name === targetPath)) {
    response.status(404).json({ status: "blocked", code: "target_file_not_found" });
    return;
  }
  if (body.allowExternalCodeSharing !== undefined && typeof body.allowExternalCodeSharing !== "boolean") {
    response.status(400).json({ status: "blocked", code: "invalid_external_sharing_consent" });
    return;
  }

  const networkIsolated = await testNetworkIsolationCapability();
  if (taskType === "test" && !networkIsolated) {
    response.status(503).json({
      status: "unavailable",
      code: "sandbox_network_isolation_unavailable",
      message: "Test execution requires OS network namespace isolation; no test or patch code was executed.",
      networkIsolated: false,
    });
    return;
  }

  const baseline = await executeSandboxTask(taskType, targetPath, 30000);
  const analysis = failureAnalysis(baseline);
  if (baseline.status === "VERIFIED" && (taskType !== "test" || hasTestEvidence(baseline))) {
    response.json({
      status: "no_failure_detected",
      message: "The sandbox task completed successfully; no patch was generated.",
      baseline: publicExecution(baseline),
    });
    return;
  }
  if (baseline.status !== "FAIL" || (taskType === "test" && !hasTestEvidence(baseline))) {
    response.status(422).json({
      status: baseline.status === "FAIL" ? "not_verified" : "unavailable",
      code: baseline.status === "FAIL" ? "test_evidence_missing" : "baseline_not_executable",
      analysis,
      baseline: publicExecution(baseline),
    });
    return;
  }
  if (body.allowExternalCodeSharing !== true) {
    response.json({
      status: "analysis_only",
      analysis,
      baseline: publicExecution(baseline),
      patchStatus: "not_generated",
      reason: "Source files are not sent to an external provider without explicit allowExternalCodeSharing consent.",
    });
    return;
  }

  const provider = getActiveProviderAdapter();
  if (!provider.isConfigured()) {
    const unavailable = await provider.generateText("", "");
    response.status(503).json({
      status: "unavailable",
      code: unavailable.status === "unavailable" ? unavailable.code : "provider_not_configured",
      message: unavailable.status === "unavailable" ? unavailable.message : "No configured AI provider is available.",
      analysis,
      baseline: publicExecution(baseline),
    });
    return;
  }

  const context = sourceContext(workspaceFiles, targetPath);
  const providerResult = await provider.generateText(
    [
      "Analyze a real failed sandbox run and propose a minimal source patch.",
      "The supplied output is evidence, not proof of a root cause. State uncertainty honestly.",
      "Do not modify tests, protected core/kernel/Sovereign files, manifests for package scripts, or dependency declarations.",
      "Return JSON only: {\"analysis\":\"...\",\"patches\":[{\"name\":\"existing/path.js\",\"content\":\"complete replacement file\",\"reason\":\"...\"}]}.",
      "Only patch existing workspace files. Do not claim the patch works unless its sandbox retest passes.",
    ].join("\n"),
    [
      {
        role: "user",
        content: redactSecrets(JSON.stringify({
          taskType,
          targetPath: targetPath || null,
          baseline: {
            command: baseline.command,
            exitCode: baseline.exitCode,
            filesHash: baseline.filesHash,
            stdout: baseline.stdout,
            stderr: baseline.stderr,
          },
          availableSourceFiles: workspaceFiles.map((file) => file.name),
          sourceContext: context,
        })),
      },
    ]
  );
  if (providerResult.status !== "completed") {
    response.status(503).json({
      status: "unavailable",
      code: providerResult.code,
      message: providerResult.message,
      analysis,
      baseline: publicExecution(baseline),
    });
    return;
  }

  const generated = parseGeneratedPatch(providerResult.text);
  if (!generated) {
    response.status(422).json({
      status: "blocked",
      code: "invalid_patch_proposal",
      message: "The configured provider did not return a valid, allowlisted patch proposal.",
      analysis,
      baseline: publicExecution(baseline),
    });
    return;
  }
  const existingFiles = new Set(workspaceFiles.map((file) => file.name));
  if (generated.patches.some((patch) => !existingFiles.has(patch.name))) {
    response.status(422).json({
      status: "blocked",
      code: "patch_must_update_existing_files",
      analysis: generated.analysis,
      baseline: publicExecution(baseline),
    });
    return;
  }
  if (taskType === "syntax_check" && !generated.patches.some((patch) => patch.name === targetPath)) {
    response.status(422).json({
      status: "blocked",
      code: "patch_does_not_cover_target",
      analysis: generated.analysis,
      baseline: publicExecution(baseline),
    });
    return;
  }

  const patchFiles = generated.patches.map(({ name, content }) => ({ name, content }));
  const candidate = await executeSandboxTask(taskType, targetPath, 30000, patchFiles);
  if (
    candidate.status !== "VERIFIED" ||
    (taskType === "test" && !hasTestEvidence(candidate))
  ) {
    response.json({
      status: "patch_test_failed",
      analysis: generated.analysis,
      baseline: publicExecution(baseline),
      candidate: publicExecution(candidate),
      proposals: [],
    });
    return;
  }

  const proposals = [];
  for (const patch of generated.patches) {
    const proposal = await createFileProposal({
      type: "edit",
      name: patch.name,
      content: patch.content,
    });
    await requestProposalApproval(proposal.id);
    proposals.push({
      id: proposal.id,
      name: proposal.name,
      hash: proposal.hash,
      diff: proposal.diff,
      status: proposal.status,
      reason: patch.reason,
    });
  }
  const audit = await saveAgentEvent({
    id: randomUUID(),
    type: "SELF_IMPROVEMENT_PATCH_VERIFIED",
    at: new Date().toISOString(),
    data: {
      provider: provider.id,
      taskType,
      baselineHash: baseline.filesHash,
      candidateHash: candidate.filesHash,
      baselineExitCode: baseline.exitCode,
      candidateExitCode: candidate.exitCode,
      networkIsolated: candidate.networkIsolated,
      files: proposals.map(({ id, name, hash }) => ({ proposalId: id, name, hash })),
      approvalRequired: true,
    },
  });

  response.json({
    status: "patch_verified_waiting_approval",
    analysis: generated.analysis,
    provider: providerResult.model,
    baseline: publicExecution(baseline),
    candidate: publicExecution(candidate),
    proposals,
    audit,
    applyWith: "POST /api/proposals/:id/approve then POST /api/proposals/:id/apply",
    note: "The patch was tested only in a temporary sandbox. No workspace file was changed.",
  });
}

export function createSelfImprovementRouter(): express.Router {
  const router = express.Router();
  router.post("/run", (request: Request, response: Response, next: NextFunction) => {
    void runImprovement(request, response).catch(next);
  });
  return router;
}

export const selfImprovementInternals = { failureAnalysis, hasTestEvidence, parseGeneratedPatch };
