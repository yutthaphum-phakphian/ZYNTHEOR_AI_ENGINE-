/**
 * Connects real run results to the learning loop and feeds validated lessons back to reasoning.
 *
 * Capture is deterministic: a lesson is derived only from an observable marker in real tool output
 * (never from model text), and always carries ledger evidence ids. Capture can never change a run's outcome.
 * Use: validated lessons enter reasoning as HYPOTHESES (verified:false) — they guide, they do not prove.
 */
import { observeLesson, retrieveUsableLessons, type Lesson } from "./learningLoop.js";
import type { EvidenceItem } from "./reasoning.js";

export interface RunObservation {
  taskType: string;
  exitCode: number;
  stdout: string;
}

const RULES: Array<{ taskType: string; lesson: string; matches: (o: RunObservation) => boolean }> = [
  {
    taskType: "build",
    lesson: "A build fails when the workspace has no index.html entry file.",
    matches: (o) => o.exitCode !== 0 && /HTML entry:\s*Missing/i.test(o.stdout),
  },
  {
    taskType: "build",
    lesson: "An app project build fails when app.json has manifest errors; fix the manifest before building.",
    matches: (o) => o.exitCode !== 0 && /Manifest \(app\.json\):\s*Issues detected/i.test(o.stdout),
  },
  {
    taskType: "research",
    lesson: "External research requires verified publisher URLs and separates facts from inferences.",
    matches: (o) => o.exitCode === 0 && /แหล่งข้อมูล/i.test(o.stdout),
  },
  {
    taskType: "research",
    lesson: "When research yields 0 results, the engine reports honest zero results without fabricating URLs.",
    matches: (o) => /0 results|ไม่พบข้อมูล/i.test(o.stdout),
  },
];

export function deriveLessonCandidates(o: RunObservation): Array<{ taskType: string; lesson: string }> {
  return RULES.filter((r) => r.taskType === o.taskType && r.matches(o)).map(({ taskType, lesson }) => ({ taskType, lesson }));
}

/** Records lessons for a finished run. Never throws; returns what was recorded. */
export async function captureLessonsFromRun(
  o: RunObservation & { runId: string; evidenceRefs: string[] },
): Promise<Lesson[]> {
  const recorded: Lesson[] = [];
  if (o.evidenceRefs.length === 0) return recorded;
  for (const c of deriveLessonCandidates(o)) {
    try {
      recorded.push(await observeLesson({ ...c, runId: o.runId, held: true, evidenceRefs: o.evidenceRefs }));
    } catch {
      // learning must never affect the task outcome
    }
  }
  return recorded;
}

/** Validated lessons for a task type, shaped as unverified hypotheses for the reasoning evidence list. */
export async function lessonsAsEvidence(taskType: string): Promise<EvidenceItem[]> {
  try {
    return (await retrieveUsableLessons(taskType)).map((l) => ({
      id: `lesson_${l.id}`,
      category: "hypothesis" as const,
      statement: `[บทเรียนที่ยืนยันซ้ำ ${l.confirmedByRuns.length} ครั้ง] ${l.lesson}`,
      source: "learning:validated_lesson",
      verified: false,
    }));
  } catch {
    return [];
  }
}
