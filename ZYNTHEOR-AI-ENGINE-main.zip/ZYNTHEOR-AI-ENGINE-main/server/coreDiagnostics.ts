/**
 * Core Connection Diagnostics: Frontend -> Core API -> Local Runtime -> Model -> Inference.
 *
 * Every stage reports PASS / FAIL / UNKNOWN / NOT_TESTED with the evidence that was actually observed
 * (HTTP status, error code, latency). Nothing is estimated, mocked or inferred from a neighbouring stage.
 * Local only: this module never contacts a hosted provider and never picks a model on the user's behalf.
 */

export type StageStatus = 'PASS' | 'FAIL' | 'UNKNOWN' | 'NOT_TESTED';

export interface DiagnosticStage {
  id: 'core_api' | 'provider_routing' | 'runtime_reachable' | 'model_present' | 'inference';
  label: string;
  status: StageStatus;
  code: string | null;
  evidence: string;
  latencyMs: number | null;
}

export interface CoreDiagnosticsReport {
  generatedAt: string;
  endpoint: string;
  runtimeKind: 'ollama' | 'openai-compatible' | null;
  models: string[];
  overall: 'PASS' | 'FAIL' | 'PARTIAL';
  firstFailure: DiagnosticStage['id'] | null;
  stages: DiagnosticStage[];
}

export interface CoreDiagnosticsOptions {
  endpoint: string;
  /** Model named in configuration (LOCAL_AI_MODEL / LOCAL_MODEL_NAME). */
  configuredModel?: string;
  /** Model the caller explicitly asked to test. Must be one the runtime reports. */
  requestedModel?: string;
  /** Run a real, tiny inference. Off by default because it loads the model. */
  infer?: boolean;
  aiProvider?: string;
  timeoutMs?: number;
  inferTimeoutMs?: number;
}

interface Attempt {
  path: string;
  ok: boolean;
  httpStatus: number | null;
  errorCode: string | null;
  latencyMs: number;
  json?: any;
}

export function classifyFetchError(err: any): string {
  const name = err?.name;
  if (name === 'AbortError' || name === 'TimeoutError') return 'TIMEOUT';
  const cause = err?.cause?.code || err?.code;
  if (typeof cause === 'string' && cause) return cause;
  return 'NETWORK_ERROR';
}

async function attempt(base: string, path: string, timeoutMs: number, init?: RequestInit): Promise<Attempt> {
  const started = Date.now();
  try {
    const res = await fetch(`${base}${path}`, { ...init, signal: AbortSignal.timeout(timeoutMs) });
    const latencyMs = Date.now() - started;
    if (!res.ok) return { path, ok: false, httpStatus: res.status, errorCode: `HTTP_${res.status}`, latencyMs };
    let json: any;
    try { json = await res.json(); } catch { return { path, ok: false, httpStatus: res.status, errorCode: 'INVALID_JSON', latencyMs }; }
    return { path, ok: true, httpStatus: res.status, errorCode: null, latencyMs, json };
  } catch (err) {
    return { path, ok: false, httpStatus: null, errorCode: classifyFetchError(err), latencyMs: Date.now() - started };
  }
}

const describe = (a: Attempt) => `GET ${a.path} -> ${a.errorCode ?? `HTTP ${a.httpStatus}`} (${a.latencyMs}ms)`;

export async function runCoreDiagnostics(options: CoreDiagnosticsOptions): Promise<CoreDiagnosticsReport> {
  const base = options.endpoint.trim().replace(/\/+$/, '');
  const timeoutMs = options.timeoutMs ?? 2500;
  const stages: DiagnosticStage[] = [];
  let runtimeKind: CoreDiagnosticsReport['runtimeKind'] = null;
  let models: string[] = [];

  // 1. Core API: if this code is running, the request reached the Core.
  stages.push({
    id: 'core_api', label: 'Frontend → Core API', status: 'PASS', code: null,
    evidence: 'Core API handled this diagnostics request.', latencyMs: 0,
  });

  // 2. Provider routing (configuration only; no network).
  const provider = (options.aiProvider ?? '').trim().toLowerCase();
  if (provider === '' || provider === 'local') {
    stages.push({
      id: 'provider_routing', label: 'Core → Provider routing', status: 'PASS', code: null,
      evidence: provider === '' ? 'AI_PROVIDER unset: local runtime is the default.' : 'AI_PROVIDER=local.', latencyMs: null,
    });
  } else if (['none', 'off', 'disabled'].includes(provider)) {
    stages.push({
      id: 'provider_routing', label: 'Core → Provider routing', status: 'FAIL', code: 'provider_disabled',
      evidence: `AI_PROVIDER=${provider}: chat is disabled, so no request can reach the local model.`, latencyMs: null,
    });
  } else {
    stages.push({
      id: 'provider_routing', label: 'Core → Provider routing', status: 'FAIL', code: 'provider_not_local',
      evidence: `AI_PROVIDER=${provider}: not local. The Core does not route un-consented chat to an online provider.`, latencyMs: null,
    });
  }

  // 3. Local runtime reachable.
  const tags = await attempt(base, '/api/tags', timeoutMs, { headers: { Accept: 'application/json' } });
  let usedAttempts: Attempt[] = [tags];
  if (tags.ok) {
    runtimeKind = 'ollama';
    models = Array.isArray(tags.json?.models) ? tags.json.models.map((m: any) => String(m?.name ?? m?.model ?? '')).filter(Boolean) : [];
  } else {
    const v1 = await attempt(base, '/v1/models', timeoutMs, { headers: { Accept: 'application/json' } });
    usedAttempts = [tags, v1];
    if (v1.ok) {
      runtimeKind = 'openai-compatible';
      models = Array.isArray(v1.json?.data) ? v1.json.data.map((m: any) => String(m?.id ?? '')).filter(Boolean) : [];
    }
  }
  if (runtimeKind) {
    const ok = usedAttempts[usedAttempts.length - 1];
    stages.push({
      id: 'runtime_reachable', label: 'Core → Local Runtime', status: 'PASS', code: null,
      evidence: `${runtimeKind} runtime answered at ${base}. ${describe(ok)}`, latencyMs: ok.latencyMs,
    });
  } else {
    const responded = usedAttempts.find((a) => a.httpStatus !== null);
    const code = (responded ?? usedAttempts[0]).errorCode ?? 'NETWORK_ERROR';
    stages.push({
      id: 'runtime_reachable', label: 'Core → Local Runtime', status: 'FAIL', code,
      evidence: `No runtime answered at ${base}. ${usedAttempts.map(describe).join('; ')}`,
      latencyMs: usedAttempts.reduce((sum, a) => sum + a.latencyMs, 0),
    });
  }

  // 4. Model present.
  if (!runtimeKind) {
    stages.push({ id: 'model_present', label: 'Local Runtime → Model', status: 'NOT_TESTED', code: null,
      evidence: 'Not tested: the runtime is unreachable.', latencyMs: null });
  } else if (models.length === 0) {
    stages.push({ id: 'model_present', label: 'Local Runtime → Model', status: 'FAIL', code: 'NO_MODELS',
      evidence: 'The runtime is reachable but reports no installed models.', latencyMs: null });
  } else if (options.configuredModel && !models.includes(options.configuredModel)) {
    stages.push({ id: 'model_present', label: 'Local Runtime → Model', status: 'FAIL', code: 'CONFIGURED_MODEL_MISSING',
      evidence: `Configured model "${options.configuredModel}" is not installed. Installed: ${models.join(', ')}.`, latencyMs: null });
  } else {
    stages.push({ id: 'model_present', label: 'Local Runtime → Model', status: 'PASS', code: null,
      evidence: `${models.length} model(s) installed: ${models.join(', ')}.`, latencyMs: null });
  }

  // 5. Real inference (opt-in).
  const modelStage = stages[stages.length - 1];
  const model = options.requestedModel || options.configuredModel || '';
  if (!options.infer) {
    stages.push({ id: 'inference', label: 'Model → Inference', status: 'NOT_TESTED', code: null,
      evidence: 'Inference test not requested.', latencyMs: null });
  } else if (modelStage.status !== 'PASS') {
    stages.push({ id: 'inference', label: 'Model → Inference', status: 'NOT_TESTED', code: null,
      evidence: 'Not tested: an earlier stage failed or was not tested.', latencyMs: null });
  } else if (!model) {
    stages.push({ id: 'inference', label: 'Model → Inference', status: 'NOT_TESTED', code: 'NO_MODEL_SELECTED',
      evidence: 'No model selected. The Core never picks a model silently; choose one to test.', latencyMs: null });
  } else if (!models.includes(model)) {
    stages.push({ id: 'inference', label: 'Model → Inference', status: 'FAIL', code: 'MODEL_NOT_INSTALLED',
      evidence: `Requested model "${model}" is not installed.`, latencyMs: null });
  } else {
    const inferTimeout = options.inferTimeoutMs ?? 30000;
    const init: RequestInit = { method: 'POST', headers: { 'Content-Type': 'application/json' } };
    const result = runtimeKind === 'ollama'
      ? await attempt(base, '/api/chat', inferTimeout, { ...init, body: JSON.stringify({
          model, stream: false, messages: [{ role: 'user', content: 'ping' }], options: { num_predict: 8 } }) })
      : await attempt(base, '/v1/chat/completions', inferTimeout, { ...init, body: JSON.stringify({
          model, stream: false, max_tokens: 8, messages: [{ role: 'user', content: 'ping' }] }) });
    const text = runtimeKind === 'ollama' ? result.json?.message?.content : result.json?.choices?.[0]?.message?.content;
    if (result.ok && typeof text === 'string' && text.trim().length > 0) {
      stages.push({ id: 'inference', label: 'Model → Inference', status: 'PASS', code: null,
        evidence: `Model "${model}" returned ${text.trim().length} character(s) in ${result.latencyMs}ms.`, latencyMs: result.latencyMs });
    } else if (result.ok) {
      stages.push({ id: 'inference', label: 'Model → Inference', status: 'FAIL', code: 'EMPTY_RESPONSE',
        evidence: `Model "${model}" answered HTTP ${result.httpStatus} with no text.`, latencyMs: result.latencyMs });
    } else {
      stages.push({ id: 'inference', label: 'Model → Inference', status: 'FAIL', code: result.errorCode ?? 'NETWORK_ERROR',
        evidence: `POST ${result.path} for "${model}" -> ${result.errorCode} (${result.latencyMs}ms).`, latencyMs: result.latencyMs });
    }
  }

  const failed = stages.find((s) => s.status === 'FAIL');
  const allPass = stages.every((s) => s.status === 'PASS');
  return {
    generatedAt: new Date().toISOString(),
    endpoint: base,
    runtimeKind,
    models,
    overall: failed ? 'FAIL' : allPass ? 'PASS' : 'PARTIAL',
    firstFailure: failed ? failed.id : null,
    stages,
  };
}
