/**
 * Decides whether /api/chat enters the reasoning / web-research workflow.
 *
 * - `auto` (and `reason`, `custom`, which keep their existing behaviour) may be routed by wording.
 * - An explicit mode the user picked is honoured: wording alone never pushes it into the reasoning workflow.
 *   Only the mode's own intent can: code/plan/explain/qa always reason; `web` honours web wording;
 *   `analysis` honours analysis wording; chat/files/tools/review never reason because of keywords.
 * Pure and deterministic, so the UI and the tests can both rely on it.
 */
export type ReasoningRouteSource = 'mode' | 'keyword' | 'none';

export interface ReasoningRoute {
  use: boolean;
  source: ReasoningRouteSource;
  /** What decided it (mode name or the matched wording); null when nothing did. */
  evidence: string | null;
}

const MODE_ALWAYS_REASONS = ['code', 'plan', 'explain', 'qa'];
/** Modes where wording may still decide, exactly as before this change. */
const MODE_ALLOWS_ANY_KEYWORD = ['auto', 'reason', 'custom'];

const GENERAL_KEYWORDS = [
  'วิเคราะห์', 'ตรวจ', 'syntax', 'build', 'test', 'แก้', 'หลักฐาน', 'อธิบายโค้ด', 'explain code',
  'verifyintegrity', 'agent.ts', 'อ่านโค้ด', 'หน้าที่ของ', 'การทำงานของ',
];
const WEB_KEYWORDS = ['ค้นเว็บ', 'ค้นหาข้อมูล', 'search the web', 'web search', 'research'];
const ANALYSIS_KEYWORDS = ['วิเคราะห์'];

function firstMatch(lower: string, words: string[]): string | null {
  return words.find((w) => lower.includes(w)) ?? null;
}

function webWording(trimmed: string, lower: string): string | null {
  const kw = firstMatch(lower, WEB_KEYWORDS);
  if (kw) return kw;
  if (trimmed.startsWith('/research')) return '/research';
  if (trimmed.startsWith('/web')) return '/web';
  if (/https?:\/\//i.test(trimmed)) return 'https://';
  return null;
}

/**
 * Whether the keyword task classifier (unsupported / needs-clarification / read-only gates) runs for this mode.
 * `chat` is plain conversation: wording such as "แก้", "test" or "bitcoin" must not turn it into a blocked task.
 * Every other mode keeps the classifier exactly as before.
 */
export function shouldClassifyTask(mode: string): boolean {
  return mode !== 'chat';
}

export function routeReasoning(mode: string, prompt: string): ReasoningRoute {
  const trimmed = (prompt ?? '').trim();
  const lower = trimmed.toLowerCase();

  if (MODE_ALWAYS_REASONS.includes(mode)) return { use: true, source: 'mode', evidence: mode };

  if (MODE_ALLOWS_ANY_KEYWORD.includes(mode)) {
    const hit = firstMatch(lower, GENERAL_KEYWORDS) ?? webWording(trimmed, lower);
    return hit ? { use: true, source: 'keyword', evidence: hit } : { use: false, source: 'none', evidence: null };
  }

  if (mode === 'web') {
    const hit = webWording(trimmed, lower);
    return hit ? { use: true, source: 'keyword', evidence: hit } : { use: false, source: 'none', evidence: null };
  }
  if (mode === 'analysis') {
    const hit = firstMatch(lower, ANALYSIS_KEYWORDS);
    return hit ? { use: true, source: 'keyword', evidence: hit } : { use: false, source: 'none', evidence: null };
  }
  // chat, files, tools, review and any other explicit mode: wording never switches the workflow.
  return { use: false, source: 'none', evidence: null };
}
