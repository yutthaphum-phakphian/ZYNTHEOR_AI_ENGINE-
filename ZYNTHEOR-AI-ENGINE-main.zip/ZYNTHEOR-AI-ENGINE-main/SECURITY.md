# Security Policy

## Reporting Security Issues

We take the security of Zyntheor AI Engine seriously. If you discover a vulnerability or security flaw, please report it privately:

- **Email**: `yuttaphumphakphian@gmail.com`
- **Response Time**: We acknowledge reports within 48 hours and provide remediation status updates.

Please do not disclose security issues publicly until a fix has been verified and released.

---

## Core Security Commitments

### 1. Zero Phantom Execution
- The agent does not execute side-effecting tools or modify files without explicit human approval.
- High-risk operations require a single-use cryptographic approval ID matched to the exact SHA-256 hash of the plan.

### 2. Strict Read-Only Boundaries
- External connectors (such as the GitHub Client) operate on read-only endpoints (`get_repo`, `list_issues`, `get_file`, `get_readme`).
- Path traversal sequences (`..`), null bytes, and non-alphanumeric repository identifiers are strictly blocked before any network request is issued.
- OAuth credentials and user-provided GitHub tokens are maintained securely in client storage and session authorization headers; tokens are never logged or exposed.

### 3. Automated Secret Redaction
- API keys (`OPENAI_API_KEY`, `GITHUB_TOKEN`, Bearer tokens, passwords) are automatically redacted using regular expression sanitization before being saved to storage, emitted in audit events, or read aloud by the Text-to-Speech (TTS) engine.

### 4. Sandbox Isolation
- Code inspection and syntax checks run inside isolated child processes with memory limits, strict execution timeouts, and network namespace isolation where supported.

### 5. Network Exposure and API Authentication
- The server listens on `127.0.0.1` by default. Exposing it to a network is an explicit choice (`HOST=0.0.0.0` or `--host`).
- Only `/api/files`, `/api/proposals`, `/api/checkpoints` and `/api/self-improvement` require the `APPHUB_AUTH_TOKEN` bearer token by default.
- Set `APPHUB_REQUIRE_AUTH=1` to require the token on every `/api` route except `/api/health`. The guard fails closed (HTTP 503) if no valid token (32+ characters) is configured. The bundled web UI does not send this token yet, so use strict mode for API/server-to-server use until UI support is added.
- There is a single shared token and no per-user identity: data is not separated between users. Do not expose a deployment to untrusted users.

### 6. Local Runtime Endpoints
- A request may name the local runtime it wants (`endpoint` / `localEndpoint`) only if it is a loopback address or the host configured in `LOCAL_AI_ENDPOINT` / `LOCAL_MODEL_URL`. Anything else is rejected with `local_endpoint_not_allowed`; it is never replaced silently.
