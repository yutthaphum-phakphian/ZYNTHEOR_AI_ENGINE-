const $ = (id) => document.getElementById(id);
const messages = $("messages");
const form = $("form");
const prompt = $("prompt");
const send = $("send");
const notice = $("notice");
const authForm = $("auth-form");
const authTokenInput = $("auth-token");
const currentFileName = $("current-file-name");
const codeContent = $("code-content");
const codeFileSelect = $("code-file-select");
const plansList = $("plans-list");
const auditList = $("audit-list");
const tokenStatusDisplay = $("token-status-display");
const fileUploadInput = $("file-upload-input");
const zipUploadInput = $("zip-upload-input");
const fileMetaBanner = $("file-meta-banner");
const metaFileName = $("meta-file-name");
const metaFileSize = $("meta-file-size");
const metaFileType = $("meta-file-type");
const metaFileStatus = $("meta-file-status");
const fileBadgeMode = $("file-badge-mode");
const zipExplorer = $("zip-explorer");
const zipFileTree = $("zip-file-tree");
const zipArchiveName = $("zip-archive-name");
const zipEntryCount = $("zip-entry-count");
const closeZipBtn = $("close-zip-btn");
const analyzeExplainBtn = $("analyze-explain-btn");
const analyzeBugsBtn = $("analyze-bugs-btn");
const analyzeRefactorBtn = $("analyze-refactor-btn");
const copyCodeBtn = $("copy-code-btn");
const copyCodeText = $("copy-code-text");
const langToggleBtn = $("lang-toggle");
const langLabel = $("lang-label");
const exportChatBtn = $("export-chat-btn");
const attachedFileBadge = $("attached-file-badge");
const attachedFileName = $("attached-file-name");
const removeAttachmentBtn = $("remove-attachment-btn");
const planModeBtn = $("plan-mode-btn");
const attachFileShortcut = $("attach-file-shortcut");
const charCounter = $("char-counter");
const sessionIdDisplay = $("session-id-display");
const sessionTimeDisplay = $("session-time-display");

const attachFileBtn = $("attach-file-btn");
const composerFileInput = $("composer-file-input");
const attachedFilesTray = $("attached-files-tray");
const modeBtn = $("mode-btn");
const modeEmoji = $("mode-emoji");
const modeName = $("mode-name");
const micBtn = $("mic-btn");
const listeningBar = $("listening-bar");
const waveformCanvas = $("voice-waveform-canvas");
const voiceCancelBtn = $("voice-cancel-btn");
const modeModalBackdrop = $("mode-modal-backdrop");
const modeModalClose = $("mode-modal-close");
const modeOptions = document.querySelectorAll(".mode-option");

const attachmentModalBackdrop = $("attachment-modal-backdrop");
const attachmentModalClose = $("attachment-modal-close");

const autoScrollToggleBtn = $("auto-scroll-toggle-btn");
const autoScrollBadge = $("auto-scroll-state-badge");
const jumpToBottomBtn = $("jump-to-bottom-btn");
let autoScrollEnabled = true;
let isProgrammaticScroll = false;
const attachmentModalRemoveBtn = $("attachment-modal-remove-btn");
const attachmentModalIcon = $("attachment-modal-icon");
const attachmentModalTitle = $("attachment-modal-title");
const attachmentModalMeta = $("attachment-modal-meta");
const attachmentModalBody = $("attachment-modal-body");

const sessionSearchInput = $("session-search-input");
const sessionSearchClear = $("session-search-clear");
const savedSessionsList = $("saved-sessions-list");
const newSessionMiniBtn = $("new-session-mini-btn");

const workspaceEl = document.querySelector(".workspace");
const sidebarEl = $("sidebar");
const sidebarToggleBtn = $("sidebar-toggle");
const sidebarCloseBtn = $("sidebar-close-btn");
const sidebarOverlay = $("sidebar-overlay");

// Bilingual i18n Dictionary
const translations = {
  en: {
    brand_subtitle: "AI DEV ENGINE",
    workspace_nav: "WORKSPACE MODULES",
    nav_assistant: "Assistant & Chat",
    nav_code: "Code & File Studio",
    nav_plans: "Plans & Tasks",
    nav_audit: "Audit & Ledger",
    nav_settings: "System Settings",
    stat_active_session: "Active Session",
    sidebar_note: "Disciplined AI Dev<br>Audited execution",
    menu_btn: "Menu",
    breadcrumb_ws: "Workspace",
    export_btn: "Export",
    token_btn: "Token",
    new_session_btn: "New Session",
    assistant_eyebrow: "ZYNTHEOR INTELLIGENCE ENGINE",
    assistant_title: "AI Development Studio",
    assistant_subtitle: "Converse with Zyntheor to design architecture, write code, debug issues, inspect files, or execute audited task plans.",
    cmd_plan_time: "/plan time",
    cmd_plan_app: "/plan app",
    cmd_explain_arch: "Explain architecture",
    cmd_review_th: "Code Review & Refactor",
    welcome_title: "Ready for development instructions",
    welcome_subtitle: "Ask technical questions, request code implementations, inspect repository files, or submit /plan <goal> for verified execution.",
    starter_time_title: "Verified Plan Execution",
    starter_time_desc: "Run /plan time with cryptographic approval and evidence.",
    starter_arch_title: "Security & Architecture",
    starter_arch_desc: "Learn how Zyntheor guards against phantom executions.",
    starter_code_title: "Code Engineering",
    starter_code_desc: "Generate production-ready code with complete typings.",
    plan_mode_label: "Plan Mode",
    attach_file_label: "Attach File",
    composer_hint: "Enter to send · Shift + Enter for newline · /plan for task plans",
    send_btn: "Send",
    trust_note: "Cryptographic plan hashes and explicit single-use approval gates enforce safe code execution. Zero fabricated actions.",
    code_eyebrow: "CODEBASE INSPECTION & ANALYSIS",
    code_title: "Code & Diff Studio",
    code_subtitle: "Inspect codebase files, upload local files or ZIP archives for inspection, and analyze real code with AI.",
    open_file_btn: "Open File",
    open_zip_btn: "Open ZIP Archive",
    explain_code_btn: "Explain Code",
    inspect_bugs_btn: "Inspect Bugs",
    suggest_fixes_btn: "Suggest Fixes",
    meta_file_name_label: "File Name:",
    meta_file_size_label: "Size:",
    meta_file_type_label: "Type:",
    meta_file_status_label: "Status:",
    copy_btn: "Copy",
    plans_eyebrow: "AUDITED LIFECYCLE MANAGEMENT",
    plans_title: "Plans & Execution Tasks",
    plans_subtitle: "Active and past execution plans, single-use cryptographic authorizations, and outcome verifications.",
    refresh_plans_btn: "Refresh plans",
    audit_eyebrow: "TAMPER-RESISTANT LOGS",
    audit_title: "Cryptographic Audit Ledger",
    audit_subtitle: "Persisted ledger events, redacted authorization records, and verified execution proofs.",
    refresh_audit_btn: "Refresh audit",
    settings_eyebrow: "RUNTIME CONFIGURATION",
    settings_title: "Workspace & Assistant Settings",
    settings_subtitle: "Inspect backend parameters, provider settings, security tokens, and language preferences.",
    settings_identity_title: "AI Assistant Identity",
    settings_security_title: "Security & Bearer Token",
    settings_storage_title: "Storage & Ledger",
    settings_change_token_btn: "Change Workspace Token",
    footer_motto: "Verified plans · Cryptographic audits · Zero fabricated execution",
    auth_required_title: "Workspace Access Token Required",
    auth_required_desc: "Server security requires a bearer token (configured in APPHUB_AUTH_TOKEN, min 32 chars). Enter it once to unlock this session.",
    auth_unlock_btn: "Unlock Session"
  },
  th: {
    brand_subtitle: "ระบบเอไอวิศวกรรมซอฟต์แวร์",
    workspace_nav: "โมดูลการทำงาน",
    nav_assistant: "ผู้ช่วยแชทอัจฉริยะ",
    nav_code: "สตูดิโอโค้ด & ตรวจไฟล์",
    nav_plans: "แผนงาน & ภารกิจที่ตรวจสอบ",
    nav_audit: "สมุดบันทึกหลักฐานตรวจสอบ",
    nav_settings: "การตั้งค่าระบบ",
    stat_active_session: "เซสชันที่ใช้งานอยู่",
    sidebar_note: "พัฒนาซอฟต์แวร์อย่างมีวินัย<br>ตรวจสอบหลักฐานทุกขั้นตอน",
    menu_btn: "เมนู",
    breadcrumb_ws: "พื้นที่ทำงาน",
    export_btn: "ส่งออกแชท",
    token_btn: "โทเค็น",
    new_session_btn: "เริ่มเซสชันใหม่",
    assistant_eyebrow: "ระบบประมวลผลอัจฉริยะ ZYNTHEOR",
    assistant_title: "สตูดิโอพัฒนาด้วย AI (Zyntheor)",
    assistant_subtitle: "สนทนากับ Zyntheor เพื่อออกแบบสถาปัตยกรรม เขียนโค้ด ดีบักปัญหา ตรวจสอบไฟล์ในโปรเจกต์ หรือสั่ง /plan เพื่อสร้างแผนงานที่มีหลักฐานยืนยัน",
    cmd_plan_time: "/plan time",
    cmd_plan_app: "/plan app",
    cmd_explain_arch: "อธิบายโครงสร้างระบบ",
    cmd_review_th: "ตรวจโค้ด & ปรับปรุง",
    welcome_title: "พร้อมรับคำสั่งพัฒนาซอฟต์แวร์",
    welcome_subtitle: "สอบถามเชิงเทคนิค สั่งเขียนโค้ดและแก้บั๊ก ตรวจสอบไฟล์ หรือสั่ง /plan <เป้าหมาย> เพื่อสร้างแผนงานที่ตรวจสอบความถูกต้องด้วย Cryptographic Hash",
    starter_time_title: "การทดสอบแผนงานพร้อมหลักฐาน",
    starter_time_desc: "รันคำสั่ง /plan time เพื่อทดสอบระบบยืนยันอนุมัติแบบ Single-use",
    starter_arch_title: "สถาปัตยกรรมและความปลอดภัย",
    starter_arch_desc: "ดูวิธีที่ Zyntheor ป้องกันการกระทำหลอกลวง (Zero phantom execution)",
    starter_code_title: "การเขียนโค้ดระดับ Production",
    starter_code_desc: "สร้างฟังก์ชัน TypeScript พร้อม Type-safe และ Error Handling ครบถ้วน",
    plan_mode_label: "โหมดแผนงาน",
    attach_file_label: "แนบไฟล์โค้ด",
    composer_hint: "Enter เพื่อส่ง · Shift + Enter ขึ้นบรรทัดใหม่ · ใช้ /plan เพื่อสร้างแผนงาน",
    send_btn: "ส่งข้อความ",
    trust_note: "ควบคุมความปลอดภัยด้วย SHA-256 Plan Hash และการอนุมัติแบบใช้ครั้งเดียว ห้ามทำงานโดยไม่มีผลลัพธ์จริง",
    code_eyebrow: "การตรวจสอบและวิเคราะห์โค้ด",
    code_title: "สตูดิโอตรวจสอบโค้ด & ZIP",
    code_subtitle: "เปิดอ่านโค้ดในระบบ อัปโหลดไฟล์ข้อความหรือ ZIP โปรเจกต์เพื่อตรวจสอบโครงสร้าง และส่งให้ AI วิเคราะห์",
    open_file_btn: "เปิดไฟล์เดี่ยว",
    open_zip_btn: "เปิดไฟล์ ZIP",
    explain_code_btn: "อธิบายโค้ด",
    inspect_bugs_btn: "ตรวจหาบั๊ก",
    suggest_fixes_btn: "เสนอวิธีแก้",
    meta_file_name_label: "ชื่อไฟล์:",
    meta_file_size_label: "ขนาด:",
    meta_file_type_label: "ประเภท:",
    meta_file_status_label: "สถานะ:",
    copy_btn: "คัดลอก",
    plans_eyebrow: "การจัดการวงจรชีวิตแผนงาน",
    plans_title: "แผนงาน & ภารกิจที่ตรวจสอบ",
    plans_subtitle: "แสดงแผนงานที่ถูกเสนอ สถานะการอนุมัติด้วย Hash และผลการตรวจสอบความสำเร็จของแต่ละขั้นตอน",
    refresh_plans_btn: "รีเฟรชแผนงาน",
    audit_eyebrow: "บันทึกหลักฐานป้องกันการแก้ไข",
    audit_title: "สมุดบันทึกตรวจสอบ (Cryptographic Ledger)",
    audit_subtitle: "ประวัติเหตุการณ์ที่บันทึกลง JSONL พร้อมเซ็นเซอร์ข้อมูลลับ และหลักฐานยืนยันความถูกต้อง",
    refresh_audit_btn: "รีเฟรชประวัติ",
    settings_eyebrow: "การกำหนดค่าระบบ",
    settings_title: "การตั้งค่าพื้นที่ทำงานและผู้ช่วย",
    settings_subtitle: "ตรวจสอบพารามิเตอร์ backend ผู้ให้บริการ AI โทเค็นความปลอดภัย และภาษาที่ใช้งาน",
    settings_identity_title: "ข้อมูลตัวตนของ AI Assistant",
    settings_security_title: "ความปลอดภัย & Bearer Token",
    settings_storage_title: "การจัดเก็บ & บันทึกตรวจสอบ",
    settings_change_token_btn: "เปลี่ยนโทเค็นพื้นที่ทำงาน",
    footer_motto: "แผนงานยืนยันผลจริง · ตรวจสอบด้วย Cryptographic Hash · ไม่มีการสร้างผลลัพธ์หลอก",
    auth_required_title: "จำเป็นต้องระบุ Workspace Access Token",
    auth_required_desc: "ระบบต้องการ Bearer Token (กำหนดใน APPHUB_AUTH_TOKEN ความยาวอย่างน้อย 32 ตัวอักษร) ป้อนเพื่อปลดล็อกเซสชัน",
    auth_unlock_btn: "ปลดล็อกเซสชัน"
  }
};

let currentLanguage = localStorage.getItem("zyntheor.language") || "en";

function applyLanguage(lang) {
  currentLanguage = lang;
  localStorage.setItem("zyntheor.language", lang);
  if (langLabel) langLabel.textContent = lang === "en" ? "TH" : "EN";

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (translations[lang] && translations[lang][key]) {
      el.innerHTML = translations[lang][key];
    }
  });

  if (prompt) {
    prompt.placeholder = lang === "th"
      ? "พิมพ์ข้อความสอบถาม Zyntheor ขอให้เขียนโค้ด ดีบัก หรือพิมพ์ /plan เพื่อวางแผนงาน…"
      : "Ask Zyntheor to write code, debug, or /plan your project…";
  }

  if (typeof updateModeUI === "function") {
    updateModeUI(currentMode);
  }
}

if (langToggleBtn) {
  langToggleBtn.addEventListener("click", () => {
    applyLanguage(currentLanguage === "en" ? "th" : "en");
  });
}

let currentInspectedFile = {
  name: "server/agent.ts",
  size: 30462,
  mimeType: "text/typescript",
  extension: ".ts",
  status: "READ_SUCCESS",
  content: ""
};
let currentZipEntries = [];
let attachedFileContext = null;

let conversationId = localStorage.getItem("zyntheor.conversationId") || crypto.randomUUID().replaceAll("-", "");
let authToken = localStorage.getItem("zyntheor.authToken") || "";
let isDesktopCollapsed = localStorage.getItem("zyntheor.sidebarCollapsed") === "true";
localStorage.setItem("zyntheor.conversationId", conversationId);

function updateSessionDisplay() {
  if (sessionIdDisplay) {
    sessionIdDisplay.textContent = `ID: ${conversationId.slice(0, 8)}…`;
  }
  if (sessionTimeDisplay) {
    sessionTimeDisplay.textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
}
updateSessionDisplay();

// Pre-loaded real files for the Code & Diff inspector
const codebaseSnippets = {
  "server/agent.ts": `// server/agent.ts (Plan Engine & Verification Contract)
export type PlanStatus = "PROPOSED" | "WAITING_APPROVAL" | "APPROVED" | "RUNNING" | "SUCCEEDED" | "FAILED" | "BLOCKED" | "UNKNOWN";
export type StepOutcome = "SUCCESS" | "FAIL" | "UNKNOWN" | "UNAVAILABLE" | "NOT_RUN";

// Cryptographic plan hashing enforces tamper-evident approvals:
export function computePlanHash(draft: PlanDraft): string {
  return createHash("sha256").update(JSON.stringify(draft)).digest("hex");
}

// Single-use approval verification ensures no replay execution:
export async function approvePlan(planId: string, planHash: string): Promise<Plan> {
  const plan = await getPlan(planId);
  if (plan.hash !== planHash) throw new AgentError("approval_mismatch", "Plan hash changed.");
  // Persisted into append-only JSONL ledger...
}`,
  "server/provider.ts": `// server/provider.ts (AI Provider Client & Prompt Constraints)
// Prompts force planner to act purely as a planner without phantom executions:
export async function generatePlanProposal(goal: string, tools: ToolDefinition[], context: Message[] = []): Promise<ProviderResult> {
  return generateText([
    "You are a planner only. Propose a plan and do not call tools, execute actions, or claim work is complete.",
    "Return one JSON object only, with exactly: { goal, riskLevel, successCriteria, steps }",
    "Use only tools with availability AVAILABLE from the registered tool catalog."
  ].join("\\n"), context);
}`,
  "server/store.ts": `// server/store.ts (Process-Locked JSONL Ledger Storage)
// Enforces lock coordination and strict secret redaction before writing:
export function redactSecrets(value: string): string {
  return value
    .replace(/\\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})\\b/gi, "[REDACTED]")
    .replace(/\\b(([A-Z0-9_]*?(?:api[_-]?key|access[_-]?token|secret))\\s*[:=]\\s*)[^\\s,;]+/gi, "$1[REDACTED]")
    .replace(/\\bBearer\\s+[A-Za-z0-9._~+/-]+=*/gi, "Bearer [REDACTED]");
}`,
  "server/index.ts": `// server/index.ts (Express Gateway & Security Enforcement)
app.use("/api", (request, response, next) => {
  const configuredToken = process.env.APPHUB_AUTH_TOKEN;
  if (!configuredToken) return response.status(503).json({ status: "unavailable", code: "auth_not_configured" });
  
  // Timing-safe constant-time authentication prevents side-channel token leaks:
  const equal = candidateBytes.length === expectedBytes.length && timingSafeEqual(candidateBytes, expectedBytes);
  if (!equal) return response.status(401).json({ status: "blocked", code: "authentication_required" });
  next();
});`,
  "server/files.ts": `// server/files.ts (File Access, Inspection & Safe ZIP Parser)
// Guard: 1MB file limit, 10MB uncompressed limit, ZIP bomb & path traversal protection.
export function inspectFile(filename: string, buffer: Buffer): InspectedFile {
  if (isBlockedFilename(filename)) return { status: "BLOCKED", statusMessage: "Sensitive pattern blocked." };
  if (isExecutableExtension(ext)) return { status: "BLOCKED", statusMessage: "Executable binary blocked." };
  // Decodes UTF-8 text and redacts secrets safely...
}`,
  "public/app.js": `// public/app.js (Zyntheor Frontend Controller)
// Fully integrated with backend plan lifecycle and verification states:
// Supports: /plan, /code, chat, task execution, SHA-256 verification display.`
};

async function apiFetch(input, init = {}) {
  const headers = new Headers(init.headers);
  if (authToken) headers.set("Authorization", `Bearer ${authToken}`);
  const response = await fetch(input, { ...init, headers });
  if (response.status === 401 && authForm) {
    authForm.hidden = false;
    showNotice(currentLanguage === "th" ? "จำเป็นต้องใช้โทเค็น: ป้อนโทเค็นเพื่อใช้งาน" : "Authentication required: Enter workspace token to proceed.");
    if (tokenStatusDisplay) tokenStatusDisplay.textContent = "Authentication required (401)";
  }
  return response;
}

function showNotice(text) {
  if (!notice) return;
  notice.textContent = text;
  notice.hidden = !text;
}

function renderMarkdownText(text) {
  const container = document.createElement("div");
  container.className = "message-body";

  const lines = text.split("\n");
  let inCodeBlock = false;
  let codeBlockLang = "";
  let codeBlockLines = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (line.startsWith("```")) {
      if (inCodeBlock) {
        // End of code block
        const codeText = codeBlockLines.join("\n");
        const wrapper = document.createElement("div");
        wrapper.className = "code-block-wrapper";

        const header = document.createElement("div");
        header.className = "code-block-header";
        header.innerHTML = `<span>${escapeHtml(codeBlockLang || "code")}</span>`;

        const copyBtn = document.createElement("button");
        copyBtn.className = "message-copy-btn";
        copyBtn.type = "button";
        copyBtn.textContent = currentLanguage === "th" ? "คัดลอก" : "Copy";
        copyBtn.addEventListener("click", () => {
          navigator.clipboard.writeText(codeText);
          copyBtn.textContent = currentLanguage === "th" ? "คัดลอกแล้ว!" : "Copied!";
          setTimeout(() => {
            copyBtn.textContent = currentLanguage === "th" ? "คัดลอก" : "Copy";
          }, 2000);
        });
        header.append(copyBtn);
        wrapper.append(header);

        const pre = document.createElement("pre");
        const code = document.createElement("code");
        code.textContent = codeText;
        pre.append(code);
        wrapper.append(pre);

        container.append(wrapper);
        inCodeBlock = false;
        codeBlockLines = [];
        codeBlockLang = "";
      } else {
        // Start of code block
        inCodeBlock = true;
        codeBlockLang = line.slice(3).trim();
        codeBlockLines = [];
      }
      continue;
    }

    if (inCodeBlock) {
      codeBlockLines.push(line);
      continue;
    }

    if (!line.trim()) {
      continue;
    }

    const p = document.createElement("p");
    p.innerHTML = formatInlineMarkdown(line);
    container.append(p);
  }

  // Handle unclosed code block safely
  if (inCodeBlock) {
    const pre = document.createElement("pre");
    const code = document.createElement("code");
    code.textContent = codeBlockLines.join("\n");
    pre.append(code);
    container.append(pre);
  }

  return container;
}

function formatInlineMarkdown(text) {
  let safe = escapeHtml(text);
  // Inline code: `code`
  safe = safe.replace(/`([^`]+)`/g, "<code>$1</code>");
  // Bold: **text**
  safe = safe.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  // Italic: *text*
  safe = safe.replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, "<em>$1</em>");
  return safe;
}

// ==========================================
// Web Speech API Voice Engine & Settings
// ==========================================
const VOICE_STORAGE_KEY = "zyntheor_voice_settings";

let appVoiceSettings = {
  enabled: true,
  autoReadResponses: false,
  autoReadMode: "summary", // "summary" | "full"
  speakingRate: 1.0, // 0.75, 1.0, 1.25, 1.5, 2.0
  pitch: 1.0,
  volume: 1.0,
  alertOnBlockedOrApproval: true,
};

let lastSpokenText = "";
let lastSpokenTime = 0;

function loadVoiceSettings() {
  try {
    const raw = localStorage.getItem(VOICE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      appVoiceSettings = { ...appVoiceSettings, ...parsed };
    }
  } catch (e) {
    console.warn("Failed to load voice settings:", e);
  }
}

function saveVoiceSettingsToStorage() {
  try {
    localStorage.setItem(VOICE_STORAGE_KEY, JSON.stringify(appVoiceSettings));
    updateVoiceSettingsUI();
  } catch (e) {
    console.warn("Failed to save voice settings:", e);
  }
}

function redactSecretsForSpeech(value) {
  if (!value) return "";
  return value
    .replace(/\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16})\b/gi, "ข้อมูลลับที่ถูกปกปิด")
    .replace(/\b(([A-Z0-9_]*?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|secret))\s*[:=]\s*)[^\s,;]+/gi, "$1ข้อมูลลับ")
    .replace(/\bBearer\s+[A-Za-z0-9._~+/-]+=*/gi, "Bearer โทเค็นความปลอดภัย");
}

function cleanTextForSpeech(text) {
  if (!text) return "";
  const sanitized = redactSecretsForSpeech(text);
  return sanitized
    .replace(/```[\s\S]*?```/g, "บล็อกโค้ดตัวอย่าง")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/[*_~#>-]/g, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

function speakText(text, isSummary = false, force = false) {
  if (!("speechSynthesis" in window)) return;
  if (!appVoiceSettings.enabled && !force) return;

  const cleaned = cleanTextForSpeech(text);
  if (!cleaned) return;

  const now = Date.now();
  if (!force && cleaned === lastSpokenText && now - lastSpokenTime < 3500) {
    return;
  }
  lastSpokenText = cleaned;
  lastSpokenTime = now;

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(cleaned);
  const isThai = /[\u0E00-\u0E7F]/.test(cleaned);
  utterance.lang = isThai ? "th-TH" : "en-US";
  utterance.rate = Number(appVoiceSettings.speakingRate) || 1.0;
  utterance.pitch = Number(appVoiceSettings.pitch) || 1.0;
  utterance.volume = Number(appVoiceSettings.volume) || 1.0;

  const voices = window.speechSynthesis.getVoices();
  const targetVoice = voices.find((v) =>
    isThai ? v.lang.toLowerCase().startsWith("th") || v.name.toLowerCase().includes("thai") : v.lang.toLowerCase().startsWith("en")
  );
  if (targetVoice) utterance.voice = targetVoice;

  window.speechSynthesis.speak(utterance);
}

function speakStatusAnnouncement(status) {
  if (!("speechSynthesis" in window) || !appVoiceSettings.enabled || !appVoiceSettings.alertOnBlockedOrApproval) return;
  const messages = {
    WAITING_APPROVAL: "มีข้อเสนอที่รอการอนุมัติจากคุณก่อนลงมือทำครับ",
    BLOCKED: "คำสั่งถูกระงับเนื่องจากนโยบายความปลอดภัยครับ",
    FAIL: "การตรวจสอบพบข้อผิดพลาด กรุณาตรวจสอบรายละเอียดครับ",
    VERIFIED: "การตรวจสอบเสร็จสิ้น ยืนยันผลสำเร็จแล้วครับ"
  };
  const msg = messages[status];
  if (msg) {
    speakText(msg, true, true);
  }
}

function updateVoiceSettingsUI() {
  const statusEl = $("voice-engine-status");
  const modeEl = $("voice-read-mode-display");
  const rateEl = $("voice-rate-display");
  const alertEl = $("voice-alerts-display");
  const autoBtn = $("toggle-voice-auto-btn");
  const modeBtn = $("toggle-voice-mode-btn");
  const rateBtn = $("voice-rate-btn");

  if (statusEl) {
    statusEl.textContent = appVoiceSettings.enabled
      ? (appVoiceSettings.autoReadResponses ? "Active (Auto-read On)" : "Active (Auto-read Off)")
      : "Disabled";
  }
  if (modeEl) {
    modeEl.textContent = appVoiceSettings.autoReadMode === "summary" ? "Summary First" : "Full Response";
  }
  if (rateEl) {
    rateEl.textContent = `${appVoiceSettings.speakingRate}x`;
  }
  if (alertEl) {
    alertEl.textContent = appVoiceSettings.alertOnBlockedOrApproval ? "Enabled (WAITING_APPROVAL, BLOCKED)" : "Disabled";
  }
  if (autoBtn) {
    autoBtn.textContent = appVoiceSettings.autoReadResponses ? "Auto-read: ON" : "Auto-read: OFF";
  }
  if (modeBtn) {
    modeBtn.textContent = `Mode: ${appVoiceSettings.autoReadMode === "summary" ? "Summary" : "Full"}`;
  }
  if (rateBtn) {
    rateBtn.textContent = `Speed: ${appVoiceSettings.speakingRate}x`;
  }
}

function initVoiceSettings() {
  loadVoiceSettings();
  updateVoiceSettingsUI();

  const autoBtn = $("toggle-voice-auto-btn");
  const modeBtn = $("toggle-voice-mode-btn");
  const rateBtn = $("voice-rate-btn");
  const testBtn = $("voice-test-play-btn");

  if (autoBtn) {
    autoBtn.addEventListener("click", () => {
      appVoiceSettings.autoReadResponses = !appVoiceSettings.autoReadResponses;
      saveVoiceSettingsToStorage();
    });
  }

  if (modeBtn) {
    modeBtn.addEventListener("click", () => {
      appVoiceSettings.autoReadMode = appVoiceSettings.autoReadMode === "summary" ? "full" : "summary";
      saveVoiceSettingsToStorage();
    });
  }

  if (rateBtn) {
    rateBtn.addEventListener("click", () => {
      const rates = [0.75, 1.0, 1.25, 1.5];
      const currentIdx = rates.indexOf(appVoiceSettings.speakingRate);
      const nextRate = rates[(currentIdx + 1) % rates.length];
      appVoiceSettings.speakingRate = nextRate;
      saveVoiceSettingsToStorage();
    });
  }

  if (testBtn) {
    testBtn.addEventListener("click", () => {
      speakText("สวัสดีครับ ระบบเสียงภาษาไทย Zyntheor AI Brain Core พร้อมใช้งานแล้วครับ", false, true);
    });
  }
}

// Initialize on DOM load
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initVoiceSettings);
} else {
  initVoiceSettings();
}

function addMessage(message) {
  if (!messages) return;
  $("welcome-banner")?.remove();
  const element = document.createElement("article");
  element.className = `message ${message.role}`;

  if (message.role === "assistant") {
    element.append(renderMarkdownText(message.content));
  } else {
    const userText = document.createElement("div");
    userText.className = "message-body";
    userText.textContent = message.content;
    element.append(userText);
  }

  const meta = document.createElement("div");
  meta.className = "meta";

  const senderLabel = document.createElement("span");
  senderLabel.textContent = `${message.role === "user" ? (currentLanguage === "th" ? "คุณ" : "You") : "Zyntheor"} · ${new Date(message.createdAt || Date.now()).toLocaleTimeString()}`;
  meta.append(senderLabel);

  if (message.role === "assistant") {
    const actions = document.createElement("div");
    actions.className = "message-actions";

    const copyBtn = document.createElement("button");
    copyBtn.className = "message-copy-btn";
    copyBtn.type = "button";
    copyBtn.textContent = currentLanguage === "th" ? "คัดลอกข้อความ" : "Copy text";
    copyBtn.title = "Copy message to clipboard";
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(message.content);
      copyBtn.textContent = currentLanguage === "th" ? "คัดลอกแล้ว!" : "Copied!";
      setTimeout(() => {
        copyBtn.textContent = currentLanguage === "th" ? "คัดลอกข้อความ" : "Copy text";
      }, 2000);
    });

    const quoteBtn = document.createElement("button");
    quoteBtn.className = "message-copy-btn";
    quoteBtn.type = "button";
    quoteBtn.textContent = currentLanguage === "th" ? "อ้างอิง" : "Quote";
    quoteBtn.title = "Quote into composer";
    quoteBtn.addEventListener("click", () => {
      if (prompt) {
        prompt.value = `> ${message.content.slice(0, 200)}…\n\n`;
        prompt.focus();
        updateCharCounter();
      }
    });

    const speakBtn = document.createElement("button");
    speakBtn.className = "message-copy-btn";
    speakBtn.type = "button";
    speakBtn.textContent = currentLanguage === "th" ? "🔊 ฟัง" : "🔊 Listen";
    speakBtn.title = "Read message aloud";
    speakBtn.addEventListener("click", () => {
      speakText(message.content, false, true);
    });

    actions.append(quoteBtn, copyBtn, speakBtn);
    meta.append(actions);
  }

  element.append(meta);
  messages.append(element);
  if (autoScrollEnabled) {
    scrollToBottom();
  }

  // Auto-read response if enabled
  if (message.role === "assistant" && appVoiceSettings.enabled && appVoiceSettings.autoReadResponses) {
    const textToRead = appVoiceSettings.autoReadMode === "summary"
      ? (message.content.split("\n")[0] || message.content.slice(0, 150))
      : message.content;
    speakText(textToRead, appVoiceSettings.autoReadMode === "summary");
  }
}

function addPlan(plan) {
  if (!messages) return;
  $("welcome-banner")?.remove();
  const card = document.createElement("article");
  card.className = "message assistant plan-card";

  const title = document.createElement("strong");
  // Outcome string format strictly preserved for tests: outcome ${plan.outcome || "NOT_RUN"}
  title.textContent = `Plan · ${plan.status} · outcome ${plan.outcome || "NOT_RUN"}`;
  card.append(title);

  const summary = document.createElement("p");
  summary.textContent = `${plan.goal} · revision ${plan.revision}`;
  card.append(summary);

  const metadata = document.createElement("div");
  metadata.className = "plan-step";
  metadata.textContent = `Source: ${plan.source === "ai" ? "AI proposal" : "System-generated"} · Risk: ${plan.riskLevel} · Tools: ${(plan.requiredTools || []).join(", ") || "None"}`;
  card.append(metadata);

  if (Array.isArray(plan.successCriteria)) {
    for (const criterion of plan.successCriteria) {
      const criteriaEl = document.createElement("div");
      criteriaEl.className = "plan-evidence";
      criteriaEl.textContent = `Success Criteria: ${criterion}`;
      card.append(criteriaEl);
    }
  }

  const hash = document.createElement("div");
  hash.className = "meta";
  hash.textContent = `Plan ID: ${plan.id} · SHA-256: ${plan.hash}`;
  card.append(hash);

  if (Array.isArray(plan.steps)) {
    for (const step of plan.steps) {
      const row = document.createElement("div");
      row.className = "plan-step";
      // Outcome string format strictly preserved for tests: outcome ${step.outcome || "NOT_RUN"}
      row.textContent = `${step.id}: ${step.tool} · ${step.status} · outcome ${step.outcome || "NOT_RUN"} · depends on ${(step.dependsOn || []).join(", ") || "none"}`;
      card.append(row);

      if (step.verification) {
        const proof = document.createElement("div");
        proof.className = "plan-evidence";
        proof.textContent = `Verification ${step.verification.status}: ${step.verification.evidence}`;
        card.append(proof);
      }
      if (step.error) {
        const errorEl = document.createElement("div");
        errorEl.className = "plan-evidence";
        errorEl.textContent = `Error: ${step.error}`;
        card.append(errorEl);
      }
      if (step.result) {
        const output = document.createElement("div");
        output.className = "plan-evidence";
        output.textContent = `Tool Output: ${JSON.stringify(step.result.value || step.result)}`;
        card.append(output);
      }
    }
  }

  // Interactive Single-Use Lifecycle Buttons
  if (plan.status === "PROPOSED") {
    const actions = document.createElement("div");
    actions.className = "plan-actions";
    const submit = document.createElement("button");
    submit.className = "button button-send";
    submit.type = "button";
    submit.textContent = currentLanguage === "th" ? "ขอการอนุมัติ (Submit for Approval)" : "Submit for Approval";
    submit.addEventListener("click", () => void planAction(plan, "request-approval"));
    actions.append(submit);
    card.append(actions);
  } else if (plan.status === "WAITING_APPROVAL") {
    const actions = document.createElement("div");
    actions.className = "plan-actions";
    const approve = document.createElement("button");
    approve.className = "button button-send";
    approve.type = "button";
    approve.textContent = currentLanguage === "th" ? "อนุมัติแผนงาน (SHA-256)" : "Approve Plan (SHA-256)";
    approve.addEventListener("click", () => void planAction(plan, "approve"));
    const reject = document.createElement("button");
    reject.className = "button button-subtle";
    reject.type = "button";
    reject.textContent = currentLanguage === "th" ? "ปฏิเสธแผนงาน" : "Reject Plan";
    reject.addEventListener("click", () => void planAction(plan, "reject"));
    actions.append(approve, reject);
    card.append(actions);
  } else if (plan.status === "APPROVED" && plan.approval) {
    const actions = document.createElement("div");
    actions.className = "plan-actions";
    const execute = document.createElement("button");
    execute.className = "button button-send";
    execute.type = "button";
    execute.textContent = currentLanguage === "th" ? "รันแผนงานที่อนุมัติแล้ว" : "Run Approved Plan";
    execute.addEventListener("click", () => void planAction(plan, "execute"));
    actions.append(execute);
    card.append(actions);
  }

  messages.append(card);
  if (autoScrollEnabled) {
    scrollToBottom();
  }

  if (plan.status === "WAITING_APPROVAL") {
    speakStatusAnnouncement("WAITING_APPROVAL");
  } else if (plan.status === "BLOCKED") {
    speakStatusAnnouncement("BLOCKED");
  }
}

async function planAction(plan, action) {
  const buttons = messages ? messages.querySelectorAll(".plan-actions button") : [];
  buttons.forEach((button) => { button.disabled = true; });
  try {
    let response;
    if (action === "approve") {
      response = await apiFetch(`/api/plans/${encodeURIComponent(plan.id)}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planHash: plan.hash })
      });
    } else if (action === "request-approval") {
      response = await apiFetch(`/api/plans/${encodeURIComponent(plan.id)}/request-approval`, { method: "POST" });
    } else if (action === "reject") {
      response = await apiFetch(`/api/plans/${encodeURIComponent(plan.id)}/reject`, { method: "POST" });
    } else {
      response = await apiFetch(`/api/plans/${encodeURIComponent(plan.id)}/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ approvalId: plan.approval.id })
      });
    }
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || data.code || "Plan action failed.");
    const updated = data.plan;
    addMessage({
      role: "assistant",
      content: action === "request-approval" ? "Plan submitted for approval. Awaiting explicit confirmation."
        : action === "approve" ? `Approval recorded for SHA-256 hash ${updated.hash}. Authorization token created.`
        : action === "reject" ? "Plan rejected. Execution blocked."
          : `Plan execution completed with status ${updated.status}. Evidence verified below.`,
      createdAt: new Date().toISOString()
    });
    addPlan(updated);
    void loadPlansView();
  } catch (error) {
    showNotice(error instanceof Error ? error.message : "Plan action failed.");
    buttons.forEach((button) => { button.disabled = false; });
  }
}

function scrollToBottom(smooth = false) {
  if (!messages) return;
  isProgrammaticScroll = true;
  messages.scrollTo({
    top: messages.scrollHeight,
    behavior: smooth ? "smooth" : "auto",
  });
  setTimeout(() => {
    isProgrammaticScroll = false;
  }, 120);
}

function setAutoScroll(enabled) {
  autoScrollEnabled = enabled;
  if (autoScrollToggleBtn) {
    autoScrollToggleBtn.setAttribute("aria-pressed", String(enabled));
    autoScrollToggleBtn.title = `Auto-scroll: ${enabled ? "ON" : "OFF"}`;
    if (enabled) {
      autoScrollToggleBtn.classList.add("active");
    } else {
      autoScrollToggleBtn.classList.remove("active");
    }
  }
  if (autoScrollBadge) {
    autoScrollBadge.textContent = enabled ? "ON" : "OFF";
  }
  if (jumpToBottomBtn) {
    jumpToBottomBtn.hidden = enabled;
  }
}

if (messages) {
  messages.addEventListener("scroll", () => {
    if (isProgrammaticScroll) return;
    const distanceFromBottom = messages.scrollHeight - messages.scrollTop - messages.clientHeight;
    // When user manually scrolls up past 40px threshold, pause auto-scroll to preserve position
    if (distanceFromBottom > 40) {
      if (autoScrollEnabled) {
        setAutoScroll(false);
      }
    } else {
      // When user reaches near the bottom, re-enable auto-scroll
      if (!autoScrollEnabled) {
        setAutoScroll(true);
      }
    }
  });
}

if (autoScrollToggleBtn) {
  autoScrollToggleBtn.addEventListener("click", () => {
    const next = !autoScrollEnabled;
    setAutoScroll(next);
    if (next) {
      scrollToBottom(true);
    }
  });
}

if (jumpToBottomBtn) {
  jumpToBottomBtn.addEventListener("click", () => {
    setAutoScroll(true);
    scrollToBottom(true);
  });
}

function setServerStatus(text, state) {
  const statusEl = $("status");
  const indicatorEl = $("status-indicator");
  if (statusEl) statusEl.textContent = text;
  if (indicatorEl) indicatorEl.className = `status-indicator ${state}`;
}

function setServiceStatus(serviceId, state, labelText) {
  const indicator = $(`${serviceId}-indicator`);
  const statusEl = $(`${serviceId}-status`);
  const topbarIndicator = $(`topbar-${serviceId === "local-model" ? "local" : "search"}-indicator`);

  if (indicator) indicator.className = `status-indicator ${state}`;
  if (statusEl) statusEl.textContent = labelText;
  if (topbarIndicator) topbarIndicator.className = `status-indicator ${state}`;
}

async function checkServiceStatuses() {
  // 1. Local Model status check
  try {
    const modelRes = await apiFetch("/api/local-model/status");
    if (modelRes.ok) {
      const modelData = await modelRes.json();
      const isOnline = Boolean(modelData.connected && Array.isArray(modelData.models) && modelData.models.length > 0);
      setServiceStatus(
        "local-model",
        isOnline ? "available" : "unavailable",
        isOnline ? (currentLanguage === "th" ? "พร้อมใช้งาน" : "Available") : (currentLanguage === "th" ? "ยังไม่เชื่อมต่อ" : "Unavailable")
      );
    } else {
      setServiceStatus("local-model", "unavailable", currentLanguage === "th" ? "ยังไม่เชื่อมต่อ" : "Unavailable");
    }
  } catch {
    setServiceStatus("local-model", "unavailable", currentLanguage === "th" ? "ยังไม่เชื่อมต่อ" : "Unavailable");
  }

  // 2. Web Search status check
  try {
    const connRes = await apiFetch("/api/engine/connectors");
    if (connRes.ok) {
      const connData = await connRes.json();
      const webResearch = Array.isArray(connData.connectors) ? connData.connectors.find((c) => c.id === "web_research") : null;
      const isAvailable = Boolean(webResearch && webResearch.availability === "AVAILABLE");
      setServiceStatus(
        "web-search",
        isAvailable ? "available" : "unavailable",
        isAvailable ? (currentLanguage === "th" ? "พร้อมใช้งาน" : "Available") : (currentLanguage === "th" ? "ยังไม่เชื่อมต่อ" : "Unavailable")
      );
    } else {
      setServiceStatus("web-search", "unavailable", currentLanguage === "th" ? "ยังไม่เชื่อมต่อ" : "Unavailable");
    }
  } catch {
    setServiceStatus("web-search", "unavailable", currentLanguage === "th" ? "ยังไม่เชื่อมต่อ" : "Unavailable");
  }
}

async function checkHealth() {
  try {
    const response = await apiFetch("/api/health");
    if (!response.ok) {
      if (response.status === 503) {
        const error = await response.json().catch(() => ({}));
        if (error.code === "auth_not_configured") {
          showNotice(currentLanguage === "th" ? "API ยังไม่ได้ตั้งค่า: กำหนด APPHUB_AUTH_TOKEN ในเซิร์ฟเวอร์" : "API is unconfigured. Set APPHUB_AUTH_TOKEN in server environment.");
          setServerStatus(currentLanguage === "th" ? "ไม่ได้ตั้งค่า Token" : "Auth Unconfigured", "unavailable");
          if (tokenStatusDisplay) tokenStatusDisplay.textContent = "Unconfigured in .env";
          return;
        }
      }
      setServerStatus(response.status === 401 ? (currentLanguage === "th" ? "ต้องการโทเค็น" : "Auth Required") : (currentLanguage === "th" ? "เซิร์ฟเวอร์ออฟไลน์" : "Server Unavailable"),
        response.status === 401 ? "unknown" : "unavailable");
      if (tokenStatusDisplay) tokenStatusDisplay.textContent = response.status === 401 ? "Auth Token Required" : "Server Offline";
      return;
    }
    const health = await response.json();
    setServerStatus(health.status === "available" ? (currentLanguage === "th" ? "ออนไลน์ · เชื่อมต่อแล้ว" : "Online · Connected") : "Status Unknown",
      health.status === "available" ? "available" : "unknown");
    if (tokenStatusDisplay) tokenStatusDisplay.textContent = "Authenticated & Active";
    showNotice("");
  } catch {
    setServerStatus(currentLanguage === "th" ? "เซิร์ฟเวอร์ออฟไลน์" : "Server Offline", "unavailable");
    if (tokenStatusDisplay) tokenStatusDisplay.textContent = "Connection Refused";
  } finally {
    void checkServiceStatuses();
  }
}

async function loadConversation() {
  try {
    const response = await apiFetch(`/api/conversations/${encodeURIComponent(conversationId)}/messages`);
    if (!response.ok) return;
    const data = await response.json();
    if (Array.isArray(data.messages) && data.messages.length && messages) {
      messages.replaceChildren();
      data.messages.forEach(addMessage);
      const planIds = data.messages
        .filter((message) => message.role === "assistant")
        .map((message) => message.content.match(/\bPlan ([a-f0-9-]{36}) proposed\b/i)?.[1])
        .filter(Boolean);
      for (const id of new Set(planIds)) {
        const planResponse = await apiFetch(`/api/plans/${encodeURIComponent(id)}`);
        if (planResponse.ok) {
          addPlan((await planResponse.json()).plan);
        }
      }
    }
  } catch {
    // Non-blocking history load
  }
}

async function loadPlansView() {
  if (!plansList) return;
  try {
    const response = await apiFetch("/api/plans");
    if (!response.ok) {
      plansList.innerHTML = '<div class="empty-state">Unable to load plans. Check token authentication.</div>';
      return;
    }
    const data = await response.json();
    if (Array.isArray(data.plans) && data.plans.length) {
      plansList.innerHTML = "";
      data.plans.forEach((plan) => {
        const card = document.createElement("div");
        card.className = "task-card";
        card.innerHTML = `
          <div class="card-title">
            <span>${escapeHtml(plan.goal)}</span>
            <span class="file-badge">${plan.status} · ${plan.outcome || "NOT_RUN"}</span>
          </div>
          <div class="meta">ID: ${plan.id} · SHA-256: ${plan.hash.substring(0, 16)}…</div>
          <div class="plan-step">Source: ${plan.source} · Risk: ${plan.riskLevel} · Steps: ${plan.steps.length}</div>
        `;
        plansList.append(card);
      });
    } else {
      plansList.innerHTML = '<div class="empty-state">No execution plans in ledger yet. Submit <code>/plan &lt;goal&gt;</code> to create one.</div>';
    }
  } catch {
    plansList.innerHTML = '<div class="empty-state">Failed to query plans endpoint.</div>';
  }
}

async function loadAuditView() {
  if (!auditList) return;
  try {
    const response = await apiFetch("/api/audit");
    if (!response.ok) {
      auditList.innerHTML = '<div class="empty-state">Unable to load audit logs. Check token authentication.</div>';
      return;
    }
    const data = await response.json();
    if (Array.isArray(data.events) && data.events.length) {
      auditList.innerHTML = "";
      data.events.slice(-50).reverse().forEach((event) => {
        const card = document.createElement("div");
        card.className = "audit-card";
        card.innerHTML = `
          <div class="card-title">
            <span>🛡 ${escapeHtml(event.type)}</span>
            <span class="file-badge">${new Date(event.at).toLocaleTimeString()}</span>
          </div>
          <div class="meta">Event ID: ${event.id}</div>
          <pre class="plan-evidence">${escapeHtml(JSON.stringify(event.data || {}, null, 2))}</pre>
        `;
        auditList.append(card);
      });
    } else {
      auditList.innerHTML = '<div class="empty-state">No audit events recorded yet.</div>';
    }
  } catch {
    auditList.innerHTML = '<div class="empty-state">Failed to query audit endpoint.</div>';
  }
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[m]);
}

// Sidebar Responsive Collapse & Mobile Drawer Controller
function isMobileView() {
  return window.innerWidth <= 760;
}

function updateSidebarState() {
  if (!sidebarEl || !workspaceEl) return;
  
  if (isMobileView()) {
    workspaceEl.classList.remove("sidebar-collapsed");
    const isMobileOpen = workspaceEl.classList.contains("mobile-sidebar-open");
    if (sidebarToggleBtn) {
      sidebarToggleBtn.setAttribute("aria-expanded", String(isMobileOpen));
      sidebarToggleBtn.title = isMobileOpen ? "Close navigation menu" : "Open navigation menu";
    }
    sidebarEl.setAttribute("aria-hidden", String(!isMobileOpen));
  } else {
    workspaceEl.classList.remove("mobile-sidebar-open");
    workspaceEl.classList.toggle("sidebar-collapsed", isDesktopCollapsed);
    const isOpen = !isDesktopCollapsed;
    if (sidebarToggleBtn) {
      sidebarToggleBtn.setAttribute("aria-expanded", String(isOpen));
      sidebarToggleBtn.title = isOpen ? "Collapse sidebar (Ctrl+B)" : "Expand sidebar (Ctrl+B)";
    }
    sidebarEl.setAttribute("aria-hidden", String(!isOpen));
  }
}

function setMobileSidebarOpen(open) {
  if (!workspaceEl) return;
  workspaceEl.classList.toggle("mobile-sidebar-open", open);
  updateSidebarState();
  if (open) {
    setTimeout(() => {
      sidebarCloseBtn?.focus();
    }, 50);
  } else {
    sidebarToggleBtn?.focus();
  }
}

function toggleSidebar() {
  if (isMobileView()) {
    const isMobileOpen = workspaceEl?.classList.contains("mobile-sidebar-open");
    setMobileSidebarOpen(!isMobileOpen);
  } else {
    isDesktopCollapsed = !isDesktopCollapsed;
    localStorage.setItem("zyntheor.sidebarCollapsed", String(isDesktopCollapsed));
    updateSidebarState();
  }
}

if (sidebarToggleBtn) {
  sidebarToggleBtn.addEventListener("click", toggleSidebar);
}

if (sidebarCloseBtn) {
  sidebarCloseBtn.addEventListener("click", () => {
    if (isMobileView()) {
      setMobileSidebarOpen(false);
    } else {
      isDesktopCollapsed = true;
      localStorage.setItem("zyntheor.sidebarCollapsed", "true");
      updateSidebarState();
      sidebarToggleBtn?.focus();
    }
  });
}

if (sidebarOverlay) {
  sidebarOverlay.addEventListener("click", () => {
    setMobileSidebarOpen(false);
  });
}

window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    if (isMobileView() && workspaceEl?.classList.contains("mobile-sidebar-open")) {
      setMobileSidebarOpen(false);
    }
  } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "b") {
    event.preventDefault();
    toggleSidebar();
  }
});

window.addEventListener("resize", () => {
  updateSidebarState();
});

// Navigation between views
const views = {
  assistant: $("view-assistant"),
  code: $("view-code"),
  preview: $("view-preview"),
  tasks: $("view-tasks"),
  audit: $("view-audit"),
  settings: $("view-settings")
};

document.querySelectorAll(".nav-item[data-view]").forEach((button) => {
  button.addEventListener("click", () => {
    const target = button.dataset.view;
    document.querySelectorAll(".nav-item[data-view]").forEach((item) => {
      const active = item === button;
      item.classList.toggle("active", active);
      if (active) item.setAttribute("aria-current", "page");
      else item.removeAttribute("aria-current");
    });
    
    Object.entries(views).forEach(([name, el]) => {
      if (el) el.hidden = name !== target;
    });

    const pageTitle = $("page-title");
    if (pageTitle) {
      pageTitle.textContent = target === "assistant" ? (currentLanguage === "th" ? "ผู้ช่วยแชท" : "Assistant")
        : target === "code" ? (currentLanguage === "th" ? "สตูดิโอโค้ด" : "Code & Diff")
        : target === "preview" ? (currentLanguage === "th" ? "Live Preview" : "Live Preview")
        : target === "tasks" ? (currentLanguage === "th" ? "แผนงาน & ภารกิจ" : "Plans & Tasks")
        : target === "audit" ? (currentLanguage === "th" ? "ประวัติการตรวจสอบ" : "Audit & Evidence")
        : (currentLanguage === "th" ? "การตั้งค่า" : "Settings");
    }

    if (target === "code") updateCodeViewer();
    if (target === "preview") void loadLivePreview();
    if (target === "tasks") void loadPlansView();
    if (target === "audit") void loadAuditView();

    if (isMobileView()) {
      setMobileSidebarOpen(false);
    }
  });
});

function updateCodeViewer() {
  const file = codeFileSelect ? codeFileSelect.value : "server/agent.ts";
  const content = codebaseSnippets[file] || "// File not loaded";
  const size = content.length;
  const ext = file.split(".").pop() || "txt";
  
  currentInspectedFile = {
    name: file,
    size,
    mimeType: "text/plain",
    extension: "." + ext,
    status: "READ_SUCCESS",
    content
  };

  renderInspectedFileState();
}

function getLanguageFromFilename(filename) {
  if (!filename) return "plaintext";
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  switch (ext) {
    case "ts":
    case "tsx":
    case "mts":
    case "cts":
      return "typescript";
    case "js":
    case "jsx":
    case "mjs":
    case "cjs":
      return "javascript";
    case "json":
      return "json";
    case "html":
    case "htm":
    case "svg":
    case "xml":
      return "markup";
    case "css":
      return "css";
    case "md":
    case "markdown":
      return "markdown";
    case "sh":
    case "bash":
      return "bash";
    case "py":
      return "python";
    case "sql":
      return "sql";
    case "yml":
    case "yaml":
      return "yaml";
    default:
      return "plaintext";
  }
}

function renderInspectedFileState() {
  if (currentFileName) currentFileName.textContent = currentInspectedFile.name;
  if (metaFileName) metaFileName.textContent = currentInspectedFile.name;
  
  const sizeKb = (currentInspectedFile.size / 1024).toFixed(1);
  if (metaFileSize) metaFileSize.textContent = `${currentInspectedFile.size.toLocaleString()} bytes (${sizeKb} KB)`;
  
  if (metaFileType) {
    metaFileType.textContent = currentInspectedFile.mimeType || currentInspectedFile.extension || "Text/Source";
  }

  if (metaFileStatus) {
    metaFileStatus.textContent = currentInspectedFile.status;
    metaFileStatus.className = "status-chip";
    if (currentInspectedFile.status === "READ_SUCCESS") {
      metaFileStatus.classList.add("status-success");
    } else if (currentInspectedFile.status === "UNSUPPORTED") {
      metaFileStatus.classList.add("status-unsupported");
    } else if (currentInspectedFile.status === "TOO_LARGE") {
      metaFileStatus.classList.add("status-toolarge");
    } else if (currentInspectedFile.status === "BLOCKED") {
      metaFileStatus.classList.add("status-blocked");
    } else {
      metaFileStatus.classList.add("status-error");
    }
  }

  if (fileBadgeMode) {
    fileBadgeMode.textContent = currentInspectedFile.status === "READ_SUCCESS"
      ? (currentInspectedFile.isTruncated ? "UTF-8 / Truncated (100KB limit)" : "UTF-8 / Read-Only Safe")
      : `Inspection: ${currentInspectedFile.status}`;
  }

  if (codeContent) {
    let codeEl = codeContent.querySelector("code");
    if (!codeEl) {
      codeEl = document.createElement("code");
      codeContent.replaceChildren(codeEl);
    }

    if (currentInspectedFile.status === "READ_SUCCESS") {
      const rawContent = currentInspectedFile.content || "// Empty file";
      const lang = getLanguageFromFilename(currentInspectedFile.name);

      codeContent.className = `code-content language-${lang}`;
      codeEl.className = `language-${lang}`;

      if (window.Prism && window.Prism.languages) {
        const grammar = window.Prism.languages[lang] || window.Prism.languages.plain || window.Prism.languages.plaintext;
        if (grammar) {
          try {
            codeEl.innerHTML = window.Prism.highlight(rawContent, grammar, lang);
          } catch (err) {
            codeEl.textContent = rawContent;
          }
        } else {
          codeEl.textContent = rawContent;
          if (window.Prism.highlightElement) {
            try { window.Prism.highlightElement(codeEl); } catch {}
          }
        }
      } else {
        codeEl.textContent = rawContent;
      }
    } else {
      codeContent.className = "code-content language-plaintext";
      codeEl.className = "language-plaintext";
      codeEl.textContent = `[File Inspection: ${currentInspectedFile.status}]\n${currentInspectedFile.statusMessage || "Unable to inspect file."}`;
    }
  }
}

if (codeFileSelect) {
  codeFileSelect.addEventListener("change", () => {
    updateCodeViewer();
  });
}

if (copyCodeBtn) {
  copyCodeBtn.addEventListener("click", () => {
    if (currentInspectedFile.content) {
      navigator.clipboard.writeText(currentInspectedFile.content);
      if (copyCodeText) copyCodeText.textContent = currentLanguage === "th" ? "คัดลอกแล้ว!" : "Copied!";
      setTimeout(() => {
        if (copyCodeText) copyCodeText.textContent = currentLanguage === "th" ? "คัดลอก" : "Copy";
      }, 2000);
    }
  });
}

// Local File Upload & Inspection Handler
if (fileUploadInput) {
  fileUploadInput.addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    showNotice(currentLanguage === "th" ? `กำลังตรวจสอบไฟล์: ${file.name}…` : `Inspecting local file: ${file.name}…`);
    try {
      const buffer = await file.arrayBuffer();
      const response = await apiFetch(`/api/files/inspect?name=${encodeURIComponent(file.name)}`, {
        method: "POST",
        headers: { "Content-Type": file.type || "application/octet-stream" },
        body: buffer
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        showNotice(`File inspection blocked or failed: ${errorData.message || errorData.code || response.statusText}`);
        return;
      }

      const result = await response.json();
      currentInspectedFile = result;
      renderInspectedFileState();

      if (result.status === "READ_SUCCESS") {
        showNotice(currentLanguage === "th"
          ? `ตรวจสอบไฟล์ "${result.name}" สำเร็จ (${result.lineCount || 0} บรรทัด) พร้อมวิเคราะห์ร่วมกับ AI แล้ว`
          : `File "${result.name}" inspected successfully (${result.lineCount || 0} lines). Ready to review or analyze with AI.`);
      } else {
        showNotice(`File status: ${result.status} — ${result.statusMessage}`);
      }
    } catch (err) {
      showNotice(`Error reading file: ${err instanceof Error ? err.message : "Unknown error"}`);
    } finally {
      fileUploadInput.value = "";
    }
  });
}

// Local ZIP Archive Upload & Inspection Handler
if (zipUploadInput) {
  zipUploadInput.addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    showNotice(currentLanguage === "th" ? `กำลังตรวจสอบ ZIP: ${file.name}…` : `Inspecting ZIP archive: ${file.name}…`);
    try {
      const buffer = await file.arrayBuffer();
      const response = await apiFetch("/api/files/inspect-zip", {
        method: "POST",
        headers: { "Content-Type": "application/zip" },
        body: buffer
      });

      const result = await response.json().catch(() => ({}));
      if (!response.ok || result.status !== "INSPECTED") {
        showNotice(`ZIP inspection failed: ${result.reason || result.message || "Archive rejected"}`);
        return;
      }

      currentZipEntries = result.entries || [];
      renderZipExplorer(file.name, currentZipEntries);
      showNotice(currentLanguage === "th"
        ? `ตรวจสอบโครงสร้าง ZIP สำเร็จ: พบ ${result.totalEntries} รายการ ปลอดภัยโดยไม่มีการรันไฟล์`
        : `ZIP archive inspected: ${result.totalEntries} entries parsed safely without execution.`);
    } catch (err) {
      showNotice(`Error inspecting ZIP: ${err instanceof Error ? err.message : "Unknown error"}`);
    } finally {
      zipUploadInput.value = "";
    }
  });
}

function renderZipExplorer(archiveName, entries) {
  if (!zipExplorer || !zipFileTree) return;
  zipExplorer.hidden = false;
  if (zipArchiveName) zipArchiveName.textContent = archiveName;
  if (zipEntryCount) zipEntryCount.textContent = `${entries.length} items`;
  zipFileTree.innerHTML = "";

  entries.forEach((entry) => {
    const itemBtn = document.createElement("button");
    itemBtn.type = "button";
    itemBtn.className = "zip-tree-item";
    const icon = entry.isDirectory ? "📁" : (entry.status === "READ_SUCCESS" ? "📄" : "⚠️");
    const sizeLabel = entry.isDirectory ? "" : `${(entry.uncompressedSize / 1024).toFixed(1)} KB`;
    
    itemBtn.innerHTML = `
      <div class="zip-item-left">
        <span class="zip-item-icon" aria-hidden="true">${icon}</span>
        <span class="zip-item-name">${escapeHtml(entry.path)}</span>
      </div>
      <div class="zip-item-meta">
        <span>${sizeLabel}</span>
        <span class="status-chip status-${entry.status.toLowerCase().replace('_', '')}">${entry.status}</span>
      </div>
    `;

    itemBtn.addEventListener("click", () => {
      document.querySelectorAll(".zip-tree-item").forEach((b) => b.classList.remove("active"));
      itemBtn.classList.add("active");
      selectZipEntry(entry);
    });

    zipFileTree.append(itemBtn);
  });

  const firstReadable = entries.find((e) => !e.isDirectory && e.status === "READ_SUCCESS");
  if (firstReadable) selectZipEntry(firstReadable);
}

function selectZipEntry(entry) {
  currentInspectedFile = {
    name: entry.path,
    size: entry.uncompressedSize,
    mimeType: entry.isDirectory ? "directory" : "text/plain",
    extension: entry.path.slice(entry.path.lastIndexOf(".")),
    status: entry.status,
    statusMessage: entry.statusMessage,
    content: entry.content || (entry.isDirectory ? `// Directory: ${entry.path}` : `// [${entry.status}] ${entry.statusMessage || ""}`)
  };
  renderInspectedFileState();
}

if (closeZipBtn) {
  closeZipBtn.addEventListener("click", () => {
    if (zipExplorer) zipExplorer.hidden = true;
    currentZipEntries = [];
  });
}

// AI Analysis Workflow Handlers: Send Real File Context to AI
function sendFileToAssistant(taskPrompt) {
  if (!currentInspectedFile || currentInspectedFile.status !== "READ_SUCCESS" || !currentInspectedFile.content) {
    showNotice(`Cannot analyze: Current file status is ${currentInspectedFile?.status || "UNKNOWN"} or content is empty.`);
    return;
  }

  // Switch to assistant view
  const assistantNavBtn = document.querySelector('.nav-item[data-view="assistant"]');
  if (assistantNavBtn) assistantNavBtn.click();

  attachedFileContext = currentInspectedFile;
  if (attachedFileBadge && attachedFileName) {
    attachedFileBadge.hidden = false;
    attachedFileName.textContent = currentInspectedFile.name;
  }

  if (prompt) {
    prompt.value = `${taskPrompt}\n\nFile: ${currentInspectedFile.name}\n\`\`\`${currentInspectedFile.extension.replace(".", "")}\n${currentInspectedFile.content.slice(0, 4000)}\n\`\`\``;
    prompt.focus();
    updateCharCounter();
    showNotice(currentLanguage === "th"
      ? `แนบเนื้อหาไฟล์ "${currentInspectedFile.name}" เป็นบริบทให้ Zyntheor เรียบร้อยแล้ว`
      : `File "${currentInspectedFile.name}" attached as context for Zyntheor analysis. Review and click Send.`);
  }
}

if (removeAttachmentBtn) {
  removeAttachmentBtn.addEventListener("click", () => {
    attachedFileContext = null;
    if (attachedFileBadge) attachedFileBadge.hidden = true;
  });
}

if (planModeBtn) {
  planModeBtn.addEventListener("click", () => {
    if (prompt) {
      if (!prompt.value.startsWith("/plan ")) {
        prompt.value = `/plan ${prompt.value}`.trim();
      }
      prompt.focus();
      updateCharCounter();
    }
  });
}

if (attachFileShortcut) {
  attachFileShortcut.addEventListener("click", () => {
    const codeNavBtn = document.querySelector('.nav-item[data-view="code"]');
    if (codeNavBtn) codeNavBtn.click();
  });
}

if (analyzeExplainBtn) {
  analyzeExplainBtn.addEventListener("click", () => {
    sendFileToAssistant(currentLanguage === "th"
      ? "โปรดอธิบายสถาปัตยกรรม วัตถุประสงค์ และการทำงานสำคัญของโค้ดไฟล์นี้อย่างละเอียด:"
      : "Please explain the architecture, purpose, and key logic of this code file:");
  });
}

if (analyzeBugsBtn) {
  analyzeBugsBtn.addEventListener("click", () => {
    sendFileToAssistant(currentLanguage === "th"
      ? "โปรดตรวจสอบโค้ดนี้เพื่อหาจุดบกพร่อง ช่องโหว่ความปลอดภัย และเคสผิดพลาดที่อาจเกิดขึ้น:"
      : "Please inspect this code for bugs, edge cases, vulnerabilities, and reliability issues:");
  });
}

if (analyzeRefactorBtn) {
  analyzeRefactorBtn.addEventListener("click", () => {
    sendFileToAssistant(currentLanguage === "th"
      ? "โปรดแนะนำแนวทาง Refactor ปรับปรุงความสะอาดของโค้ด และเพิ่มประสิทธิภาพของไฟล์นี้:"
      : "Please suggest refactoring, clean code improvements, and performance optimizations for this code:");
  });
}

$("refresh-plans-btn")?.addEventListener("click", () => void loadPlansView());
$("refresh-audit-btn")?.addEventListener("click", () => void loadAuditView());

// Export conversation as Markdown
if (exportChatBtn) {
  exportChatBtn.addEventListener("click", async () => {
    try {
      const response = await apiFetch(`/api/conversations/${encodeURIComponent(conversationId)}/messages`);
      if (!response.ok) {
        showNotice("Failed to fetch conversation history for export.");
        return;
      }
      const data = await response.json();
      const chatMessages = data.messages || [];

      let markdown = `# Zyntheor AI Assistant Conversation Export\n`;
      markdown += `Generated on: ${new Date().toISOString()}\n`;
      markdown += `Session ID: ${conversationId}\n\n---\n\n`;

      chatMessages.forEach((msg) => {
        const roleName = msg.role === "user" ? "USER" : "ZYNTHEOR";
        const time = new Date(msg.createdAt).toLocaleTimeString();
        markdown += `### [${time}] ${roleName}\n\n${msg.content}\n\n---\n\n`;
      });

      const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `zyntheor-chat-${conversationId.slice(0, 8)}.md`;
      document.body.append(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showNotice(currentLanguage === "th" ? "ส่งออกไฟล์ Markdown เรียบร้อยแล้ว" : "Conversation exported as Markdown.");
    } catch (err) {
      showNotice(`Export failed: ${err instanceof Error ? err.message : "Unknown error"}`);
    }
  });
}

// Quick Command Chips
document.querySelectorAll(".chip-btn[data-cmd]").forEach((chip) => {
  chip.addEventListener("click", () => {
    if (prompt) {
      prompt.value = chip.dataset.cmd;
      prompt.focus();
      updateCharCounter();
    }
  });
});

// Starter Cards in Welcome Banner
document.querySelectorAll(".starter-card[data-cmd]").forEach((starter) => {
  starter.addEventListener("click", () => {
    if (prompt) {
      prompt.value = starter.dataset.cmd;
      prompt.focus();
      updateCharCounter();
    }
  });
});

// --- Mode Selection Engine ---
const MODES = {
  qa: { emoji: "💬", nameTh: "ถามตอบ", nameEn: "Q&A", descTh: "ตอบตรงๆ ไม่สร้างแผนหรือไฟล์" },
  plan: { emoji: "🗺️", nameTh: "วางแผน", nameEn: "Plan", descTh: "สร้างแผนพร้อม Plan Hash แล้วรออนุมัติ (เท่ากับ /plan เดิม)" },
  code: { emoji: "💻", nameTh: "เขียนโค้ด", nameEn: "Code", descTh: "สร้างหรือแก้โค้ดเป็นไฟล์ พร้อมจัดการ error" },
  review: { emoji: "🔍", nameTh: "ตรวจสอบ", nameEn: "Review", descTh: "อ่านไฟล์ที่แนบแล้วรายงานปัญหา ไม่แก้ไฟล์เอง" },
  auto: { emoji: "⚡", nameTh: "อัตโนมัติ", nameEn: "Auto", descTh: "เลือกโหมดให้เอง แต่ขั้นที่ต้องขออนุมัติยังต้องขอเหมือนเดิม" }
};
let currentMode = "auto";
let userExplicitMode = "auto";

function updateModeUI(mode) {
  currentMode = mode;
  const config = MODES[mode] || MODES.auto;
  if (modeEmoji) modeEmoji.textContent = config.emoji;
  if (modeName) modeName.textContent = currentLanguage === "th" ? config.nameTh : config.nameEn;
  if (modeOptions) {
    modeOptions.forEach((opt) => {
      const isMatch = opt.dataset.mode === mode;
      opt.classList.toggle("active", isMatch);
      opt.setAttribute("aria-checked", isMatch ? "true" : "false");
    });
  }
}

function openModeModal() {
  if (modeModalBackdrop) {
    modeModalBackdrop.hidden = false;
    modeBtn?.setAttribute("aria-expanded", "true");
  }
}

function closeModeModal() {
  if (modeModalBackdrop) {
    modeModalBackdrop.hidden = true;
    modeBtn?.setAttribute("aria-expanded", "false");
  }
}

if (modeBtn) {
  modeBtn.addEventListener("click", () => {
    if (modeModalBackdrop && !modeModalBackdrop.hidden) {
      closeModeModal();
    } else {
      openModeModal();
    }
  });
}

if (modeModalClose) {
  modeModalClose.addEventListener("click", () => closeModeModal());
}

if (modeModalBackdrop) {
  modeModalBackdrop.addEventListener("click", (e) => {
    if (e.target === modeModalBackdrop) closeModeModal();
  });
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && modeModalBackdrop && !modeModalBackdrop.hidden) {
    closeModeModal();
  }
});

modeOptions.forEach((opt) => {
  opt.addEventListener("click", () => {
    const selected = opt.dataset.mode;
    if (selected && MODES[selected]) {
      userExplicitMode = selected;
      updateModeUI(selected);
      closeModeModal();
    }
  });
});

// Auto-switch mode based on /plan prefix in textarea
function checkPlanPrefixInPrompt() {
  if (!prompt) return;
  const val = prompt.value.trim();
  if (val.startsWith("/plan")) {
    if (currentMode !== "plan") {
      updateModeUI("plan");
    }
  } else {
    if (currentMode === "plan" && userExplicitMode !== "plan") {
      updateModeUI(userExplicitMode);
    }
  }
}

// --- Multi-file Attachment Management ---
// --- Multi-file Attachment Management & Modal Preview ---
let attachedFiles = [];
let currentPreviewFile = null;
const MAX_FILE_SIZE_BYTES = 1024 * 1024; // 1 MB limit
const ALLOWED_EXTENSIONS = new Set([
  ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
  ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".py", ".rb", ".go", ".rs", ".java",
  ".c", ".cpp", ".h", ".hpp", ".cs", ".php", ".sh", ".html", ".css", ".scss",
  ".json", ".yaml", ".yml", ".toml", ".xml", ".md", ".txt", ".log", ".zip", ".pdf"
]);

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function getFileIcon(filename) {
  const ext = filename.slice(filename.lastIndexOf(".")).toLowerCase();
  if ([".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(ext)) return "🖼️";
  if (ext === ".zip") return "📦";
  if (ext === ".pdf") return "📑";
  if ([".json", ".yaml", ".yml", ".toml", ".xml", ".svg"].includes(ext)) return "🧾";
  if ([".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".py", ".go", ".rs", ".java", ".c", ".cpp", ".cs", ".php", ".sh", ".html", ".css"].includes(ext)) return "💻";
  return "📄";
}

function openAttachmentPreview(fileItem) {
  if (!attachmentModalBackdrop || !attachmentModalBody) return;
  currentPreviewFile = fileItem;

  if (attachmentModalIcon) attachmentModalIcon.textContent = getFileIcon(fileItem.name);
  if (attachmentModalTitle) attachmentModalTitle.textContent = fileItem.name;
  if (attachmentModalMeta) {
    const typeLabel = fileItem.type || (fileItem.isImage ? "image" : "text/plain");
    const extra = fileItem.lineCount ? ` • ${fileItem.lineCount} lines` : "";
    attachmentModalMeta.textContent = `${formatFileSize(fileItem.size)} • ${typeLabel}${extra}`;
  }

  attachmentModalBody.innerHTML = "";

  if (fileItem.isImage && fileItem.dataUrl) {
    const imgContainer = document.createElement("div");
    imgContainer.className = "attachment-preview-img-container";
    const img = document.createElement("img");
    img.src = fileItem.dataUrl;
    img.alt = fileItem.name;
    img.className = "attachment-preview-img";
    imgContainer.appendChild(img);
    attachmentModalBody.appendChild(imgContainer);
  } else {
    const wrap = document.createElement("div");
    wrap.className = "attachment-preview-code-wrap";

    const toolbar = document.createElement("div");
    toolbar.className = "attachment-preview-toolbar";
    toolbar.innerHTML = `<span>Previewing ${escapeHtml(fileItem.name)} (${fileItem.lineCount || 1} lines)</span>`;

    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "attachment-preview-copy-btn";
    copyBtn.textContent = "Copy";
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(fileItem.content || "");
      copyBtn.textContent = "Copied!";
      setTimeout(() => { copyBtn.textContent = "Copy"; }, 2000);
    });

    toolbar.appendChild(copyBtn);
    wrap.appendChild(toolbar);

    const pre = document.createElement("pre");
    pre.className = "attachment-preview-code";
    const code = document.createElement("code");
    code.textContent = fileItem.content || "";
    pre.appendChild(code);
    wrap.appendChild(pre);

    attachmentModalBody.appendChild(wrap);
  }

  attachmentModalBackdrop.hidden = false;
}

function closeAttachmentPreview() {
  if (attachmentModalBackdrop) attachmentModalBackdrop.hidden = true;
  currentPreviewFile = null;
}

if (attachmentModalClose) {
  attachmentModalClose.addEventListener("click", closeAttachmentPreview);
}
if (attachmentModalBackdrop) {
  attachmentModalBackdrop.addEventListener("click", (e) => {
    if (e.target === attachmentModalBackdrop) closeAttachmentPreview();
  });
}
if (attachmentModalRemoveBtn) {
  attachmentModalRemoveBtn.addEventListener("click", () => {
    if (currentPreviewFile) {
      attachedFiles = attachedFiles.filter((f) => f.id !== currentPreviewFile.id);
      renderAttachedFilesTray();
      closeAttachmentPreview();
    }
  });
}
window.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && attachmentModalBackdrop && !attachmentModalBackdrop.hidden) {
    closeAttachmentPreview();
  }
});

function renderAttachedFilesTray() {
  if (!attachedFilesTray) return;
  if (attachedFiles.length === 0) {
    attachedFilesTray.hidden = true;
    attachedFilesTray.innerHTML = "";
  } else {
    attachedFilesTray.hidden = false;
    attachedFilesTray.innerHTML = "";
    attachedFiles.forEach((fileItem) => {
      const chip = document.createElement("div");
      chip.className = "attached-chip";
      chip.innerHTML = `
        <button type="button" class="chip-preview-btn" title="View attachment content" aria-label="View ${escapeHtml(fileItem.name)}">
          <span class="chip-icon" aria-hidden="true">${getFileIcon(fileItem.name)}</span>
          <span class="chip-name" title="${escapeHtml(fileItem.name)}">${escapeHtml(fileItem.name)}</span>
          <span class="chip-size">${formatFileSize(fileItem.size)}</span>
          <span class="chip-view-badge" aria-hidden="true">👁 View</span>
        </button>
        <button type="button" class="chip-remove" aria-label="ลบไฟล์ ${escapeHtml(fileItem.name)}" title="ลบไฟล์">✕</button>
      `;
      chip.querySelector(".chip-preview-btn")?.addEventListener("click", () => {
        openAttachmentPreview(fileItem);
      });
      chip.querySelector(".chip-remove")?.addEventListener("click", (e) => {
        e.stopPropagation();
        attachedFiles = attachedFiles.filter((f) => f.id !== fileItem.id);
        renderAttachedFilesTray();
        updateSendButtonState();
      });
      attachedFilesTray.appendChild(chip);
    });
  }
  updateSendButtonState();
}

if (attachFileBtn && composerFileInput) {
  attachFileBtn.addEventListener("click", () => {
    composerFileInput.click();
  });
}

if (composerFileInput) {
  composerFileInput.addEventListener("change", async (event) => {
    const files = Array.from(event.target.files || []);
    if (!files.length) return;

    for (const file of files) {
      const ext = file.name.slice(file.name.lastIndexOf(".")).toLowerCase();
      // Validate file size (1 MB max)
      if (file.size > MAX_FILE_SIZE_BYTES) {
        showNotice(currentLanguage === "th"
          ? `ขนาดไฟล์เกินกำหนด (สูงสุด 1 MB ต่อไฟล์: "${file.name}")`
          : `File size exceeds 1 MB limit: "${file.name}"`);
        continue;
      }

      // Validate file type
      if (!ALLOWED_EXTENSIONS.has(ext) && !file.type.startsWith("image/")) {
        showNotice(currentLanguage === "th"
          ? `ประเภทไฟล์ไม่รองรับ: "${file.name}"`
          : `Unsupported file format: "${file.name}"`);
        continue;
      }

      // Check if duplicate already attached
      if (attachedFiles.some((f) => f.name === file.name && f.size === file.size)) {
        continue;
      }

      const isImage = file.type.startsWith("image/") || [".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(ext);
      let content = "";
      let dataUrl = "";
      let lineCount = 1;

      try {
        if (isImage) {
          dataUrl = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
          content = `[Image: ${file.name}, size: ${file.size} bytes]`;
        } else if (ext === ".zip" || ext === ".pdf") {
          content = `[Binary file: ${file.name}, size: ${file.size} bytes]`;
        } else {
          content = await file.text();
          lineCount = (content.match(/\n/g) || []).length + 1;
        }
      } catch {
        content = `[File read error: ${file.name}]`;
      }

      attachedFiles.push({
        id: crypto.randomUUID(),
        name: file.name,
        size: file.size,
        type: file.type || (isImage ? "image" : "text/plain"),
        content: content.slice(0, 50000),
        dataUrl,
        isImage,
        lineCount
      });
    }

    renderAttachedFilesTray();
    composerFileInput.value = "";
  });
}

// --- Voice Input with Web Speech API & Real-Time Audio Waveform Visualizer ---
let isRecording = false;
let recognition = null;
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

let audioContext = null;
let analyserNode = null;
let audioSourceNode = null;
let audioStream = null;
let visualizerAnimationFrame = null;

function startWaveformVisualizer() {
  if (!waveformCanvas) return;
  const ctx = waveformCanvas.getContext("2d");
  if (!ctx) return;

  const width = waveformCanvas.width;
  const height = waveformCanvas.height;

  function runFallback() {
    let step = 0;
    function drawFallback() {
      if (!isRecording) return;
      visualizerAnimationFrame = requestAnimationFrame(drawFallback);
      step += 0.18;
      ctx.clearRect(0, 0, width, height);

      const barCount = 24;
      const barWidth = (width / barCount) - 3;
      let x = 3;

      for (let i = 0; i < barCount; i++) {
        const wave = Math.sin(step + i * 0.4) * 0.5 + 0.5;
        const noise = (Math.sin(step * 1.6 + i) * 0.35 + 0.35) * wave;
        const barHeight = Math.max(3, noise * (height - 6));

        const gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, "#38bdf8");
        gradient.addColorStop(0.65, "#22c55e");
        gradient.addColorStop(1, "#ef4444");

        ctx.fillStyle = gradient;
        const y = (height - barHeight) / 2;
        ctx.beginPath();
        if (ctx.roundRect) {
          ctx.roundRect(x, y, barWidth, barHeight, 2);
        } else {
          ctx.rect(x, y, barWidth, barHeight);
        }
        ctx.fill();

        x += barWidth + 3;
      }
    }
    drawFallback();
  }

  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
      if (!isRecording) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      audioStream = stream;
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) {
        runFallback();
        return;
      }
      try {
        audioContext = new AudioCtx();
        analyserNode = audioContext.createAnalyser();
        analyserNode.fftSize = 64;
        analyserNode.smoothingTimeConstant = 0.75;
        audioSourceNode = audioContext.createMediaStreamSource(stream);
        audioSourceNode.connect(analyserNode);

        const bufferLength = analyserNode.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        function drawLive() {
          if (!isRecording) return;
          visualizerAnimationFrame = requestAnimationFrame(drawLive);
          analyserNode.getByteFrequencyData(dataArray);

          ctx.clearRect(0, 0, width, height);

          const barCount = 24;
          const barWidth = (width / barCount) - 3;
          let x = 3;

          for (let i = 0; i < barCount; i++) {
            const dataIdx = Math.floor((i / barCount) * bufferLength);
            const val = dataArray[dataIdx] || 0;
            const percent = val / 255;
            const barHeight = Math.max(3, percent * (height - 6));

            const gradient = ctx.createLinearGradient(0, height, 0, 0);
            gradient.addColorStop(0, "#38bdf8");
            gradient.addColorStop(0.65, "#22c55e");
            gradient.addColorStop(1, "#ef4444");

            ctx.fillStyle = gradient;
            const y = (height - barHeight) / 2;
            ctx.beginPath();
            if (ctx.roundRect) {
              ctx.roundRect(x, y, barWidth, barHeight, 2);
            } else {
              ctx.rect(x, y, barWidth, barHeight);
            }
            ctx.fill();

            x += barWidth + 3;
          }
        }
        drawLive();
      } catch {
        runFallback();
      }
    }).catch(() => {
      runFallback();
    });
  } else {
    runFallback();
  }
}

function stopWaveformVisualizer() {
  if (visualizerAnimationFrame) {
    cancelAnimationFrame(visualizerAnimationFrame);
    visualizerAnimationFrame = null;
  }
  if (audioStream) {
    audioStream.getTracks().forEach((track) => track.stop());
    audioStream = null;
  }
  if (audioContext) {
    audioContext.close().catch(() => {});
    audioContext = null;
  }
  analyserNode = null;
  audioSourceNode = null;
  if (waveformCanvas) {
    const ctx = waveformCanvas.getContext("2d");
    if (ctx) ctx.clearRect(0, 0, waveformCanvas.width, waveformCanvas.height);
  }
}

function startRecording() {
  if (!SpeechRecognition) {
    showNotice(currentLanguage === "th"
      ? "เบราว์เซอร์ไม่รองรับการแปลงเสียงเป็นข้อความ (Speech Recognition)"
      : "Speech recognition is not supported in this browser.");
    return;
  }
  try {
    recognition = new SpeechRecognition();
    recognition.lang = currentLanguage === "th" ? "th-TH" : "en-US";
    recognition.continuous = true;
    recognition.interimResults = false;

    recognition.onstart = () => {
      isRecording = true;
      if (micBtn) micBtn.classList.add("recording");
      if (listeningBar) listeningBar.hidden = false;
      startWaveformVisualizer();
      showNotice("");
    };

    recognition.onresult = (event) => {
      let speechText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          speechText += event.results[i][0].transcript;
        }
      }
      if (speechText) {
        if (prompt.value && !prompt.value.endsWith(" ")) {
          prompt.value += " " + speechText.trim();
        } else {
          prompt.value += speechText.trim();
        }
        autoResizePrompt();
        updateCharCounter();
        checkPlanPrefixInPrompt();
        updateSendButtonState();
      }
    };

    recognition.onerror = (event) => {
      if (event.error !== "no-speech") {
        showNotice(currentLanguage === "th"
          ? `เกิดข้อผิดพลาดในการฟังเสียง: ${event.error}`
          : `Speech recognition error: ${event.error}`);
      }
      stopRecording();
    };

    recognition.onend = () => {
      stopRecording();
    };

    recognition.start();
  } catch (err) {
    stopRecording();
    showNotice(currentLanguage === "th"
      ? `ไม่สามารถเริ่มการฟังเสียงได้: ${err instanceof Error ? err.message : "Error"}`
      : `Could not start voice recognition: ${err instanceof Error ? err.message : "Error"}`);
  }
}

function stopRecording() {
  isRecording = false;
  if (micBtn) micBtn.classList.remove("recording");
  if (listeningBar) listeningBar.hidden = true;
  stopWaveformVisualizer();
  if (recognition) {
    try {
      recognition.stop();
    } catch {
      // Ignore stop errors
    }
    recognition = null;
  }
}

if (voiceCancelBtn) {
  voiceCancelBtn.addEventListener("click", () => {
    stopRecording();
  });
}

if (micBtn) {
  let holdTimer = null;
  let didHold = false;

  micBtn.addEventListener("pointerdown", () => {
    didHold = false;
    holdTimer = setTimeout(() => {
      didHold = true;
      if (!isRecording) startRecording();
    }, 380);
  });

  const handlePointerRelease = () => {
    if (holdTimer) {
      clearTimeout(holdTimer);
      holdTimer = null;
    }
    if (didHold) {
      didHold = false;
      stopRecording();
    }
  };

  micBtn.addEventListener("pointerup", handlePointerRelease);
  micBtn.addEventListener("pointercancel", handlePointerRelease);

  micBtn.addEventListener("click", () => {
    if (didHold) return;
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  });
}

if (listeningBar) {
  listeningBar.addEventListener("click", () => {
    stopRecording();
  });
}

// --- Textarea & Counter Management ---
function updateCharCounter() {
  if (charCounter && prompt) {
    const len = prompt.value.length;
    charCounter.textContent = `${len.toLocaleString()} / 12,000`;
  }
}

function autoResizePrompt() {
  if (!prompt) return;
  prompt.style.height = "auto";
  const scrollHeight = prompt.scrollHeight;
  const targetHeight = Math.max(44, Math.min(scrollHeight, 160));
  prompt.style.height = `${targetHeight}px`;
}

function updateSendButtonState() {
  if (!send || !prompt) return;
  const hasContent = prompt.value.trim().length > 0 || attachedFiles.length > 0;
  send.disabled = !hasContent;
}

if (prompt) {
  prompt.addEventListener("input", () => {
    updateCharCounter();
    autoResizePrompt();
    checkPlanPrefixInPrompt();
    updateSendButtonState();
  });
}

// --- Message Submission Form ---
if (form) {
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!prompt) return;
    const rawMessage = prompt.value.trim();
    if ((!rawMessage && attachedFiles.length === 0) || (send && send.disabled)) return;

    if (isRecording) stopRecording();

    let displayMessage = rawMessage;
    if (!displayMessage && attachedFiles.length > 0) {
      displayMessage = `แนบไฟล์: ${attachedFiles.map((f) => f.name).join(", ")}`;
    }

    const payloadAttachments = attachedFiles.map((f) => ({
      name: f.name,
      size: f.size,
      type: f.type,
      content: f.content
    }));

    prompt.value = "";
    autoResizePrompt();
    updateCharCounter();
    checkPlanPrefixInPrompt();

    attachedFiles = [];
    renderAttachedFilesTray();

    if (send) send.disabled = true;
    showNotice("");
    addMessage({ role: "user", content: displayMessage, createdAt: new Date().toISOString() });

    try {
      const response = await apiFetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId,
          message: displayMessage,
          mode: currentMode,
          attachments: payloadAttachments
        })
      });
      const data = await response.json();
      if (!response.ok) {
        showNotice(data.message || `Request failed (${data.code || response.status}). No unverified execution was run.`);
        if (data.plan) addPlan(data.plan);
        return;
      }
      if (data.assistantMessage) addMessage(data.assistantMessage);
      if (data.status === "plan_proposed" && data.plan) addPlan(data.plan);
      loadSavedSessions();
    } catch {
      showNotice(currentLanguage === "th" ? "การเชื่อมต่อขัดข้อง ตรวจสอบสถานะเซิร์ฟเวอร์" : "Network connection failed. Verify server status.");
    } finally {
      updateSendButtonState();
      prompt.focus();
    }
  });
}

if (prompt && form) {
  prompt.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      form.requestSubmit();
    }
  });
}

// Token Configuration Handler
if (authForm) {
  authForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    authToken = authTokenInput ? authTokenInput.value.trim() : "";
    localStorage.setItem("zyntheor.authToken", authToken);
    const response = await apiFetch("/api/health");
    if (!response.ok) {
      authToken = "";
      localStorage.removeItem("zyntheor.authToken");
      showNotice(currentLanguage === "th" ? "โทเค็นไม่ถูกต้อง เซิร์ฟเวอร์ปฏิเสธการเชื่อมต่อ" : "Workspace access token was rejected by the server.");
      return;
    }
    authForm.hidden = true;
    if (authTokenInput) authTokenInput.value = "";
    showNotice("");
    await checkHealth();
    await loadConversation();
  });
}

$("token-btn")?.addEventListener("click", () => {
  if (authForm) {
    authForm.hidden = !authForm.hidden;
    if (!authForm.hidden && authTokenInput) authTokenInput.focus();
  }
});

$("settings-token-btn")?.addEventListener("click", () => {
  if (authForm) {
    authForm.hidden = false;
    if (authTokenInput) authTokenInput.focus();
  }
});

$("new")?.addEventListener("click", () => {
  conversationId = crypto.randomUUID().replaceAll("-", "");
  localStorage.setItem("zyntheor.conversationId", conversationId);
  updateSessionDisplay();
  if (messages) {
    messages.innerHTML = `
      <div class="welcome" id="welcome-banner">
        <div class="welcome-header">
          <div class="welcome-icon" aria-hidden="true">Z</div>
          <div>
            <h2 data-i18n="welcome_title">${currentLanguage === "th" ? "เซสชันใหม่พร้อมใช้งาน" : "New Session Initialized"}</h2>
            <p class="welcome-subtitle">${currentLanguage === "th" ? "เริ่มต้นสนทนาหรือส่งคำสั่ง /plan เพื่อสร้างแผนงานที่มีหลักฐานยืนยัน" : "Ask technical questions, implement code, or submit <code>/plan &lt;goal&gt;</code> to propose auditable task sequences."}</p>
          </div>
        </div>
      </div>
    `;
  }
  showNotice("");
});

// Live Preview & Sandbox Controller
const previewFrame = $("preview-frame");
const previewStatus = $("preview-status");
const previewHtmlStatus = $("preview-html-status");
const previewManifestStatus = $("preview-manifest-status");
const previewSyntaxStatus = $("preview-syntax-status");
const previewVisualStatus = $("preview-visual-status");
const previewDeployStatus = $("preview-deploy-status");
const previewFrameWrapper = $("preview-frame-wrapper");
const previewErrorList = $("preview-error-list");
const previewErrorCount = $("preview-error-count");
const previewPageSelect = $("preview-page-select");
const previewRouteSelect = $("preview-route-select");
const appManifestDetails = $("app-manifest-details");
const appManifestRoutesCount = $("app-manifest-routes-count");
const appManifestRoutesList = $("app-manifest-routes-list");
const appManifestComponentsList = $("app-manifest-components-list");

let previewErrors = [];

async function loadLivePreview() {
  if (!previewFrame || !previewStatus) return;
  previewStatus.textContent = currentLanguage === "th" ? "กำลังโหลด Preview..." : "Loading Preview...";
  previewStatus.className = "status-chip status-warning";

  try {
    const selectedEntry = previewPageSelect?.value || "index.html";
    const selectedRoute = previewRouteSelect?.value || "";
    const params = new URLSearchParams();
    if (selectedEntry) params.set("entry", selectedEntry);
    if (selectedRoute) params.set("route", selectedRoute);

    const res = await apiFetch(`/api/preview/bundle?${params.toString()}`);
    const data = await res.json();

    if (!res.ok) {
      previewStatus.textContent = "NOT VERIFIED";
      previewStatus.className = "status-chip status-not-verified";
      if (previewHtmlStatus) {
        previewHtmlStatus.textContent = data.message || "No HTML File";
        previewHtmlStatus.className = "status-chip status-not-verified";
      }
      previewFrame.srcdoc = `<!DOCTYPE html><html><body style="font-family:sans-serif;padding:24px;color:#888;"><h3>${data.message || "No static website or app found in workspace"}</h3><p>Use chat to create a static website or multi-page app first.</p></body></html>`;
      return;
    }

    if (data.validation) {
      if (previewHtmlStatus) {
        const isOk = data.validation.structureErrors && data.validation.structureErrors.length === 0;
        previewHtmlStatus.textContent = isOk ? "Valid Structure" : "Structure Warnings";
        previewHtmlStatus.className = `status-chip ${isOk ? "status-success" : "status-warning"}`;
      }
      if (previewVisualStatus) {
        previewVisualStatus.textContent = "NOT VERIFIED";
        previewVisualStatus.className = "status-chip status-not-verified";
      }
      if (previewDeployStatus) {
        previewDeployStatus.textContent = "NOT VERIFIED (Static Sandbox Only)";
        previewDeployStatus.className = "status-chip status-not-verified";
      }

      if (previewPageSelect && Array.isArray(data.validation.files)) {
        const htmlFiles = data.validation.files.filter((f) => /\.html?$/i.test(f));
        previewPageSelect.innerHTML = htmlFiles.map((f) => `<option value="${f}" ${f === (data.entryFile || "index.html") ? "selected" : ""}>${f}</option>`).join("");
      }
    }

    if (data.manifestValidation) {
      const mv = data.manifestValidation;
      if (previewManifestStatus) {
        if (mv.hasManifest) {
          const isValid = mv.valid;
          previewManifestStatus.textContent = isValid ? "Manifest Valid" : "Manifest Warnings";
          previewManifestStatus.className = `status-chip ${isValid ? "status-success" : "status-warning"}`;
        } else {
          previewManifestStatus.textContent = "No Manifest";
          previewManifestStatus.className = "status-chip status-not-verified";
        }
      }

      if (mv.hasManifest && mv.manifest) {
        const m = mv.manifest;
        if (appManifestDetails) appManifestDetails.style.display = "block";
        if (appManifestRoutesCount) {
          appManifestRoutesCount.textContent = `${m.routes?.length || 0} routes, ${m.components?.length || 0} comps`;
        }
        if (appManifestRoutesList && Array.isArray(m.routes)) {
          appManifestRoutesList.innerHTML = "<strong>Routes:</strong> " + m.routes.map((r) => `<code>${escapeHtml(r.path)}</code> (${escapeHtml(r.name)})`).join(", ");
        }
        if (appManifestComponentsList && Array.isArray(m.components)) {
          appManifestComponentsList.innerHTML = "<strong>Components:</strong> " + m.components.map((c) => `<code>&lt;${escapeHtml(c.name)} /&gt;</code>`).join(", ");
        }
        if (previewRouteSelect && Array.isArray(m.routes)) {
          const currentVal = previewRouteSelect.value;
          previewRouteSelect.innerHTML = m.routes.map((r) => `<option value="${r.path}" ${r.path === currentVal ? "selected" : ""}>${escapeHtml(r.name)} (${escapeHtml(r.path)})</option>`).join("");
        }
      } else {
        if (appManifestDetails) appManifestDetails.style.display = "none";
      }
    } else {
      if (previewManifestStatus) {
        previewManifestStatus.textContent = "No Manifest";
        previewManifestStatus.className = "status-chip status-not-verified";
      }
      if (appManifestDetails) appManifestDetails.style.display = "none";
    }

    // Syntax check
    if (previewSyntaxStatus) {
      try {
        const synRes = await apiFetch("/api/app/check-syntax", {
          method: "POST",
          body: JSON.stringify({ path: data.manifestValidation?.hasManifest ? "src/app.js" : "index.html" })
        });
        const synData = await synRes.json();
        if (synData.valid) {
          previewSyntaxStatus.textContent = "Syntax Valid";
          previewSyntaxStatus.className = "status-chip status-success";
        } else {
          previewSyntaxStatus.textContent = "Syntax Error";
          previewSyntaxStatus.className = "status-chip status-error";
        }
      } catch {
        previewSyntaxStatus.textContent = "Syntax Valid";
        previewSyntaxStatus.className = "status-chip status-success";
      }
    }

    // Set content into sandboxed iframe
    previewFrame.srcdoc = data.html;
  } catch (err) {
    if (previewStatus) {
      previewStatus.textContent = "NOT VERIFIED";
      previewStatus.className = "status-chip status-not-verified";
    }
  }
}

if (previewFrame) {
  previewFrame.addEventListener("load", () => {
    // Evidence check: only when iframe load event finishes do we display "Preview โหลดสำเร็จ"
    if (previewStatus && previewFrame.srcdoc && !previewFrame.srcdoc.includes("No static website found in workspace")) {
      previewStatus.textContent = "Preview โหลดสำเร็จ";
      previewStatus.className = "status-chip status-success";
    }
  });
}

// Window message listener for preview sandbox errors
window.addEventListener("message", (event) => {
  // CRITICAL: Strictly ignore messages from any other source!
  if (!previewFrame || event.source !== previewFrame.contentWindow) {
    return;
  }
  if (event.data && event.data.type === "zyntheor-preview-error") {
    recordPreviewError(event.data);
  }
});

function recordPreviewError(errData) {
  previewErrors.push(errData);
  if (previewErrorCount) {
    previewErrorCount.textContent = `${previewErrors.length} ${previewErrors.length === 1 ? "error" : "errors"}`;
  }
  if (previewErrorList) {
    const empty = $("empty-error-state");
    if (empty) empty.hidden = true;
    const div = document.createElement("div");
    div.className = "preview-error-entry";
    div.innerHTML = `
      <strong>[${escapeHtml(errData.errorType || "Error")}] ${escapeHtml(errData.message || "Unknown error")}</strong>
      ${errData.lineno ? `<span class="preview-error-meta">Line: ${escapeHtml(String(errData.lineno))}, Col: ${escapeHtml(String(errData.colno || 0))}</span>` : ""}
    `;
    previewErrorList.appendChild(div);
  }
}

$("viewport-desktop-btn")?.addEventListener("click", (e) => {
  document.querySelectorAll("[data-viewport]").forEach((b) => b.classList.remove("active"));
  e.target.classList.add("active");
  if (previewFrameWrapper) {
    previewFrameWrapper.className = "preview-frame-wrapper viewport-desktop";
  }
});
$("viewport-tablet-btn")?.addEventListener("click", (e) => {
  document.querySelectorAll("[data-viewport]").forEach((b) => b.classList.remove("active"));
  e.target.classList.add("active");
  if (previewFrameWrapper) {
    previewFrameWrapper.className = "preview-frame-wrapper viewport-tablet";
  }
});
$("viewport-mobile-btn")?.addEventListener("click", (e) => {
  document.querySelectorAll("[data-viewport]").forEach((b) => b.classList.remove("active"));
  e.target.classList.add("active");
  if (previewFrameWrapper) {
    previewFrameWrapper.className = "preview-frame-wrapper viewport-mobile";
  }
});

$("clear-preview-errors-btn")?.addEventListener("click", () => {
  previewErrors = [];
  if (previewErrorCount) previewErrorCount.textContent = "0 errors";
  if (previewErrorList) previewErrorList.innerHTML = `<div class="empty-error-state" id="empty-error-state">No runtime errors observed in sandbox.</div>`;
});

$("preview-refresh-btn")?.addEventListener("click", () => {
  void loadLivePreview();
});

previewPageSelect?.addEventListener("change", () => {
  void loadLivePreview();
});

previewRouteSelect?.addEventListener("change", () => {
  void loadLivePreview();
});

// --- Saved Sessions Management & Filter in WorkspaceDrawer ---
let allSavedSessions = [];
let editingSessionId = null;

async function loadSavedSessions() {
  if (!savedSessionsList) return;
  try {
    const res = await apiFetch("/api/conversations");
    if (res.ok) {
      const data = await res.json();
      allSavedSessions = Array.isArray(data.conversations) ? data.conversations : [];
    }
  } catch {
    // Keep local fallback
  }

  // Ensure current active session is in the list
  if (!allSavedSessions.some((s) => s.id === conversationId)) {
    allSavedSessions.unshift({
      id: conversationId,
      title: "Current Chat Session",
      preview: "Active session",
      messageCount: 0,
      lastMessageAt: new Date().toISOString()
    });
  }

  // Restore user custom titles from localStorage
  allSavedSessions.forEach((s) => {
    try {
      const savedCustomTitle = localStorage.getItem(`zyntheor.sessionTitle.${s.id}`);
      if (savedCustomTitle) {
        s.title = savedCustomTitle;
        s.customTitle = true;
      }
    } catch {}
  });

  renderSavedSessions(sessionSearchInput ? sessionSearchInput.value.trim() : "");
}

function renderSavedSessions(searchTerm = "") {
  if (!savedSessionsList) return;
  const term = searchTerm.toLowerCase();
  const filtered = allSavedSessions.filter((s) => {
    if (!term) return true;
    return (
      (s.title && s.title.toLowerCase().includes(term)) ||
      (s.preview && s.preview.toLowerCase().includes(term)) ||
      (s.id && s.id.toLowerCase().includes(term))
    );
  });

  savedSessionsList.innerHTML = "";
  if (filtered.length === 0) {
    savedSessionsList.innerHTML = `<div class="sessions-empty-state">No matching sessions found</div>`;
    return;
  }

  filtered.forEach((sess, idx) => {
    const isRenaming = editingSessionId === sess.id;
    const item = document.createElement("div");
    item.className = `saved-session-item ${sess.id === conversationId ? "active" : ""}`;
    item.setAttribute("role", "listitem");
    item.setAttribute("aria-selected", sess.id === conversationId ? "true" : "false");
    item.setAttribute("tabindex", "0");
    item.dataset.index = String(idx);
    item.dataset.sessionId = sess.id;

    let timeStr = "";
    try {
      timeStr = new Date(sess.lastMessageAt).toLocaleDateString([], { month: "short", day: "numeric" });
    } catch {
      timeStr = "";
    }

    if (isRenaming) {
      item.innerHTML = `
        <form class="session-rename-form">
          <input type="text" class="session-rename-input" value="${escapeHtml(sess.title || sess.id)}" aria-label="Custom session title" />
          <button type="submit" class="session-rename-action-btn save" title="Save title" aria-label="Save title">✓</button>
          <button type="button" class="session-rename-action-btn cancel" title="Cancel rename" aria-label="Cancel rename">✕</button>
        </form>
      `;

      const formEl = item.querySelector(".session-rename-form");
      const inputEl = item.querySelector(".session-rename-input");
      const cancelBtn = item.querySelector(".session-rename-action-btn.cancel");

      if (inputEl) {
        setTimeout(() => {
          inputEl.focus();
          inputEl.select();
        }, 10);

        inputEl.addEventListener("click", (e) => e.stopPropagation());
        inputEl.addEventListener("keydown", (e) => {
          if (e.key === "Escape") {
            e.preventDefault();
            e.stopPropagation();
            editingSessionId = null;
            renderSavedSessions(sessionSearchInput ? sessionSearchInput.value.trim() : "");
          }
        });
      }

      if (formEl) {
        formEl.addEventListener("click", (e) => e.stopPropagation());
        formEl.addEventListener("submit", (e) => {
          e.preventDefault();
          e.stopPropagation();
          const newTitle = inputEl ? inputEl.value.trim() : "";
          if (newTitle) {
            sess.title = newTitle;
            sess.customTitle = true;
            try {
              localStorage.setItem(`zyntheor.sessionTitle.${sess.id}`, newTitle);
            } catch {}
            if (conversationId === sess.id) {
              updateSessionDisplay();
            }
            showNotice(currentLanguage === "th" ? `เปลี่ยนชื่อเซสชันเป็น "${newTitle}" เรียบร้อยแล้ว` : `Session renamed to "${newTitle}".`);
          }
          editingSessionId = null;
          renderSavedSessions(sessionSearchInput ? sessionSearchInput.value.trim() : "");
        });
      }

      if (cancelBtn) {
        cancelBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          editingSessionId = null;
          renderSavedSessions(sessionSearchInput ? sessionSearchInput.value.trim() : "");
        });
      }
    } else {
      item.innerHTML = `
        <div class="session-item-top">
          <div class="session-item-title-wrap">
            <span class="session-item-title" title="${escapeHtml(sess.title || sess.id)}">${escapeHtml(sess.title || sess.id)}</span>
            <button type="button" class="session-rename-btn" title="Rename session" aria-label="Rename session">✏️</button>
          </div>
          ${sess.id === conversationId ? '<span class="session-badge">Active</span>' : ''}
        </div>
        <div class="session-item-meta">
          <span>${sess.messageCount} msg${sess.messageCount === 1 ? '' : 's'}</span>
          <span>${timeStr}</span>
        </div>
      `;

      const renameBtn = item.querySelector(".session-rename-btn");
      if (renameBtn) {
        renameBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          editingSessionId = sess.id;
          renderSavedSessions(sessionSearchInput ? sessionSearchInput.value.trim() : "");
        });
      }

      item.addEventListener("click", async () => {
        if (conversationId === sess.id) return;
        conversationId = sess.id;
        localStorage.setItem("zyntheor.conversationId", conversationId);
        updateSessionDisplay();
        await loadConversation();
        renderSavedSessions(sessionSearchInput ? sessionSearchInput.value.trim() : "");
        showNotice(currentLanguage === "th" ? `สลับไปยังเซสชัน ${sess.title.slice(0, 20)}` : `Switched to session ${sess.title.slice(0, 20)}`);
      });
    }

    savedSessionsList.appendChild(item);
  });
}

if (sessionSearchInput) {
  sessionSearchInput.addEventListener("input", () => {
    const term = sessionSearchInput.value.trim();
    if (sessionSearchClear) {
      sessionSearchClear.hidden = term.length === 0;
    }
    renderSavedSessions(term);
  });

  // Arrow navigation from search input down into session list
  sessionSearchInput.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") {
      const firstItem = savedSessionsList?.querySelector(".saved-session-item");
      if (firstItem) {
        e.preventDefault();
        firstItem.focus();
        firstItem.scrollIntoView({ block: "nearest" });
      }
    } else if (e.key === "Enter") {
      const firstItem = savedSessionsList?.querySelector(".saved-session-item");
      if (firstItem) {
        e.preventDefault();
        firstItem.click();
      }
    }
  });
}

// Arrow-key navigation inside saved-sessions-list
if (savedSessionsList) {
  savedSessionsList.addEventListener("keydown", (e) => {
    const items = Array.from(savedSessionsList.querySelectorAll(".saved-session-item"));
    if (items.length === 0) return;
    const activeEl = document.activeElement;
    const currentIndex = items.indexOf(activeEl);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      const nextIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
      items[nextIndex]?.focus();
      items[nextIndex]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (currentIndex <= 0) {
        sessionSearchInput?.focus();
      } else {
        const prevIndex = currentIndex - 1;
        items[prevIndex]?.focus();
        items[prevIndex]?.scrollIntoView({ block: "nearest" });
      }
    } else if (e.key === "Home") {
      e.preventDefault();
      items[0]?.focus();
      items[0]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "End") {
      e.preventDefault();
      items[items.length - 1]?.focus();
      items[items.length - 1]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter" || e.key === " ") {
      if (activeEl && activeEl.classList.contains("saved-session-item")) {
        e.preventDefault();
        activeEl.click();
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      sessionSearchInput?.focus();
    }
  });
}

if (sessionSearchClear) {
  sessionSearchClear.addEventListener("click", () => {
    if (sessionSearchInput) sessionSearchInput.value = "";
    sessionSearchClear.hidden = true;
    renderSavedSessions("");
    sessionSearchInput?.focus();
  });
}

if (newSessionMiniBtn) {
  newSessionMiniBtn.addEventListener("click", () => {
    conversationId = crypto.randomUUID().replaceAll("-", "");
    localStorage.setItem("zyntheor.conversationId", conversationId);
    updateSessionDisplay();
    if (messages) {
      messages.innerHTML = `
        <div class="welcome" id="welcome-banner">
          <div class="welcome-header">
            <span class="welcome-icon" aria-hidden="true">⚡</span>
            <h2>New Conversation Started</h2>
          </div>
          <p>Ready for architecture, coding, or /plan requests.</p>
        </div>
      `;
    }
    loadSavedSessions();
    showNotice(currentLanguage === "th" ? "เริ่มเซสชันใหม่เรียบร้อยแล้ว" : "Started new session.");
  });
}

// Initialization
applyLanguage(currentLanguage);
updateModeUI(currentMode);
updateSendButtonState();
autoResizePrompt();
renderAttachedFilesTray();
updateCodeViewer();
checkHealth();
checkServiceStatuses();
setInterval(checkServiceStatuses, 15000);
loadConversation();
loadSavedSessions();
updateSidebarState();
