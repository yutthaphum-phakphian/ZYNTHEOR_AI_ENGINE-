# Essential Capability Audit (Static)

Generated: 2026-10-24T01:34:05.458Z
Project: apphub-ai-agent
Overall: **PARTIAL**

> This is a static source-pattern audit, not proof of runtime behavior. A pattern match does not establish correctness; a missing pattern can miss indirect implementations.

| Capability | Status | Evidence | Risk / next requirement |
|---|---|---|---|
| member_signup_route | `NOT_IMPLEMENTED` | No generic email/password signup route pattern found in server.ts. | Without member accounts, the single shared bearer token is not per-user identity. |
| member_login_route | `NOT_IMPLEMENTED` | No generic email/password login route pattern found in server.ts. | Do not claim complete member authentication. |
| proposal_durable_persistence | `IMPLEMENTED_SOURCE_REVIEW_REQUIRED` | JSON snapshot persistence, atomic rename, and fail-closed loading are present in source; restart behavior and concurrency need runtime tests. | Durability is not tenant isolation; multi-process locking, crash consistency across workspace effects, and per-user ownership still require tests. |
| session_sync_auth | `CONDITIONAL_GUARD_ONLY` | Session sync route exists; generic API guard is opt-in via APPHUB_REQUIRE_AUTH, and the route has no evident per-user ownership check. | Enable strict auth as an interim barrier; shared token still does not isolate each user. |
| server_verified_workspace_ownership | `NOT_VERIFIED` | No obvious server-authenticated user-to-workspace binding pattern found in server.ts. | Every workspace read/write must be bound to server-verified identity, not a client-supplied ID. |
| app_builder_generation_route | `NOT_DETECTED` | No matching canonical app-builder generation route pattern found. | Must generate real project files, show diff, and run allowlisted validation before claiming build support. |
| dependency_lockfile | `MISSING` | No npm/pnpm/yarn lockfile found at repository root. | Reproducible install and npm ci cannot be established without a canonical lockfile. |
| runtime_test_environment | `NOT_AVAILABLE` | node_modules is absent in this environment. | Full tests, typecheck, build and live runtime remain unverified. |
