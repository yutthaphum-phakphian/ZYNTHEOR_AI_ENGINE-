# Dependency review — Local/Offline paths

**Method:** static inspection of source and test files read from the uploaded ZIP archive. No archive was extracted; no code was executed and no source file was modified.

## Observed references

- `server.ts` imports `resolveLocalEndpoint` (`server/localEndpoint.ts`), `probeLocalRuntime`/`executeInference` (`server/api.ts`), `handleApiRequest` (`server/middleware.ts`), and provider-selection logic from `server/provider.ts`. References include runtime status/probe paths and chat inference branches.
- `server/middleware.ts` imports `resolveLocalEndpoint`, uses local runtime status/probe endpoints, and includes local-default inference behavior.
- `server/provider.ts` calls `probeLocalRuntime` and owns provider-selection behavior. Treat this as the platform routing/provider contract; do not remove the router when deferring Local AI.
- `server/api.ts` contains `probeLocalRuntime` and callers.
- `App.tsx` (root-level file) has local-endpoint state and sends endpoint values in requests. Its inclusion/use must be checked: `src/main.tsx` imports `src/App.tsx`, while `tsconfig.json` includes `src` but not root `App.tsx`.
- Tests include `tests/local-endpoint.test.ts`, `tests/local-runtime-zero-fake.test.ts`, `tests/provider.test.ts`, `tests/mode-routing.test.ts`, plus runtime and integration tests. Preserve all tests; distinguish Local-specific cases from shared zero-fallback/provider-routing invariants before deciding V1 test gates.
- `server/modeRouting.ts` is used by `server.ts`, `server/preflight.ts`, and tests; this is platform reasoning/mode routing, not inherently Local model execution, so it remains in V1 scope.

## Conclusion

Removing or relocating Local/Offline modules now would break direct imports/call sites and likely tests. Defer these modules in the target map; first implement and test a deliberate provider-selection boundary/feature gate, online-first default, explicit provider configuration, consent enforcement before outbound network calls, and zero-silent-fallback errors. Only after that baseline and regression checks should any unused local-specific code be considered for removal. No removal is approved by this review.

## Verification status

- Static references: observed as listed above.
- Typecheck/build/tests/provider network calls: **NOT RUN**.
- Runtime provider readiness or production readiness: **NOT VERIFIED**.
