<div align="center">
<img src="./src/assets/images/zyntheor-banner.svg" alt="Zyntheor AI Engine Banner" width="100%" style="border-radius: 14px; max-width: 960px;" />

# ⚡ ZYNTHEOR AI ENGINE
**Next-Generation Sovereign AI Software Engineering Studio with Cryptographic Verification, Multi-Mode Reasoning & One Chat Workspace**

<p align="center">
  <a href="https://www.typescriptlang.org/"><img src="https://img.shields.io/badge/TypeScript-5.7-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TS" /></a>
  <a href="https://react.dev/"><img src="https://img.shields.io/badge/React-19-61DAFB?style=for-the-badge&logo=react&logoColor=black" alt="React" /></a>
  <a href="https://expressjs.com/"><img src="https://img.shields.io/badge/Express-4.21-000000?style=for-the-badge&logo=express" alt="Express" /></a>
  <a href="https://tailwindcss.com/"><img src="https://img.shields.io/badge/TailwindCSS-v4-06B6D4?style=for-the-badge&logo=tailwindcss" alt="Tailwind" /></a>
  <a href="#-security--zero-fake-verification"><img src="https://img.shields.io/badge/Security-Zero_Fake-10B981?style=for-the-badge&logo=shield" alt="Security" /></a>
  <a href="#governance-closure"><img src="https://img.shields.io/badge/Governance-v10.0--final-7c3aed?style=for-the-badge" alt="Governance" /></a>
  <a href="#governance-closure"><img src="https://img.shields.io/badge/Closure-Complete-10b981?style=for-the-badge" alt="Closure" /></a>
  <a href="#thai-and-english-support"><img src="https://img.shields.io/badge/Language-TH_%7C_EN-blueviolet?style=for-the-badge" alt="Bilingual" /></a>
</p>
</div>

---

## 🌟 Overview / ภาพรวมโครงการ

**Zyntheor AI Engine** เป็นแพลตฟอร์มวิศวกรรมซอฟต์แวร์อัจฉริยะ (AI Software Engineering Studio) ที่มุ่งเน้นความโปร่งใส ความถูกต้อง และความปลอดภัยสูงสุด ด้วยหลักการ **Zero Phantom Execution** และ **Cryptographic Audit Ledger** ทำให้ทุกคำสั่ง การวางแผน (Task Plans) และการปรับปรุงโค้ด (Code Proposals) มีหลักฐานดิจิทัลกำกับและตรวจสอบย้อนหลังได้จริง

### Key Highlights
- **Zero Phantom Execution**: ไม่มีผลลัพธ์หลอกลวง หากโมเดลหรือเครื่องมือภายนอกไม่พร้อม ระบบจะแจ้งสถานะ `UNAVAILABLE` หรือ `BLOCKED` อย่างโปร่งใส
- **Cryptographic Audit Ledger**: บันทึกทุกขั้นตอนด้วย SHA-256 Digest พร้อม Correlation ID เพื่อการสอบทานด้านความปลอดภัย
- **Multi-Mode Reasoning**: สลับโหมดการทำงานได้ทันที (Auto, Fast, Deep Reasoning, Coding, Review, และ Custom)
- **Unified One-Chat Workspace**: หน้าจอพัฒนาโค้ด แชท สรุปเซสชัน และตรวจจับแท็กอัตโนมัติ (Code, Bug, Idea, Arch) ในที่เดียว
- **Bilingual Experience**: รองรับภาษาไทยและภาษาอังกฤษอย่างสมบูรณ์แบบ ทั้งคำสั่งเสียง (Thai Voice Commands), UI และการประมวลผลข้อความ

---

## 🏛️ Governance Closure / สถานะปิดโครงการ

> **Final State — Verified from your terminal**

```yaml
closure_status: Governance Closure Complete
legacy_preservation: archived
final_commit:
  hash: 13c12ad19fa42ed0094ad5c6041f
  message: "Updated P10 audit trail"
  date: 2026-10-24 20:38:57 +0000
governance:
  tags: [v4.0-governance, v10.0-final]
  audit_chain: audit/trail_p1.log ... trail_p10.log [VALID]
  ledger: VALID
  merkle_root: verified
```

**Verify:**
```bash
git ls-tree -r main | grep -E "audit/trail_p|governance/final.yaml"
git log -1 --oneline
git tag -l | grep -E "v4.0|v10.0"
git show v10.0-final --stat
```

---

## 🚀 Quick Start / เริ่มต้นใช้งาน

### Prerequisites
- **Node.js** 22+
- **npm** (มาพร้อมกับ Node.js)

### 1. Installation
```bash
# Clone the repository
git clone https://github.com/maewhyxng2-prog/ZYNTHEOR-AI-ENGINE.git
cd ZYNTHEOR-AI-ENGINE

# Install dependencies
npm install
```

### 2. Environment Configuration
คัดลอกไฟล์ `.env.example` ไปยัง `.env` และกำหนดค่าตัวแปร:
```bash
cp .env.example .env
```

| Environment Variable | Description |
|---|---|
| `HOST` | Default: `0.0.0.0` (bind network interface) |
| `PORT` | Default: `3000` |
| `APPHUB_AUTH_TOKEN` | Bearer token สำหรับรักษาความปลอดภัย API (>= 32 ตัวอักษร) |
| `AI_PROVIDER` | `local` (แนะนำ) / `none` เพื่อปิด routing โดยตั้งใจ — ไม่มี external provider แล้ว |
| `LOCAL_AI_ENDPOINT` | URL สำหรับ Local AI (เช่น Ollama `http://127.0.0.1:11434`) |
| `LOCAL_AI_MODEL` | ชื่อโมเดล Local (เช่น `llama3.2:3b`) |

> **Local-only Engine:** `@google/generative-ai` ถูกลบแล้ว เหลือ adapter เดียวคือ `zyntheor-local` ตามนโยบาย Zero-Fake ดู `docs/EXTERNAL_AI_REMOVAL_REPORT.md`

### 3. Running the Application
```bash
# Start development server (Port 3000)
npm run dev

# Run test suite
npm test

# Typecheck and Lint
npm run typecheck
npm run lint

# Build for production
npm run build

# Runtime health (8 probes)
curl http://localhost:3000/api/runtime-health
```

เปิดเบราว์เซอร์ไปที่: `http://localhost:3000`

---

## 🎯 Architecture & Modes

### 1. Engine Modes
| โหมด (Mode) | หน้าที่และการทำงาน |
|---|---|
| **Auto** | จำแนกเจตนาและเลือกโหมดการประมวลผลที่เหมาะสมที่สุดให้อัตโนมัติ |
| **Fast** | โหมดตอบกลับรวดเร็ว เหมาะสำหรับการถาม-ตอบทั่วไปและตรวจสอบสั้นๆ |
| **Deep Reasoning** | วิเคราะห์สถาปัตยกรรม ออกแบบขั้นตอน และตรวจสอบความสอดคล้องเชิงลึก |
| **Coding (/code)** | สร้างและแก้ไขโค้ดผ่าน File Change Proposals พร้อมระบบ Diff และต้องได้รับการอนุมัติก่อนเขียนไฟล์ |
| **Review (Read-Only)** | ตรวจสอบช่องโหว่ความปลอดภัยและวิเคราะห์โครงสร้างแบบอ่านอย่างเดียว |
| **Custom** | ปรับแต่งระดับความลึก, ระบบอนุมัติ, และ Connector permissions ได้ตามต้องการ |

### 2. Unified Interface
- **Assistant & Chat**: สนทนา สั่งการวางแผนงาน และสั่งเขียนโค้ด
- **Code & File Studio**: ตรวจดูโครงสร้างโปรเจกต์ ดูความแตกต่างของโค้ด (Diffs) และไฟล์ใน Workspace
- **Plans & Tasks Studio**: ดูสถานะงาน แผนการทำงาน และ Step-by-step progress
- **Audit Ledger**: ตรวจสอบประวัติการทำงานและ Hash cryptographic verification
- **System Settings**: จัดการคีย์ลัด ธีม (Dark/Light) และการตั้งค่าเสียง/โมเดล

---

## 🛡️ Security & Zero-Fake Verification

1. **Proof-of-Execution**: ทุกแอคชันมีการผูกโยงกับ SHA-256 Hash และ Session Correlation ID
2. **Approval Gate**: ป้องกันการเขียนทับไฟล์โดยไม่ตั้งใจ ไฟล์โปรเจกต์จะถูกแก้ไขเมื่อผู้ใช้กดอนุมัติเท่านั้น
3. **Secret Redaction**: ระบบจะซ่อนและกรอง API Keys, Tokens และ Passwords จาก Log และ UI โดยอัตโนมัติ
4. **Sandbox Isolation**: รองรับการแยกสภาพแวดล้อมเพื่อความปลอดภัยของระบบโฮสต์
5. **Zero-Fake Policy**: ถ้าเจอ `external_provider_removed` หรือ `CONFIG_REQUIRED` → ระบบ HALT ทันที ไม่มีการปลอมผลลัพธ์
6. **Evidence Verification Gate**: Model digest = SHA256(weights||tokenizer||system_prompt), Merkle root, Ed25519 signature, hash chaining

**Runtime Health — 8 Probes** จาก `server/routes/runtime-health.ts`: Local Core, API Key, Runtime Probe, Ledger, Compliance, Routing, Recovery, Error State

---

## 📁 Project Structure — Cleaned

```
/
├── README.md
├── audit/
│   ├── trail_p1.log ... trail_p10.log  # P1-P10 hash-chained evidence
│   └── trail_p4.log (legacy)
├── governance/
│   └── final.yaml  # Governance Closure Certificate (legacy_preservation: archived)
├── docs/
│   ├── pdpa/          # PDPA_DATA_*, RIGHTS_WORKFLOW, INCIDENT_RUNBOOK
│   ├── governance/    # *AUDIT*, *STATUS*, PROVIDER_ROUTING, REBUILD_*
│   ├── reports/       # AI_STUDIO_*, IMMERSIVE_*, ONLINE_OFFLINE_*
│   ├── P1/ P2/ P3/    # Roadmaps
│   └── EXTERNAL_AI_REMOVAL_REPORT.md
├── server/             # Core backend services, connectors, memory & diagnostics
│   ├── engine/         # ZynthCore, Router, Policy, Adapter types
│   ├── providers/      # local-runtime only (gemini removed)
│   ├── routes/         # auth, consent, chat, build, runtime-health
│   └── security/       # auth, consent, Merkle
├── src/                # Modern React 19 Frontend
│   ├── assets/images/  # zyntheor-banner.svg
│   ├── components/     # UI components & panels
│   ├── hooks/          # theme, shortcut, speech, scroll
│   ├── types/          # TypeScript interfaces
│   └── utils/
├── tests/              # external-provider-removal, auth, consent, workspace-isolation
├── scripts/
│   └── run_audit.sh
├── .data/              # Runtime data - IGNORED (prevent merge conflicts)
├── package.json / tsconfig.json / vite.config.ts
├── docker-compose.yml / index.html
└── .gitignore (ignores .data/, *.swp, *.log except audit/trail_*.log)
```

---

## 🇹🇭 Thai and English Support

Zyntheor รองรับการทำงานแบบสองภาษา (Bilingual):
- **Thai Voice Commands**: คำสั่งเสียงภาษาไทย เช่น "สรุปเซสชัน", "เปิดแผนงาน", "ตรวจสอบโค้ด", "สร้างเอกสาร"
- **Auto-Tagging**: ระบบตรวจจับเนื้อหาภาษาไทยและสากล เช่น ปัญหา/บั๊ก (Bug), แผนงาน (Idea), สถาปัตยกรรม (Arch)
- **Bilingual Interface**: สามารถสลับระหว่างภาษาไทยและภาษาอังกฤษได้ทันที

---

## 📜 P1-P10 Evidence Chain

- **P1-P4**: Core runtime + external AI removal + audit chain + `v4.0-governance`
- **P5-P9**: Recovery, memory-in, orchestration, PDPA readiness
- **P10**: Final audit + `governance/final.yaml` + `v10.0-final` + Legacy Preservation archived

All logs are hash-chained. No mocked outputs. `.swp` and `.data/` are ignored to prevent merge conflicts.

---

## 📄 License

MIT License — Developed and maintained by Zyntheor AI Engine Community.  
Private Flagship Runtime — All evidence hash-chained, tamper-proof.
