# สถานะการปรับโหมดในแชท — Revision 2026-10-24

## สถานะ UI
- แถบโหมดอยู่เหนือช่องพิมพ์ และโหมดหลักคือ แชททั่วไป, คิดและวางแผน, เขียนโค้ด และสร้างแอป
- โหมดสร้างแอปเปิด Workspace ที่แท็บ Build โดยตรง
- เพิ่มช่องพิมพ์โจทย์สร้างแอปและตัวเลือก Web / Android / iOS ใน Build workspace
- คำสั่งจากช่อง Build จะถูกนำไปวางในแชทโหมดเขียนโค้ดเพื่อให้ผู้ใช้ตรวจสอบและกดส่งเอง
- ลดความรกด้วยการปิด Diagnostics/Telemetry rail ไว้ก่อน และเปิดได้ผ่านปุ่มที่แถบด้านบน
- ธีมหลักเปลี่ยนเป็น Graphite + Teal + Amber โดยไม่มีม่วงเป็นสี accent หลัก

## ขอบเขตที่ต้องบอกตามจริง
- ไม่พบ dedicated app-generation route เช่น `POST /api/builder/generate` ใน `server.ts` ดังนั้นช่อง Build ใหม่ยังไม่ถือว่าเขียนไฟล์โปรเจกต์จริงด้วยการคลิกครั้งเดียว
- การเขียนไฟล์ยังต้องผ่านความสามารถ Backend ที่มีจริง รวมถึง flow ของ proposal / diff / approval
- ชุดทดสอบเฉพาะ source-level ผ่าน 21/21; full typecheck/build/test ยังติดตั้ง dependencies ไม่ได้ในสภาพแวดล้อมที่แก้ไฟล์นี้

สถานะ: `PARTIAL` — UI source changes and selected tests verified; runtime/build validation pending.
