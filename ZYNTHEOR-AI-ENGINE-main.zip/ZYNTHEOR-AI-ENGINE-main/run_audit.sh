#!/usr/bin/env bash
# Evidence-based audit runner. Never emits PASS for checks it did not execute.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
REPORT_FILE="FINAL_VERIFICATION_REPORT.md"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
TIMESTAMP="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
NODE_VERSION="$(node --version 2>/dev/null || echo UNAVAILABLE)"
NPM_VERSION="$(npm --version 2>/dev/null || echo UNAVAILABLE)"

# Append a report row. All status values come from explicit checks below.
rows="$TMP_DIR/rows.md"
: > "$rows"

add_row() {
  local check="$1" status="$2" detail="$3"
  detail="${detail//|/\\|}"
  printf '| %s | `%s` | %s |\n' "$check" "$status" "$detail" >> "$rows"
}

if node -e "const p=require('./package.json'); if (!p.name || !p.scripts?.build || !p.scripts?.typecheck || !p.scripts?.test) process.exit(1)" >/dev/null 2>&1; then
  add_row "package.json and key scripts" "PASS" "Node successfully parsed package.json and found build/typecheck/test scripts."
else
  add_row "package.json and key scripts" "FAIL" "package.json parse or required script check failed; inspect the command output manually."
fi

LOCK=""
for candidate in package-lock.json npm-shrinkwrap.json pnpm-lock.yaml yarn.lock bun.lockb bun.lock; do
  if [ -s "$candidate" ]; then LOCK="$candidate"; break; fi
done
if [ -n "$LOCK" ]; then
  add_row "dependency lockfile" "PASS" "Non-empty lockfile found: $LOCK (integrity and freshness are not established by existence alone)."
else
  add_row "dependency lockfile" "BLOCKED" "No non-empty recognized dependency lockfile found; reproducible install is not established."
fi

if [ -d node_modules ] && [ -x node_modules/.bin/tsx ] && [ -x node_modules/.bin/vite ] && [ -x node_modules/.bin/tsc ]; then
  add_row "local project dependencies" "PASS" "Local tsx, vite, and tsc executables are present."
else
  add_row "local project dependencies" "BLOCKED" "Local project binaries are missing. Global tools are not substituted for declared versions."
fi

if node --test tests/pdpa-readiness-doc.test.mjs >"$TMP_DIR/pdpa.log" 2>&1; then
  summary="$(grep -E '^# (tests|pass|fail) ' "$TMP_DIR/pdpa.log" | tr '\n' ';' | sed 's/;*$//')"
  add_row "PDPA documentation/source checks" "PASS" "Executed node --test tests/pdpa-readiness-doc.test.mjs; $summary."
else
  tail_text="$(tail -n 5 "$TMP_DIR/pdpa.log" | tr '\n' ' ' | sed 's/|/\\|/g')"
  add_row "PDPA documentation/source checks" "FAIL" "$tail_text"
fi

if node --experimental-strip-types --test \
  tests/mobile-first-redesign.test.ts \
  tests/ui-zero-fake-workspaces.test.ts \
  tests/ui-no-unbacked-claims.test.ts \
  tests/workspace-panel.test.ts >"$TMP_DIR/source-tests.log" 2>&1; then
  summary="$(grep -E '^# (tests|pass|fail) ' "$TMP_DIR/source-tests.log" | tr '\n' ';' | sed 's/;*$//')"
  add_row "selected source-level regression tests" "PASS" "Executed with Node type stripping (experimental); $summary. This is not a full suite."
else
  tail_text="$(tail -n 8 "$TMP_DIR/source-tests.log" | tr '\n' ' ' | sed 's/|/\\|/g')"
  add_row "selected source-level regression tests" "FAIL" "$tail_text"
fi

# Parse the active TypeScript/TSX source tree when a TypeScript compiler is available.
TSC_CMD="$(command -v tsc 2>/dev/null || true)"
if [ -z "$TSC_CMD" ] && [ -x node_modules/.bin/tsc ]; then TSC_CMD="$ROOT/node_modules/.bin/tsc"; fi
if [ -n "$TSC_CMD" ]; then
  TS_ROOT="$(dirname "$(dirname "$(readlink -f "$TSC_CMD")")")"
  if NODE_PATH="$(dirname "$TS_ROOT")" node - "$ROOT" >"$TMP_DIR/parse.log" 2>&1 <<'NODE'
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const root = process.argv[2];
const roots = ['src', 'server', 'tests', 'features'];
const files = [];
const errors = [];
function walk(dir) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, item.name);
    if (item.isDirectory()) walk(file);
    else if (/\.(ts|tsx)$/.test(item.name)) files.push(file);
  }
}
for (const dir of roots) if (fs.existsSync(path.join(root, dir))) walk(path.join(root, dir));
for (const file of files) {
  const text = fs.readFileSync(file, 'utf8');
  const kind = file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
  const parsed = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, kind);
  for (const d of parsed.parseDiagnostics) errors.push(`${path.relative(root, file)}:${parsed.getLineAndCharacterOfPosition(d.start || 0).line + 1}: ${ts.flattenDiagnosticMessageText(d.messageText, ' ')}`);
}
console.log(`filesParsed=${files.length}; parseDiagnostics=${errors.length}`);
for (const error of errors.slice(0, 20)) console.log(error);
if (errors.length) process.exitCode = 1;
NODE
  then
    detail="$(cat "$TMP_DIR/parse.log" | tr '\n' ';' | sed 's/;*$//; s/|/\\|/g')"
    add_row "TypeScript/TSX syntax parse" "PASS" "$detail"
  else
    detail="$(tail -n 8 "$TMP_DIR/parse.log" | tr '\n' ' ' | sed 's/|/\\|/g')"
    add_row "TypeScript/TSX syntax parse" "FAIL" "$detail"
  fi
else
  add_row "TypeScript/TSX syntax parse" "NOT_TESTED" "No TypeScript parser available."
fi

if [ -x node_modules/.bin/tsc ]; then
  if node_modules/.bin/tsc --noEmit >"$TMP_DIR/typecheck.log" 2>&1; then
    add_row "TypeScript typecheck" "PASS" "Project-local tsc --noEmit exited 0."
  else
    code=$?
    tail_text="$(tail -n 8 "$TMP_DIR/typecheck.log" | tr '\n' ' ' | sed 's/|/\\|/g')"
    add_row "TypeScript typecheck" "FAIL" "Project-local tsc exit=$code; $tail_text"
  fi
else
  add_row "TypeScript typecheck" "BLOCKED" "Project-local TypeScript is unavailable; no semantic typecheck result."
fi

if [ -x node_modules/.bin/vite ]; then
  if npm run build >"$TMP_DIR/build.log" 2>&1; then
    add_row "Vite production build" "PASS" "npm run build exited 0."
  else
    code=$?
    tail_text="$(tail -n 8 "$TMP_DIR/build.log" | tr '\n' ' ' | sed 's/|/\\|/g')"
    add_row "Vite production build" "FAIL" "npm run build exit=$code; $tail_text"
  fi
else
  add_row "Vite production build" "BLOCKED" "Project-local Vite is unavailable; build was not run."
fi

if [ -x node_modules/.bin/tsx ]; then
  if npm run test:mock >"$TMP_DIR/full-tests.log" 2>&1; then
    summary="$(grep -E '# (tests|pass|fail) ' "$TMP_DIR/full-tests.log" | tail -n 3 | tr '\n' ';' | sed 's/;*$//')"
    add_row "unit + integration tests" "PASS" "npm run test:mock exited 0; $summary."
  else
    code=$?
    tail_text="$(tail -n 8 "$TMP_DIR/full-tests.log" | tr '\n' ' ' | sed 's/|/\\|/g')"
    add_row "unit + integration tests" "FAIL" "npm run test:mock exit=$code; $tail_text"
  fi
else
  add_row "unit + integration tests" "BLOCKED" "Project-local tsx is unavailable; full unit/integration suite was not run."
fi

GIT_INFO="UNAVAILABLE (no Git metadata in this delivery)"
if git -C "$ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  GIT_INFO="$(git -C "$ROOT" rev-parse HEAD)"
fi

cat > "$REPORT_FILE" <<REPORT
# ZYNTHEOR AI ENGINE — Evidence-Based Verification Report

- **Generated (UTC):** $TIMESTAMP
- **Node:** $NODE_VERSION
- **npm:** $NPM_VERSION
- **Git revision:** $GIT_INFO
- **Overall status:** \`PARTIAL\`

This report records only commands actually executed by this script. Presence of a script or test file is not treated as proof that it passed. It does not certify production readiness, browser behavior, live Local inference, or legal compliance.

## Results

| Check | Status | Evidence / limitation |
|---|---|---|
$(cat "$rows")

## Dependency installation blocker

At the time of this report, this environment has no populated npm cache and DNS resolution for \`registry.npmjs.org\` failed with \`EAI_AGAIN\`. Therefore the project dependency tree and an npm lockfile cannot be generated here without fabricating resolver metadata. Do not create a placeholder lockfile. Restore registry access, generate and review \`package-lock.json\`, then run \`npm ci\`, \`npm run typecheck\`, \`npm run build\`, and \`npm run test:mock\`.

## Scope limits

- The source-level tests are not a replacement for the full test suite.
- Browser/mobile visual interaction was not performed by this script.
- Local AI inference and provider network handshakes were not tested by this script.
- ZYNTHEOR AI ENGINE remains separate from ZYRQUEN; this audit adds no cross-product integration.
REPORT

printf 'Wrote %s\n' "$REPORT_FILE"
cat "$rows"
