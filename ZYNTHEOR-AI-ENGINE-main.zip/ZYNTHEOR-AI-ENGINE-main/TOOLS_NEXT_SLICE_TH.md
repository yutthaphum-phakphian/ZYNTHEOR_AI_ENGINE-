# ZYNTHEOR AI ENGINE — Tool Capability Slice

Status: IMPLEMENTED_SOURCE / TESTS_NOT_EXECUTED_IN_THIS_ENVIRONMENT

## Added: `check_local_runtime`
- Read-only, low-risk tool for checking the local Ollama `/api/tags` endpoint.
- Fixed loopback endpoint `http://127.0.0.1:11434/api/tags`; callers cannot supply arbitrary URLs.
- 2.5-second timeout; does not submit prompts, invoke model inference, or contact a hosted provider.
- Reports `CONNECTED` only after a successful HTTP response and `UNAVAILABLE` on connection/HTTP failure.
- Returns measured probe latency and up to 100 model names from the runtime response.
- Tool result verification confirms the endpoint and evidence shape; it does not claim inference quality or model readiness.
- The tool is registered as a core read-only capability and cannot be unregistered or have its permission revoked through the public agent helpers.

## Next tool slices
1. `search_project_files`: workspace-root constrained text search with symlink/path traversal protection and bounded output.
2. `read_project_file`: read-only file inspection with explicit path allowlist and size caps.
3. `run_project_checks`: explicit approval-gated execution of allowlisted test/typecheck/build commands; never use `shell: true`.
4. `web_research`: online research tool with explicit user consent and source URLs retained as evidence.
5. `edit_project_file`: proposal + diff + approval + post-write hash; no silent overwrite.

## Verification boundary
The environment used for this slice does not currently have the project dependency tree available. Source assertions were updated, but the full TypeScript test suite and runtime HTTP probe have not been executed here. Do not label this slice runtime-verified until those checks run in the project environment.
