# ZYNTHEOR Cumulative Incremental Patch

## Patch set

**Model Registry & Provenance Integration — Patch 1 + Patch 2**

แพตช์นี้รวมงาน Patch 1 และ Patch 2 ไว้ใน ZIP เดียวสำหรับติดตั้งครั้งเดียวใน Repository เดิม ไม่รวมโปรเจกต์เต็ม ไม่รวม `node_modules`, `dist`, credentials หรือ checkpoint และไม่มีการเปลี่ยน Model Router หรือ External Provider identity

## วิธีติดตั้งแบบปลอดภัย

1. สร้าง backup หรือ branch ของ Repository เดิมก่อนติดตั้ง
2. แตก ZIP นี้ที่ root ของ Repository เดิม
3. ตรวจสอบว่าไฟล์ใน ZIP ตรงกับรายการด้านล่าง
4. รัน typecheck, build และ regression tests ก่อนเปิดใช้งาน
5. หาก Repository เดิมมีการแก้ไขไฟล์เดียวกันหลัง Patch 1 ให้ merge ตาม diff แทนการ overwrite โดยไม่ตรวจสอบ

```bash
unzip zyntheor_model_registry_provenance_cumulative_patch.zip -d /path/to/ZYNTHEOR_AI_ENGINE
cd /path/to/ZYNTHEOR_AI_ENGINE
npm run typecheck
npm run build
npx vitest run src/tests/evidenceProvenanceSecurity.test.ts
node --import tsx --test tests/corex-model-lifecycle.test.mjs tests/dataset-quality.test.mjs
```

## รายการไฟล์ใน cumulative patch

```text
PATCH_README.md
docs/audit/MODEL_REGISTRY_PROVENANCE_INTEGRATION_AUDIT.md
lib/native-model-runtime.ts
server.ts
src/components/ModelsPage.tsx
src/components/ModelProvenancePanel.tsx
src/components/TrainingLogHistory.tsx
```

## Patch 1 changes

- เชื่อม Model Registry กับ selected model ใน `ModelsPage`
- เพิ่ม `ModelProvenancePanel`
- แสดง training, dataset, license และ checkpoint metadata จากข้อมูลจริง
- ลบ hardcoded evidence fallback
- รองรับ mobile และ long SHA-256 values

## Patch 2 changes

- เพิ่ม cross-check ระหว่าง `model_registry.json` และ `native_model_identity.json`
- ส่งผล `registryCrossCheck` เป็น `MATCH`, `MISMATCH` หรือ `UNAVAILABLE`
- เชื่อม `/api/native-model/status` ที่มีอยู่แล้วเข้ากับ provenance UI
- แสดง runtime model ID, actual checkpoint digest และ checksum result แยกจาก recorded digest
- ลบ synthetic checkpoint digest, synthetic checkpoint path และ synthetic evidence digest จาก `/api/training/history`
- เปลี่ยน Training History เป็น `BLOCKED_NO_VERIFIED_CHECKPOINT` เมื่อไม่มี checkpoint จริง
- เปลี่ยน metrics/digest ที่ไม่มีหลักฐานเป็น `null` และทำให้ `TrainingLogHistory` แสดง `UNVERIFIED` แบบ null-safe

## สถานะ verification ที่ต้องอ่านก่อนใช้งาน

Build และ tests ผ่าน แต่ **Runtime Model Provenance Verification ยังไม่ผ่านโดยเจตนา** เพราะ Repository ปัจจุบันไม่มี checkpoint จริง และ environment ไม่มี `torch`

ผล runtime probe ที่ตรวจจริง:

```text
status: MODEL_NOT_FOUND
registryCrossCheck: MISMATCH
checkpointExists: false
checksumMatched: null
Python native runtime: RUNTIME_UNAVAILABLE (torch unavailable)
```

ห้ามแก้ registry ให้เป็น `trained`, `INFERENCE_READY` หรือ `PRODUCTION_APPROVED` เพื่อข้าม gate นี้ หากยังไม่มี checkpoint และผล probe จริง

## ไฟล์ที่แพตช์นี้ไม่แก้

- `src/contracts/modelIdentityContract.ts`
- `lib/native-model-gateway.mjs`
- `training/registry/model_registry.json`
- `training/registry/native_model_identity.json`
- `training/native_cpu/native_runtime.py`

## Verification ก่อนแพ็ก

- TypeScript typecheck: PASS
- Production build: PASS
- Evidence provenance tests: 9/9 PASS
- Model lifecycle และ dataset quality tests: 11/11 PASS
- Synthetic evidence scan: PASS
- Null-safe Training History scan: PASS
- Runtime checkpoint verification: NOT VERIFIED — ไม่มี checkpoint จริง
- Registry cross-check: MISMATCH — แสดงตามข้อมูลจริงและไม่ถูกซ่อน
